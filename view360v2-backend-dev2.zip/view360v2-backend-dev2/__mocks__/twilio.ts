//write below mock for twilio here
const twilioConfig= jest.fn().mockImplementation((TWILIO_ACCOUNT_ID,TWILIO_AUTH_TOKEN) => {
    return {
        TWILIO_ACCOUNT_ID,
        TWILIO_AUTH_TOKEN,
        messages: {
            create: jest.fn().mockReturnValue({
                sid: '1',
            }),
        },
    }
});
export default twilioConfig;


