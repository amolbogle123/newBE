export const get=jest.fn().mockReturnValue({
    data: {
        public: {
            id: '123',
        },
        encData: 'mockedEncryptedData',
    },
});