export const readJWT= jest.fn().mockImplementation((token, secret) => {
    if (token === 'mockedCookies') {
        return {
            data: {
                id: 'mockedId',
                username: 'mockedUsername',
                useremail: 'mockedUseremail',
            },
        };
    } else {
        return {
            data: {},
        };
    }
})