// __mocks__/saml-encoder-decoder-js.js

// Mocked implementation of decodeSamlPost

  
  export const  decodeSamlPost=jest.fn().mockImplementation((xmlData, callback) => {
    // Simulate successful decoding
    callback(null, 'mocked-xml-response');
  });
  