// __mocks__/xml2js.ts

export const parseString = jest.fn((xmlResponse, options, callback) => {
    // Simulate successful parsing
    const result = {
      Response: {
        Assertion: [
          {
            AttributeStatement: [
              {
                Attribute: [
                  {
                    AttributeValue: [
                      {
                        _: 'mocked-user-data',
                      },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
    };
    callback(null, result);
  });
  export const processors= jest.fn().mockImplementation(() => {
    return {
    stripPrefix: (text) => text
    }});

  