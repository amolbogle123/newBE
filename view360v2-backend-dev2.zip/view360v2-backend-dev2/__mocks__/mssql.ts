export const connect = jest.fn().mockImplementation(() => {
    return {
        query: jest.fn().mockImplementation(() => {
            return {
                recordset: [
                    {
                        id: '123',
                        config: {
                            dbType: 'abc',
                            host: 'abc',
                            port: 'abc',
                            username: 'abc',
                            password: 'abc',
                            database: 'abc',
                        },
                        close: jest.fn().mockImplementation(() => {
                        }),
                        query: jest.fn().mockImplementation(() => {
                        })
                    }
                ]
            }
            close: jest.fn().mockImplementation(() => {
            })
        }),
        close: jest.fn().mockImplementation(() => {
        })
    };
});