const dbServiceMock = {
    _createQueryService: jest.fn(),
    _deleteMultipleQueryService: jest.fn(),
    _findQueryService: jest.fn(),
    _updateQueryService: jest.fn(),
    // ... other methods you want to mock
};

export default dbServiceMock;
