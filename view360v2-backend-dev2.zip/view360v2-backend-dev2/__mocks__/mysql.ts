import { resolve } from "path";

export const createConnection = jest.fn().mockImplementation(() => {
    return {
        query: jest.fn().mockImplementation((queryToExecute,callback) => {
            if (callback) {
                callback(null,[{
                    id: '123',
                }],[]);
            }
        }),
        destroy: jest.fn().mockImplementation(() => {
        }),
        connect: jest.fn().mockImplementation((callback?: (err: any, ...args: any[]) => void) => {
            if (callback) {
                callback(null);
            }
        }),
    };
});