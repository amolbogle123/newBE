const container = {
  get: jest.fn().mockReturnValue({
    manager: {
      save: jest.fn(),
      query: jest.fn(),
      // Add other necessary methods or mocks
    },
    getRepository: jest.fn().mockReturnValue({
      // Add other necessary methods or mocks
      findOneBy: jest.fn(),
      findOne: jest.fn(),
      find: jest.fn(),
      findBy: jest.fn(),  
      count: jest.fn(),
      save: () => Promise.resolve({
        id: '1',
      }),
      update: jest.fn(),
      delete: jest.fn(),
      create:jest.fn(),
    }),
    hasMetadata: jest.fn(),
  }),
  set: jest.fn(),
};

export default container;