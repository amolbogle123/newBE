export const Engine = jest.fn().mockImplementation(() => {
    return {
        execute: jest.fn().mockImplementationOnce(({ listener, services }) => {
            services.getRequest = jest.fn(async (scope,callback)=>{
            });
            services.check = jest.fn().mockResolvedValue({});
            return Promise.resolve({});
        }),

        stop: jest.fn(),       
    }});    