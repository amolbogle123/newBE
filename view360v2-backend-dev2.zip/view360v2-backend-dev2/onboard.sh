#!/bin/zsh

#Install HomeBrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install git
printf "Installing git..."
brew install git

# Install nodejs
printf "Installing nodejs..."
brew install node

# Install yarn
printf "Installing yarn..."
brew install yarn

# Install AWS CLI
printf "Installing AWS CLI..."
brew install awscli

# Install nvm for using node-js 18
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.3/install.sh | bash
cat <<EOF >> ~/.bashrc
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
EOF

source $HOME/.bashrc
source $HOME/.zshrc

nvm install 18.12.1
nvm use 18.12.1

# Install MySql
brew install mysql
brew services start mysql

printf "Starting MySql setup. Please choose to:\n 1. Delete the test database\n 2. Allow remote access to 'root'\nPress any key to continue..."
read -r </dev/tty
mysql_secure_installation

# Setup mysql with root password as 'admin@123'
printf "Enter MySql root password you set (you will be prompted to enter the password one more time): "
read -r -s MYSQL_ROOT_PASS
printf "\n"
printf "Setting up MySql and creating 'epikso' user"
mysql -u root -p <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password by "${MYSQL_ROOT_PASS}";
GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost';
FLUSH PRIVILEGES;
CREATE USER 'epikso'@'localhost' IDENTIFIED BY 'admin@123';
GRANT ALL PRIVILEGES ON *.* TO 'epikso'@'localhost';
FLUSH PRIVILEGES;
ALTER USER 'epikso'@'localhost' IDENTIFIED WITH mysql_native_password by 'admin@123';
EOF

printf "Finished MySql setup"
