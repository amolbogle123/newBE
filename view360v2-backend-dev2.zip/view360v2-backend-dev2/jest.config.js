module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  testMatch: ['**/__tests__/**/*.test.(ts|js)'],
  collectCoverage: true,
  coverageReporters: ['html','lcov'],
  coverageDirectory: 'coverage',
  moduleNameMapper: {
    "^typeorm$": "<rootDir>/__mocks__/typeorm.ts",
    "^typedi$": "<rootDir>/__mocks__/typedi.ts",
    "^bpmn-engine$": "<rootDir>/__mocks__/bpmn-engine.ts",
    "^saml-encoder-decoder-js$": "<rootDir>/__mocks__/samlEncoderDecoderJs.ts",
    "^xml2js$": "<rootDir>/__mocks__/xml2js.ts",
    "^objectPath$": "<rootDir>/__mocks__/objectPath.ts",
    "^mssql$": "<rootDir>/__mocks__/mssql.ts",
    "^mysql$": "<rootDir>/__mocks__/mysql.ts",
    "^twilio$": "<rootDir>/__mocks__/twilio.ts",
  },
};
