const { exec } = require('child_process');


const script = process.argv[2]; // capture the argument (e.g., 'clean' or 'build')

switch (script) {
  case 'clean':
    const cleanCommand = `rimraf dist/* && rimraf src/**/!(*activation.utils).js && rimraf src/**/*.map && rimraf __tests__/**/*.js && rimraf __tests__/**/*.map && rimraf __tests__/**/**/*.js && rimraf __tests__/**/**/*.map && rimraf __mocks__/**/*.js && rimraf __mocks__/**/*.map && rimraf __mocks__/**/**/*.js && rimraf __mocks__/**/**/*.map && rimraf dd-tracer.js && rimraf dd-tracer.js.map && rimraf tracer.js && rimraf tracer.js.map`;
    exec(cleanCommand, (err, stdout, stderr) => {
      if (err) {
        console.error(`Error: ${err}`);
        return;
      }
      console.log(`Cleaning in progress ....`);
      if (stderr) {
        console.error(`Clean stderr: ${stderr}`);
      }
    });
    break;

  case 'build':
    console.log('Build process started...');
    // Perform your build tasks here
    break;

  default:
    console.log('Unknown script:', script);
}
