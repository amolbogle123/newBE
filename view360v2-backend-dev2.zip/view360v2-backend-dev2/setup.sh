#!/usr/bin/env zsh

set -e

MYSQL_USER=${MYSQL_USER:-'epikso'}
MYSQL_PASS=${MYSQL_PASS:-'admin@123'}

printf "Installing the view360-backend application..."
yarn install

printf "Compiling the view360-backend application..."
yarn build:dev

printf "Creating the DB and tables..."
yarn db:create

### In case the migration is not working, please run the following command manually:
# printf "Migrating the DB..."
# yarn typeorm migration:run -d dist/src/core/data-source.js

printf "Finished"

exit;
