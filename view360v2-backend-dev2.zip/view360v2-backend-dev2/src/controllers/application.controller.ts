import {Response} from "express";
import {CommonHelper} from "utils/helpers/common.helper";

export default class ApplicationController {
    static handleError(res: Response, message: string): void  {
        CommonHelper.apiErrorResponse(res, {
            error: { error_description: message },
        });
    }
}
