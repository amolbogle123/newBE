import {Request, Response} from "express";

import HubSpot from "lib/hubspot";
import {CommonHelper} from "utils/helpers/common.helper";
import ApplicationController from "../application.controller";

export default class ResourcesController extends ApplicationController {
    public static async show(req: Request, res: Response): Promise<void> {
        try {
            let data;

            switch (req.params.resource) {
                case 'contacts':
                    data = await HubSpot.getContacts();
                    break;
                case 'companies':
                    data = await HubSpot.getCompanies();
                    break;
                case 'deals':
                    data = await HubSpot.getDeals();
                    break;
                default:
                    return ResourcesController.handleError(res, "Unknown HubSpot resource");
            }

            CommonHelper.apiSuccessResponse(res, { data });
        } catch (error) {
            ResourcesController.handleError(res, error.message);
        }
    }
}
