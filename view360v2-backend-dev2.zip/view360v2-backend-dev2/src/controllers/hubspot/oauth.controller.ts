import type {NextFunction, Request, Response} from 'express';

import {WidgetAccount} from "entities";
import {dataSource} from "core/data-source";
import HubSpot, { type HubSpotTokens } from "lib/hubspot";
import { CommonHelper } from "utils/helpers/common.helper";
import ApplicationController from "../application.controller";

export default class OAuthController extends ApplicationController {
    static startAuthorization(req: Request, res: Response): void {
        CommonHelper.apiSuccessResponse(res, {
            data: HubSpot.getAuthorizationUrl(req.query.returnTo as string),
        });
    }

    static async completeAuthorization(req: any, res: Response): Promise<void> {
        try {
            const tokens = await HubSpot.authorize(req.body.code);
            const currentUser = await HubSpot.getCurrentUser();
            const objWidgetAccount = new WidgetAccount();

            objWidgetAccount.widgetType = "HUBSPOT";
            objWidgetAccount.createdBy = req.userDetails.id;
            objWidgetAccount.config = JSON.stringify(tokens);
            objWidgetAccount.accountName = currentUser.email;
            objWidgetAccount.clientId = req.userDetails.client_id;

            await dataSource.manager.save(objWidgetAccount);

            CommonHelper.apiSuccessResponse(res, {})
        } catch (error) {
            OAuthController.handleError(res, error.message);
        }
    }

    static async authorize(req: Request, res: Response, next: NextFunction): Promise<void> {
        res.on('finish', () => {
            HubSpot.setToken(null);
        });

        try {
            const { config } = await dataSource
                .getRepository(WidgetAccount)
                .findOneBy({ id: req.params.widgetAccountId });

            const widgetAccountConfig: HubSpotTokens = JSON.parse(config);

            if (!widgetAccountConfig.accessToken) {
                return OAuthController.handleError(res, 'Invalid widget account');
            }

            if (HubSpot.isTokenExpired(widgetAccountConfig)) {
                await OAuthController.refresh(req.params.widgetAccountId, widgetAccountConfig);
            } else {
                HubSpot.setToken(widgetAccountConfig.accessToken);
            }

            next();
        } catch (error) {
            OAuthController.handleError(res, error.message);
        }
    }

    static async refresh(widgetAccountId: string, widgetAccountConfig: any): Promise<void> {
        const tokens = await HubSpot.refreshToken(widgetAccountConfig);

        await dataSource
            .createQueryBuilder()
            .update(WidgetAccount)
            .set({ config: JSON.stringify(tokens) })
            .where("ID = :id", { id: widgetAccountId })
            .execute();
    }
}
