import { AppRoutes } from "../../app.routes";
import OAuthController from "./oauth.controller";
import ResourcesController from "./resources.controller";

export default class HubSpotRoutes extends AppRoutes {
    constructor() {
        super();
        this.initRoutes();
    }

    initRoutes() {
        this.router.get('/oauth', OAuthController.startAuthorization);
        this.router.post('/oauth', OAuthController.completeAuthorization);
        this.router.use('/:widgetAccountId', OAuthController.authorize);

        this.router.get('/:widgetAccountId/:resource', ResourcesController.show);
    }
}
