import "reflect-metadata";
import { ConnectionService } from "./config/view360-config";
import { DataSource } from "typeorm";
import Container from 'typedi';

/* Database Connection
-------------------------- */

export class DatabaseConnection {
    private connectionService: ConnectionService = new ConnectionService();
    private maxRetries: number = Number(process.env.DB_RETRY_ATTEMPTS) || 3;
    private retryDelay: number = Number(process.env.DB_RETRY_DELAY) || 3000;

    public initialize(): DataSource {
        const databaseConnection: DataSource = this.connectionService.getConnection();
        let retries = 0;

        const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

        const tryInitialize = () => {
            databaseConnection.initialize()
                .then(() => {
                    console.log("✅ Successfully connected to the database");
                })
                .catch(async (e) => {
                    retries++;
                    console.error(`Attempt ${retries} - Unable to connect to the database. Error :: ${e}`);
                    if (retries < this.maxRetries) {
                        console.log(`Retrying in ${this.retryDelay / 1000} seconds...`);
                        await delay(this.retryDelay); // 3-second delay before retrying
                        tryInitialize(); // Retry if not reached max retries
                    } else {
                        console.error('Max retries reached. Application will break.');
                        process.exit(1);
                    }
                });
        };

        if (process.env.INITIAL_SETUP !== 'false') {
            tryInitialize();
            Container.set(DataSource, databaseConnection);
            return databaseConnection;
        } else {
            Container.set(DataSource, databaseConnection);
            return databaseConnection;
        }
    }

    public async setDbOption(entities: any[]): Promise<DataSource> {
        try {
            const databaseConnection: DataSource = this.connectionService.getConnection(entities);
            await databaseConnection.initialize();

            return databaseConnection;
        } catch (e) {
            console.error('Unable to connect to the database. Error :: ' + e);
        }
    }
}

export let reloadSetDataSource = async () => {
    let connectionService: ConnectionService = new ConnectionService();
    const databaseConnection: DataSource = connectionService.getConnection();
    return databaseConnection.initialize();
}

export let setDataSource = async (updatedDataSource: DataSource): Promise<void> => {
    dataSource = updatedDataSource;
    Container.set(DataSource, updatedDataSource);
}

export let dataSource: DataSource = new DatabaseConnection().initialize();
