import express from "express";
import compression from "compression";
import * as http from "http";
import * as https from "https";
import * as path from "path";
import fs from "fs";
import cors from "cors";
import moment from "moment";
import { ApplicationLogger, ErrorLogger } from "./config/pino-loggers";
import * as bodyParser from "body-parser";
import { AppRoutes } from "../app.routes";
import apikeyvalidation from "../utils/apikeyvalidation.util";
import { DecryptRequestUtil } from "utils/decryptrequest.util";

import { ProcessBuilderRoutes } from "../modules/process-builder-v2/process-builder.routes";
import { TemplateBuilderRoutes } from "../modules/template-builder/template-builder.routes";
import { DynamicDashBoardRoutes } from "../modules/dynamic-dashboard/dynamic-dashboard.routes";
import { SettingsRoutes } from "../modules/settings/settings.route";
import { UserRoutes } from "../modules/user/user.routes";
import { UserLogsRoutes } from "../modules/user-logs/user-logs.route";
import { FormBuilderRoutes } from "../modules/form-builder/form-builder.route";
import { MapperRoutes } from "../modules/mapper/mapper.route";
import { DocumentsRoutes } from "../modules/documents/documents.route";
import { ConfigurationRoutes } from "../modules/app-configration/configuration.routes";
import { AiDrivenRoutes } from "../modules/ai-driven/ai-driven.routes";
import { UploadFilesRoutes } from "../modules/upload-files/upload-files.route";
import { ChatbotRoutes } from "../modules/chatbot/chatbot.route";
import { NotificationRoutes } from "../modules/notification/notification.route";
import swaggerFile from "../../swagger/swagger.json";
import swaggerUi from "swagger-ui-express";
import LogMiddleware from "utils/log.middleware";
import { AdfsRoutes } from "../modules/adfs-ad/adfs.routes";
import { OpenApiRoutes } from "../modules/open-api/open-api.routes";
import { ValidateError } from "tsoa";
import HubSpotRoutes from "../controllers/hubspot/routes";
import { CustomFootersRoutes } from "../modules/custom-footer/custom-footer.routes";
import { CustomHeaderRoutes } from "../modules/custom-header/custom-header.routes";
import { RequestFormsRoutes } from "../modules/request-forms/request-forms.routes";
import { ThemeRoutes } from "../modules/theme/theme.route";
import { RegisterRoutes } from "../routes/routes";
import { ConfigRoutes } from "../modules/configuration/config.routes";
import { CustomBodyRoutes } from "../modules/custom-body/custom-body.routes";
import { rateLimiterMiddleware } from "../middlewares/rate-limiter.middleware";
const cookieParser = require("cookie-parser");

const apival = new apikeyvalidation();

export class Bootstrap {
    private SET_API_VERSION: string = "v2";
    private express = express();

    /**
     * Application bootstrap
     * @param app
     */
    bootstrap(): void {
        this.setupCors(this.express);
        this.defineExpressApp(this.express);
        this.configure(this.express);

        // Rate Limiter
        this.setupRateLimiter(this.express);

        // Setup routes
        this.setupRoutes(this.express);
        this.startHttpServer(this.express);

        // Syncronize module list
        // this.syncModuleList();
        // setInterval(this.syncModuleList, 2 * 60 * 60 * 1000); // 2 hours

        this.express.on("listening", () => {
            const port =
                this.express.get("enableHttps") === true
                    ? this.express.get("securePort")
                    : this.express.get("port");

            const msg = `Application is ready on ${
                this.express.get("host") || "localhost"
            }:${port}`;

            console.log(`✅ ${msg}`);
            ApplicationLogger.info(msg);
        });

        this.express.on("error", (error?: any) => {
            switch (error.code) {
                case "EACCES":
                    console.error(`The Server requires elevated privileges`);
                    ApplicationLogger.error(
                        `The Server requires elevated privileges`
                    );
                    process.exit(1);
                    break;
                case "EADDRINUSE":
                    console.error(
                        `Port is already in use or blocked by the os`
                    );
                    ApplicationLogger.error(
                        `Port is already in use or blocked by the os`
                    );
                    process.exit(1);
                    break;
                default:
                    throw error;
            }
        });
    }

    /**
     * Set application port
     * @param app
     */
    defineExpressApp(app: express.Application) {
        app.set("port", process.env.EXPRESS_PORT || 8080);
    }

    configure(app: express.Application): void {
        app
            // Parse incoming request bodies in a middleware before your handlers, available under the req.body property.
            .use(bodyParser.json({ limit: "100mb" }))
            .use(
                bodyParser.urlencoded({
                    limit: "100mb",
                    extended: true,
                })
            )
            .use(cookieParser());

        const DisableAuthorizePlugin = function () {
            return {
                wrapComponents: {
                    authorizeBtn: () => () => null,
                },
            };
        };

        const swaggerOptions = {
            swaggerOptions: {
                plugins: [DisableAuthorizePlugin],
            },
        };

        app.use(
            "/docs",
            swaggerUi.serve,
            swaggerUi.setup(swaggerFile, swaggerOptions)
        );
    }

    /**
     * This method will start http server
     * @param app
     */
    startHttpServer(app: express.Application): http.Server {
        let httpServer;
        let isHTTPS = process.env.IS_HTTPS || "false";
        if (isHTTPS === "true") {
            let privateKey = fs.readFileSync("./ssl/private.key").toString();
            let certificate = fs
                .readFileSync("./ssl/certificate.crt")
                .toString();
            let cabundle = fs.readFileSync("./ssl/ca_bundle.crt").toString();
            let credentials = {
                key: privateKey,
                cert: certificate,
                ca: [cabundle],
            };
            httpServer = https.createServer(credentials, app);
            https.globalAgent.options.rejectUnauthorized = false;
        } else {
            httpServer = http.createServer(app);
        }
        httpServer.listen(app.get("port"), () => {
            ApplicationLogger.info(
                "Express server listening on port " + app.get("port")
            );
        });

        process
            .on("unhandledRejection", (reason, p) => {
                ApplicationLogger.error({
                    unhandledRejection: reason.toString(),
                    Occurredtime: moment(Date.now()).format(
                        "MM-DD-YYYY HH:mm:ss"
                    ),
                });
                console.error(reason, "Unhandled Rejection at Promise", p);
            })
            .on("uncaughtException", (err) => {
                ApplicationLogger.error({
                    uncaughtException: err.toString(),
                    Occurredtime: moment(Date.now()).format(
                        "MM-DD-YYYY HH:mm:ss"
                    ),
                });
                console.error(err, "Uncaught Exception thrown");
            });

        // Event listener for app start
        httpServer.on("listening", () => {
            ApplicationLogger.info({
                StartTime: moment(Date.now()).format("MM-DD-YYYY HH:mm:ss"),
            });
        });

        // Event listener for app restart
        // process.on('SIGINT', () => {
        //     ServerLogger.info({ RestartTime: moment(Date.now()).format('MM-DD-YYYY HH:mm:ss') });
        // });
        return httpServer;
    }

    /**
     * It will initialize all server side routes
     * @param app
     */
    setupRoutes(app: express.Application): void {
        app.get("/health-status/:id", (req, res) => {
            res.status(200).json({ 
                status: "UP" ,
                message: `Health Check ${req.params.id} is working fine`
            });
        });

        app.use(
            "/public/theme-builder",
            express.static(path.join("./", "public/theme-builder"))
        );
        app.use(
          "/public/embed-form",
          express.static(path.join("./", "public/embed-form"))
      );
        app.use(express.static(path.join("./", "client")));
        app.use(express.static(path.join("./", "public")));
        app.use(cookieParser());
        app.use(apival.validate);
        const decryptRequest: DecryptRequestUtil = new DecryptRequestUtil();
        app.use(decryptRequest.decryptRequestData);

        const logMiddleware: LogMiddleware = new LogMiddleware();
        if (process.env.IS_LOGS_ENABLED !== "false") {
            app.use(logMiddleware.log);
        }

        // Define the path to your CSS file
        const cssFilesDirectory = path.join(__dirname, "/public/theme-builder");
        console.log(cssFilesDirectory,'csssss')
        // Define the route to serve the CSS file dynamically
        app.get("/public/theme-builder/:filename", (req, res) => {
            const filename = req.params.filename;
            const cssFilePath = path.join(cssFilesDirectory, filename);
            res.sendFile(cssFilePath);
        });

        const jssFilesDirectory = path.join(__dirname, "/public/embed-form");

        // Define the route to serve the CSS file dynamically
        app.get("/public/embed-form/:filename", (req, res) => {
            const filename = req.params.filename;
            const cssFilePath = path.join(jssFilesDirectory, filename);
            res.sendFile(cssFilePath);
        });
        
        // Routes
        app.use(new AppRoutes().router);
        app.use(new DynamicDashBoardRoutes().router);
        app.use(new ProcessBuilderRoutes().router);
        app.use(new TemplateBuilderRoutes().router);
        app.use(new SettingsRoutes().router);
        app.use(new UserRoutes().router);
        app.use(new UserLogsRoutes().router);
        app.use(new FormBuilderRoutes().router);
        app.use(new MapperRoutes().router);
        app.use(new DocumentsRoutes().router);
        app.use(new ConfigurationRoutes().router);
        app.use(new ConfigRoutes().router);
        app.use(new AiDrivenRoutes().router);
        app.use(new AdfsRoutes().router);
        app.use(new UploadFilesRoutes().router);
        app.use(new ChatbotRoutes().router);
        app.use(new NotificationRoutes().router);
        app.use(new CustomFootersRoutes().router);
        app.use(new CustomHeaderRoutes().router);
        app.use(new CustomBodyRoutes().router);
        app.use(new OpenApiRoutes().router);
        app.use(new RequestFormsRoutes().router);

        app.use(new ThemeRoutes().router);
        app.use("/hubspot", new HubSpotRoutes().router);

        // Apply compression middleware
        app.use(compression());

        RegisterRoutes(app);

        app.use((err, req, res, next) => {
            ErrorLogger.error({
                error: err.toString(),
                Occurredtime: moment(Date.now()).format("MM-DD-YYYY HH:mm:ss"),
            });
            res.status(500).json({ error: err.toString() });
        });

        app.use(function notFoundHandler(_req, res: express.Response) {
            res.status(404).json({
                status: 404,
                error: true,
                message: "Not Found",
            });
        });

        app.use(function errorHandler(
            err: unknown,
            req: express.Request,
            res: express.Response,
            next: express.NextFunction
        ): express.Response | void {
            if (err instanceof ValidateError) {
                console.warn(
                    `Caught Validation Error for ${req.path}:`,
                    err.fields
                );
                return res.status(422).json({
                    status: 422,
                    error: true,
                    message: "Validation Failed",
                    details: err?.fields,
                });
            }
            if (err instanceof Error) {
                console.log("Error :: ", err);
                return res.status(500).json({
                    status: 500,
                    error: true,
                    message: "Internal Server Error",
                });
            }
            next();
        });
    }

    setupCors(app: express.Application): void {
        let isAllowedOrigin =
            process.env.ALLOWED_ORIGIN || "http://localhost:4200";
        const allOrigin = isAllowedOrigin.split(",").map((item) => item.trim());

    // Middleware to dynamically set CORS options
    // const dynamicCors = (req, res, next) => {
    //   let origin = req.header('origin');
    //     if (!origin) {
    //         cors()(req, res, next);
    //     } else if (
    //     ['/public/chatbot/embed.js', '/chatbot/chatbot.css'].includes(req.path) || 
    //     req.path.startsWith('/embed-chatbot/') ||
    //     req.path.startsWith('/public/media-assets')
    //   ) {
    //     cors()(req, res, next);
    //   } else if (allOrigin.indexOf(origin) !== -1) {
    //     const corsOptionsSpecific = {
    //       origin: origin,
    //       credentials: true,
    //       optionsSuccessStatus: 200,
    //     };
    //     cors(corsOptionsSpecific)(req, res, next);
    //   }
    // };
    // app.use(dynamicCors);
    // console.log('process.env.ALLOWED_ORIGIN', process.env.ALLOWED_ORIGIN);
    // console.log('allOrigin', allOrigin);
    app.use(cors({ origin: allOrigin, credentials: true, optionsSuccessStatus: 200 }));
  }

    // syncModuleList() {
    //   console.log("Inside Sync Module List")
    //   const subscriptionModuleService = new SubscriptionModuleService();
    //   subscriptionModuleService.syncModuleList();
    // }

    setupRateLimiter(app: express.Application): void {
        const urlRateLimiter = rateLimiterMiddleware(parseInt(process.env.RATE_LIMITER_MAX) || 50, parseInt(process.env.RATE_LIMITER_WINDOW_MS) || 60 * 1000);
        if (process.env.RATE_LIMITER === 'true') {
            app.use(urlRateLimiter);
        }
    }
}
