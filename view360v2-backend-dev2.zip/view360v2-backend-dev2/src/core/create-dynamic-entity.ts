import { InstanceChecker } from 'typeorm';

import { ConnectionMetadataBuilder } from 'typeorm/connection/ConnectionMetadataBuilder';
import { EntityMetadataValidator } from 'typeorm/metadata-builder/EntityMetadataValidator';
import { ObjectUtils } from 'typeorm/util/ObjectUtils';

import { dataSource } from './data-source';

export async function addEntities(...entities) {
    const connectionMetadataBuilder = new ConnectionMetadataBuilder(dataSource);
    const entityMetadataValidator = new EntityMetadataValidator();

    // build entity metadatas
    const flattenedEntities = ObjectUtils.mixedListToArray(entities || []);
    const entityMetadatas = await connectionMetadataBuilder.buildEntityMetadatas(
        flattenedEntities
    );

    entityMetadatas.forEach((entityMetadata) => {
        if (dataSource.hasMetadata(entityMetadata.target)) {
            throw new Error(`entity ${entityMetadata.targetName} already exists`);
        } else {
            dataSource.entityMetadatas.push(entityMetadata);
        }
    });

    // validate all created entity metadatas to make sure user created entities are valid and correct
    entityMetadataValidator.validateMany(
        entityMetadatas.filter((metadata) => metadata.tableType !== 'view'),
        dataSource.driver
    );

    // set current data source to the entities
    for (let entityMetadata of entityMetadatas) {
        if (InstanceChecker.isBaseEntityConstructor(entityMetadata.target)) {
            entityMetadata.target.useDataSource(dataSource);
        }
    }
}