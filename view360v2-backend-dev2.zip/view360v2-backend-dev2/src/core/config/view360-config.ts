import "reflect-metadata"
import { DataSource } from "typeorm";
import * as dotenv from 'dotenv';
import { getVaultConfig, preloadVaultSecrets } from "./vault-config";
dotenv.config()
export class ConnectionService {
    public getConnection(userEntities?: any): DataSource {
        preloadVaultSecrets();
        const dbConfig = dbConfiguration();
        console.log("DB Config :: 9 :: ", dbConfig);
        if (Array.isArray(userEntities) && userEntities.length > 0) {
            dbConfig.entities.push(...userEntities)
        }

        return new DataSource(dbConfig);
    }
}

export function dbConfiguration() {
    const vaultConfig = getVaultConfig(); // Get cached secrets from Vault

    let entities = require("../../entities");
    entities = Object.keys(entities).map(key => entities[key]);

    const dbConfig = {
        host: vaultConfig.DB_HOST || process.env.DB_HOST || "127.0.0.1",
        port: vaultConfig.DB_PORT || process.env.DB_PORT || 3306,
        type: vaultConfig.DB_TYPE || process.env.DB_TYPE || 'mysql' as any,
        username: vaultConfig.DB_USERNAME || process.env.DB_USERNAME || "root",
        password: vaultConfig.DB_PASSWORD || process.env.DB_PASSWORD || "",
        database: vaultConfig.DB_NAME || process.env.DB_NAME || "view360",
        synchronize: process.env.DB_SYNCHRONIZE === 'true',
        logging: process.env.DB_LOGGING !== 'false',
        connectTimeout: Number(process.env.DB_CONNECTION_TIMEOUT),
        acquireTimeout: Number(process.env.DB_CONNECTION_TIMEOUT),
        migrations: ["src/database/migrations/*{.ts,.js}", "dist/src/database/migrations/*{.ts,.js}"],
        entitiesDir: "../../entities",
        migrationsDir: "src/database/migrations",
        seeds: ['src/database/seeds/*{.ts,.js}'],
        entities: entities,
    };

    return dbConfig;
}
