import moment from 'moment';
import pino from 'pino';

const tal = pino.transport({
  targets: [
    {
      level: "info",
      target: 'pino-roll',
      options: { destination: process.cwd() + `/logs/Application.` + moment().format("YYYY-MM-DD") ,file: process.cwd() + `/logs/Application.`+ moment().format("YYYY-MM-DD") , frequency: 'daily', mkdir: true },
    },
    {
      level: "info",
      target: 'pino-pretty',
      options: { 
        colorize: true,
        messageFormat: '{method} - {reqURL} - {status} - {processingTime} ms',
        // singleLine:true,
        hideObject:true,
        customColors: 'err:red,info:blue',
        customPrettifiers: {
          // The argument for this function will be the same
          // string that's at the start of the log-line by default:
          // time: timestamp => `🕰 ${timestamp}`,

          // The argument for the level-prettifier may vary depending
          // on if the levelKey option is used or not.
          // By default this will be the same numerics as the Pino default:
          // level: logLevel => `LEVEL: ${logLevel}`,

          // other prettifiers can be used for the other keys if needed, for example
          // hostname: hostname => colorGreen(hostname),
          // pid: pid => colorRed(pid),
          // name: name => colorBlue(name),
          // caller: caller => colorCyan(caller)
        }
      } // use 2 for stderr
    }
  ],
});

const transportAccessLogs = pino.transport({
  targets: [
    {
      level: "info",
      target: 'pino-roll',
      options: { destination: process.cwd() + `/logs/Application.`+ moment().format("YYYY-MM-DD"), file: process.cwd() + `/logs/Application.`+ moment().format("YYYY-MM-DD"), frequency: 'daily', mkdir: true },
    }
  ],
});

const transportErrorLogs = pino.transport({
  targets: [
    {
      level: "error",
      target: 'pino-roll',
      options: { destination: process.cwd() + `/logs/Error.`+ moment().format("YYYY-MM-DD"), file: process.cwd() + `/logs/Error.`+ moment().format("YYYY-MM-DD"), frequency: 'daily', mkdir: true },
    }
  ],
});


const findLoggerLevel = pino();
const formatter: any = {
    level: process.env.PINO_LOG_LEVEL || 'info',
    timestamp: pino.stdTimeFunctions.isoTime,
    enabled:process.env.isLogsEnabled !== 'false',
    mixin(_context, level) {
      return { 'level-label': findLoggerLevel.levels.labels[level] }
    }
};

export const AccessLogger = pino(formatter, transportAccessLogs);
export const ApplicationLogger = pino(formatter,tal);
export const ErrorLogger = pino(formatter,transportErrorLogs);
