import { ConfigurationService } from 'services/configuration.service';
import deasync from 'deasync';

let vaultConfig: Record<string, any> = {};
let isPreloaded = false;

export function preloadVaultSecrets() {
    if (process.env.IS_VAULT_ENABLED === 'true') {
        const configurationService = new ConfigurationService();

        // Load Vault secrets synchronously using deasync
        configurationService.getSecrets(process.env.IS_VAULT_ENABLED, process.env.VAULT_NAME)
            .then(secrets => {
                console.log("Secrets fetched from Vault:", secrets);
                vaultConfig = secrets;
                isPreloaded = true; // Mark preload complete
            })
            .catch(error => {
                console.error("Error fetching secrets from Vault:", error);
                isPreloaded = true; // Even on error, mark preload complete
            });

        // Block the execution until isPreloaded becomes true
        deasync.loopWhile(() => !isPreloaded);
    } else {
        isPreloaded = true; // If Vault is not enabled, mark it as complete
    }
}

export function getVaultConfig() {
    return vaultConfig;
}
