import * as express from 'express';

export class AppRoutes {

    public router: express.Router;

    constructor() {
        this.router = express.Router();
        this.initRoutes();
    }

    initRoutes() {
    	this.router.get('/test', (req,res, next) => res.send("API v2"));
    }
}
