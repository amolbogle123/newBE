import { Entity, CreateDateColumn, ManyToOne, JoinColumn } from "typeorm";
import { MdbClient } from "../entities";
import { getColumnType, getType } from "../services/db.service";

@Entity("usersbkp")
export class UserBkp {
    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id: string;

    // @Column({ type: 'int', name: 'CLIENT_ID' })
    @getColumnType({
        name: "CLIENT_ID",
        mongoType: "number",
        postgresType: "int",
        type: "int",
    })
    clientId!: number;

    @ManyToOne(() => MdbClient, (mdbClient: MdbClient) => mdbClient.id, {
        onDelete: "CASCADE",
    })
    @JoinColumn({ name: "CLIENT_ID" })
    mdbClient: MdbClient;

    // @Column({ type: 'varchar', length: 255, name: 'ROLE_ID', nullable: true })
    @getColumnType({
        name: "ROLE_ID",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        length: 255,
        nullable: true,
        isLengthRequired: true,
    })
    roleID: string;

    // @Column({ type: 'int', name: 'IS_SUPERADMIN', default: 0 })
    @getColumnType({
        name: "IS_SUPERADMIN",
        mongoType: "number",
        postgresType: "int",
        type: "int",
        default: 0,
    })
    isSuperAdmin: number;

    // @Column({ type: 'int', name: 'IS_ADMIN', default: 0 })
    @getColumnType({
        name: "IS_ADMIN",
        mongoType: "number",
        postgresType: "int",
        type: "int",
        default: 0,
    })
    isAdmin: number;

    // @Column({ type: 'varchar', name: 'TEAM_ID', nullable: true })
    @getColumnType({
        name: "TEAM_ID",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    teamId: number;

    // @Column({ type: 'varchar', name: 'USER_MANAGER', nullable: true })
    @getColumnType({
        name: "USER_MANAGER",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    userManager: string;

    // @Column({ type: 'varchar', name: 'FIRST_NAME', nullable: true })
    @getColumnType({
        name: "FIRST_NAME",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    firstName: string;

    // @Column({ type: 'varchar', name: 'LAST_NAME', nullable: true })
    @getColumnType({
        name: "LAST_NAME",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    lastName: string;

    // @Column({ type: 'varchar', name: 'EMAIL', nullable: true })
    @getColumnType({
        name: "EMAIL",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    email: string;

    // @Column({ type: 'varchar', name: 'PHONE', nullable: true })
    @getColumnType({
        name: "PHONE",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    phone: string;

    // @Column({ type: 'varchar', name: 'USERNAME', nullable: true })
    @getColumnType({
        name: "USERNAME",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    userName: string;

    // @Column({ type: 'varchar', name: 'PASSWORD', nullable: true })
    @getColumnType({
        name: "PASSWORD",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    password: string;

    // @Column({ type: 'varchar', name: 'STATE', nullable: true })
    @getColumnType({
        name: "STATE",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    state: string;

    // @Column({ type: 'varchar', name: 'CITY', nullable: true })
    @getColumnType({
        name: "CITY",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    city: string;

    // @Column({ type: 'varchar', name: 'ZIP', nullable: true })
    @getColumnType({
        name: "ZIP",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    zip: string;

    // @Column({ type: 'varchar', name: 'HASHCODE', nullable: true })
    @getColumnType({
        name: "HASHCODE",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    hashcode: string;

    // @Column({ type: 'timestamp', name: 'PASS_RESET_DATE', nullable: true })
    @getColumnType({
        name: "PASS_RESET_DATE",
        mongoType: "number",
        postgresType: "timestamp",
        type: "timestamp",
        nullable: true,
    })
    passResetDate: number;

    // @Column({ type: 'varchar', name: 'HIRE_DATE', nullable: true })
    @getColumnType({
        name: "HIRE_DATE",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    hireDate: string;

    // @Column({ type: 'varchar', name: 'ADDRESS' })
    @getColumnType({
        name: "ADDRESS",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
    })
    address: string;

    // @Column({ type: 'varchar', name: 'COUNTRY' })
    @getColumnType({
        name: "COUNTRY",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
    })
    country: string;

    // @Column({ type: 'varchar', name: 'DEPARTMENT' })
    @getColumnType({
        name: "DEPARTMENT",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
    })
    department: string;

    // @Column({ type: 'varchar', name: 'JOB_TITLE' })
    @getColumnType({
        name: "JOB_TITLE",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    jobTitle: string;

    // @Column({ type: 'varchar', name: 'MOBILE' })
    @getColumnType({
        name: "MOBILE",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
    })
    mobile: string;

    // @Column({ type: 'varchar', name: 'TAG', nullable: true })
    @getColumnType({
        name: "TAG",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    tag: string;

    // @Column({ type: 'varchar', name: 'CHILD_COMPANY', nullable: true })
    @getColumnType({
        name: "CHILD_COMPANY",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    childCompany: string;

    // @Column({ type: 'varchar', name: 'LOCATION', nullable: true })
    @getColumnType({
        name: "LOCATION",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    location: string;

    // @Column({ type: 'integer', name: 'WORKING_YEAR', default: () => new Date().getFullYear().toString() })
    @getColumnType({
        name: "WORKING_YEAR",
        mongoType: "number",
        postgresType: "int",
        type: "int",
        default: () => new Date().getFullYear().toString(),
    })
    workingYear!: Date;

    // @Column({ type: 'int', name: 'IS_ACTIVE', default: 1 })
    @getColumnType({
        name: "IS_ACTIVE",
        mongoType: "number",
        postgresType: "int",
        type: "int",
        default: 1,
    })
    isActive: number;

    // @Column({ type: 'varchar', name: 'APPLY_THEMES', default: 'default' })
    @getColumnType({
        name: "APPLY_THEMES",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        default: "default",
    })
    applyThemes: string;

    // @Column({ type: 'varchar', name: 'DISABLED_STATUS', default: 1 })
    @getColumnType({
        name: "DISABLED_STATUS",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        default: 1,
    })
    disabledStatus: number;

    // @Column({ type: 'varchar', name: 'PROFILE_IMAGE', default: 1 })
    @getColumnType({
        name: "PROFILE_IMAGE",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        default: 1,
    })
    profileImage: number;

    // @Column({ type: 'varchar', name: 'PROFILE_URL', nullable: true })
    @getColumnType({
        name: "PROFILE_URL",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    profileURL: string;

    // @Column({ type: 'varchar', name: 'LANID', nullable: true })
    @getColumnType({
        name: "LANID",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    lanID: string;

    // @Column({ type: 'text', name: 'MENU_LIST', nullable: true })
    @getColumnType({
        name: "MENU_LIST",
        mongoType: "string",
        postgresType: "text",
        type: "text",
        nullable: true,
    })
    menuList: string;

    // @Column({ type: 'varchar', name: 'EMAIL_VERIFIED', default: 0 })
    @getColumnType({
        name: "EMAIL_VERIFIED",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        default: 0,
    })
    emailVerified: number;

    // @Column({ type: 'text', name: 'CHANGE_PASSWORD_TOKEN', nullable: true })
    @getColumnType({
        name: "CHANGE_PASSWORD_TOKEN",
        mongoType: "string",
        postgresType: "text",
        type: "text",
        nullable: true,
    })
    changePasswordToken: string;

    // @Column({ type: 'timestamp', name: 'LAST_LOGIN_DATE', nullable: true })
    @getColumnType({
        name: "LAST_LOGIN_DATE",
        mongoType: "date",
        postgresType: "timestamp",
        type: "timestamp",
        nullable: true,
    })
    lastLoginDate: Date;

    // @Column({ type: 'timestamp', name: 'CURRENT_LOGIN_DATE', nullable: true })
    @getColumnType({
        name: "CURRENT_LOGIN_DATE",
        mongoType: "date",
        postgresType: "timestamp",
        type: "timestamp",
        nullable: true,
    })
    currentLoginDate: Date;

    // @Column({ type: 'timestamp', name: 'UPDATED_DATE', nullable: true })
    @getColumnType({
        name: "UPDATED_DATE",
        mongoType: "date",
        postgresType: "timestamp",
        type: "timestamp",
        nullable: true,
    })
    updatedDate: Date;

    // @Column({ type: 'timestamp', name: 'UPDATED_AT', nullable: true })
    @getColumnType({
        name: "UPDATED_AT",
        mongoType: "date",
        postgresType: "timestamp",
        type: "timestamp",
        nullable: true,
    })
    updatedAt: Date;

    @CreateDateColumn({ type: "timestamp", name: "CREATEDON" })
    createdOn: Date;

    // @Column({ type: 'text', name: 'CHANGE_PASSWORD_TOKENS', nullable: true })
    @getColumnType({
        name: "CHANGE_PASSWORD_TOKENS",
        mongoType: "string",
        postgresType: "text",
        type: "text",
        nullable: true,
    })
    changePasswordTokens: string;

    // @Column({ type: 'text', name: 'AI_APP', nullable: true })
    @getColumnType({
        name: "AI_APP",
        mongoType: "string",
        postgresType: "text",
        type: "text",
        nullable: true,
    })
    aiApp: string;

    // @Column({ type: 'int', name: 'IS_DELETED', default: 0 })
    @getColumnType({
        name: "IS_DELETED",
        mongoType: "number",
        postgresType: "int",
        type: "int",
        default: 0,
    })
    isDeleted: number;

    // @Column({ type: 'varchar', name: 'ESCALATION_CONTACT1', nullable: true })
    @getColumnType({
        name: "ESCALATION_CONTACT1",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    escalationContact1: string;

    // @Column({ type: 'varchar', name: 'ESCALATION_CONTACT2', nullable: true })
    @getColumnType({
        name: "ESCALATION_CONTACT2",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    escalationContact2: string;

    // @Column({ type: 'varchar', name: 'IS_VIEW360_LOGIN', default: 1 })
    @getColumnType({
        name: "IS_VIEW360_LOGIN",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        default: 1,
    })
    isView360Login: number;
}
