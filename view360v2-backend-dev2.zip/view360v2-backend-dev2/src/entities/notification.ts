import { CreateDateColumn, Entity, Index } from 'typeorm';

import { getColumnType, getType } from '../services/db.service';

@Entity('notification')
export class Notification  {

    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    // @Column({ name: 'CLIENT_ID', type: 'int' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    // @Column({ name: 'TYPE', type: "varchar", length: 100 })
    @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'varchar', type: "varchar", length: 100, isLengthRequired: true })
    type!: string;

    // @Column({ name: 'SENDER_ID', type: "char", length: 36 })
    @getColumnType({ name: 'SENDER_ID', mongoType: 'string', postgresType: 'char', type: "char", length: 36 })
    senderId!: string;

    // @Column({ name: 'RECIEVER_ID', type: "char", length: 36 })
    @getColumnType({ name: 'RECIEVER_ID', mongoType: 'string', postgresType: 'char', type: "char", length: 36 })
    receiverId!: string;

    // @Column({ name: 'ROLE_TYPE', type: "int" })
    @getColumnType({ name: 'ROLE_TYPE', mongoType: 'string', postgresType: 'char', type: "char", length: 36 })
    roleType!: string;

    // @Column({ name: 'MESSAGE', type: "text" })
    @getColumnType({ name: 'MESSAGE', mongoType: 'string', postgresType: 'text', type: "text" })
    message!: string;

    // @Column({ name: 'EXTRA_MESSAGE', type: "text", nullable: true })
    @getColumnType({ name: 'EXTRA_MESSAGE', mongoType: 'string', postgresType: 'text', type: "text", nullable: true })
    extraMessage!: string;

    // @Column({ name: 'VIEW_MESSAGE', type: "smallint", default: 0 })
    @getColumnType({ name: 'VIEW_MESSAGE', mongoType: 'number', postgresType: 'smallint', type: "smallint", default: 0 })
    viewMessage!: number;

    // @Column({ name: 'REDIRECT_URL', type: "text" })
    @getColumnType({ name: 'REDIRECT_URL', mongoType: 'string', postgresType: 'text', type: "text" })
    redirectUrl!: string;

    // @Column({ name: 'CREATED_BY', type: "char", length: 36 })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: "char", length: 36 })
    createdBy!: string;

    @CreateDateColumn({name: 'CREATED_ON', type: "timestamp"})
    createdOn!: Date;
    
    @getColumnType({ name: 'EXTRA_DATA', mongoType: 'string', postgresType: 'text', type: "text", nullable: true })
    extraData!: any;
}
