import { Entity, Index, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';

import { MdbClient } from "./mdb-client";
import { getColumnType, getType } from '../services/db.service';

@Entity("chatbot_history")
export class ChatbotHistory  {

    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    @ManyToOne(() => MdbClient, (mdbClient: MdbClient) => mdbClient.id, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'CLIENT_ID' })
    mdbClient: MdbClient;

    @getColumnType({ name: 'SESSION_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    sessionId: string;
    
    @getColumnType({ name: 'DOCUMENT_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    documentId: string;
    
    @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    type!: string;

    @getColumnType({ name: 'MSG', mongoType: 'text', postgresType: 'text', type: 'longtext', nullable: true })
    msg!: string;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;
}
