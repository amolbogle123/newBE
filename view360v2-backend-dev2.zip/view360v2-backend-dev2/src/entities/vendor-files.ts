import {Entity, CreateDateColumn, Index} from 'typeorm'
import {getColumnType, getType} from "../services/db.service";

@Entity('vendor_files')
export class VendorFiles  {

    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId!: number;
    
    @getColumnType({ name: 'DOC_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255})
    docName!: string;

    @getColumnType({ name: 'FILE_PATH', mongoType: 'string', postgresType: 'char', type: 'char', length: 255 })
    filePath!: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;
}
