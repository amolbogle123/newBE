import {
    Entity,
    CreateDateColumn,
    Index
} from 'typeorm';
import { getColumnType, getType } from '../services/db.service';

@Entity("genai_history")
export class GenAIHistory {
    // @PrimaryGeneratedColumn("uuid", {name: 'ID'})
    @getType()
    id: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'string', postgresType: 'int', type: 'int', })
    clientId: number;

    // @Column({ type: 'varchar', length: 255, name: 'NAME', nullable: true })
    @getColumnType({ name: 'QUESTION', mongoType: 'text', postgresType: 'text', type: 'longtext', nullable: true })
    question!: string;

    // @Column({ type: 'char', length: 36, name: 'CREATEDBY' })
    @getColumnType({ name: 'ANSWER', mongoType: 'text', postgresType: 'text', type: 'longtext' })
    answer: string;

     // @Column({ type: 'varchar', length: 255, name: 'NAME', nullable: true })
     @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
     type!: string;

     @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
     createdOn!: Date;

}
