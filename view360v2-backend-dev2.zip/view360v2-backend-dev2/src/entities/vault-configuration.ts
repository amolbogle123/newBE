import { CreateDateColumn, Entity, Index } from 'typeorm';
import { getColumnType, getType } from '../services/db.service';

@Entity('vault_configuration')
export class VaultConfiguration {
    @getType()
    id!: number;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    clientId!: number;

    @getColumnType({ name: 'VAULT_URL', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    vaultUrl !: string;

    @getColumnType({ name: 'VAULT_PORT', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    vaultPort!: string;

    @getColumnType({ name: 'SECRET_SHARES', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    secretShares!: number;
    
    @getColumnType({ name: 'SECRET_THRESHOLD', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    secretThreshold!: number;

    @getColumnType({ name: 'TOKEN', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    token !: string;

    @getColumnType({ name: 'KEYS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    keys!: string;

    @getColumnType({ name: 'VAULT_INITIALIZED', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    vaultInitialized!: boolean;
    
    @getColumnType({ name: 'ENCRYPTED_VALUES', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    ecryptedValues!: number;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn: Date;
}