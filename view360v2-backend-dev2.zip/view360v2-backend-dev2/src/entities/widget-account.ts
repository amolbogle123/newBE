import {
    Entity,
    CreateDateColumn,
    Index
} from 'typeorm'
import {getColumnType, getType} from "../services/db.service";

@Entity('widget_account')
export class WidgetAccount  {

    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id!: string;

    // @Column({type: 'int', name: 'CLIENT_ID'})
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId!: number;

    // @Column({type: 'varchar', name: 'WIDGET_TYPE'})
    @getColumnType({ name: 'WIDGET_TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    widgetType!: string;

    // @Column({type: 'varchar', name: 'ACCOUNT_NAME'})
    @getColumnType({ name: 'ACCOUNT_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    accountName!: string;

    // @Column({type: 'text', name: 'CONFIG'})
    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: 'text', })
    config!: string;

    // @Column({name: 'CREATED_BY', type: 'char', length: 36})
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
    
    @getColumnType({ name: 'SECRET_CONFIG_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, default: '' })
    secretConfigId!: string;
}
