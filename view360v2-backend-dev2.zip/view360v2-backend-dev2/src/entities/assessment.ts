import { CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';
import { getColumnType } from '../services/db.service';

@Entity('assessment')
export class Assessment {
    @PrimaryGeneratedColumn('uuid')
    id!: number;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    clientId!: number;

    @getColumnType({ name: 'USER_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    userId!: number;

    @getColumnType({ name: 'ASSESSMENT_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    assessmentName!: string;

    @getColumnType({ name: 'ASSESSMENT_DESCRIPTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', default: '' })
    assessmentDescription!: string;

    @getColumnType({ name: 'DOCUMENT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    documentId!: string;

    @getColumnType({ name: 'ASSESSMENT_TEMPLATE_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    assessmentTemplateId!: number;

    @getColumnType({ name: 'ASSESSMENTS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 10000})
    assessments!: string;

    @getColumnType({ name: 'STATUS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', default: 'pending' })
    status!: number;

    @getColumnType({ name: 'IS_ACTIVE', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    isActive!: number;

    @getColumnType({ name: 'IS_DELETED', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    isDeleted!: number;

    @CreateDateColumn({ name: 'CREATED_ON', type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
    createdOn: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'UPDATED_ON', type: 'timestamp', default: '', onUpdate: "CURRENT_TIMESTAMP(6)" })
    updatedOn: string;

    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, default: '' })
    updatedBy!: string;
}