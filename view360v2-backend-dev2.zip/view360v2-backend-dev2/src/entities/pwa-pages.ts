import { CreateDateColumn, Entity } from 'typeorm';

import { getColumnType, getType } from '../services/db.service';

@Entity("pwa_pages")
export class PwaPages  {

    @getType()
    id!: string;

    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    name!: string;

    @getColumnType({ name: 'PAGE_URL', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    pageUrl!: string;

    @getColumnType({ name: 'CREATEDBY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    createdBy: string;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;
}
