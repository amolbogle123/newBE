import { Entity, Index, UpdateDateColumn, CreateDateColumn } from "typeorm";

import { getColumnType, getType } from "../services/db.service";

@Entity("themes")
export class Themes  {
    @getType()
    id!: string;

    @Index()
    @getColumnType({
        name: "CLIENT_ID",
        mongoType: "number",
        postgresType: "int",
        type: "int",
    })
    client_id!: number;

    @getColumnType({
        name: "THEME",
        mongoType: "string",
        postgresType: "text",
        type: "longtext",
        default: null
    })
    theme!: string;
    @getColumnType({
        name: "USER_ID",
        mongoType: "string",
        postgresType: "text",
        type: "longtext",
        default: null
    })
    userid!: string;
    @getColumnType({
        name: "IS_SYSTEM",
        mongoType: "boolean",
        postgresType: "boolean",
        type: "boolean",
        default: false
    })
    isSystem!: boolean;

    @getColumnType({
        name: "IS_DEFAULT",
        mongoType: "boolean",
        postgresType: "boolean",
        type: "boolean",
        default: false
    })
    isDefault!: boolean;

    @UpdateDateColumn({ name: 'UPDATED_AT', type: 'timestamp' })
    updatedAt!: Date;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;
}
