import {
    CreateDateColumn,
    Entity,
    Index
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';
 
@Entity("dms-folders")
export class DMSFolders  {
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    clientId!: number;

    @getColumnType({ name: 'FOLDER_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    folderName!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    @CreateDateColumn({ name: 'UPDATED_ON', type: 'timestamp' })
    updatedOn!: Date;
}
