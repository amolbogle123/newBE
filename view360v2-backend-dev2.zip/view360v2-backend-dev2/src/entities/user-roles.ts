import { Entity, CreateDateColumn, Index } from "typeorm";
import { getColumnType, getType } from "../services/db.service";

@Entity("user_roles")
export class UserRoles  {
    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id!: string;

    // @Column({ type: 'int', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({
        name: "CLIENT_ID",
        mongoType: "number",
        postgresType: "int",
        type: "int",
    })
    clientId!: number;

    // @Column({ name: 'NAME', type: 'varchar', length: 128, nullable: true })
    @getColumnType({
        name: "NAME",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        length: 128,
        nullable: true,
        isLengthRequired: true,
    })
    name!: string;

    // @Column({ name: 'PERMISSION', type: 'text' })
    @getColumnType({
        name: "PERMISSION",
        mongoType: "string",
        postgresType: "text",
        type: "longtext",
    })
    permission!: string;

    // @Column({ name: 'IS_DEFAULT_ROLE', type: 'smallint' })
    @getColumnType({
        name: "IS_DEFAULT_ROLE",
        mongoType: "number",
        postgresType: "smallint",
        type: "smallint",
    })
    isDefaultRole!: number;

    @getColumnType({ name: 'MFA', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    mfa !: number

    // @Column({ name: 'CREATED_BY', type: 'char', length: 36 })
    @getColumnType({
        name: "CREATED_BY",
        mongoType: "string",
        postgresType: "char",
        type: "char",
        length: 36,
        isLengthRequired: true,
    })
    createdBy!: string;

    @CreateDateColumn({ name: "CREATED_ON", type: "timestamp" })
    createdOn!: Date;

    // @Column({ name: 'APP_ID', type: 'char', length: 36, default: 1 })
    @getColumnType({
        name: "APP_ID",
        mongoType: "string",
        postgresType: "char",
        type: "char",
        length: 36,
        default: 1,
    })
    appId!: string;

    // @Column({ name: 'DESCRIPTION', type: 'varchar', length: 255, nullable: true })
    @getColumnType({
        name: "DESCRIPTION",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        length: 255,
        nullable: true,
        isLengthRequired: true,
    })
    description!: string;
}
