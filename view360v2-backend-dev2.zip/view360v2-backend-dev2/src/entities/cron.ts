import {Entity, CreateDateColumn, ManyToOne, JoinColumn} from 'typeorm'

import { ApiMethod } from '../modules/process-builder/models';
import { BusinessProcessModeling } from './bpmn';
import { getColumnType, getType } from '../services/db.service';

@Entity("cron")
export class Cron  {

    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id!: string;

    // @Column({name: 'TYPE', type: 'varchar', length: 100})
    @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true })
    type!: string;

    // @Column({name: 'CONFIG', type: 'text'})
    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: 'text' })
    config!: string;

    // @Column({name: 'CREATED_BY', type: 'char', length: 36})
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    @ManyToOne(() => BusinessProcessModeling, (bpmn: BusinessProcessModeling) => bpmn.id, {onDelete: 'CASCADE'})
    @JoinColumn({name: 'BPMN_ID'})
    bpmn!: string;

    // @Column({name: 'HIT_API', type: 'text'})
    @getColumnType({ name: 'HIT_API', mongoType: 'string', postgresType: 'text', type: 'text' })
    hitApi!: string;

    // @Column({name: 'HIT_METHOD', type: 'enum', enum: ApiMethod, default: ApiMethod.POST})
    @getColumnType({ name: 'HIT_METHOD', mongoType: 'string', postgresType: 'varchar', type: 'enum', enum: ApiMethod, default: ApiMethod.POST })
    hitMethod!: string;

    // @Column({name: 'REF_ID', type: 'char', length: 36})
    @getColumnType({ name: 'REF_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    refId!: string;

    // @Column({name: 'TIMEZONE', type: 'varchar', length: 100})
    @getColumnType({ name: 'TIMEZONE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true })
    timezone!: string;
}
