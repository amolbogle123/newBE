import {
    Entity,
    CreateDateColumn,
    JoinColumn,
    ManyToOne,
    Index
} from 'typeorm'
import {CustomFormsGroup} from "./custom-forms-group";
import {getColumnType, getType} from "../services/db.service";


@Entity('custom_forms')
export class CustomForms  {

// @PrimaryGeneratedColumn("uuid", { name: "ID"})
    @getType()
    id!: string;

    // @Column({ type: 'number', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId!: number;

    // @Column({ type: 'string', length: 36, name: 'DOC_ID' })
    @getColumnType({ name: 'DOC_ID', mongoType: 'string', postgresType: 'char', type: 'char'})
    docId!: string;

    // @Column({ type: 'string', length: 255, name: 'FORM_NAME' })
    @getColumnType({ name: 'FORM_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true })
    formName!: string;

    // @Column({ type: 'string', length: 255, name: 'FORM_DESCRIPTION' })
    @getColumnType({ name: 'FORM_DESCRIPTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true })
    formDescription!: string;

    // @Column({ type: 'number', name: 'IS_SHOW_DASHBOARD', default: 0 })
    @getColumnType({ name: 'IS_SHOW_DASHBOARD', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isShowDashboard!: number;

    // @Column({ type: 'number', name: 'IS_TIMER_BASED', default: 0 })
    @getColumnType({ name: 'IS_TIMER_BASED', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isTimerBased!: number;

    // @Column({ type: 'number', name: 'IS_VERSION_CONTROL', default: 0 })
    @getColumnType({ name: 'IS_VERSION_CONTROL', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isVersionControl!: number;

    // @Column({ type: 'number', name: 'IS_COMMENABLED', default: 0 })
    @getColumnType({ name: 'IS_COMMENABLED', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isCommanable!: number;

    // @Column({ type: 'number', name: 'IS_ASSIGNMENT', default: 0 })
    @getColumnType({ name: 'IS_ASSIGNMENT', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isAssignment!: number;

    // @Column({ type: 'number', name: 'IS_APPROVAL' })
    @getColumnType({ name: 'IS_APPROVAL', mongoType: 'number', postgresType: 'int', type: 'int', })
    isApproval!: number;

    @getColumnType({ name: 'IS_ENABLE_EXCEL_UPLOAD', mongoType: 'number', postgresType: 'int', type: 'int', default: 0 })
    isEnableExcelUpload!: number;

    // @Column({ type: 'string', name: 'FORM_CONTROLS' })
    @getColumnType({ name: 'FORM_CONTROLS', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    formControls!: string;

    // @Column({ type: 'string', name: 'STATUSBOXES' })
    @getColumnType({ name: 'STATUSBOXES', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    statusBoxes!: string;

    // @Column({ type: 'string', name: 'APPROVAL_DATA' })
    @getColumnType({ name: 'APPROVAL_DATA', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    approvalData!: string;

    // @Column({ type: 'string', name: 'APPROVAL_SETTING' })
    @getColumnType({ name: 'APPROVAL_SETTING', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    approvalSetting!: string;

    // @Column({ type: 'string', length: 255, name: 'ASSIGNED_USER', nullable: true })
    @getColumnType({ name: 'ASSIGNED_USER', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    assignedUser!: string;

    // @Column({ type: 'string', name: 'FORMDATA' })
    @getColumnType({ name: 'FORMDATA', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    formData!: string;

    // @Column({ type: 'string', name: 'FORMDATA_CONFIG' })
    @getColumnType({ name: 'FORMDATA_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    formDataConfig!: string;

    // @Column({ type: 'string', name: 'PERMISSION_CONFIG' })
    @getColumnType({ name: 'PERMISSION_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    permissionConfig!: string;

    // @Column({ type: 'string', length: 36, name: 'CREATED_BY' })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: number

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    // @Column({ type: 'string', name: 'MAPPED_USER' })
    @getColumnType({ name: 'MAPPED_USER', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    mappedUser!: string;

    // @Column({ type: 'string', length: 50, name: 'FORM_TYPE' })
    @getColumnType({ name: 'FORM_TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 50, isLengthRequired: true })
    formType!: string;

    @getColumnType({ name: 'REFERENCE_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    referenceId!: string;

    @ManyToOne(() => CustomFormsGroup, (cfg: CustomFormsGroup) => cfg.id, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'DOC_ID' })
    docGroup!: CustomFormsGroup;

  }
