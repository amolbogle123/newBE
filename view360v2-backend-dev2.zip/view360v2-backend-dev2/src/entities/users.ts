import {
    Entity,
    CreateDateColumn,
    UpdateDateColumn, ManyToOne, JoinColumn, Index
} from 'typeorm'
import { MdbClient } from "./mdb-client";
import { getColumnType, getType } from '../services/db.service';


@Entity('users')
export class Users  {


    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id!: string;

    // @Column({ type: 'int', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId!: number;

    @ManyToOne(() => MdbClient, (mdbClient: MdbClient) => mdbClient.id, { onDelete: 'CASCADE' })
    @JoinColumn({ name: "CLIENT_ID" })
    mdbClient: MdbClient;

    // @Column({ type: 'char', length: 36, name: 'ROLE_ID', nullable: true })
    @getColumnType({ name: 'ROLE_ID', mongoType: 'string', postgresType: 'char', type: 'char', nullable: true, length: 36, isLengthRequired: true })
    roleId!: string;

    // @Column({ name: 'IS_SUPERADMIN', type: 'smallint', default: 0 })
    @getColumnType({ name: 'IS_SUPERADMIN', mongoType: 'number', postgresType: 'smallint', type: 'smallint' })
    isSuperAdmin!: number;

    // @Column({ type: 'smallint', name: 'IS_ADMIN', default: 0 })
    @getColumnType({ name: 'IS_ADMIN', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    isAdmin!: number;

    // @Column({ type: 'int', name: 'TEAM_ID', nullable: true })
    @getColumnType({ name: 'TEAM_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    teamId!: number;

    // @Column({ type: 'char', length: 36, name: 'USER_MANAGER', nullable: true })
    @getColumnType({ name: 'USER_MANAGER', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true, isLengthRequired: true })
    userManager!: string;

    // @Column({ type: 'varchar', length: 255, name: 'FIRST_NAME', nullable: true })
    @getColumnType({ name: 'FIRST_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    firstName!: string;

    // @Column({ type: 'varchar', length: 255, name: 'LAST_NAME', nullable: true })
    @getColumnType({ name: 'LAST_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    lastName!: string;

    // @Column({ type: 'varchar', length: 255, name: 'EMAIL', nullable: true })
    @getColumnType({ name: 'EMAIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    email!: string;

    // @Column({ type: 'varchar', length: 255, name: 'PHONE', nullable: true })
    @getColumnType({ name: 'PHONE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    phone!: string;

    // @Column({ type: 'varchar', length: 255, name: 'USERNAME', nullable: true })
    @getColumnType({ name: 'USERNAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    username!: string;

    // @Column({ type: 'varchar', length: 255, name: 'PASSWORD', nullable: true })
    @getColumnType({ name: 'PASSWORD', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    password!: string;

    // @Column({ type: 'varchar', length: 255, name: 'STATE', nullable: true })
    @getColumnType({ name: 'STATE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    state!: string;

    // @Column({ type: 'varchar', length: 255, name: 'CITY', nullable: true })
    @getColumnType({ name: 'CITY', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    city!: string;

    // @Column({ type: 'varchar', length: 255, name: 'ZIP', nullable: true })
    @getColumnType({ name: 'ZIP', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    zipCode!: string;

    // @Column({ type: 'varchar', length: 255, name: 'HASHCODE', nullable: true })
    @getColumnType({ name: 'HASHCODE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    hashCode!: string;

    @CreateDateColumn({ name: 'PASS_RESET_DATE', nullable: true, type: 'timestamp' })
    passResetDate!: Date;

    // @Column({ type: 'varchar', length: 255, name: 'HIRE_DATE', nullable: true })
    @getColumnType({ name: 'HIRE_DATE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    hireDate!: string;

    // @Column({ type: 'varchar', length: 255, name: 'ADDRESS' })
    @getColumnType({ name: 'ADDRESS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, })
    address!: string;

    // @Column({ type: 'varchar', length: 255, name: 'COUNTRY' })
    @getColumnType({ name: 'COUNTRY', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, })
    country!: string;

    // @Column({ type: 'varchar', length: 255, name: 'DEPARTMENT' })
    @getColumnType({ name: 'DEPARTMENT', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, })
    department!: string;

    
    // @Column({ type: 'varchar', length: 255, name: 'JOB_TITLE', nullable: true })
    @getColumnType({ name: 'JOB_TITLE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    jobTitle!: string;

    // @Column({ type: 'varchar', length: 255, name: 'MOBILE' })
    @getColumnType({ name: 'MOBILE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, })
    mobile!: string;


    // @Column({ type: 'varchar', length: 255, name: 'TAG', nullable: true })
    @getColumnType({ name: 'TAG', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    tag!: string;


    // @Column({ type: 'varchar', length: 255, name: 'CHILD_COMPANY', nullable: true })
    @getColumnType({ name: 'CHILD_COMPANY', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    childCompany!: string;

    // @Column({ type: 'varchar', length: 255, name: 'LOCATION', nullable: true })
    @getColumnType({ name: 'LOCATION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, nullable: true })
    location!: string;

    // @Column({ type: 'integer', name: 'WORKING_YEAR', default: () => new Date().getFullYear().toString() })
    @getColumnType({ name: 'WORKING_YEAR', mongoType: 'number', postgresType: 'int', type: 'integer', default: () => new Date().getFullYear().toString() })
    workingYear!: number;

    // @Column({ type: 'smallint', name: 'IS_ACTIVE', default: 1 })
    @getColumnType({ name: 'IS_ACTIVE', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    isActive!: number;

    // @Column({ type: 'varchar', length: 50, name: 'APPLY_THEMES', default: 'default' })
    @getColumnType({ name: 'APPLY_THEMES', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 50, isLengthRequired: true, default: 'default' })
    applyTheme!: string;

    // @Column({ type: 'smallint', name: 'DISABLED_STATUS', default: 1 })
    @getColumnType({ name: 'DISABLED_STATUS', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    disabledState!: number;

    // @Column({ type: 'smallint', name: 'PROFILE_IMAGE', default: 1 })
    @getColumnType({ name: 'PROFILE_IMAGE', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    profileImage!: number;

    // @Column({ type: 'varchar', name: 'PROFILE_URL', nullable: true })
    @getColumnType({ name: 'PROFILE_URL', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    profileUrl!: string;

    // @Column({ type: 'varchar', name: 'LAN_ID', nullable: true })
    @getColumnType({ name: 'LAN_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    lanId!: string;

    // @Column({ type: 'text', name: 'MENU_LIST', nullable: true })
    @getColumnType({ name: 'MENU_LIST', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    menuList!: string;

    // @Column({ type: 'smallint', name: 'EMAIL_VERIFIED', default: 0 })
    @getColumnType({ name: 'EMAIL_VERIFIED', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    emailVerified!: string;

    // @Column({ type: 'text', name: 'CHANGE_PASSWORD_TOKEN', nullable: true })
    @getColumnType({ name: 'CHANGE_PASSWORD_TOKEN', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    changePasswordToken!: string;

    // @Column({ type: 'timestamp', name: 'LAST_LOGIN_DATE', default: () => 'CURRENT_TIMESTAMP' })
    @getColumnType({ name: 'LAST_LOGIN_DATE', mongoType: 'date', postgresType: 'timestamp', type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    lastLoginDate!: Date;

    // @Column({ type: 'timestamp', name: 'CURRENT_LOGIN_DATE', default: () => 'CURRENT_TIMESTAMP' })
    @getColumnType({ name: 'CURRENT_LOGIN_DATE', mongoType: 'date', postgresType: 'timestamp', type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    currentLoginDate!: Date;

    // @Column({ type: 'timestamp', name: 'UPDATED_DATE', default: () => 'CURRENT_TIMESTAMP' })
    @getColumnType({ name: 'UPDATED_DATE', mongoType: 'date', postgresType: 'timestamp', type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    updatedDate!: Date;

    @UpdateDateColumn({ name: 'UPDATED_AT', type: 'timestamp', })
    updatedAt!: Date;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;

    // @Column({ name: 'CHANGE_PASSWORD_TOKENS', type: 'text', nullable: true })
    @getColumnType({ name: 'CHANGE_PASSWORD_TOKENS', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    changePasswordTokens!: string;

    // @Column({ name: 'AI_APP', type: 'text', nullable: true })
    @getColumnType({ name: 'SELECTED_THEME_ID', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    selectedThemeId!: string;

    @getColumnType({ name: 'SELECTED_COLOR_THEME', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    selectedColorTheme!: string;

    
    // @Column({ name: 'IS_DELETED', type: 'smallint', default: 0 })
    @getColumnType({ name: 'IS_DELETED', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    isDeleted!: number;

    // @Column({ name: 'ESCALATION_CONTACT1', type: 'smallint', default: 0 })
    @getColumnType({ name: 'ESCALATION_CONTACT1', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    escalationContact1!: number;

    // @Column({ name: 'ESCALATION_CONTACT2', type: 'smallint', default: 0 })
    @getColumnType({ name: 'ESCALATION_CONTACT2', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    escalationContact2!: number;

    // @Column({ name: 'IS_VIEW360_LOGIN', type: 'smallint',mongoType: 'number', default: 1 })
    @getColumnType({ name: 'IS_VIEW360_LOGIN', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    isView360Login!: number;

    // @Column({ name: 'COUNTRY_CODE', type: 'varchar', default: '+1' })
    @getColumnType({ name: 'COUNTRY_CODE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', default: '+1' })
    countryCode!: string;

    // @Column({ name: 'LOGO_URL', type: 'text', nullable: true })
    @getColumnType({ name: 'LOGO_URL', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    logoUrl!: string;

    @getColumnType({ name: 'SECRET_KEY', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    secretKey!: string;

    @getColumnType({ name: 'FAIL_PWD_ATTEMPT', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    failpwdAttempt!: number;

}
