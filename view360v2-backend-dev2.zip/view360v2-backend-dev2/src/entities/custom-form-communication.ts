import { Entity, CreateDateColumn, Index } from 'typeorm'

import { getColumnType, getType } from '../services/db.service';

@Entity("custom_form_communication")
export class CustomFormCommunication  {

    // @PrimaryGeneratedColumn("uuid", { name: "ID"})
    @getType()
    id!: string;

    // @Column({ type: 'string', length: 36, name: 'FORM_ID' })
    @getColumnType({ name: 'FORM_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    formId !: number;

    // @Column({ type: 'string', length: 36, name: 'ENTRY_ID' })
    @getColumnType({ name: 'ENTRY_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    entryId !: number;

    // @Column({ type: 'number', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId !: number;

    // @Column({ type: 'string', name: 'COMMENTS' })
    @getColumnType({ name: 'COMMENTS', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    comments !: string

    // @Column({ type: 'string', length: 36, name: 'CREATED_BY' })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    createdBy !: string

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    @getColumnType({ name: 'FIRST_NAME', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    firstName !: string

    @getColumnType({ name: 'LAST_NAME', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    lastName !: string
}
