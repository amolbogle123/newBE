import {Entity, CreateDateColumn, Index} from 'typeorm'

import { getType, getColumnType } from '../services/db.service';

@Entity('campaign')
export class Campaign  {

    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    // @Column({ type: 'int', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    // @Column({ type: 'varchar', length: 100, name: 'NAME' })
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true })
    name!: string;

    // @Column({ name: 'EMAIL_CONFIG', type: 'text' })
    @getColumnType({ name: 'EMAIL_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext' })
    emailConfig!: string;

    // @Column({ name: 'TOTAL_EMAIL', type: 'int', default: 0 })
    @getColumnType({ name: 'TOTAL_EMAIL', mongoType: 'number', postgresType: 'int', type: 'int', default: 0 })
    totalEmail!: any;

    // @Column({ name: 'STATUS', type: 'int', default: 0 })
    @getColumnType({ name: 'STATUS', mongoType: 'number', postgresType: 'int', type: 'int', default: 0 })
    status!: any;

    // @Column({ name: 'FOLLOW_AFTER', type: 'char', length: 36 })
    @getColumnType({ name: 'FOLLOW_AFTER', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    followAlter!: string;

    // @Column({ name: 'CREATED_BY', type: 'char', length: 36 })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
