import { getColumnType, getType } from "../services/db.service";
import { CreateDateColumn, Entity, Index } from "typeorm";

@Entity("share_dashboard")
export class ShareDashboard {
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    @getColumnType({ name: 'DASHBOARD_ID', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    dashboardId!: string;

    @getColumnType({ name: 'TITLE', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    title!: string;

    @getColumnType({ name: 'UUID', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    uuid!: string;
    
    @getColumnType({ name: 'URL', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    url!: string;
    
    @getColumnType({ name: 'URL_VIEW_ONCE', mongoType: 'boolean', postgresType: 'boolean', type: 'boolean', default: false })
    urlViewOnce!: string;
    
    @getColumnType({ name: 'URL_EXPIRY', type: 'timestamp', nullable: true })
    urlExpiry!: Date;
    
    @getColumnType({ name: 'URL_ACCESSED', mongoType: 'boolean', postgresType: 'boolean', type: 'boolean', default: false })
    urlAccessed!: string;
    
    @getColumnType({ name: 'SESSION_UID', mongoType: 'string', postgresType: 'char', type: 'longtext', nullable: true })
    sessionUid!: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}