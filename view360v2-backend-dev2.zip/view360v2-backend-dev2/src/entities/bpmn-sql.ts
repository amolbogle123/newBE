import {Entity, PrimaryGeneratedColumn, CreateDateColumn, ManyToOne, JoinColumn} from 'typeorm'
import {BusinessProcessModeling} from "./bpmn";
import {getColumnType} from "../services/db.service";

@Entity("bpmn_sql")
export class BusinessProcessModelingSql {

    @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    id!: string;

    @ManyToOne(() => BusinessProcessModeling, (bpmn: BusinessProcessModeling) => bpmn.id, {onDelete: 'CASCADE'})
    @JoinColumn({name: 'BPMN_ID'})
    bpmn!: string;

    // @Column({name: 'EXECUTED_DATA', type: 'text'})
    @getColumnType({ name: 'EXECUTED_DATA', mongoType: 'string', postgresType: 'text', type: 'text' })
    executeData!: string;

    @CreateDateColumn({name: 'CREATED_ON', type: "timestamp"})
    createdOn!: Date;
}
