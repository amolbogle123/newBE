import { Entity, Index} from 'typeorm';

import { getColumnType, getType } from '../services/db.service';

@Entity("client_general")
export class ClientGeneral {
    // @PrimaryGeneratedColumn('increment', { name: '_id' })
    @getType()
    id!: string;

    // @Column({ name:'CLIENT_ID', type:'number'})
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    client_id!: number;

    // @Column({ name:'COMPANY_NAME', type:'string'})
    @getColumnType({ name: 'COMPANY_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    company_name!: string;

    // @Column({ name:'LEGAL_NAME', type:'string'})
    @getColumnType({ name: 'LEGAL_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    legal_name!: string;

    // @Column({ name:'CONTACT_PERSON', type:'string'})
    @getColumnType({ name: 'CONTACT_PERSON', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    contact_person!: string;

    // @Column({ length: 500, name:'COMP_ADDRESS', type:'string'})
    @getColumnType({ name: 'COMP_ADDRESS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 500, isLengthRequired: true })
    comp_address!: string;

    // @Column({ name:'ZIP', type:'string'})
    @getColumnType({ name: 'ZIP', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    zip!: string;

    // @Column({ name:'CITY', type:'string'})
    @getColumnType({ name: 'CITY', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    city!: string;

    // @Column({ name:'STATE', type:'string'})
    @getColumnType({ name: 'STATE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    state!: string;

    // @Column({ name:'COUNTRY', type:'string'})
    @getColumnType({ name: 'COUNTRY', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    country!: string;

    // @Column({ name:'COMP_PHONE', type:'string'})
    @getColumnType({ name: 'COMP_PHONE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    comp_phone!: string;

    // @Column({ name:'COMP_PHONE2', type:'string'})
    @getColumnType({ name: 'COMP_PHONE2', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    comp_phone2!: string;

    // @Column({ name:'COMPANY_EMAIL', type:'string'})
    @getColumnType({ name: 'COMPANY_EMAIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    company_email!: string;

    // @Column({ name:'MOBILE', type:'string'})
    @getColumnType({ name: 'MOBILE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    mobile!: string;

    // @Column({ name:'FAX', type:'string'})
    @getColumnType({ name: 'FAX', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    fax!: string;

    // @Column({ name:'WEBSITE', type:'string'})
    @getColumnType({ name: 'WEBSITE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    website!: string;

    // @Column({ name:'COMP_REGISTRATION', type:'string'})
    @getColumnType({ name: 'COMP_REGISTRATION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    comp_registration!: string;

    // @Column({ name:'TAX_NO', type:'string'})
    @getColumnType({ name: 'TAX_NO', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    tax_no!: string;
}
