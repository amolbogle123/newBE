import { CreateDateColumn, Entity } from "typeorm";

import { getColumnType, getType } from "../services/db.service";

@Entity("module_subscription")
export class ModuleSubscription  {
    @getType()
    id!: string;

    @getColumnType({ mongoType: "number", type: "int", name: "CLIENT_ID" })
    clientId !: number;
    
    @getColumnType({ mongoType: "string", type: "varchar", name: "MODULE_ID" })
    moduleId!: string;
    
    @getColumnType({ mongoType: "string", type: "varchar", name: "ACCESS_KEY" })
    accessKey!: string;

    @getColumnType({ mongoType: "number", type: "int", name: "IS_ACTIVE" })
    isActive!: number;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    @CreateDateColumn({ name: 'UPDATED_ON', type: 'timestamp' })
    updatedOn!: Date;
}
