import { Entity, CreateDateColumn, Index } from 'typeorm';

import { getColumnType, getType } from '../services/db.service';

@Entity("company_department")
export class CompanyDepartment  {

    // @PrimaryGeneratedColumn('increment', { name:'ID' })
    @getType()
    id!: string;

    // @Column({ name: 'CLIENT_ID', type: 'number', nullable: true })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    client_id!: number;

    // @Column({ name: 'NAME', type: 'string', nullable: true })
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    name!: string;

    // @Column({ name: 'CHILD_COMPANIES', type: 'string', nullable: true })
    @getColumnType({ name: 'CHILD_COMPANIES', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    childCompanies!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
