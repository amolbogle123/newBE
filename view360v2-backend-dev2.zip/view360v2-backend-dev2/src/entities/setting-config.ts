import { Entity, CreateDateColumn, Index } from 'typeorm'

import { getColumnType, getType } from '../services/db.service';

@Entity('setting_config')
export class SettingConfig  {

    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id!: string;

    // @Column({ name: 'CLIENT_ID', type: 'number', nullable: true })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    clientId!: number;

    // @Column({ name: 'TYPE', type: 'string', length: 255 })
    @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true })
    type!: string;

    // @Column({ name: 'CONFIG', type: 'string', nullable: true })
    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true })
    config!: string;

    // @Column({ name: 'CREATED_BY', type: 'string', length: 36 })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
