import { Entity, Index } from 'typeorm';

import { getColumnType, getType } from '../services/db.service';

@Entity("client_theme")
export class ClientTheme  {

    // @PrimaryGeneratedColumn('increment', { name:'ID'})
    @getType()
    id!: string;

    // @Column({ name: 'CLIENT_ID', type: 'number' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    client_id!: number;

    // @Column({ name: 'SITENAME', type: 'string', nullable: true })
    @getColumnType({ name: 'SITENAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    sitename!: string;

    // @Column({ name: 'SITENAME_COLOR', type: 'string', nullable: true })
    @getColumnType({ name: 'SITENAME_COLOR', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    sitename_color!: string;

    // @Column({ name: 'LOGO_OR_ICON', type: 'string', nullable: true })
    @getColumnType({ name: 'LOGO_OR_ICON', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    logo_or_icon!: string;

    // @Column({ name: 'COMPANY_LOGO', type: 'string', nullable: true })
    @getColumnType({ name: 'COMPANY_LOGO', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    company_logo!: string;

    // @Column({ name: 'FAVICON', type: 'string', nullable: true })
    @getColumnType({ name: 'FAVICON', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    favicon!: string;

    // @Column({ name: 'FONTSIZE', type: 'string', nullable: true })
    @getColumnType({ name: 'FONTSIZE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    fontsize!: string;

    // @Column({ name: 'TYPOGRAPHY', type: 'string', nullable: true })
    @getColumnType({ name: 'TYPOGRAPHY', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    typography!: string;
}
