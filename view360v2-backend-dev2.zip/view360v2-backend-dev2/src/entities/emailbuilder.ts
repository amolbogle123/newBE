import { CreateDateColumn, Entity, Index } from 'typeorm';

import { getColumnType, getType } from '../services/db.service';

@Entity('email_builder_page')
export class EmailBuilderPage {

    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    // @Column({ name: 'CLIENT_ID', type: 'int' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number; 

    // @Column({ name: 'MESSAGE', type: "text" })
    @getColumnType({ name: 'TITLE', mongoType: 'string', postgresType: 'text', type: "text" })
    title!: string;

    // @Column({ name: 'MESSAGE', type: "text" })
    @getColumnType({ name: 'MESSAGE', mongoType: 'string', postgresType: 'text', type: "text" })
    message!: string;

    // @Column({ name: 'MESSAGE', type: "text" })
    @getColumnType({ name: 'BODY_STYLE', mongoType: 'string', postgresType: 'text', type: "text" })
    bodyStyle!: string;

    @getColumnType({ name: 'IS_PUBLISH', mongoType: 'number', postgresType: 'int', type: "int", default: 1 })
    isPublish!: string;

    @getColumnType({ name: 'LAYOUT', mongoType: 'string', postgresType: 'text', type: "text" })
    layout!: string;

    // @Column({ name: 'MESSAGE', type: "text" })
    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: "text" })
    config!: string;

    @getColumnType({ name: 'HTML_CONTEXT', mongoType: 'string', postgresType: 'text', type: "text" })
    htmlContext!: string;
 
    // @Column({ name: 'CREATED_BY', type: "char", length: 36 })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: "char", length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: "timestamp" })
    createdOn!: Date;
}
