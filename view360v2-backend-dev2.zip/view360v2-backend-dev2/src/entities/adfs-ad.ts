import {Entity, CreateDateColumn, Index} from 'typeorm';
import {getColumnType, getType} from "../services/db.service";

@Entity("adfs_ad")
export class AdfsAd  {

    //@PrimaryGeneratedColumn('increment', { name:'ID'})
    @getType('increment')
    id!: string;

    @getColumnType({ name: 'MICROSOFT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    microsoftId: number;

    @getColumnType({ name: 'CERT', mongoType: 'string', postgresType: 'text', type: 'text' })
    cert: string;

    // @Column({ name: 'CLIENT_ID', type: 'int' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId: number;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn: Date;

    // @Column({ name: 'UPDATED_AT', type: 'timestamp', nullable: true })
    @getColumnType({ name: 'UPDATED_AT', mongoType: 'string', postgresType: 'timestamp', type: 'timestamp', nullable: true })
    updatedAt: string;

    // @Column({ name: 'DELETED_AT', type: 'timestamp', nullable: true })
    @getColumnType({ name: 'DELETED_AT', mongoType: 'string', postgresType: 'timestamp', type: 'timestamp', nullable: true })
    deletedAt: string;
}
