import { Entity, Index } from 'typeorm';
import { getColumnType, getType } from '../services/db.service';

@Entity('form_builder_time_log')
export class FormBuilderTimeLog {
  //   @PrimaryGeneratedColumn('uuid', { name: 'ID'} )
  @getType()
  id!: number;

  //   @Column({type: 'varchar', name: 'FORM_ID'})
  @getColumnType({ name: 'FORM_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
  formId!: string;

  //   @Column({type: 'varchar', name: 'CLIENT_ID'})
  @Index()
  @getColumnType({ name: 'CLIENT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
  clientId!: string;

  //   @Column({type: 'varchar', name: 'ENTRY_ID'})
  @getColumnType({ name: 'ENTRY_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
  entryId !: string;

  //   @Column({type: 'varchar', name: 'USERNAME'})
  @getColumnType({ name: 'USERNAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
  userName!: string;

  //   @Column({type: 'varchar', name: 'CREATED_BY'})
  @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
  createdBy !: string;

  //   @Column({type: 'int', name: 'BEING_FILLED_BY'})
  @getColumnType({ name: 'BEING_FILLED_BY', mongoType: 'number', postgresType: 'int', type: 'int', })
  beingFilledBy!: number;

  //   @Column({type: 'int', name: 'CREATEDON'})
  @getColumnType({ name: 'CREATEDON', mongoType: 'number', postgresType: 'int', type: 'int', })
  createdOn !: number;

  //   @Column({type: 'varchar', name: 'DESSC'})
  @getColumnType({ name: 'DESSC', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
  description !: string;

}
