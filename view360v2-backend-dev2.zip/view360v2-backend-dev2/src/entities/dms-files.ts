import {
    CreateDateColumn,
    Entity,
    Index
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';
 
@Entity("dms-files")
@Index(['fileName', 'filePath'], { fulltext: true })
export class DMSFiles  {
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    clientId!: number;

    @Index({ fulltext: true })
    @getColumnType({ name: 'FILE_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    fileName!: string;

    @Index({ fulltext: true })
    @getColumnType({ name: 'FILE_PATH', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    filePath!: string;

    @getColumnType({ name: 'FILE_SIZE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    fileSize!: string;

    @getColumnType({ name: 'IS_INDEXED', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isIndexed!: number;

    @getColumnType({ name: 'ACTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    action!: string;

    @CreateDateColumn({ name: 'ACTION_DATE', type: 'timestamp' })
    actionDate!: Date;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    @CreateDateColumn({ name: 'UPDATED_ON', type: 'timestamp' })
    updatedOn!: Date;
}
