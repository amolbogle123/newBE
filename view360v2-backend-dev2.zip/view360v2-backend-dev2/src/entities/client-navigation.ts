import { Entity, CreateDateColumn, Index } from 'typeorm'
import { getColumnType, getType } from '../services/db.service';


@Entity("client_navigation")
export class ClientNavigation  {

    // @PrimaryGeneratedColumn("uuid", { name: "ID"})
    @getType()
    id!: string;

    // @Column({ type: 'string', name: 'MENU' })
    @getColumnType({ name: 'MENU', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    menu !: string

    // @Column({ type: "number", name: "CLIENT_ID" })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId !: number;

    // @Column({ type: "number", name: "ACTIVE" })
    @Index()
    @getColumnType({ name: 'ACTIVE', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', })  
    active !: number

    // @Column({type: "char", length: 36, name: "UPDATED_BY"})
    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    updatedBy !: string

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
    loginRedirectUrl: string;
}
