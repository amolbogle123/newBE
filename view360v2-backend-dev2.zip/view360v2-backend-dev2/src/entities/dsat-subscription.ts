import {Entity, CreateDateColumn, ManyToOne, JoinColumn} from "typeorm"
import {MdbClient} from "./mdb-client";
import {getColumnType, getType} from "../services/db.service";


@Entity("dsat_subscription")
export class DsatSubscription  {
    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id: string;

    @ManyToOne(() => MdbClient, (mdbClient: MdbClient) => mdbClient.id, { onDelete: 'CASCADE' })
    @JoinColumn({ name: "CLIENT_ID" })
    mdbClient: MdbClient;

    // @Column({ name: 'VALID_UNTIL', type: 'timestamp' })
    @getColumnType({ name: 'VALID_UNTIL', mongoType: 'number', postgresType: 'int', type: 'timestamp' })
    validUntil: number;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn: Date;

    // @Column({ name: 'NAME', type: 'varchar' })
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    name: string;

    // @Column({ name: 'DESCRIPTION', type: 'varchar', length: 255 })
    @getColumnType({ name: 'DESCRIPTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true })
    description: string;

    // @Column({ name: 'CONFIG', type: 'varchar', length: 255 })
    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, })
    config: string;

    // @Column({ name: 'TYPE', type: 'varchar', length: 255 })
    @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, })
    type: string;

    // @Column({ name: 'SUBSCRIPTION_DATE', type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    @getColumnType({ name: 'SUBSCRIPTION_DATE', mongoType: 'number', postgresType: 'timestamp', type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    subscriptionDate: number;

    // @Column({ name: 'IS_LAUNCH', type: 'smallint', default: 0 })
    @getColumnType({ name: 'IS_LAUNCH', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isLaunch: number;

    // @Column({ name: 'PACKAGE_CONFIG', type: 'text', nullable: true })
    @getColumnType({ name: 'PACKAGE_CONFIG', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    packageConfig: string;

    // @Column({ name: 'MAP_CONFIG', type: 'text', nullable: true })
    @getColumnType({ name: 'MAP_CONFIG', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    mapConfig: string;

}
