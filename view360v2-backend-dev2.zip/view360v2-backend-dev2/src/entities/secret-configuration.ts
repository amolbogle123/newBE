import { CreateDateColumn, Entity, Index } from 'typeorm';
import { getColumnType, getType } from '../services/db.service';

@Entity('secret_configuration')
export class SecretConfiguration {
    @getType()
    id!: string;

    @getColumnType({ name: 'VAULT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    vaultId!: string;

    @getColumnType({ name: 'CONFIG_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    configurationName!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    clientId!: number;

    @getColumnType({ name: 'SECRET_PATH', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    secretPath !: string;

    @getColumnType({ name: 'POLICY_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    policyName!: string;

    @getColumnType({ name: 'ROLE_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    roleName!: string;

    @getColumnType({ name: 'CAPABILITIES', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    capabilities!: string;

    @getColumnType({ name: 'ROLE_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    roleId!: string;

    @getColumnType({ name: 'SECRET_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    secretId!: string;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn: Date;
}