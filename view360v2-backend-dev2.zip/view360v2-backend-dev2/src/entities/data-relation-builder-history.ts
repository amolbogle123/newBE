import {
    CreateDateColumn,
    Entity,
    Index
} from "typeorm";
import { getColumnType, getType } from '../services/db.service';

@Entity("data_relation_builder_history")
export class DataRelationBuilderHistory  {
    
    @getType()
    id!: string;
    
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    @getColumnType({ name: 'RELATION_ID', mongoType: 'string', postgresType: 'char', type: 'char', nullable: true, length: 36, isLengthRequired: true })
    relationId!: string;

    @getColumnType({ name: 'EXECUTION_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true })
    executionConfig!: string;

    // completedProcess, failedProcess
    @getColumnType({ name: 'STATUS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255 })
    status!: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'varchar', type: 'char', length: 36, nullable: true })
    createdBy: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
