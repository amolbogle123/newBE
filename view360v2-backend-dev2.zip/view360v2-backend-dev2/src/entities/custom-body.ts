import {
    Entity,
    CreateDateColumn,
    Index
} from 'typeorm';
import { getColumnType, getType } from '../services/db.service';

@Entity("custom_body")
export class CustomBody {
    // @PrimaryGeneratedColumn("uuid", {name: 'ID'})
    @getType()
    id: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'string', postgresType: 'int', type: 'int', })
    clientId: number;

    // @Column({ type: 'varchar', length: 255, name: 'NAME', nullable: true })
    @getColumnType({ name: 'DATA', mongoType: 'text', postgresType: 'text', type: 'longtext', nullable: true })
    data!: string;

    // @Column({ type: 'char', length: 36, name: 'CREATEDBY' })
    @getColumnType({ name: 'CREATEDBY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    createdBy: string;

     // @Column({ type: 'varchar', length: 255, name: 'NAME', nullable: true })
     @getColumnType({ name: 'THEME_SETTING', mongoType: 'text', postgresType: 'text', type: 'longtext', nullable: true })
     themeSetting!: string;
 

     // @Column({ type: "number", name: "ACTIVE" })
     @getColumnType({ name: 'ACTIVE', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', })
     active !: number

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;

}
