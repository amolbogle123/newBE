import {
    Entity,
    CreateDateColumn,
    Index
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';

@Entity("data_relation_builder")
export class DataRelationBuilder  {
    
    @getType()
    id!: string;
    
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true })
    name!: string;

    @getColumnType({ name: 'CONNECTOR_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true })
    connectorId: string;

    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    config!: string;

    @getColumnType({ name: 'EXTRA_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    extraConfig!: string;

    @getColumnType({ name: 'IS_SYNC_DATA', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 1, comment: '0 = Not Sync, 1 = Sync done', })
    isSyncData!: number;

    @getColumnType({ name: 'SYNC_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', default: null })
    syncConfig!: string;

    @getColumnType({ name: 'SYNC_META_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', default: null })
    syncMetaConfig!: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'varchar', type: 'char', length: 36, nullable: true })
    createdBy: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
