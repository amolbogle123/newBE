import { Entity, Index } from 'typeorm';

import { getColumnType, getType } from '../services/db.service';

@Entity("client_system")
export class ClientSystem  {

    // @PrimaryGeneratedColumn('increment', { name:'ID'})
    @getType()
    id!: string;

    // @Column({ name: 'CLIENT_ID', type: 'number' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    client_id!: number;

    // @Column({ name: 'DEFAULT_LANGUAGE', type: 'string' })
    @getColumnType({ name: 'DEFAULT_LANGUAGE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    default_language!: string;

    // @Column({ name: 'LOCALE', type: 'number' })
    @getColumnType({ name: 'LOCALE', mongoType: 'number', postgresType: 'int', type: 'int', })
    locale!: number;

    // @Column({ name: 'time_zone', type: 'number' })
    @getColumnType({ name: 'time_zone', mongoType: 'number', postgresType: 'int', type: 'int', })
    time_zone!: number;

    // @Column({ name: 'default_currency', type: 'number' })
    @getColumnType({ name: 'default_currency', mongoType: 'number', postgresType: 'int', type: 'int', })
    default_currency!: number;

    // @Column({ name: 'currency_symbol', type: 'number' })
    @getColumnType({ name: 'currency_symbol', mongoType: 'number', postgresType: 'int', type: 'int', })
    currency_symbol!: number;

    // @Column({ name: 'thousand_seperator', type: 'string' })
    @getColumnType({ name: 'thousand_seperator', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    thousand_seperator!: string;

    // @Column({ name: 'decimal_seperator', type: 'string' })
    @getColumnType({ name: 'decimal_seperator', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    decimal_seperator!: string;

    // @Column({ name: 'default_calendar', type: 'string' })
    @getColumnType({ name: 'default_calendar', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    default_calendar!: string;

    // @Column({ name: 'tax1', type: 'string' })
    @getColumnType({ name: 'tax1', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    tax1!: string;

    // @Column({ name: 'default_subscription', type: 'string' })
    @getColumnType({ name: 'default_subscription', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    default_subscription!: string;

    // @Column({ name: 'tax1_label', type: 'string' })
    @getColumnType({ name: 'tax1_label', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    tax1_label!: string;

    // @Column({ name: 'tax2', type: 'string' })
    @getColumnType({ name: 'tax2', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    tax2!: string;

    // @Column({ name: 'tax2_label', type: 'string' })
    @getColumnType({ name: 'tax2_label', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    tax2_label!: string;

    // @Column({ name: 'tax_decimals', type: 'string' })
    @getColumnType({ name: 'tax_decimals', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    tax_decimals!: string;

    // @Column({ name: 'quantity_decimals', type: 'string' })
    @getColumnType({ name: 'quantity_decimals', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    quantity_decimals!: string;

    // @Column({ name: 'date_format', type: 'string' })
    @getColumnType({ name: 'date_format', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    date_format!: string;

    // @Column({ name: 'datepicker_format', type: 'string' })
    @getColumnType({ name: 'datepicker_format', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    datepicker_format!: string;

    // @Column({ name: 'file_max_size', type: 'string' })
    @getColumnType({ name: 'file_max_size', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    file_max_size!: string;

    // @Column({ name: 'allowed_files', type: 'string' })
    @getColumnType({ name: 'allowed_files', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    allowed_files!: string;

    // @Column({ name: 'privacy_policy_url', type: 'string' })
    @getColumnType({ name: 'privacy_policy_url', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    privacy_policy_url!: string;

    // @Column({ name: 'slac_webhook_url', type: 'string' })
    @getColumnType({ name: 'slac_webhook_url', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    slac_webhook_url!: string;

    // @Column({ name: 'wablas_token', type: 'string' })
    @getColumnType({ name: 'wablas_token', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    wablas_token!: string;

    // @Column({ name: 'whatsapp_number', type: 'string' })
    @getColumnType({ name: 'whatsapp_number', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    whatsapp_number!: string;

    // @Column({ name: 'whatsapp_subscribe_text', type: 'string' })
    @getColumnType({ name: 'whatsapp_subscribe_text', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    whatsapp_subscribe_text!: string;

    // @Column({ name: 'sms_driver', type: 'string' })
    @getColumnType({ name: 'sms_driver', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    sms_driver!: string;

    // @Column({ name: 'open_exchange_api', type: 'string' })
    @getColumnType({ name: 'open_exchange_api', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    open_exchange_api!: string;

    // @Column({ name: 'google_calendar_api_key', type: 'string' })
    @getColumnType({ name: 'google_calendar_api_key', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    google_calendar_api_key!: string;

    // @Column({ name: 'google_calendar_id', type: 'string' })
    @getColumnType({ name: 'google_calendar_id', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    google_calendar_id!: string;

    // @Column({ name: 'default_role', type: 'string' })
    @getColumnType({ name: 'default_role', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    default_role!: string;

    // @Column({ name: 'pdf_engine', type: 'string' })
    @getColumnType({ name: 'pdf_engine', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    pdf_engine!: string;
}
