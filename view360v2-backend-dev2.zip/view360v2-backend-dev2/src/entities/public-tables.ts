import { Entity, Index, UpdateDateColumn, CreateDateColumn } from "typeorm";

import { getColumnType, getType } from "../services/db.service";

@Entity("public_tables")
export class PublicTables  {
    @getType()
    id!: string;

    @Index()
    @getColumnType({
        name: "CLIENT_ID",
        mongoType: "number",
        postgresType: "int",
        type: "int",
    })
    client_id!: number;

    @getColumnType({
        name: "NAME",
        mongoType: "string",
        postgresType: "text",
        type: "longtext",
        default: null
    })
    name!: string;
    @getColumnType({
        name: "TYPE",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        default: "migrationTable"
    })
    type!: string;
    @getColumnType({
        name: "MIGRATION_ID",
        mongoType: "string",
        postgresType: "text",
        type: "longtext",
        default: null
    })
    migration_id!: string;
    @getColumnType({
        name: "DESCRIPTION",
        mongoType: "string",
        postgresType: "json",
        type: "json",
        default: null
    })
    description!: JSON;
    @getColumnType({
        name: "CONFIG",
        mongoType: "string",
        postgresType: "text",
        type: "longtext",
        default: null
    })
    config!: string;
    @getColumnType({
        name: "IS_DELETED",
        mongoType: "number",
        postgresType: "smallint",
        type: "tinyint",
        default: 0
    })
    is_deleted!: number;
    @getColumnType({
        name: "IS_CLIENT_CHECK",
        mongoType: "number",
        postgresType: "smallint",
        type: "tinyint",
        default: 0
    })
    isClientCheck!: number;
    @getColumnType({
        name: "CREATED_BY",
        mongoType: "string",
        postgresType: "char",
        type: "char",
        length: 36,
        default: null
    })
    created_by!: string;
    @CreateDateColumn({ name: "CREATED_ON", type: "timestamp" })
    created_on!: Date;
    @getColumnType({
        name: "UPDATED_BY",
        mongoType: "string",
        postgresType: "char",
        type: "char",
        length: 36,
        default: null
    })
    @UpdateDateColumn({ name: "UPDATED_ON", type: "timestamp" })
    updated_on!: Date;
}

