import { getColumnType, getType } from "../services/db.service";
import { CreateDateColumn, Entity } from "typeorm";

@Entity("global_filter")
export class GlobalFilter  {
    @getType()
    id!: string;

    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    @getColumnType({ name: 'DASHBOARD_ID', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    dashboardId!: string;
    
    @getColumnType({ name: 'FILTER_NAME', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    filterName!: string;
    
    @getColumnType({ name: 'FILTER_TYPE', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    filterType!: string;
    
    @getColumnType({ name: 'FILTER', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    filter!: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'longtext' })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}