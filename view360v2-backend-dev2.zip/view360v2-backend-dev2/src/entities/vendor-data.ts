import {Entity, CreateDateColumn, Index} from 'typeorm'
import {getColumnType, getType} from "../services/db.service";

@Entity('vendor_data')
export class VendorData  {

    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId!: number;

    @getColumnType({ name: 'FILE_INDEX', mongoType: 'number', postgresType: 'int', type: 'int' })
    fileIndex!: number;

    @getColumnType({ name: 'FILE_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    fileId!: string;

    @getColumnType({ name: 'DOC_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255})
    docName!: string;

    @getColumnType({ name: 'DOC_INDEX_COLUMN', mongoType: 'string', postgresType: 'char', type: 'char', length: 255 })
    docIndexColumn!: string;
    
    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    config!: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;
}
