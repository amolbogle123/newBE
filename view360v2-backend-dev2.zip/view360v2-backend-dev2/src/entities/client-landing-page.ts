import { Entity, CreateDateColumn, Index } from 'typeorm'
import { getColumnType, getType } from '../services/db.service';


@Entity("client_landing_page")
export class ClientLandingPage {

    // @PrimaryGeneratedColumn("uuid", { name: "ID"})
    @getType()
    id!: string;

    // @Column({ type: 'string', name: 'MENU' })
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'text', type: 'text', })
    name !: string

    // @Column({ type: "number", name: "CLIENT_ID" })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId !: number;

    @getColumnType({ mongoType: "string", type: "text", postgresType: 'text', name: "CONFIG" })
    config !: string

    // @Column({ type: "number", name: "ACTIVE" })
    @Index()
    @getColumnType({ name: 'ACTIVE', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', })  
    active !: number

    // @Column({type: "char", length: 36, name: "UPDATED_BY"})
    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    updatedBy !: string

    // @Column({ name: 'CREATED_BY', type: 'string', length: 36 })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;
    
    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
