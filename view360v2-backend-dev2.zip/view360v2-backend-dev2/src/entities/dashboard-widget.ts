import {Entity,CreateDateColumn, ManyToOne, JoinColumn} from 'typeorm'
import {WidgetAccount} from './widget-account';
import {getColumnType, getType} from "../services/db.service";

@Entity('dashboard_widget')
export class DashboardWidget  {

    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    // @Column({ name: 'DASHBOARD', type: 'varchar', length: 100, nullable: true })
    @getColumnType({ name: 'DASHBOARD', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true, nullable: true })
    dashboard!: string;

    @ManyToOne(() => WidgetAccount, (widgetAccount: WidgetAccount) => widgetAccount.id, { cascade: false, onDelete: 'SET NULL' })
    @JoinColumn({ name: "WIDGET_ACCOUNT" })
    widgetAccount!: WidgetAccount | string;

    // @Column({ name: 'TYPE', type: 'varchar', length: 30 })
    @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 30, isLengthRequired: true, })
    type!: string;

    // @Column({ name: 'TITLE', type: 'varchar', length: 255 })
    @getColumnType({ name: 'TITLE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true, })
    title!: string;

    // @Column({ name: 'WIDGET_CONFIG', nullable: true, type: 'text' })
    @getColumnType({ name: 'WIDGET_CONFIG', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true, })
    widgetConfig!: string;

    // @Column({ name: 'IS_CONFIGURED', type: 'smallint', default: 0 })
    @getColumnType({ name: 'IS_CONFIGURED', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isConfigured!: number;
    
    @getColumnType({ name: 'IS_WIDGET_VISIBLE', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 1 })
    isWidgetVisible!: number;

    // @Column({ name: 'POSITIONX', type: 'varchar', length: 20, default: 0, })
    @getColumnType({ name: 'POSITIONX', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 20, default: 0, isLengthRequired: true, })
    positonX!: string;

    // @Column({ name: 'POSITIONY', type: 'varchar', length: 20, default: 0 })
    @getColumnType({ name: 'POSITIONY', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 20, default: 0, isLengthRequired: true, })
    positonY!: string;

    // @Column({ name: 'WIDTH', type: 'varchar', length: 20, default: 0 })
    @getColumnType({ name: 'WIDTH', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 20, default: 0, isLengthRequired: true, })
    width!: string;

    // @Column({ name: 'HEIGHT', type: 'varchar', length: 20, default: 0 })
    @getColumnType({ name: 'HEIGHT', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 20, default: 0, isLengthRequired: true, })
    height!: string;

    // @Column({ type: 'char', length: 36, name: 'CREATED_BY' })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'varchar', type: 'char', length: 36, })
    createdBy: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    // @Column({ name: 'MAPPED_USER', type: 'text' })
    @getColumnType({ name: 'MAPPED_USER', mongoType: 'string', postgresType: 'text', type: 'text' })
    mappedUser!: string;

}

