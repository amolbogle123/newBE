import { Entity, CreateDateColumn, Index } from "typeorm";
import { getColumnType, getType } from "../services/db.service";

@Entity("custom_header")
export class CustomHeader  {
    // @PrimaryGeneratedColumn("uuid", {name: 'ID'})
    @getType()
    id: string;

    @Index()
    @getColumnType({
        name: "CLIENT_ID",
        mongoType: "string",
        postgresType: "int",
        type: "int",
    })
    clientId: string;

    // @Column({ type: 'varchar', length: 255, name: 'NAME', nullable: true })
    @getColumnType({
        name: "CONFIG",
        mongoType: "text",
        postgresType: "text",
        type: "longtext",
        nullable: true,
    })
    config!: string;

    // @Column({ type: "number", name: "ACTIVE" })
    @getColumnType({
        name: "ACTIVE",
        mongoType: "number",
        postgresType: "smallint",
        type: "tinyint",
    })
    active!: number;

    @getColumnType({
        name: "CREATED_BY",
        mongoType: "string",
        postgresType: "char",
        type: "char",
        length: 36,
    })
    createdBy!: string;

    @CreateDateColumn({ name: "CREATED_ON", type: "timestamp" })
    createdOn!: Date;
}
