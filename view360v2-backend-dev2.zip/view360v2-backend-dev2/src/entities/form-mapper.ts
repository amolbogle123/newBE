import {
    Entity,
    CreateDateColumn,
    ManyToOne,
    JoinColumn,
    Index,
} from "typeorm";
import { MdbClient } from "./mdb-client";
import { CustomForms } from "./custom-forms";
import { getColumnType, getType } from "../services/db.service";

@Entity("form_mapper")
export class FormMapper  {
    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    @ManyToOne(() => MdbClient, (mdbClient: MdbClient) => mdbClient.id, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'CLIENT_ID' })
    mdbClient: MdbClient;

    @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'char', type: 'char', length: 50, nullable: false, default: 'excel' })
    type!: string;

    @getColumnType({ name: 'FILE_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: false })
    fileConfig!: string;

    // @Column({ name: 'FORM_ID', type: 'char', length: 36, nullable: false })
    @getColumnType({ name: 'FORM_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: false })
    formId!: string;

    @ManyToOne(() => CustomForms, (customForms: CustomForms) => customForms.id, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'FORM_ID' })
    form!: CustomForms | string;

    // @Column({ name: 'CONFIG', nullable: true, type: 'longtext' })
    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true })
    config!: string;

    // @Column({ name: 'COLUMN_HEADER', type: 'int', default: 0 })
    @getColumnType({ name: 'COLUMN_HEADER', mongoType: 'number', postgresType: 'int', type: 'int', default: 0 })
    columnHeader!: string;

    // @Column({ name: 'CREATED_BY', type: 'char', length: 36 })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
