import { CreateDateColumn, Entity } from 'typeorm';
import { getColumnType, getType } from "../services/db.service";

@Entity("active_session")
export class ActiveSession  {

    //@PrimaryGeneratedColumn('increment', { name:'ID'})
    @getType('increment')
    id!: string;

    @getColumnType({ name: 'DATE', mongoType: 'string', postgresType: 'text', type: 'text' })
    expiryDate: string;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn: Date;

    @getColumnType({ name: 'UPDATED_AT', mongoType: 'string', postgresType: 'timestamp', type: 'timestamp', nullable: true })
    updatedAt: string;

    @getColumnType({ name: 'DELETED_AT', mongoType: 'string', postgresType: 'timestamp', type: 'timestamp', nullable: true })
    deletedAt: string;

    @getColumnType({ name: 'IS_LOGOUT_PERFORMED', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    isLogoutPerformed!: number;
}