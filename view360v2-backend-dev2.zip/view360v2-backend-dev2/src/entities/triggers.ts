import { Entity, CreateDateColumn, Index } from "typeorm";
import { getColumnType, getType } from "../services/db.service";

@Entity("widget_trigger")
export class WidgetTriggers { 
    // @PrimaryGeneratedColumn("uuid", {name: 'ID'})
    @getType()
    id: string;

    @Index()
    @getColumnType({
        name: "CLIENT_ID",
        mongoType: "string",
        postgresType: "int",
        type: "int",
    })
    clientId: number;

    // @Column({ name: 'DASHBOARD_ID', type: 'varchar', length: 100, nullable: true })
    @getColumnType({
        name: "DASHBOARD_ID",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        length: 100,
        nullable: true,
    })
    dashboard!: string;

    // @Column({ type: 'varchar', length: 255, name: 'NAME', nullable: true })
    @getColumnType({
        name: "NAME",
        mongoType: "text",
        postgresType: "text",
        type: "longtext",
        nullable: true,
    })
    name!: string;

    @getColumnType({
        name: "WIDGET_ID",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        nullable: true,
    })
    widgetId!: string;

    @getColumnType({
        name: "CONFIG",
        mongoType: "string",
        postgresType: "text",
        type: "longtext",
        default: null,
    })
    config!: string;

    // @Column({ type: 'char', length: 36, name: 'CREATED_BY' })
    @getColumnType({
        name: "CREATED_BY",
        mongoType: "string",
        postgresType: "varchar",
        type: "char",
        length: 36,
    })
    createdBy: string;

    @CreateDateColumn({ name: "CREATEDON", type: "timestamp" })
    createdOn!: Date;
}
