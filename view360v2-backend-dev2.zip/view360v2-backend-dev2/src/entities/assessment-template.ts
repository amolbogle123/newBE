import { CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';
import { getColumnType } from '../services/db.service';

@Entity('assessment_template')
export class AssessmentTemplate {
    @PrimaryGeneratedColumn('uuid')
    id!: number;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    clientId!: number;

    @getColumnType({ name: 'TEMPLATE_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    templateName !: string;

    @getColumnType({ name: 'TEMPLATE_DESCRIPTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', default: '' })
    templateDescription!: string;

    @getColumnType({ name: 'TEMPLATE_QUESTIONS', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    templateQuestions!: number;

    @getColumnType({ name: 'IS_ACTIVE', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    isActive!: number;

    @getColumnType({ name: 'IS_DELETED', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    isDeleted!: number;

    @CreateDateColumn({ name: 'CREATED_ON', type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
    createdOn: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'UPDATED_ON', type: 'timestamp', default: '', onUpdate: "CURRENT_TIMESTAMP(6)" })
    updatedOn: string;

    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, default: '' })
    updatedBy!: string;
}