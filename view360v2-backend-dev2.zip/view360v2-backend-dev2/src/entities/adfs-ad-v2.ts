import {Entity, CreateDateColumn, Index} from 'typeorm';
import {getColumnType, getType} from "../services/db.service";

@Entity("adfs_ad_v2")
export class AdfsAdv2  {
    @getType('increment')
    id!: string;

    @getColumnType({ name: 'MICROSOFT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    microsoftId: number;

    @getColumnType({ name: 'CERT', mongoType: 'string', postgresType: 'text', type: 'text' })
    cert: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId: number;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn: Date;

    @getColumnType({ name: 'UPDATED_AT', mongoType: 'string', postgresType: 'timestamp', type: 'timestamp', nullable: true })
    updatedAt: string;

    @getColumnType({ name: 'DELETED_AT', mongoType: 'string', postgresType: 'timestamp', type: 'timestamp', nullable: true })
    deletedAt: string;
}
