import {
    Entity,
    CreateDateColumn,
    Index,
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';

@Entity("child_company")
export class ChildCompany {
    
    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id!: string;

    // @Column({ type: 'int', name: 'CLIENT_ID', nullable: true })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    clientId!: number;

    // @Column({type: 'string', length: 255, name: 'NAME', nullable: true})
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    name!: string;

    // @Column({type: 'string', name: 'LOCATIONS', nullable: true})
    @getColumnType({ name: 'LOCATIONS', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    locations!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
