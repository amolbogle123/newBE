import { CreateDateColumn, Entity } from 'typeorm';
import { getColumnType, getType } from "../services/db.service";

@Entity("activation_data")
export class ActivationData {
    @getType('increment')
    id!: string;

    @getColumnType({ name: 'CLIENT_ID', mongoType: 'string', postgresType: 'text', type: 'text' })
    clientId: string;
    
    @getColumnType({ name: 'BUNDLE_ID', mongoType: 'string', postgresType: 'text', type: 'text' })
    bundleId: string;
    
    @getColumnType({ name: 'ACTIVATION_KEY', mongoType: 'string', postgresType: 'text', type: 'text' })
    activationKey: string;

    @getColumnType({ name: 'IS_ACTIVE', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    isActive!: number;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn: Date;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'text', type: 'text' })
    createdBy: string;
    
    @getColumnType({ name: 'UPDATED_AT', mongoType: 'string', postgresType: 'timestamp', type: 'timestamp', nullable: true })
    updatedAt: string;
    
    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    updatedBy: string;
}