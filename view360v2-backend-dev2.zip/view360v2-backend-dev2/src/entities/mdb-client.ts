import {Entity, CreateDateColumn} from "typeorm"
import { getType, getColumnType } from '../services/db.service';

@Entity("mdb_clients")
export class MdbClient  {

    // @PrimaryGeneratedColumn("increment", {name: "ID"})
    @getType('increment')
    id!: number;

    // @Column({ name: 'NAME', type: 'varchar' })
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    name!: string;

    // @Column({ name: 'FIRST_NAME', type: 'varchar', length: 50 })
    @getColumnType({ name: 'FIRST_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 50, isLengthRequired: true })
    firstName!: string;

    // @Column({ name: 'LAST_NAME', type: 'varchar', length: 50 })
    @getColumnType({ name: 'LAST_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 50, isLengthRequired: true })
    lastName!: string;

    // @Column({ name: 'EMAIL', type: 'varchar' })
    @getColumnType({ name: 'EMAIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    email!: string;

    // @Column({ name: 'PRIMARY_CONTACT', type: 'varchar' })
    @getColumnType({ name: 'PRIMARY_CONTACT', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    primaryContact!: string;

    // @Column({ name: 'SECONDARY_CONTACT', type: 'varchar' })
    @getColumnType({ name: 'SECONDARY_CONTACT', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    secondaryContact!: string;

    // @Column({ name: 'COMPANY_NAME', type: 'varchar' })
    @getColumnType({ name: 'COMPANY_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    companyName!: string;

    // @Column({ name: 'EMPLOYEES', type: 'varchar' })
    @getColumnType({ name: 'EMPLOYEES', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    employees!: string;

    // @Column({ name: 'WEBSITE_URL', type: 'varchar' })
    @getColumnType({ name: 'WEBSITE_URL', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    websiteUrl!: string;

    // @Column({ name: 'STORE_NAME', type: 'varchar' })
    @getColumnType({ name: 'STORE_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    storeName!: string;

    // @Column({ name: 'VERTICAL', type: 'varchar' })
    @getColumnType({ name: 'VERTICAL', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    vertical!: string;

    // @Column({ name: 'IS_TRIAL', type: 'smallint', default: 1 })
    @getColumnType({ name: 'IS_TRIAL', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 1 })
    isTrial!: number;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    // @Column({ name: 'MODIFIED_ON', type: 'varchar', length: 100, nullable: true })
    @getColumnType({ name: 'MODIFIED_ON', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, nullable: true, isLengthRequired: true })
    modifiedOn!: string;

    // @Column({ name: 'MAX_USER_LIMIT', type: 'int', length: 0 })
    @getColumnType({ name: 'MAX_USER_LIMIT', mongoType: 'number', postgresType: 'int', type: 'int', length: 0 })
    maxUserLimit!: number;

    // @Column({ name: 'PWA_URL', type: 'varchar', nullable: true })
    @getColumnType({ name: 'PWA_URL', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    pwaUrl!: string;

    // @Column({ name: 'USING_ACCESS', type: 'smallint', default: 1 })
    @getColumnType({ name: 'USING_ACCESS', mongoType: 'string', postgresType: 'smallint', type: 'smallint', default: 1 })
    usingAccess!: number;

    // @Column({ name: 'VALUE_MULTIPLIER', type: 'smallint', default: 1 })
    @getColumnType({ name: 'VALUE_MULTIPLIER', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    valueMultiplier!: number;

    // @Column({ name: 'ACCESSIBLE_UNTIL', type: 'varchar' })
    @getColumnType({ name: 'ACCESSIBLE_UNTIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    accessibleUntil!: string;

    // @Column({ name: 'CLIENT_ADDRESS', type: 'varchar', nullable: true })
    @getColumnType({ name: 'CLIENT_ADDRESS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    clientAddress!: string;

    // @Column({ name: 'CHATBOT_AGENT', type: 'char', length: 36, nullable: true })
    @getColumnType({ name: 'CHATBOT_AGENT', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    chatbotAgent!: string;

    // @Column({ name: 'LOGO_URL', type: 'text' })
    @getColumnType({ name: 'LOGO_URL', mongoType: 'string', postgresType: 'text', type: 'text' })
    logoUrl!: string;

    // @Column({ name: 'ORG_ID', type: 'varchar', length: 20 })
    @getColumnType({ name: 'ORG_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 20, isLengthRequired: true })
    orgId!: string;

    // @Column({ name: 'STATE', type: 'varchar', length: 50, nullable: true })
    @getColumnType({ name: 'STATE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 50, nullable: true, isLengthRequired: true })
    state!: string;

    // @Column({ name: 'ZIPCODE', type: 'varchar', length: 50, nullable: true })
    @getColumnType({ name: 'ZIPCODE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 50, nullable: true, isLengthRequired: true })
    zipCode!: string;

    // @Column({ name: 'TERRITORY_FILE_PATH', type: 'varchar', nullable: true })
    @getColumnType({ name: 'TERRITORY_FILE_PATH', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    territoryFilePath!: string;

    // @Column({ name: 'METERS', type: 'varchar', nullable: true })
    @getColumnType({ name: 'METERS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    meters!: string;

    // @Column({ name: 'USER_ID', type: 'varchar' })
    @getColumnType({ name: 'USER_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    userId!: string;

    // @Column({ name: 'SECOND_EMAIL', type: 'varchar' })
    @getColumnType({ name: 'SECOND_EMAIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    secondEmail!: string;

    // @Column({ name: 'THIRD_EMAIL', type: 'varchar' })
    @getColumnType({ name: 'THIRD_EMAIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    thirdEmail!: string;

    // @Column({ name: 'FOURTH_EMAIL', type: 'varchar' })
    @getColumnType({ name: 'FOURTH_EMAIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    fourthEmail!: string;
}
