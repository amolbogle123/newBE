import { Entity, CreateDateColumn } from "typeorm";
import { getColumnType, getType } from '../services/db.service';

abstract class EntityClass {
    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id!: string;

    // @Column({name: 'FORM_ID', type: 'char', length: 36})
    @getColumnType({ name: 'FORM_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    formId!: string;

    // @Column({name: 'SUBMITTED_DATA', type: 'text', nullable: true})
    @getColumnType({ name: 'SUBMITTED_DATA', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    submittedData!: string;

    // @Column({name: 'CREATED_BY', type: 'char', length: 36})
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}

export function createFormBuilder(clientId: number, referenceId?: string) {
    const tableName: string = referenceId ? `form_builder_${clientId}_${referenceId}` : `form_builder_${clientId}`;

    @Entity({ name: tableName })
    class FormBuilder extends EntityClass {
        public static tableName = tableName;

        // @Column({name: 'BEING_FILLED_BY', type: 'char', length: 36})
        @getColumnType({ name: 'BEING_FILLED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
        beingFilledBy!: string;
    }
    return FormBuilder;
}

export function createFormBuilderHistory(clientId: number) {
    const tableName: string = `form_builder_${clientId}_history`;

    @Entity({ name: tableName })
    class FormBuilderHistory extends EntityClass {
        public static tableName = tableName;

        // @Column({name: 'ENTRY_ID', type: 'char', length: 36})
        @getColumnType({ name: 'ENTRY_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
        entryId!: string;
    }
    return FormBuilderHistory;
}

export function createFormBuilderPdf(clientId: number) {
    const tableName: string = `pdf_form_builder_${clientId}`;

    @Entity({ name: tableName })
    class FormBuilderPdf extends EntityClass {
        public static tableName = tableName;
    }
    return FormBuilderPdf;
}

export interface FormBuilder extends EntityClass {
    beingFilledBy: string;
}
export interface FormBuilderHistory extends EntityClass {
    entryId: string;
}
export interface FormBuilderPdf extends EntityClass { }

export const formBuilderEntity: string = 'FormBuilder';
export const formBuilderHistoryEntity: string = 'FormBuilderHistory';
export const formBuilderPdfEntity: string = 'FormBuilderPdf';