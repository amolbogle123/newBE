import {Entity, CreateDateColumn, Index} from 'typeorm';

import { getColumnType, getType } from '../services/db.service';

@Entity('bpmn')
export class BusinessProcessModeling {

    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    // @Column({ type: 'int', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    // @Column({ type: 'char', length: 36, name: 'FORM_ID', nullable: true })
    @getColumnType({ name: 'FORM_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    formId!: string;

    // @Column({ type: 'varchar', length: 50, name: 'TYPE' })
    @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 50, isLengthRequired: true })
    type!: string;

    // @Column({ name: 'SQL_CONNECTOR', type: 'int' })
    @getColumnType({ name: 'SQL_CONNECTOR', mongoType: 'number', postgresType: 'int', type: 'int' })
    sqlConnector!: number;

    // @Column({ name: 'BPMN_DATA', type: 'text' })
    @getColumnType({ name: 'BPMN_DATA', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    bpmnData!: string;

    // @Column({ name: 'PANEL_DATA', type: 'text' })
    @getColumnType({ name: 'PANEL_DATA', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    panelData!: any;

    // @Column({ name: 'FOLLOW_AFTER', type: 'char', length: 36 })
    @getColumnType({ name: 'FOLLOW_AFTER', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    followAfter!: string;

    // @Column({ name: 'CREATED_BY', type: 'char', length: 36 })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36,isLengthRequired: true })
    createdBy!: string;

    // @Column({ name: 'UPDATED_BY', type: 'char', length: 36, nullable: true })
    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    updatedBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    // @Column({ name: 'APP_ID', type: 'char', length: 36, nullable: true })
    @getColumnType({ name: 'APP_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    appId!: string;

    // @Column({ name: 'STATUS', type: 'int', default: 0 })
    @getColumnType({ name: 'STATUS', mongoType: 'number', postgresType: 'int', type: 'int', default: 0 })
    status!: number;
}
