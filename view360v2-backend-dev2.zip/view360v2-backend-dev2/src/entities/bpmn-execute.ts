import {
    Entity,
    CreateDateColumn,
    ManyToOne,
    JoinColumn
} from 'typeorm'
import {BusinessProcessModeling} from "./bpmn";
import { getColumnType, getType } from '../services/db.service';
@Entity("bpmn_execute")
export class BusinessProcessModelingExecute  {

    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    // @Column({ type: 'char', length: 36, name: 'ENTRY_ID' })
    @getColumnType({ name: 'ENTRY_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    entryId!: string;

    // @Column({ type: 'varchar', length: 100, name: 'STAGE' })
    @getColumnType({ name: 'STAGE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true, nullable: true })
    stage!: string;

    @ManyToOne(() => BusinessProcessModeling, (bpmn: BusinessProcessModeling) => bpmn.id, {onDelete: 'CASCADE'})
    @JoinColumn({name: 'BPMN_ID'})
    bpmn!: string;

    // @Column({ type: 'char', length: 36, name: 'FORM_ID' })
    @getColumnType({ name: 'FORM_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    formId!: string;

    // @Column({ type: 'varchar', length: 100, name: 'ACTIVITY_ID' })
    @getColumnType({ name: 'ACTIVITY_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true, nullable: true })
    activityId!: string;

    // @Column({ type: 'varchar', length: 100, name: 'TASK_NAME' })
    @getColumnType({ name: 'TASK_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true, nullable: true})
    taskName!: string;

    // @Column({ name: 'STATUS', type: 'varchar', length: 50 })
    @getColumnType({ name: 'STATUS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 50, isLengthRequired: true, nullable: true })
    status!: string;

    // @Column({ name: 'ASSIGN_USER_ID', type: 'char', length: 36 })
    @getColumnType({ name: 'ASSIGN_USER_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    assignedUserId!: string;

    // @Column({ name: 'ASSIGN_ROLE_ID', type: 'char', length: 36 })
    @getColumnType({ name: 'ASSIGN_ROLE_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    assignedRoleId!: string;

    // @Column({ name: 'ESCALATE_USER_TO', type: 'char', length: 36 })
    @getColumnType({ name: 'ESCALATE_USER_TO', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    escalateUserTo!: string;

    // @Column({ name: 'IS_REJECTED', type: 'smallint' })
    @getColumnType({name: 'IS_REJECTED', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isRejected!: number;

    // @Column({ name: 'FOLLOW_AFTER', type: 'char', length: 36 })
    @getColumnType({ name: 'FOLLOW_AFTER', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    followAfter!: string;

    // @Column({ name: 'PANEL_DATA', type: 'text' })
    @getColumnType({ name: 'PANEL_DATA', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true })
    panelData!: string;

    @getColumnType({ name: 'EXECUTED_DATA', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true })
    executedData!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    // @Column({ name: 'SUBMITTED_BY', type: 'char', length: 36 })
    @getColumnType({ name: 'SUBMITTED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    submittedBy!: string;
}
