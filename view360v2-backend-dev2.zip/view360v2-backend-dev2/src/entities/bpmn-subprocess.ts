import { CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { getColumnType } from "../services/db.service";

@Entity("bpmn_subprocess")
export class BusinessProcessModelingSubProcess {

    @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    id!: string;

    //@ManyToOne(() => BusinessProcessModeling, (bpmn: BusinessProcessModeling) => bpmn.id, {onDelete: 'CASCADE'})
    //@JoinColumn({name: 'BPMN_ID'})
    @getColumnType({ name: 'BPMN_ID', mongoType: 'string', postgresType: 'text', type: 'text' })
    bpmn!: string;

    @getColumnType({ name: 'ACTIVITY_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true, nullable: true })
    activityId!: string;

    @getColumnType({ name: 'SERVICE_TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true, nullable: true })
    serviceType!: string;

    @getColumnType({ name: 'PROCESS_DATA', mongoType: 'string', postgresType: 'json', type: 'json' })
    processData!: JSON;

    @getColumnType({ name: 'STATUS', mongoType: 'string', postgresType: 'text', type: 'text' })
    status!: string;

    @CreateDateColumn({name: 'CREATED_ON', type: "timestamp"})
    createdOn!: Date;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    updatedBy!: string;

    @CreateDateColumn({ name: `UPDATED_ON`, type: "timestamp"})
    updatedOn!: Date;

    @getColumnType({ name: 'IS_DELETED', mongoType: 'number', postgresType: 'smallint', type: 'smallint' })
    isDeleted!: number;
}
