import {Entity, CreateDateColumn, ManyToOne, JoinColumn, Index} from 'typeorm'
import {Users} from "./users";
import {getColumnType, getType} from "../services/db.service";

@Entity('request_form')
export class RequestForm  {

    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    // @Column({ type: 'int', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId!: number;

    // @Column({ name: 'URL_PATH', type: 'varchar', length: 100 })
    @getColumnType({ name: 'URL_PATH', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 100, isLengthRequired: true })
    urlPath!: string;

    // @Column({ name: 'FORM_ID', type: 'char', length: 36 })
    @getColumnType({ name: 'FORM_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    formId!: string;
    
    @getColumnType({ name: 'ENTRY_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, default: null })
    entryId!: string;
    
    @getColumnType({ name: 'FORM_NAME', mongoType: 'string', postgresType: 'char', type: 'char', length: 50 })
    formName!: string;

    // @Column({ name: 'CREATEDBY', type: 'char', length: 36 })
    @getColumnType({ name: 'CREATEDBY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    // @Column({ name: 'REQUEST_CONFIG', type: 'text' })
    @getColumnType({ name: 'REQUEST_CONFIG', mongoType: 'string', postgresType: 'text', type: 'text' })
    requestConfig!: string;

    @getColumnType({ name: 'SUBMITTEDON', type: 'timestamp', default: null })
    submittedOn!: Date | null;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;

    @ManyToOne(() => Users, (usr: Users) => usr.id, { cascade: false, onDelete: 'SET NULL' })
    @JoinColumn({name: 'USER_ID'})
    user!: Users | any;
}
