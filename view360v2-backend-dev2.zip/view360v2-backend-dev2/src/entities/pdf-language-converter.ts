import { CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

import { getColumnType } from '../services/db.service';

@Entity('pdf_converter')
export class PdfLanguageConverter {
    @PrimaryGeneratedColumn('uuid')
    id!: number;

    @getColumnType({ name: 'FILE_ORIGINAL_NAME', mongoType: 'string', postgresType: 'char', type: "char", length: 255, nullable: true })
    fileOriginalName: string;

    @getColumnType({ name: 'FILE_SERVER_NAME', mongoType: 'string', postgresType: 'char', type: "char", length: 255, nullable: true })
    fileServerName: string;

    @getColumnType({ name: 'TRANSLATED_FILE_NAME', mongoType: 'string', postgresType: 'char', type: "char", length: 255, nullable: true })
    translatedFileName: string;

    @getColumnType({ name: 'FILE_PATH', mongoType: 'string', postgresType: 'char', type: "char", length: 255, nullable: true })
    filePath: string;

    @getColumnType({ name: 'FILE_SIZE', mongoType: 'string', postgresType: 'char', type: "char", length: 255, nullable: true })
    fileSize: string;

    @getColumnType({ name: 'FILE_UPLOADED_LANGUAGE', mongoType: 'string', postgresType: 'char', type: "char", length: 255, nullable: true })
    fileUploadedLanguage: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: "char", length: 36, deafult: 'SYSTEM' })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: "timestamp" })
    createdOn!: Date;

}
