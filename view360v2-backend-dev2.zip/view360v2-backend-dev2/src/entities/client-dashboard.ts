import { Entity, CreateDateColumn, Index } from 'typeorm'

import { getColumnType, getType } from '../services/db.service';

@Entity('client_dashboard')
export class ClientDashboard {

    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id!: string;

    // @Column({name: 'TITLE', type: 'varchar', length: 255, nullable: true})
    @getColumnType({ name: 'TITLE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    title!: string;

    // @Column({name: 'TITLE', type: 'varchar', length: 255, nullable: true})
    @getColumnType({ name: 'WIDGET_SPACE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    widgetSpace!: string;
    // @Column({type: 'int', name: 'CLIENT_ID'})
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    // @Column({type: 'char', length: 36, name: 'CREATED_BY'})
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;

    // @Column({ nullable: true, type: 'text', name: 'ROLE_PERMISSION_CONFIG'})
    @getColumnType({ name: 'ROLE_PERMISSION_CONFIG', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    rolePermissionConfig!: string;

    // @Column({ nullable: true, type: 'text', name: 'MAPPED_USER'})
    @getColumnType({ name: 'MAPPED_USER', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    mappedUser!: string;

    // @Column({ nullable: true, type: 'text', name: 'USER_PERMISSION_CONFIG'})
    @getColumnType({ name: 'USER_PERMISSION_CONFIG', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    userPermissionConfig!: string;

    // @Column({name: 'APP_ID', type: 'char', length: 36, nullable: true})
    @getColumnType({ name: 'APP_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true })
    appId!: string;

    // @Column({ nullable: true, type: 'text', name: 'FILTER_CONFIG'})
    @getColumnType({ name: 'FILTER_CONFIG', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    filterConfig!: string;

    // @Column({ nullable: true, default: 0, type: 'int', name: 'DEFAULT_ID'})
    @getColumnType({ name: 'DEFAULT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true, default: 0 })
    defaultId!: number;

    @getColumnType({ name: 'DASHBOARD_CONFIG', mongoType: 'string', postgresType: 'text', type: 'text' })
    dashboardConfig!: string;
}
