import {
    Entity,
    CreateDateColumn,
    JoinColumn, ManyToOne, Index
} from 'typeorm';
import { WidgetAccount } from "../entities";
import { getColumnType, getType } from '../services/db.service';

@Entity("connected_dataset")
export class ConnectedDataset  {
    // @PrimaryGeneratedColumn("uuid", {name: 'ID'})
    @getType()
    id: string;

    // @Column({ name: 'CLIENT_ID', type: 'int' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId: number;

    // @Column({ type: 'varchar', length: 255, name: 'NAME', nullable: true })
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    name!: string;

    // @Column({ name: 'CONFIG', nullable: true, type: 'text' })
    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    config: string;

    // @Column({ type: 'char', length: 36, name: 'CREATEDBY' })
    @getColumnType({ name: 'CREATEDBY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, })
    createdBy: string;

    @CreateDateColumn({ name: 'CREATEDON', type: 'timestamp' })
    createdOn!: Date;

    @ManyToOne(() => WidgetAccount, (widgetAccount: WidgetAccount) => widgetAccount.id, { cascade: false, onDelete: 'SET NULL' })
    @JoinColumn({ name: "WIDGET_ACCOUNT_ID" })
    widgetAccount: WidgetAccount | string;
}
