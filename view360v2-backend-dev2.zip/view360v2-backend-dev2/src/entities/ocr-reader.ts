import {
    Entity,
    CreateDateColumn,
    ManyToOne,
    JoinColumn,
    Index,
} from "typeorm";
import { MdbClient } from "./mdb-client";
import { getColumnType, getType } from "../services/db.service";

@Entity("ocr_reader")
export class OcrReader  {
    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    @ManyToOne(() => MdbClient, (mdbClient: MdbClient) => mdbClient.id, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'CLIENT_ID' })
    mdbClient: MdbClient;

    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255 })
    name!: string;

    @getColumnType({ name: 'FILE_SOURCE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, default: 'manual' })
    fileSource!: string;

    @getColumnType({ name: 'FILE_SOURCE_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, default: null })
    fileSourceId!: string;

    @getColumnType({ name: 'MODEL_TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, default: null })
    modelType!: string;

    @getColumnType({ name: 'FILE_PATH', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255 })
    filePath!: string;

    @getColumnType({ name: 'FILE_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', default: null })
    fileConfig!: string;

    @getColumnType({ name: 'IS_DATA_PARSED', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isDataParsed!: number;

    @getColumnType({ name: 'PAGE_COUNT', mongoType: 'string', postgresType: 'text', type: 'varchar', length: 25, default: '0' })
    pageCount!: string;

    @getColumnType({ name: 'JOB_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 500, default: null })
    jobId!: string;
    
    @getColumnType({ name: 'STATUS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, default: 'COMPLETED' })
    status!: string;

    @getColumnType({ name: 'IS_DELETED', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isDeleted!: number;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
