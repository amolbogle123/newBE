import {Entity, Index} from "typeorm";

import { getColumnType, getType } from '../services/db.service';

@Entity('user_logs')
export class UserLogs  {

    // @PrimaryGeneratedColumn('increment', {name: 'ID'})
    @getType('increment')
    id!: number;

    // @Column({name: 'USER_ID', type: 'char'})
    @getColumnType({ name: 'USER_ID', mongoType: 'string', postgresType: 'char', type: 'char' })
    userId!: string;

    // @Column({name: 'CLIENT_ID', type: 'int'})
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    // @Column({name: 'RECORD_ID', type: 'char'})
    @getColumnType({ name: 'RECORD_ID', mongoType: 'string', postgresType: 'char', type: 'char' })
    recordId!: string;

    // @Column({name: 'TABLE_NAME', type: 'varchar'}) // type: 'varchar2'
    @getColumnType({ name: 'TABLE_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    tableName!: number;

    // @Column({name: 'ACTION', type: 'varchar'}) // type: 'varchar2'
    @getColumnType({ name: 'ACTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar' })
    action!: number;
}
