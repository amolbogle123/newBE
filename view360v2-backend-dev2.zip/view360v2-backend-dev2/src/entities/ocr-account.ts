import {
    Entity,
    CreateDateColumn,
    ManyToOne,
    JoinColumn,
    Index,
} from "typeorm";
import { MdbClient } from "./mdb-client";
import { getColumnType, getType } from "../services/db.service";

@Entity("ocr_account")
export class OcrAccount  {
    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    @ManyToOne(() => MdbClient, (mdbClient: MdbClient) => mdbClient.id, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'CLIENT_ID' })
    mdbClient: MdbClient;

    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255 })
    name!: string;

    @getColumnType({ name: 'TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255 })
    type!: string;

    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: false })
    config!: string;

    @getColumnType({ name: 'IS_CONFIGURED', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 0 })
    isConfigured!: number;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}