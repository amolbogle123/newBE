import {
    Entity
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';

@Entity("geo_targets")
export class GeoTargets  {
    
    @getType('increment')
    id!: string;
    
    @getColumnType({ name: 'Criteria_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    criteriaId!: number;

    @getColumnType({ name: 'Name', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    name!: string;

    @getColumnType({ name: 'Canonical_Name', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    canonicalName!: string;

    @getColumnType({ name: 'Parent_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    parentId!: number;

    @getColumnType({ name: 'Country_Code', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    countryCode!: string;

    @getColumnType({ name: 'Target_Type', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    targetType!: string;

    @getColumnType({ name: 'Status', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    status!: string;
}
