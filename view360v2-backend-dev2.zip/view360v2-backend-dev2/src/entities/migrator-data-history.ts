import {
    CreateDateColumn,
    Entity,
    Index
} from "typeorm";
import { getColumnType, getType } from '../services/db.service';

@Entity("migrator_data_history")
export class MigratorDataHistory  {
    
    @getType()
    id!: string;
    
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int' })
    clientId!: number;

    @getColumnType({ name: 'MIGRATION_ID', mongoType: 'string', postgresType: 'char', type: 'char', nullable: true, length: 36, isLengthRequired: true })
    migrationId!: string;

    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true })
    name!: string;

    @getColumnType({ name: 'CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true })
    config!: string;

    @getColumnType({ name: 'EXECUTION_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true })
    executionConfig!: string;

    // initiateProcess, completedProcess, failedProcess
    @getColumnType({ name: 'STATUS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255 })
    status!: any;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'varchar', type: 'char', length: 36, nullable: true })
    createdBy: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
