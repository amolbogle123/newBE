import { Entity, CreateDateColumn, Index } from "typeorm";

import { getColumnType, getType } from "../services/db.service";

@Entity("signup_config")
export class SignupConfig {
    // @PrimaryGeneratedColumn('increment', { name:'ID'})
    @getType()
    id!: string;

    // @Column({ name: 'CLIENT_ID', type: 'number' })
    @Index()
    @getColumnType({
        name: "CLIENT_ID",
        mongoType: "number",
        postgresType: "int",
        type: "int",
    })
    client_id!: number;

    @getColumnType({
        name: "CONFIG",
        mongoType: "string",
        postgresType: "text",
        type: "longtext",
        default: null,
    })
    config!: string;

    @CreateDateColumn({ name: "CREATEDON", type: "timestamp" })
    createdOn!: Date;
}
