import { Entity, CreateDateColumn, Index } from "typeorm";
import { getColumnType, getType } from "../services/db.service";

@Entity("escaltion_level")
export class EscalationLevel {
    // @PrimaryGeneratedColumn('uuid', {name: 'ID'})
    @getType()
    id!: string;

    // @Column({ type: 'int', name: 'CLIENT_ID', nullable: true })
    @Index()
    @getColumnType({
        name: "CLIENT_ID",
        mongoType: "number",
        postgresType: "int",
        type: "int",
        nullable: true,
    })
    clientId!: number;

    @getColumnType({
        name: "name",
        mongoType: "string",
        postgresType: "varchar",
        type: "varchar",
        length: 255,
        nullable: true,
        isLengthRequired: true,
    })
    name!: string;

    @getColumnType({
        name: "EscalationmailId",
        mongoType: "string",
        postgresType: "text",
        type: "text",
        nullable: true,
    })
    escalationmailId!: string;

    @getColumnType({
        name: "IsActive",
        mongoType: "string",
        postgresType: "text",
        type: "text",
        nullable: true,
    })
    isActive!: string;

    @CreateDateColumn({ name: "CREATED_ON", type: "timestamp" })
    createdOn!: Date;

    @getColumnType({
        name: "UPDATED_AT",
        mongoType: "string",
        postgresType: "timestamp",
        type: "timestamp",
        nullable: true,
    })
    updatedAt: string;
}
