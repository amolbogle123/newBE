import {
    Entity,
    CreateDateColumn,
    Index,
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';

@Entity('mail_log')
export class MailLog  {
    // @PrimaryGeneratedColumn('uuid', { name: 'ID' })
    @getType()
    id!: string;

    // @Column({ type: 'int', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId!: number;

    // @Column({ type: 'varchar', name: 'TO_MAIL' })
    @getColumnType({ name: 'TO_MAIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    toMail!: string;

    // @Column({ type: 'varchar', name: 'FROM_MAIL' })
    @getColumnType({ name: 'FROM_MAIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    fromMail!: string;

    // @Column({
    //     type: 'smallint',
    //     name: 'OPEN',
    //     default: 0,
    //     comment: '0 = Not Open,1 = Open',
    // })
    @getColumnType({
        name: 'OPEN',
        mongoType: 'number',
        postgresType: 'smallint',
        type: 'tinyint',
        default: 0,
        comment: '0 = Not Open,1 = Open',
    })
    isOpened!: number;

    // @Column({ type: 'text', name: 'OPEN_LOG', nullable: true })
    @getColumnType({ name: 'OPEN_LOG', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true, default: null })
    openLog!: string;

    // @Column({ type: 'char', length: 36, name: 'CAMPAIGN_ID', nullable: true })
    @getColumnType({ name: 'CAMPAIGN_ID', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, nullable: true, default: null })
    campaignId!: string;

    // @Column({ name: 'DATA', type: 'text' })
    @getColumnType({ name: 'DATA', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    data!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
