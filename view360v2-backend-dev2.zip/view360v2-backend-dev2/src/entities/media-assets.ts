import {
    Entity,
    CreateDateColumn,
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';

@Entity("media_assets")
export class MediaAssets  {
    
    @getType()
    id!: string;
    
    @getColumnType({ name: 'FILE_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true })
    fileName!: string;

    @getColumnType({ name: 'FILE_PATH', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true })
    filePath!: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'varchar', type: 'char', length: 36, nullable: true })
    createdBy: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
