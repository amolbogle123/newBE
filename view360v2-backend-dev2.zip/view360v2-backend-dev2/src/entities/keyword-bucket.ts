import { CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { getColumnType } from '../services/db.service';

@Entity('keyword_bucket')
export class KeywordBucket {
    @PrimaryGeneratedColumn('uuid')
    id!: number;

    @getColumnType({ name: 'CLIENT_ID', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    clientId!: number;
    
    @getColumnType({ name: 'KEYWORD_BUCKET_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    keywordBucketName!: string;
    
    @getColumnType({ name: 'KEYWORD_BUCKET_DESCRIPTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    keywordBucketDescription!: string;
    
    @getColumnType({ name: 'KEYWORDS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    keywords!: string;
    
    // @getColumnType({ name: 'RECIPIENTS', mongoType: 'string', postgresType: 'varchar', type: 'varchar', })
    // recipients!: string;

    @getColumnType({ name: 'IS_ACTIVE', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 1 })
    isActive!: number;

    @getColumnType({ name: 'IS_DELETED', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    isDeleted!: number;

    @CreateDateColumn({ name: 'CREATED_ON', type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
    createdOn: string;

    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    @CreateDateColumn({ name: 'UPDATED_ON', type: 'timestamp', default: '', onUpdate: "CURRENT_TIMESTAMP(6)" })
    updatedOn: string;

    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, default: '' })
    updatedBy!: string;
}
