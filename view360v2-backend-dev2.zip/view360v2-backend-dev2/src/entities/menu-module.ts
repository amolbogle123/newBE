import { Entity, Index } from "typeorm";

import { getColumnType, getType } from "../services/db.service";

@Entity("client_menu_module")
export class MenuModule  {
    // @PrimaryGeneratedColumn("increment", { name: "ID" })
    @getType()
    id!: string;

    @Index()
    @getColumnType({ mongoType: "number", type: "int", name: "CLIENT_ID" })
    clientId !: number;
    
    // @Column({ name: "NAME", type: "string" })
    @getColumnType({ mongoType: "string", type: "varchar", name: "NAME" })
    name!: string;

    @getColumnType({ mongoType: "string", type: "varchar", name: "TYPE", default: 'featureModule' })
    type!: string;

    @getColumnType({ mongoType: "string", type: "varchar", name: "MODULE_NAME", nullable: true })
    moduleName!: string;

    @getColumnType({ mongoType: "string", type: "varchar", name: "CONFIG", nullable: true })
    config!: string;

    // @Column({ name: "URL", type: "string" })
    @getColumnType({ mongoType: "string", type: "varchar", name: "URL", nullable: true })
    url!: string;

    // @Column({ name: "IS_ACTIVE", type: "number" })
    @getColumnType({ mongoType: "number", type: "int", name: "IS_ACTIVE" })
    isActive!: number;
}
