
import {
    CreateDateColumn,
    Entity,
    Index
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';
 
@Entity("dms-files-logs")
export class DMSFilesLogs  {
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    CLIENT_ID!: number;

    @Index({ fulltext: true })
    @getColumnType({ name: 'FILE_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    FILE_NAME!: string;

    @Index({ fulltext: true })
    @getColumnType({ name: 'FILE_PATH', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    FILE_PATH!: string;

    @getColumnType({ name: 'ACTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    ACTION!: string;

    @CreateDateColumn({ name: 'ACTION_DATE', type: 'timestamp' })
    ACTION_DATE!: Date;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    CREATED_ON!: Date;
}
