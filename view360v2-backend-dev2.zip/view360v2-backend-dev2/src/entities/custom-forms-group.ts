import {
    Entity,
    CreateDateColumn,
    JoinColumn,
    OneToMany,
    Index
} from 'typeorm'
import { getColumnType, getType } from '../services/db.service';
import { CustomForms } from "./custom-forms";


@Entity('custom_forms_group')
export class CustomFormsGroup  {

    // @PrimaryGeneratedColumn("uuid", { name: "ID"})
    @getType()
    id!: string;

    // @Column({ type: 'number', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId!: number;

    // @Column({ type: 'string', length: 50, name: 'SHORT_NAME' })
    @getColumnType({ name: 'SHORT_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 50, isLengthRequired: true })
    shortName!: string;

    // @Column({ type: 'string', length: 255, name: 'NAME' })
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true })
    name!: string;

    // @Column({ type: 'string', length: 255, name: 'PROJECT_MANAGER' })
    @getColumnType({ name: 'PROJECT_MANAGER', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true })
    projectManager!: string;

    // @Column({ type: 'string', name: 'MAPPED_USER' })
    @getColumnType({ name: 'MAPPED_USER', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    mappedUser!: string;

    // @Column({ type: 'string', length: 255, name: 'DESCRIPTION' })
    @getColumnType({ name: 'DESCRIPTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255 })
    description!: string;

    // @Column({ type: 'number', name: 'STATUS', default: 1 })
    @getColumnType({ name: 'STATUS', mongoType: 'number', postgresType: 'smallint', type: 'tinyint', default: 1 })
    status!: number;

    // @Column({ type: 'string', length: 36, name: 'APP_ID' })
    @getColumnType({ name: 'APP_ID', mongoType: 'string', postgresType: 'char', type: 'char', default: 1, length: 36, })
    appId!: number;

    @getColumnType({ name: 'USERNAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true })
    username!: string;

    // @Column({ type: 'string', length: 36, name: 'CREATED_BY' })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36, isLengthRequired: true })
    createdBy!: number

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    @OneToMany(() => CustomForms, (cF: CustomForms) => cF.docGroup, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'DOC_ID' })
    docs!: CustomForms[];
}
