import {
    Entity,
    CreateDateColumn,JoinColumn, ManyToOne, Index
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';
import { UserRoles } from "../entities";

@Entity("role_invites")
export class RoleInvites  {
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    clientId!: number;

    @getColumnType({ name: 'EMAIL', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    email!: string;

    @getColumnType({ name: 'ROLE_ID', mongoType: 'string', postgresType: 'char', type: 'char', nullable: true })
    roleId!: string;

    @getColumnType({ name: 'EMAIL_TEMPLATE_ID', mongoType: 'string', postgresType: 'char', type: 'char', nullable: true, length: 36, isLengthRequired: true })
    emailTemplateId!: string;

    @getColumnType({ name: 'STATUS', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    status!: string;

    @getColumnType({ name: 'EMAIL_VERIFY_CODE', mongoType: 'string', postgresType: 'text', type: 'text', nullable: true })
    code!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    @CreateDateColumn({ name: 'UPDATED_ON', type: 'timestamp' })
    updatedOn!: Date;



    @ManyToOne(() => UserRoles)
    @JoinColumn({ name: 'ROLE_ID' })
    role: UserRoles;
}
