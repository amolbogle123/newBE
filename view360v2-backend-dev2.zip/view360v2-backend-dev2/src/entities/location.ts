import { Entity, CreateDateColumn, Index } from 'typeorm';
import { getColumnType, getType } from '../services/db.service';

@Entity('location')
export class Location  {

    // @PrimaryGeneratedColumn('increment', {name:'ID'})
    @getType('increment')
    id!: string;

    // @Column({ name: 'CLIENT_ID', type: 'number', nullable: true })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    clientId!: number;

    // @Column({ name: 'NAME', type: 'string', nullable: true })
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', nullable: true })
    name!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;
}
