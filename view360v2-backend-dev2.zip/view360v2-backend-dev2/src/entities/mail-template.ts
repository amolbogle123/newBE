import { Entity, CreateDateColumn, Index } from 'typeorm'
import { getColumnType, getType } from '../services/db.service';

@Entity('mail_template')
export class MailTemplate {

    // @PrimaryGeneratedColumn("uuid", {name: 'ID'})
    @getType()
    id!: string;

    // @Column({ type: 'int', name: 'CLIENT_ID' })
    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', })
    clientId!: number;

    // @Column({ type: 'varchar', length: 255, name: 'NAME' })
    @getColumnType({ name: 'NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, isLengthRequired: true })
    name!: string;

    // @Column({ type: 'varchar', length: 500, name: 'SUBJECT' })
    @getColumnType({ name: 'SUBJECT', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 500, isLengthRequired: true })
    subject!: string;

    // @Column({ name: 'BODY', type: 'text' })
    @getColumnType({ name: 'BODY', mongoType: 'string', postgresType: 'text', type: 'longtext', })
    body!: string;

    // @Column({ name: 'CREATED_BY', type: 'char', length: 36 })
    @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    createdBy!: string;

    // @Column({ name: 'UPDATED_BY', type: 'char', length: 36 })
    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    updatedBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    // @Column({ name: 'FORM_MAP_KEY', type: 'longtext', nullable: true })
    @getColumnType({ name: 'FORM_MAP_KEY', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true })
    formMapKey!: string;

    // @Column({ name: 'MAIL_CONFIG', type: 'longtext', nullable: true })
    @getColumnType({ name: 'MAIL_CONFIG', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true })
    mailConfig!: string;
}
