import {
    CreateDateColumn,
    Entity,
    Index
} from "typeorm";

import { getColumnType, getType } from '../services/db.service';
 
@Entity("dms-indexed-files")
export class DMSIndexedFiles  {
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'CLIENT_ID', mongoType: 'number', postgresType: 'int', type: 'int', nullable: true })
    clientId!: number;

    @getColumnType({ name: 'FILE_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    fileName!: string;

    @getColumnType({ name: 'PAGE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    page!: string;

    @getColumnType({ name: 'DATA', mongoType: 'string', postgresType: 'text', type: 'longtext', nullable: true, isLengthRequired: true })
    data!: string;

    @getColumnType({ name: 'FILE_TYPE', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    fileType!: string;

    @getColumnType({ name: 'ACTION', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255, nullable: true, isLengthRequired: true })
    action!: string;

    @CreateDateColumn({ name: 'ACTION_DATE', type: 'timestamp' })
    actionDate!: Date;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    @CreateDateColumn({ name: 'UPDATED_ON', type: 'timestamp' })
    updatedOn!: Date;
}
