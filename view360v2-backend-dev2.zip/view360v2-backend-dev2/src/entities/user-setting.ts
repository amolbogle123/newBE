import {
    Entity,
    CreateDateColumn,
    UpdateDateColumn, ManyToOne, JoinColumn, Index
} from 'typeorm';
import { getColumnType, getType } from '../services/db.service';
import { Users } from './users';

@Entity('user_setting')
export class UserSetting  {
    @getType()
    id!: string;

    @Index()
    @getColumnType({ name: 'USER_ID', mongoType: 'string', postgresType: 'text', type: 'text' })
    userId!: string;

    @getColumnType({ name: 'SETTING_NAME', mongoType: 'string', postgresType: 'varchar', type: 'varchar', length: 255 })
    settingName!: string;

    @getColumnType({ name: 'SETTING_VALUE', mongoType: 'string', postgresType: 'text', type: 'text' })
    settingValue!: string;

    @getColumnType({ name: 'IS_DELETED', mongoType: 'number', postgresType: 'smallint', type: 'smallint', default: 0 })
    isDeleted!: number;

     @getColumnType({ name: 'CREATED_BY', mongoType: 'string', postgresType: 'text', type: 'text'})
    createdBy!: string;

    @CreateDateColumn({ name: 'CREATED_ON', type: 'timestamp' })
    createdOn!: Date;

    @getColumnType({ name: 'UPDATED_BY', mongoType: 'string', postgresType: 'char', type: 'char', length: 36 })
    updatedBy!: string;

    @UpdateDateColumn({ name: 'UPDATED_ON', type: 'timestamp' })
    updatedOn!: Date;

    @ManyToOne(() => Users)
    @JoinColumn({ name: 'USER_ID' })
    user: Users;
}