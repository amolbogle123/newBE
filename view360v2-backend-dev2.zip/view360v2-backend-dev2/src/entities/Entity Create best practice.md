## Entity create best practice

### Entity Definition

Entities in TypeORM are classes decorated with @Entity(), which map the class to a database table. The class's properties are treated as columns in the corresponding table.

* @Entity('table_name'): This decorator marks the class as an entity and associates it with the table name specified.

### Primary Column
Each entity should have a primary key, which uniquely identifies each row. In this example, id is the primary key, and it uses a custom @getType() decorator.

* @PrimaryGeneratedColumn(): Typically, this decorator generates the primary key (UUID or auto-incremented integer). Here, @getType() is used for custom type management across different databases.

### Column Definitions
Columns in the entity represent fields in the database table. Use the @Column() decorator (or custom @getColumnType()) to define column types and properties.

* @Column(): Defines a basic column. Use the name, type, length, and nullable options to specify the column's behavior in the database.

* Custom Decorators: @getColumnType() is a custom decorator used in the example for handling multiple database types (e.g., MongoDB, PostgreSQL) dynamically.

#### Column Options

* name: The name of the column in the database.
* type: The data type (e.g., varchar, text, smallint, etc.).
* length: Maximum length for string-type fields.
* nullable: Specifies if the column can be null.
* default: Sets a default value for the column.

### Relations
TypeORM supports defining relationships between entities.

* @ManyToOne(): This defines a many-to-one relationship between two entities. Here, DashboardWidget is associated with WidgetAccount. You can specify options like cascade and onDelete.

* @JoinColumn(): Specifies which column in the current entity (in this case, WIDGET_ACCOUNT) acts as the foreign key for the relationship.

#### Cascade and Deletion Options

* cascade: Determines whether operations like insert, update, or delete are cascaded to related entities.
* onDelete: Specifies behavior when the related entity is deleted. For example, onDelete: 'SET NULL' will set the foreign key to NULL if the related entity is deleted.

### CreateDateColumn
The @CreateDateColumn() decorator is used for columns that store the creation timestamp. This column is automatically set by TypeORM when an entity is created.

* @CreateDateColumn(): Automatically sets the timestamp of when the entity was created. No need to manually assign values to this column.

### Custom Column Handling for Multiple Databases
A custom decorator @getColumnType() is used to handle different databases dynamically (e.g., MongoDB, PostgreSQL). This approach allows flexibility when using multiple database types in a project.

This ensures that TypeORM dynamically picks the correct column type based on the database being used.

### Default Values
You can define default values for columns using the default option.

* default: 0: This sets the default value for the IS_CONFIGURED column to 0.


### Index
* The @Index() decorator is used to optimize query performance for this field.
