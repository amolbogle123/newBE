import {Client} from "@hubspot/api-client";
import {TokenResponseIF} from "@hubspot/api-client/lib/codegen/oauth";

const OBJECTS_LIMIT = 10;
const hubspotClient = new Client();
const SCOPES = 'crm.objects.contacts.read crm.objects.companies.read crm.objects.deals.read settings.users.read';
const REDIRECT_URI = `${process.env.VIEW360v2FE_URL}/hubspot/oauth`;
const GRANT_TYPES = {
    AUTHORIZATION_CODE: 'authorization_code',
    REFRESH_TOKEN: 'refresh_token',
};

export default class HubSpot {
    static async getCurrentUser(): Promise<{ id: string, email: string }> {
        return hubspotClient.settings.users.usersApi.getPage()
            .then(({ results }) => results[0]);
    }

    static setToken(accessToken: string | null): void {
        hubspotClient.setAccessToken(accessToken);
    }

    static getAuthorizationUrl(state?: string): string {
        return hubspotClient.oauth.getAuthorizationUrl(
            process.env.HUBSPOT_CLIENT_ID,
            REDIRECT_URI,
            SCOPES,
            null,
            state,
        );
    }

    private static augmentAndUseTokens(tokens: TokenResponseIF): HubSpotTokens {
        HubSpot.setToken(tokens.accessToken);

        return ({
            ...tokens,
            updatedAt: Date.now(),
        });
    }

    static isTokenExpired(tokens: HubSpotTokens): boolean {
        return Date.now() >= tokens.updatedAt + tokens.expiresIn * 1000;
    }

    static authorize(code: string): Promise<HubSpotTokens> {
        return hubspotClient.oauth.tokensApi.create(
            GRANT_TYPES.AUTHORIZATION_CODE,
            code,
            REDIRECT_URI,
            process.env.HUBSPOT_CLIENT_ID,
            process.env.HUBSPOT_CLIENT_SECRET,
        ).then(HubSpot.augmentAndUseTokens);
    }

    static refreshToken(tokens: HubSpotTokens): Promise<HubSpotTokens> {
        return hubspotClient.oauth.tokensApi.create(
            GRANT_TYPES.REFRESH_TOKEN,
            undefined,
            undefined,
            process.env.HUBSPOT_CLIENT_ID,
            process.env.HUBSPOT_CLIENT_SECRET,
            tokens.refreshToken
        ).then(HubSpot.augmentAndUseTokens);
    }

    static async getContacts(): Promise<Contact[]> {
        const contacts = await hubspotClient.crm.contacts.basicApi.getPage(OBJECTS_LIMIT);

        return contacts.results.map(({ properties }) => ({
            firstName: properties.firstname || "",
            lastName: properties.lastname || "",
            email: properties.email || "",
            phone: properties.phone || "",
            company: properties.company || "",
            website: properties.website || "",
            lifecycleStage: properties.lifecyclestage || "",
            hubspotId: properties.hs_object_id,
        }));
    }

    static async getCompanies(): Promise<Company[]> {
        const companies = await hubspotClient.crm.companies.basicApi.getPage(OBJECTS_LIMIT);

        return companies.results.map(({ properties }) => ({
            name: properties.name || "",
            domain: properties.domain || "",
            phone: properties.phone || "",
            industry: properties.industry || "",
            city: properties.city || "",
            state: properties.state || "",
            lifecycleStage: properties.lifecyclestage || "",
            hubspotId: properties.hs_object_id,
        }));
    }

    static async getDeals(): Promise<Deal[]> {
        const deals = await hubspotClient.crm.deals.basicApi.getPage(OBJECTS_LIMIT);

        return deals.results.map(({ properties }) => ({
            dealName: properties.dealname || "",
            createDate: properties.createdate,
            closeDate: properties.closedate || "",
            dealStage: properties.dealstage || "",
            amount: properties.amount || "",
            hubspotId: properties.hs_object_id,
        }));
    }
}

export type HubSpotTokens = {
    accessToken: string;
    refreshToken: string;
    updatedAt: number;
    expiresIn: number;
}

export type Contact = {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    company: string;
    website: string;
    lifecycleStage: string;
    hubspotId: string;
};

export type Company = {
    name: string;
    domain: string;
    phone: string;
    industry: string;
    city: string;
    state: string;
    lifecycleStage: string;
    hubspotId: string;
};

export type Deal = {
    dealName: string;
    createDate: string;
    closeDate: string;
    dealStage: string;
    amount: string;
    hubspotId: string;
};
