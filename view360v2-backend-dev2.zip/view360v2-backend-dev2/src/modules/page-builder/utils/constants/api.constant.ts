

export const ERROR_UNKNOWN: string = 'unknown error.';


export const PAGE_TEMPLATE_NO_FOUND: string = 'Operation has been successfully executed.'; 
export const PAGE_TEMPLATE_SAVED: string = 'Page Builder template created successfully.'; 
export const PAGE_TEMPLATE_UPDATED: string = 'Page Builder template updated successfully.'; 
export const PAGE_TEMPLATE_DELETED: string = 'Page Builder template deleted successfully.'; 
export const PAGE_TEMPLATE_NO_DATA: string = 'Couldn\'t processed, page template data not available.'; 