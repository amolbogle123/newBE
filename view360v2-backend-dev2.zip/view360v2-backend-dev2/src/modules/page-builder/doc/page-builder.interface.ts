export interface AddPageBuilderRequestBody {
    title: string;
    message: string;
    bodyStyle: string;
    config: string;
    extraConfig:string;
    isPublish: number;
    layout: "fullLayout" | "mainLayout"  | "designLayout";
}

export interface UpdatePageBuilderRequestBody {
    title: string;
    message: string;
    bodyStyle: string;
    config: string;
    extraConfig: string;
    isPublish: number;
    layout: "fullLayout" | "mainLayout" | "designLayout";
}

export interface PageBuilderMessageResponse {
    message: string;
}

export interface PageBuilderApiErrorResponse {
    status: boolean;
    message: string;
    error: {
        error_description: string;
    };
}
