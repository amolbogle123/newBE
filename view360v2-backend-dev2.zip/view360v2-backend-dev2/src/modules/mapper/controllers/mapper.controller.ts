import { ApiErrorResponse, CommonHelper } from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import * as crypto from "crypto";
import { FormMapper, CustomForms } from "../../../entities";
import { dataSource } from "../../../core/data-source";
import { DocumentService } from "../../documents/services/document.service";
import { FormBuilderService } from "../../form-builder/services/form-builder.service";
import Container from 'typedi';
import {DataSource} from 'typeorm';
import { Body, Controller, Get, Post, Query, Request, Route, Security, Tags, Path, Put, Delete, Hidden } from "tsoa";
import { GetMapperListRequest, InsertMapperRequest, UpdateMapperRequest, DeleteMapper, MapperListResponse, AllMapperListResponse, SaveMapperResponse, MapperDetailsResponse, UpdateMapperResponse, DeleteMapperResponse } from "../doc/mapper-interface";
import { CommonUtil } from "utils/common.util";

@Route('')
@Tags('Pdf/Excel Mappers')
export class MapperController extends Controller {

    // Services
    private documentService: DocumentService = new DocumentService();
    private formBuilderService: FormBuilderService = new FormBuilderService();

    @Security('bearerAuth')
    @Post('mapper/list')
    @Hidden()
    async mapperList(
        @Body() requestBody: GetMapperListRequest,
        @Request() request: any,
        @Query('page') page: number = 1,
        @Query('pageSize') pageSize: number = 10,
        @Query('sortOrder') sortOrder?: number,
        @Query('sortField') sortField?: string,
        @Query('filters') filters?: string
    ) : Promise<MapperListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };
            const selectedFields: any = [
                "id",
                "clientId",
                "formId",
                "config",
                "createdOn",
            ];
            let whereCondition = { clientId: request.userDetails.client_id };
            if (requestBody.type) {
                whereCondition['type'] = requestBody.type;
            }
            const totalRecordCount = await Container.get(DataSource)
            .getRepository(FormMapper)
            .count({where:whereCondition});
            whereCondition = await CommonUtil.applyFilter(filters, whereCondition);

            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject['id'] = sortOrder;
            }

           

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(FormMapper),
                {
                    where: whereCondition,
                    select: selectedFields,
                    relations: ["form"],
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );

            if (results?.length > 0) {
                apiResponse.data = results;
                apiResponse.recordsTotal = totalRecordCount;
                apiResponse.recordsFiltered = totalRecordCount;
    
                const totalPages = Math.ceil(totalRecordCount / pageSize);
                apiResponse.totalPages = totalPages;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('mapper')
    async getAllMapper(
        @Query() type: 'pdf'| 'excel',
        @Request() request: any
    ) : Promise<AllMapperListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };
            const selectedFields: any = ["id", "columnHeader", "formId"];
            let whereCondition = { clientId: request.userDetails.client_id };
            if (type) {
                whereCondition['type'] = type;
            }
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(FormMapper),
                {
                    where: whereCondition,
                    select: selectedFields,
                }
            );

            if (results?.length) {
                apiResponse.data = results;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('mapper')
    @Hidden()
    async saveMapper(
        @Body() requestBody: InsertMapperRequest,
        @Request() request: any
    ) : Promise<SaveMapperResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };
            let mapperConfig = requestBody;

            if (mapperConfig?.formDetails) {
                const insertDoc = {
                    clientId: request.userDetails.client_id,
                    name: requestBody.formDetails.name,
                    shortName: "EM",
                    projectManager: "",
                    description: "EM",
                    mappedUser: "[]",
                    createdBy: request.userDetails.id,
                    status: 2,
                    username: request.userDetails.username,
                };

                const docSavedResponse: any =
                    await this.documentService.saveFormGroup(insertDoc);
                if (docSavedResponse?.id) {
                    const dataInsert = {
                        clientId: request.userDetails.client_id,
                        docId: docSavedResponse.id,
                        formName: insertDoc.name,
                        formDescription: insertDoc.description,
                        isTimerBased: 0,
                        isShowDashboard: 0,
                        formData: JSON.stringify(requestBody.formDetails.data),
                        isVersionControl: 0,
                        isCommanable: 0,
                        isAssignment: 0,
                        assignedUser: null,
                        isApproval: 0,
                        approvalData: "[]",
                        approvalSetting: "",
                        formDataConfig: JSON.stringify(
                            requestBody.formDetails.formFields
                        ),
                        createdBy: request.userDetails.id,
                        formControls: "",
                        statusBoxes: "",
                        permissionConfig: "",
                        mappedUser: "",
                        formType: "",
                        referenceId: crypto.randomBytes(4).toString('hex').toUpperCase()
                    } as unknown as CustomForms;

                    const formSaveResponse: any =
                        await this.formBuilderService.saveCustomForms(
                            dataInsert
                        );
                    if (formSaveResponse?.id) {
                        mapperConfig["formId"] = formSaveResponse.id;
                    }
                }
            }

            if (mapperConfig?.formId) {
                const FormMapperModel = new FormMapper();
                FormMapperModel.clientId = request.userDetails.client_id;
                FormMapperModel.formId = mapperConfig.formId;
                FormMapperModel.fileConfig = JSON.stringify(mapperConfig.fileConfig);
                FormMapperModel.type = mapperConfig.type || 'excel';
                FormMapperModel.config = JSON.stringify(
                    mapperConfig.config
                );
                FormMapperModel.columnHeader = mapperConfig.columnHeader;
                FormMapperModel.createdBy = request.userDetails.id;
                
                const result = await Container.get(DataSource).manager.save(
                    FormMapperModel
                );
                if (result?.id) {
                    apiResponse.data = { insertedId: result.id };
                    this.setStatus(201);
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('mapper/:id')
    async getMapper(
        @Path() id: string,
        @Request() request: any
    ) : Promise<MapperDetailsResponse | unknown> {
        try {
            const apiResponse = {
                data: null,
            };
            let result: any = await dataSource
                .getRepository(FormMapper)
                .findOne({
                    where: {
                        id: request.params.id,
                        clientId: request.userDetails.client_id,
                    },
                    relations: ["form"],
                });
            apiResponse.data = result;

            if (apiResponse.data) {
                if (apiResponse.data["config"]) {
                    apiResponse.data["config"] = JSON.parse(
                        apiResponse.data["config"]
                    );
                } else {
                    apiResponse.data["config"] = {};
                }
                if (apiResponse.data["fileConfig"]) {
                    apiResponse.data["fileConfig"] = JSON.parse(
                        apiResponse.data["fileConfig"]
                    );
                } else {
                    apiResponse.data["fileConfig"] = {};
                }
            } else {
                this.setStatus(204);
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Put('mapper/:id')
    @Hidden()
    async updateMapper(
        @Path() id: string,
        @Body() requestBody: UpdateMapperRequest,
        @Request() request: any
    ) : Promise<UpdateMapperResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };
            let mapperConfig = request.body;

            if (mapperConfig?.formDetails) {
                const insertDoc = {
                    clientId: request.userDetails.client_id,
                    name: requestBody.formDetails.name,
                    shortName: "EM",
                    projectManager: "",
                    description: "EM",
                    mappedUser: "[]",
                    createdBy: request.userDetails.id,
                    status: 2,
                    username: request.userDetails.username,
                };

                const docSavedResponse: any =
                    await this.documentService.saveFormGroup(insertDoc);
                if (docSavedResponse?.id) {
                    const dataInsert = {
                        clientId: request.userDetails.client_id,
                        docId: docSavedResponse.id,
                        formName: insertDoc.name,
                        formDescription: insertDoc.description,
                        isTimerBased: 0,
                        isShowDashboard: 0,
                        formData: JSON.stringify(requestBody.formDetails.data),
                        isVersionControl: 0,
                        isCommanable: 0,
                        isAssignment: 0,
                        assignedUser: null,
                        isApproval: 0,
                        approvalData: "[]",
                        approvalSetting: "",
                        formDataConfig: JSON.stringify(
                            requestBody.formDetails.formFields
                        ),
                        createdBy: request.userDetails.id,
                        formControls: "",
                        statusBoxes: "",
                        permissionConfig: "",
                        mappedUser: "",
                        formType: "",
                    } as unknown as CustomForms;

                    const formSaveResponse: any =
                        await this.formBuilderService.saveCustomForms(
                            dataInsert
                        );
                    if (formSaveResponse?.id) {
                        mapperConfig["formId"] = formSaveResponse.id;
                    }
                }
            }

            if (mapperConfig?.formId) {
                const payload = {
                    formId: mapperConfig.formId,
                    config: JSON.stringify(mapperConfig.config),
                    columnHeader: mapperConfig.columnHeader,
                };

                const updateResult = await dataSource
                    .getRepository(FormMapper)
                    .update({ id: request.params.id }, payload);
                apiResponse.data = updateResult;
                
                if (!updateResult?.affected) {
                    this.setStatus(204);
                } else {
                    this.setStatus(200);
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Delete('mapper')
    async deleteMapper(
        @Body() requestBody: DeleteMapper,
        @Request() request: any
    ) : Promise<DeleteMapperResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            const widgetResult = await dataSource
                .getRepository(FormMapper)
                .delete(requestBody.id);
            apiResponse.data = widgetResult;

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
