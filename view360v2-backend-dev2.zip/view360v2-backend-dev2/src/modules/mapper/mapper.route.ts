import { AppRoutes } from "../../app.routes";
import { MapperController } from "./controllers/mapper.controller";



export class MapperRoutes extends AppRoutes {
    private mapperController: MapperController;

    constructor() {
        super();
        this.mapperController = new MapperController();

        this.initRoutes();
    }


    initRoutes() {
        /*
        // Excel Mapper
         * this.router.post('/form-builder/excel-mapper-list', (req, res, next) => this.excelMapperController.excelMapperList(req, res, next).catch(next));
         * this.router.get('/form-builder/get-all-excel-mapper', (req, res, next) => this.excelMapperController.getAllExcelMapper(req, res, next).catch(next));
         * this.router.post('/form-builder/save-excel-mapper', (req, res, next) => this.excelMapperController.saveExcelMapper(req, res, next).catch(next));
         * this.router.get('/form-builder/get-excel-mapper/:id', (req, res, next) => this.excelMapperController.getExcelMapper(req, res, next).catch(next));
         * this.router.post('/form-builder/update-excel-mapper/:id', (req, res, next) => this.excelMapperController.updateExcelMapper(req, res, next).catch(next));
         * this.router.post('/form-builder/delete-excel-mapper', (req, res, next) => this.excelMapperController.deleteExcelMapper(req, res, next).catch(next));
         */
    }

}
