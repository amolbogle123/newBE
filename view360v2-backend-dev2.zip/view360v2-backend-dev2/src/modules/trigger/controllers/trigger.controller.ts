import {
    Post,
    Request,
    Route,
    Security,
    Tags,
    Controller,
    Body,
    Get,
    Middlewares,
    Put,
    Path,
    Delete,
    Hidden,
} from "tsoa";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import { WidgetTriggers } from "entities/triggers";
import { ProcessStatus } from "../../../modules/process-builder/models";
import { DataSource } from "typeorm";
import Container from "typedi";
import { ProcessBuilderHelper } from "../../process-builder/utils/helpers/process-builder.helper";
import {
    commonMiddleware,
    validateEntryCount,
} from "../../../middlewares/common.middleware";
import { ProcessCronService } from "../../process-builder/services/process-cron.service";
import { ApiMethod } from "../../process-builder/models";
import { CronHelper } from "utils/helpers/cron.helper";
import { ConnectorsUtil } from "utils/connectors.util";
import { GoogleController } from "../../dynamic-dashboard/controllers/execution/google.controller";
import { GoogleAdwordsController } from "../../dynamic-dashboard/controllers/execution/google-adwords.controller";
import dbService from "services/db.service";
import { DashboardWidget } from "entities";
import lodash from "lodash";

@Route("trigger")
@Tags("Trigger ")
export class TriggerController extends Controller {
    private processCronService: ProcessCronService = new ProcessCronService();
    private googleAnalyticsService: any = new GoogleController();
    private googleAdwordsService: any = new GoogleAdwordsController();
    private processBuilderHelper: ProcessBuilderHelper =
        new ProcessBuilderHelper();

    @Security("bearerAuth")
    @Get("/")
    @Middlewares(commonMiddleware)
    @Middlewares(validateEntryCount)
    async getAllTrigger(@Request() request: any): Promise<any> {
        try {
            let client_id = request.userDetails.client_id;
            const apiResult = { status: false, data: null };
            let results;
            results = await Container.get(DataSource)
                .getRepository(WidgetTriggers)
                .createQueryBuilder("DT")
                .leftJoinAndSelect(DashboardWidget, "DW", "DW.id = DT.widgetId")
                .where("DT.clientId = :client_id", { client_id: [client_id] })
                .execute();
            if (results && Array.isArray(results) && results.length > 0) {
                apiResult.data = results;
                apiResult.status = true;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResult);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: error.message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Post("/")
    @Middlewares(commonMiddleware)
    @Middlewares(validateEntryCount)
    async addTrigger(
        @Body() requestBody: any,
        @Request() req: any
    ): Promise<any> {
        try {
            const triggersModel = new WidgetTriggers();
            triggersModel.clientId = req.userDetails.client_id;
            triggersModel.dashboard = requestBody.dashboardId;
            triggersModel.widgetId = requestBody.widgetId;
            triggersModel.name = requestBody.pulseTitle;
            triggersModel.config = requestBody.pulseConfig
                ? JSON.stringify(requestBody.pulseConfig)
                : null;
            triggersModel.createdBy = req.userDetails.id;

            const result = await Container.get(DataSource).manager.save(
                triggersModel
            );
            if (result) {
                await this.addProcessCron(requestBody, result, req.userDetails);
            }
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Trigger",
                data: result,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Put("/:triggerId")
    @Middlewares(commonMiddleware)
    @Middlewares(validateEntryCount)
    async editTrigger(
        @Path() triggerId: string,
        @Body() requestBody: any,
        @Request() req: any
    ): Promise<any> {
        try {
            let updateData = {
                clientId: req.userDetails.client_id,
                dashboard: requestBody.dashboardId,
                widgetId: requestBody.widgetId,
                name: requestBody.pulseTitle,
                config: requestBody.pulseConfig
                    ? JSON.stringify(requestBody.pulseConfig)
                    : null,
                createdBy: req.userDetails.id,
            };
            const result = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(WidgetTriggers),
                {
                    paramsObj: {
                        id: triggerId,
                        clientId: req.userDetails.client_id,
                    },
                    ...updateData,
                }
            );
            if (result) {
                await this.addProcessCron(
                    requestBody,
                    { id: triggerId },
                    req.userDetails
                );
            }
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: null,
                data: result,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("/")
    @Middlewares(commonMiddleware)
    @Middlewares(validateEntryCount)
    async deleteTriggers(@Body() requestBody: any): Promise<any> {
        try {
            const triggerDelete = await dbService._deleteQueryService(
                Container.get(DataSource).getRepository(WidgetTriggers),
                { id: requestBody.id }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                data: triggerDelete,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Hidden()
    @Get("/:id")
    async getTemplate(@Request() request: any): Promise<any> {
        console.log(request.params.id, "request.params.id");
        try {
            const triggerData: WidgetTriggers[] =
                await dbService._findOneQueryService(
                    Container.get(DataSource).getRepository(WidgetTriggers),
                    {
                        where: {
                            id: request.params.id,
                            clientId: request.userDetails.client_id,
                        },
                    }
                );
            return CommonHelper.apiSwaggerSuccessResponse({
                message: null,
                data: triggerData,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("/check-trigger")
    async checkTrigger(
        @Body() requestBody: any,
        @Request() req: any
    ): Promise<any> {
        try {
            const response = { status: true, data: null, message: "" };
            let query = `SELECT dp.ID,dp.CLIENT_ID,dp.NAME,dp.CONFIG PULSE_CONFIG,dp.WIDGET_ID,dw.WIDGET_ACCOUNT,
            dw.TYPE WIDGET_TYPE,dw.WIDGET_CONFIG FROM widget_trigger dp LEFT JOIN dashboard_widget dw ON (dw.id = dp.widget_id) WHERE dp.id = '${requestBody.triggerId}'`;
            const results = await Container.get(DataSource).manager.query(
                query
            );
            
            if (results && results?.length > 0) {
                let pulse = results[0];
                const pulseConfig = pulse.PULSE_CONFIG
                    ? JSON.parse(pulse.PULSE_CONFIG)
                    : null;
                const widgetConfig = pulse.WIDGET_CONFIG
                    ? JSON.parse(pulse.WIDGET_CONFIG)
                    : null;
                if (
                    pulseConfig &&
                    pulseConfig.workflow &&
                    pulseConfig.field &&
                    pulseConfig.operationValue
                ) {
                    let compareResult = false;
                    response.data = {
                        field: pulseConfig.field,
                        operation: pulseConfig.operation,
                        operationValue: pulseConfig.operationValue,
                        workflow: pulseConfig.workflow,
                    };
                    if (widgetConfig) {
                        if (
                            pulse.WIDGET_TYPE === "SQL" &&
                            widgetConfig.sqlQuery &&
                            pulse.WIDGET_ACCOUNT
                        ) {
                            const connectorData: any =
                                await ConnectorsUtil.connect(
                                    pulse.WIDGET_ACCOUNT.trim(),
                                    widgetConfig.sqlQuery,
                                    null
                                );

                            if (
                                connectorData.data &&
                                connectorData.data.length > 0
                            ) {
                                if (connectorData.data[0][pulseConfig.field]) {
                                    compareResult = await this.valueCompare(
                                        connectorData.data[0][
                                            pulseConfig.field
                                        ],
                                        pulseConfig.operation,
                                        pulseConfig.operationValue
                                    );
                                    response.data.fieldValue =
                                        connectorData.data[0][
                                            pulseConfig.field
                                        ];
                                    response.data.compareResult = compareResult;
                                }
                            }
                        } else if (
                            ["GOOGLE_ANALYTICS"].indexOf(pulse.WIDGET_TYPE) >=
                                0 &&
                            pulse.WIDGET_ACCOUNT
                        ) {
                            let payload = {
                                widgetType: "GOOGLE_ANALYTICS_SEARCH",
                                dateRange: [],
                            };
                            let reqparam = {
                                params: {
                                    widgetId: pulse.WIDGET_ID.trim(),
                                    drillDownLevel: 0,
                                },
                            };
                            const googleData =
                                await this.googleAnalyticsService.getGoogleDetails(
                                    reqparam,
                                    payload
                                );
                            if (
                                googleData &&
                                googleData?.data &&
                                googleData?.data?.data
                            ) {
                                let boxDataResult =
                                    googleData.data?.data?.totals[0].values[0];
                                compareResult = await this.valueCompare(
                                    boxDataResult,
                                    pulseConfig.operation,
                                    pulseConfig.operationValue
                                );
                            }
                        } else if (
                            ["GOOGLE_ADWORDS"].indexOf(pulse.WIDGET_TYPE) >=
                                0 &&
                            pulse.WIDGET_ACCOUNT
                        ) {
                            let payload = {
                                widgetType: "GOOGLE_ADWORDS_SEARCH",
                                dateRange: [],
                            };
                            let reqparam = {
                                params: {
                                    widgetId: pulse.WIDGET_ID.trim(),
                                    drillDownLevel: 0,
                                },
                            };
                            const googleAdwordsData =
                                await this.googleAdwordsService.getGoogleAdwordDetails(
                                    reqparam,
                                    payload
                                );
                            if (googleAdwordsData?.data?.summaryRow) {
                                let WIDGET_CONFIG = pulse.WIDGET_CONFIG
                                    ? JSON.parse(pulse.WIDGET_CONFIG)
                                    : {};
                                let boxDataResult =
                                    this.boxCompareConvertSutaibleFormatData(
                                        googleAdwordsData,
                                        WIDGET_CONFIG?.metric
                                    );
                                compareResult = await this.valueCompare(
                                    boxDataResult,
                                    pulseConfig.operation,
                                    pulseConfig.operationValue
                                );
                            }
                        }
                    }
                    if (compareResult) {
                        if (pulseConfig.workflow) {
                            await this.processBuilderHelper.execute(
                                pulse.CLIENT_ID,
                                null,
                                null,
                                pulse.ID,
                                response.data,
                                pulseConfig.workflow,
                                { type: ProcessStatus.MANUAL_TRIGGER }
                            );
                        }
                        response.message =
                            "Threshold match. workflow executed.";
                    } else {
                        response.message = "Threshold does not match.";
                    }
                } else {
                    response.message = `Pulse config problem. please check.`;
                }
            }
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: null,
                data: response,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    async addProcessCron(panelData, Response, userDetails) {
        return this.processCronService.addCron({
            hitApi: "check-trigger",
            hitMethod: ApiMethod.POST,
            cronType: "WIDGET_TRIGGER",
            refId: Response.id,
            createdBy: userDetails.id,
            client_id: userDetails.clientId,
            config: {
                apiBody: {
                    triggerId: Response.id,
                },
                scheduleOn: CronHelper.generateTime(
                    panelData?.pulseConfig?.timer
                ),
            },
            timezone: panelData?.pulseConfig?.timer?.timezone,
        });
    }
    async valueCompare(value1: any, conditionOf: any, value2: any) {
        if (typeof value1 === "string") {
            value1 = value1.toLowerCase();
        } else if (typeof value1 === "boolean") {
            value1 = value1.toString();
        } else if (!isNaN(value1)) {
            value1 = parseFloat(value1);
        }

        if (typeof value2 === "string") {
            value2 = value2.toLowerCase();
        } else if (typeof value2 === "boolean") {
            value2 = value2.toString();
        } else if (!isNaN(value2)) {
            value2 = parseFloat(value2);
        }

        switch (conditionOf) {
            case "equals":
                return value1 == value2;
            case "notequals":
                return value1 != value2;
            case "greaterthan":
                return value1 > value2;
            case "smallerthen":
                return value1 < value2;
            case "greaterequals":
                return value1 >= value2;
            case "smallerequals":
                return value1 <= value2;
            case "contains":
                return value1.includes(value2);
            case "startswith":
                return value1.startsWith(value2);
            case "endswith":
                return value1.endsWith(value2);
            default:
                return false;
        }
    }
    private boxCompareConvertSutaibleFormatData(resp: any, metrics) {
        if (metrics.includes("_")) {
            metrics = metrics.replace(/_([a-z])/g, (gValue) => {
                return gValue[1].toUpperCase();
            });
        }
        const microsMetrics = [
            "averagecost",
            "costperconversion",
            "averagecpc",
            "averagecpm",
            "costperallconversions",
        ];
        const percentMatrics = [
            "optimizationscore",
            "ctr",
            "activectr",
            "interactionrate",
        ];
        let totalVal = lodash.get(resp.data.summaryRow, metrics);

        const metricVal = metrics.replaceAll("metrics.", "").toLowerCase();
        if (
            metricVal.toLowerCase().includes("micros") ||
            microsMetrics.indexOf(metricVal.toLowerCase()) > -1
        ) {
            totalVal = totalVal / 1000000;
        }
        if (
            metricVal.toLowerCase().includes("optimizationscore") ||
            percentMatrics.indexOf(metricVal.toLowerCase()) > -1
        ) {
            totalVal = totalVal ? totalVal * 100 : "-";
        }
        return totalVal;
    }
}
