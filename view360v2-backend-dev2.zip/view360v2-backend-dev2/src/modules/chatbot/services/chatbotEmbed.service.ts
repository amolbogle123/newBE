
import { Chatbot } from "../../../entities";
import dbService from "../../../services/db.service";
import Container from "typedi";
import { DataSource } from "typeorm";

export class ChatbotEmbedService {
    async validateUser(apiKey, siteLocation): Promise<any> {
        return new Promise(async (resolve) => {
            try {
                let response: any = {};

                let whereCondition = { siteUrl: siteLocation, siteApiKey: apiKey };
                const chatbotResult = await dbService._findQueryService(
                    Container.get(DataSource).getRepository(Chatbot),
                    {
                        where: whereCondition,
                    }
                );
                if (chatbotResult?.length) {
                    response.id = chatbotResult[0].id;
                    response.clientId = chatbotResult[0].clientId;
                    response.documentId = chatbotResult[0].documentId;
                    response.config = chatbotResult[0].config;
                }
                resolve(response);
            } catch (error) {
                resolve(null);
            }
        });
    }
}
