import fs from "fs";
import { AppRoutes } from "../../app.routes";
import { ChatbotController } from "./controllers/chatbot.controller";
import { embedData } from "./utils/constants/embed.constant";

export class ChatbotRoutes extends AppRoutes {
    private chatbotController: ChatbotController;

    constructor() {
        super();
        this.chatbotController = new ChatbotController();
        
        this.initRoutes();
    }

    initRoutes() {
        const baseChatbotDir = "./public/chatbot/";
        if (!fs.existsSync(baseChatbotDir)) {
            fs.mkdirSync(baseChatbotDir);
        }

        this.createSuportFiles();
    }
 
    createSuportFiles() {
        if (!fs.existsSync("./public/chatbot/embed.js")) {
            fs.writeFileSync("./public/chatbot/embed.js", embedData.embedJsData);
        }
        if (!fs.existsSync("./public/chatbot/chatbot.css")) {
            fs.writeFileSync("./public/chatbot/chatbot.css", embedData.cssData);
        }
        if (!fs.existsSync("./public/chatbot/logo.png")) {
            fs.writeFileSync("./public/chatbot/logo.png", embedData.logoData, { encoding: "base64" });
        }
    }
}
