import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import { ChatbotEmbedService } from "../services/chatbotEmbed.service";
import { ChatbotHistory } from "../../../entities";
import Container from "typedi";
import { DataSource } from "typeorm";
import { Controller, Post, Request, Route, Tags, Body } from "tsoa";
import {
    BasicDetailsRequest,
    FetchDataRequest,
    StartConverstionRequest,
    FetchHistoryDataRequest,
    GetDetailsResponse,
} from "../doc/chatbot-embed-interface";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import fetch from "node-fetch";

@Route("embed-chatbot")
@Tags("Embed Chatbot")
export class ChatbotEmbedController extends Controller {
    private chatbotEmbedService: ChatbotEmbedService =
        new ChatbotEmbedService();

    @Post("basic-info")
    async getChatbotBasicInfo(
        @Body() requestBody: BasicDetailsRequest,
        @Request() request: any
    ): Promise<GetDetailsResponse | unknown> {
        try {
            let apiResponse: any = {
                data: null,
            };
            
            const userDetails = await this.chatbotEmbedService.validateUser(
                requestBody.apiKey,
                requestBody.siteLocation
            );
            if (userDetails?.id) {
                apiResponse.data = {
                    id: userDetails.id,
                    documentId: userDetails.documentId,
                    config: null,
                };
                if (userDetails["config"]) {
                    apiResponse.data["config"] = JSON.parse(
                        userDetails["config"]
                    );
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("start-conversation")
    async startConversation(
        @Body() requestBody: StartConverstionRequest,
        @Request() request: any
    ): Promise<GetDetailsResponse | unknown> {
        try {
            let apiResponse: any = {
                data: null,
            };
            const userDetails = await this.chatbotEmbedService.validateUser(
                requestBody.apiKey,
                requestBody.siteLocation
            );
            if (userDetails?.id) {
                apiResponse.data = {
                    sessionId: uuidv4(),
                    documentId: userDetails.documentId,
                };
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("fetch-history-data")
    async getEmbedChatbotHistory(
        @Body() requestBody: FetchHistoryDataRequest,
        @Request() request: any
    ): Promise<GetDetailsResponse | unknown> {
        try {
            let apiResponse: any = {
                data: [],
            };
            const userDetails = await this.chatbotEmbedService.validateUser(
                requestBody.apiKey,
                requestBody.siteLocation
            );
            if (userDetails?.id) {
                let whereCondition = {
                    sessionId: requestBody.sessionId,
                    documentId: requestBody.documentId,
                };
                const chatbotResult = await dbService._findQueryService(
                    Container.get(DataSource).getRepository(ChatbotHistory),
                    {
                        select: ["type", "msg", "createdOn"],
                        where: whereCondition,
                        order: { createdOn: "ASC" },
                    }
                );
                if (chatbotResult?.length) {
                    apiResponse.data = chatbotResult.map((item) => {
                        return {
                            type: item.type,
                            msg: item.msg,
                            createdOn: moment(item.createdOn)
                                .tz("Asia/Kolkata")
                                .format("hh:mm A"),
                        };
                    });
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("fetch-data")
    async getEmbedChatbot(
        @Body() requestBody: FetchDataRequest,
        @Request() request: any
    ): Promise<GetDetailsResponse | unknown> {
        try {
            let apiResponse: any = {
                data: {
                    msg: "hippp backend code",
                },
            };
            const userDetails = await this.chatbotEmbedService.validateUser(
                requestBody.apiKey,
                requestBody.siteLocation
            );
            if (userDetails?.id) {
                const chatbotHistoryModel = new ChatbotHistory();
                chatbotHistoryModel.clientId = userDetails.clientId;
                chatbotHistoryModel.sessionId = requestBody.sessionId;
                chatbotHistoryModel.documentId = userDetails.documentId;
                chatbotHistoryModel.type = "user";
                chatbotHistoryModel.msg = requestBody.msg;

                await Container.get(DataSource).manager.save(
                    chatbotHistoryModel
                );

                let msg = "Dummy data";
                if (!process.env.BASE_URL.includes("localhost")) {
                    const apiPostData = {
                        documentId: userDetails.documentId,
                        // modelname: "orca-mini",
                        question: requestBody.msg,
                        sessionId: requestBody.sessionId,
                        userId: userDetails.id,
                    };
                    const apiFetchResult = await fetch(
                        process.env.CHATBOT_API_URL + "ollama/query",
                        {
                            method: "POST",
                            body: JSON.stringify(apiPostData),
                            headers: {
                                "Content-Type": "application/json",
                            },
                        }
                    );
                    const result = await apiFetchResult.json();
                    msg = result?.answer;
                }

                const chatbotHistoryModelSys = new ChatbotHistory();
                chatbotHistoryModelSys.clientId = userDetails.clientId;
                chatbotHistoryModelSys.sessionId = requestBody.sessionId;
                chatbotHistoryModelSys.documentId = userDetails.documentId;
                chatbotHistoryModelSys.type = "system";
                chatbotHistoryModelSys.msg = msg;

                await Container.get(DataSource).manager.save(
                    chatbotHistoryModelSys
                );

                apiResponse.data.msg = msg;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
