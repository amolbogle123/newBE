import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import { Chatbot, ChatbotHistory } from "../../../entities";
import { dataSource } from "../../../core/data-source";
import Container from "typedi";
import { DataSource } from "typeorm";
import {
    Body,
    Controller,
    Get,
    Post,
    Request,
    Route,
    Security,
    Tags,
    Path,
    Patch,
} from "tsoa";
import {
    SaveResponse,
    GetDetailsResponse,
    ChatbotResponse,
    UpdateChatbotRequest,
} from "../doc/chatbot-interface";
import { v4 as uuidv4 } from "uuid";

@Route("")
@Tags("Chatbot")
export class ChatbotController extends Controller {
    @Security("bearerAuth")
    @Get("chatbot/all-user/:documentId")
    async chatbotAllSessionList(
        @Request() request: any,
        @Path() documentId: string
    ): Promise<ChatbotResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };

            let results: any = await Container.get(DataSource).query("SELECT CH.SESSION_ID AS sessionId, MIN(CH.CREATEDON) AS createdOn FROM chatbot_history CH WHERE CH.CLIENT_ID = ? AND CH.DOCUMENT_ID = ? GROUP BY CH.SESSION_ID ORDER BY MIN(CH.CREATEDON) DESC", [request.userDetails.client_id, documentId]);
            if (results?.length) {
                apiResponse.data = results;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("chatbot/user-msg/:sessionId")
    async sessionChatList(
        @Request() request: any,
        @Path() sessionId: string
    ): Promise<ChatbotResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };

            let whereCondition = {
                clientId: request.userDetails.client_id,
                sessionId: sessionId,
            };
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ChatbotHistory),
                {
                    where: whereCondition,
                    order: { createdOn: "ASC" },
                }
            );

            if (results?.length) {
                apiResponse.data = results;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Patch("chatbot/:id")
    async updateChatbot(
        @Path() id: string,
        @Body() requestBody: UpdateChatbotRequest,
        @Request() request: any
    ): Promise<ChatbotResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            let isDataFound = false;
            let payload: any = {};

            if (requestBody?.documentId) {
                payload.documentId = requestBody.documentId;
                isDataFound = true;
            }
            if (requestBody?.siteUrl) {
                payload.siteUrl = requestBody.siteUrl;
                isDataFound = true;
            }
            if (requestBody?.config) {
                payload.config = JSON.stringify(requestBody.config);
                isDataFound = true;
            }

            let updateResult: any = null;
            if (isDataFound) {
                updateResult = await dataSource
                    .getRepository(Chatbot)
                    .update({ id: id }, payload);
                apiResponse.data = updateResult;
            }
            if (!updateResult?.affected) {
                this.setStatus(204);
            } else {
                this.setStatus(200);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("chatbot/:documentId")
    async getChatbot(
        @Path() documentId: string,
        @Request() request: any
    ): Promise<GetDetailsResponse | unknown> {
        try {
            const apiResponse = {
                data: null,
            };

            let whereCondition = {
                clientId: request.userDetails.client_id,
                documentId: documentId,
            };
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Chatbot),
                {
                    where: whereCondition,
                }
            );

            if (results?.length) {
                apiResponse.data = results[0];
                apiResponse.data["config"] = JSON.parse(
                    apiResponse.data["config"]
                );
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("chatbot")
    async saveChatbotConfig(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<SaveResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            const chatbotModel = new Chatbot();
            chatbotModel.clientId = request.userDetails.client_id;
            chatbotModel.documentId = requestBody.documentId;
            chatbotModel.siteUrl = requestBody.siteUrl;
            chatbotModel.config = JSON.stringify(requestBody.config);
            chatbotModel.createdBy = request.userDetails.id;

            chatbotModel.siteApiKey = uuidv4();

            const result = await Container.get(DataSource).manager.save(
                chatbotModel
            );
            if (result?.id) {
                apiResponse.data = {
                    insertedId: result.id,
                    siteApiKey: chatbotModel.siteApiKey,
                };
                this.setStatus(201);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
