export interface BasicDetailsRequest {
    siteLocation: string;
    apiKey: string;
}
export interface FetchDataRequest {
    msg: string;
    sessionId?: string | null;
    siteLocation: string;
    apiKey: string;
}
export interface StartConverstionRequest {
    siteLocation: string;
    apiKey: string;
}
export interface FetchHistoryDataRequest {
    sessionId?: string | null;
    siteLocation: string;
    apiKey: string;
    documentId: string;
}
export interface GetDetailsResponse {
    status: boolean;
    data?: any;
    message?: string;
}