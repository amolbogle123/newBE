export interface InsertRequest {
    documentId?: string;
    siteUrl?: string;
    config?: any;
}

export interface UpdateChatbotRequest {
    documentId?: string;
    siteUrl?: string;
    config?: any;
}

export interface SaveResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface ChatbotResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface GetDetailsResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DeleteChatbot {
    id: string[];
}