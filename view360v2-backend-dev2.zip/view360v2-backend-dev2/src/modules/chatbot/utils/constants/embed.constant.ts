export const embedData = {
    embedJsData: `let script = document.createElement("script");
    script.src =
      "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js";
    document.head.insertBefore(script, document.head.firstChild);
    setTimeout(() => {
      loadChatScript();
    }, 2000);
    
    function loadChatScript() {
      // const baseUrl = "http://localhost:8080/";
      const baseUrl = "https://v2devapi.epiksolution.org:8080/";
      importFiles();
      let themeDetails = {
        startBtnClick: false,
        fontSize: 12,
        userIcon: null,
        bgColor: "#0066ff",
        textColor: "#fff",
      };
      let sessionDetails = null;
      let chatBasicDetails = null;
      let scriptApiKey = null;
      let siteLocation = window.location.origin;
      console.log("siteLocation", siteLocation);
      let scriptTag = document.getElementById("view360-chatbot-embed");
      if (!scriptTag?.dataset?.apiKey) {
        return;
      }
      scriptApiKey = scriptTag.dataset.apiKey;
    
      const view360ChatbotApp = document.createElement("div");
      view360ChatbotApp.className =
        "view360-chatbot-container app-wrapper app-responsive";
    
      let body = document.getElementsByTagName("body")[0];
      body.appendChild(view360ChatbotApp);
    
      const view360ChatbotWrapper = document.createElement("div");
      view360ChatbotWrapper.className = "view360-chatbot-wrapper closed chatbox";
      view360ChatbotApp.appendChild(view360ChatbotWrapper);
    
      const chatView = document.createElement("div");
      chatView.className = "view360-chatbot-view chat";
      view360ChatbotWrapper.appendChild(chatView);
    
      const chatMsgBodyView = document.createElement("div");
      chatMsgBodyView.className = "view360-chatbot-body conversation";
    
      const chatStartBtn = document.createElement("div");
      chatStartBtn.addEventListener("click", showHidePopup);
    
      const chatInputText = document.createElement("input");
    
      getChatBasicInfo();
    
      function showMsg(type, msgConfig) {
        let name = chatBasicDetails?.config?.assistantName || "View360 ChatBot";
        let logo = chatBasicDetails?.config?.logo || "chatbot/logo.png";
        const chatMsg = document.createElement("div");
    
        if (type === "user") {
          chatMsg.className = "view360-chatbot-msg user";
          let html =
            '<div class="user"><div data-type="CAPTION" data-user="true" class="message"><div class="caption">';
          if (themeDetails?.userIcon) {
            html +=
              '<div class="avatar"><div data-status="loaded" data-cover="true" class="lazy-img"><img src="' +
              themeDetails.userIcon +
              '" alt="" style="width: 18px;height: 18px;" class="lazy-img-loaded"></div></div>';
          }
          html +=
            '<span>You</span></div></div><div data-user="true" class="message"><div class="input-wrapper"><div ' +
            ' class="anchors input-wrapper-text" data-first="true">' +
            msgConfig.msg +
            '</div></div><div class="message-date-wrapper"><div class="message-date">' +
            msgConfig.time +
            "</div></div></div></div>";
          chatMsg.innerHTML = html;
        } else if (msgConfig?.questionList?.length) {
          let btnMsgHtml = "";
          msgConfig.questionList.forEach((q) => {
            if (q) {
              btnMsgHtml +=
                '<div class="single-button" data-question="' +
                q +
                '"><span>' +
                q +
                '</span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"class="bi bi-arrow-right" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8" /></svg></div>';
            }
          });
          chatMsg.innerHTML =
            '<div class="bot-response"><div data-bot="true" class="message"><h4 class="quick-start-text">Quick Action</h4><div class="quick-replies-buttons">' +
            btnMsgHtml +
            '</div><div class="message-date-wrapper"><div class="message-date">' +
            msgConfig.time +
            "</div></div></div></div>";
        } else if (msgConfig?.msg) {
          chatMsg.className = "view360-chatbot-msg bot-response";
          chatMsg.innerHTML =
            '<div data-bot="true" class="message"><div class="caption"><div class="avatar"><div data-status="loaded" data-cover="true" class="lazy-img"><img src="' +
            baseUrl +
            logo +
            '" alt="" class="lazy-img-loaded"></div></div> <span>' +
            name +
            '</span></div></div><div data-bot="true" class="message"><div class="anchors bot-response text" data-first="true">' +
            msgConfig.msg +
            '</div><div class="message-date-wrapper"><div class="message-date">' +
            msgConfig.time +
            "</div></div></div>";
        }
        chatMsgBodyView.appendChild(chatMsg);
    
        if (msgConfig?.questionList?.length) {
          setTimeout(() => {
            let elements = document.getElementsByClassName("single-button");
            for (var i = 0; i < elements.length; i++) {
              elements[i].addEventListener("click", chatMsgBtn, false);
            }
          }, 100);
        }
      }
    
      let chatMsgBtn = function () {
        let question = this.getAttribute("data-question");
        if (question) {
          showMsg("user", {
            time: getTimeFormat(),
            msg: question,
          });
          showHideLoader("show");
          getChatData(question);
        }
      };
    
      function getChatBasicInfo() {
        const settings = {
          url: baseUrl + "embed-chatbot/basic-info",
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          data: JSON.stringify({
            apiKey: scriptApiKey,
            siteLocation: siteLocation,
          }),
        };
    
        $.ajax(settings).done(function (response) {
          if (response?.status && response?.data?.id) {
            chatBasicDetails = response.data;
            if (response.data?.config?.bgColor) {
              themeDetails.bgColor = response.data.config.bgColor;
            }
            if (response.data?.config?.textColor) {
              themeDetails.textColor = response.data.config.textColor;
            }
            if (response.data?.config?.fontSize) {
              themeDetails.fontSize = response.data.config.fontSize;
              view360ChatbotApp.style.fontSize = themeDetails.fontSize + "px";
            }
            if (response.data?.config?.avtar) {
              themeDetails.userIcon = baseUrl + response.data.config.avtar;
            }
            if (chatBasicDetails?.documentId) {
              sessionDetails = getLocalStorageData(chatBasicDetails.documentId);
            }
            loadStartBtn();
            loadChatView();
          } else {
            console.error("View360 chatbot basic info not found");
          }
        });
      }
    
      function startConversation() {
        const settings = {
          url: baseUrl + "embed-chatbot/start-conversation",
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          data: JSON.stringify({
            apiKey: scriptApiKey,
            siteLocation: siteLocation,
          }),
        };
    
        $.ajax(settings).done(function (response) {
          if (response?.status && response?.data?.sessionId) {
            sessionDetails = {
              sessionId: response.data.sessionId,
              documentId: response.data.documentId,
            };
            setLocalStorageData(sessionDetails);
          }
        });
      }
    
      function getChatData(msg) {
        const settings = {
          url: baseUrl + "embed-chatbot/fetch-data",
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          data: JSON.stringify({
            msg: msg,
            sessionId: sessionDetails.sessionId,
            apiKey: scriptApiKey,
            siteLocation: siteLocation,
          }),
        };
    
        $.ajax(settings).done(function (response) {
          if (response?.status && response?.data?.msg) {
            showMsg("system", {
              time: getTimeFormat(),
              msg: response.data.msg,
            });
          }
          showHideLoader("hide");
        });
      }
    
      function getChatHistoryData(sessionDetails) {
        const settings = {
          url: baseUrl + "embed-chatbot/fetch-history-data",
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          data: JSON.stringify({
            sessionId: sessionDetails.sessionId,
            documentId: sessionDetails.documentId,
            apiKey: scriptApiKey,
            siteLocation: siteLocation,
          }),
        };
    
        $.ajax(settings).done(function (response) {
          showHideLoader("hide");
          if (response?.status && response?.data?.length) {
            // chatMsgBodyView.innerHTML = "";
            response.data.forEach((v, k) => {
              showMsg(v.type, {
                time: v.createdOn,
                msg: v.msg,
              });
            });
          } else {
            showDefaultQuestion();
          }
        });
      }
    
      function getLocalStorageData(documentId) {
        let dataSet = null;
        let storageSession = localStorage.getItem("chat-session-id");
        if (storageSession) {
          try {
            let allData = JSON.parse(storageSession);
            allData.forEach((d) => {
              if (d?.documentId === documentId) {
                dataSet = d;
              }
            });
            console.log("allData", documentId, allData, d);
          } catch (error) {}
        }
    
        return dataSet;
      }
    
      function setLocalStorageData(sessionData) {
        let dataSet = [];
        let storageSession = localStorage.getItem("chat-session-id");
        if (storageSession) {
          try {
            dataSet = JSON.parse(storageSession);
          } catch (error) {}
        }
        dataSet.push(sessionData);
        localStorage.setItem("chat-session-id", JSON.stringify(dataSet));
      }
    
      function loadChatView() {
        let dataSet = {
          name: chatBasicDetails?.config?.assistantName || "View360 ChatBot",
          chatModel: chatBasicDetails?.config?.assistantDescription || "",
          logo: chatBasicDetails?.config?.logo || "chatbot/logo.png",
        };
        const chatHeaderView = document.createElement("div");
        chatHeaderView.className = "view360-chatbot-header chat-header";
        chatHeaderView.style.backgroundColor = themeDetails.bgColor;
        chatHeaderView.style.color = themeDetails.textColor;
        chatHeaderView.innerHTML =
          '<div class="avatar"><div class="chat-avatar"><div class="chat-avatar-status"></div><div class="chat-avatar-image"><div data-status="loaded" data-cover="true" class="lazy-img"><img src="' +
          baseUrl +
          dataSet.logo +
          '" alt="" class="lazy-img-loaded" id="view360-chatbot-logo"></div></div></div></div><div class="company"><div class="header" id="view360-chatbot-name">' +
          dataSet.name +
          '</div><div class="status" id="view360-chat-model">' +
          dataSet.chatModel +
          "</div></div>";
        chatView.appendChild(chatHeaderView);
    
        const chatCloseBtn = document.createElement("div");
        chatCloseBtn.className = "view360-header-close-btn close";
        chatCloseBtn.addEventListener("click", showHidePopup);
        chatCloseBtn.innerHTML ='<div data-actions="true" data-tooltip="Close" class="chat-close"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">' +
          '<path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z"/> </svg></div>';
        chatHeaderView.appendChild(chatCloseBtn);
    
        chatView.appendChild(chatMsgBodyView);
    
        const chatInputView = document.createElement("div");
        chatInputView.className = "view360-chatbot-input typing";
    
        chatInputText.type = "text";
        chatInputText.setAttribute("placeholder", "Type your message here");
        chatInputText.setAttribute("id", "view360-chat-input");
        chatInputText.setAttribute("maxlength", "256");
        chatInputText.addEventListener("keypress", inputKeypressEvent);
        chatInputView.appendChild(chatInputText);
    
        const chatSendBtn = document.createElement("div");
        chatSendBtn.addEventListener("click", sendMsg);
        chatSendBtn.className = "view360-chatbot-send-btn send-icon";
        chatSendBtn.innerHTML =
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-send-horizontal"><path d="m3 3 3 9-3 9 19-9Z"></path><path d="M6 12h16"></path></svg>';
        chatInputView.appendChild(chatSendBtn);
    
        chatView.appendChild(chatInputView);
    
        if (
          chatBasicDetails?.config?.showFooter &&
          chatBasicDetails?.config?.showFooterMsg
        ) {
          const chatFooterView = document.createElement("div");
          chatFooterView.className = "view360-chatbot-footer chat-powered-by";
          chatFooterView.innerHTML = chatBasicDetails.config.showFooterMsg;
          // '<span><span>Powered by</span> <a target="_blank" href="https://www.epikso.com"> View360 </a></span>';
          chatView.appendChild(chatFooterView);
        }
    
        showHideLoader("show");
        console.log("chatBasicDetails", chatBasicDetails);
      }
    
      function inputKeypressEvent(event) {
        if (event.charCode == 13) {
          sendMsg();
        }
      }
    
      function loadStartBtn() {
        chatStartBtn.className = "view360-chatbot-btn bubble";
        chatStartBtn.style.backgroundColor = themeDetails.bgColor;
        chatStartBtn.style.color = themeDetails.textColor;
        chatStartBtn.innerHTML =
          '<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" class="bi bi-chat-dots" viewBox="0 0 16 16"><path d="M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0m4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2" /> <path d="m2.165 15.803.02-.004c1.83-.363 2.948-.842 3.468-1.105A9 9 0 0 0 8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6a10.4 10.4 0 0 1-.524 2.318l-.003.011a11 11 0 0 1-.244.637c-.079.186.074.394.273.362a22 22 0 0 0 .693-.125m.8-3.108a1 1 0 0 0-.287-.801C1.618 10.83 1 9.468 1 8c0-3.192 3.004-6 7-6s7 2.808 7 6-3.004 6-7 6a8 8 0 0 1-2.088-.272 1 1 0 0 0-.711.074c-.387.196-1.24.57-2.634.893a11 11 0 0 0 .398-2" /></svg>';
        view360ChatbotApp.appendChild(chatStartBtn);
      }
    
      function importFiles() {
        let headTag = document.getElementsByTagName("head")[0];
    
        let linkElement = document.createElement("link");
        linkElement.setAttribute("rel", "stylesheet");
        linkElement.setAttribute("type", "text/css");
        linkElement.setAttribute("href", baseUrl + "chatbot/chatbot.css");
        headTag.appendChild(linkElement);
      }
    
      function showHidePopup() {
        if (view360ChatbotWrapper.classList.contains("closed")) {
          view360ChatbotWrapper.classList.remove("closed");
          view360ChatbotWrapper.classList.add("opened");
    
          showHideLoader("hide");
          if (
            !themeDetails?.startBtnClick &&
            chatBasicDetails?.config?.greeting &&
            chatBasicDetails?.config?.greetingMsg
          ) {
            showMsg("system", {
              time: getTimeFormat(),
              msg: chatBasicDetails?.config?.greetingMsg,
            });
          }
    
          if (!sessionDetails?.sessionId) {
            showDefaultQuestion();
            startConversation();
          } else if (!themeDetails?.startBtnClick && sessionDetails?.sessionId) {
            showHideLoader("show");
            getChatHistoryData(sessionDetails);
          } else {
            showHideLoader("hide");
          }
    
          themeDetails.startBtnClick = true;
          chatInputText.focus();
        } else {
          view360ChatbotWrapper.classList.remove("opened");
          view360ChatbotWrapper.classList.add("closed");
        }
      }
    
      function showDefaultQuestion() {
        if (chatBasicDetails?.config?.questionList?.length) {
          let questionList = [];
          chatBasicDetails.config.questionList.forEach((q) => {
            if (q?.question) {
              questionList.push(q.question);
            }
          });
          showMsg("system", {
            time: getTimeFormat(),
            questionList: questionList,
          });
        }
      }
    
      function getTimeFormat() {
        let dateObj = new Date();
        let hours = dateObj.getHours();
        let minutes = dateObj.getMinutes();
        let ampm = hours >= 12 ? "PM" : "AM";
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? "0" + minutes : minutes;
        return hours + ":" + minutes + " " + ampm;
      }
    
      function showHideLoader(type) {
        const findLoader = document.getElementsByClassName("view360-msg-loader");
        if (findLoader?.length) {
          for (let i = 0; i < findLoader.length; i++) {
            findLoader[i].remove();
          }
        }
    
        if (type === "show") {
          const chatLoader = document.createElement("div");
          chatLoader.className = "view360-msg-loader message";
          chatLoader.innerHTML =
            '<div data-first="true" class="indicator" ><div class="dot" ></div><div class="dot" ></div><div class="dot" ></div></div>';
          chatMsgBodyView.appendChild(chatLoader);
        }
      }
    
      function sendMsg() {
        const inputElement = document.getElementById("view360-chat-input");
        if (inputElement?.value && inputElement.value.trim()) {
          showMsg("user", {
            time: getTimeFormat(),
            msg: inputElement.value,
          });
          showHideLoader("show");
          getChatData(inputElement.value);
          inputElement.value = "";
        }
      }
    }`,
    cssData: `@import url("https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");

    .view360-chatbot-container {
        font-family: "Poppins", system-ui, -apple-system, "Segoe UI", Roboto,
            "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif,
            "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol",
            "Noto Color Emoji";
        font-size: 11px;
        box-sizing: border-box;
    }
    .view360-chatbot-container .bubble {
        -webkit-backface-visibility: hidden;
        border-radius: 100%;
        /* -webkit-box-shadow: 0 0 50px 0 rgba(0, 0, 0, 0.06); */
        box-shadow: 0 1px 10px 0 rgb(120 96 96 / 42%);
        cursor: pointer;
        height: 50px;
        overflow: hidden;
        -webkit-transition: all 0.3s;
        transition: all 0.3s;
        width: 50px;
        background: rgb(0, 102, 255);
        flex-shrink: 0;
        transform: translateY(0px);
        transition: 0.3s;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        /* filter: drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25)); */
        z-index: 99999;
        position: fixed;
        bottom: 30px;
        right: 30px;
    }
    .view360-chatbot-container .opened + .bubble {
        transform: translateY(200px);
        display: none;
        height: 0;
    }
    
    .view360-chatbot-container.app-responsive {
        overflow: hidden;
    }
    .view360-chatbot-container .chat-powered-by {
        -ms-flex-align: center;
        -ms-flex-pack: center;
        display: -ms-flexbox;
        font-size: 10px;
        text-align: center;
    
        line-height: 24px;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    
        color: #777777;
        margin-top: -12px;
        z-index: 1;
        display: none;
    }
    .view360-chatbot-container .chat-avatar {
        height: 100%;
        position: relative;
        width: 100%;
    }
    .view360-chatbot-container .chat-avatar .chat-avatar-image {
        border-radius: 100%;
    
        height: 100%;
        overflow: hidden;
        width: 100%;
    }
    .view360-chatbot-container .chat-close {
        border-radius: 100%;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
    }
    
    .view360-chatbot-container .chat-close:after {
        content: attr(data-tooltip);
        background: #555;
        color: #fff;
        border-radius: 6px;
        padding: 2px 8px;
        position: absolute;
        bottom: 100%;
        right: 50%;
    
        white-space: nowrap;
        transform: translateX(50%) scale(0);
        transition: 0.1s;
    }
    .view360-chatbot-container .chat-close:hover:after {
        transform: translateX(50%) scale(1);
    }
    
    .view360-chatbot-container .chat-close svg {
        height: 16px;
        width: 16px;
    }
    .view360-chatbot-container .chat-close {
        margin-left: 15px;
    }
    .view360-chatbot-container .chat-close {
        -webkit-backface-visibility: hidden;
        cursor: pointer;
        -webkit-transition: all 0.3s;
        transition: all 0.3s;
        position: relative;
    }
    .view360-chatbot-container .chat-close:hover {
        background: rgba(13, 110, 253, 0.25);
        box-shadow: 0 0 0 6px rgba(13, 110, 253, 0.25);
    }
    
    .view360-chatbot-container .lazy-img img.lazy-img-loaded {
        display: block;
        max-width: 100%;
    }
    .view360-chatbot-container .lazy-img[data-status="loaded"][data-cover="true"] {
        height: 100%;
        width: 100%;
    }
    .view360-chatbot-container
        .lazy-img[data-status="loaded"][data-cover="true"]
        img.lazy-img-loaded {
        height: 100%;
        -o-object-fit: cover;
        object-fit: cover;
        width: 100%;
    }
    .view360-chatbot-container .opened {
        position: relative;
    }
    .view360-chatbot-container .chatbox.opened {
        height: calc(100vh - 60px);
    }
    .view360-chatbot-container .chatbox.closed {
    }
    .view360-chatbot-container .chatbox {
        border-radius: 15px;
        height: 0;
        width: 390px;
        position: relative;
    
        transition: 0.1s;
        box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.2);
        position: fixed;
        bottom: 30px;
        right: 30px;
        z-index: 99999;
        overflow: hidden;
    }
    .view360-chatbot-container .chatbox .chat {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-direction: column;
        flex-direction: column;
        height: 100%;
        width: 100%;
    }
    .view360-chatbot-container .chatbox .chat .chat-header {
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        padding: 10px 14px;
        gap: 14px;
        position: relative;
        z-index: 3;
        background: rgb(249 249 249);
    
        color: #302e2e;
        align-items: center;
        border-radius: 10px 10px 0 0;
    }
    .view360-chatbot-container .chatbox .chat .chat-header .avatar {
        height: 35px;
        width: 35px;
    
        background-color: rgb(255 255 255 / 92%);
        padding: 3px;
        border-radius: 50%;
    }
    .view360-chatbot-container .chatbox .chat .chat-header .company {
        -webkit-box-flex: 1;
        -ms-flex-positive: 1;
        -ms-flex-negative: 0;
        flex-grow: 1;
        flex-shrink: 0;
        width: 0;
        align-self: center;
    }
    .view360-chatbot-container .chatbox .chat .chat-header .company .header {
        cursor: default;
        font-size: 15px;
        font-weight: 500;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        line-height: 1.6;
    }
    .view360-chatbot-container .chatbox .chat .chat-header .company .status {
        cursor: default;
        font-size: 10px;
    }
    .view360-chatbot-container .chatbox .chat .typing {
        -ms-flex-align: center;
    
        display: -ms-flexbox;
    }
    .view360-chatbot-container .chatbox .chat .typing {
        background: rgb(255, 255, 255);
    
        padding: 0 16px;
        box-sizing: border-box;
    
        padding: 10px 14px 14px 14px;
        position: relative;
        border-radius: 0 0 10px 10px;
    }
    .view360-chatbot-container .chatbox .chat .typing input::placeholder {
        color: rgb(150, 155, 166) !important;
    }
    .view360-chatbot-container .chatbox .chat .typing input {
        -webkit-box-flex: 1;
        background: transparent;
        border: 0;
        -ms-flex: 1 0 0px;
        flex: 1 0 0;
    
        outline: none;
        color: rgb(0 0 0);
        font-family: inherit;
        border: 1px solid rgb(234, 234, 234);
        border-radius: 6px;
        font-size: inherit;
        padding: 10px 14px;
        width: 100%;
    }
    .view360-chatbot-container .chatbox .chat .typing input:focus {
        border-color: rgb(0 102 255 / 0%);
        border: 1px solid rgb(0, 102, 255);
    }
    .view360-chatbot-container
        .chatbox
        .chat
        .typing
        input:not(:placeholder-shown)
        + .send-icon {
        color: rgb(0, 102, 255);
    }
    
    .view360-chatbot-container
        .chatbox
        .chat
        .typing
        input::-webkit-input-placeholder {
        color: currentColor;
    }
    .view360-chatbot-container .chatbox .chat .typing input::-moz-placeholder {
        color: currentColor;
    }
    .view360-chatbot-container .chatbox .chat .typing input:-ms-input-placeholder {
        color: currentColor;
    }
    .view360-chatbot-container .chatbox .chat .typing input::-ms-input-placeholder {
        color: currentColor;
    }
    .view360-chatbot-container .chatbox .chat .typing .send-icon {
        -webkit-box-flex: 0;
        -webkit-backface-visibility: hidden;
        cursor: pointer;
        -ms-flex: 0 0 26px;
    
        -webkit-transition: all 0.3s;
        transition: all 0.3s;
    
        color: #c1c1c1;
        position: absolute;
        right: 26px;
        top: 50%;
        transform: translateY(-50%);
    }
    .view360-chatbot-container .chatbox .chat .typing .send-icon:hover {
        opacity: 0.8 !important;
    }
    .view360-chatbot-container .chatbox .chat .typing .send-icon:active {
        opacity: 0.5 !important;
    }
    .view360-chatbot-container .chatbox .chat .typing .send-icon:disabled {
        opacity: 0.2;
    }
    .view360-chatbot-container .chatbox .chat .typing .send-icon svg {
        height: 20px;
        width: 20px;
    }
    .view360-chatbot-container .chatbox .chat .typing .send-icon svg path {
        -webkit-transition: fill 0.3s;
        transition: fill 0.3s;
    }
    .conversation {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -webkit-box-flex: 1;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -ms-flex: 1 0 0px;
        flex: 1 0 0;
        -ms-flex-direction: column;
        flex-direction: column;
        height: 100%;
        overflow-x: hidden;
        overflow-y: auto;
        overscroll-behavior-y: contain;
        width: 100%;
        background: rgb(255 255 255);
        padding: 14px;
        box-sizing: border-box;
        gap: 5px;
    }
    .conversation:after,
    .conversation:before {
        width: 100%;
    }
    .conversation .message,
    .conversation:after,
    .conversation:before {
        -ms-flex-negative: 0;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        flex-shrink: 0;
    }
    .conversation .message {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -webkit-box-align: start;
        -ms-flex-align: start;
        align-items: flex-start;
        -ms-flex-direction: column;
        flex-direction: column;
        position: relative;
    }
    .conversation .message[data-bot] {
        -webkit-box-align: start;
        -ms-flex-align: start;
        align-items: flex-start;
    }
    .conversation .message[data-user] {
        -webkit-box-align: end;
        -ms-flex-align: end;
        align-items: flex-end;
    }
    .conversation .message .message-date-wrapper:hover,
    .conversation .message > :first-child:hover ~ .message-date-wrapper {
        opacity: 1 !important;
        visibility: visible;
    }
    .conversation .message .message-date-wrapper .message-date {
        font-size: 10px;
        margin: 5px 0 0px 0;
        margin-left: 12px;
        display: none;
    }
    .conversation .bot-responve .message .message-date-wrapper .message-date {
        margin-left: 12px;
    }
    .conversation .message .bot-response.text {
        word-wrap: break-word;
        border-radius: 20px;
        max-width: 100%;
        padding: 8px 14px;
        background: #f6f6f6;
        color: rgb(0, 0, 0);
    }
    .conversation .message .bot-response.text:hover {
        background: #efefef;
    }
    .conversation .message .caption {
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        max-width: 100%;
        font-size: 9px;
        margin-bottom: 4px;
    }
    .conversation .message .caption .avatar {
        border-radius: 100%;
        height: 18px;
        margin-right: 6px;
        overflow: hidden;
        width: 18px;
    }
    .conversation .message .input-wrapper {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -webkit-box-align: end;
        -ms-flex-align: end;
        align-items: flex-end;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-direction: column;
        flex-direction: column;
    }
    .conversation .message .input-wrapper .input-wrapper-text {
        word-wrap: break-word;
        border-radius: 23px;
        max-width: 100%;
        padding: 8px 14px;
        white-space: initial;
        word-break: break-word;
        background: #ecf3fe;
    }
    .conversation .message .input-wrapper .input-wrapper-text:hover {
        background: #dde9ff;
    }
    
    a {
        text-decoration: none;
    }
    .conversation .message .indicator {
        -ms-flex-item-align: start;
        -ms-flex-align: center;
        align-items: center;
        align-self: flex-start;
        border-radius: 20px;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        word-wrap: break-word;
        border-radius: 20px;
        max-width: 100%;
        padding: 15px 14px;
        background: #f6f6f6;
        color: rgb(0, 0, 0);
    }
    
    .conversation .message .indicator .dot {
        -webkit-animation: indicator-bounce 1s ease-in-out infinite both;
        animation: indicator-bounce 1s ease-in-out infinite both;
        -webkit-animation-delay: 0s;
        animation-delay: 0s;
        border-radius: 100%;
        height: 4px;
        margin: 0 3px;
        width: 4px;
        background: rgb(94, 94, 94);
    }
    .conversation .message .indicator .dot:first-child {
        -webkit-animation-delay: -0.125s;
        animation-delay: -0.125s;
    }
    .conversation .message .indicator .dot:last-child {
        -webkit-animation-delay: 0.25s;
        animation-delay: 0.25s;
    }
    .quick-start-text {
        font-size: 14px;
        margin: 20px 0 10px 0;
        font-weight: 600;
    }
    .quick-replies-buttons {
        display: flex;
    
        flex-wrap: wrap;
        border-radius: 10px;
    
        margin-bottom: 10px;
        border: 1px solid #ecf3fe;
        overflow: hidden;
    }
    .conversation .message .quick-replies-buttons .single-button:hover {
        background: #ecf3fe;
    }
    .conversation .message .quick-replies-buttons .single-button svg {
        transition: 0.2s;
    }
    .conversation .message .quick-replies-buttons .single-button:hover svg {
        transform: translateX(10px);
    }
    .conversation .message .quick-replies-buttons .single-button:first-child {
        border-top: 0;
    }
    .conversation .message .quick-replies-buttons .single-button:hover svg {
        transform: translateX(10px);
    }
    .conversation .message .quick-replies-buttons .single-button {
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        -webkit-backface-visibility: hidden;
        cursor: pointer;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        max-width: 100%;
        padding: 12px 16px;
        -webkit-transition: all 0.3s;
        transition: all 0.3s;
        color: rgb(0, 102, 255);
    
        width: 100%;
        border-top: 1px solid #ecf3fe;
    
        justify-content: space-between;
        transition: 0.2s;
    }
    @-webkit-keyframes indicator-bounce {
        50% {
            -webkit-transform: translateY(-5px);
            transform: translateY(-5px);
        }
    }
    @keyframes indicator-bounce {
        50% {
            -webkit-transform: translateY(-5px);
            transform: translateY(-5px);
        }
    }
    
    .view360-chatbot-container .bubble svg {
        width: 1.2rem;
        height: 1.2rem;
    }
    
    `,
    logoData:
        "iVBORw0KGgoAAAANSUhEUgAAAGsAAABuCAYAAAAgcu2/AAAAAXNSR0IB2cksfwAAAAlwSFlzAAALEwAACxMBAJqcGAAARipJREFUeJztXQdYFOfW3lmqdBABRVEBexcb9t67YqdI773XXdhl2WWB7b0Xlt5FLAg27F1jS09uclNvejPJ/PPNsssuRc29Mcm9f77n+R40QZidd875znnPe85gMH/hJb3+kdn66nsrx7Cv+vKvvWv5Z1/P36vfCu54w2ZF1YOFU6S3k0exr59xZVx5tFx6NRPPkVr92df29+pdwSfecligfhDizLl5zo5x/Tuo9DIMUXrgFcLzjQxF7QoKhez4Z1/j3wtZCzQPt7jx75wyo11/BpVdhTHUKzCGcgmGyD1wiKSDKhFLFhPwRdZ/9nX+v1/7297wtGbd+hqquA5jyq5pgSrtA2ursEstEIrmphcQzP7sa/1/tw6detc179IH6+X33zIHfx8vuVeEqbgBYxCwoHKdVV1Gdg8C1kV4FP3ip6HyU6E4UurfAcYftSLOfDB2VtWTwlmVD0/HVXWPdXBwwIL/7im+k4ZaVfk1WO8CS7VgYUouwBDpAjyK1vPPKPXZtQkJR7B/9uf4n15R3e+NmKR5wrMRPvjZkn/v2SHNpbjyMtroJUuWoJbFab/s6sK59gRCwep1gaUIUIhVQQhYmOLzMIZ4HnYqPf/xNumFQ+FpfqZ/9mf6n1tJlz423Xb8vTku8kf/hLj3YQznHuzAv/NxnrLFn84qG+3u7o5aSWB2umla3fnt43nXn6BgARdYqnWBGJIOrHMwhtANWxK7v1srvkQ/KuwYGVIugv7sz/g/sfZ1vG86Vv0k1l766EMM7wGsA8uJd+fzfFVbMJNR4Wz4/aSiQpuIynP73FlX3oL059UFA7DOImB1wZjCM7ApskeWdj2Yz+r2j63tsZu9c+PfoP0na1Hjm37DRI++xvAfwBieFigM+x5sybn7i5+8O6+cQnHq/29KiHjrUOmJLR7MntsmAKySi1qgis+iVoUp0oKFwXXCUMEp2Bx/6me3ks4rUyvOFG7gn564ee3Sv0H7rSvv+j9tRiienMfwX4MNrQrDuovsO7CX6ObdHGn9jC1btpgY/rtw/EyITC22Spe2LJ3PO19nXXrxB61VdaNWBQGw8ACs0whYJ2FM/gkYk9sBY3OPw67Ek68d4HbMSo30/zsAeZmleP0LNGBYd+zdcVbix2/prAoFi90HlgX71k8blVdzc7Lx9oP9nPz8UhuJWDxto+icbBj5PAwhLhBCLAvqtSoM7pQWrDwtWJic4/Cw/OPwlormwJyMpL8T5xetnaf+MZt485MV4M+7jr89zkb0CAULMnCBACgM8xYMMW7B1qyb365V3xTHpiUPyJ38NmCgHes2mZbTykfGSk9EjC4/+4kpcIP4PheosyoAFCanHfYgHv+UoqgPJOApLpiaAmiP7PJqN1x72YjcFspSeudBQusVhz/+rvwF16aO92bPbXjrRGp2JPpUF0haTD0UDxuhAS7wNgwhYGEYN2EM7QYMIXuW5EZtMadyqBsJJSYm2oora5fs4J+ucCrp+gZCraoPLAgBywHX/k26uKFMLpevIBXn202lnIo0S2uCMckNMCapHoYSamG79PofxhU0d04tOoYPll/w+QNvz19n+Z35wNut8s0Pl9c+IJWVU9wwGGv0zNhafWOTrei1bw1doB4oHVgoY3ENniK62XVE2eWxMzF20PMmMyXGksWiexDUx4OnlnfecySc/taq8CRsV3gC9iZ1fBAvahGpVardPB5nXKCka9zw/GO/QikNRmBB8TUwFKeBoVgNjI1RwxPzGx9tpJ3MXkZunZ1Xe/Z/n83ffvIfK0ZWvvkUEj+BQ2t6EsrLqWMwGCc0Iosr49rOU9wqtRXc/xbD1p5VerDoWrAwFddgTPlVGIvkVq6sa/dmC68mRGnODMqs52XnmZaUkIeXi5SLkoSN4cGcxtw4QROeIdOESKWyjUwmwys7PdNiHf+iEEpphDEArKQ6GJOIgJRQA2Piq2EMClYljIlWw1CUEsZGK2Gb+Mp/OSdpLs4uaEjaU9Yw2p+6+X8volzd/v4cF/WbjyHxUxgSPYGz6s5mkcnkkbr/H7tnB4SX17ofrLmWbsO7+zVk6AIBWIBeQsACXCBEvQJDpZdgM+qlZx6sK10LBZfXpamaBpxl48aNg2JjY83z8/MdqFSqO4PB8ARfCwoKHP39/VFWYz3/ggxKbey1Ki1YWqCqYAxiVRBiVZhoFYxBwMJEKmBMuBzGhMlgs3DZs/HpVdeL2VLXtWvXooClV180W4hvmDkxVb1zanrlxiMVLf99597Ozg8mOKje7IEkCFAIWBjRY/ig5hKTTi8dZfh9CdFx2PKyUru9igsRzvzbn4HAos+qrqNWhTEsh1AuolzgMMqFL0fTL7YtEV3eTmi6MqiLcnV1hebPnw+Br4b/PYzf5OFV2HbJIq0BhhCwoMQ+qxoAVkQvWKFSZEtgKEQCH6BUhaWnJlkGiLrsZ+TUkm3CxJ9jA3iwZZAAnpCs7Eqli11e5b39XRf/yT9Npze+22QqfR0FCrhAANaSyjsn2WzmuP7fv8FvGkQpo7ocre7Jt2Xf+q6/CzQuh2jBgpDcCkISYXvK+S9ncXqIxPYbzkv9fF7KPS1cPtEkT1S/eFlp63G3nMbv+lxgFQJUJQoUBMCK1IIFhcu0YCFAYULE8H6ypghfQHDcXH7c3z5S+hkGAQrjz4WhIxwYe4QN7yZVR2fi0sx/9xv7KtacpvdSMQAoiRYoHVj2koffU9VNyw/FBw6oOSUl+UJkMtERV3Vy31zxtU5zxg2UYccYlEOg3nIIZEAvgdwKU9gF25G6v/aqOFe/V3llmd82vxeCVliCt2CwmJ5SiXQVTtaSt5FSXz8pr/ZN26Qq9LzSukAlDEXIYSisDyy7KBksUNfFUMilbo5RUpzpUQFsCBZ0mAVPiJfcZbCZY7KJuX99MtlF89YVjOR1GCPpsyqM8DEMCR7CCzT3z7AY7JERu8MHRHWE8olQZGqKNYvL99qnOFvkwr72BSBtIdSy+lygIWnbRy+dhkHIbl54CnannOmZxzoXVdZxy/V51+np6QmFhoZaUihkFy6PN0kskSwRKKv2Z/LrcRtJtY3Tc6see6RXw6aIZUEIWM5x8q8PUSqr5XLZ+pz8fDtffF0M4gK/wfgjYB3RgoVBwPKMl8ICodAnJy/nr558T4Om1L/za3+rghCwMIJHMMR/CM9T3ZFmC5WuG3xHD2oBuZx4UzKFMrxY2bRxm/yC3Lbi8g96q+oHVn96CdLnVu2wPf7Ezx7FJyv9FFc2Z9dctnveVfulrMfGBCWa4wsLHCjllFEcDnsqcsMXI5a3oVRaE5/IrCpCgIySyxTbaBXMcaEJB01KVR1u3snK08CqULAOs1GwpidJXpdIJMvwOPxfWw8ybZoL5K55883+YAGg0M1/DbYSPvh2geJmZgJHOuSTt2/fPiyBUOzIlipn+knOFI1h9LxjQtG5wHO9LrDXqvBaegljRC+1w5jsY7BJdhtsl9/+vgexo2Ez9/S8uBj/57rIefPmQYcOHTJJSEiwQCJIewqF4oZElN4cDmcWsmeUl5ePjY6ORqPQmLijpjuI1TtHRYufWgTxfgHn1Ygw/tdJDI0IAWsBoajI9ve+v7/7mlT9utIwsMAIdUA9hFEukPsAHsa//+1M+e3CBPUpp0WLBj9jtobHQyFJGaYV9HIXgqx+zRZRt3g8/fxTM9L5n/VWpWPYcb2kLQqWll6CELCgzDYYk94KQ2nN8Ehc291QZu3kTWsW/KY8acOGDdjIyEhTsNevX2/kvvMKiMNyWIplhwjStP2FkuIinjpdLpOtp9GZI3MJxL/emZV+/VOLfd0fL9T9fV/jnaXWste/A7kVZAgW76G2FNLLBZpz7/00QXpXvaPyyiK/gJUmz/sdMTExFqWlpe6lirpVuwSnyz3Kul+3IHb9jCnsHMCwo1wgACrrGIzJaIUxaS0IWE2wdVbzr34VDcHJqcn6UL/izCPLuSXHV7pm1mfNJh5Ln1XUsnZZacsM5ul7gxLIgy3E0sxLSkpcaTTaeGR7gpwOAPzv3c1XvNaf+HDytMb3yOuWLUcvMDYxymJp/SOVueSJ/qwyBEvHBUKsu7A55w7sLrr7ILDu0kJf3w3PfeKXLl2KJReS7YQCwWSiqjVgPa+z1Y3c9RWkAytvcLCAVQGw7LKbf4pk18fl5uaM0P1MH8qJaIe0us9AyA4hUaBTSvWzkek1j7yy6yWLCC2hhKabPrSa7uc+SGA5ODiAnM7E19cXfO9fl+GYUP9u+TjN65rcnAwnd3d39EJzWWKXmeoHVaboefWwzwUaMeyAC9SyFtbs2z/Pk98ms2qabChBz6dzli9fjk1LS7NFzg9PsVy5aj+/gzWR2vmhJe7kLxBwgdmIC8xC3J/eBTbBmNRGeCah+aFEWbm7kEBEwVpAPeVnEl/VSy/1JsFRCqPcCkSBIxLUX49JqeyYkVOTtYnauolbe3HYH3Fff/e1uuMf02xVb308o+pRC4vFmLhixQrUT28IP4CtkGrGrqy6ozQXPXymLTLeH1AO0dFLEJIIA4bdjXvzvTmSm7kJNZ0vpG2mTZsGJcUlWDLZtDESsWRhsbI5fAXteMsoQsc3KFgZfWBNwLe8T5HVZErEUp+ImBj0Zo/KbTqDErf96aV+uRVgLaBgEQwFCZEtgB0ipbB7vPzK5NRK8oqi+gOEuovPTRH+Eov/+C40seFdOUb2JjxZ/eAiEuYuyMqN12fuW7ZswZLJZNfUxp54d+n9915UDtFzgWVX4eHMa28tkl6PKmq64NpV8+Ikd//+/WbZ2dn2DCZjgkSpXp8gbMldWX7s9LKyY7dSJa1ykaoqSigSLc7Ly9OfReaJ1d2oVb0ALEywGIaOCmEMAhQmkK/daG6F5FVIBGh9lP/N5GQF92B500Ifn8GvterSE/tVBTURq/KrIySnrjjFK54flf7ua9PJD6baq99+F5K+Abuqnn5dWtm0KTkh3cLwe8KjIswYDLpbbPW5o2Mldx9huff6wEJcoGE5REcvAbCAht2q/PLnI5lXOheJru5Kabxgdzjx+WfB4sWLobikJItSKs2Fx+NOFCvVq0SaugNKuXyjSChcgAQBLgEBAfrzxxvX3Kpj2I25wF6gdJbVH6yAPrAgBCzoEAs292f/5BYhfLKTqFk+ceJEo+vcQmpc4hUrabAPYH1t58/82itKWLsZp1gcnZryxwQhyVc+tJrU+N4ZrPxNGCMF+w3Yt/pBK7281NkPZ3xT/XNTsZlpmdYkVdPSxYrrdfaCu99CzymHGAo4QSJsTrn4kxutp2eh8ErIamHPBJxE89wDf/Y4B2iv/x5sSnKyZT6uwL4Qj7NLQkBcsHyx0XWto7astEmq/kILlErPsBtzgQhYR8VaoPRgaeklYFUgCUb3QSayGbBnrPgBYr3Ddb9jF6XFzS2UfwvjVw5j95bD0B7kK7JHBbPvBhKkU1auXPnqLWxO6/uxWPlbMHCBKFiS12Fz6evPdtfdTo1Jj7cY7N+kpKZacjmCcVHqM6HTxDcuWbBuP4MGcYGG0miUXupNhM1J52Bb8rn3vBgXhMtFl1bGVJ23zuvJ+7c/bNjRCLNQVtOhWfm13c7Jmk8sY1S/Aqv6LS4QBeqQDiwmPDJCCHO53Nnbtm1Dz+7pSfJl1keYP0N7dWCVodsUAW9JqpiZkZFh8+9e/0svZ807ZyEAFNiSN9ANEmFb2ZMvY9Wn5uLYaYM+/eHh4dic3Hz7EpFy3lblJZkV6+YzqLcijBK3AChqP4YdgAXoJWJfImxF7Pp2VOnZq37qq0G7dy/4t91JXk6uDZvLm4bjVx4OpVWXrybW3pyUVfW9FizxQLBQq+pzgVqwmHrLGhcl+EQkEq2IiIhAWY6luVUrHQIQVwmAMgAMi2yPYNYdJovtuW/fplfrDsfWvvsrCpb0DSOwQCLspnj0EAFsRkTw4SHdFUhy2UyWZ3RlV9oc8bWbWMOGg37lEJQLJJzTCjgNuEBMwSmUCxxNPvPWlLLOvCOVV5YFpnB+8wf38/Mzw+Pxzkwma7JMIl0ml8s305UNaYep1eLFucqTU9KUbzpHS36GdGAF9JG2fS6QCUMHGPCWfNlJgUCw+ODBg2igdaSsaTQC1lMtUGV6oFCwQtkfitS16yIjI19t54tHzTs/YQzBEj/tBUtL2tpJHn26VnPbLyQma0jAdvnFYIlkkiObxZ0UrurMGcu9+jHUe15BvQJOo3KIEb3US9zm9YliTHPa4ZGEk0+nlp4mxNZeX7rMb/5vAs7b2xtKSgq3yM7IsqGWVLixGQxvPk8wWyQWL5MrlTuJwpr0o9RK9qpc+emJCeKnrpEi2AQEGAhQw0N4P67Mkt5WqjVHQf6nyzdxefHYxRmyXJvDTCOgwJ4UwXkkEkuXxaakvFp9x5iqNxohqc4Fvo6ANZBhtxE//H6p5l5qJp353CTSL2iHCYlMcZbK5Qv3ys+Kx7MvvYdFwTJk2A0FnJ0D6SXABQLGAkmEofQWlLVwzj/20cTi46K94vPbcG09w593DUMsaMGCBSZIBGmOpAV2RCLRjcmieYlFwjlSqXSFTC7fJtbUx3Iqm3AqtSZEoZTvkohFs8PCwozO7HwG33l7gSLD9jDjFx1Qw/0ZP0SS5WzkfJsTFBT0ai0rpO3helvlG99qwepj2CE9w/4QZdiHCV/7ZUnVA2GsvP2FiWNCQhqS4LLH81WVa9cJzzfall74BjIqMuoEnMZWpSNtUcYC0EsArNQmWKteqkd1Fk7ZTd/7UDokS0qPr0ypvjzqRdcy1PLDTIV2zN1ompedaUOhUEaw6NwxbBbLm8FgepbRytz3h+4foAuJS4nEFhYVORIENUf2FqnPhJTIq9kyTbZMLttaWlo6atmyZa82Iiwm5Vn61d0KQ/KrD3QMO7p1XCBfCxZgLUyR7S65d3FL9U3fwMDDz3VNhw8fNsHhCu34Ytn0CMnx6BXcrnonyrnP9OUQAFbB6V6GvaOvHNJrVYCxwKRr6SVUwYSKYmpRnQUUXw1bJ9d+b59S+9gjp7F5NrE1ZnFJ27yKmjP/1pMNtB1r1qzBImeeyd69e01WrFgx5GcD34eci05sNns6cqYt4vF4cxGgRoeEhLy68v/q4x9sX9fx3hx6MQYiFRTbBNddOTxa9fhdYxeoA6qPC4TYd2Eb3t1P5yru5AbW3nA7GBP03KcpPT7JtLyMBj6cV6akad9abme1K7nrI4uizp+NXKCeCzzWSy+1wJheLlCnCdRLzeJ6pWYGOgubhMqvvLJrhUeolS7JFfte6RPeW5k2AcFVfHy8GeA4X+XvAyH7mc0N97eOHz8eDRyKSwpsI6vP7ndTPP4nJOrPsBvQS2zAst+Bzdh3YGfe7RuH6u6u8+ynOhpsbd26FZucnGzL4/OmkFWNhw4JOphjKJ1f6hl2BCxDFwjKIShQKS8vNTONUv68lVIfmZiSOGh+yD31xIx54sF/V/tr2bkH5s6at3/ZWnszITExES2TH+XNhPD4IvtiTeuqaZWvPYQMi4wG5RCUYQesBeM2ylhYsW59O1t2m3608owrOAde9Luj8jLMkAjNmcfnT+Iqa7bu558QTaKceAKaDfqsCpxXyFmlsyqdCzRULyFgoUD1k5otxVeJaXTaAAnZQlzDHudo2ccWwQJ4VKzsk+ER4nNeSXLFwrwa3LRU5dYYcedSxZlbz5UM/Clr95kPo0G47lv9WiOpuNjd8P/l4FKG8SXSycs1d9pMBL1tPAMY9tt6hl0njR7Bufn5ZNENXnzj1TEvcw2Ad0MeFCvkcB8N/D5dVR+wkd6m8S4+/rFVTtuvaO0qVae2BS6wTgvUYFIzFCw5ygXuJteoeFyu56xZs/QPzn7O6VUWIUKDRBjoLHrzq4O9+RWSW1keYcFjokRfOQRxL09JkreNiRDgluRWRSzPrV7LOnZ9Sh7pD+6+pN/6Eprc8F43SISRoOJfQpFiNrKMcqiM5P2mFTT66EPVV0ucxA++HYph14LV18wNcisb2tUfJguusRIaro6Nnv1yXYpbtmwxzc3Psecxud4yqXwZQ9UQtI/VKp9BbH3olN38M6phN3KBVYOWQ+xjlT+kszVZPA53PMi1dD/fM7WyEiVtAwzpJbZRIgzAgvbTtXsfDdkVMOABIbCRJBgwFi5HObBHOP9j91Be94RokXhnce2GQknDkPqMfWXtblPiVRq3UPFP3rHKB2tyq1bExxFfHvC86x97OFa+/YaOXtpfd6uIUJ7vuNXHmJtDDlFsUVGRC07dtstbduexid4F9oJlpLa91qe2RaVmPbAz7fIvPqKryuXCnsm4mvYXVmjBAnUtJBcahsPhnJlM5mSRSLQcyYO2p4haOQtJzQ+d02s/tUup+dEEDS5UqIYdgAUhLtAiWvHLntLas8j3b0Ou2ygXsw4Xd/dxgWwDeqk/WMjepwULAKXb2H58IHa3dpsi/21itLDnEEkz9ciREKP7ly3vsZ6RpKofdoANDzvMhYcdEcDu4bJPcxlKr+WzZ78cYIta35lprXrrMx1YI1VP3i2oObk0OSVpQNi7efNmbGEh3iFT2bbaR3ajxZp75wedC0SBeoHa1qTkPGxDOf++N/OSeLHw0t7o+ksvldD6+PhA4eHhZvn5+XaImxzJ4XAnSSSSJcWSGv94VnXyEVodZzmhpt0HV3vfLVn1eEZO1ZPA8mqZslITBJRLERERRmH08CjJ2UEZ9kP9gEKsCoNaFc3AqoyBMgTLZE85bIb8v5FB7EsHCsWTdiWu00eFqwvqjjgHCT4bdoiDgMWDrRCwrP1F8Nr8Gk5OfsHLkb4T6t5ZPUzxlp64hcSvw+PVj+8EV52bH1sYMKgFpKVlWZRwxRPCKrvjJgiv3zQHloWCpWXYMWUDyyH6Zm6CVmpmSez+ZTil++505oW8NYKLs0OrLr80S+23/QA2IyvHoghf6EAuIbsy6AxPDpc7SyAU+ErEkjWINW0QicVLmQyGV1pamhHl4xeNgWZlaUqAVUGo2nYgWJDOBfa6P8ivwsiqjIAyAku7zZHvX5IiouTl5OoDlDERYpztER487BAXtjrMh62PCGHrABE8JbHyEy6XPdEvdduLvc2yY++FY2Rv9HKBWg07FsmtvCsfX45v6Jmxc8uKQU00KOSoCY1W6lQu18zbquhhD2df/wRTbuACS3XSaAPStriPYQdtpxD+NNocZ0fo/Ny5+PTFuczz2cvY52YWNlwYNNQeaq1evRobFBQEJGUWmZmZ1hkZGbYpKSmWoKI92PcnMDVj5mSqT9qECL4fzAVqrYrRa1UAqL7zaiiwgFUBoEyRr2DPi+c3cdicichZiV7DnFR1rlOQ4BfgAq0Oa63KOlAMO4bKYalMtSo6MurF+o/NJz/AoWDpGfbXUcYCKJjmVT9SZEqqnRzWDVFI8x0NpaQlW7LYbO8IVWcqEki8bUa7ZmBVl40ZdkMuUE/cahl2KK8DNkW2W/GpJ1OpneV7JD2rd4UlvZLkMjAw37SYJZu2s7iSOzFB8qZ1ELcPrANMg8Ci4rlgGZK3OqsyRV1hBbwjR6zgCcSz1q5di9a/thEbDrkECz8FLhC1KgQsGwQs26MyWK6u3lVCJLxY5bu5430cZMSw92nYTYSPYHfZaxcTWq7M4+MyhrxxU6ZMwWZlZTkIRaJZIYou3DjOlfdBzxVGZ1VGDQc6ta1B570BvaQTcEJIIjwC1/7xhOITkqX0MyGZDZd+13abnMxMMyaDPgo5+xYKlTVH0lka/E68omFRuvTOuCjBR26hvF9MAGB+WjeoCyoGO69Qq9oLAgwtWJMiuB8wxOoYLps/AYms0fvGr2p2mBArO4FaFQKWTSBiWUFSeFJC5TcymXxzcX4xGDfx/EBjRs0b283kb8LQIGDpuEA78Wtfrq+6eygNH/xcv5qUmmpGKaU482WVi/dKuhgTWBffQOdZkHRWddagbtUrjdbTSwZcYC+9pJOagdzKOqPpZ/eC1kszSjoou3hdmxmtJ/5j7m3Tpk1QdEKiOZlIcSwtLXNnsViThULhQgTAtXK5bLtQXRMXX6YgBpIUkvVZwqZlaaLrM+N4T8eFsd7xiuT/PCKQBVvtp+mtarg/A16YKHhcJlRniUQS3+KCAv2ZtWuDB/ZASdVa1xDxZzoXODxUBsfRapUikXgJkmO+uNnhQPNdj9GaN16HJMY9Vxh9w8FrMFAvmfIfwFOU91Wk9qtjp28++NwnIDM/1YLNZo5GLmJOpOJU4QTG+XcgXXeIXsM+SDnEkF7SgZXSxwVCiVrWAhC3zhn1v4zJrj8zGddE3Ug/uZl2/PbvwTZA27dvN42Li7NCzj17kKog0acHnU6fiESVM5GgxVcqFa+WSiTrkCBmq1wh36tQKA8o1FXhqpq6JKVS6S+Xy3fzhKJ5ubm5DnPmzDG6T+k5WRZJdM3WlVnK6jXZynaCsJYmk8u3k0gkQES8OHzPZnHNNtfdDrCVP/1KV2TUNxzwe0WcvVygGffeM3fJvfNLVLe3RSo7nhsEkCi5ZkRyiS1fyJ2QKW85vIrbVT+a2v2mGaHrF8NyiKHaVs8FAoa9V23bnwvUNnNr6SWQCFvEV/5qk6B53zW1+sLo9JryeUUtQYuKmn3y6y7/R25zwoQJ0LZt27BhYWEAPPPk5ORheDzOjkqiOtPKKtzoNPoYPpfrxeEKJnK5nKkcDmsaEpFOZbNZniUUssOePXsGHBtkQhSWQiI7iqXy+TKZbL1MJl3NYrMmIGnJywdUoaGhFvvqbyfZyp7+APVzgYOpbYdx7nzlJbkj3VR9exFLXvVc13jgwAFsTkGBrUQimlSqqN+4T3CC6k3tvOdI7PwWyj+JBha6IqNhOQRK78+w18IYlGGv6uUCKwdwgUAQgw2XwTYxiq/sYhSvjUvTnJqSVU2ZmVu7exG+fnaIqHNsuebU7xK0WFtbQ0uWLEEB3bVrF1pOAV/XrFnzXAtZsGABBMr9SEphnZqaar1z586XIgiMFoVEsDvceDvPRvLoG4zAACwjte1dPReIZdyCbdi3PvcW365cV3lrDjk95rk3IS8xxYReRLbi8tijmRLV4mRxc9ga5skGN8KJf1jk93eBrQNcoBHDHtefXlIOFHCGiFG1LSZICJshX63DxF/YhYvfHBEtPTczU8Ocm6maE1le+981HVT19GvUXQBqp6CgwHlD1W2uhegR2s0I6aTRhlwg846x2hZJhD0Et9/coLkVEHF0t6lfwfP1cogfB6UR6+Li4pGAsC1UtMSupHecHlvc8ZFJljYK1JK2hmDVGnOB/cHqZdgHSs1EA6VmvayFW5T4rWU56s2kov+igZObT/7jKO7qeyj5CIpopWUlLjE158NHyR58oCsy9g0fGUzAqR0+AtpOR3NvfDxfeqMwQHXupWgkxK+bUoqpznwhb6pUJl+eJmnOWkJt6xpb1P4tZDAlBoCFSTAkbiu1YPVygYOrbUVDSM20nYxg2x7lf7olV7Ls6OGdgwImOPsQGy86M3d0uGBlNP/0SlX3vZGDfd/vuULFF8fPxnWwPTPauteVdqUu27Spz03ObHhbsKbhof+h8GDdIQdKFTbZiraV0xR3r2EBWEYu8NYALtB4tu1l2LHi8pcTOJcr/OturPAL8nzhkwsUQ8i5aV5YWOjM5fGnKxWK1fmyptS1ZS0d4wqaPxuWWq+NAtGzqq8cMqSGHVXbDmZVvSy7gdRsXppUSSkpAQ+XkUfYV9biMyZCcMsUJMYGSbDdESY8OowHe0eLvnH0Z96z2Ffe7RLI6faMEHbPSJB1z0tTdy/OqjqzIF3TNjNZXTUpTikZHSGlu4RISu2CxEUOwRLcBmLbxoCt7gPuy17W2akTs9o+cIxrgJ3iG+HhiS3wEcaJEOSh1rprF9XrTAfF069Sa88tXb++b6RpSlqmJU1aOW2v5kq5k/DeNxj2HRh6TsOBUed9iZYLNEHyKw9Gz40V4ishzNpTFn64aS8MTzOSj5qm47OsaFSqi1gkmoZETSuZyrrgfbQG6Sx8/V3XjNqf/m0XaNDMrWMs5qeIO7hstveKFX1P8Nbi+gkjgrm3ob0VAwScAxmLPtbC3I+GbDpsvo8BWx5gwZYHOSjDbnWEr2UsAsSwDZIIu0YqvztAbT5aSMg0qlJPyzlW6RhXjwLllNCEgrWK1N6BpA9jQPCCsZY+LoZET+FZmodNDJ5E34y2YMFaKCs725LDF3r5qS9kjRTe/ifKsA8oh2gbDvRcILlHTy9BvVygLfnsF+5l55rmcC7GbpKc92K1q15obf5H/LFZmdkWpGLScCRMHsvn8+cWCzV+oRWatG2UWsW03Oq7I5IrP7GLV/2oHZOgGz4iHsIFcvupbVmwCbK34+RKvoA3JSipT5Dpk6FOsj3C/KE/a6EnbfcM5AIBWGa9YFnsZyJgsQ3A6uMCAVh2wQp4RnrtQ6ZQ5rkpaDd6L3Lqb7uMS2t+oLMqp4RmBKxWeHPpidtsNnsa6MLEjKt8iseInsDm4sfwfPVdcly68Vi5zNBQkzI6dXi2qn3TPOn109bsW99DBiN9Bms46D8uFSVukUTYtLDzVzti5zsTys/KF3LOHzmsujz6RaCBBZq3IyIizHJycmxB2yifx50kEkoWksXVh2PpmuQ9lGrx/DzNJY8k5dtO0bLPbSIkKFiQDqz+GnZkgw4RzxjhRyS+Oh5JeMfvCFqltyx7fyYZ69dnVQPAMqSY+oO1D4DFQsEahoBlhXKBApRht+7lAm0RsOxDVXAMoyE6JzMXrQpMzmob5xzf8JZTHAJUPGJVCS3w8KRWeCOp7QQSiM1Dm9NXtb6djhFqpWZmokc/zlTeKSgRyO23+MXoXdZU36lQfm7+MLZQMvGIrDN6iuDaNQv69Z+NxntTLvU2HPSCRdR23huOS9XSS1ou0LzgBGyLO/F0EvWM2IfWudZPenFsRrn0pSKz5ORobFRMnHl2dp4dkv27gK575AP5iJXqjblsVVAYVZW3j1ylXpgp65ieKn/NPVr0D8dQwafWR7mf2QdzPxsdKfhwVbbsciG3Ei8SiZbk5+faJtf46j/v2Ag+wfIgfci6VR/LXq4HS+sCAVhMFCwAFFoOQV2gUG9VNkflsF2IErYLU8NBFc2yYpK2W3N6dvO4EQkNb6NgAatCwHJOaoNjOK0iMFEgKioKsSzlow2GPcLmgteeLat5TVled2wEZpTxobt9+3aT/Px8pzJZ1eJd8osSK/rVH4xfR2HIsA8+29ZIagZYCyRct8w59pNDfvubvowublrdhZfSbBguoOsLDAw0i4uLs0auzxkM4eLwebNEEtESmVy2XqyqDijiqGLSy6UJeJYiRaTSRCnlyj0SsWQJsbjEZfXq1cZ9V0XVfnb+zI+GJG37AaU/r/bRUbB0VjXQBWqtSgdWGL1ZSSoho5qXwoZbY8ent75p6ALHZrTDInVNdEVFhdf+/ftNMItrH8+1kT75Qqe2BbmVqeA12FtxvzGpvtuj/43x9QuB8IVEKyaL6VmiaT+4RHyp27L8ChJYXOo3fOSsMReIHzgudYDaFgnXbbNbfvQmHL86lXQ8K6768mSf4JG/WZTi6uqKDT4cY4Z4AysikeRQTCa5VpSVj2OymRPpTOakigq6F5VCGZWPI9gunjVvwM8vJBZazU+RVljsp/08MLAoH+S80lkVo88FHuIYFRltgiR6F2iHuMARURqYIqnLKKsoQ4+CXDrPdEp227Hh8drAArjAbeS2HrlMsQWPx4+YDUr/hJO3HMarn97sk0b35VYu4vuPt1Td3hlNSBgw92Hz+hXYjOwMGzaXMyFPfSxkLv/iHXMwj32w4SNG8yx09JIxFwilN+sZdiCNBlPNTJH8yj23+ekEXItsTcXJHayOq/9pzxOEeRnCdPZKiFpR4RRKVkYtShae947gvOt2FAlI9pbro8C+2lW53qp0gYXeBSJg2RgEFra9LnBsvOaHJHZTPZKibC8uxut7rANZHWumZB/70Dvz2A9bSo5dVVVWh/FFgumrVq3SBj9bo0OgyOYby20kYLS3bvhIH72ERUL2afL7J49qznn4Jg3sq916OBZbWJRnx2VzppbVdoQt45/rtKWc/2mwkT7GDHt73zwLw3JIMhg/18ewo4lwrFZt65BS/Z1XXsPlqQVNeH9x98KXuvH/5goLiMCSyER75LyYKhKKlqIse1VtNFFQVRRVIiWFkBTy/XhF46YscfPiBF7rqgzp1dWZisdL0+RPFibLnsxLlj2dn6x4uihN9WR1btXT9fnVNzbla05EVdSpuPLqZKlMupXNYk/0D8/SG0JBVqI5j82dJJNJN8nlsm0CAW9mSlyMcQUZ8flmm6rvZJsLHg4p4BwhuPvJzqqbm2PjUwedrrJ06VITGpPjIhQKZ5ZUd8RPo3ffsyV1fQ+Gj0C6idGDlUPStWBhUgeWQwzVtoM1c3tm1b4/v6hZuLCwfnWo+Ix7EVf1u4MHuk2OHj1qBc5CoGFHzg9vJpM5BXRBIunEAuTzLhZLxKvEYvFa5AzcIJFINgNggaoK2TtkUul28HeZTLlFIpNvEIlFy5BQfEZxcfEoJHcawE0iZ5M56CkrLCwcceDAgcFrdrzKypG+lXdrTPkIUAbN3Og8C4Y2EbZm3fzKS3ir2ld6bVlufcuAH5ScGAvlFCBRI4flXiapXBopbIlazOzsGl58+guowGCkT3b70C5wUHpJY9DMregb7BimnWdhFSX/0T5a8WRCRlXX9OzqopnZ1evWFjd5Kbru/G7Ty0aMGIEy7MHBwaahoaFmSChtkZiYOAxoPnKzcHYFBQQHPA7vRCAQhpeUUEaUlJS6FBeTXSklJNeSEvIIahnZmVhU5JiVkWkTExNjvnLlyiEj38mTJ0NTpkwZ+sFLJyRiqRLF2CWVt+uGCYy5QHTrEuHy67A1/frnk4Q3RBvV1xYzjrcOeDpmzJgBgSSOTCU7Cfj8KTnSFv/N7BNKb/KJe7a4jh+g3ikxUOZAF2jUcKAHq79VKdBxqf0770ESDHIrq1AxbB0qes8+XHzVK0nV4J2kzFtWULv2YGnj8Jr23yCq/CuvhMJYE5ZM5bWj+qbcknvvmR4sA4ZdRy+BQcQ2tKv/mim+ISXXnBpUhbq2JAM6HBJiipg8ChpXqlyTJGrJX1h+4r5tXjvKsOvaeAyLjCgPaDSFcyBYg3GB6PCRQAPWAmUsOKg02iqI94N7tOSSuKN73B98W1/dQiIPE0o5w32V/DLZinP7R3BeQXRjLhBjyAWSgdr20gdzBVeSOCevOyZOCxz0yQU/NyUlxRrx+x5A58DW1B/dQmvTeBOO/dMkrUnbc5WkjQKNGw76a9i1DPvLcYED1baTk2Q30nLS/rIj6EQ9T02F3a8/332LH342NrLr/dngz2BYMINePsJffSFpBO/W5xD9hvEgYj291JdbgU5G29IL307lXJIHVF2bFR47Y1CfDMowkaEh5gRioSOLwfGSymRLibLGWD9mq2pqYfNT67T6XzGDgGVYDnnxPIs+sAYIOJEdRK1JRoKGAa0+4TWnoIUZarzdEeZVu8OMS5Nixafdgtk0jzA+bj2utmBOkuKgd6Ro5R5Ky0pay7Xl6rP3vdhtt3+TxnGotYtxduTcotMaj8zjP7qltf+0sLjrQhapYpif3xARr2/9Gw0H1ZecF4cWQBv2boCysrJspXUtKxdJr3diaf0Y9tLB3nPVjSbCFsXdz7zpF04sFfSEVjQff17/E3TkyBHz3Nzc4WVlZeNAdMVR1hwJZTezfQkN59yz6r4ydIFAww5IW8yL5lkEGDLs7AGd96uypSrQrdJ/xuDUBBkN2js0Y6HjAg0ZC0skt3IO4sOe0TJ4ZnLlr5MTVJ85h0iuu4TJur3iNd1zshq6l+PbOudkN6vHJtZWLChoC4nmHTeynAj5TS/PrOP/BPSSc3IbPCL5GLoD6W0BMcFhgz8ME5UP8sbL7p+OFdWM3B6rzanIOVnWQjF38nr5JbVFxbWf+tS2g8y2BWpbgrHadnRp97urBRcPJladHx6fkjPk4Q4q1UjYakEik12EAtZkiVTiq1TKt+FkLaUbyQ1n3NM0/7CLV/2EHWL+EjTI8JGB8yy0YB0sVqsYDMYkJCrTpyH5NdccHMFci+fSS4OUQ/YPLIdY6bjAo1LYJlgG2/bSS3YRlfDw6Bp4U0l7xlH/vuHPs/GnuE6AtUhsRflAAJRLSjucyGlOJ+KIA15fha6Q5tuzrPj3fnYX3enaob66OCkhGBu7ex6UlZZlLpDKJu6SnS10Z19534R6+RdoABeoBQuDMuzGibAF7uQzZ+Kpu16UTsZK7tkVsVUXrMNPZQwK3KZNu6Co2CjTvPxCK0ppqQuSBkwA5ZEKiWZXHLMqzZ9WL1lcoOnySFK+5RQj/8o6UvoLalkGgQWknxjNHqBhtw9kPysValJAvhQUFKRn2tfgandBvWN9+jcbDAmWAb1keUjLsKMiTpRhN6CXAFjhlbB9hAa2j6qGF+Y3n6OQyaN9fHywssvvmUzK7fjUEKgRCFBe2R0/ChUaf5AKDApWKj7abJLi/lmQWznz77y1WH7dr0CkQs0wLy/VhEQljSAqm9esFJ5XOFb0fDmQuDVm2A25QKg3t7LOP/6NC/5493TqacLCipM+6u6rz9V4A706UAPl5xbaVNBoI7k83gShSOgjUVZuzOFUhkeWV+btJFYqF2YrL3nEip+6RIo+dQgTPjPxN3aB5kdYv7iEcv4VVVapkcsVG5EkdziSyOsfmM2E+uShOkP6k7b9wdLSS31coFWAMcMOyiE6sByiauDFBU13+DyeD3JuWuQ3PZjjbGBVzghYYzKOP9tfcbwbSbTXJCUN8ZqppA04aFf1jW3DOHe0r05i3/pyquQmd4+yx5NF8YHWLVoEZaRmWNDZXI9QcXuQD/f8OSSo+M5oYnThEPMs+jVzA1GMTXbLl+64Y+emFLdHLyk7sShG0f3cKGjtkc1QITEGG5eWbJaRnWNFKCIOLy8rB0raSXwBf75YKltDEqj8EypU6YFkJW0LTlHvk8Rv2ZAnbY2gKjlkoTpNIpGsL6OWjV6+fLmRBGwnsXaJmWEJ/zkMu77IOCjDrnOBxgw7alWRVbAj4gZ3lTQ2CwXChUAvODm3YyUgbp2TWlGgXFPb4U3k9ssCVXUM4qonIlH00GWjfBLRZpby/msALN1gx0ni26ejqzvHYpIWoU/inj17TEqKSS4SiWzBPkkXx6Xs/DdQPy4Q0w+sPoZ9oDTaNKUeds1t/sAL31pxQNS1gtnS+dJaujFjxuhUtNY4HM6RRCKNYjIZE0WI9Ykl4uWomFKh2CKTSdcif19EJpPd9+7dOyCRp9IqrUYGc94c2gUal0MsDIuMaN2Kp2fYgQsEVqVj2FGrQoCyj6qC3RPrnmVyG8hcLmcWEuCYTsvrWAUYdp1VIX//iiJrLJLL5RszMzOfP0hzzf5J2H2Ks0vsOLc+MexkdGBe/2KV8kbkgS270UPZNyQJCjgYZUYpK3OTVNVtXMPtrBpB6foaVIQhFKwTgw8fSe8bRKxNhEFu1TfPAots18z6LzxyGqtXUI8HirruOvtuHfabWIeA2enYDSu2mSQnxVniCous87MzbfOy06wi/EKH1AlO81sJZTBUC2bFC6/ZH6b3Muu6UojhWaUDq/e80hcZedq6VYAxw24XptJblXNMLbyX3HhepVLvQR4qoJSCyI0XRiKR4FcgCpyDO/4JQdxIFkuka8sqaGN8fX1fQlKdE2qxUH6DbErvN9iRehn2YF97sF5xbV9AAkH/9JNyiq24XPZ4gUK9eh//JGsM+fSHerWtDiy92nYQeql/532Mru0UzLPQwCPTal6fXtDAiZCd3Sg5cfGVjUKISQmxEAq4E+QKxWa+uj45sUxBCiWrVPsL5S3Lkngtq9KlNxenSB7PjBU88QrjPfUMF7w/PUH2w5R4Bewdo4DHRSvgMUiKMQZJNTxiKmHPhCp4SmotPCuz/lvf3LrXImkNVapKTaBQxJsan6rtLA2ZNgYqkzXPI8nbEhXqKn+JTLYCaOwBifBSF10S7gmlSmrdvQQ3enTNcdpXJ2nVSxbUHngc63JbcM31RasPr0Z96q4tPti0vALLCipjlEihWhYi6qDMpp7oscGd6J0YPXTDwYD3XA0xLtUM+eqRVv2vhfj65Iz9/r9ddvwSKyR6Dza/IN+WSCS4lFPLxrGYrMlsDneGUMifLxKLlohF4hXIXo0c/uulUskW5AwE7PpOxN3uUchl+5CvYO8HXxFXdkCpUIA/70b2VolEvILBZHompBnP5QgOO2RWhER9lFLqSHIJzqZ/Q8MLV3RmhNlm6fkDjqzrHxs2c+t0FiYlF352LLvwdC7/Uo6f9KyLX3Ex+gvAWwkoxSQHHk8whSKp3nyI2142idR+xy7/2HemmUBt29JPbVvXj7QdZJ5Fv0TYKkL6+WZi1WYwiud3xEm/gI5x3bp16ID+2NhYi4SEhGHZ2dk2YA4vGP1DJBKdETfmCuYzUanU0eBtC3Q6fTyTyfQCehDkzxN0G/wdzIUHs+tBIzqqUhpkgd+3adMmbP/Rri+9SKUVNsGqLr/R7KuPgQs0SoRJ2rZT0+Kz8AjqufsLeBfDI2svu+6J3YH+soCwYJNsfJ4VB7T+yJWL4nj1UTsZbcKJhLYHjtnN35mmas8rTGL/4SMD6aW+91xJ9aStZ4rqPqj5oNqEfmt3edvIdcVNK9YUNSw4SDs2RnXu/qt4w4Gu6gyBsQ1gzsbOnTshMKR/7dq1+g1SD0CxYf6ImfDF2SSrbFnL4nn8Cy3WZZd+QtVLg+RW5oQzvw4v6bo3g3E2c7fs3BgS7ih6caAuExUVBYY0OjEZjHECuWpZqqAh+hCjmTGH0HTFObP+I+uUWjS4gAaM9FEOsCqUsQgWwu4Jyl/BmDgkYjIq9c/NrVlpHyp47BQmhO2D+d/ZBHFedwsXnveIFvFnpKpw0xKlu1fkVy8bH8n3zFGfG8Nr7vnvak543kry84OyUnKsRXLZ3I3ic0qnip7v+7edQr2iGBAFmuNPPfOkdrXtkV1cGpDkZ+SmwuIOm+LweDs6g+UhkohnIQf5unxxQ/oWakPjbHz9bbeM2u+xLwMWYllT01UfC4XCpYhrMgpvPeLl58C7riCUsTDsvNeOSTA7QIfHRol+tDnMuDApTnpiVCiXsixHkwlAjBWeWqnsvDUC89++wiLizBhM+hiarHrdWkF3rS3l/I8Q4ezgiTASBVoUnPh1LOXMW8s53eElVOoANwR6bWNiYoYB5Q7oLOTz+fMkUulGkrQ+LYhRL11eVH1qYkblk9Gpml/MI5EAo1dtiw0WwRNTlZ8XCasIwLIMBwezj3VbWgRyB+m8B0BVGE2JwfbOtu3PWoDBI+4hPHhcOP+zEQGsczMSZMdHBfNoC9PVuCVZVYGbChtXURquLZa2X3+ueEfa+RS7ldq5ZEZOa9l8XEe1b1FHXKysZ+KrwGbQJeh+6lSQGWWDREjjCOq2w0vYZ47ZlXT/qO8R1r+NR/ueK6g3CnQp7Hh/NvV0Rrj64rTBfi440BHfbpaSkmxDpZDdWEymt1AomCORilcoFLJtMk3NUaK0vrBAWFssqWrMVqqUh6ViybLc3Fwn5JzQW2+x7KSlVRBvwPARzD66fkyCdq7F0M3cWH1e1Ztb6fMrel9uhSTCLsGij9Zkqxds8wsbEOTsZ58dNj2zmeccXQ07RFXDjtG1sGNsPTw1u+0enl87qvcMe7Ur6+w769eoboWF0dS2RSSCg5DHnkCrbNqzlH3mjDUBsax8Xef98X6JcAuym2HLzOafvYjHu1YzOw8Vt9/wAj/zfs2gBy+EJIRYQMckJSXZFBQUOIG+27KysvFgEwgENyRSA5yi0b8tjtlq4hUvuwDpBo/0A8twRIIhSAPnWfSxFn30Ek0v4LTsHemzIEXGLaOUjfLtdx3z81qKnSK1ibADAphTTD0MNOzeGc0fFotq14aFhb3690bGtz8ctlR+s2CO8GrJLm7LmIyoyGEVtLKRZdLq5ds5x8vHkU+9YVlw4tngXKA2EcYi2zaz6RO3vJbbC6kd+DRunXWxJO55TxoECNeDBw+aIMCZJicnm+7evdtksKfTr8QHu5NUfcQ2iPMVpB/powOrwmj+0otk0SZ7Bqpt9Qx7LxfokyhWCQX8mTu2LNNb1xbqyYnucdVvaFmLapQLdIypg50QsJYXtt7iS+QrQDrwSgDqvwJYDXYLhZcFo2kXrsxjnz8QWiazz0hPtKIzWaNpUvXSg9xjRV6kjtcsctufQf3UtsbN3LWwWVItvKCklUfMy7Xatn1wOcBvXfEp8RZHKaqDSzKkxybE8B+OCuP+0yGQ9YVdAPNX8wO9M5j29k4201sV1Uhxq3OBQ4E17CAXtvXnwwGkSqFYJFlw+Mge/Zk8J6e5yCG8EnZALAtYFXCBw+Pq4dWE5teKxXV5HCTBBgqp3+OzvnCFB8yC4tiaUVMZZ9U2pO4fxpWfO7We3zXv4BE/06SMVMuKsjJXmrRq2QHOMdJMcvtV65y2H/SzAvs3cyPh+rDkmh85Vc1L8vJy9aWS8Aw+tIDYttMjo1bgnVWD8y1qWh8hOPXSLynLzs6y5vE5E8H7GTlyzf4sujwyjqrICygSFwWWqCpXpwsbfZME5+YnCh96BDOfjAlhfeQayPjM/lDFv5wRUG0QUM0NSyH9GfZDPHhqnOyDcqEmUsATTFu6ebfesiak1J+xR8HSusDRifU/7ShpOi9SVsfIZbJVZDLpj31fZHpKoklchdRzEefccUDc2hI7P90t7Qkk5+0xSYpcDuXmpFiUIpm9UCpbkCBqyfMuOvYxhA4i7pVGJxrqAjUwv/Z4WCmZoh+FsJ3dGWsepfheF64Pi5T/MDJRdW0ztTVG0nHppeZd4JJiTDKykoelp6c7EIoII8FMdjAGj8vjzgGDh8Ui0UqJWLJeKpPvQG5kCFWgiskqlyRl0JSECJKEHEKUssNLq7s3Zkkvz43j31iSrvrJK1oCg2FZU+JkX+O41XSxRLKS0PvOLrDKk3yh6RlNdcAFAvc3P7fps1xhk1StVgfx+QIfIqnYZfOObX98D3NaWpwZjcX2WMLpbgHle0v8KXhyeXebn6jLJzliAxYECKmJmZZsLnusTF25ejetiTulsPmRearB8JG4Knhqft37CoVqSzmNBsZ8Q6GKi272CZWPjN5zBTSBvVIz51gFPDZJdWV6ZhVxL+3YGgqSV7/M9VpbW4NrMtm+fTsQaFqCiS5ZWVn2SLDiTCQSR5LJZA8ajTaBxWJNBSmBQMBfIBGLlkkksjVSuWwjmDijUin2KZSKgyql8qBMIV9fVlY+euvWrXqXNtrXDwqltcxdVVAnTGE3sFRqTaRCpdguEnCnJSQkWG/cuPHPazYPDDhoUkYvH7mJd0Zu2lu7ssad+G5ORRclmNMIklUoqcAXys3OHQY+GF8gmJMhbExaT6mvXoCvbt5fUV8jU1dHCgS82VnZWag8bAGxZZxltPJtHVjQAFGMwOi9ITYhAnhUjOSed6KC45NZeTRD3e2zbqXDv3v+obQQAHW330HTqNhoi/SstGHx8UnW2WnZdnl5BY54PGFECYnkUojD2x7at2PAzc+KiTWl02lgdOx0Bos9oQBf5BgUGPrXeKEniMrI5DLXQ8JTRY6FJ7+Del/151rY8XQVqysrJXyv/kJ37Nhhmp+f74gkwd7g6QUdfUALgURHVrraDamm1Xx2fh3dBGgDdVKz4KGkZn0jU0EnIxqyH2SAN/L86BEl6nKPFBYvyqr0z1N3T/mDbwvUO7rur6f+TcvLM+OKlJ572O2Zowgdb4F5FtjMVtg6p/WrSaTj9ADBCX07KhhuFRUXYQ4mrABeD8mXzA1LAr6BvlBEiXzc/PxqjXOc4l8mIX0CTqO2UzDccYiXvOgmcJodYsA2/qzPHALZ98dHiVo8o4TFizMrt7PE6r/Gk/5nLcA20xkVw9PFDRvnUNrbEaB+AA0HIGT3wB+7lsauGhUdrB19s4p5atTskuMrF5A7FuQ2Xhmgjp0+fTqWWlrqlsvVHNhJVLPmZqkujYiWfGIRLPi1r5mbO+hs275EmGaUW+lYC/P9FT/6pknjg4KChkxMN+Brp85NVsaMjxAfGxki7JqeoFRtLar6o63z1a70ogSovKzQisqVTDzAbE6bRWo7Z5vV9D2IAo+wmoPLysuG57VetxuZ09Ruk1IL2yTVfOuWWXdlVlFz6nxiy9pgcfdoccfbqJVlZIRjycXFtkw2fZxYLJpL4Fce8ierSCvzlKfGxonfdAgVfIftrwschF4yBArb+/qkMaGcjxH36xkWFmbEuPuRlNazk+R4R3/2R8P2M37VqpeYqC5wTITkaSpV4rE1YPVfz7X9JwsUIMEAEp5YMjuOW5+0nXHsJE9Zs13I53gEybo97dLq3zJsOADl+2Gx6h8dEiqfzi1slubWXl7hV6Jl7NdvWYaNiw0zL8ATHIFqF4wQEsnV29LpqpTDZE3Nwgz5Y7ujPPSFZBjg/gzB8qMZ0Us6LnBEIBMGLy5DokGjNMAzQlBuuY+mb+a2QOdZsPWimP0EdUJOZuZ/5+txn7e8vLyg7ORMSwat3F0oEs+VSwUzSkuITrzj3dbjC5pOQbHqAeV7CG040PZcuSZW/mNSZjVvL+P4Bry6yyGtZiM0depULJBbkygkJxaDNU4sEfvIZNKVYlV1YEyFumxjrrRhQar4zvgo/mf2gSz9IGLDcanD9tPg7XkyVJMHZgLqrjcLCULAoMfBpGaAXnJEolAiTxNZUkodvsNv33/PvKffukAoDN6irePzdhTJJ/sUNdaZgaqwDqjeNxwYNRwEawMLu0jpt14p6vrVxIYd9BNabeEWzARoxYoVJogrs0RuuiOYwgI6EpGEd6FUKlmH5EK7ZdXN6fmcKkIwUVRyBC+gxFJkFIm6Nl2uUOxkMBiTQUOc7hrxlV2jXAPZX/Yx7H30kj0SzAQUK6uB7gJJsm11Lzz7f7Hy0hNNGSzaqHxRXeDGkvp2r8zqT21iVcZFRn3PVZ+GHUKCi+GRkq8npSiVO8gNM/v/3DFjxmCBhjA1C29dWIhzolBIbqVUqgeLzZ3AYrMm8wX8qVwOdwIFyZMCAgL6V4ihHKbKZ12WrGZSJO/J5GjRl1OiRR9uzlWcLxbW0JVK5R7ghsGr5f+g2/TXWaARATkzHMF7p0A/LlNZG7OdXHdydJLyQ7so+bOBI30MGw7Q5jh4XqYSv4ugHEtKih70Sa/p0eZuw32HQ3OWYExGYWyfm/sgZ605jUbzRs6z1aAnGCiWQD8weFMDFQF969at/zsSgN+6Fi5cCN6EYA6UtHQGY6xAIJxTLq3aE0/XpO8iVclnpitvjYgWf2wXLvoR2++FzyBct/DnwBMTpMcK6UKjTosdJc2ec9KUO5GEGOcYyMY5+LNwi9KVBwNK69xedE2gXxhIBcDYIaBIAhNsEDdrB17W9uruxH/Z2rR/H5Sem2WWl19gU0KmuDAYTG8BXzCfLFQfTKCrU/YVq0WLshQ9Y2KET90iBZ/aBLI/twtifz4jUXyFKVbNBfUu8HN8c6qCbANY7wCtheHrKCz2V/w0KUbYFR8f/1temvn/52z6TxY4GxISEhCrw9tVlNNcBUL+RIlENF8ql68rF2sCkqnSiEy6LIYtUe9jMBleBw4cQMFyOsq9oE+EDQZlgUY4LzBvHQksQNL9Z3++/9m1a8oyCJ8ZYIbLy7IuoZQAkeXIClqFF5PDmoycMZ6ZWRm2ukhzepKUpdNZ6F74DCbDjA1l/yuAKJeBPG3VqlX/v+mmP2FBmEHG++RnEGwTK1RBgWS1OoisbgotUUiIvEqCSlUZpJArNoEuk/7/5u/1Jy28fyCWRCLYM1hMbx6PO4PL484Eb0IoLy8fQySWOCJR6N8u8C+4ICsrKyySwIKz7H8CoP8Dy42jJBqCo+QAAAAASUVORK5CYII=",
};
