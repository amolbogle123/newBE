import htmlDocx from 'html-docx-js';
import fs from 'fs';

import { OcrReader } from "../../../entities";
import { dataSource } from "../../../core/data-source";
import { PdfToTextService } from "../services/pdfToText.service";

export class OcrReaderService {
    private pdfToTextService: PdfToTextService = new PdfToTextService();

    async deleteRelatedFile(configData): Promise<any> {
        return new Promise(async (resolve) => {
            try {
              if (configData?.fileConfig) {
                let fileConfig = JSON.parse(configData.fileConfig);
                let docUrl = fileConfig?.ApiResponse?.document_url;
                if (docUrl) {
                    const urlObject = new URL(docUrl);
                    const pathnameParts = urlObject.pathname.split('/');
                    const filename = pathnameParts.pop();
                    await this.pdfToTextService.deleteFile("docs", filename);
                }
                if (fileConfig?.ApiResponse?.images_data.length > 0) {
                    fileConfig.ApiResponse.images_data.forEach(async (element) => {
                        let imageUrl = element?.imageUrl;
                        if (imageUrl) {
                            let fileName = imageUrl.split('filename=')[1];
                            await this.pdfToTextService.deleteImageFile(fileName);
                        }
                        let image_url = element?.image_url;
                        if (image_url) {
                            const urlObject = new URL(image_url);
                            const pathnameParts = urlObject.pathname.split('/');
                            const filename = pathnameParts.pop();
                            await this.pdfToTextService.deleteFile("images", filename);
                        }
                    });
                }
              }
              resolve(true);
            } catch (error) {
              resolve(false);
            }
        });
    }

    async generateDocxFile(requestBody, filePath) {
        return new Promise(async (resolve) => {
            let apiResponse = {
                data: null
            };

            let pageData = "";
            requestBody.fileData.forEach((p, k) => {
                if (p?.text) {
                    if (k !== 0) {
                        pageData += '<br/><br/><hr/><br/><br/>';
                    }
                    pageData += `<div>${p.text.replace(/\n/g, "<br />")}</div>`;
                }
            });

            const htmlString = `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8" /><title>Document</title></head><body>${pageData}</body></html>`;
            const docx = htmlDocx.asBlob(htmlString);

            fs.writeFileSync(filePath, docx);
            if (fs.existsSync(filePath)) {
                apiResponse.data = filePath.replace('./public', '');
            }

            resolve(apiResponse);
        });
    }

    deleteUnusedFile(ocrRecords) {
        return new Promise(async (resolve) => {
            try {
                for (let record of ocrRecords) {
                    if (record?.modelType === "pdf-to-word") {
                        if (record?.fileConfig) {
                            let fileConfig = JSON.parse(record.fileConfig);
                            let docUrl = fileConfig?.ApiResponse?.document_url;
                            if (docUrl) {
                                const urlObject = new URL(docUrl);
                                const pathnameParts = urlObject.pathname.split('/');
                                const filename = pathnameParts.pop();
                                await this.pdfToTextService.deleteFile("docs", filename);
                            }

                            await this.deleteImagesOcr(fileConfig);
                        }
                    }

                    await dataSource.getRepository(OcrReader)
                        .createQueryBuilder()
                        .update(OcrReader)
                        .set({ fileConfig: '', isDeleted: 1 })
                        .where("id = :id", { id: record.id })
                        .execute();
                }

                resolve(true);
            } catch (error) {
                resolve(true);
            }
        });
    }

    deleteImagesOcr(fileConfig) {
        return new Promise(async (resolve) => {
            try {
                if (fileConfig?.ApiResponse?.images_data.length > 0) {
                    fileConfig.ApiResponse.images_data.forEach(async (data) => {
                        let imageUrl = data?.imageUrl;
                        if (imageUrl) {
                            let fileName = imageUrl.split('filename=')[1];
                            await this.pdfToTextService.deleteImageFile(fileName);
                        }
                        let image_url = data?.image_url;
                        if (image_url) {
                            const urlObject = new URL(image_url);
                            const pathnameParts = urlObject.pathname.split('/');
                            const filename = pathnameParts.pop();
                            await this.pdfToTextService.deleteFile("images", filename);
                        }
                    });
                }

                resolve(true);
            } catch (error) {
                resolve(true);
            }
        });
    }
}
