import fs from "fs";

import { OcrReader } from "../../../entities";
import { DataSource } from "typeorm";
import Container from "typedi";
import AwsS3 from "../../../utils/awsS3.util";
import path from "path";

const s3UploadDir = "./public/s3-files/";
const sourceType = "s3";

export class S3 {
    static syncFiles(config, userDetails): Promise<any> {
        return new Promise(async (resolve) => {
            if (!fs.existsSync(s3UploadDir)) {
                fs.mkdirSync(s3UploadDir);
            }
            const response = { status: true, data: [], error: null };
            try {
                const s3Client = await AwsS3.getAwsS3Client(config);
                if (!(s3Client && config?.bucketName)) {
                    response.status = false;
                    response.error = "Please again configure account";
                    resolve(response);
                }

                const command: any = await AwsS3.listObjV2Cmd({
                    Bucket: config.bucketName,
                    MaxKeys: 10,
                });
                let isTruncated = true;

                while (isTruncated) {
                    const result: any = await AwsS3.s3ClientSend(
                        s3Client,
                        command
                    );
                    if (result) {
                        const validateResult: any = await this.validateFileStatus(
                            result,
                            userDetails,
                            s3Client,
                            config
                        );
                        if (validateResult?.data?.length) {
                            response.data = response.data.concat(
                                validateResult.data
                            );
                        }

                        isTruncated = result.IsTruncated;
                        command.input.ContinuationToken =
                            result.NextContinuationToken;
                    }
                }
                    
                resolve(response);
            } catch (error) {
                response.status = false;
                resolve(response);
            }
        });
    }

    static checkFileStatus(userDetails, sourceTypes, sourceIds) {
        return new Promise(async (resolve) => {
            const response = { status: false, data: [] };
            try {
                let whereCondition = `WA.CLIENT_ID = :client_id AND WA.FILE_SOURCE = :sourceTypes AND WA.FILE_SOURCE_ID IN (${sourceIds.join(
                    ", "
                )})`;
                let params = {
                    client_id: userDetails.client_id,
                    sourceTypes: sourceTypes,
                };
                const results = await Container.get(DataSource)
                    .getRepository(OcrReader)
                    .createQueryBuilder("WA")
                    .where(whereCondition, params)
                    .getMany();

                if (results?.length) {
                    response.data = results;
                }
                response.status = true;

                resolve(response);
            } catch (error) {
                console.log("--->checkFileStatus", error);
                resolve(response);
            }
        });
    }

    static insertFileDetails(userDetails, fileDetails) {
        return new Promise(async (resolve) => {
            const response = { data: {} };
            try {
                const ocrReader = new OcrReader();
                ocrReader.clientId = userDetails.client_id;
                ocrReader.name = fileDetails.name;
                ocrReader.filePath = fileDetails.filePath;
                ocrReader.fileSource = fileDetails.fileSource;
                ocrReader.fileSourceId = fileDetails.fileSourceId;
                ocrReader.createdBy = userDetails.id;

                const result = await Container.get(DataSource).manager.save(
                    ocrReader
                );
                if (result?.id) {
                    response.data = { insertedId: result.id };
                }
                resolve(response);
            } catch (error) {
                console.log("--->insertFileDetails", error);
                resolve(response);
            }
        });
    }

    static validateFileStatus(result, userDetails, s3Client, config) {
        return new Promise(async (resolve) => {
            let response = {data: []};
            try {
                if (result.Contents?.length) {
                    let insertedKey = [];
                    const sourceIds = result.Contents.map(
                        (c) => c.ETag
                    );
                    const fileStatus: any =
                        await this.checkFileStatus(
                            userDetails,
                            sourceType,
                            sourceIds
                        );

                    if (
                        fileStatus?.status &&
                        fileStatus?.data?.length > 0
                    ) {
                        insertedKey = fileStatus.data.map(
                            (f: any) => f.fileSourceId
                        );
                    }

                    for (let c of result.Contents) {
                        let key = c.ETag.replace('"', "").replace(
                            '"',
                            ""
                        );
                        const fileExt = path.extname(c.Key);
                        if (
                            key &&
                            insertedKey.indexOf(key) === -1 &&
                            [".jpg", ".jpeg", ".png", ".pdf"].indexOf(
                                fileExt
                            ) > -1
                        ) {
                            const filePath = s3UploadDir + c.Key;

                            AwsS3.downloadFile(
                                s3Client,
                                config.bucketName,
                                c.Key,
                                filePath
                            );

                            const insertResult: any =
                                await this.insertFileDetails(
                                    userDetails,
                                    {
                                        name: c.Key,
                                        filePath: filePath,
                                        fileSource: sourceType,
                                        fileSourceId: key,
                                    }
                                );
                            if (insertResult?.data?.insertedId) {
                                response.data.push(
                                    insertResult.data.insertedId
                                );
                            }
                        }
                    }
                }

                resolve(response);
            } catch (error) {
                resolve(response);
            }
        });
    }
}
