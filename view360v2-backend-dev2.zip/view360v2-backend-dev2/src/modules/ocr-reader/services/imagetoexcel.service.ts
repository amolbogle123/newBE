import fetch from "node-fetch";
import fs from "fs";
import FormData from "form-data";

export class ImageToExcelService {
    private static BIG_FILE_THRESHOLD = 4 * 1024 * 1024; // 4MB
    async createJob(tokenKey: string, filePath: string): Promise<any> {
      const fileSize = fs.statSync(filePath).size;
      if (fileSize > ImageToExcelService.BIG_FILE_THRESHOLD) {
          return this.handleBigFile(tokenKey, filePath, fileSize);
      } else {
          return this.handleSmallFile(tokenKey, filePath); 
      }
    }
    private async handleSmallFile(tokenKey: string, filePath: string): Promise<any> {
      return new Promise(async (resolve) => {
        try {
            let params = new FormData();
            let fileStream: any = fs.createReadStream(filePath);
            params.append("input", fileStream);
            params.append("dup_check", "False");

            const apiFetchResult = await fetch(
                "https://trigger.extracttable.com",
                {
                    method: "POST",
                    headers: {
                        "x-api-key": tokenKey,
                    },
                    body: params,
                    redirect: "follow",
                }
            );

            const jsonData = await apiFetchResult.json();
            resolve(jsonData);
        } catch (error) {
            resolve(null);
        }
      });
    }
    private async handleBigFile(tokenKey: string, filePath: string, fileSize: any): Promise<any> {
      try {
          const fileName = filePath.split("/").pop();

          // Step 1: Get presigned URL
          let params_step1 = new FormData();
          params_step1.append("filename", fileName);
          const presignResponse = await fetch("https://bigfile.extracttable.com", {
              method: "POST",
              headers: { "x-api-key": tokenKey },
              body: params_step1,
              redirect: "follow",
          });

          const presignData = await presignResponse.json();

          // Step 2: Upload file to S3
          let formData = await this.createS3UploadFormData(presignData.fields, filePath, fileName);
          const uploadResponse = await fetch(presignData.url, {
              method: "POST",
              body: formData,
              redirect: "follow",
              headers: {
                "Content-Length": fileSize.toString(), 
              },
              timeout: 120000,
          });
          if (uploadResponse.status === 400) {
            try {
              let errorText = JSON.parse(await uploadResponse.text());
              console.log(`errorText=`+errorText);
            } catch (er) {
              console.log(`Request failed due to invalid parameters.`+er);
            }
          }

          if (!uploadResponse.ok) {
              throw new Error(`File upload failed with status ${uploadResponse.status}`);
          }

          // Step 3: Trigger extracttable job
          let params_step3 = new FormData();
          params_step3.append("signed_filename", presignData.fields.key);
          const triggerResponse = await fetch("https://trigger.extracttable.com", {
              method: "POST",
              headers: { "x-api-key": tokenKey },
              body: params_step3,
              redirect: "follow",
          });

          return await triggerResponse.json();

      } catch (error) {
          console.error("Error processing big file:", error);
          return null; // Or throw an error to propagate it
      }
    }
    async azureApi(filePath: string): Promise<any> {
      try {
          // const fileName = filePath.split("/").pop();

          let params = new FormData();
          let fileStream: any = fs.createReadStream(filePath);
          params.append("file", fileStream);
          // console.log('process.env.AZURE_IMAGE_TO_EXCEL_UPLOAD_API_ENDPOINT', process.env.AZURE_IMAGE_TO_EXCEL_UPLOAD_API_ENDPOINT);
          const presignResponse = await fetch(process.env.AZURE_IMAGE_TO_EXCEL_UPLOAD_API_ENDPOINT, {
              method: "POST",
              headers: { "data-key": process.env.AZURE_IMAGE_TO_EXCEL_API_KEY },
              body: params,
              redirect: "follow",
          });
          // console.log('presignResponse', presignResponse);
          // console.log('presignResponse.status', presignResponse.status);
          // console.log('await presignResponse.text()', await presignResponse.text());
          const presignData = await presignResponse.json();
          console.log('presignData', presignData);
          return presignData;

      } catch (error) {
          console.error("Error processing big file:", error);
          return null;
      }
    }

    async azureStausApi(jobId: string): Promise<any> {
      try {
          // console.log('process.env.AZURE_IMAGE_TO_EXCEL_BATCH_API_ENDPOINT', process.env.AZURE_IMAGE_TO_EXCEL_BATCH_API_ENDPOINT);
          const presignResponse = await fetch(`${process.env.AZURE_IMAGE_TO_EXCEL_BATCH_API_ENDPOINT}?jobid=${jobId}`, {
              method: "GET",
              headers: { "data-key": process.env.AZURE_IMAGE_TO_EXCEL_API_KEY },
              redirect: "follow",
          });
          // console.log('presignResponse', presignResponse);
          // console.log('presignResponse.status', presignResponse.status);
          // console.log('await presignResponse.text()', await presignResponse.text());
          // if (presignResponse.status === 400) {
          //   try {
          //     let errorText = JSON.parse(await presignResponse.text());
          //     console.log(`errorText=`+errorText);
          //   } catch (er) {
          //     console.log(`Request failed due to invalid parameters.`+er);
          //   }
          // }

          const presignData = await presignResponse.json();
          console.log('presignData', presignData);
          return presignData;

      } catch (error) {
          console.error("Error processing big file:", error);
          return null; // Or throw an error to propagate it
      }
    }

    private async createS3UploadFormData(fields: any, filePath: string, fileName: string): Promise<FormData> {
      const formData = new FormData();
      for (const [key, value] of Object.entries(fields)) {
          formData.append(key, value as string); // Explicitly cast value to string
      }
       // Read file content into a Buffer
      const fileContent = await fs.promises.readFile(filePath);
      formData.append("file", fileContent, fileName);
      return formData;
  }
    // async createJob(tokenKey, filePath): Promise<any> {
    //     return new Promise(async (resolve) => {
    //         try {
    //             let params = new FormData();
    //             let fileStream: any = fs.createReadStream(filePath);
    //             params.append("input", fileStream);
    //             params.append("dup_check", "False");

    //             const apiFetchResult = await fetch(
    //                 "https://trigger.extracttable.com",
    //                 {
    //                     method: "POST",
    //                     headers: {
    //                         "x-api-key": tokenKey,
    //                     },
    //                     body: params,
    //                     redirect: "follow",
    //                 }
    //             );

    //             const jsonData = await apiFetchResult.json();
    //             resolve(jsonData);
    //         } catch (error) {
    //             resolve(null);
    //         }
    //     });
    // }

    async updateJobByJobId(tokenKey, jobId): Promise<any> {
      return new Promise(async (resolve) => {
        try {
          if (!jobId || !tokenKey) {
            return resolve(null);
          }
          const apiFetchResult = await fetch(
            `https://getresult.extracttable.com?JobId=${jobId}`,
            {
              method: "GET",
              headers: {
                "x-api-key": tokenKey,
              },
            }
          );

          const jsonData = await apiFetchResult.json();
          resolve(jsonData);
        } catch (error) {
          resolve(null);
        }
      });
    }

    async checkKeyStatus(tokenKey): Promise<any> {
        return new Promise(async (resolve) => {
            try {
                const apiFetchResult = await fetch(
                    "https://validator.extracttable.com",
                    {
                        method: "GET",
                        headers: {
                            "x-api-key": tokenKey,
                        },
                    }
                );

                const jsonData = await apiFetchResult.json();
                resolve(jsonData);
            } catch (error) {
                resolve(null);
            }
        });
    }
}
