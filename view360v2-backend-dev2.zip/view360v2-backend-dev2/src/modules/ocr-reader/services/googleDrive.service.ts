import fs from "fs";
import path from "path";

import { dataSource } from "core/data-source";
import { OcrReader, WidgetAccount } from "../../../entities";
import { DataSource } from "typeorm";
import Container from "typedi";
import GoogleDriveUtil from "../../../utils/googleDrive.util";

const googleDriveUploadDir = "./public/google-drive-files/";
const sourceType = "googleDrive";

export class GoogleDrive {
    static syncFiles(config, userDetails): Promise<any> {
        return new Promise(async (resolve) => {
            if (!fs.existsSync(googleDriveUploadDir)) {
                fs.mkdirSync(googleDriveUploadDir);
            }

            const response = { status: false, data: [], error: null };
            try {
                let folderId = null;
                const urlArr = config.folderId ? config.folderId.split("/") : [];
                if (urlArr?.length) {
                    folderId = urlArr[urlArr.length - 1];
                }
                if (!(folderId && config?.connectorId)) {
                    response.error = "Please again configure account";
                    resolve(response);
                    return;
                }

                const widgetAccountResult: any = await dataSource
                    .getRepository(WidgetAccount)
                    .findOneBy({ id: config.connectorId });
                if (!widgetAccountResult?.config) {
                    response.error = "Please again configure account";
                    resolve(response);
                    return;
                }

                const widgetConfig = JSON.parse(
                    widgetAccountResult?.config
                );
                if (
                    !widgetConfig?.token?.access_token ||
                    !widgetConfig?.token?.refresh_token
                ) {
                    response.error = "Please again configure connector";
                    resolve(response);
                    return;
                }
                const tokenDetails: any = await GoogleDriveUtil.getToken(
                    widgetConfig
                );
                if (!tokenDetails?.token) {
                    response.error = "Please again configure connector";
                    resolve(response);
                    return;
                }

                const drive =
                    await GoogleDriveUtil.getGoogleDriveClient(
                        {
                            client_id:
                                process.env.GOOGLE_DRIVE_CLIENT_ID,
                            client_secret:
                                process.env.GOOGLE_DRIVE_CLIENT_SECRET,
                            redirect_uris:
                                process.env.GOOGLE_DRIVE_REDIRECT_URI,
                        },
                        {
                            version: process.env.GOOGLE_DRIVE_VERSION,
                            access_token:
                                widgetConfig.token.access_token,
                            refresh_token: tokenDetails.token,
                        }
                    );
                if (!drive) {
                    response.error = "Please select valid drive";
                    resolve(response);
                    return;
                }

                const fileResult: any =
                    await GoogleDriveUtil.getFileList(drive, {
                        folderId: folderId,
                    });
                if (fileResult?.error) {
                    response.error = fileResult.error;
                    resolve(response);
                    return;
                } else if (
                    !fileResult?.status ||
                    !fileResult?.data?.length
                ) {
                    resolve(response);
                    return;
                }
                
                response.data = [];
                const fileInsertResult: any = await this.fileInsert(
                    fileResult,
                    userDetails,
                    drive
                );
                if (fileInsertResult?.data?.length) {
                    response.data = fileInsertResult.data;
                }

                response.status = true;

                resolve(response);
            } catch (error) {
                response.status = false;
                resolve(response);
            }
        });
    }

    static fileInsert(fileResult, userDetails, drive) {
        return new Promise(async (resolve) => {
            const response = { data: [] };
            try {
                let insertedKey = [];
                const sourceIds = fileResult.data.map(
                    (c) => c.id
                );
                const fileStatus: any =
                    await this.checkFileStatus(
                        userDetails,
                        sourceType,
                        sourceIds
                    );

                if (
                    fileStatus?.status &&
                    fileStatus?.data?.length > 0
                ) {
                    insertedKey = fileStatus.data.map(
                        (f: any) => f.fileSourceId
                    );
                }

                for (let f of fileResult.data) {
                    const fileExt = path.extname(f.name);
                    if (
                        fileExt &&
                        f.id &&
                        insertedKey.indexOf(f.id) === -1 &&
                        [".jpg", ".jpeg", ".png", ".pdf"].indexOf(
                            fileExt
                        ) > -1
                    ) {
                        let fileName =
                            new Date().getTime() + fileExt;
                        const fileDetails: any =
                            await GoogleDriveUtil.getFileDetails(
                                drive,
                                f.id,
                                `${googleDriveUploadDir}${fileName}`
                            );
                        if (
                            fileDetails?.status &&
                            fileDetails?.data?.filePath
                        ) {
                            const insertResult: any =
                                await this.insertFileDetails(
                                    userDetails,
                                    {
                                        name: fileName,
                                        filePath:
                                            fileDetails.data
                                                .filePath,
                                        fileSource: sourceType,
                                        fileSourceId: f.id,
                                    }
                                );
                            if (
                                insertResult?.data?.insertedId
                            ) {
                                response.data.push(
                                    insertResult.data.insertedId
                                );
                            }
                        }
                    }
                }

                resolve(response);
            } catch (error) {
                resolve(response);
            }
        });
    }

    static checkFileStatus(userDetails, sourceTypes, sourceIds) {
        return new Promise(async (resolve) => {
            const response = { status: false, data: [] };
            try {
                let whereCondition = `WA.CLIENT_ID = :client_id AND WA.FILE_SOURCE = :sourceTypes AND WA.FILE_SOURCE_ID IN ('${sourceIds.join(
                    "', '"
                )}')`;
                let params = {
                    client_id: userDetails.client_id,
                    sourceTypes: sourceTypes,
                };
                const results = await Container.get(DataSource)
                    .getRepository(OcrReader)
                    .createQueryBuilder("WA")
                    .where(whereCondition, params)
                    .getMany();

                if (results?.length) {
                    response.data = results;
                }
                response.status = true;

                resolve(response);
            } catch (error) {
                console.log("--->checkFileStatus", error);
                resolve(response);
            }
        });
    }

    static insertFileDetails(userDetails, fileDetails) {
        return new Promise(async (resolve) => {
            const response = { data: {} };
            try {
                const ocrReader = new OcrReader();
                ocrReader.clientId = userDetails.client_id;
                ocrReader.name = fileDetails.name;
                ocrReader.filePath = fileDetails.filePath;
                ocrReader.fileSource = fileDetails.fileSource;
                ocrReader.fileSourceId = fileDetails.fileSourceId;
                ocrReader.createdBy = userDetails.id;

                const result = await Container.get(DataSource).manager.save(
                    ocrReader
                );
                if (result?.id) {
                    response.data = { insertedId: result.id };
                }
                resolve(response);
            } catch (error) {
                console.log("--->insertFileDetails", error);
                resolve(response);
            }
        });
    }
}
