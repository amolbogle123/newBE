import fetch from "node-fetch";
import fs from 'fs';
//Live
// const apiUrl = "https://ocraibackend.epikview360.com";
// const pythonApiUrl = "https://ocraibackend.epikview360.com";
//DEV
const apiUrl = process.env.OCR_PDF_IMAGE_URL;
const pythonApiUrl = process.env.OCR_API_URL;
export class PdfToTextService {
    async readFile(filePath): Promise<any> {
        return new Promise(async (resolve) => {
            try {
                filePath = `${process.env.BASE_URL}/${filePath}`;

                if (process.env.BASE_URL.includes("localhost")) {
                    filePath =
                        "https://v2dev.epiksolution.org:8080/file-sample.pdf";
                }
                const url = `${apiUrl}/read-multiple-pdf?file=${filePath}`;
                const apiFetchResult = await fetch(url);
                const jsonData = await apiFetchResult.json();
                resolve(jsonData);
            } catch (error) {
                resolve(null);
            }
        });
    }

    async readFileAsPythonAPI(filePath): Promise<any> {
        const response = {
            status: true,
            data: null,
            error: null,
        };
        return new Promise(async (resolve) => {
            try {
                filePath = `${process.env.BASE_URL}/${filePath}`;

                if (process.env.BASE_URL.includes("localhost")) {
                    filePath = "https://ocraibackend.epiksolution.org:8080/public/media-assets/1722332879714.pdf";
                }

                const imgPathUrl = await this.getPdfToImg(filePath);
                if (imgPathUrl?.status && imgPathUrl?.data?.list?.length) {
                    const imgUrl = imgPathUrl.data.list.map((f) => { return {image_url: apiUrl + "/get-file?filename=" + f.url}; });
                    response.data = {
                      images_data: []
                    };
                    response.data.images_data = imgPathUrl.data.list.map(obj => {
                      return {
                        url: obj.url,
                        imageUrl: `${apiUrl}/get-file?filename=${obj.url}`,
                        height: 'auto',
                        width: 'auto',
                      }
                    });
                    response.data.pageCount = imgPathUrl.data.list.length || 1;
                    const imgToData = await this.getImgToReadData(imgUrl,filePath);
                    if (imgToData) {
                        response.data = imgToData;
                        response.data.pageCount = imgToData?.images_data?.length || 1;

                        if (response.data?.images_data?.length) {
                            response.data.images_data = response.data.images_data.map((f, k) => { f['imageUrl'] = imgUrl[k]['image_url']; return f; });
                        }
                    }
                }

                resolve(response);
            } catch (error) {
                console.log('--error - readFileAsPythonAPI', error);
                resolve(response);
            }
        });
    }

    async pdfToDocConvert(requestFilePath): Promise<{ responseCode: number; status: boolean; data: any; error: any }> {
      return new Promise(async (resolve) => {
        const methodRes = {
          responseCode: 500,
          status: false,
          data: null,
          error: null,
        }
        try {
          const filePath = requestFilePath;
          const url = `https://www.ocrwebservice.com/restservices/processDocument?gettext=true&outputformat=docx`;
          const readStream = fs.createReadStream(filePath);
          // console.log('readStream', readStream);

          const response = await fetch(url, {
            method: 'POST',
            headers: {
              Authorization: `Basic ${Buffer.from(`${process.env.OCR_WEBSERVICE_USERNAME}:${process.env.OCR_WEBSERVICE_LICENCE_CODE}`).toString('base64')}`,
            },
            body: readStream,
          });
          methodRes.responseCode = response.status;
          if (response.ok) {
            const jsonData = await response.json();
            methodRes.status = true;
            methodRes.data = jsonData;
          } else {
            methodRes.status = false;
            methodRes.data = null;
            if (response.status === 401) {
              methodRes.responseCode = 400;
              methodRes.error = `Request failed due to invalid credentials.`;
            } else if (response.status === 402) {
              methodRes.error = `Request failed due to insufficient credits.`;
            } else if (response.status === 400) {
              try {
                let errorText = JSON.parse(await response.text());
                if (errorText && errorText.ErrorMessage) {
                  methodRes.error = `${errorText.ErrorMessage}`;
                }
              } catch (er) {
                methodRes.error = `Request failed due to invalid parameters.`;
              }
            }
            
          }
          resolve(methodRes);
        } catch (error) {
          methodRes.status = false;
          methodRes.data = null;
          methodRes.error = error;
          methodRes.responseCode = 500;
          console.error('1.error', error, '1.error');
          resolve(methodRes);
        }
      });
    }

    async getOCRWebServiceAccountUsage() {
      return new Promise(async (resolve) => {
        const methodRes = {
          responseCode: 500,
          status: false,
          data: null,
          error: null,
        }
        try {
          const url = `https://www.ocrwebservice.com/restservices/getAccountInformation`;

          const response = await fetch(url, {
            method: 'GET',
            headers: {
              Authorization: `Basic ${Buffer.from(`${process.env.OCR_WEBSERVICE_USERNAME}:${process.env.OCR_WEBSERVICE_LICENCE_CODE}`).toString('base64')}`,
            },
          });
          methodRes.responseCode = response.status;
          if (response.ok) {
            const jsonData = await response.json();
            methodRes.status = true;
            methodRes.data = jsonData;
          } else {
            methodRes.status = false;
            methodRes.data = null;
          }
          resolve(methodRes);
        } catch (error) {
          methodRes.status = false;
          methodRes.data = null;
          methodRes.error = error;
          methodRes.responseCode = 500;
          resolve(methodRes);
        }
      });
    }

    async downloadDocFromURL(url, localPath): Promise<any> {
      return new Promise(async (resolve) => {
        const res = await fetch(url);
        const fileStream = fs.createWriteStream(localPath);
        res.body.pipe(fileStream)
        fileStream.on("finish", () => {
          fileStream.close();
          resolve(true);
        });
        fileStream.on("error", (err) => {
          console.error('downloadDocFromURL.Download Error', err);
          resolve(false);
        });
      });
    }

    async getPdfToImg(filePath): Promise<any> {
        return new Promise(async (resolve) => {
            try {
                const url = `${apiUrl}/pdf-to-img?file=${filePath}`;
                const apiFetchResult = await fetch(url);
                const jsonData = await apiFetchResult.json();
                resolve(jsonData);
            } catch (error) {
                console.log('--error - getPdfToImg', error);
                resolve(null);
            }
        });
    }

    async getImgToReadData(filePath,pdfUrl): Promise<any> {
        console.log("filePath", JSON.stringify(filePath));
        let requestBody={
            "images":filePath,
            "pdf_url":pdfUrl
        }
        return new Promise(async (resolve) => {
            try {
                const url = `${pythonApiUrl}/process_image`;
                const apiFetchResult = await fetch(url, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(requestBody),
                    redirect: "follow",
                });
                const jsonData = await apiFetchResult.json();
                resolve(jsonData);
            } catch (error) {
                console.log('--error - getImgToReadData', error);
                resolve(null);
            }
        });
    }

    async deleteImageFile(fileName): Promise<any> {
        return new Promise(async (resolve) => {
            try {
                const url = `${apiUrl}/pdf-image-delete-file?filename=${fileName}`;
                const apiFetchResult = await fetch(url, {
                    method: "DELETE",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    redirect: "follow",
                });
                const jsonData = await apiFetchResult.json();
                resolve(jsonData);
            } catch (error) {
                resolve(null);
            }
        });
    }

    async deleteFile(fileType,filename): Promise<any> {
        let data={
            "fileType":fileType,
            "filename":filename
        }
        return new Promise(async (resolve) => {
            try {
                const url = `${pythonApiUrl}/delete-file`;
                const apiFetchResult = await fetch(url, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(data),
                    redirect: "follow",
                });
                const jsonData = await apiFetchResult.json();
                resolve(jsonData);
            } catch (error) {
                resolve(null);
            }
        });
    }
    async imgToWordConvert(imgUrl): Promise<any> {
      let images=[{"image_url":imgUrl}];
      let methodRes = {
        responseCode: 500,
        status: false,
        data: null,
        error: null,
      }
      const imgToData = await this.getImgToReadData(images,"");
      return new Promise(async (resolve) => {
        if (imgToData) {
            methodRes.data = imgToData;
            methodRes.data.pageCount = imgToData?.images_data?.length || 1;

            if (methodRes.data.images_data?.length) {
              methodRes.data.images_data = methodRes.data.images_data.map((f, k) => { f['imageUrl'] = f['image_url']; return f; });
            }
            methodRes.status = true;
            methodRes.responseCode = 200;
            resolve(methodRes);
        }
    });
    }
    async extractTableData(imgUrl): Promise<any> {

        return new Promise(async (resolve) => {
            try {
                const response ={
                  data: null,
                  status: false,
                }
                const url = `${pythonApiUrl}/extract-tables`;
                const apiFetchResult = await fetch(url, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({ "image_url": imgUrl }),
                    redirect: "follow",
                });
                const jsonData = await apiFetchResult.json();
                response.data = jsonData;
                response.status = true;
                resolve(response);
            } catch (error) {
                console.log('--error - extractTableData', error);
                resolve(null);
            }
        });
    }

}
