export const imageToExcelData = {
    JobId: "3jBqubRf6sBaZTAc3eIC6AwWuQARwBW7gNI36Puz_dj5AUevblj_1708427091_1",
    JobStatus: "Success",
    Lines: [
        {
            CharacterConfidence: 81.17,
            LinesArray: [
                {
                    Line: "DATE",
                    WordsArray: [
                        {
                            Conf: 99.91,
                            Loc: [0.071, 0.0166, 0.0981, 0.0341],
                            Word: "DATE",
                        },
                    ],
                },
                {
                    Line: "MODE",
                    WordsArray: [
                        {
                            Conf: 99.83,
                            Loc: [0.1255, 0.0157, 0.1561, 0.0331],
                            Word: "MODE",
                        },
                    ],
                },
                {
                    Line: "PARTICULARS",
                    WordsArray: [
                        {
                            Conf: 99.45,
                            Loc: [0.2192, 0.0141, 0.2895, 0.0326],
                            Word: "PARTICULARS",
                        },
                    ],
                },
                {
                    Line: "DEPOSITS",
                    WordsArray: [
                        {
                            Conf: 99.75,
                            Loc: [0.5431, 0.0162, 0.5919, 0.0354],
                            Word: "DEPOSITS",
                        },
                    ],
                },
                {
                    Line: "WITHDRAWALS",
                    WordsArray: [
                        {
                            Conf: 99.67,
                            Loc: [0.6257, 0.0162, 0.7047, 0.0343],
                            Word: "WITHDRAWALS",
                        },
                    ],
                },
                {
                    Line: "BALANCE",
                    WordsArray: [
                        {
                            Conf: 99.76,
                            Loc: [0.7599, 0.018, 0.8055, 0.0359],
                            Word: "BALANCE",
                        },
                    ],
                },
                {
                    Line: "01-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.93,
                            Loc: [0.0689, 0.0533, 0.1224, 0.0696],
                            Word: "01-01-2024",
                        },
                    ],
                },
                {
                    Line: "B/F",
                    WordsArray: [
                        {
                            Conf: 99.36,
                            Loc: [0.22, 0.052, 0.2357, 0.0682],
                            Word: "B/F",
                        },
                    ],
                },
                {
                    Line: "14,769.99",
                    WordsArray: [
                        {
                            Conf: 99.41,
                            Loc: [0.7619, 0.0553, 0.8055, 0.0731],
                            Word: "14,769.99",
                        },
                    ],
                },
                {
                    Line: "UPI/336535150643/UPl/narayanad938-1@/Unio Bank of",
                    WordsArray: [
                        {
                            Conf: 44.06,
                            Loc: [0.2207, 0.0774, 0.4321, 0.0966],
                            Word: "UPI/336535150643/UPl/narayanad938-1@/Unio",
                        },
                        {
                            Conf: 98.78,
                            Loc: [0.4412, 0.0791, 0.4647, 0.0948],
                            Word: "Bank",
                        },
                        {
                            Conf: 99.86,
                            Loc: [0.466, 0.0789, 0.4761, 0.0951],
                            Word: "of",
                        },
                    ],
                },
                {
                    Line: "01-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.95,
                            Loc: [0.0692, 0.0888, 0.1227, 0.1058],
                            Word: "01-01-2024",
                        },
                    ],
                },
                {
                    Line: "IICla855c4gee56e490ba8040bd3500c6d8d",
                    WordsArray: [
                        {
                            Conf: 25.96,
                            Loc: [0.2207, 0.1003, 0.4144, 0.1167],
                            Word: "IICla855c4gee56e490ba8040bd3500c6d8d",
                        },
                    ],
                },
                {
                    Line: "1,000.00",
                    WordsArray: [
                        {
                            Conf: 99.96,
                            Loc: [0.665, 0.0909, 0.7033, 0.1082],
                            Word: "1,000.00",
                        },
                    ],
                },
                {
                    Line: "13,769.99",
                    WordsArray: [
                        {
                            Conf: 99.21,
                            Loc: [0.7615, 0.0909, 0.8051, 0.1089],
                            Word: "13,769.99",
                        },
                    ],
                },
                {
                    Line: "UPI/336517082897/UPI/arunkumarswain7/A Bank",
                    WordsArray: [
                        {
                            Conf: 36.29,
                            Loc: [0.2206, 0.1212, 0.4179, 0.1379],
                            Word: "UPI/336517082897/UPI/arunkumarswain7/A",
                        },
                        {
                            Conf: 99.58,
                            Loc: [0.4313, 0.1229, 0.4549, 0.139],
                            Word: "Bank",
                        },
                    ],
                },
                {
                    Line: "01-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.93,
                            Loc: [0.0698, 0.1328, 0.1232, 0.1492],
                            Word: "01-01-2024",
                        },
                    ],
                },
                {
                    Line: "Ltd./AXI7ff25d8174ab4087bag41071c2ef9b3b",
                    WordsArray: [
                        {
                            Conf: 32.71,
                            Loc: [0.2214, 0.1421, 0.4278, 0.1588],
                            Word: "Ltd./AXI7ff25d8174ab4087bag41071c2ef9b3b",
                        },
                    ],
                },
                {
                    Line: "8,598.00",
                    WordsArray: [
                        {
                            Conf: 99.5,
                            Loc: [0.552, 0.1343, 0.5914, 0.1529],
                            Word: "8,598.00",
                        },
                    ],
                },
                {
                    Line: "22,367.99",
                    WordsArray: [
                        {
                            Conf: 99.61,
                            Loc: [0.7607, 0.1346, 0.8048, 0.1525],
                            Word: "22,367.99",
                        },
                    ],
                },
                {
                    Line: "01-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.94,
                            Loc: [0.0703, 0.1739, 0.1235, 0.1901],
                            Word: "01-01-2024",
                        },
                    ],
                },
                {
                    Line: "JPI/373171412878/Request fromAm/amazonpayrechar/Yes",
                    WordsArray: [
                        {
                            Conf: 28.43,
                            Loc: [0.2255, 0.163, 0.4852, 0.1837],
                            Word: "JPI/373171412878/Request fromAm/amazonpayrechar/Yes",
                        },
                    ],
                },
                {
                    Line: "Bank Ltd/APY83b424cd18754cbd98b705aa590a5360",
                    WordsArray: [
                        {
                            Conf: 86.3,
                            Loc: [0.2213, 0.1852, 0.2446, 0.2009],
                            Word: "Bank",
                        },
                        {
                            Conf: 44.66,
                            Loc: [0.2436, 0.1857, 0.4608, 0.2042],
                            Word: "Ltd/APY83b424cd18754cbd98b705aa590a5360",
                        },
                    ],
                },
                {
                    Line: "2,000.00",
                    WordsArray: [
                        {
                            Conf: 99.89,
                            Loc: [0.6639, 0.1761, 0.7025, 0.1938],
                            Word: "2,000.00",
                        },
                    ],
                },
                {
                    Line: "20,367.99",
                    WordsArray: [
                        {
                            Conf: 98.92,
                            Loc: [0.7605, 0.1761, 0.8041, 0.1939],
                            Word: "20,367.99",
                        },
                    ],
                },
                {
                    Line: "UPI/336525805818/UPl/arunkumarswain7/Axis. Bank",
                    WordsArray: [
                        {
                            Conf: 30.01,
                            Loc: [0.2226, 0.2066, 0.4327, 0.2239],
                            Word: "UPI/336525805818/UPl/arunkumarswain7/Axis.",
                        },
                        {
                            Conf: 93.32,
                            Loc: [0.4318, 0.2088, 0.4547, 0.2242],
                            Word: "Bank",
                        },
                    ],
                },
                {
                    Line: "01-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.91,
                            Loc: [0.0708, 0.2175, 0.1239, 0.2337],
                            Word: "01-01-2024",
                        },
                    ],
                },
                {
                    Line: "Ltd./AXI1a133e7a2dc7401695e639ab013b1828",
                    WordsArray: [
                        {
                            Conf: 20.99,
                            Loc: [0.2248, 0.2278, 0.4325, 0.2441],
                            Word: "Ltd./AXI1a133e7a2dc7401695e639ab013b1828",
                        },
                    ],
                },
                {
                    Line: "1,360.00",
                    WordsArray: [
                        {
                            Conf: 99.71,
                            Loc: [0.5529, 0.2197, 0.5904, 0.2382],
                            Word: "1,360.00",
                        },
                    ],
                },
                {
                    Line: "21,727.99",
                    WordsArray: [
                        {
                            Conf: 93.27,
                            Loc: [0.7598, 0.219, 0.8037, 0.2371],
                            Word: "21,727.99",
                        },
                    ],
                },
                {
                    Line: "01-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.92,
                            Loc: [0.0715, 0.2586, 0.1243, 0.2742],
                            Word: "01-01-2024",
                        },
                    ],
                },
                {
                    Line: "UPI336533976963/UPl/panigrahichinky/State Bank Of",
                    WordsArray: [
                        {
                            Conf: 45.8,
                            Loc: [0.2238, 0.2497, 0.4233, 0.2697],
                            Word: "UPI336533976963/UPl/panigrahichinky/State",
                        },
                        {
                            Conf: 99.83,
                            Loc: [0.4268, 0.2518, 0.4495, 0.2676],
                            Word: "Bank",
                        },
                        {
                            Conf: 99.38,
                            Loc: [0.4514, 0.2519, 0.4624, 0.2673],
                            Word: "Of",
                        },
                    ],
                },
                {
                    Line: "500.00",
                    WordsArray: [
                        {
                            Conf: 99.88,
                            Loc: [0.6707, 0.261, 0.7012, 0.2769],
                            Word: "500.00",
                        },
                    ],
                },
                {
                    Line: "21,227.99",
                    WordsArray: [
                        {
                            Conf: 98.96,
                            Loc: [0.7595, 0.2612, 0.8027, 0.2781],
                            Word: "21,227.99",
                        },
                    ],
                },
                {
                    Line: "I/IC1308d64b1bc1d44cbge2c7f50933c6ad7/",
                    WordsArray: [
                        {
                            Conf: 20.88,
                            Loc: [0.2218, 0.2711, 0.4136, 0.2876],
                            Word: "I/IC1308d64b1bc1d44cbge2c7f50933c6ad7/",
                        },
                    ],
                },
                {
                    Line: "01-01-2024 ICICI ATM",
                    WordsArray: [
                        {
                            Conf: 99.84,
                            Loc: [0.0717, 0.294, 0.1252, 0.31],
                            Word: "01-01-2024",
                        },
                        {
                            Conf: 90.31,
                            Loc: [0.1256, 0.2938, 0.1468, 0.3102],
                            Word: "ICICI",
                        },
                        {
                            Conf: 99.49,
                            Loc: [0.1474, 0.294, 0.1695, 0.3096],
                            Word: "ATM",
                        },
                    ],
                },
                {
                    Line: "ATM/S1CPN207/CASHWDL/31-12-23",
                    WordsArray: [
                        {
                            Conf: 84.47,
                            Loc: [0.2249, 0.2951, 0.3921, 0.312],
                            Word: "ATM/S1CPN207/CASHWDL/31-12-23",
                        },
                    ],
                },
                {
                    Line: "20,000.00",
                    WordsArray: [
                        {
                            Conf: 99.6,
                            Loc: [0.6573, 0.2962, 0.7012, 0.315],
                            Word: "20,000.00",
                        },
                    ],
                },
                {
                    Line: "1,227.99",
                    WordsArray: [
                        {
                            Conf: 99.5,
                            Loc: [0.7652, 0.2965, 0.8026, 0.3143],
                            Word: "1,227.99",
                        },
                    ],
                },
                {
                    Line: "01-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.92,
                            Loc: [0.0721, 0.3299, 0.1253, 0.3458],
                            Word: "01-01-2024",
                        },
                    ],
                },
                {
                    Line: "UPI/400154893469/UPl/panigrahishreed/HDFC BANK",
                    WordsArray: [
                        {
                            Conf: 54.81,
                            Loc: [0.2242, 0.3193, 0.4298, 0.3386],
                            Word: "UPI/400154893469/UPl/panigrahishreed/HDFC",
                        },
                        {
                            Conf: 99.87,
                            Loc: [0.4305, 0.3215, 0.4572, 0.3368],
                            Word: "BANK",
                        },
                    ],
                },
                {
                    Line: "372.00",
                    WordsArray: [
                        {
                            Conf: 99.8,
                            Loc: [0.6697, 0.3319, 0.7007, 0.3486],
                            Word: "372.00",
                        },
                    ],
                },
                {
                    Line: "855.99",
                    WordsArray: [
                        {
                            Conf: 99.65,
                            Loc: [0.7713, 0.3318, 0.8025, 0.3487],
                            Word: "855.99",
                        },
                    ],
                },
                {
                    Line: "LTD/CId8017586314d4b77b6c069e2a5ec8a96",
                    WordsArray: [
                        {
                            Conf: 28.2,
                            Loc: [0.2214, 0.342, 0.4308, 0.3585],
                            Word: "LTD/CId8017586314d4b77b6c069e2a5ec8a96",
                        },
                    ],
                },
                {
                    Line: "02-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.88,
                            Loc: [0.0728, 0.3726, 0.1256, 0.3885],
                            Word: "02-01-2024",
                        },
                    ],
                },
                {
                    Line: "UPI/400282229558/UPI/panigrahishreed/HDFC BANK",
                    WordsArray: [
                        {
                            Conf: 38.05,
                            Loc: [0.2231, 0.3625, 0.4286, 0.3808],
                            Word: "UPI/400282229558/UPI/panigrahishreed/HDFC",
                        },
                        {
                            Conf: 99.67,
                            Loc: [0.4307, 0.364, 0.4574, 0.3794],
                            Word: "BANK",
                        },
                    ],
                },
                {
                    Line: "LTD/ICIbdb60706200f45e8b36019bb048797c6",
                    WordsArray: [
                        {
                            Conf: 23.83,
                            Loc: [0.2239, 0.3831, 0.4255, 0.3988],
                            Word: "LTD/ICIbdb60706200f45e8b36019bb048797c6",
                        },
                    ],
                },
                {
                    Line: "717.00",
                    WordsArray: [
                        {
                            Conf: 99.58,
                            Loc: [0.6696, 0.3743, 0.7002, 0.3917],
                            Word: "717.00",
                        },
                    ],
                },
                {
                    Line: "138.99",
                    WordsArray: [
                        {
                            Conf: 99.89,
                            Loc: [0.7718, 0.3749, 0.8019, 0.3914],
                            Word: "138.99",
                        },
                    ],
                },
                {
                    Line: "02-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.92,
                            Loc: [0.0737, 0.4134, 0.1262, 0.4297],
                            Word: "02-01-2024",
                        },
                    ],
                },
                {
                    Line: "UPI/400270792802/UPl/eeraj.shetty.we/HDFC BANK",
                    WordsArray: [
                        {
                            Conf: 39.28,
                            Loc: [0.2236, 0.4054, 0.4524, 0.4237],
                            Word: "UPI/400270792802/UPl/eeraj.shetty.we/HDFC BANK",
                        },
                    ],
                },
                {
                    Line: "80,625.00",
                    WordsArray: [
                        {
                            Conf: 99.02,
                            Loc: [0.5456, 0.4155, 0.5893, 0.433],
                            Word: "80,625.00",
                        },
                    ],
                },
                {
                    Line: "80,763.99",
                    WordsArray: [
                        {
                            Conf: 99.38,
                            Loc: [0.7574, 0.4155, 0.801, 0.4323],
                            Word: "80,763.99",
                        },
                    ],
                },
                {
                    Line: "LTD/HDF22b4e068d543475f9924d6b14e4390d1",
                    WordsArray: [
                        {
                            Conf: 50.24,
                            Loc: [0.2241, 0.4256, 0.4356, 0.4416],
                            Word: "LTD/HDF22b4e068d543475f9924d6b14e4390d1",
                        },
                    ],
                },
                {
                    Line: "02-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.91,
                            Loc: [0.0742, 0.4559, 0.1268, 0.4718],
                            Word: "02-01-2024",
                        },
                    ],
                },
                {
                    Line: "UPI/400200149637/UPl/yadavarvijay@ok/HDFC BANK",
                    WordsArray: [
                        {
                            Conf: 44.16,
                            Loc: [0.2248, 0.4462, 0.4356, 0.4646],
                            Word: "UPI/400200149637/UPl/yadavarvijay@ok/HDFC",
                        },
                        {
                            Conf: 99.94,
                            Loc: [0.4351, 0.4473, 0.4612, 0.4622],
                            Word: "BANK",
                        },
                    ],
                },
                {
                    Line: "850.00",
                    WordsArray: [
                        {
                            Conf: 99.77,
                            Loc: [0.6686, 0.4578, 0.6994, 0.4747],
                            Word: "850.00",
                        },
                    ],
                },
                {
                    Line: "79,913.99",
                    WordsArray: [
                        {
                            Conf: 98.45,
                            Loc: [0.7567, 0.458, 0.8004, 0.4749],
                            Word: "79,913.99",
                        },
                    ],
                },
                {
                    Line: "UPI/436836973288/UPUmotharurongksin/CICI",
                    WordsArray: [
                        {
                            Conf: 21.31,
                            Loc: [0.2251, 0.489, 0.4283, 0.5037],
                            Word: "UPI/436836973288/UPUmotharurongksin/CICI",
                        },
                    ],
                },
                {
                    Line: "02-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.89,
                            Loc: [0.075, 0.4964, 0.1271, 0.5127],
                            Word: "02-01-2024",
                        },
                    ],
                },
                {
                    Line: "268.00",
                    WordsArray: [
                        {
                            Conf: 99.78,
                            Loc: [0.5588, 0.4981, 0.5891, 0.5144],
                            Word: "268.00",
                        },
                    ],
                },
                {
                    Line: "80,181.99",
                    WordsArray: [
                        {
                            Conf: 91.47,
                            Loc: [0.7566, 0.4979, 0.7998, 0.5157],
                            Word: "80,181.99",
                        },
                    ],
                },
                {
                    Line: "Bank/IC17ad777702bff4ad8927a923378cf7dat",
                    WordsArray: [
                        {
                            Conf: 25.94,
                            Loc: [0.2242, 0.5086, 0.4288, 0.5243],
                            Word: "Bank/IC17ad777702bff4ad8927a923378cf7dat",
                        },
                    ],
                },
                {
                    Line: "03-01-2024 CICI ATM",
                    WordsArray: [
                        {
                            Conf: 26.48,
                            Loc: [0.0751, 0.5313, 0.1492, 0.5474],
                            Word: "03-01-2024 CICI",
                        },
                        {
                            Conf: 99.88,
                            Loc: [0.1509, 0.5318, 0.1721, 0.5472],
                            Word: "ATM",
                        },
                    ],
                },
                {
                    Line: "ATM/S1CPN207/CASHWDL/03-01-2",
                    WordsArray: [
                        {
                            Conf: 81.98,
                            Loc: [0.2249, 0.5324, 0.3871, 0.5479],
                            Word: "ATM/S1CPN207/CASHWDL/03-01-2",
                        },
                    ],
                },
                {
                    Line: "20,000.00",
                    WordsArray: [
                        {
                            Conf: 98.55,
                            Loc: [0.6552, 0.5338, 0.6986, 0.5496],
                            Word: "20,000.00",
                        },
                    ],
                },
                {
                    Line: "60.181.99",
                    WordsArray: [
                        {
                            Conf: 57.56,
                            Loc: [0.7562, 0.5335, 0.7994, 0.5498],
                            Word: "60.181.99",
                        },
                    ],
                },
                {
                    Line: "03-01-20241CIC ATM",
                    WordsArray: [
                        {
                            Conf: 51.63,
                            Loc: [0.0754, 0.5582, 0.1494, 0.5744],
                            Word: "03-01-20241CIC",
                        },
                        {
                            Conf: 99.72,
                            Loc: [0.1511, 0.5599, 0.1723, 0.5745],
                            Word: "ATM",
                        },
                    ],
                },
                {
                    Line: "ATM/S1CPN207/CASHWDL/03-01-24",
                    WordsArray: [
                        {
                            Conf: 84.28,
                            Loc: [0.228, 0.5598, 0.3905, 0.5752],
                            Word: "ATM/S1CPN207/CASHWDL/03-01-24",
                        },
                    ],
                },
                {
                    Line: "20,000.00",
                    WordsArray: [
                        {
                            Conf: 98.15,
                            Loc: [0.6552, 0.5608, 0.6985, 0.5772],
                            Word: "20,000.00",
                        },
                    ],
                },
                {
                    Line: "40,181.99",
                    WordsArray: [
                        {
                            Conf: 91.58,
                            Loc: [0.7558, 0.5613, 0.7993, 0.5782],
                            Word: "40,181.99",
                        },
                    ],
                },
                {
                    Line: "UPI/436966486674/UPt/rupeshpanigrahi/Bank of",
                    WordsArray: [
                        {
                            Conf: 35.37,
                            Loc: [0.226, 0.5833, 0.4264, 0.6013],
                            Word: "UPI/436966486674/UPt/rupeshpanigrahi/Bank",
                        },
                        {
                            Conf: 98.97,
                            Loc: [0.4282, 0.5841, 0.4372, 0.5993],
                            Word: "of",
                        },
                    ],
                },
                {
                    Line: "03-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.78,
                            Loc: [0.0763, 0.5942, 0.1285, 0.6094],
                            Word: "03-01-2024",
                        },
                    ],
                },
                {
                    Line: "230.00",
                    WordsArray: [
                        {
                            Conf: 99.91,
                            Loc: [0.5585, 0.5946, 0.5887, 0.6119],
                            Word: "230.00",
                        },
                    ],
                },
                {
                    Line: "40,411.99",
                    WordsArray: [
                        {
                            Conf: 89.65,
                            Loc: [0.7554, 0.5957, 0.7984, 0.6125],
                            Word: "40,411.99",
                        },
                    ],
                },
                {
                    Line: "Indig/Cla64b4d1da9c942c186b4ga986ce5f417",
                    WordsArray: [
                        {
                            Conf: 23.22,
                            Loc: [0.2253, 0.6057, 0.4301, 0.6211],
                            Word: "Indig/Cla64b4d1da9c942c186b4ga986ce5f417",
                        },
                    ],
                },
                {
                    Line: "UPI/400339226099/paymention CRED/cred.club@axisb/Axis",
                    WordsArray: [
                        {
                            Conf: 39.06,
                            Loc: [0.226, 0.6262, 0.3647, 0.6429],
                            Word: "UPI/400339226099/paymention",
                        },
                        {
                            Conf: 44.03,
                            Loc: [0.367, 0.6255, 0.4855, 0.6413],
                            Word: "CRED/cred.club@axisb/Axis",
                        },
                    ],
                },
                {
                    Line: "03-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.89,
                            Loc: [0.077, 0.6359, 0.1295, 0.6516],
                            Word: "03-01-2024",
                        },
                    ],
                },
                {
                    Line: "Bank Ltd/ACD7479c56b3e704a3c9dd9eef679g6710e/",
                    WordsArray: [
                        {
                            Conf: 98.45,
                            Loc: [0.2261, 0.6463, 0.2488, 0.661],
                            Word: "Bank",
                        },
                        {
                            Conf: 27.65,
                            Loc: [0.2467, 0.6455, 0.462, 0.6613],
                            Word: "Ltd/ACD7479c56b3e704a3c9dd9eef679g6710e/",
                        },
                    ],
                },
                {
                    Line: "8,669.80",
                    WordsArray: [
                        {
                            Conf: 98.58,
                            Loc: [0.6593, 0.6369, 0.6978, 0.6542],
                            Word: "8,669.80",
                        },
                    ],
                },
                {
                    Line: "31,742.19",
                    WordsArray: [
                        {
                            Conf: 65.5,
                            Loc: [0.7553, 0.6374, 0.7977, 0.6539],
                            Word: "31,742.19",
                        },
                    ],
                },
                {
                    Line: "UPI400403558006/UPI/ankitanikam1919/Bank",
                    WordsArray: [
                        {
                            Conf: 30.74,
                            Loc: [0.2266, 0.6675, 0.4348, 0.6828],
                            Word: "UPI400403558006/UPI/ankitanikam1919/Bank",
                        },
                    ],
                },
                {
                    Line: "of",
                    WordsArray: [
                        {
                            Conf: 97.85,
                            Loc: [0.4329, 0.6688, 0.4415, 0.6809],
                            Word: "of",
                        },
                    ],
                },
                {
                    Line: "04-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.91,
                            Loc: [0.0778, 0.6759, 0.1299, 0.6914],
                            Word: "04-01-2024",
                        },
                    ],
                },
                {
                    Line: "18.00",
                    WordsArray: [
                        {
                            Conf: 99.49,
                            Loc: [0.6735, 0.6771, 0.697, 0.6936],
                            Word: "18.00",
                        },
                    ],
                },
                {
                    Line: "31,724.19",
                    WordsArray: [
                        {
                            Conf: 83.89,
                            Loc: [0.7549, 0.6773, 0.7973, 0.6942],
                            Word: "31,724.19",
                        },
                    ],
                },
                {
                    Line: "Boroda/C1327da083df0d4399b631c8e6fa7b9f6",
                    WordsArray: [
                        {
                            Conf: 20.42,
                            Loc: [0.2253, 0.6874, 0.4322, 0.703],
                            Word: "Boroda/C1327da083df0d4399b631c8e6fa7b9f6",
                        },
                    ],
                },
                {
                    Line: "UPI/437118970845/UPl/ry2349084-1@oka/Kotak Mahindra",
                    WordsArray: [
                        {
                            Conf: 36.08,
                            Loc: [0.2276, 0.707, 0.4386, 0.7248],
                            Word: "UPI/437118970845/UPl/ry2349084-1@oka/Kotak",
                        },
                        {
                            Conf: 89.43,
                            Loc: [0.4411, 0.7074, 0.4826, 0.7223],
                            Word: "Mahindra",
                        },
                    ],
                },
                {
                    Line: "05-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.87,
                            Loc: [0.0787, 0.7176, 0.1307, 0.7332],
                            Word: "05-01-2024",
                        },
                    ],
                },
                {
                    Line: "203.00",
                    WordsArray: [
                        {
                            Conf: 99.48,
                            Loc: [0.6673, 0.7184, 0.6971, 0.7353],
                            Word: "203.00",
                        },
                    ],
                },
                {
                    Line: "31,521.19",
                    WordsArray: [
                        {
                            Conf: 91.16,
                            Loc: [0.7544, 0.7188, 0.7973, 0.7349],
                            Word: "31,521.19",
                        },
                    ],
                },
                {
                    Line: "BANK",
                    WordsArray: [
                        {
                            Conf: 99.75,
                            Loc: [0.4375, 0.7492, 0.4633, 0.7632],
                            Word: "BANK",
                        },
                    ],
                },
                {
                    Line: "05-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.78,
                            Loc: [0.0791, 0.7568, 0.1312, 0.7727],
                            Word: "05-01-2024",
                        },
                    ],
                },
                {
                    Line: "3,500.00",
                    WordsArray: [
                        {
                            Conf: 98.71,
                            Loc: [0.551, 0.7576, 0.5876, 0.7735],
                            Word: "3,500.00",
                        },
                    ],
                },
                {
                    Line: "35,021.19",
                    WordsArray: [
                        {
                            Conf: 86.71,
                            Loc: [0.754, 0.7591, 0.796, 0.776],
                            Word: "35,021.19",
                        },
                    ],
                },
                {
                    Line: "UPI/400596186721/UPl/eeraj.shetty.we/HDFC BANK",
                    WordsArray: [
                        {
                            Conf: 23.15,
                            Loc: [0.2277, 0.7884, 0.4247, 0.8065],
                            Word: "UPI/400596186721/UPl/eeraj.shetty.we/HDFC",
                        },
                        {
                            Conf: 99.71,
                            Loc: [0.4262, 0.7887, 0.4523, 0.803],
                            Word: "BANK",
                        },
                    ],
                },
                {
                    Line: "05-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.89,
                            Loc: [0.0806, 0.7984, 0.132, 0.8145],
                            Word: "05-01-2024",
                        },
                    ],
                },
                {
                    Line: "100.00",
                    WordsArray: [
                        {
                            Conf: 99.82,
                            Loc: [0.5584, 0.7994, 0.5876, 0.8148],
                            Word: "100.00",
                        },
                    ],
                },
                {
                    Line: "35.121.19",
                    WordsArray: [
                        {
                            Conf: 95.73,
                            Loc: [0.7534, 0.7996, 0.7959, 0.8167],
                            Word: "35.121.19",
                        },
                    ],
                },
                {
                    Line: "TD/HDFbbb81fo6a3544be4ac38d2f92e0c1/e5",
                    WordsArray: [
                        {
                            Conf: 22.64,
                            Loc: [0.2324, 0.8102, 0.435, 0.8267],
                            Word: "TD/HDFbbb81fo6a3544be4ac38d2f92e0c1/e5",
                        },
                    ],
                },
                {
                    Line: "06-01-2024",
                    WordsArray: [
                        {
                            Conf: 98.75,
                            Loc: [0.0813, 0.8398, 0.1325, 0.8549],
                            Word: "06-01-2024",
                        },
                    ],
                },
                {
                    Line: "105.00",
                    WordsArray: [
                        {
                            Conf: 99.28,
                            Loc: [0.5591, 0.8407, 0.5875, 0.8564],
                            Word: "105.00",
                        },
                    ],
                },
                {
                    Line: "35,226.19",
                    WordsArray: [
                        {
                            Conf: 96.3,
                            Loc: [0.7529, 0.8411, 0.7954, 0.8586],
                            Word: "35,226.19",
                        },
                    ],
                },
                {
                    Line: "BANK",
                    WordsArray: [
                        {
                            Conf: 97.71,
                            Loc: [0.4261, 0.8716, 0.4521, 0.8859],
                            Word: "BANK",
                        },
                    ],
                },
                {
                    Line: "06-01-2024",
                    WordsArray: [
                        {
                            Conf: 96.23,
                            Loc: [0.082, 0.879, 0.1329, 0.8932],
                            Word: "06-01-2024",
                        },
                    ],
                },
                {
                    Line: "200.00",
                    WordsArray: [
                        {
                            Conf: 98.31,
                            Loc: [0.558, 0.88, 0.5875, 0.8964],
                            Word: "200.00",
                        },
                    ],
                },
                {
                    Line: "35,426.19",
                    WordsArray: [
                        {
                            Conf: 94.61,
                            Loc: [0.7523, 0.8813, 0.7946, 0.8964],
                            Word: "35,426.19",
                        },
                    ],
                },
                {
                    Line: "LTD/HDF4126589672c04cf6b26d95b642613eu1",
                    WordsArray: [
                        {
                            Conf: 21.43,
                            Loc: [0.2317, 0.8912, 0.442, 0.9068],
                            Word: "LTD/HDF4126589672c04cf6b26d95b642613eu1",
                        },
                    ],
                },
                {
                    Line: "SHOT ON REDME",
                    WordsArray: [
                        {
                            Conf: 95.93,
                            Loc: [0.0892, 0.9036, 0.1268, 0.9203],
                            Word: "SHOT",
                        },
                        {
                            Conf: 67.11,
                            Loc: [0.1292, 0.9034, 0.1991, 0.9229],
                            Word: "ON REDME",
                        },
                    ],
                },
                {
                    Line: "08-01-2024",
                    WordsArray: [
                        {
                            Conf: 67.65,
                            Loc: [0.0829, 0.9195, 0.134, 0.9344],
                            Word: "08-01-2024",
                        },
                    ],
                },
                {
                    Line: "UPI/437319284213/PaytoBharatPe/bhiorutpe900684/Federo",
                    WordsArray: [
                        {
                            Conf: 20.34,
                            Loc: [0.2283, 0.9101, 0.4932, 0.929],
                            Word: "UPI/437319284213/PaytoBharatPe/bhiorutpe900684/Federo",
                        },
                    ],
                },
                {
                    Line: "30.00",
                    WordsArray: [
                        {
                            Conf: 40.92,
                            Loc: [0.6718, 0.9218, 0.6951, 0.9382],
                            Word: "30.00",
                        },
                    ],
                },
                {
                    Line: "35,396.19",
                    WordsArray: [
                        {
                            Conf: 82.29,
                            Loc: [0.7518, 0.9218, 0.7939, 0.9384],
                            Word: "35,396.19",
                        },
                    ],
                },
                {
                    Line: "ALDUAL CAMERA",
                    WordsArray: [
                        {
                            Conf: 71.89,
                            Loc: [0.088, 0.9362, 0.1432, 0.955],
                            Word: "ALDUAL",
                        },
                        {
                            Conf: 99.85,
                            Loc: [0.1479, 0.9346, 0.204, 0.9554],
                            Word: "CAMERA",
                        },
                    ],
                },
                {
                    Line: "08-01-2024",
                    WordsArray: [
                        {
                            Conf: 99.52,
                            Loc: [0.0834, 0.9585, 0.1345, 0.9733],
                            Word: "08-01-2024",
                        },
                    ],
                },
                {
                    Line: "100.00",
                    WordsArray: [
                        {
                            Conf: 46.68,
                            Loc: [0.6662, 0.9605, 0.6953, 0.9763],
                            Word: "100.00",
                        },
                    ],
                },
                {
                    Line: "35,296.19",
                    WordsArray: [
                        {
                            Conf: 93.02,
                            Loc: [0.7514, 0.9601, 0.7933, 0.977],
                            Word: "35,296.19",
                        },
                    ],
                },
            ],
            Page: 1,
        },
    ],
    Pages: 1,
    Tables: [
        {
            CharacterConfidence: 88.84,
            LayoutConfidence: 78.56,
            Page: 1,
            TableConfidence: {
                "0": {
                    "0": 99.91,
                    "1": 99.83,
                    "2": 99.45,
                    "3": 99.75,
                    "4": 99.67,
                    "5": 99.76,
                },
                "1": {
                    "0": 99.93,
                    "1": 0,
                    "2": 99.36,
                    "3": 0,
                    "4": 0,
                    "5": 99.41,
                },
                "2": {
                    "0": 99.95,
                    "1": 0,
                    "2": 67.16,
                    "3": 0,
                    "4": 99.96,
                    "5": 99.21,
                },
                "3": {
                    "0": 99.93,
                    "1": 0,
                    "2": 56.19,
                    "3": 99.5,
                    "4": 0,
                    "5": 99.61,
                },
                "4": {
                    "0": 99.94,
                    "1": 0,
                    "2": 53.13,
                    "3": 0,
                    "4": 99.89,
                    "5": 98.92,
                },
                "5": {
                    "0": 99.91,
                    "1": 0,
                    "2": 48.11,
                    "3": 99.71,
                    "4": 0,
                    "5": 93.27,
                },
                "6": {
                    "0": 99.92,
                    "1": 0,
                    "2": 66.47,
                    "3": 0,
                    "4": 99.88,
                    "5": 98.96,
                },
                "7": {
                    "0": 99.84,
                    "1": 94.9,
                    "2": 84.47,
                    "3": 0,
                    "4": 99.6,
                    "5": 99.5,
                },
                "8": {
                    "0": 99.92,
                    "1": 0,
                    "2": 60.96,
                    "3": 0,
                    "4": 99.8,
                    "5": 99.65,
                },
                "9": {
                    "0": 99.88,
                    "1": 0,
                    "2": 53.85,
                    "3": 0,
                    "4": 99.58,
                    "5": 99.89,
                },
                "10": {
                    "0": 99.92,
                    "1": 0,
                    "2": 44.76,
                    "3": 99.02,
                    "4": 0,
                    "5": 99.38,
                },
                "11": {
                    "0": 99.91,
                    "1": 0,
                    "2": 72.05,
                    "3": 0,
                    "4": 99.77,
                    "5": 98.45,
                },
                "12": {
                    "0": 99.89,
                    "1": 0,
                    "2": 23.62,
                    "3": 99.78,
                    "4": 0,
                    "5": 91.47,
                },
                "13": {
                    "0": 26.48,
                    "1": 99.88,
                    "2": 81.98,
                    "3": 0,
                    "4": 98.55,
                    "5": 97.91,
                },
                "14": {
                    "0": 51.63,
                    "1": 99.72,
                    "2": 84.28,
                    "3": 0,
                    "4": 98.15,
                    "5": 91.58,
                },
                "15": {
                    "0": 99.78,
                    "1": 0,
                    "2": 52.52,
                    "3": 99.91,
                    "4": 0,
                    "5": 98.71,
                },
                "16": {
                    "0": 99.89,
                    "1": 0,
                    "2": 52.3,
                    "3": 0,
                    "4": 98.58,
                    "5": 98.42,
                },
                "17": {
                    "0": 99.91,
                    "1": 0,
                    "2": 49.67,
                    "3": 0,
                    "4": 99.49,
                    "5": 98.46,
                },
                "18": {
                    "0": 99.87,
                    "1": 0,
                    "2": 62.76,
                    "3": 0,
                    "4": 99.48,
                    "5": 91.16,
                },
                "19": {
                    "0": 99.78,
                    "1": 0,
                    "2": 99.75,
                    "3": 98.71,
                    "4": 0,
                    "5": 97.72,
                },
                "20": {
                    "0": 99.89,
                    "1": 0,
                    "2": 48.5,
                    "3": 99.82,
                    "4": 0,
                    "5": 95.73,
                },
                "21": {
                    "0": 98.75,
                    "1": 0,
                    "2": 0,
                    "3": 99.28,
                    "4": 0,
                    "5": 96.3,
                },
                "22": {
                    "0": 96.23,
                    "1": 0,
                    "2": 59.57,
                    "3": 98.31,
                    "4": 0,
                    "5": 94.61,
                },
                "23": {
                    "0": 78.49,
                    "1": 83.48,
                    "2": 20.34,
                    "3": 0,
                    "4": 97.91,
                    "5": 98.48,
                },
                "24": {
                    "0": 99.52,
                    "1": 0,
                    "2": 0,
                    "3": 0,
                    "4": 97.39,
                    "5": 93.02,
                },
            },
            TableCoordinates: {
                "0": {
                    "0": [0.061, 0.0046, 0.123, 0.0451],
                    "1": [0.1224, 0.0046, 0.2166, 0.0452],
                    "2": [0.2161, 0.0047, 0.5018, 0.0454],
                    "3": [0.5016, 0.0049, 0.5957, 0.0455],
                    "4": [0.5956, 0.0049, 0.7077, 0.0456],
                    "5": [0.7078, 0.005, 0.8053, 0.0457],
                },
                "1": {
                    "0": [0.0617, 0.0451, 0.1234, 0.075],
                    "1": [],
                    "2": [0.2166, 0.0452, 0.5019, 0.0754],
                    "3": [],
                    "4": [],
                    "5": [0.7077, 0.0456, 0.8051, 0.0757],
                },
                "2": {
                    "0": [0.0622, 0.075, 0.1241, 0.1191],
                    "1": [],
                    "2": [0.217, 0.0751, 0.5021, 0.1195],
                    "3": [],
                    "4": [0.5957, 0.0755, 0.7076, 0.1197],
                    "5": [0.7076, 0.0756, 0.8049, 0.1198],
                },
                "3": {
                    "0": [0.0629, 0.119, 0.1247, 0.1602],
                    "1": [],
                    "2": [0.2175, 0.1192, 0.5023, 0.1607],
                    "3": [0.5021, 0.1195, 0.5959, 0.1608],
                    "4": [],
                    "5": [0.7076, 0.1197, 0.8047, 0.161],
                },
                "4": {
                    "0": [0.0636, 0.1601, 0.1253, 0.204],
                    "1": [],
                    "2": [0.218, 0.1603, 0.5024, 0.2046],
                    "3": [],
                    "4": [0.5959, 0.1608, 0.7074, 0.2049],
                    "5": [0.7075, 0.1609, 0.8045, 0.205],
                },
                "5": {
                    "0": [0.0643, 0.204, 0.126, 0.2464],
                    "1": [],
                    "2": [0.2185, 0.2042, 0.5026, 0.247],
                    "3": [0.5024, 0.2046, 0.596, 0.2471],
                    "4": [],
                    "5": [0.7074, 0.2049, 0.8043, 0.2474],
                },
                "6": {
                    "0": [0.065, 0.2463, 0.1266, 0.2886],
                    "1": [],
                    "2": [0.2191, 0.2465, 0.5028, 0.2892],
                    "3": [],
                    "4": [0.596, 0.2471, 0.7072, 0.2896],
                    "5": [0.7073, 0.2473, 0.8041, 0.2898],
                },
                "7": {
                    "0": [0.0657, 0.2885, 0.127, 0.3167],
                    "1": [0.1266, 0.2886, 0.2199, 0.3169],
                    "2": [0.2196, 0.2888, 0.5029, 0.3174],
                    "3": [],
                    "4": [0.596, 0.2894, 0.7072, 0.3178],
                    "5": [0.7072, 0.2896, 0.804, 0.3179],
                },
                "8": {
                    "0": [0.0662, 0.3166, 0.1276, 0.3601],
                    "1": [],
                    "2": [0.2199, 0.3169, 0.5031, 0.3609],
                    "3": [],
                    "4": [0.5961, 0.3176, 0.7071, 0.3613],
                    "5": [0.7072, 0.3178, 0.8038, 0.3615],
                },
                "9": {
                    "0": [0.0669, 0.36, 0.1283, 0.4021],
                    "1": [],
                    "2": [0.2204, 0.3603, 0.5032, 0.4029],
                    "3": [],
                    "4": [0.5961, 0.3611, 0.707, 0.4034],
                    "5": [0.7071, 0.3613, 0.8036, 0.4036],
                },
                "10": {
                    "0": [0.0676, 0.402, 0.1289, 0.4439],
                    "1": [],
                    "2": [0.2209, 0.4023, 0.5034, 0.4448],
                    "3": [0.5032, 0.4029, 0.5963, 0.445],
                    "4": [],
                    "5": [0.707, 0.4034, 0.8034, 0.4455],
                },
                "11": {
                    "0": [0.0683, 0.4438, 0.1295, 0.4843],
                    "1": [],
                    "2": [0.2214, 0.4442, 0.5036, 0.4852],
                    "3": [],
                    "4": [0.5963, 0.445, 0.7069, 0.4857],
                    "5": [0.707, 0.4453, 0.8033, 0.486],
                },
                "12": {
                    "0": [0.0689, 0.4841, 0.1301, 0.5273],
                    "1": [],
                    "2": [0.2219, 0.4845, 0.5038, 0.5283],
                    "3": [0.5036, 0.4852, 0.5964, 0.5286],
                    "4": [],
                    "5": [0.7069, 0.4857, 0.8031, 0.5291],
                },
                "13": {
                    "0": [0.0696, 0.5272, 0.1305, 0.555],
                    "1": [0.1301, 0.5273, 0.2228, 0.5553],
                    "2": [0.2225, 0.5276, 0.5039, 0.5561],
                    "3": [],
                    "4": [0.5964, 0.5286, 0.7068, 0.5567],
                    "5": [0.7068, 0.5289, 0.8029, 0.5569],
                },
                "14": {
                    "0": [0.0701, 0.5549, 0.1309, 0.58],
                    "1": [0.1305, 0.555, 0.2231, 0.5802],
                    "2": [0.2228, 0.5553, 0.504, 0.581],
                    "3": [],
                    "4": [0.5964, 0.5563, 0.7067, 0.5816],
                    "5": [0.7068, 0.5567, 0.8028, 0.5819],
                },
                "15": {
                    "0": [0.0705, 0.5798, 0.1315, 0.6228],
                    "1": [],
                    "2": [0.2231, 0.5802, 0.5041, 0.6239],
                    "3": [0.504, 0.581, 0.5965, 0.6242],
                    "4": [],
                    "5": [0.7067, 0.5816, 0.8026, 0.6248],
                },
                "16": {
                    "0": [0.0712, 0.6226, 0.1321, 0.6641],
                    "1": [],
                    "2": [0.2236, 0.623, 0.5043, 0.6653],
                    "3": [],
                    "4": [0.5965, 0.6242, 0.7066, 0.6659],
                    "5": [0.7067, 0.6245, 0.8024, 0.6662],
                },
                "17": {
                    "0": [0.0719, 0.6639, 0.1327, 0.7053],
                    "1": [],
                    "2": [0.2241, 0.6644, 0.5045, 0.7066],
                    "3": [],
                    "4": [0.5966, 0.6656, 0.7065, 0.7072],
                    "5": [0.7066, 0.6659, 0.8023, 0.7076],
                },
                "18": {
                    "0": [0.0726, 0.7051, 0.1333, 0.7464],
                    "1": [],
                    "2": [0.2246, 0.7056, 0.5046, 0.7477],
                    "3": [],
                    "4": [0.5966, 0.7069, 0.7064, 0.7485],
                    "5": [0.7065, 0.7072, 0.8021, 0.7488],
                },
                "19": {
                    "0": [0.0732, 0.7462, 0.1339, 0.7861],
                    "1": [],
                    "2": [0.2251, 0.7468, 0.5048, 0.7875],
                    "3": [0.5046, 0.7477, 0.5967, 0.7878],
                    "4": [],
                    "5": [0.7064, 0.7485, 0.8019, 0.7886],
                },
                "20": {
                    "0": [0.0739, 0.7859, 0.1346, 0.8284],
                    "1": [],
                    "2": [0.2256, 0.7864, 0.505, 0.8298],
                    "3": [0.5048, 0.7875, 0.5968, 0.8302],
                    "4": [],
                    "5": [0.7064, 0.7882, 0.8017, 0.831],
                },
                "21": {
                    "0": [0.0746, 0.8282, 0.1352, 0.8692],
                    "1": [],
                    "2": [],
                    "3": [0.505, 0.8298, 0.5968, 0.8711],
                    "4": [],
                    "5": [0.7063, 0.8306, 0.8015, 0.8719],
                },
                "22": {
                    "0": [0.0753, 0.869, 0.1357, 0.9086],
                    "1": [],
                    "2": [0.2266, 0.8696, 0.5053, 0.9102],
                    "3": [0.5051, 0.8707, 0.5969, 0.9105],
                    "4": [],
                    "5": [0.7062, 0.8715, 0.8013, 0.9114],
                },
                "23": {
                    "0": [0.0759, 0.9084, 0.1363, 0.9493],
                    "1": [0.1357, 0.9086, 0.2276, 0.9497],
                    "2": [0.2271, 0.909, 0.5055, 0.9509],
                    "3": [],
                    "4": [0.5969, 0.9105, 0.7061, 0.9517],
                    "5": [0.7061, 0.911, 0.8011, 0.9521],
                },
                "24": {
                    "0": [0.0766, 0.949, 0.137, 0.9922],
                    "1": [],
                    "2": [],
                    "3": [],
                    "4": [0.597, 0.9513, 0.706, 0.9948],
                    "5": [0.7061, 0.9517, 0.8009, 0.9952],
                },
            },
            TableJson: {
                "0": {
                    "0": "DATE",
                    "1": "MODE",
                    "2": "PARTICULARS",
                    "3": "DEPOSITS",
                    "4": "WITHDRAWALS",
                    "5": "BALANCE",
                },
                "1": {
                    "0": "01-01-2024",
                    "1": "",
                    "2": "B/F",
                    "3": "",
                    "4": "",
                    "5": "14,769.99",
                },
                "2": {
                    "0": "01-01-2024",
                    "1": "",
                    "2": "UPI/336535150643/UPl/narayanad938-1@/Unio Bank of IICla855c4gee56e490ba8040bd3500c6d8d",
                    "3": "",
                    "4": "1,000.00",
                    "5": "13,769.99",
                },
                "3": {
                    "0": "01-01-2024",
                    "1": "",
                    "2": "UPI/336517082897/UPI/arunkumarswain7/A Bank Ltd./AXI7ff25d8174ab4087bag41071c2ef9b3b",
                    "3": "8,598.00",
                    "4": "",
                    "5": "22,367.99",
                },
                "4": {
                    "0": "01-01-2024",
                    "1": "",
                    "2": "JPI/373171412878/Request fromAm/amazonpayrechar/Yes Bank Ltd/APY83b424cd18754cbd98b705aa590a5360",
                    "3": "",
                    "4": "2,000.00",
                    "5": "20,367.99",
                },
                "5": {
                    "0": "01-01-2024",
                    "1": "",
                    "2": "UPI/336525805818/UPl/arunkumarswain7/Axis. Bank Ltd./AXI1a133e7a2dc7401695e639ab013b1828",
                    "3": "1,360.00",
                    "4": "",
                    "5": "21,727.99",
                },
                "6": {
                    "0": "01-01-2024",
                    "1": "",
                    "2": "UPI336533976963/UPl/panigrahichinky/State Bank Of I/IC1308d64b1bc1d44cbge2c7f50933c6ad7/",
                    "3": "",
                    "4": "500.00",
                    "5": "21,227.99",
                },
                "7": {
                    "0": "01-01-2024",
                    "1": "ICICI ATM",
                    "2": "ATM/S1CPN207/CASHWDL/31-12-23",
                    "3": "",
                    "4": "20,000.00",
                    "5": "1,227.99",
                },
                "8": {
                    "0": "01-01-2024",
                    "1": "",
                    "2": "UPI/400154893469/UPl/panigrahishreed/HDFC BANK LTD/CId8017586314d4b77b6c069e2a5ec8a96",
                    "3": "",
                    "4": "372.00",
                    "5": "855.99",
                },
                "9": {
                    "0": "02-01-2024",
                    "1": "",
                    "2": "UPI/400282229558/UPI/panigrahishreed/HDFC BANK LTD/ICIbdb60706200f45e8b36019bb048797c6",
                    "3": "",
                    "4": "717.00",
                    "5": "138.99",
                },
                "10": {
                    "0": "02-01-2024",
                    "1": "",
                    "2": "UPI/400270792802/UPl/eeraj.shetty.we/HDFC BANK LTD/HDF22b4e068d543475f9924d6b14e4390d1",
                    "3": "80,625.00",
                    "4": "",
                    "5": "80,763.99",
                },
                "11": {
                    "0": "02-01-2024",
                    "1": "",
                    "2": "UPI/400200149637/UPl/yadavarvijay@ok/HDFC BANK",
                    "3": "",
                    "4": "850.00",
                    "5": "79,913.99",
                },
                "12": {
                    "0": "02-01-2024",
                    "1": "",
                    "2": "UPI/436836973288/UPUmotharurongksin/CICI Bank/IC17ad777702bff4ad8927a923378cf7dat",
                    "3": "268.00",
                    "4": "",
                    "5": "80,181.99",
                },
                "13": {
                    "0": "03-01-2024 CICI",
                    "1": "ATM",
                    "2": "ATM/S1CPN207/CASHWDL/03-01-2",
                    "3": "",
                    "4": "20,000.00",
                    "5": "60.181.99",
                },
                "14": {
                    "0": "03-01-20241CIC",
                    "1": "ATM",
                    "2": "ATM/S1CPN207/CASHWDL/03-01-24",
                    "3": "",
                    "4": "20,000.00",
                    "5": "40,181.99",
                },
                "15": {
                    "0": "03-01-2024",
                    "1": "",
                    "2": "UPI/436966486674/UPt/rupeshpanigrahi/Bank of Indig/Cla64b4d1da9c942c186b4ga986ce5f417",
                    "3": "230.00",
                    "4": "",
                    "5": "40,411.99",
                },
                "16": {
                    "0": "03-01-2024",
                    "1": "",
                    "2": "UPI/400339226099/paymention CRED/cred.club@axisb/Axis Bank Ltd/ACD7479c56b3e704a3c9dd9eef679g6710e/",
                    "3": "",
                    "4": "8,669.80",
                    "5": "31,742.19",
                },
                "17": {
                    "0": "04-01-2024",
                    "1": "",
                    "2": "UPI400403558006/UPI/ankitanikam1919/Bank of Boroda/C1327da083df0d4399b631c8e6fa7b9f6",
                    "3": "",
                    "4": "18.00",
                    "5": "31,724.19",
                },
                "18": {
                    "0": "05-01-2024",
                    "1": "",
                    "2": "UPI/437118970845/UPl/ry2349084-1@oka/Kotak Mahindra",
                    "3": "",
                    "4": "203.00",
                    "5": "31,521.19",
                },
                "19": {
                    "0": "05-01-2024",
                    "1": "",
                    "2": "BANK",
                    "3": "3,500.00",
                    "4": "",
                    "5": "35,021.19",
                },
                "20": {
                    "0": "05-01-2024",
                    "1": "",
                    "2": "UPI/400596186721/UPl/eeraj.shetty.we/HDFC BANK TD/HDFbbb81fo6a3544be4ac38d2f92e0c1/e5",
                    "3": "100.00",
                    "4": "",
                    "5": "35.121.19",
                },
                "21": {
                    "0": "06-01-2024",
                    "1": "",
                    "2": "",
                    "3": "105.00",
                    "4": "",
                    "5": "35,226.19",
                },
                "22": {
                    "0": "06-01-2024",
                    "1": "",
                    "2": "BANK LTD/HDF4126589672c04cf6b26d95b642613eu1",
                    "3": "200.00",
                    "4": "",
                    "5": "35,426.19",
                },
                "23": {
                    "0": "SHOT 08-01-2024 ALDUAL",
                    "1": "ON REDME CAMERA",
                    "2": "UPI/437319284213/PaytoBharatPe/bhiorutpe900684/Federo",
                    "3": "",
                    "4": "30.00",
                    "5": "35,396.19",
                },
                "24": {
                    "0": "08-01-2024",
                    "1": "",
                    "2": "",
                    "3": "",
                    "4": "100.00",
                    "5": "35,296.19",
                },
            },
        },
    ],
};

export const pythonApiData = {
    "document_url": "http://127.0.0.1:5000/static/docs/output_document_with_text.docx",
    "image_url": "https://ocrapi.epiksolution.org/static/images/rcXLXgHchXjnJEon5R4Q.jpg",
    "width": 1240,
    "height": 1755,
    "text_boxes": [
      {
        "confidence": 96,
        "height": 18,
        "left": 591,
        "text": "HOTEL",
        "top": 2,
        "width": 56
      },
      {
        "confidence": 92,
        "height": 83,
        "left": 65,
        "text": "|",
        "top": 0,
        "width": 4
      },
      {
        "confidence": 24,
        "height": 19,
        "left": 537,
        "text": "Mm",
        "top": 34,
        "width": 29
      },
      {
        "confidence": 9,
        "height": 25,
        "left": 585,
        "text": "Atala",
        "top": 27,
        "width": 108
      },
      {
        "confidence": 28,
        "height": 13,
        "left": 875,
        "text": "aawr",
        "top": 32,
        "width": 94
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 373,
        "text": "OFFICE",
        "top": 156,
        "width": 77
      },
      {
        "confidence": 96,
        "height": 12,
        "left": 458,
        "text": "OF",
        "top": 159,
        "width": 27
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 493,
        "text": "THE",
        "top": 159,
        "width": 42
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 543,
        "text": "DEVELOPMENT",
        "top": 159,
        "width": 156
      },
      {
        "confidence": 95,
        "height": 16,
        "left": 706,
        "text": "COMMISSIONER,",
        "top": 159,
        "width": 173
      },
      {
        "confidence": 93,
        "height": 13,
        "left": 451,
        "text": "SEEPZ",
        "top": 180,
        "width": 65
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 523,
        "text": "SPECIAL",
        "top": 180,
        "width": 88
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 618,
        "text": "ECONOMIC",
        "top": 180,
        "width": 112
      },
      {
        "confidence": 95,
        "height": 15,
        "left": 738,
        "text": "ZONE,",
        "top": 180,
        "width": 62
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 539,
        "text": "GOVT.",
        "top": 201,
        "width": 61
      },
      {
        "confidence": 96,
        "height": 12,
        "left": 610,
        "text": "OF",
        "top": 202,
        "width": 27
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 645,
        "text": "INDIA,",
        "top": 202,
        "width": 64
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 418,
        "text": "MINISTRY",
        "top": 222,
        "width": 104
      },
      {
        "confidence": 95,
        "height": 13,
        "left": 528,
        "text": "OF",
        "top": 222,
        "width": 29
      },
      {
        "confidence": 93,
        "height": 15,
        "left": 564,
        "text": "COMMERCE",
        "top": 222,
        "width": 123
      },
      {
        "confidence": 93,
        "height": 13,
        "left": 694,
        "text": "&",
        "top": 224,
        "width": 14
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 716,
        "text": "INDUSTRY,",
        "top": 222,
        "width": 113
      },
      {
        "confidence": 90,
        "height": 12,
        "left": 452,
        "text": "ANDHERI",
        "top": 244,
        "width": 97
      },
      {
        "confidence": 90,
        "height": 17,
        "left": 556,
        "text": "(E),",
        "top": 244,
        "width": 31
      },
      {
        "confidence": 93,
        "height": 14,
        "left": 595,
        "text": "MUMBAI",
        "top": 244,
        "width": 87
      },
      {
        "confidence": 93,
        "height": 2,
        "left": 690,
        "text": "-",
        "top": 253,
        "width": 5
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 703,
        "text": "400",
        "top": 245,
        "width": 38
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 749,
        "text": "096.",
        "top": 244,
        "width": 43
      },
      {
        "confidence": 0,
        "height": 9,
        "left": 556,
        "text": "Tennant",
        "top": 265,
        "width": 133
      },
      {
        "confidence": 0,
        "height": 20,
        "left": 222,
        "text": "No.SEEPZ-SEZ/ADMN/28/2001-02/VolLl",
        "top": 300,
        "width": 417
      },
      {
        "confidence": 12,
        "height": 23,
        "left": 664,
        "text": "|23)1S",
        "top": 297,
        "width": 104
      },
      {
        "confidence": 19,
        "height": 14,
        "left": 806,
        "text": "\u2014-17\"",
        "top": 304,
        "width": 38
      },
      {
        "confidence": 96,
        "height": 17,
        "left": 852,
        "text": "November,",
        "top": 303,
        "width": 109
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 969,
        "text": "2017",
        "top": 304,
        "width": 52
      },
      {
        "confidence": 95,
        "height": 14,
        "left": 455,
        "text": "CIRCULAR",
        "top": 345,
        "width": 108
      },
      {
        "confidence": 57,
        "height": 14,
        "left": 570,
        "text": "No.",
        "top": 347,
        "width": 31
      },
      {
        "confidence": 26,
        "height": 32,
        "left": 602,
        "text": "22\u00b0",
        "top": 332,
        "width": 119
      },
      {
        "confidence": 54,
        "height": 16,
        "left": 722,
        "text": "_2017",
        "top": 347,
        "width": 63
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 216,
        "text": "Subject:",
        "top": 384,
        "width": 80
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 305,
        "text": "Communal",
        "top": 386,
        "width": 109
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 421,
        "text": "Harmony",
        "top": 387,
        "width": 82
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 523,
        "text": "Campaign",
        "top": 389,
        "width": 75
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 630,
        "text": "Week",
        "top": 390,
        "width": 54
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 692,
        "text": "from",
        "top": 390,
        "width": 48
      },
      {
        "confidence": 91,
        "height": 14,
        "left": 750,
        "text": "19",
        "top": 390,
        "width": 22
      },
      {
        "confidence": 61,
        "height": 2,
        "left": 780,
        "text": "\u2014",
        "top": 397,
        "width": 11
      },
      {
        "confidence": 90,
        "height": 14,
        "left": 798,
        "text": "25t",
        "top": 390,
        "width": 39
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 847,
        "text": "November,",
        "top": 390,
        "width": 104
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 965,
        "text": "2017.",
        "top": 390,
        "width": 58
      },
      {
        "confidence": 88,
        "height": 14,
        "left": 277,
        "text": "As",
        "top": 429,
        "width": 22
      },
      {
        "confidence": 88,
        "height": 14,
        "left": 319,
        "text": "per",
        "top": 433,
        "width": 30
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 367,
        "text": "directives",
        "top": 429,
        "width": 90
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 476,
        "text": "of",
        "top": 431,
        "width": 19
      },
      {
        "confidence": 96,
        "height": 20,
        "left": 511,
        "text": "Ministry",
        "top": 431,
        "width": 78
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 608,
        "text": "of",
        "top": 433,
        "width": 18
      },
      {
        "confidence": 93,
        "height": 14,
        "left": 642,
        "text": "Commerce",
        "top": 434,
        "width": 102
      },
      {
        "confidence": 91,
        "height": 15,
        "left": 763,
        "text": "&",
        "top": 433,
        "width": 15
      },
      {
        "confidence": 93,
        "height": 19,
        "left": 797,
        "text": "Industry,",
        "top": 433,
        "width": 88
      },
      {
        "confidence": 92,
        "height": 18,
        "left": 906,
        "text": "SEEPZ-SEZ,",
        "top": 433,
        "width": 120
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 212,
        "text": "Administration",
        "top": 454,
        "width": 143
      },
      {
        "confidence": 94,
        "height": 14,
        "left": 366,
        "text": "is",
        "top": 456,
        "width": 15
      },
      {
        "confidence": 94,
        "height": 19,
        "left": 392,
        "text": "organizing",
        "top": 457,
        "width": 100
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 502,
        "text": "\u201cCommunal",
        "top": 458,
        "width": 113
      },
      {
        "confidence": 96,
        "height": 18,
        "left": 626,
        "text": "Harmony",
        "top": 460,
        "width": 88
      },
      {
        "confidence": 96,
        "height": 19,
        "left": 725,
        "text": "Campaign",
        "top": 460,
        "width": 97
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 834,
        "text": "Week\u201d",
        "top": 460,
        "width": 60
      },
      {
        "confidence": 95,
        "height": 15,
        "left": 906,
        "text": "from",
        "top": 460,
        "width": 43
      },
      {
        "confidence": 94,
        "height": 15,
        "left": 964,
        "text": "19%",
        "top": 460,
        "width": 34
      },
      {
        "confidence": 96,
        "height": 12,
        "left": 1009,
        "text": "to",
        "top": 462,
        "width": 18
      },
      {
        "confidence": 87,
        "height": 15,
        "left": 212,
        "text": "25th",
        "top": 481,
        "width": 34
      },
      {
        "confidence": 96,
        "height": 19,
        "left": 254,
        "text": "November,",
        "top": 482,
        "width": 100
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 364,
        "text": "2017",
        "top": 484,
        "width": 46
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 418,
        "text": "and",
        "top": 485,
        "width": 36
      },
      {
        "confidence": 96,
        "height": 19,
        "left": 462,
        "text": "\u201cFlag",
        "top": 485,
        "width": 48
      },
      {
        "confidence": 93,
        "height": 19,
        "left": 518,
        "text": "Day\u201d",
        "top": 486,
        "width": 43
      },
      {
        "confidence": 96,
        "height": 10,
        "left": 568,
        "text": "on",
        "top": 490,
        "width": 22
      },
      {
        "confidence": 52,
        "height": 15,
        "left": 599,
        "text": "24",
        "top": 486,
        "width": 36
      },
      {
        "confidence": 96,
        "height": 18,
        "left": 642,
        "text": "November,",
        "top": 487,
        "width": 101
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 752,
        "text": "2017.",
        "top": 487,
        "width": 53
      },
      {
        "confidence": 97,
        "height": 16,
        "left": 274,
        "text": "The",
        "top": 527,
        "width": 35
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 317,
        "text": "National",
        "top": 529,
        "width": 80
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 405,
        "text": "Foundation",
        "top": 530,
        "width": 110
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 523,
        "text": "for",
        "top": 531,
        "width": 26
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 557,
        "text": "Communal",
        "top": 531,
        "width": 104
      },
      {
        "confidence": 92,
        "height": 19,
        "left": 670,
        "text": "Harmony",
        "top": 533,
        "width": 89
      },
      {
        "confidence": 92,
        "height": 19,
        "left": 767,
        "text": "(NFCH),",
        "top": 533,
        "width": 74
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 852,
        "text": "set",
        "top": 536,
        "width": 26
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 887,
        "text": "up",
        "top": 538,
        "width": 26
      },
      {
        "confidence": 95,
        "height": 15,
        "left": 921,
        "text": "in",
        "top": 534,
        "width": 17
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 949,
        "text": "1992",
        "top": 534,
        "width": 46
      },
      {
        "confidence": 96,
        "height": 11,
        "left": 1004,
        "text": "as",
        "top": 539,
        "width": 21
      },
      {
        "confidence": 96,
        "height": 11,
        "left": 210,
        "text": "an",
        "top": 558,
        "width": 22
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 244,
        "text": "autonomous",
        "top": 557,
        "width": 120
      },
      {
        "confidence": 96,
        "height": 20,
        "left": 377,
        "text": "body",
        "top": 557,
        "width": 45
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 434,
        "text": "under",
        "top": 558,
        "width": 57
      },
      {
        "confidence": 96,
        "height": 21,
        "left": 503,
        "text": "Ministry",
        "top": 558,
        "width": 78
      },
      {
        "confidence": 97,
        "height": 15,
        "left": 593,
        "text": "of",
        "top": 560,
        "width": 19
      },
      {
        "confidence": 97,
        "height": 15,
        "left": 623,
        "text": "Home",
        "top": 560,
        "width": 54
      },
      {
        "confidence": 96,
        "height": 18,
        "left": 688,
        "text": "Affairs,",
        "top": 561,
        "width": 68
      },
      {
        "confidence": 97,
        "height": 16,
        "left": 769,
        "text": "The",
        "top": 561,
        "width": 36
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 817,
        "text": "Foundation",
        "top": 562,
        "width": 112
      },
      {
        "confidence": 96,
        "height": 20,
        "left": 942,
        "text": "provides",
        "top": 562,
        "width": 81
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 210,
        "text": "financial",
        "top": 582,
        "width": 81
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 308,
        "text": "assistance",
        "top": 584,
        "width": 99
      },
      {
        "confidence": 96,
        "height": 12,
        "left": 423,
        "text": "to",
        "top": 588,
        "width": 18
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 458,
        "text": "those",
        "top": 586,
        "width": 50
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 525,
        "text": "children",
        "top": 587,
        "width": 76
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 619,
        "text": "who",
        "top": 588,
        "width": 38
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 675,
        "text": "become",
        "top": 588,
        "width": 71
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 762,
        "text": "destitute",
        "top": 589,
        "width": 85
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 864,
        "text": "and",
        "top": 590,
        "width": 37
      },
      {
        "confidence": 96,
        "height": 19,
        "left": 918,
        "text": "orphan",
        "top": 591,
        "width": 69
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 1004,
        "text": "in",
        "top": 591,
        "width": 18
      },
      {
        "confidence": 95,
        "height": 18,
        "left": 210,
        "text": "communal,",
        "top": 612,
        "width": 106
      },
      {
        "confidence": 95,
        "height": 17,
        "left": 324,
        "text": "caste,",
        "top": 614,
        "width": 53
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 386,
        "text": "ethnic",
        "top": 613,
        "width": 58
      },
      {
        "confidence": 97,
        "height": 10,
        "left": 452,
        "text": "or",
        "top": 619,
        "width": 19
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 479,
        "text": "terrorist",
        "top": 615,
        "width": 76
      },
      {
        "confidence": 96,
        "height": 19,
        "left": 562,
        "text": "violence,",
        "top": 616,
        "width": 80
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 652,
        "text": "up",
        "top": 621,
        "width": 24
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 684,
        "text": "to",
        "top": 619,
        "width": 16
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 709,
        "text": "the",
        "top": 618,
        "width": 30
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 746,
        "text": "age",
        "top": 623,
        "width": 30
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 785,
        "text": "of",
        "top": 618,
        "width": 18
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 809,
        "text": "25",
        "top": 619,
        "width": 22
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 838,
        "text": "years.",
        "top": 624,
        "width": 58
      },
      {
        "confidence": 95,
        "height": 15,
        "left": 271,
        "text": "You",
        "top": 657,
        "width": 36
      },
      {
        "confidence": 95,
        "height": 11,
        "left": 324,
        "text": "are",
        "top": 662,
        "width": 28
      },
      {
        "confidence": 96,
        "height": 18,
        "left": 368,
        "text": "cordially",
        "top": 660,
        "width": 81
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 464,
        "text": "invited",
        "top": 660,
        "width": 63
      },
      {
        "confidence": 96,
        "height": 12,
        "left": 544,
        "text": "to",
        "top": 664,
        "width": 17
      },
      {
        "confidence": 95,
        "height": 19,
        "left": 576,
        "text": "participate",
        "top": 663,
        "width": 102
      },
      {
        "confidence": 95,
        "height": 14,
        "left": 693,
        "text": "in",
        "top": 664,
        "width": 17
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 727,
        "text": "the",
        "top": 665,
        "width": 29
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 771,
        "text": "Seminar",
        "top": 666,
        "width": 82
      },
      {
        "confidence": 96,
        "height": 12,
        "left": 868,
        "text": "to",
        "top": 669,
        "width": 17
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 902,
        "text": "be",
        "top": 666,
        "width": 21
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 939,
        "text": "held",
        "top": 667,
        "width": 41
      },
      {
        "confidence": 96,
        "height": 10,
        "left": 996,
        "text": "on",
        "top": 671,
        "width": 23
      },
      {
        "confidence": 93,
        "height": 17,
        "left": 206,
        "text": "22.11.2017",
        "top": 681,
        "width": 109
      },
      {
        "confidence": 92,
        "height": 22,
        "left": 327,
        "text": "(04:30pm-06:30pm)",
        "top": 684,
        "width": 189
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 527,
        "text": "and",
        "top": 688,
        "width": 35
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 572,
        "text": "also",
        "top": 689,
        "width": 38
      },
      {
        "confidence": 96,
        "height": 18,
        "left": 620,
        "text": "requested",
        "top": 691,
        "width": 92
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 723,
        "text": "to",
        "top": 693,
        "width": 18
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 751,
        "text": "donate",
        "top": 692,
        "width": 64
      },
      {
        "confidence": 96,
        "height": 19,
        "left": 826,
        "text": "generously",
        "top": 693,
        "width": 105
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 942,
        "text": "towards",
        "top": 693,
        "width": 76
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 206,
        "text": "this",
        "top": 708,
        "width": 34
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 251,
        "text": "noble",
        "top": 710,
        "width": 52
      },
      {
        "confidence": 96,
        "height": 11,
        "left": 315,
        "text": "cause.",
        "top": 715,
        "width": 59
      },
      {
        "confidence": 96,
        "height": 20,
        "left": 387,
        "text": "Kindly",
        "top": 712,
        "width": 61
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 459,
        "text": "contact",
        "top": 716,
        "width": 70
      },
      {
        "confidence": 96,
        "height": 19,
        "left": 540,
        "text": "Receptionist",
        "top": 716,
        "width": 117
      },
      {
        "confidence": 93,
        "height": 15,
        "left": 668,
        "text": "in",
        "top": 718,
        "width": 18
      },
      {
        "confidence": 93,
        "height": 15,
        "left": 698,
        "text": "SEEPZ",
        "top": 719,
        "width": 64
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 774,
        "text": "Service",
        "top": 720,
        "width": 67
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 854,
        "text": "Centre",
        "top": 721,
        "width": 64
      },
      {
        "confidence": 96,
        "height": 20,
        "left": 930,
        "text": "Building,",
        "top": 720,
        "width": 87
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 205,
        "text": "Ground",
        "top": 736,
        "width": 71
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 290,
        "text": "Floor",
        "top": 737,
        "width": 49
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 351,
        "text": "to",
        "top": 741,
        "width": 17
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 382,
        "text": "donate",
        "top": 739,
        "width": 63
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 457,
        "text": "your",
        "top": 745,
        "width": 45
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 513,
        "text": "contribution",
        "top": 743,
        "width": 118
      },
      {
        "confidence": 96,
        "height": 10,
        "left": 644,
        "text": "or",
        "top": 749,
        "width": 19
      },
      {
        "confidence": 96,
        "height": 20,
        "left": 676,
        "text": "directly",
        "top": 745,
        "width": 71
      },
      {
        "confidence": 96,
        "height": 19,
        "left": 758,
        "text": "drop",
        "top": 747,
        "width": 44
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 814,
        "text": "the",
        "top": 748,
        "width": 30
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 857,
        "text": "donation",
        "top": 749,
        "width": 85
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 956,
        "text": "in",
        "top": 748,
        "width": 19
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 988,
        "text": "the",
        "top": 748,
        "width": 29
      },
      {
        "confidence": 96,
        "height": 20,
        "left": 203,
        "text": "following",
        "top": 763,
        "width": 84
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 294,
        "text": "mentioned",
        "top": 766,
        "width": 102
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 403,
        "text": "counters:",
        "top": 770,
        "width": 89
      },
      {
        "confidence": 90,
        "height": 15,
        "left": 269,
        "text": "1.",
        "top": 810,
        "width": 13
      },
      {
        "confidence": 95,
        "height": 20,
        "left": 299,
        "text": "Reception",
        "top": 810,
        "width": 94
      },
      {
        "confidence": 96,
        "height": 13,
        "left": 401,
        "text": "counter:",
        "top": 816,
        "width": 78
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 589,
        "text": "Box",
        "top": 817,
        "width": 37
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 632,
        "text": "No.",
        "top": 818,
        "width": 31
      },
      {
        "confidence": 92,
        "height": 14,
        "left": 674,
        "text": "1",
        "top": 819,
        "width": 6
      },
      {
        "confidence": 92,
        "height": 18,
        "left": 691,
        "text": "(",
        "top": 820,
        "width": 3
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 703,
        "text": "Ground",
        "top": 820,
        "width": 71
      },
      {
        "confidence": 95,
        "height": 20,
        "left": 783,
        "text": "Floor)",
        "top": 821,
        "width": 53
      },
      {
        "confidence": 93,
        "height": 15,
        "left": 265,
        "text": "2.",
        "top": 842,
        "width": 16
      },
      {
        "confidence": 92,
        "height": 15,
        "left": 298,
        "text": "SEEPZ",
        "top": 843,
        "width": 65
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 372,
        "text": "Gate",
        "top": 845,
        "width": 42
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 427,
        "text": "No.",
        "top": 845,
        "width": 28
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 470,
        "text": "1:",
        "top": 846,
        "width": 13
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 588,
        "text": "Box",
        "top": 849,
        "width": 37
      },
      {
        "confidence": 95,
        "height": 14,
        "left": 632,
        "text": "No.",
        "top": 851,
        "width": 30
      },
      {
        "confidence": 58,
        "height": 16,
        "left": 671,
        "text": "2&3",
        "top": 851,
        "width": 50
      },
      {
        "confidence": 92,
        "height": 15,
        "left": 263,
        "text": "3.",
        "top": 881,
        "width": 16
      },
      {
        "confidence": 92,
        "height": 15,
        "left": 296,
        "text": "SEEPZ",
        "top": 882,
        "width": 66
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 370,
        "text": "Gate",
        "top": 884,
        "width": 43
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 425,
        "text": "No.",
        "top": 884,
        "width": 29
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 466,
        "text": "2:",
        "top": 885,
        "width": 16
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 587,
        "text": "Box",
        "top": 888,
        "width": 36
      },
      {
        "confidence": 95,
        "height": 14,
        "left": 631,
        "text": "No.",
        "top": 890,
        "width": 30
      },
      {
        "confidence": 95,
        "height": 15,
        "left": 670,
        "text": "4",
        "top": 890,
        "width": 10
      },
      {
        "confidence": 92,
        "height": 13,
        "left": 262,
        "text": "4.",
        "top": 922,
        "width": 16
      },
      {
        "confidence": 91,
        "height": 15,
        "left": 295,
        "text": "SEEPZ",
        "top": 922,
        "width": 66
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 369,
        "text": "Gate",
        "top": 924,
        "width": 43
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 424,
        "text": "No.",
        "top": 924,
        "width": 29
      },
      {
        "confidence": 96,
        "height": 16,
        "left": 466,
        "text": "3:",
        "top": 924,
        "width": 15
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 587,
        "text": "Box",
        "top": 929,
        "width": 35
      },
      {
        "confidence": 95,
        "height": 14,
        "left": 630,
        "text": "No.",
        "top": 930,
        "width": 30
      },
      {
        "confidence": 79,
        "height": 14,
        "left": 669,
        "text": "5",
        "top": 930,
        "width": 11
      },
      {
        "confidence": 91,
        "height": 18,
        "left": 728,
        "text": "(R.",
        "top": 1124,
        "width": 25
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 763,
        "text": "Harish",
        "top": 1124,
        "width": 66
      },
      {
        "confidence": 96,
        "height": 21,
        "left": 837,
        "text": "Chaudhary)",
        "top": 1126,
        "width": 118
      },
      {
        "confidence": 91,
        "height": 14,
        "left": 663,
        "text": "Asstt.",
        "top": 1147,
        "width": 53
      },
      {
        "confidence": 96,
        "height": 20,
        "left": 727,
        "text": "Development",
        "top": 1147,
        "width": 123
      },
      {
        "confidence": 86,
        "height": 19,
        "left": 859,
        "text": "Commissioner,",
        "top": 1150,
        "width": 144
      },
      {
        "confidence": 91,
        "height": 16,
        "left": 777,
        "text": "SEEPZ-SEZ",
        "top": 1173,
        "width": 114
      },
      {
        "confidence": 96,
        "height": 17,
        "left": 191,
        "text": "To,",
        "top": 1184,
        "width": 27
      },
      {
        "confidence": 87,
        "height": 14,
        "left": 226,
        "text": "1.",
        "top": 1209,
        "width": 12
      },
      {
        "confidence": 95,
        "height": 14,
        "left": 254,
        "text": "ALL",
        "top": 1210,
        "width": 30
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 300,
        "text": "Units",
        "top": 1211,
        "width": 51
      },
      {
        "confidence": 91,
        "height": 10,
        "left": 359,
        "text": "in",
        "top": 1216,
        "width": 16
      },
      {
        "confidence": 90,
        "height": 16,
        "left": 385,
        "text": "SEEPZ-SEZ",
        "top": 1212,
        "width": 112
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 224,
        "text": "2.",
        "top": 1233,
        "width": 14
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 255,
        "text": "Office",
        "top": 1233,
        "width": 54
      },
      {
        "confidence": 96,
        "height": 14,
        "left": 318,
        "text": "Notice",
        "top": 1235,
        "width": 53
      },
      {
        "confidence": 96,
        "height": 15,
        "left": 385,
        "text": "Board",
        "top": 1236,
        "width": 53
      },
      {
        "confidence": 94,
        "height": 65,
        "left": 58,
        "text": "|",
        "top": 1586,
        "width": 6
      },
      {
        "confidence": 6,
        "height": 22,
        "left": 1056,
        "text": "_\u2014",
        "top": 1629,
        "width": 120
      },
      {
        "confidence": 96,
        "height": 22,
        "left": 835,
        "text": "Scanned",
        "top": 1702,
        "width": 127
      },
      {
        "confidence": 93,
        "height": 28,
        "left": 975,
        "text": "by",
        "top": 1702,
        "width": 34
      },
      {
        "confidence": 92,
        "height": 22,
        "left": 1019,
        "text": "CamScanner",
        "top": 1702,
        "width": 190
      }
    ]
  }
  