import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import { OcrAccount } from "../../../entities";
import { dataSource } from "../../../core/data-source";
import Container from "typedi";
import { DataSource } from "typeorm";
import {
    Body,
    Controller,
    Get,
    Post,
    Put,
    Request,
    Route,
    Security,
    Tags,
    Delete,
} from "tsoa";
import {
    InsertOcrAccountRequest,
    DeleteOcrAccount,
    OcrAccountListResponse,
    SaveOcrAccountResponse,
    DeleteOcrAccountResponse,
} from "../doc/ocr-account-interface";

@Route("")
@Tags("OCR Account")
export class OcrAccountController extends Controller {
    @Security("bearerAuth")
    @Get("ocr-accounts")
    async ocrAccountList(
        @Request() request: any
    ): Promise<OcrAccountListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };

            let whereCondition = { clientId: request.userDetails.client_id };
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(OcrAccount),
                {
                    where: whereCondition,
                    order: {
                        createdOn: "DESC",
                    },
                }
            );

            if (results?.length > 0) {
                apiResponse.data = results;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("ocr-accounts")
    async saveOcrAccount(
        @Body() requestBody: InsertOcrAccountRequest,
        @Request() request: any
    ): Promise<SaveOcrAccountResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            let ocrConfig = requestBody;
            const OcrModel = new OcrAccount();
            OcrModel.clientId = request.userDetails.client_id;
            OcrModel.name = ocrConfig.name;
            OcrModel.type = ocrConfig.type;
            OcrModel.config = JSON.stringify(ocrConfig.config);
            OcrModel.isConfigured = 1;
            OcrModel.createdBy = request.userDetails.id;

            const result = await Container.get(DataSource).manager.save(
                OcrModel
            );
            if (result?.id) {
                apiResponse.data = { insertedId: result.id };
                this.setStatus(201);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Put("ocr-accounts/:id")
    async updateOcrAccount(
        @Body() requestBody: InsertOcrAccountRequest,
        @Request() request: any
    ): Promise<SaveOcrAccountResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            const payload = {
                name: requestBody.name,
                type: requestBody.type,
                config: JSON.stringify(requestBody.config),
            };

            const updateResult = await dataSource
                .getRepository(OcrAccount)
                .update({ id: request.params.id }, payload);
            apiResponse.data = updateResult;
            
            if (!updateResult?.affected) {
                this.setStatus(204);
            } else {
                this.setStatus(200);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("ocr-accounts")
    async deleteOcrAccount(
        @Body() requestBody: DeleteOcrAccount
    ): Promise<DeleteOcrAccountResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            const widgetResult = await dataSource
                .getRepository(OcrAccount)
                .delete(requestBody.id);
            apiResponse.data = widgetResult;

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}