import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import fs from 'fs';
import fetch from "node-fetch";
import { OcrReader, SettingConfig, OcrAccount, Notification, Users } from "../../../entities";
import { dataSource } from "../../../core/data-source";
import Container from "typedi";
import { DataSource, In, LessThan, Between } from "typeorm";
import {
    Body,
    Controller,
    Get,
    Put,
    Post,
    Query,
    Request,
    Route,
    Security,
    Path,
    Tags,
    Delete,
    Hidden,
} from "tsoa";
import {
    SyncOcrReaderFiles,
    SyncOcrReaderFilesResponse,
    FileReaderResponse,
    InsertOcrReaderRequest,
    UpdateOcrReaderRequest,
    DeleteOcrReader,
    OcrReaderListResponse,
    SaveOcrReaderResponse,
    DeleteOcrReaderResponse,
    OcrReaderDetailsResponse,
    GenerateDocxRequest,
    GenerateDocxResponse,
} from "../doc/ocr-reader-interface";
import { CommonUtil } from "utils/common.util";
import { S3 } from "../services/s3.service";
import { GoogleDrive } from "../services/googleDrive.service";
import { ImageToExcelService } from "../services/imagetoexcel.service";
import { PdfToTextService } from "../services/pdfToText.service";
import { OcrReaderService } from "../services/ocr-reader.service";
import axios from "axios";
import { NotificationService } from "../../notification/services/notification.service";
import moment from "moment";

@Route("")
@Tags("OCR Reader")
export class OcrReaderController extends Controller {
    private imageToExcelService: ImageToExcelService =
        new ImageToExcelService();
    private ocrReaderService: OcrReaderService = new OcrReaderService();
    private pdfToTextService: PdfToTextService = new PdfToTextService();
    private NotificationService: NotificationService = new NotificationService();

    
    @Security("bearerAuth")
    @Get("ocr-reader")
    async ocrReaderList(
        @Request() request: any,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<OcrReaderListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };
            const selectedFields: any = [
                "id",
                "clientId",
                "name",
                "fileSource",
                "fileSourceId",
                "modelType",
                "isDataParsed",
                "jobId",
                "status",
                "filePath",
                "fileConfig",
                "pageCount",
                "createdOn",
            ];

            let whereCondition = { clientId: request.userDetails.client_id, isDeleted: 0 };
            const totalRecordCount = await Container.get(DataSource)
                .getRepository(OcrReader)
                .count({ where: whereCondition });
            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["id"] = sortOrder;
            }

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(OcrReader),
                {
                    where: whereCondition,
                    select: selectedFields,
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );

            if (results?.length > 0) {
                apiResponse.data = results;
                apiResponse.recordsTotal = totalRecordCount;
                apiResponse.recordsFiltered = totalRecordCount;

                const totalPages = Math.ceil(totalRecordCount / pageSize);
                apiResponse.totalPages = totalPages;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("ocr-reader/usage/:clientId")
    async ocrReaderUsage(@Path() clientId: string): Promise<any> {
        try {
            const apiResponse = {
                data: {},
                error: null,
            };
            let ocrDetails = await this.getOCRDetails(clientId);
            let extractTableService= await this.getForImageToExcel(clientId);
            let ocrWebService:any = await this.pdfToTextService.getOCRWebServiceAccountUsage();
            apiResponse.data = {
                used: ocrDetails.totalUsed,
                credits: ocrDetails.credits,
                remaining: ocrDetails.credits - ocrDetails.totalUsed,
                imageToExcel:ocrDetails.imageToExcel,
            pdfToExcel:ocrDetails.pdfToExcel,
            imageToWord:ocrDetails.imageToWord,
            pdfToWord:ocrDetails.pdfToWord,
            totalFiles:ocrDetails.totalFiles,
            filesimageToExcel:ocrDetails.filesimageToExcel,
            filespdfToExcel:ocrDetails.filespdfToExcel,
            filesimageToWord:ocrDetails.filesimageToWord,
            filespdfToWord:ocrDetails.filespdfToWord,
            startDate:ocrDetails.startDate,
            endDate:ocrDetails.endDate,
            extractTableService:extractTableService,
            ocrWebService:ocrWebService?.data
            };
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            //OLD Code commented
            // const results = await dbService._findQueryService(
            //     Container.get(DataSource).getRepository(SettingConfig),
            //     {
            //         where: { type: "OCR_API_KEY", clientId: clientId },
            //     }
            // );
            // if (results?.length) {
            //     const config = results[0].config
            //         ? JSON.parse(results[0].config)
            //         : {};
            //     if (config?.apiKey) {

            //         const responseResult =
            //             await this.imageToExcelService.checkKeyStatus(config.apiKey);
            //         if (responseResult) {
            //             apiResponse.data = responseResult.usage;
            //             this.setStatus(200);
            //         } else {
            //             let msg = "Something went wrong, Please try again";
            //             if (responseResult?.Message) {
            //                 msg = responseResult.Message;
            //             }
            //             apiResponse.error = msg;
            //         }

            //         return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            //     }
            // }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("ocr-reader/file-reader")
    async prepareOcrData(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<FileReaderResponse | unknown> {
        this.setStatus(500);
        try {
            console.log('requestBody', requestBody);
            let apiResponse = {
                data: {},
                error: null,
            };
            if (requestBody.modelType === "pdf-to-word" || requestBody.modelType === "image-to-word") {
                let docDownloadURL, docDownloadPath = null;
                // const docConversionResult = await this.pdfToTextService.pdfToDocConvert(requestBody.filePath);
                
                if (requestBody.modelType === "image-to-word") {
                    const docConversionResult=await this.pdfToTextService.imgToWordConvert(process.env.BASE_URL+"/"+requestBody.filePath.replace(/\\/g, '/'));
                    if (docConversionResult.status && docConversionResult.data?.document_url) {
                        ({ docDownloadURL, docDownloadPath } = await this.downloadOCRServiceDoc(docConversionResult, docDownloadURL, docDownloadPath));
                    } else if (!docConversionResult.status || docConversionResult.error) {
                        this.setStatus(docConversionResult.responseCode);
                        apiResponse.error = docConversionResult.error || "Something went wrong, Please try again";
                        return CommonHelper.apiSwaggerErrorResponse(apiResponse);
                    }
                //   apiResponse.data = {
                //     images_data: [
                //       {
                //         url: requestBody.filePath,
                //         // imageUrl: `${apiUrl}/get-file?filename=${obj.url}`,
                //         imageUrl: `${requestBody.filePath}`,
                //         height: 'auto',
                //         width: 'auto',
                //       }
                //     ]
                //   };
                //   apiResponse.data['document_url'] = docDownloadURL;
                //   apiResponse.data['document_path'] = docDownloadPath;
                  apiResponse.data=docConversionResult.data;
                  apiResponse.data['document_url'] = docDownloadURL;
                  apiResponse.data['document_path'] = docDownloadPath;
                  this.setStatus(200);
                  return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
                }
                await this.getImagesData(requestBody, apiResponse, docDownloadURL, docDownloadPath);
            } else if (requestBody.modelType === "text-from-pdf") {
                await this.text_from_pdf(requestBody, apiResponse);
            } else if (requestBody.modelType === "image-to-excel") {
                await this.convert_image_and_pdf_to_excel(apiResponse, requestBody);
            } else if (requestBody.modelType === "pdf-to-excel") {
                await this.convert_image_and_pdf_to_excel(apiResponse, requestBody);
            } else {
                apiResponse.error = "Please configure valid model type";
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    private async downloadOCRServiceDoc(docConversionResult: { responseCode: number; status: boolean; data: any; error: any; }, docDownloadURL: any, docDownloadPath: any) {
        const localPath = `ocr-docx/ocrservice-${new Date().getTime()}.docx`;
        const docDownloaded = await this.pdfToTextService.downloadDocFromURL(docConversionResult.data.document_url, `public/${localPath}`);
        if (docDownloaded) {
            docDownloadURL = `${process.env.BASE_URL}/${localPath}`;
            docDownloadPath = localPath;
        }
        return { docDownloadURL, docDownloadPath };
    }

    private async getImagesData(requestBody: any, apiResponse: { data: {}; error: any; }, docDownloadURL: any, docDownloadPath: any) {
        const result = await this.pdfToTextService.readFileAsPythonAPI(
            requestBody.filePath
        );
        if (result?.status && result?.data) {
            apiResponse.data = result.data;
            let docConversionResult:any={status:true,data:{document_url:result.data.document_url},responseCode:200,error:null};
            
            ({ docDownloadURL, docDownloadPath } = await this.downloadOCRServiceDoc(docConversionResult, docDownloadURL, docDownloadPath));
            
            apiResponse.data['document_url'] = docDownloadURL;
            apiResponse.data['document_path'] = docDownloadPath;
            this.setStatus(200);
        } else {
            apiResponse.error =
                "Something went wrong, Please try again";
        }
    }

    private async image_and_pdf_to_excel(apiResponse: { data: {}; error: any; }, requestBody: any) {
        console.log('image_and_pdf_to_excel called.', apiResponse);
        const results = await dbService._findQueryService(
            Container.get(DataSource).getRepository(SettingConfig),
            {
                where: { type: "OCR_API_KEY" },
            }
        );
        if (results?.length) {
            const config = results[0].config
                ? JSON.parse(results[0].config)
                : {};
            if (config?.apiKey) {
                const apiResData = await this.imageToExcelService.azureApi(requestBody.filePath);
                // console.log('apiResData', JSON.stringify(apiResData, null, 4));
                if (apiResData?.JobId) {
                  apiResponse.data = apiResData;
                  apiResponse.data['pageCount'] = 1;
                  if (apiResponse.data && apiResponse.data['Pages']) {
                      apiResponse.data['pageCount'] = apiResponse.data['Pages'];
                  }
                  // apiResponse.data['JobId'] = apiResData.jobId;
                  // apiResponse.data['pageCount'] = 0;
                  // apiResponse.data['JobStatus'] = 'Processing';
                  this.setStatus(200);
                }
                // if (config?.apiKey === "dummy_key") {
                //     apiResponse.data = imageToExcelData;
                //     this.setStatus(200);
                // } else {
                //     await this.img_2_excel_service_create_job(config, requestBody, apiResponse);
                // }

                // apiResponse.data['pageCount'] = 1;
                // if (apiResponse.data && apiResponse.data['Pages']) {
                //     apiResponse.data['pageCount'] = apiResponse.data['Pages'];
                // }
            } else {
                apiResponse.error = "Please configure API Key";
            }
        } else {
            apiResponse.error = "Please configure API Key";
        }
    }

    private async img_2_excel_service_create_job(config: any, requestBody: any, apiResponse: { data: {}; error: any; }) {
        const responseResult = await this.imageToExcelService.createJob(
            config.apiKey,
            requestBody.filePath
        );
        if (responseResult?.JobId) {
            apiResponse.data = responseResult;
            this.setStatus(200);
        } else {
            let msg = "Something went wrong, Please try again";
            if (responseResult?.Message) {
                msg = responseResult.Message;
            }
            apiResponse.error = msg;
        }
    }

    private async text_from_pdf(requestBody: any, apiResponse: { data: {}; error: any; }) {
        const result = await this.pdfToTextService.readFile(
            requestBody.filePath
        );
        if (result?.status && result?.data) {
            apiResponse.data = result.data;
            this.setStatus(200);
        } else {
            apiResponse.error =
                "Something went wrong, Please try again";
        }
    }
    private async convert_image_and_pdf_to_excel(apiResponse: { data: {}; error: any; }, requestBody: any) {
        const excelData = await this.pdfToTextService.extractTableData(process.env.BASE_URL+"/"+requestBody.filePath.replace(/\\/g, '/'));
        if (excelData?.status && excelData?.data) {
            apiResponse.data = excelData.data.result;
            apiResponse.data['pageCount'] = excelData.data.result?.pageCount;
            apiResponse.data['JobStatus'] = "Success";
            this.setStatus(200);
        } else {
            apiResponse.error =
                "Something went wrong, Please try again";
        }
    }

    @Security("bearerAuth")
    @Post("ocr-reader")
    async saveOcrReader(
        @Body() requestBody: InsertOcrReaderRequest,
        @Request() request: any
    ): Promise<SaveOcrReaderResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            let ocrReaderConfig = requestBody;
            const OcrReaderModel = new OcrReader();
            OcrReaderModel.clientId = request.userDetails.client_id;
            OcrReaderModel.name = ocrReaderConfig.name;
            OcrReaderModel.filePath = ocrReaderConfig.filePath;
            OcrReaderModel.modelType = ocrReaderConfig.modelType;
            OcrReaderModel.pageCount = String(ocrReaderConfig.pageCount);
            OcrReaderModel.createdBy = request.userDetails.id;
            OcrReaderModel.jobId = ocrReaderConfig.JobId;
            OcrReaderModel.status = 'COMPLETED';
            if (ocrReaderConfig.JobStatus === 'Processing') {
                OcrReaderModel.status = 'IN_PROCESS';
            }

            if (ocrReaderConfig.fileConfig) {
                OcrReaderModel.fileConfig = JSON.stringify(
                    ocrReaderConfig.fileConfig
                );
            }
            if (ocrReaderConfig?.isDataParsed) {
                OcrReaderModel.isDataParsed = ocrReaderConfig.isDataParsed;
            }

            const result = await Container.get(DataSource).manager.save(
                OcrReaderModel
            );
            if (result?.id) {
                apiResponse.data = { insertedId: result.id };
                this.setStatus(201);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Put("ocr-reader/:id")
    async updateOcrReader(
        @Body() requestBody: UpdateOcrReaderRequest,
        @Request() request: any
    ): Promise<SaveOcrReaderResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            let isDataFound = false;
            let payload: any = {};

            if (requestBody?.name) {
                payload.name = requestBody.name;
                isDataFound = true;
            }
            if (requestBody?.modelType) {
                payload.modelType = requestBody.modelType;
                isDataFound = true;
            }
            if (requestBody?.fileConfig) {
                payload.fileConfig = JSON.stringify(requestBody.fileConfig);
                isDataFound = true;
            }
            if (requestBody?.isDataParsed) {
                payload.isDataParsed = requestBody.isDataParsed;
                isDataFound = true;
            }

            let updateResult = null;
            if (isDataFound) {
                updateResult = await dataSource
                    .getRepository(OcrReader)
                    .update({ id: request.params.id }, payload);
                apiResponse.data = updateResult;
            }
            if (!updateResult?.affected) {
                this.setStatus(204);
            } else {
                this.setStatus(200);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("ocr-reader/update-current-status")
    async ocrReaderUpdateStatus(
        @Body() requestBody: any | null,
        @Request() request: any
    ): Promise<SaveOcrReaderResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                error: null,
                message: null
            };
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(SettingConfig),
                {
                    where: { type: "OCR_API_KEY" },
                }
            );
            if (!results?.length) {
                apiResponse.error = "Please configure API Key";
                this.setStatus(400);
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }
            const config = results[0].config ? JSON.parse(results[0].config) : {};
            if (!config?.apiKey) {
                apiResponse.error = "Please configure API Key";
                this.setStatus(400);
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }
            const apiKey = config.apiKey;
            if (apiKey === 'dummy_key') {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }
            const ocrResult: OcrReader[] = await dataSource.getRepository(OcrReader).find({
                where: {
                    status: 'IN_PROCESS',
                },
                select: ['id', 'jobId', 'status', 'modelType']
            });
            // console.log('ocrResult', ocrResult);
            if (!ocrResult?.length) {
                this.setStatus(200);
                apiResponse.message = `No OCR data found`;
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }
            for (const ocrValue of ocrResult) {
                if (ocrValue.modelType === 'pdf-to-word') {
                    continue;
                }

                // let ocrDetails: any = await this.imageToExcelService.azureStausApi(ocrValue.jobId);
                // if (ocrDetails?.tables) {
                //     ocrDetails.Tables = ocrDetails.tables;
                //     delete ocrDetails.tables;
                    
                //     const payload: any = {
                //         pageCount: ocrDetails?.pages || 0,
                //         status: 'COMPLETED',
                //         fileConfig: JSON.stringify({
                //             ApiResponse: ocrDetails
                //         })
                //     };
                //     await dataSource.getRepository(OcrReader).update({ id: ocrValue.id }, payload);
                //     apiResponse.data.push(ocrValue.id);
                // }

                // const updateJobResult = await this.imageToExcelService.updateJobByJobId(apiKey, ocrValue.jobId);
                let updateJobResult: any = await this.imageToExcelService.azureStausApi(ocrValue.jobId);
                if (updateJobResult?.JobStatus === 'Success') {
                    let jobFileResponse = updateJobResult;
                    if(updateJobResult?.DownloadUrl){
                        jobFileResponse = await this.fetchDataFromDownloadUrl(updateJobResult)
                    }

                    let fileConfig = {
                        ApiResponse: jobFileResponse,
                        tableData: {
                            headerList: [],
                            bodyList: [],
                        },
                    };
                    const updateData = { status: 'COMPLETED', fileConfig: JSON.stringify(fileConfig), pageCount: updateJobResult?.Pages || 1 };
                    await dataSource.getRepository(OcrReader).update({ id: ocrValue.id }, updateData);
                    apiResponse.data.push(ocrValue.id);
                }
            }
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    async fetchDataFromDownloadUrl(updateJobResult: any) {
        try {
          if (!updateJobResult || !updateJobResult.DownloadUrl) {
            throw new Error("Invalid updateJobResult or missing DownloadUrl");
          }

          const response = await fetch(updateJobResult.DownloadUrl, {
            method: "GET",
            // Add any other headers or options you need here
          });

          if (!response.ok) {
            const errorText = await response.text(); // Capture the error response for debugging
            throw new Error(`Failed to fetch data. Status: ${response.status}. Error: ${errorText}`);
          }

          return await response.json();

        } catch (error) {
          console.error("Error fetching data:", error);
          throw error; // Re-throw the error to handle it further up the call stack
        }
      }
      
    @Security("bearerAuth")
    @Get("ocr-reader/:id")
    async getOcrReader(
        @Path() id: string,
        @Request() request: any
    ): Promise<OcrReaderDetailsResponse | unknown> {
        try {
            const apiResponse = {
                data: null,
            };
            let result: any = await dataSource
                .getRepository(OcrReader)
                .findOne({
                    where: {
                        id: id,
                        clientId: request.userDetails.client_id,
                    },
                });
            apiResponse.data = result;

            if (apiResponse.data) {
                if (apiResponse.data["fileConfig"]) {
                    apiResponse.data["fileConfig"] = JSON.parse(
                        apiResponse.data["fileConfig"]
                    );
                } else {
                    apiResponse.data["fileConfig"] = {};
                }
            } else {
                this.setStatus(204);
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("ocr-reader")
    async deleteOcrReader(
        @Body() requestBody: DeleteOcrReader
    ): Promise<DeleteOcrReaderResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            //get fileConfig first
            let configData = await dataSource.getRepository(OcrReader).findOne(
                {
                    where: {
                        id: In(requestBody.id)
                    },
                    select: {
                        fileConfig: true,
                        modelType: true
                    }
                }
            );
            if (configData?.modelType === "pdf-to-word") {
                await this.ocrReaderService.deleteRelatedFile(configData);
            }

            const widgetResult = await dataSource.getRepository(OcrReader)
                .createQueryBuilder()
                .update(OcrReader)
                .set({ fileConfig: '', isDeleted: 1 })
                .where("id IN (:...ids)", { ids: requestBody.id })
                .execute();
            apiResponse.data = widgetResult;

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("ocr-reader/validate-key/:key")
    async checkKeyUsage(
        @Path() key: string,
        @Request() request: any
    ): Promise<OcrReaderDetailsResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
                error: null,
            };

            if (key && key !== "dummy_key") {
                const responseResult =
                    await this.imageToExcelService.checkKeyStatus(key);
                if (responseResult) {
                    apiResponse.data = responseResult;
                    this.setStatus(200);
                } else {
                    let msg = "Something went wrong, Please try again";
                    if (responseResult?.Message) {
                        msg = responseResult.Message;
                    }
                    apiResponse.error = msg;
                }
            } else {
                apiResponse.error = "Please configure API Key";
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("ocr-reader/sync-files")
    async syncOcrReaderFiles(
        @Request() request: any,
        @Body() requestBody: SyncOcrReaderFiles
    ): Promise<SyncOcrReaderFilesResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
                error: null,
            };

            let result: any = await dataSource
                .getRepository(OcrAccount)
                .findOne({
                    where: {
                        id: requestBody.accountId,
                        clientId: request.userDetails.client_id,
                    },
                });
            if (!(result?.isConfigured && result?.config)) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);

            }

            let config = JSON.parse(result["config"]);

            if (result?.type === "s3") {
                const syncFileDetails = await S3.syncFiles(
                    config,
                    request.userDetails
                );
                if (
                    syncFileDetails?.status &&
                    syncFileDetails?.data?.length
                ) {
                    apiResponse.data = syncFileDetails.data;
                } else if (syncFileDetails?.error) {
                    apiResponse.error = syncFileDetails.error;
                }
            } else if (result?.type === "googleDrive") {
                const syncFileDetails = await GoogleDrive.syncFiles(
                    config,
                    request.userDetails
                );
                if (
                    syncFileDetails?.status &&
                    syncFileDetails?.data?.length
                ) {
                    apiResponse.data = syncFileDetails.data;
                } else if (syncFileDetails?.error) {
                    apiResponse.error = syncFileDetails.error;
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("ocr-reader/generate-docx")
    async GenerateDocxRequest(
        @Body() requestBody: GenerateDocxRequest,
        @Request() request: any
    ): Promise<GenerateDocxResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
                error: null,
            };

            const docxUploadDir = "./public/ocr-docx/";
            if (!fs.existsSync(docxUploadDir)) {
                fs.mkdirSync(docxUploadDir);
            }
            const filePath = `${docxUploadDir}${new Date().getTime()}.doc`;

            if (requestBody?.fileData && typeof requestBody.fileData === 'string') {
                const data = await fetch(requestBody.fileData);
                const blob = await data.arrayBuffer();

                fs.writeFileSync(filePath, Buffer.from(blob));
                if (fs.existsSync(filePath)) {
                    apiResponse.data = filePath.replace('./public', '');
                }
            } else if (requestBody.fileData?.length) {
                const fileDetails: any = await this.ocrReaderService.generateDocxFile(requestBody, filePath);
                if (fileDetails?.data) {
                    apiResponse.data = fileDetails.data;
                }
            } else {
                apiResponse.error = "Data is missing";
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("ocr-reader/credits/:clientId")
    async getOcrCredits(
        @Path() clientId: string,
        @Request() request: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
                error: null,
            };
            return await this.getRemainingCredit(clientId, request, apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("ocr-reader/delete-data")
    async deleteOCRData(
        @Body() requestBody: any,
        @Request() request: any
    ) {
        try {
            const apiResponse = {
                data: {},
                error: null,
            };
            const oneHourAgo = new Date();
            oneHourAgo.setHours(oneHourAgo.getHours() - 1); // Calculate the timestamp one hour ago

            let ocrRecords = await dataSource.getRepository(OcrReader).find({
                where: {
                    createdOn: LessThan(oneHourAgo), // Filter for records older than one hour,
                    //clientId:requestBody.clientId  //commented since we need to delete all clients ocr data 
                },
                select: {
                    fileConfig: true,
                    modelType: true,
                    id: true
                }
            });

            await this.ocrReaderService.deleteUnusedFile(ocrRecords);

            apiResponse.data = true;
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        }
        catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }

    }

    private async getForPDFToWord(clientId: string, request: any, apiResponse: { data: {}; error: any; }) {
        let totalUsed = await Container.get(DataSource).getRepository(OcrReader).count({ where: { clientId: Number(clientId), modelType: "pdf-to-word" } });

        let response = await axios.get(`${process.env.MASTER_SITE_URL}client-config/${clientId}/PDF-Word-Credits`);
        let res = await axios.get(`${process.env.MASTER_SITE_URL}client-config/${clientId}/PDF-Word-Notification`);
        if (response.data) {
            let notificationTriggerValue = Number(res?.data?.data?.configValue || 0);
            if (totalUsed >= notificationTriggerValue) {
                let exists = await this.NotificationService.checkNotificationEntryForTodayExists(request.userDetails.id || 0, 'OCR-PDF-to-Word');
                if (!exists) {
                    const insertData = {
                        clientId,
                        type: 'OCR-PDF-to-Word',
                        senderId: 'System',
                        receiverId: request.userDetails.id || 0,
                        roleType: 0,
                        message: "Your PDF to Word credits are running low, Please contact administator",
                        redirectUrl: '/ocr-reader/create/pdf-to-word',
                        createdBy: 'System',
                    } as unknown as Notification;
                    this.NotificationService.addNotification(insertData);
                }
            }
            apiResponse.data = { used: totalUsed, credits: Number(response?.data?.data?.configValue || 0), notificationTriggerValue: notificationTriggerValue };
            this.setStatus(200);

        }
        return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
    }

    private async getRemainingCredit(clientId: string, request: any, apiResponse: { data: {}; error: any; }) {
        try {
            let ocrDetails = await this.getOCRDetails(clientId);
            let res = await axios.get(`${process.env.MASTER_SITE_URL}client-config/${clientId}/OCR-Notification`);

            if (res.data) {
                let notificationTriggerValue = Number(res?.data?.data?.configValue || 0);
                // if (ocrDetails.totalUsed >= notificationTriggerValue) {
                //     let exists = await this.NotificationService.checkNotificationEntryForTodayExists(request.userDetails.id || 0, 'OCR-Credits');
                //     if (!exists) {
                //         const insertData = {
                //             clientId,
                //             type: 'OCR-Credits',
                //             senderId: 'System',
                //             receiverId: request.userDetails.id || 0,
                //             roleType: 0,
                //             message: "Your OCR credits are running low, Please contact administator",
                //             redirectUrl: '/notification-list',
                //             createdBy: 'System',
                //         } as unknown as Notification;
                //         this.NotificationService.addNotification(insertData);
                //     }
                // }

                apiResponse.data = { used: ocrDetails.totalUsed, credits: ocrDetails.credits, notificationTriggerValue: notificationTriggerValue };

                this.setStatus(200);
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            console.log(error);
            return CommonHelper.apiSwaggerErrorResponse({ error: error });
        }
    }

    private async getOCRDetails(clientId: string) {
        let response = await axios.get(`${process.env.MASTER_SITE_URL}client-config/${clientId}/OCR-Credits`);
        let ocrDetails ={
            totalUsed:0,
            credits:0,
            imageToExcel:0,
            pdfToExcel:0,
            imageToWord:0,
            pdfToWord:0,
            totalFiles:0,
            filesimageToExcel:0,
            filespdfToExcel:0,
            filesimageToWord:0,
            filespdfToWord:0,
            startDate:null,
            endDate:null
        }
        if (response.data.data.subscriptionStartDate && response.data.data.subscriptionEndDate) {
            ocrDetails.credits = Number(response?.data?.data?.configValue || 0);
            const startDate = new Date(response.data.data.subscriptionStartDate);
            const endDate = new Date(response.data.data.subscriptionEndDate);
            //endDate.setDate(endDate.getDate() + 1); // Make endDate inclusive of the whole day

            // let totalUsed:any = await dataSource.getRepository(OcrReader)
            // .createQueryBuilder("ocrReader")  // Use a query builder for more flexibility
            // .where("ocrReader.clientId = :clientId", { clientId: Number(clientId) })
            // .andWhere("ocrReader.createdOn BETWEEN :startDate AND :endDate", { startDate, endDate })
            // .select("SUM(ocrReader.pageCount)", "totalUsed") // Calculate the sum
            // .getRawOne(); // Get a single result as a raw object

            const totalUsedByModelType = await dataSource.getRepository(OcrReader)
            .createQueryBuilder("ocrReader")
            .where("ocrReader.clientId = :clientId", { clientId: Number(clientId) })
            .andWhere("ocrReader.createdOn BETWEEN :startDate AND :endDate", { startDate, endDate })
            .select("ocrReader.modelType", "modelType") 
            .addSelect("SUM(ocrReader.pageCount)", "totalUsed")
            .addSelect("COUNT(DISTINCT ocrReader.id)", "totalFiles") 
            .groupBy("ocrReader.modelType")
            .getRawMany();
            totalUsedByModelType.forEach((element:any) => {
                ocrDetails.totalUsed += Number(element.totalUsed);
                ocrDetails.totalFiles += Number(element.totalFiles);
            });
            ocrDetails.imageToExcel = totalUsedByModelType.find((element:any) => element.modelType === 'image-to-excel')?.totalUsed || 0;
            ocrDetails.pdfToExcel = totalUsedByModelType.find((element:any) => element.modelType === 'pdf-to-excel')?.totalUsed || 0;
            ocrDetails.imageToWord = totalUsedByModelType.find((element:any) => element.modelType === 'image-to-word')?.totalUsed || 0;
            ocrDetails.pdfToWord = totalUsedByModelType.find((element:any) => element.modelType === 'pdf-to-word')?.totalUsed || 0;
            ocrDetails.filesimageToExcel = totalUsedByModelType.find((element:any) => element.modelType === 'image-to-excel')?.totalFiles || 0;
            ocrDetails.filespdfToExcel = totalUsedByModelType.find((element:any) => element.modelType === 'pdf-to-excel')?.totalFiles || 0;
            ocrDetails.filesimageToWord = totalUsedByModelType.find((element:any) => element.modelType === 'image-to-word')?.totalFiles || 0;
            ocrDetails.filespdfToWord = totalUsedByModelType.find((element:any) => element.modelType === 'pdf-to-word')?.totalFiles || 0;
            ocrDetails.startDate =  moment(startDate).format('DD-MM-YYYY');
            ocrDetails.endDate = moment(endDate).format('DD-MM-YYYY');


        }
        return ocrDetails;
    }

    private async getForImageToExcel(clientId: string) {
        const results = await dbService._findQueryService(
            Container.get(DataSource).getRepository(SettingConfig),
            {
                where: { type: "OCR_API_KEY", clientId: clientId },
            }
        );
        if (results?.length) {
            const config = results[0].config
                ? JSON.parse(results[0].config)
                : {};
            if (config?.apiKey) {
                    const responseResult = await this.imageToExcelService.checkKeyStatus(
                        config.apiKey
                    );
                    if (responseResult) {
                        return responseResult.usage;
                
                    }
                }
            }
    }


    @Security("bearerAuth")
    @Post("ocr-reader-data/:id")
    async updateOcrData(
        @Body() requestBody: any,
        @Request() request: any,
        @Path() id: string
    ): Promise<unknown> {
        try {
            const apiResponse = {
                data: {},
            };
            console.log('request.params', request.params);
            let fileDataConfig = null;
            let data: any = await dataSource.getRepository(OcrReader).findOne({ where: { id: id } });
            if (data?.fileConfig) {
                fileDataConfig = JSON.parse(data.fileConfig);

                if (fileDataConfig?.ApiResponse?.Tables?.length && fileDataConfig?.ApiResponse?.Tables[requestBody.tableIndex].TableJson && fileDataConfig.ApiResponse.Tables[requestBody.tableIndex].TableJson[requestBody.indexKey]) {
                    fileDataConfig.ApiResponse.Tables[requestBody.tableIndex].TableJson[requestBody.indexKey] = requestBody.dataSet;
                }
                console.log('ApiResponse', JSON.stringify(fileDataConfig, null, 2));
                const updateResult = await dataSource
                    .getRepository(OcrReader)
                    .update({ id: request.params.id }, {
                        fileConfig: JSON.stringify(fileDataConfig)
                    });
                apiResponse.data = updateResult;
                if (!updateResult?.affected) {
                    this.setStatus(204);
                } else {
                    this.setStatus(200);
                }
            } else {
                this.setStatus(200);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            console.log(error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("ocr-reader-table-data/:id")
    async updateOcrTableData(
        @Body() requestBody: any,
        @Request() request: any,
        @Path() id:string
    ): Promise<unknown> {
        try {
            const apiResponse = {
                data: {},
            };
            console.log('request.params', request.params);
            let fileDataConfig = null;
            let data: any = await dataSource.getRepository(OcrReader).findOne( {where: { id: id }});
            if(data?.fileConfig) {
                fileDataConfig = JSON.parse(data.fileConfig);

                // if (fileDataConfig?.ApiResponse?.Tables?.length && fileDataConfig?.ApiResponse?.Tables[requestBody.tableIndex].TableJson && fileDataConfig.ApiResponse.Tables[requestBody.tableIndex].TableJson[requestBody.indexKey]) {
                //     fileDataConfig.ApiResponse.Tables[requestBody.tableIndex].TableJson[requestBody.indexKey] = requestBody.dataSet;
                // }

                if(fileDataConfig?.ApiResponse?.Tables?.length > 0) {
                    fileDataConfig?.ApiResponse?.Tables.forEach( (table, tableIndex) => {
                      fileDataConfig.ApiResponse.Tables[tableIndex].TableJson = requestBody[tableIndex].bodyList;
                        // if (fileDataConfig.ApiResponse.Tables[tableIndex].tableJson) {
                        //   fileDataConfig.ApiResponse.Tables[tableIndex].tableJson = requestBody[tableIndex].bodyList;
                        // } else {
                        //   fileDataConfig.ApiResponse.Tables[tableIndex].TableJson = requestBody[tableIndex].bodyList;
                        // }
                    })
                }
                console.log('ApiResponse', JSON.stringify(fileDataConfig, null, 2));
                const updateResult = await dataSource
                    .getRepository(OcrReader)
                    .update({ id: request.params.id }, {
                        fileConfig: JSON.stringify(fileDataConfig)
                    });
                apiResponse.data = updateResult;
                if (!updateResult?.affected) {
                    this.setStatus(204);
                } else {
                    this.setStatus(200);
                }
            } else {
                this.setStatus(200);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) { console.log(error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("ocr-reader/notification")
    @Hidden()
    async getNotificationTrigger(
    @Body() requestBody: any,
    @Request() request: any): Promise<unknown> {
        const apiResponse = {
            data: {
                userId:null,
                firstName:null,
                lastName:null,
                email:null,
                totalUsed:0,
                sendNotification:false,
                notificationTriggerValue:0
            },
        };
        try {
            
            let usersInfo: any = await dataSource
                .getRepository(Users)
                .findOne({
                    where: {
                        clientId: requestBody.clientId,
                        isAdmin: 1,
                        isSuperAdmin:0,
                    },
                    select:{
                        id:true,
                        firstName:true,
                        lastName:true,
                        email:true
                    }
                });
            if(usersInfo){
                apiResponse.data.userId = usersInfo.id;
                apiResponse.data.firstName = usersInfo.firstName;
                apiResponse.data.lastName = usersInfo.lastName;
                apiResponse.data.email = usersInfo.email;
            }
            let ocrDetails = await this.getOCRDetails(requestBody.clientId);
            if(ocrDetails){
                apiResponse.data.totalUsed = ocrDetails.totalUsed;
            }
            let res = await axios.get(`${process.env.MASTER_SITE_URL}client-config/${requestBody.clientId}/OCR-Notification`);
            if (res.data) {
                let notificationTriggerValues = res?.data?.data?.configValue.split(',');
                let foundMatch = false; // Flag to track if a match was found

                    await Promise.all(notificationTriggerValues.map(async (value) => {
                        if (!foundMatch && ocrDetails.totalUsed >= Number(value)) {
                            const exists = await this.NotificationService.checkNotificationEntryForTriggerValueExists(apiResponse.data.userId, value);
                            if (!exists) {
                                apiResponse.data.sendNotification = true;
                                apiResponse.data.notificationTriggerValue = Number(value);
                                foundMatch = true;
                            }
                        }
                    }));
            }
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            console.log(error);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        }
    }

    @Security("bearerAuth")
    @Post("ocr-reader/weekly-report")
    async weeklyReport(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        try {
            const startDate = new Date(requestBody.startDate);
            const endDate = new Date(requestBody.endDate);
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(OcrReader),
                {
                    where: {
                        createdOn: Between(startDate, endDate),
                    },
                    select: ['id', 'clientId', 'modelType', 'createdOn']
                }
            );

            if (results?.length) {
                const csv = results.map((row) => {
                    return `${row.id},${row.clientId},${row.modelType},${row.createdOn}`;
                }).join('\n');

                // Set response headers for CSV download
                request.res.setHeader('Content-Type', 'text/csv');
                request.res.setHeader('Content-Disposition', 'attachment; filename=weekly_report.csv');

                // Send CSV data directly to response
                request.res.end(csv);

                return; // No need to return a structured response
            }

            return CommonHelper.apiSwaggerSuccessResponse({ data: null }); 
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}