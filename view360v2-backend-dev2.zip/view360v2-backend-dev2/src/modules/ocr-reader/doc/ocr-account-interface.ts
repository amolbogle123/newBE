export interface InsertOcrAccountRequest {
    name?: string;
    type?: any;
    config?: any;
    modelType?: string;
    isConfigured?: boolean;
}

export interface DeleteOcrAccount {
    id: string[];
}

export interface OcrAccountListResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface SaveOcrAccountResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DeleteOcrAccountResponse {
    status: boolean;
    data?: any;
    message?: string;
}