interface Columns {
    data: string;
    name: string;
    searchable: boolean;
    orderable: boolean;
    search: Search;
}
interface Search {
    value: string;
    regex: boolean;
}

interface Order {
    column: number;
    dir: string;
}

export interface GetOcrReaderListRequest {
    draw: number;
    columns: Columns[];
    order: Order[];
    start: number;
    length: number;
    search: Search;
    type: string;
}

export interface FileReaderRequest {
    filePath: string;
}

export interface FileReaderResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface GenerateDocxRequest {
    fileData: any;
}

export interface GenerateDocxResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface InsertOcrReaderRequest {
    name: string;
    fileConfig?: any;
    filePath: string;
    pageCount?: number;
    modelType: string;
    isDataParsed?: number;
    JobId?: string;
    JobStatus?: string;
}

export interface UpdateOcrReaderRequest {
    name?: string;
    fileConfig?: any;
    modelType?: string;
    pageCount?: number;
    isDataParsed?: number;
}

export interface DeleteOcrReader {
    id: string[];
}

export interface OcrReaderListResponse {
    status: boolean;
    data?: any;
    message?: string;
    recordsTotal?: number;
    recordsFiltered?: number;
}

export interface SaveOcrReaderResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface OcrReaderDetailsResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DeleteOcrReaderResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface SyncOcrReaderFiles {
    accountId: string;
}

export interface SyncOcrReaderFilesResponse {
    status: boolean;
    data?: any;
    message?: string;
}