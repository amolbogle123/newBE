import { AppRoutes } from "../../app.routes";
import { OcrReaderController } from "./controllers/ocr-reader.controller";

export class OcrReaderRoutes extends AppRoutes {
    private ocrReaderController: OcrReaderController;

    constructor() {
        super();
        this.ocrReaderController = new OcrReaderController();
    }
}
