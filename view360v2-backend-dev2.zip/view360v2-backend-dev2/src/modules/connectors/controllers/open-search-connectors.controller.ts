import {
    Body,
    Controller,
    Get,
    Path,
    Post,
    Request,
    Route,
    Security,
    Tags
} from "tsoa";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { OpenSearchExecutor } from "../executor-utils/openSearchExecutor.util";

@Route("opensearch-connectors")
@Tags("Open Search Connectors")
export class OpenSearchConnectorsController extends Controller {

    @Security("bearerAuth")
    @Get("list/:type/:accountId")
    async getList(
        @Request() req: any,
        @Path() type: string,
        @Path() accountId: string
    ): Promise<any> {
        try {
            let response: any = {status: false, data: [], message: {}, error: null};
            
            if (type === "indexes") {
                const list: any = await OpenSearchExecutor.getIndexesList(accountId);
                if (list?.status) {
                    response.data = list.data;
                    response.status = true;
                }
            } else {
                response = await OpenSearchExecutor.getTestList(accountId, req.query);
            }
            
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Data Fetched Successfully!",
                data: response
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("column-list/:columnType/:accountId")
    async getColumnList(
        @Body() requestBody: any,
        @Path() columnType: string,
        @Path() accountId: string
    ): Promise<any> {
        try {
            let response: any = {status: false, data: [], message: {}, error: null};
            if (requestBody?.indexName) {
                if (columnType === "indexes") {
                    const list: any = await OpenSearchExecutor.getIndexColumn(accountId, requestBody.indexName);
                    if (list?.status) {
                        response.data = list.data;
                        response.status = true;
                    }
                }
            }

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Data Fetched Successfully!",
                data: response
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("data-table/:type/:accountId")
    async getTableData(
        @Body() requestBody: any,
        @Path() type: string,
        @Path() accountId: string
    ): Promise<any> {
        try {
            let response: any = {status: false, data: [], message: {}, error: null};
            
            if (type === "index") {
                const config = {
                    search: requestBody?.search,
                    start: requestBody?.start,
                    limit: requestBody?.limit  
                };
                response = await OpenSearchExecutor.searchIndexData(accountId, requestBody?.indexId, requestBody?.filter, config);
            }
            
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Data Fetched Successfully!",
                data: response
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
