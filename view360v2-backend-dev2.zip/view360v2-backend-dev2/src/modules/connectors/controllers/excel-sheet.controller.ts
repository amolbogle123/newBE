import { Body, Controller, Post, Request, Route, Security, Tags } from "tsoa";
import { ApiErrorResponse, CommonHelper } from "../../../utils/helpers/common.helper";
import { InsertVendorRequest, SaveVendorResponse } from "../interface/excel.interface";
import { UploadFile } from '../services/uploadFile';

@Route('')
@Tags('Excel Data')
export class ExcelSheetController extends Controller {

    // Services
    private uploadFile: UploadFile = new UploadFile();

    @Security('bearerAuth')
    @Post('excel-data')
    async saveVendorData(
        @Body() requestBody: InsertVendorRequest,
        @Request() request: any
    ) : Promise<SaveVendorResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: [],
            };

            if (requestBody?.files?.length) {
                for(let i = 0; i < requestBody.files.length; i++) {
                    const file = requestBody.files[i];
                    
                    let fileResult = await this.uploadFile.xlsxFile(i, file, request.userDetails, requestBody.shareSampleData);
                    if (fileResult?.data?.length) {
                        apiResponse.data.push({fileResult: fileResult.data});
                    }
                }
            }
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
