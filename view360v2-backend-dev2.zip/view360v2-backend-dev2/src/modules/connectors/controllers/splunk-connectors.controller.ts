import {
    Body,
    Controller,
    Get,
    Path,
    Post,
    Request,
    Route,
    Security,
    Tags
} from "tsoa";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { SplunkExecutor } from "../executor-utils/splunkExecutor.util";

@Route("splunk-connectors")
@Tags("Splunk Connectors")
export class SplunkConnectorsController extends Controller {

    @Security("bearerAuth")
    @Get("list/:type/:accountId")
    async getList(
        @Request() req: any,
        @Path() type: string,
        @Path() accountId: string
    ): Promise<any> {
        try {
            let response: any = {status: false, data: [], message: {}, error: null};
            
            switch(type) {
                case "app":
                    response = await SplunkExecutor.getAppList(accountId);
                    break;
                case "dashboards":
                    response = await SplunkExecutor.getAppList(accountId);
                    break;
                case "datasets":
                    response = await SplunkExecutor.getDatasetList(accountId);
                    break;
                case "indexes":
                    response = await SplunkExecutor.getIndexesList(accountId);
                    break;
                case "indexFields":
                    response = await SplunkExecutor.getIndexFields(accountId, req.query.index);
                    break;
            }
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Data Fetched Successfully!",
                data: response
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("data-table/:type/:accountId")
    async getTableData(
        @Body() requestBody: any,
        @Path() type: string,
        @Path() accountId: string
    ): Promise<any> {
        try {
            let response: any = {status: false, data: [], message: {}, error: null};
            
            if (type === "index") {
                const config = {
                    search: requestBody?.search,
                    start: requestBody?.start,
                    limit: requestBody?.limit  
                };
                response = await SplunkExecutor.searchIndexData(accountId, requestBody?.indexId, [], config);
            }
            
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Data Fetched Successfully!",
                data: response
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
