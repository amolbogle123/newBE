import { Body, Controller, Post, Request, Route, Tags } from "tsoa";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import { HanaConnection } from "../executor-utils/sapHanaExecutor.util";
@Route("")
@Tags("Sap Hana cloud")
export class SapHanaController extends Controller {
    @Post("sap-hana-connect")
    async connectSapHana(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any | unknown> {
        this.setStatus(500);
        try {
            // Connect to SAP HANA
            const hanaConnection = HanaConnection.connect(requestBody);
            const apiResponse = {
                data: [],
            };
            // SQL query to be executed
            // const sqlQuery = "SELECT * FROM Employee";
            // Execute the query
            hanaConnection.exec(requestBody.query, (err, result) => {
                if (err) {
                    console.error("Error executing query:", err);
                } else {
                    console.log("Query result:", result);
                    apiResponse.data = result;
                }

                // Disconnect from SAP HANA
                hanaConnection.disconnect((disconnectErr) => {
                    if (disconnectErr) {
                        console.error("Disconnection failed:", disconnectErr);
                    } else {
                        console.log("Disconnected from SAP HANA successfully!");
                    }
                });
            });
            console.log(hanaConnection, "hananananan");

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
