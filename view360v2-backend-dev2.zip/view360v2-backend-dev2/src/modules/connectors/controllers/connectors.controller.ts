import { dataSource } from "core/data-source";
import {
    SecretConfiguration,
    VaultConfiguration,
    WidgetAccount,
} from "entities";
import dbService from "../../../services/db.service";
import {
    Body,
    Controller,
    Delete,
    Get,
    Patch,
    Path,
    Post,
    Request,
    Route,
    Security,
    Tags,
    Query,
    Middlewares,
} from "tsoa";
import Container from "typedi";
import { DataSource, In } from "typeorm";
import lodash from "lodash";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { MySQLExecutorUtil } from "../executor-utils/mySQLExecutor.util";
import { MsSQLExecutorUtil } from "../executor-utils/msSQLExecutor.util";
import { AddWidgetAccount } from "../doc/connectors.interface";
import { VaultService } from "../../vault/service/vault.service";
import { CommonUtil } from "utils/common.util";
import {
    commonMiddleware,
    validateEntryCount,
} from "../../../middlewares/common.middleware";
import { HanaConnection } from "../executor-utils/sapHanaExecutor.util";

@Route("connectors")
@Tags("Connectors")
export class WidgetCrudOperationController extends Controller {
    private vaultService: VaultService = new VaultService();
    /**
     * Add Widget Account
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Middlewares(validateEntryCount)
    @Post("account")
    async addWidgetAccount(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = { status: "error", data: {} };
            const objWidgetAccount = new WidgetAccount();
            objWidgetAccount.clientId = req.userDetails.client_id;
            objWidgetAccount.widgetType = requestBody.widgetType;
            objWidgetAccount.accountName = requestBody.accountName;
            objWidgetAccount.config = JSON.stringify(requestBody.accountConfig);
            objWidgetAccount.createdBy = req.userDetails.id;

            const vaultConfig = await Container.get(DataSource)
                .getRepository(VaultConfiguration)
                .find({ where: { clientId: req.userDetails.client_id } });

            if (vaultConfig.length) {
                try {
                    const appRole = await this.vaultService.getAppRoleRoleId(
                        `${vaultConfig[0].vaultUrl}:${vaultConfig[0].vaultPort}`,
                        vaultConfig[0].token
                    );
                    const appSecret =
                        await this.vaultService.getAppRoleSecretId(
                            `${vaultConfig[0].vaultUrl}:${vaultConfig[0].vaultPort}`,
                            vaultConfig[0].token
                        );
                    if (appRole.data && appSecret.data) {
                        const result = await this.vaultService.createSecret(
                            `${vaultConfig[0].vaultUrl}:${vaultConfig[0].vaultPort}`,
                            vaultConfig[0].token,
                            requestBody.accountName,
                            objWidgetAccount
                        );
                        if (!result.error) {
                            objWidgetAccount.config = "";
                            const secretConfiguration = {
                                vaultId: vaultConfig[0].id as unknown as string,
                                configurationName: requestBody.accountName,
                                clientId: req.userDetails.client_id,
                                secretPath: requestBody.accountName,
                                policyName: "view360-default-policy",
                                roleName: "view360-default-role",
                                capabilities: JSON.stringify("read"),
                                roleId: appRole.data.role_id,
                                secretId: appSecret.data.secret_id,
                            };
                            const secretCofigResult = await Container.get(
                                DataSource
                            )
                                .getRepository(SecretConfiguration)
                                .save(secretConfiguration);
                            if (secretCofigResult) {
                                objWidgetAccount.secretConfigId =
                                    secretCofigResult.id as unknown as string;
                            }
                        }
                    }
                } catch (e) {
                    const apiErrorResponse: ApiErrorResponse = {
                        error: {
                            error_description: (e as Error).message,
                        },
                    };
                    this.setStatus(500);
                    return CommonHelper.apiSwaggerErrorResponse(
                        apiErrorResponse
                    );
                }
            }

            const accountResult = await Container.get(DataSource).manager.save(
                objWidgetAccount
            );

            if (accountResult) {
                response.data = accountResult;
                response.status = "success";
            }

            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: response,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update Widget Account
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Patch("account")
    async updateWidgetAccount(
        @Request() req: any,
        @Body() requestBody: AddWidgetAccount
    ): Promise<any> {
        try {
            const updateData = {
                widgetType: requestBody.widgetType,
                accountName: requestBody.accountName,
                config: JSON.stringify(requestBody.accountConfig),
            };

            const whereClause = {
                clientId: req.userDetails.client_id,
                id: req.body.id,
            };

            const vaultConfig = await Container.get(DataSource)
                .getRepository(VaultConfiguration)
                .find({ where: { clientId: req.userDetails.client_id } });
            if (vaultConfig.length) {
                const result = await this.vaultService.createSecret(
                    `${vaultConfig[0].vaultUrl}:${vaultConfig[0].vaultPort}`,
                    vaultConfig[0].token,
                    requestBody.accountName,
                    updateData
                );
                const widgetAccount = await Container.get(DataSource)
                    .getRepository(WidgetAccount)
                    .findOne({ where: { id: requestBody.id } });

                if (result) {
                    updateData.config = "";
                }

                if (widgetAccount && widgetAccount.secretConfigId) {
                    const secretConfiguration = {
                        configurationName: requestBody.accountName,
                        secretPath: requestBody.accountName,
                    };
                    await Container.get(DataSource)
                        .getRepository(SecretConfiguration)
                        .update(
                            { id: widgetAccount.secretConfigId },
                            secretConfiguration
                        );
                }
            }

            await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .update(whereClause, updateData);

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Account updated successfully",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Delete Widget Account
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */

    @Security("bearerAuth")
    @Delete("account")
    async deleteWidgetAccount(
        @Request() req: any,
        @Body() requestBody: { id: string[] }
    ): Promise<any> {
        try {
            let listOfIds: any = requestBody.id;
            const apiResponse: any = {
                message: null,
                data: null,
            };
            const deleteResult = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .delete({ id: In(listOfIds) });

            if (deleteResult?.affected) {
                apiResponse.data = { deletedData: listOfIds };
                apiResponse.message = "Account has been deleted successfully";
            }

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Account has been deleted successfully",
                data: { deletedData: listOfIds },
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get widget Account List
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security("bearerAuth")
    @Get("account")
    async widgetAccountList(@Request() req: any): Promise<any> {
        try {
            const responseData = {
                records: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };
            let whereCondition = " WA.clientId = :id ";
            if (req.query.type) {
                whereCondition =
                    whereCondition +
                    ` AND WA.widgetType IN ('${req.query.type
                        .split(",")
                        .join("', '")}')`;
            }
            let result: any;
            result = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .createQueryBuilder("WA")
                .where(whereCondition, {
                    id: req.userDetails.client_id,
                    type: req.query.type ? req.query.type : "",
                })
                .getMany();
            if (result && result.length > 0) {
                responseData.records = result;
                responseData.recordsTotal = result.length;
                responseData.recordsFiltered = result.recordsFiltered
                    ? result.recordsFiltered
                    : 0;
            }

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: responseData,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get Widget Account
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Get("account/:accountId")
    async getWidgetAccount(
        @Request() req: any,
        @Path() accountId: string
    ): Promise<any> {
        try {
            const apiResponse: any = {
                data: null,
            };
            const widgetAccountResult: WidgetAccount = await dataSource
                .getRepository(WidgetAccount)
                .findOneBy({ id: req.params.accountId });

            if (widgetAccountResult && !lodash.isEmpty(widgetAccountResult)) {
                widgetAccountResult.config = JSON.parse(
                    widgetAccountResult.config
                );
                apiResponse.data = widgetAccountResult;
            }

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Data Fetched Successfully!",
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("account/list")
    @Middlewares(commonMiddleware)
    async getWidgetAccountList(
        @Request() req: any,
        @Query("pagination") pagination: boolean = true,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<any> {
        try {
            let whereCondition: any = {
                clientId: req.userDetails.client_id,
            };
            const fieldsToBeSelected: any[] = [
                "id",
                "accountName",
                "widgetType",
                "createdOn",
            ];

            if (req.body.type && req.body.type !== "") {
                whereCondition.widgetType = req.body.type;
            }

            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["createdOn"] = sortOrder;
            }

            // Get total record count before applying pagination
            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(WidgetAccount),
                {
                    where: whereCondition,
                }
            );

            // Fetch paginated and sorted data
            const result: any = await dbService._findQueryService(
                Container.get(DataSource).getRepository(WidgetAccount),
                {
                    select: fieldsToBeSelected,
                    where: whereCondition,
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject
                }
            );

            const apiResponse = {
                data: result,
                recordsTotal: totalRecordCount,
                recordsFiltered: totalRecordCount
            };

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("account/database-support-list")
    async databaseSupportList(@Request() req: any): Promise<any> {
        try {
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Data Fetched Successfully!",
                data: [
                    {
                        id: "MYSQL",
                        name: "MySQL",
                    },
                    {
                        id: "MSSQL",
                        name: "Microsoft SQL Server",
                    },
                    {
                        id: "MONGODB",
                        name: "Mongo DB",
                    },
                    {
                        id: "POSTGRESQL",
                        name: "PostgreSQL",
                    },
                ],
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("account/check-connection")
    async checkConnection(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<any> {
        try {
            const response = {
                isConnection: false,
            };

            let query = "";
            let result: any = "";
            switch (requestBody.dbType) {
                case "MYSQL":
                    query = `SHOW CREATE DATABASE ${requestBody.dbName}`;
                    result = await MySQLExecutorUtil.executeMYSQLQuery(
                        query,
                        requestBody
                    );
                    if (result?.status) {
                        response.isConnection = true;
                    }
                    break;
                case "MSSQL":
                    // TO_DO: need to be test with sql query
                    query = `SHOW CREATE DATABASE ${requestBody.dbName}`;
                    result = await MsSQLExecutorUtil.executeMSSQLQuery(
                        query,
                        requestBody
                    );
                    if (result?.status) {
                        response.isConnection = true;
                    }
                    break;

                case "SAP_HANA":
                    const hanaConnection = HanaConnection.connect(requestBody);
                    console.log(hanaConnection,'hanaConnectionhanaConnectionhanaConnection')
                    if (hanaConnection?.exec) {
                        response.isConnection = true;
                    }
                    break;
                // case "MONGODB":
                //     // TO_DO: need to be test with sql query
                //     query = `SHOW CREATE DATABASE ${requestBody.dbName}`;
                //     result = await MySQLExecutorUtil.executeMYSQLQuery(query, requestBody);
                //     if (result?.status){
                //         response.isConnection = true;
                //     }
                //     break;
                // case "POSTGRESQL":
                //     // TO_DO: need to be test with sql query
                //     query = `SHOW CREATE DATABASE ${requestBody.dbName}`;
                //     result = await MySQLExecutorUtil.executeMYSQLQuery(query, requestBody);
                //     if (result?.status){
                //         response.isConnection = true;
                //     }
                //     break;
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Data Fetched Successfully!",
                data: response,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("account/check-database")
    async checkDatabaseConnection(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<any> {
        try {
            const response = {
                message: "Data Fetched Successfully!",
                data: [],
                error: null
            };

            let query = "";
            let result: any = "";
            switch (requestBody.dbType) {
                case "MYSQL":
                    query = `SHOW DATABASES`;
                    result = await MySQLExecutorUtil.executeMYSQLQuery(
                        query,
                        requestBody
                    );
                    if (result?.status && result?.data?.length) {
                        response.data = result.data.map((d) => ({ database: d?.Database }));
                    } else if (!result?.status) {
                        let msg = "Something went wrong, please try again later.";
                        if (result?.message) {
                            msg = result.message;
                        }
                        response.error = msg;
                    }
                    break;
                case "MSSQL":
                    // TO_DO: need to be test with sql query
                    query = `SHOW DATABASES`;
                    result = await MsSQLExecutorUtil.executeMSSQLQuery(
                        query,
                        requestBody
                    );
                    if (result?.status && result?.data?.length) {
                        // TO_DO: need to be test with sql query
                        response.data = result.data.map((d) => ({ database: d?.Database }));
                    }
                    break;
            }
            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
