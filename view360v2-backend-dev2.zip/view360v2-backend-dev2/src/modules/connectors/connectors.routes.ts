import {AppRoutes} from "../../app.routes";

export class ConnectorsRoutes extends AppRoutes {

    constructor() {
        super();
    }

    initRoutes() {
        /**
         * this.router.get('/connector-forms/get-details/:id',  (req, res, next) => this.connectorsService.getDetails(req,res,next).catch(next));
         * this.router.post('/connector-forms/get-table-data-list',  (req, res, next) => this.connectorsService.getTableDataList(req,res,next).catch(next));
         * this.router.post('/connector-forms/list',  (req, res, next) => this.connectorsService.connectorList(req,res,next).catch(next));
         * this.router.post('/connector-forms/get-table-primary-key',  (req, res, next) => this.connectorsService.getTablePrimaryKey(req,res,next).catch(next));
         * this.router.get('/get-column-distinct-value',  (req, res, next) => this.connectorsService.getColumnValues(req,res,next).catch(next));

         * this.router.post('/connector-forms/add',  (req, res, next) => this.connectorsService.addConnectors(req,res,next).catch(next));
         * this.router.post('/connector-forms/update',  (req, res, next) => this.connectorsService.setConnectors(req,res,next).catch(next));
         * this.router.post('/update-table-data',  (req, res, next) => this.connectorsService.updateTableData(req,res,next).catch(next));
         * this.router.post('/update-map-data',  (req, res, next) => this.connectorsService.updateMapData(req,res,next).catch(next));
         * this.router.post('/insert-table-data',  (req, res, next) => this.connectorsService.insertTableData(req,res,next).catch(next));
         * this.router.post('/update-webhook-data',  (req, res, next) => this.connectorsService.updateWebhookData(req,res,next).catch(next));

         * this.router.post('/connector-forms/delete',  (req, res, next) => this.connectorsService.delete(req,res,next).catch(next));
         * this.router.delete('/delete-table-row',  (req, res, next) => this.connectorsService.deleteTableRow(req,res,next).catch(next)); 
         */
    }
}
