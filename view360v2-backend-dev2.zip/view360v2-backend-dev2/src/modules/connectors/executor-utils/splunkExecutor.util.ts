let splunkjs = require('splunk-sdk');
import Container from "typedi";
import { DataSource } from "typeorm";

import { WidgetAccount } from "entities";

export class SplunkExecutor {
    static async getAppList(accountId) {
      const response: any = {status: false, data: [], error: null};
      return new Promise(async (resolve) => {
        try {
          let service: any = await connect(accountId);
          if (service) {
            let apps = await service.apps().fetch();
            let appList = apps.list();
            
            let allApp = [];
            for(let i = 0; i < appList.length; i++){
              let app = appList[i];
              allApp.push({
                index: i,
                name: app.name
              });
            }
            response.status = true;
            response.data = allApp;
          } else {
            response.error = "Unable to connect to Splunk";
          }

          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      })
    }

    static async getDatasetList(accountId) {
        const response: any = {status: false, data: [], error: null};
        return new Promise(async (resolve) => {
            try {
                let service: any = await connect(accountId);
                if (service) { 
                  let apps = await service.apps().fetch();
                  let appList = apps.list();

                  response.status = true;
                  response.data = appList;
                } else {
                  response.error = "Unable to connect to Splunk";
                }
                resolve(response);
              } catch(err){
                console.log("There was an error retrieving the list of applications:", err);
                response.error = "There was an error retrieving the list of applications";
                resolve(response);
              }
        })
    }

    static async getIndexesList(accountId) {
      const response: any = {status: false, data: [], error: null};
      return new Promise(async (resolve) => {
        try {
          let service: any = await connect(accountId);
          if (service) { 
            let indexes = await service.indexes().fetch();
            let indexList = indexes.list();
            
            let allIndexes = [];
            for(let i = 0; i < indexList.length; i++){
              let indexesObj = indexList[i];
              allIndexes.push({
                index: indexesObj.name,
                name: indexesObj.name
              });
            }
            response.status = true;
            response.data = allIndexes;
          } else {
            response.error = "Unable to connect to Splunk";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }

    static async getIndexFields(accountId, indexId) {
      const response: any = {status: false, data: [], error: null};
      return new Promise(async (resolve) => {
        try {
          let service: any = await connect(accountId);
          if (service) { 
            let searchParams = {
              exec_mode: "blocking",
              // earliest_time: "2012-06-20T16:27:43.000-07:00"
            };
            const searchQuery = `search index="${indexId}" sourcetype="csv" | fields - "_bkt","_cd","_indextime","_raw","_serial","_si","_sourcetype","_time",host,index,linecount,source,sourcetype,eventtype,punct,splunk_server_group,timestamp,"splunk_server",_eventtype_color | table * | head 1`;
            
            let indexes = await service.search(searchQuery, searchParams);
            indexes = await indexes.fetch();

            const results = await getFieldFromResult(indexes);
    
            response.status = true;
            response.data = results;
          } else {
            response.error = "Unable to connect to Splunk";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }

    static async createIndex(accountId, indexId) {
      const response: any = {status: false, data: {}, error: null};
      return new Promise(async (resolve) => {
        try {
          let service: any = await connect(accountId);
          if (service) { 
            const indexes = await service.indexes().create(indexId);
            if (indexes?.name) {
              response.status = true;
              response.data = {id: indexId};
            }
          } else {
            response.error = "Unable to connect to Splunk";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }

    static async createBulkIndex(accountId, indexId, documentList) {
      const response: any = {status: false, data: {}, error: null};
      return new Promise(async (resolve) => {
        try {
          let service: any = await connect(accountId);
          if (service) { 
            console.log('indexId', indexId);
            console.log('documentList', documentList);

            // Get the collection of indexes
            let myindexes = service.indexes();

            // Get an index to send events to
            myindexes = await myindexes.fetch();
            let myindex = myindexes.item(indexId);

            console.log("myindex: ", myindex);

            // Submit an event to the index
            // let result;
            // [result, myindex] = await myindex.submitEvent("A new event", {sourcetype: "mysourcetype"});
            // console.log("Submitted event: ", result);

            // const indexes = await service.indexes().create(indexId);
            // if (indexes?.name) {
            //   response.status = true;
            //   response.data = {id: indexId};
            // }
          } else {
            response.error = "Unable to connect to Splunk";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }

    static async searchIndexData(accountId, indexId, filter, config) {
      const response: any = {status: false, data: [], totalRecords: 0, error: null};
      return new Promise(async (resolve) => {
        try {
          let service: any = await connect(accountId);
          if (service) { 
            let searchParams = {
              exec_mode: "blocking",
              // earliest_time: "2012-06-20T16:27:43.000-07:00"
            };

            let searchStr = "";
            let whereFilter = [];
            if (filter?.length) {
              for(let f of filter) {
                whereFilter.push(getConditionalQuery(f.operation, f.columnName, f.value));
              }
            }

            if (config?.search?.trim()) {
              searchStr = " | " + config.search.trim();
            }

            let splungQuery = `search index="${indexId}" sourcetype="csv" | fields - "_bkt","_cd","_indextime","_raw","_serial","_si","_sourcetype","_time",host,index,linecount,source,sourcetype,eventtype,punct,splunk_server_group,timestamp,"splunk_server",_eventtype_color | table * ${whereFilter.length ? '| where ' + whereFilter.join(' AND ') : ''} ${searchStr}`;
            
            let indexes = await service.search(splungQuery, searchParams);
            indexes = await indexes.fetch();
            const results: any = await getSearchResult(indexes, config);
    
            response.status = true;
            response.data = results.data;
            response.totalRecords = results.totalRecords;
          } else {
            response.error = "Unable to connect to Splunk";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          if (err?.data?.messages?.length && err?.data?.messages[0]['text']) {
            response.error = err.data.messages[0]['text'];
          }
          resolve(response);
        }
      });
    }
}

function connect(accountId) {
    return new Promise(async(resolve) => {
      let result: any = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .createQueryBuilder("WA")
                .where(" WA.id = :id ", { id: accountId })
                .getOne();
                
      const config = result && result.config ? JSON.parse(result.config) : {};
      if (config?.dbType === "SPLUNK" && config?.dbUser && config?.dbPassword && config?.dbHost && config?.dbPort) {
        try { 
          const service = new splunkjs.Service({
              username: config.dbUser,
              password: config.dbPassword,
              host: config.dbHost,
              port: config.dbPort,
              scheme: 'https',
              debug: true
          });
          service.login();
          resolve(service);
        } catch (err) {
          console.log("Login failure. Please check your server hostname and authentication credentials.");
          resolve(null);
        }
      }
      
      resolve(null);
    });
}

function getSearchResult(indexes, config) {
  const response: any = {
    data: [],
    totalRecords: indexes.properties().resultCount || 0
  };
  return new Promise(async (resolve) => {
    try {
      // Page through results by looping through sets of 10 at a time
      let myOffset = 0;         // Start at result 0
      let myCount = 10;         // Get sets of 10 results at a time

      if (config?.start) {
        myOffset = config.start;
      }
      if (config?.limit) {
        myCount = config.limit;
      } 
      // Run an asynchronous while loop using the Utils.whilst helper function to
      // loop through each set of results 
      await splunkjs.Utils.whilst(

          // Condition--loop while there are still results to display
          function() {
              return (myOffset < response.totalRecords);
          },

          // Body--display each set of results
          async function() {
              // Get one set of results
              let results;
              [results, indexes] = await indexes.results();
              
              // Display results
              let fields = results.fields;
              let rows = results.rows;
              for(let i = 0; i < rows.length; i++) {
                  let values = rows[i];
                  let dataSet = {};
                  for(let j = 0; j < values.length; j++) {
                    dataSet[fields[j]]= values[j];
                  }
                  response.data.push(dataSet);
              }
                  
              // Increase the offset to get the next set of results
              // once we are done processing the current set.
              myOffset = myOffset + myCount;
          }
      );
      resolve(response);
    } catch(err){
      console.log("There was an error retrieving the list of applications:", err);
      response.error = "There was an error retrieving the list of applications";
      resolve(response);
    }
  });
}

function getFieldFromResult(indexes) {
  let response: any = [];
  return new Promise(async (resolve) => {
    try {
      // Page through results by looping through sets of 10 at a time
    let resultCount = indexes.properties().resultCount; // Number of results this job returned
    let myOffset = 0;         // Start at result 0
    let myCount = 1;         // Get sets of 10 results at a time

    // Run an asynchronous while loop using the Utils.whilst helper function to
    // loop through each set of results 
    await splunkjs.Utils.whilst(

        // Condition--loop while there are still results to display
        function() {
            return (myOffset < resultCount);
        },

        // Body--display each set of results
        async function() {
            // Get one set of results
            let results;
            [results, indexes] = await indexes.results();

            // Display results
            response = results.fields;
                
            // Increase the offset to get the next set of results
            // once we are done processing the current set.
            myOffset = myOffset + myCount;
        }
    );
    resolve(response);
    } catch(err){
      console.log("There was an error retrieving the list of applications:", err);
      response.error = "There was an error retrieving the list of applications";
      resolve(response);
    }
  });
}

function getConditionalQuery(sign, field, value) {
  switch (sign) {
      case 'equals':
            return `${field} = "${value}"`;
      case 'greater':
          return `${field} > "${value}"`;
      case 'greater_equals':
          return `${field} >= "${value}"`;
      case 'less':
          return `${field} < "${value}"`;
      case 'less_equals':
          return `${field} <= "${value}"`;
      case 'not_equals':
          return `${field} != "${value}"`;
      default:
          return '';
  }
}