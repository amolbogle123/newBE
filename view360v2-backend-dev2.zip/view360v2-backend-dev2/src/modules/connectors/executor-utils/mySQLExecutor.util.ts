import * as mysql from "mysql";


export class MySQLExecutorUtil {
    static async executeMYSQLQuery(queryToExecute, widgetAccountConfig) {
        const response: any = {status: false, data: [], message: {}};
        return new Promise(async (resolve) => {
            let accountConfig = await this.getAccountConfig(widgetAccountConfig);
            if (accountConfig) {
                const mysqlConnection = mysql.createConnection(accountConfig);
                mysqlConnection.connect((err) => {
                    if (err) {
                        response.displayType = "error";
                        response.message = `Could not connect to MYSQL database..`;
                        resolve(response);
                    } else {
                        mysqlConnection.query(queryToExecute, (error, results, fields) => {
                            mysqlConnection.destroy();
                            if (error) {
                                response.displayType = "error";
                                response.message = `Error while fetching data please check your MYSQL query.`;
                                resolve(response);
                            } else {
                                response.status = true;
                                response.data = results;
                                response.fields = fields;
                                resolve(response);
                            }
                        });
                    }
                });
            } else {
                response.message = `Provide Connector.`;
                resolve(response);
            }
        })
    }

    static async getAccountConfig(widgetAccountConfig) {
        let accountConfig = {};
        if (widgetAccountConfig && widgetAccountConfig.dbType) {
            accountConfig = {
                multipleStatements: true,
                host: widgetAccountConfig.dbHost ? widgetAccountConfig.dbHost : "",
                user: widgetAccountConfig.dbUser ? widgetAccountConfig.dbUser : "",
                password: widgetAccountConfig.dbPassword ? widgetAccountConfig.dbPassword : "",
                database: widgetAccountConfig.dbName ? widgetAccountConfig.dbName : "",
            };
            return accountConfig;
        } else  {
            return accountConfig;
        }
    }
}
