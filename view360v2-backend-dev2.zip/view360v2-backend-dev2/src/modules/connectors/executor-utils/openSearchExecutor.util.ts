import { Client } from "@opensearch-project/opensearch";
import fs from "fs";
import Container from "typedi";
import { DataSource } from "typeorm";

import { WidgetAccount } from "entities";

export class OpenSearchExecutor {
    static async getTestList(accountId, queryArr) {
      const response: any = {status: false, data: [], error: null};
      return new Promise(async (resolve) => {
        try {
          let service: any = await connect(accountId);
          if (!service) {
            response.error = "Unable to connect to Open Search";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }

    static async getIndexesList(accountId) {
      const response: any = {status: false, data: [], error: null};
      return new Promise(async (resolve) => {
        try {
          let client: any = await connect(accountId);
          if (client) { 
            const clientResponse = await client.indices.get_alias();

            let list = [];
            if (clientResponse?.body) {
              Object.keys(clientResponse.body).forEach((v, k) => {
                list.push({
                  index: v,
                  name: v
                });
              });
            }

            response.status = true;
            response.data = list;
          } else {
            response.error = "Unable to connect to Open Search";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }

    static async getIndexColumn(accountId, indexName) {
      const response: any = {status: false, data: [], error: null};
      return new Promise(async (resolve) => {
        try {
          let client: any = await connect(accountId);
          if (client && indexName) { 
            const clientResponse = await client.indices.get({index:indexName});

            if (
              clientResponse?.body && 
              clientResponse?.body[indexName] && 
              clientResponse?.body[indexName].mappings?.properties
            ) {
              response.status = true;
              response.data = clientResponse.body[indexName].mappings.properties;
            }
          } else {
            response.error = "Unable to connect to Open Search";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }

    static async createIndex(accountId, indexName) {
      const response: any = {status: false, data: {}, error: null};
      return new Promise(async (resolve) => {
        try {
          let client: any = await connect(accountId);
          if (client) { 
            const settings = {
              settings: {
                  index: {
                  number_of_shards: 4,
                  number_of_replicas: 3,
                  },
              },
            };
            const clientResponse = await client.indices.create({
              index: indexName,
              body: settings,
            });
            
            if (clientResponse?.statusCode == 200 && clientResponse?.body) {
              response.status = true;
              response.data = clientResponse.body;
            }
          } else {
            response.error = "Unable to connect to Open Search";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }

    static async createBulkIndex(accountId, indexName, documentList) {
      const response: any = {status: false, data: [], error: null};
      return new Promise(async (resolve) => {
        try {
          let client: any = await connect(accountId);
          if (client && documentList?.length) { 
            const result = await client.helpers.bulk({
              datasource: documentList,
              onDocument (doc) {
                return {
                  index: { _index: indexName }
                }
              }
            });

            response.status = true;
            response.data = result;
          } else {
            response.error = "Unable to connect to Open Search";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }

    static async searchIndexData(accountId, indexId, filter, config) {
      const response: any = {status: false, data: [], error: null};
      return new Promise(async (resolve) => {
        try {
          let client: any = await connect(accountId);
          if (client) { 
            let from = 0;
            let size = 10;

            if (config?.limit) {
              size = config.limit;
            }
            if (config?.start) {
              from = config.start;
            }
            const query = {
              query: {
                // match: {
                //   title: {
                //     query: '',
                //   },
                // },
                match_all: {},
              },
              from: from,
              size: size,
            };
            const clientResponse = await client.search({
              index: indexId,
              body: query,
            });

            // const clientResponse = await client.cat.doc({ index: indexId, format: "json" });

            const responseData = {list: [], totalRecords: 0};
            if (clientResponse?.body?.hits?.hits?.length) {
              responseData.totalRecords = clientResponse.body.hits.total.value;
              responseData.list = clientResponse.body.hits.hits.map((v) => {
                return v._source;
              });
            }
    
            response.status = true;
            response.data = responseData;
          } else {
            response.error = "Unable to connect to Open Search";
          }
          resolve(response);
        } catch(err){
          console.log("There was an error retrieving the list of applications:", err);
          response.error = "There was an error retrieving the list of applications";
          resolve(response);
        }
      });
    }
}

function connect(accountId) {
    return new Promise(async(resolve) => {
      const base64UploadDir = "public/open-search/";
      if (!fs.existsSync(base64UploadDir)) {
        fs.mkdirSync(base64UploadDir);
        fs.writeFileSync(`${base64UploadDir}cert.pem`, '');
      }
      let result: any = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .createQueryBuilder("WA")
                .where(" WA.id = :id ", { id: accountId })
                .getOne();
                
      const config = result && result.config ? JSON.parse(result.config) : {};
      if (config?.dbType === "OPEN_SEARCH" && config?.dbUser && config?.dbPassword && config?.dbHost && config?.dbPort) {
        try { 
          const ca_certs_path = "public/open-search/cert.pem";
          const nodeUrl = `https://${config.dbUser}:${config.dbPassword}@${config.dbHost}:${config.dbPort}`;
          const client = new Client({
            node: nodeUrl,
            ssl: {
              ca: fs.readFileSync(ca_certs_path),
              rejectUnauthorized: false,
            },
          });
          
          resolve(client);
        } catch (err) {
          console.log("Login failure. Please check your server hostname and authentication credentials.");
          resolve(null);
        }
      }
      
      resolve(null);
    });
}