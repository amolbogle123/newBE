import * as mssql from "mssql";


export class MsSQLExecutorUtil {
    static async executeMSSQLQuery(queryToExecute, widgetAccountConfig) {
        const response: any = {status: false, data: [], message: {}};
        return new Promise(async (resolve) => {
            if (widgetAccountConfig && widgetAccountConfig.dbType) {
                let connectorConfig: any = {};
                connectorConfig = widgetAccountConfig;
                let sqlConfig = {
                    user: connectorConfig.dbUser,
                    password: connectorConfig.dbPassword,
                    database: connectorConfig.dbName,
                    server: connectorConfig.dbHost,
                    options: {
                        arrayRowMode: true,
                        encrypt: true, // for azure
                        trustServerCertificate: true, // change to true for local dev / self-signed certs
                    },
                    arrayRowMode: true,
                };
                try {
                    const newConnection = await mssql.connect(sqlConfig);
                    const result = await newConnection.query(queryToExecute);
                    await newConnection.close();
                    response.status = true;
                    response.data = result;
                    resolve(response);
                } catch (dbError) {
                    if (dbError) {
                        response.message = dbError;
                    } else {
                        response.message = `Error while fetching records or connecting database. please check configuration.`;
                    }
                    resolve(response);
                }
            } else {
                response.message = `Provide Connector.`;
                resolve(response);
            }
        })
    }
}
