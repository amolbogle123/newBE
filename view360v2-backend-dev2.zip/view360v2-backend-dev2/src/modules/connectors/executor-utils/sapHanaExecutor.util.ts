import { createConnection } from "@sap/hana-client";

export class HanaConnection {
    private static connection: any;
    public static connect(request): any {
        if (!HanaConnection.connection) {
            const connection = createConnection();
            connection.connect(
                {
                    serverNode: `${request.dbHost}:${request.dbPort}`,
                    uid: request.dbUser,
                    pwd: request.dbPassword,
                    databaseName: request.dbName,
                    encrypt: false,
                    sslValidateCertificate: false,
                },
                (err: any) => {
                    if (err) {
                        console.error("Error connecting to SAP HANA:", err);
                        HanaConnection.connection = {
                            status: false,
                            error: err,
                        };
                    }
                }
            );

            HanaConnection.connection = connection;
        }

        return HanaConnection.connection;
    }
}
