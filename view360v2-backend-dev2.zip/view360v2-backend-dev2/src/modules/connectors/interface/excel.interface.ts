interface Columns {
    data: string;
    name: string;
    searchable: boolean;
    orderable: boolean;
    search: Search;
}
interface Search {
    value: string;
    regex: boolean;
}

interface Order {
    column: number;
    dir: string;
}

export interface GetVendorListRequest {
    draw: number;
    columns: Columns[];
    order: Order[];
    start: number;
    length: number;
    search: Search;
    type: string;
}

export interface InsertVendorRequest {
    files?: any;
    name?: string;
    shareSampleData?: boolean;
}

export interface DeleteVendorData {
    id: string[];
}

export interface VendorListResponse {
    status: boolean;
    data?: any;
    message?: string;
    recordsTotal?: number;
    recordsFiltered?: number;
}

export interface SaveVendorResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DeleteVendorDataResponse {
    status: boolean;
    data?: any;
    message?: string;
}
