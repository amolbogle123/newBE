export interface GetWidgetToAccountList{
    type?:string
}
export interface AddWidgetAccount{
    widgetType?:string
    accountName?:string
    config?:string
    accountConfig?:object
    id?:string
}
