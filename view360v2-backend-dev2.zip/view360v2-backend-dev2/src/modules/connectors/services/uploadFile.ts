import fs from "fs";
import XLSX from "xlsx";

export class UploadFile {
    public xlsxRowData = [];
    async xlsxFileTest(i, fileDetails, userDetails): Promise<any> {
        return new Promise(async (resolve) => {
            console.log('i, fileDetails, userDetails', i, fileDetails, userDetails);
            if (fileDetails?.fileUrl && fs.existsSync("./public" + fileDetails.fileUrl)) {
                let fileUrl = "./public" + fileDetails.fileUrl;
                console.log('File exists.');

                const filePath = fileUrl;
                const chunkSize = 1024 * 1024; // Adjust chunk size as needed (e.g., 1MB)
                const headerRange = 'A6:F6'; // Replace with your actual header range

                readFirstFiveRecords(filePath, chunkSize, headerRange).then((records) => {
                    console.log('First 5 records:', records);
                }).catch((error) => {
                    console.error('Error reading Excel file:', error);
                });
            }
            resolve(true);
        });
    }
    async xlsxFile(i, fileDetails, userDetails, shareSampleData = false): Promise<any> {
        return new Promise(async (resolve) => {
            const apiResponse: any = {
                data: null,
                error: null,
            };
            let headerKeys;
            const uploadedFilePath = "./public" + fileDetails.fileUrl;
            const uploadedJsonFile = "./public/json-data-migration/" + fileDetails.jsonFile;
            if (!fs.existsSync("./public/json-data-migration")) {
                // If the folder does not exist, create it
                fs.mkdirSync("./public/json-data-migration", { recursive: true });
            }
            if (fs.existsSync(uploadedJsonFile)) {
                console.log('File exists.');
            } else {
                this.xlsxRowData = [];
            }

            try {
                if (fs.existsSync(uploadedFilePath)) {
                    let fileData = [];
                    const workSheetsFromFile = XLSX.readFile(
                        uploadedFilePath,
                        {
                            type: "binary",
                            cellDates: true,
                            cellNF: false,
                            cellText: false,
                        }
                    );

                    const sheetnames = Object.keys(workSheetsFromFile.Sheets);
                    for (let sheetname of sheetnames) {
                        var range = XLSX.utils.decode_range(
                            workSheetsFromFile.Sheets[sheetname]["!ref"]
                        );
                        
                        const sheetDetails = fileDetails.sheetName.find((sheet) => sheet.name === sheetname)
                        const matches = sheetDetails.columnStartNumber.match(/([A-Za-z]+)(\d+)/);
                        
                        const numberPart = Number(matches[2]); // Extract numeric part
                        //range.s.c = stringPart;
                        range.s.r = numberPart - 1;

                        const matches1 = sheetDetails.columnEndNumber.match(/([A-Za-z]+)(\d+)/);
                        
                        const startRange = XLSX.utils.decode_range(matches[0]);
                        const endRange = XLSX.utils.decode_range(matches1[0]);
                        range.s.c = startRange.s.c;
                        range.e.c = endRange.e.c;


                        var new_range = XLSX.utils.encode_range(range);
                        const xlsxJson = XLSX.utils.sheet_to_json(workSheetsFromFile.Sheets[sheetname],
                                {
                                    range: new_range,
                                    blankrows: false,
                                    raw: false,
                                    dateNF: 'm"/"d"/"yyyy',
                                }
                            )
                                .map((row) =>
                                    Object.keys(row).reduce((obj, key) => {
                                        obj[key.trim()] = row[key];
                                        return obj;
                                    }, {})
                                );
                            fileData.push({
                                name: sheetname,
                                xlsxJson,
                            });
                    }
                    const xlsxResult: any = await xlsxFileParse(apiResponse, fileData, headerKeys);
                    if (xlsxResult) {
                        apiResponse.data = xlsxResult.data;
                    }
                }
                if (shareSampleData) {
                    apiResponse.data = this.xlsxRowData.map((x) => {
                        return {
                            name: x.name,
                            headers: x.headers
                        };
                    });
                }
                
                const jsonFileName = JSON.stringify(this.xlsxRowData, null, 2);
                fs.writeFile(uploadedJsonFile, jsonFileName , (err) => {
                    if (err) {
                        console.error('Error writing JSON file:', err);
                    } else {
                        console.log('JSON file created successfully.');
                    }
                });
                resolve(apiResponse);
            } catch (error) {
                resolve(apiResponse);
            }
        });
    }
}

function readFirstFiveRecords(filePath, chunkSize, headerRange) {
    return new Promise((resolve, reject) => {
      const chunks = [];
      const records = [];
      let rowCount = 0; // Track the number of processed rows
        console.log('filePath, chunkSize, headerRange', filePath, chunkSize, headerRange);
      const stream = fs.createReadStream(filePath);
  
      stream.on('data', (chunk) => {
        chunks.push(chunk);
        if (chunks.length * chunkSize >= stream.bytesRead) {
          const buffer = Buffer.concat(chunks);
          const workbook = XLSX.read(buffer, { type: 'buffer' });
  
          const sheet = workbook.Sheets[workbook.SheetNames[0]]; // Assuming first sheet
          const headerRow = XLSX.utils.decode_cell(headerRange.split(':')[0]); // Get starting cell of header range
          const headerRowIndex = headerRow.r; // Get row index of header
  
          for (const rowKey in sheet) {
            if (XLSX.utils.decode_row(rowKey) > headerRowIndex && rowCount < 5) { // Skip header and limit to 5 records
              const record = {};
              for (const colKey in sheet[rowKey]) {
                const cell = sheet[colKey];
                const cellValue = cell ? cell.v : ''; // Handle empty cells
                record[XLSX.utils.decode_col(colKey)] = cellValue; // Extract data based on column index
              }
              records.push(record);
              rowCount++;
            }
            if (rowCount >= 5) {
              break; // Stop processing after reading 5 records
            }
          }
          chunks.length = 0; // Reset chunks for next iteration
        }
      });
  
      stream.on('end', () => {
        resolve(records);
      });
  
      stream.on('error', (error) => {
        reject(error);
      });
    });
}

function xlsxFileParse(apiResponse, fileData, headerKeys) {
    return new Promise((resolve) => {
        apiResponse.data = [];
        if (fileData?.length) {
            for (let sheet of fileData) {
                if (sheet.xlsxJson?.length) {
                    for (let row of sheet.xlsxJson) {
                        if (row) {
                            headerKeys = Object.keys(row);
                            const rowData = JSON.stringify(Object.values(row));
                            apiResponse.data.push(rowData);
                        }
                    }
                }
                this.xlsxRowData.push({name: sheet.name, headers: headerKeys , rows: apiResponse.data});
                apiResponse.data = [];
            }
        }

        resolve(apiResponse);
    });
}