import { config } from "dotenv";

config();

export const dbConfig = {
    host: process.env.HANA_HOST || "",
    port: process.env.HANA_PORT || "",
    user: process.env.HANA_USER || "",
    password: process.env.HANA_PASSWORD || "",
    database: process.env.HANA_DATABASE || "",
    encrypt: process.env.HANA_ENCRYPT || "false", 
    sslValidateCertificate:
        process.env.HANA_SSL_VALIDATE_CERTIFICATE || "false",
};
