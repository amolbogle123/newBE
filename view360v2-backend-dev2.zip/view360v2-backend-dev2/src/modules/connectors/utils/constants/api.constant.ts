export const SUPPORT_DB_LIST = [
    {
        id: "MYSQL",
        name: "MySQL",
    },
    {
        id: "MSSQL",
        name: "Microsoft SQL Server",
    },
    {
        id: "MONGODB",
        name: "Mongo DB",
    },
    {
        id: "POSTGRESQL",
        name: "PostgreSQL",
    }
];
