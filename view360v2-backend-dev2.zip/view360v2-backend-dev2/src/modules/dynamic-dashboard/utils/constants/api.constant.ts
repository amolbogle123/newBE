

export const NO_RECORD_FOUND: string = 'No records has been found!.'

export const formBuilderTableName: string = 'FORM_BUILDER_'
