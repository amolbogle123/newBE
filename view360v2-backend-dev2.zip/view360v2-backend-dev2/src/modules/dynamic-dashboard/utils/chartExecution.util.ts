import { DashboardWidget, PublicTables, Users, WidgetAccount } from "entities";
import moment from "moment/moment";
import Container from "typedi";
import { DataSource } from "typeorm";
import { CommonUtil } from "utils/common.util";
import { DMSFilesLogs } from "../../../entities/dms-files-logs";
import { MsSQLExecutorUtil } from "../../connectors/executor-utils/msSQLExecutor.util";
import { MySQLExecutorUtil } from "../../connectors/executor-utils/mySQLExecutor.util";
import { FormBuilderExecutionUtil } from "../../form-builder/utils/form-builderExecutionUtil";

import * as jsforce from 'jsforce';
export class ChartExecutionUtil {
    static is_superadmin = false;
    static async getWidgetConfigAndAccountConfig(req) {
        const id = req.params.widgetId;
        let returnValue: any = { isConfigured: false, widgetFound: false, widgetConfig: '', accountConfigDetails: '' };
        const result = await Container.get(DataSource).getRepository(DashboardWidget)
            .createQueryBuilder('DW')
            .leftJoinAndSelect('DW.widgetAccount', 'widgetAccount')
            .where('DW.id = :id', { id: id })
            .getMany();
        if (result && result.length > 0) {
            const widgetResponse: any = result[0];
            if (widgetResponse.isConfigured <= 0) {
                return false;
            }
            returnValue.isConfigured = true;
            returnValue.widgetFound = true;
            let accountConfigDetails;
            if(!widgetResponse.widgetAccount) {
               accountConfigDetails = {
                    dbType: process.env.DB_TYPE,
                    dbHost: process.env.DB_HOST,
                    dbName: process.env.DB_NAME,
                    dbUser: process.env.DB_USERNAME,
                    dbPassword: process.env.DB_PASSWORD,
                };
            }
            returnValue.widgetConfig = widgetResponse.widgetConfig ? JSON.parse(widgetResponse.widgetConfig.replace(/\\/g, "")) : {};
            returnValue.accountConfigDetails = widgetResponse.widgetAccount ? JSON.parse(widgetResponse.widgetAccount.config) : accountConfigDetails;

            if (widgetResponse?.widgetAccount?.widgetType === "VIEW360_TABLE") {
                returnValue['widgetType'] = 'VIEW360_TABLE';
            }

            if (widgetResponse?.widgetAccount?.widgetType === "VIEW360_TABLE") {
                returnValue['widgetType'] = 'VIEW360_TABLE';
            }
            return returnValue;
        } else {
            return false;
        }
    }

    static async getAccountConfig(req) {
        let returnValue = { accountConfigDetails: '' };
        const queryResponse = await Container.get(DataSource).getRepository(WidgetAccount)
            .findOne({ where: { id: req.body.widgetAccount } });
        returnValue.accountConfigDetails = queryResponse?.config ? JSON.parse(queryResponse.config) : {};
        if (queryResponse?.widgetType === "VIEW360_TABLE") {
            returnValue['widgetType'] = 'VIEW360_TABLE';
        }
        if (queryResponse?.widgetType === "VIEW360_TABLE") {
            returnValue['widgetType'] = 'VIEW360_TABLE';
        }
        return returnValue;
    }

    static async executeView360DataSource(widgetConfig, req) {
        let data;

        const responseObj: any = { status: true, data: [], error: null };
        responseObj.cacheWidget = widgetConfig.cacheWidget;
        responseObj.isManualQuery = widgetConfig.isManualQuery;
        responseObj.sourceType = widgetConfig.sourceType;
        responseObj.displayType = widgetConfig.chartType;
        responseObj.formField = widgetConfig.formField;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        responseObj.properties = widgetConfig.properties || {};

        let mysqlQuery = await this.customMYSQLQuery(widgetConfig, req,false,true);
        const publicResult = await Container.get(DataSource).manager.query(mysqlQuery);
        if (publicResult?.length) {
            let fields = [];
            if (widgetConfig?.xAxis) {
                fields.push({name: widgetConfig.xAxis});
            }
            if (widgetConfig?.yAxis?.length) {
                fields = fields.concat(widgetConfig.yAxis.map((y) => ({name: y})));
            }
            data = this.chartDataFormatter({fields: fields, data: publicResult}, responseObj, mysqlQuery);
        }
        return data;
    }
    static async executeAccountDataSource(widgetConfig, accountConfigDetails, req) {
        const responseObj: any = { status: true, data: [], error: null };
        let data;
        responseObj.widgetConfig = widgetConfig;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        if (accountConfigDetails && accountConfigDetails.dbType === "MSSQL") {
            data = await this.prepareMSSQLQueryAndExecute(accountConfigDetails, widgetConfig);
        } else if (accountConfigDetails && accountConfigDetails.dbType.toLowerCase() === "MYSQL".toLowerCase()) {
            data = await this.prepareMYSQLQueryAndExecute(accountConfigDetails, widgetConfig, req);
        } else if (accountConfigDetails && accountConfigDetails.dbType === "POSTGRES") {
            //TO_DO the function of Postgress goes here
        } else if (accountConfigDetails && accountConfigDetails.dbType === "MONGODB") {
            //TO_DO the function of MONGODB goes here
        } else if (accountConfigDetails && accountConfigDetails.dbType === "SALESFORCE"){
            data = await this.prepareSalesforceQueryAndExecute(accountConfigDetails, widgetConfig, req);
        }
        return data;
    }
    static async executeRelationAccountDataSource(widgetConfig, accountConfigDetails, req) {
        const responseObj: any = { status: true, data: [], error: null };
        let data;
        responseObj.widgetConfig = widgetConfig;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        if (accountConfigDetails && accountConfigDetails.dbType === "MYSQL") {
            data = await this.prepareMYSQLRelationQueryAndExecute(accountConfigDetails, widgetConfig, req);
        }
        return data;
    }
    static async executeRelationView360DataSource(widgetConfig, accountConfigDetails, req) {
        const responseObj: any = { status: true, data: [], error: null };
        let data;
        responseObj.widgetConfig = widgetConfig;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        data = await this.prepareMYSQLRelationQueryAndExecute(accountConfigDetails, widgetConfig, req);
        return data;
    }
    static async executeUpdateAccountDataSource(widgetConfig, accountConfigDetails, req) {
        const responseObj: any = { status: true, data: [], error: null };
        let data;
        responseObj.widgetConfig = widgetConfig;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        if (accountConfigDetails && accountConfigDetails.dbType === "MSSQL") {
            data = await this.prepareMSSQLQueryAndExecute(accountConfigDetails, widgetConfig);
        } else if (accountConfigDetails && accountConfigDetails.dbType === "MYSQL") {
            data = await this.prepareMYSQLUpdateDeleteQueryAndExecute(accountConfigDetails, widgetConfig, req);
        } else if (accountConfigDetails && accountConfigDetails.dbType === "POSTGRES") {
            //TO_DO the function of Postgress goes here
        } else if (accountConfigDetails && accountConfigDetails.dbType === "MONGODB") {
            //TO_DO the function of MONGODB goes here
        } else if(accountConfigDetails && accountConfigDetails.dbType === "SALESFORCE"){
            data = await this.prepareSalesforceQueryAndExecute(accountConfigDetails, widgetConfig, req);
        }
        return data;
    }

    static async prepareMSSQLQueryAndExecute(accountConfigDetails, widgetConfig) {
        const responseObj: any = { status: true, data: [], error: null };
        let mssqlQuery = "";
        if (widgetConfig.isManualQuery && widgetConfig.query) {
            mssqlQuery = widgetConfig.query;
        } else {
            mssqlQuery = this.createMSSQLQuery(widgetConfig);
        }
        const mssqlData: any = await MsSQLExecutorUtil.executeMSSQLQuery(mssqlQuery, accountConfigDetails);
        if (mssqlData.status) {
            responseObj.data = [];
            responseObj.xAxis = '';
            responseObj.yAxis = [];
            if (mssqlData.data && mssqlData.data.recordset && mssqlData.data.recordset.length > 0) {
                const queryFields = Object.keys(mssqlData.data.recordset[0]);
                responseObj.xAxis = queryFields[0];
                queryFields.splice(0, 1);
                responseObj.yAxis = queryFields;
                responseObj.data = mssqlData.data.recordset;
            }
            return responseObj;
        } else {
            responseObj.error = mssqlData.message;
            return responseObj;
        }
    }

    private static createMSSQLQuery(widgetConfig) {
        if (!Array.isArray(widgetConfig.yAxis)) {
            widgetConfig.yAxis = [widgetConfig.yAxis];
        }
        const selectFields = [];
        selectFields.push(`[${widgetConfig.xAxis}] as '${widgetConfig.xAxis}'`);
        for (const yField of widgetConfig.yAxis) {
            if (widgetConfig.operationType === 'SUM') {
                selectFields.push(`SUM([${yField}]) as '${yField}'`);
            } else if (widgetConfig.operationType === 'COUNT') {
                selectFields.push(`COUNT([${yField}]) as '${yField}'`);
            } else if (widgetConfig.operationType === 'AVG') {
                selectFields.push(`AVG([${yField}]) as '${yField}'`);
            } else if (widgetConfig.operationType === 'MIN') {
                selectFields.push(`MIN([${yField}]) as '${yField}'`);
            } else if (widgetConfig.operationType === 'MAX') {
                selectFields.push(`MAX([${yField}]) as '${yField}'`);
            } else if (widgetConfig.operationType === 'DISTINCT') {
                selectFields.push(`DISTINCT([${yField}]) as '${yField}'`);
            } else {
                selectFields.push(`[${yField}]`);
            }
        }
        return `SELECT ${selectFields.join(',')} FROM ${widgetConfig.form} GROUP BY ${widgetConfig.xAxis}`;
    }

    static async prepareView360RelationQueryAndExecute(widgetConfig, req, columnList) {
        const responseObj: any = { status: true, data: [], error: null };
        responseObj.cacheWidget = widgetConfig.cacheWidget;
        responseObj.isManualQuery = widgetConfig.isManualQuery;
        responseObj.sourceType = widgetConfig.sourceType;
        responseObj.displayType = widgetConfig.chartType;
        responseObj.formField = widgetConfig.formField;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        responseObj.properties = widgetConfig.properties || {};
        
        let query = widgetConfig.query + ' WHERE 1 ';

        if (Array.isArray(widgetConfig.whereFields) && widgetConfig.whereFields.length > 0 && widgetConfig.whereFields[0].columnName) {
            let innerConditions = [];
            for (const whereValue of widgetConfig.whereFields) {
                let conditionQuery = await CommonUtil.getConditionalQuery(whereValue.columnName, whereValue.matchCase, whereValue.matchValue, '');
                if (conditionQuery) {
                    innerConditions.push(`${conditionQuery}`);
                }
            }
            if (innerConditions.length) {
                query += ` AND ${innerConditions.join(' AND ')}`;
            }
        }
        
        let filterWhere = await CommonUtil.applyFilterToAccounts(
            req.body?.filters,
            ''
        );
        if (filterWhere) {
            if (req.body?.selectedFilter) {
                let condition = "";
                const fieldNames = await CommonUtil.getFieldNameFromFilter(req.body.filters);
                if (fieldNames.length) {
                    for (let fieldName of fieldNames) {
                        const tableIdentifier = await CommonUtil.getAliasOrTableForField(query, fieldName);
                        if (tableIdentifier) {
                            const filters = filterWhere.split(' AND ');
                            for (let filter of filters) {
                                if (filter.includes(fieldName)) {
                                    if (condition) {
                                        condition += ' AND ';
                                    }
                                    condition += `${tableIdentifier}.${filter.trim()}`;
                                }
                            }
                        }
                    }
                    query = query.replace(/WHERE\s+/g, `WHERE ${condition} AND `);
                }
            } else {
                query += ' AND ' + filterWhere;
            }
        }

        let limit = req.body.length ? req.body.length : 10;
        let start = req.body.start ? req.body.start : 0;
        let sortField = req.body.sortField ? req.body.sortField : "";
        let sortOrder: 'DESC' | 'ASC' = req.body.sortOrder ? req.body.sortOrder : 'DESC';
        let orderBy = "";
        let offsetLimit = "";
        if (sortField !== "") {
            if (query.includes('ORDER BY')) {
                let lastOrderByIndex = query.lastIndexOf('ORDER BY');
                if (lastOrderByIndex !== -1) {
                    query = query.substring(0, lastOrderByIndex);
                }
            }
            
            orderBy = ` ORDER BY ${this.addtick(sortField)} ${sortOrder}`;
        }

        columnList.push({name: "recordsTotal"});
        offsetLimit = ` LIMIT ${start},${limit}`;
        let mysqlQuery = `SELECT t.*,(SELECT COUNT(*) FROM (${query}) AS subquery) AS recordsTotal FROM (${query + orderBy + (req.body.allData ? '' : offsetLimit)}) AS t;`

        const accountConfigDetails = {
            dbType: process.env.DB_TYPE,
            dbHost: process.env.DB_HOST,
            dbName: process.env.DB_NAME,
            dbUser: process.env.DB_USERNAME,
            dbPassword: process.env.DB_PASSWORD,
        };
        let resultData = [];
        const dbData: any = await MySQLExecutorUtil.executeMYSQLQuery(mysqlQuery, accountConfigDetails);
        if (dbData?.status && dbData?.data?.length) {
            resultData = dbData.data;
        } else if(!dbData?.status && widgetConfig?.properties?.relationFormId?.extraConfig?.isMultipleConnector && widgetConfig?.properties?.relationFormId?.extraConfig?.tableName) {
            let tableName = widgetConfig.properties.relationFormId.extraConfig.tableName;
            if (widgetConfig.properties.relationFormId.extraConfig.tableSubName) {
                tableName = `${widgetConfig.properties.relationFormId.extraConfig.tableSubName}${widgetConfig.properties.relationFormId.extraConfig.tableName}`;
            }
            let mysqlQuery1 = `SHOW TABLES LIKE '${tableName}'`;
            const checkTable: any = await MySQLExecutorUtil.executeMYSQLQuery(mysqlQuery1, accountConfigDetails);
            if (!checkTable?.status || !checkTable?.data?.length) {
                let errorMsg = "The data relation has been deleted, or the table does not exist.";
                responseObj.status = false;
                responseObj.error = errorMsg;
                responseObj.message = errorMsg;
                responseObj.displayType = "error";
                return responseObj;
            }
        }
        return this.chartDataFormatter({fields: columnList, data: resultData}, responseObj, mysqlQuery);
    }

    static async prepareMYSQLRelationQueryAndExecute(accountConfigDetails, widgetConfig, req) {
        const responseObj: any = { status: true, data: [], error: null };
        responseObj.cacheWidget = widgetConfig.cacheWidget;
        responseObj.isManualQuery = widgetConfig.isManualQuery;
        responseObj.sourceType = widgetConfig.sourceType;
        responseObj.displayType = widgetConfig.chartType;
        responseObj.formField = widgetConfig.formField;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        responseObj.properties = widgetConfig.properties || {};

        let query = widgetConfig.query + ' WHERE 1 ';
        if (widgetConfig.xAxis) {
            query = await this.checkPrimaryColumn(query, widgetConfig.xAxis);
        }

        if (req.body?.fromWidget === "BUTTON_WIDGET" && req.body?.fromButtonQuery) {
            query = req.body.fromButtonQuery;
        } else if (req.body?.selectedFilter) {
            query = req.body.selectedFilter;
            // query = await this.checkPrimaryColumn(req.body.selectedFilter, widgetConfig.xAxis);
            console.log("Query :: Inside widget filter :: ", query);
        } else if (req.body?.fromWidget === 'WIDGET_FILTER') {
            query += ` AND ${this.addtick(req.body.columnName)}  =  '${req.body.selectedFilter.replace(/^\s+|\s+$/g, '')}'`;
        }

        if (query.includes("{DATE_FILTER_COLUMN}") && req.body?.columnName) {
            let nameArr = req.body.columnName.split(".");
            if (nameArr?.length > 1 && nameArr[1]) {
                // query = query.replace("{DATE_FILTER_COLUMN}", `${await this.formatColumnString(nameArr[1])}`);
                query = query.replace(/{DATE_FILTER_COLUMN}/g, `${await this.formatColumnString(nameArr[1])}`);
            }
        }
        if (req.body?.dateRange && (query.includes("{START_DATE}") || query.includes("{END_DATE}"))) {
            const dateRange = JSON.parse(req.body.dateRange);

            if (dateRange?.length === 2) {
                // query = query.replace("{START_DATE}", `"${await this.formatDateString(dateRange[0])}"`);
                // query = query.replace("{END_DATE}", `"${await this.formatDateString(dateRange[1])}"`);
                query = query.replace(/{START_DATE}/g, `"${await this.formatDateString(dateRange[0])}"`);
                query = query.replace(/{END_DATE}/g, `"${await this.formatDateString(dateRange[1])}"`);
            }
        }

        if (Array.isArray(widgetConfig.whereFields) && widgetConfig.whereFields.length > 0 && widgetConfig.whereFields[0].columnName) {
            let innerConditions = [];
            for (const whereValue of widgetConfig.whereFields) {
                let conditionQuery = await CommonUtil.getConditionalQuery(whereValue.columnName, whereValue.matchCase, whereValue.matchValue, '');
                if (conditionQuery) {
                    innerConditions.push(`${conditionQuery}`);
                }
            }
            if (innerConditions.length) {
                query += ` AND ${innerConditions.join(' AND ')}`;
            }
        }

        let filterWhere = await CommonUtil.applyFilterToAccounts(
            req.body?.filters,
            ''
        );

        if (filterWhere) {
            if (req.body?.selectedFilter) {
                let condition = "";
                const fieldNames = await CommonUtil.getFieldNameFromFilter(req.body.filters);
                if (fieldNames.length) {
                    for (let fieldName of fieldNames) {
                        const tableIdentifier = await CommonUtil.getAliasOrTableForField(query, fieldName);
                        if (tableIdentifier) {
                            const filters = filterWhere.split(' AND ');
                            for (let filter of filters) {
                                if (filter.includes(fieldName)) {
                                    if (condition) {
                                        condition += ' AND ';
                                    }
                                    condition += `${tableIdentifier}.${filter.trim()}`;
                                }
                            }
                        }
                    }
                    query = query.replace(/WHERE\s+/g, `WHERE ${condition} AND `);
                }
            } else {
                query += ' AND ' + filterWhere;
            }
        }

        let limit = req.body.length ? req.body.length : 10;
        let start = req.body.start ? req.body.start : 0;
        let sortField = req.body.sortField ? req.body.sortField : "";
        let sortOrder: 'DESC' | 'ASC' = req.body.sortOrder ? req.body.sortOrder : 'DESC';
        let orderBy = "";
        let offsetLimit = "";
        if (sortField !== "") {
            if (query.includes('ORDER BY')) {
                let lastOrderByIndex = query.lastIndexOf('ORDER BY');
                if (lastOrderByIndex !== -1) {
                    query = query.substring(0, lastOrderByIndex);
                }
            }
            
            orderBy = ` ORDER BY ${this.addtick(sortField)} ${sortOrder}`;
        }
        offsetLimit = ` LIMIT ${start},${limit}`;
        let mysqlQuery = `SELECT t.*,(SELECT COUNT(*) FROM (${query}) AS subquery) AS recordsTotal FROM (${query + orderBy + (req.body.allData ? '' : offsetLimit)})t;`
        console.log('mysqlQuery', mysqlQuery);
        const mysqlData: any = await MySQLExecutorUtil.executeMYSQLQuery(mysqlQuery, accountConfigDetails);
        if (mysqlData.status) {
            return this.chartDataFormatter(mysqlData, responseObj, mysqlQuery);
        } else {
            return mysqlData
        }
    }

    static async prepareMYSQLQueryAndExecute(accountConfigDetails, widgetConfig, req) {
        const responseObj: any = { status: true, data: [], error: null };
        responseObj.cacheWidget = widgetConfig.cacheWidget;
        responseObj.isManualQuery = widgetConfig.isManualQuery;
        responseObj.sourceType = widgetConfig.sourceType;
        responseObj.displayType = widgetConfig.chartType;
        responseObj.formField = widgetConfig.formField;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        responseObj.properties = widgetConfig.properties || {};
        let mysqlQuery = "";
        if (widgetConfig.isManualQuery && widgetConfig.query) {
            if (widgetConfig.chartType === 'TABLE') {
                mysqlQuery = await this.mysqlManualQueryForTable(widgetConfig, req);
            } else {
                mysqlQuery = widgetConfig.query;
            }
        } else {
            mysqlQuery = await this.customMYSQLQuery(widgetConfig, req);
        }
        const mysqlData: any = await MySQLExecutorUtil.executeMYSQLQuery(mysqlQuery, accountConfigDetails);
        if (mysqlData.status) {
            return this.chartDataFormatter(mysqlData, responseObj, mysqlQuery);
        } else {
            return mysqlData
        }
    }

    static async prepareSalesforceQueryAndExecute(accountConfigDetails, widgetConfig, req) {
        const responseObj: any = { status: true, data: [], error: null };
        responseObj.cacheWidget = widgetConfig.cacheWidget;
        responseObj.isManualQuery = widgetConfig.isManualQuery;
        responseObj.sourceType = widgetConfig.sourceType;
        responseObj.displayType = widgetConfig.chartType;
        responseObj.formField = widgetConfig.formField;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        responseObj.properties = widgetConfig.properties || {};
        let salesforceQuery = "";
        if (widgetConfig.isManualQuery && widgetConfig.query) {
            salesforceQuery = widgetConfig.query;
        } else {
            salesforceQuery = await this.customMYSQLQuery(widgetConfig, req,true);
        }
        // Initialize jsforce.Connection object with the access token
        const conn = new jsforce.Connection({
            accessToken: accountConfigDetails.token.access_token,
            instanceUrl: accountConfigDetails.token.instance_url // Replace with your Salesforce instance URL
        });
        const result = await conn.query(salesforceQuery);
        if (result?.records) {
            const updatedResults = result?.records.map(uResult => ({
                ...uResult,  // Spread the existing properties of the object
                recordsTotal: 100,  // Add the new field with the value 1000
            }));
            const keysArray = Object.keys(updatedResults[0])
                .filter(key => key !== 'attributes').map(key => ({ name: key }));
            let response={
                data:updatedResults,
                fields:keysArray,
            }
            return this.chartDataFormatter(response, responseObj, salesforceQuery);
        } else {
            return result?.records
        }
    }

    static async prepareMYSQLUpdateDeleteQueryAndExecute(accountConfigDetails, widgetConfig, req) {
        const responseObj: any = { status: true, data: [], error: null };
        responseObj.cacheWidget = widgetConfig.cacheWidget;
        responseObj.isManualQuery = widgetConfig.isManualQuery;
        responseObj.sourceType = widgetConfig.sourceType;
        responseObj.displayType = widgetConfig.chartType;
        responseObj.formField = widgetConfig.formField;
        responseObj.config = widgetConfig.config ? widgetConfig.config : {};
        responseObj.properties = widgetConfig.properties || {};
        let mysqlQuery = "";
        if (widgetConfig.isManualQuery && widgetConfig.query) {
            mysqlQuery = widgetConfig.query;
        } else {
            mysqlQuery = this.customMYSQLUpdateQuery(widgetConfig, req);

        }
        const mysqlData: any = await MySQLExecutorUtil.executeMYSQLQuery(mysqlQuery, accountConfigDetails);
        if (mysqlData.status) {
            return responseObj;
        } else {
            return mysqlData
        }
    }

    static chartDataFormatter(mysqlData, responseObj, mysqlQuery) {
        const queryFields = mysqlData.fields.map(obj => obj.name);
        responseObj.xAxis = queryFields[0];
        queryFields.splice(0, 1);

        if (responseObj?.isManualQuery) {
            responseObj.yAxis = queryFields.filter(field => !['recordsTotal'].includes(field));
        } else {
            responseObj.yAxis = queryFields;
        }
        responseObj.data = mysqlData.data;
        responseObj.query = mysqlQuery;
        return responseObj;
    }

    static async customMYSQLQuery(widgetConfig, req, isSalesforce?,isPublicView360?) {
        let query = "";
        let whereCondition = "";
        let forUpdateQueryTotal = "";
        let orderBy="";
        let offsetLimit="";
        if (!Array.isArray(widgetConfig.yAxis)) {
            widgetConfig.yAxis = [widgetConfig.yAxis];
        }
        let selectFields = [];
        if(isSalesforce){
            selectFields.push(widgetConfig.xAxis);
        }else{
            selectFields.push(this.addtick(widgetConfig.xAxis));
        }

        for (const yField of widgetConfig.yAxis) {
            if (widgetConfig.operationType === 'SUM') {
                const selectField = isSalesforce ? `SUM(${yField}) ${yField}` : `SUM(${this.addtick(yField)}) as ${this.addtick(yField)}`;
                selectFields.push(selectField);
            } else if (widgetConfig.operationType === 'COUNT') {
                const selectField = isSalesforce ? `COUNT(${yField}) ${yField}` : `COUNT(${this.addtick(yField)}) as ${this.addtick(yField)}`;
                selectFields.push(selectField);
            } else if (widgetConfig.operationType === 'AVG') {
                const selectField = isSalesforce ? `AVG(${yField}) ${yField}` : `AVG(${this.addtick(yField)}) as ${this.addtick(yField)}`;
                selectFields.push(selectField);
            } else if (widgetConfig.operationType === 'MIN') {
                const selectField = isSalesforce ? `MIN(${yField}) ${yField}` : `MIN(${this.addtick(yField)}) as ${this.addtick(yField)}`;
                selectFields.push(selectField);
            } else if (widgetConfig.operationType === 'MAX') {
                const selectField = isSalesforce ? `MAX(${yField}) ${yField}` : `MAX(${this.addtick(yField)}) as ${this.addtick(yField)}`;
                selectFields.push(selectField);
            } else if (widgetConfig.operationType === 'DISTINCT') {
                const selectField = isSalesforce ? `DISTINCT(${yField}) ${yField}` : `DISTINCT(${this.addtick(yField)}) as ${this.addtick(yField)}`;
                selectFields.push(selectField);
            } else {
                let selectField;
                if(widgetConfig.chartType === 'TABLE') {
                    selectField = isSalesforce ? `${yField}` : `${this.addtick(yField.key)}`;
                } else {
                    selectField = isSalesforce ? `${yField}` : `${this.addtick(yField)}`;
                }
                selectFields.push(selectField);
            }
        }
        if (widgetConfig.chartType === 'TABLE') {
            selectFields = [...new Set(selectFields)];
        }
        // Check if CREATED_BY exists in selectFields
        if (selectFields.includes('`CREATED_BY`') && isPublicView360) {
            selectFields = selectFields.filter(field => field !== '`CREATED_BY`');
            // Add 'users.firstname', 'users.lastname' with alias 'CREATED_BY' to selectFields
            selectFields.push('CONCAT(users.`FIRST_NAME`, " ", users.`LAST_NAME`) AS CREATED_BY');
        }
        let whereFields = '';
        if (widgetConfig.chartType === 'TABLE' && Array.isArray(widgetConfig.whereFields) && widgetConfig.whereFields.length > 0 && widgetConfig.whereFields[0].columnName) {
            let innerConditions = [];
            for (const whereValue of widgetConfig.whereFields) {
                let conditionQuery = await CommonUtil.getConditionalQuery(whereValue.columnName, whereValue.matchCase, whereValue.matchValue, '');
                if (conditionQuery) {
                    innerConditions.push(`${conditionQuery}`);
                }
            }
            if (innerConditions.length) {
                whereFields += ` ${innerConditions.join(' AND ')}`;
            }
        }
        if (widgetConfig.operationType === 'DEFAULT') {
            if (req.body?.fromWidget === 'WIDGET_FILTER') {
                if (isSalesforce) {
                    whereCondition = `WHERE ${req.body.columnName}  =  '${req.body.selectedFilter.replace(/^\s+|\s+$/g, '')}'`;
                    /**
                     * Old code
                     * (whereFields.length) ? whereCondition += ` AND ${whereFields}` : whereCondition;
                     */
                    if (whereFields.length) { 
                        whereCondition += ` AND ${whereFields}`;
                    }
                    query = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.form}` + whereCondition;
                } else {
                    if (req.body?.filterBySqlQuery) {
                        query = req.body.selectedFilter;
                    } else {
                        whereCondition = `WHERE ${this.addtick(req.body.columnName)}  =  '${req.body.selectedFilter.replace(/^\s+|\s+$/g, '')}'`;
                        query = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)}` + whereCondition;
                    }
                }
            } else if (req.body?.fromWidget === 'SEARCH_WIDGET' && req.body.searchInput.searchText.length) {
                whereCondition = ` WHERE MATCH(${req.body.searchInput.filterColumn.toString()}) AGAINST ('${req.body.searchInput.searchText}' IN NATURAL LANGUAGE MODE)`;
                query = (isSalesforce) ? `SELECT ${selectFields.join(',')} FROM ${widgetConfig.form}` + whereCondition
                    : `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)}` + whereCondition;
            } else {
                if (isSalesforce) {
                    /**
                     * Old Code
                     * (whereFields.length) ? ((whereCondition != '') ? whereCondition += ` AND ${whereFields}` : whereCondition += ` WHERE ${whereFields}`) : whereCondition;
                     */
                    if (whereFields.length) { 
                        if (whereCondition != '') {
                            whereCondition += ` AND ${whereFields}`
                        }  else {
                            whereCondition += ` WHERE ${whereFields}`;
                        }
                    }

                    query = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.form} ` + whereCondition;
                } else {
                    let OrderBy = '';
                    if (widgetConfig?.properties?.orderField && widgetConfig?.properties?.orderByField) {
                        OrderBy = ' ORDER BY ' + widgetConfig.properties.orderField + ' ' + widgetConfig.properties.orderByField
                    }
                    if (whereFields) {
                        let filterWhere = '';
                        filterWhere = await CommonUtil.applyFilterToAccounts(
                            req.body?.filters,
                            filterWhere
                        );
                        const filterWithANDCondition = await this.addAndBeforeString(filterWhere);
                        whereFields += filterWithANDCondition;
                        forUpdateQueryTotal = whereFields;
                        query = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)} WHERE ${whereFields}  ${OrderBy}`;
                    } else {
                        let filterWhere = '';
                        filterWhere = await CommonUtil.applyFilterToAccounts(
                            req.body?.filters,
                            filterWhere
                        );
                        const filterWithWHERECondition = await this.addWhereBeforeString(filterWhere);
                        forUpdateQueryTotal = filterWithWHERECondition;
                        query = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)} ${filterWithWHERECondition} ${OrderBy}`;
                    }
                }
            }

        } else {
            if (req.body?.fromWidget === 'WIDGET_FILTER') {
                if(isSalesforce){
                    whereCondition=`WHERE ${req.body.columnName}  =  '${req.body.selectedFilter.replace(/^\s+|\s+$/g, '')}'`;
                    query = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.form} `+whereCondition+`  GROUP BY ${widgetConfig.xAxis}`;
                }else{
                    whereCondition=`WHERE ${this.addtick(req.body.columnName)}  =  '${req.body.selectedFilter.replace(/^\s+|\s+$/g, '')}'`;
                    query = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)} `+whereCondition+`  GROUP BY ${this.addtick(widgetConfig.xAxis)}`;
                }
            } else  {
                if(isSalesforce){
                    if(whereFields.length){
                        query = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.form} WHERE ${whereFields} GROUP BY ${widgetConfig.xAxis}`;
                    }else{//whereCondition+=` AND ${whereFields}`:whereCondition;
                        query = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.form} GROUP BY ${widgetConfig.xAxis}`;
                    }
                }else{
                    if(isPublicView360){
                        // Check if CREATED_BY exists in selectFields
                        const hasCreatedByAlias = selectFields.some(field => field.endsWith(' AS CREATED_BY'));
                        let stmt ='';
                        if (hasCreatedByAlias) {
                            stmt += ` LEFT JOIN users ON ${this.addtick(widgetConfig.form)}.CREATED_BY = users.id`;
                        }
                        query = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)} ${stmt} GROUP BY ${this.addtick(widgetConfig.xAxis)}`;
                    }else{
                        query = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)} GROUP BY ${this.addtick(widgetConfig.xAxis)}`;
                    }

                }
            }
        }

        if (req.query.qs) {
            const queryString = JSON.parse(atob(req.query.qs));
            /**
             * switch (true) {
                case queryString.globalFilter.dateRange.length > 0:
                    whereCondition=`WHERE ${widgetConfig.filter.dateColumn} BETWEEN '${queryString.globalFilter.dateRange[0]}' AND '${queryString.globalFilter.dateRange[1]}'`;
                    query = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)} ` + whereCondition;
                    break;
                }
             */

            if (queryString.globalFilter.dateRange.length > 0) {
                whereCondition=`WHERE ${widgetConfig.filter.dateColumn} BETWEEN '${queryString.globalFilter.dateRange[0]}' AND '${queryString.globalFilter.dateRange[1]}'`;
                    query = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)} ` + whereCondition;
            }
        }

        if (widgetConfig.chartType === 'TABLE') {
            let limit = req.body.length ? req.body.length : 10;
            let start = req.body.start ? req.body.start : 0;
            let sortField = req.body.sortField ? req.body.sortField : "";
            let sortOrder: 'DESC' | 'ASC' = req.body.sortOrder ? req.body.sortOrder : 'DESC';
            if (sortField !== "") {
                orderBy = (isSalesforce)?` ORDER BY ${sortField} ${sortOrder}`:` ORDER BY ${this.addtick(sortField)} ${sortOrder}`;
            }
            offsetLimit = ` LIMIT ${start},${limit}`;
            let tableWhereCondition = '';
            if(whereFields) {
                tableWhereCondition = await this.addWhereBeforeString(forUpdateQueryTotal);
            } else {
                tableWhereCondition = forUpdateQueryTotal;
            }

            let updateQueryForTotalRecordCounts = `SELECT t.*,(SELECT COUNT(*) FROM ${this.addtick(widgetConfig.form)} `+tableWhereCondition+`) AS recordsTotal FROM (${query + orderBy + offsetLimit})t`;
            if(isSalesforce){
                offsetLimit = ` LIMIT ${limit} OFFSET ${start}`;
                updateQueryForTotalRecordCounts = `${query + orderBy + offsetLimit}`
            }
            return updateQueryForTotalRecordCounts;
        } else {
            return query;
        }
    }
    static customMYSQLUpdateQuery(widgetConfig, req) {
        let query = "";
        let actionData = req.body.actionData;
        if (req.body.actionData.additionalColumn !== undefined && req.body.actionData.additionalColumn !== null && req.body.actionData.additionalColumn !== '') {
            query = `UPDATE ${this.addtick(widgetConfig.form)} SET ${this.addtick(actionData.columnName)} = '${actionData.selectedValue}', ${this.addtick(actionData.additionalColumn)} = '${req.body.data[actionData.additionalColumn]}' WHERE ${this.addtick(req.body.submissionId)} = '${req.body.data[req.body.submissionId]}'`;
        } else {
            query = `UPDATE ${this.addtick(widgetConfig.form)} SET ${this.addtick(actionData.columnName)} = '${actionData.selectedValue}' WHERE ${this.addtick(req.body.submissionId)} = '${req.body.data[req.body.submissionId]}'`;
        }
        if (widgetConfig.form == 'dms-files') {
            const dmsFileLog = new DMSFilesLogs();
            dmsFileLog.CLIENT_ID = req.userDetails.client_id;
            dmsFileLog.FILE_NAME = req.body.data.FILE_NAME;
            dmsFileLog.FILE_PATH = req.body.data.FILE_PATH;
            dmsFileLog.ACTION = req.body.data.ACTION;
            dmsFileLog.ACTION_DATE = req.body.data.ACTION_DATE;
            dmsFileLog.CREATED_ON = new Date();

            Container.get(DataSource).manager.save(dmsFileLog);
        }
        return query;
    }

    static async executeCustomTable(req, widgetConfig) {
        const responseObj: any = { status: true, data: [], error: null };
        responseObj.cacheWidget = widgetConfig.cacheWidget;
        responseObj.isManualQuery = widgetConfig.isManualQuery;
        responseObj.sourceType = widgetConfig.sourceType;
        responseObj.displayType = widgetConfig.chartType;
        responseObj.formField = widgetConfig.formField;
        responseObj.config = widgetConfig.config || {};
        responseObj.properties = widgetConfig.properties;

        if (!Array.isArray(widgetConfig.yAxis)) {
            widgetConfig.yAxis = [widgetConfig.yAxis];
        }
        const selectFields = [];
        selectFields.push(`DISTINCT ${widgetConfig.xAxis}`);
        for (const yField of widgetConfig.yAxis) {
            switch (widgetConfig.operationType) {
                case 'SUM':
                    selectFields.push(`SUM(${yField}) ${yField}`);
                    break;
                case 'COUNT':
                    selectFields.push(`COUNT(${yField}) ${yField}`);
                    break;
                default:
                    selectFields.push(`${yField}`);
                    break;
            }
        }
        let stmt = this.prepareCustomTableQuery(selectFields, widgetConfig, req);

        let results: any = await Container.get(DataSource).manager.query(stmt); // await db_procedure.v_select(stmt);
        if (results?.errorNum) {
            responseObj.displayType = "error";
            responseObj.message = `Error: ${results.message}`;
            responseObj.data = [];
        } else if (results?.length > 0) {
            responseObj.xAxis = widgetConfig.xAxis;
            responseObj.yAxis = widgetConfig.yAxis;
            responseObj.data = results;
            responseObj.status = true;
        }
        return responseObj;
    }

    static async executePublicView360Table(req, widgetConfig) {
        const responseObj: any = { status: true, data: [], error: null };
        responseObj.cacheWidget = widgetConfig.cacheWidget;
        responseObj.isManualQuery = widgetConfig.isManualQuery;
        responseObj.sourceType = widgetConfig.sourceType;
        responseObj.displayType = widgetConfig.chartType;
        responseObj.formField = widgetConfig.formField;
        responseObj.config = widgetConfig.config || {};
        responseObj.properties = widgetConfig.properties;
        let stmt = await this.generateStmlQuery(req, widgetConfig);
        
        console.log('stmt', stmt);
        let results: any = await Container.get(DataSource).manager.query(stmt); // await db_procedure.v_select(stmt);
        if (results?.errorNum) {
            responseObj.displayType = "error";
            responseObj.message = `Error: ${results.message}`;
            responseObj.data = [];
        } else if (results?.length > 0) {
            let updatedResult = results.map((d) => {
                let istDateTime = moment.tz(d.CREATED_ON, 'Asia/Kolkata');
                d.CREATED_ON =istDateTime.format('MMMM D, YYYY, h:mm:ss A');
                switch (d.MODEL_TYPE) {
                    case "image-to-excel":
                        d.MODEL_TYPE = "Image to Excel";
                        break;
                    case "pdf-to-excel":
                            d.MODEL_TYPE = "PDF to Excel";
                        break;
                    case "text-from-pdf":
                        d.MODEL_TYPE = "PDF to word";
                        break;
                    case "pdf-to-word":
                        d.MODEL_TYPE = "PDF to Word";
                        break;
                    case "image-to-word":
                        d.MODEL_TYPE = "Image to Word";
                        break;
                    default:
                        d.modelTypeFormatted = d.modelType;
                }
                return d;
            });
            responseObj.xAxis = widgetConfig.xAxis;
            responseObj.yAxis = widgetConfig.yAxis;
            responseObj.data = updatedResult;
            responseObj.query = stmt;
            responseObj.status = true;
        }
        return responseObj;
    }

    private static async generateStmlQuery(req, widgetConfig) {
        let stmt;
        if(req.body.filterBySqlQuery) {
            stmt = req.body.selectedFilter;
        } else {
            if (!Array.isArray(widgetConfig.yAxis)) {
                widgetConfig.yAxis = [widgetConfig.yAxis];
            }
            console.log('widgetConfig--->', widgetConfig);
            const selectFields = [];
            selectFields.push(`DISTINCT ${widgetConfig.xAxis}`);
            for (const yFieldObj of widgetConfig.yAxis) {
                let yField = yFieldObj;
                if (typeof yFieldObj?.key === 'string') {
                    yField = `${yFieldObj.key}`;
                }
                switch (widgetConfig.operationType) {
                    case 'SUM':
                        selectFields.push(`SUM(${yField}) ${yField}`);
                        break;
                    case 'COUNT':
                        selectFields.push(`COUNT(${yField}) as ${yField}`);
                        break;
                    default:
                        selectFields.push(`${yField}`);
                        break;
                }
            }
            
            widgetConfig.customTableName = widgetConfig.form;
            stmt = await this.preparePublicView360TableQuery(selectFields, widgetConfig, req);
        }

        return stmt;
    }

    private static async createWhereCondition(filter) {
        const whereConditions = [];
        // Iterate over the properties of the filter object
        for (const key in filter) {
            if (filter.hasOwnProperty(key)) {
                const operator = filter[key]; // Get the operator object
                // Extract necessary properties from the operator object
                const type = operator._type;
                const value = operator._value;
                // Construct the where condition based on the operator type
                if (type === 'ilike') {
                    whereConditions.push(`\`${key}\` LIKE '${value}'`);
                }else if (type === 'notLike') {
                    whereConditions.push(`\`${key}\` NOT LIKE '${value}'`);
                } else if (type === 'equals') {
                    whereConditions.push(`\`${key}\` = '${value}'`);
                } else if (type === 'lessThan') {
                    whereConditions.push(`\`${key}\` < '${value}'`);
                } else if (type === 'moreThan') {
                    whereConditions.push(`\`${key}\` > '${value}'`);
                } else {
                    // Handle other operator types if needed
                }
            }
        }
        // Join all where conditions with 'AND' operator
        return whereConditions.length > 0 ?  whereConditions.join(' AND ') : '';
    }
    private static async preparePublicView360TableQuery(selectFields: any[], widgetConfig, req) {
        const objShallowCopySelectFields = [...selectFields];
        selectFields = objShallowCopySelectFields.filter(field => !field.includes('~'));
        let orderBy="";
        let sortField = req.body.sortField ? req.body.sortField : "";
        let sortOrder: 'DESC' | 'ASC' = req.body.sortOrder ? req.body.sortOrder : 'DESC';
        if (sortField !== "") {
            orderBy = ` ORDER BY ${this.addtick(sortField)} ${sortOrder}`;
        }

        if(req.body.fromButtonQuery) {
            let limit = req.body.length ? req.body.length : 10;
        let start = req.body.start ? req.body.start : 0;
        let offsetLimit = ` LIMIT ${start},${limit}`;
            let filterWhere = {};
            filterWhere = await CommonUtil.applyFilter(
                req.body.filters,
                filterWhere
            );
            let whereClause = '';
            if (filterWhere && Object.keys(filterWhere).length > 0) {
                whereClause = ` AND `+ await this.createWhereCondition(filterWhere);
            }
            return `SELECT t.*,(SELECT COUNT(*) FROM (${req.body.fromButtonQuery.trim() + whereClause })a` +`) AS recordsTotal FROM  (${req.body.fromButtonQuery + whereClause + orderBy + offsetLimit} )t`;
        }

        for (let field of objShallowCopySelectFields) {
            if (field.includes('~')) {
                let [config, jsonKey] = field.split('~');
                // Add doc name
                // if (!selectFields.includes(docName)) {
                // selectFields.push(docName);
                // }
                // Add JSON key with proper formatting
                let jsonKeyFetchValue = `REPLACE(JSON_EXTRACT(${config}, '$."${jsonKey}"'), '"', '')AS \`${jsonKey}\``;

                if (!selectFields.includes(jsonKeyFetchValue)) {
                    selectFields.push(jsonKeyFetchValue);
                }
            }
        }
        let onBarClickUserValuesForCount = '';
        let onBarClickUserValuesQuery = '';
// Check if CREATED_BY exists in selectFields
if (selectFields.includes('CREATED_BY')) {
    selectFields = selectFields.filter(field => field !== 'CREATED_BY');
    // Add 'users.firstname', 'users.lastname' with alias 'CREATED_BY' to selectFields
    selectFields.push('CONCAT(users.`FIRST_NAME`, " ", users.`LAST_NAME`) AS CREATED_BY');
    if(req.body.fromBarChartClickData && req.body.fromBarChartClickData.barChartClick && req.body.chartType === 'TABLE'){
        const name = req.body.fromBarChartClickData.name.split(' ');
        const FName = name[0];
        const LName = name[1];
        let whereCondition = {};
        if(FName && LName) {
            whereCondition = {firstName: FName, lastName: LName};
        } else {
            whereCondition = {firstName: FName};
        }
        let results: any = await Container.get(DataSource)
            .getRepository(Users)
            .findOne({
                where: whereCondition,
            });
        if(results) {
            onBarClickUserValuesForCount = ` AND CREATED_BY = '${results.id}'`;
            onBarClickUserValuesQuery = ` AND ocr_reader.CREATED_BY = '${results.id}'`;
        }
    }
}
selectFields = selectFields.filter((item, index) => {
    if (item === "id" && selectFields.indexOf("DISTINCT id") !== -1) {
      return false;
    }
    return true;
  });
        let selectClause = selectFields.some(field => field.startsWith('DISTINCT')) ? 'DISTINCT ' : '';
        let stmt = `SELECT ${selectClause}${selectFields.map(field => {
    if (field.startsWith('DISTINCT')) {
        let column = field.substring('DISTINCT'.length).trim();
        if(column === 'id'){
            return widgetConfig.customTableName + '.`id`';
        }
        return '`'+column+'`';
    }
    // else if(field == 'id'){
    //     return `${widgetConfig.customTableName}.\`id\``;
    // }
    if (field.startsWith('CONCAT')) {
        return field;
    }
    return '`'+field+'`';
}).join(',')} FROM \`${widgetConfig.customTableName}\``;

// Check if CREATED_BY exists in selectFields
        const hasCreatedByAlias = selectFields.some(field => field.endsWith(' AS CREATED_BY'));

        if (hasCreatedByAlias) {
            stmt += ` LEFT JOIN users ON ${widgetConfig.customTableName}.CREATED_BY = users.id`;
        }

        let offSetLimit="";
        let countWhere = " WHERE 1 = 1 "
        stmt += ` WHERE 1 = 1`;
        let filterWhere = {};
        filterWhere = await CommonUtil.applyFilter(
            req.body.filters,
            filterWhere
        );
        if (filterWhere && Object.keys(filterWhere).length > 0) {
            stmt += ` AND `+ await this.createWhereCondition(filterWhere);
            countWhere += ` AND `+ await this.createWhereCondition(filterWhere);
        }
        const result = await Container.get(DataSource).getRepository(PublicTables).createQueryBuilder('DW').where('DW.name = :name', { name: widgetConfig.customTableName }).getOne();
        if (result?.id && result?.isClientCheck) {
            stmt += ` AND \`${widgetConfig.customTableName}\`.\`client_id\` = '${req?.userDetails?.client_id}'` + onBarClickUserValuesQuery;
            countWhere += ` AND \`${widgetConfig.customTableName}\`.\`client_id\` = '${req?.userDetails?.client_id}'` + onBarClickUserValuesForCount;
        }

        if (widgetConfig.chartType === 'TABLE' && Array.isArray(widgetConfig.whereFields) && widgetConfig.whereFields.length > 0) {
            let innerConditions = [];
            for (const whereValue of widgetConfig.whereFields) {
                if (whereValue?.columnName && whereValue?.matchCase) {
                    let conditionQuery = await CommonUtil.getConditionalQuery(whereValue.columnName, whereValue.matchCase, whereValue.matchValue, '');
                    if (conditionQuery) {
                        innerConditions.push(`${conditionQuery}`);
                    }
                }
            }
            if (innerConditions.length) {
                innerConditions=innerConditions.map(field => {
                    if (field.startsWith('IS_DELETED')) {
                        return `${widgetConfig.customTableName}.${field}`;
                    }
                    return field;
                });
                countWhere += ` AND ${innerConditions.join(' AND ')}`;
                stmt += ` AND ${innerConditions.join(' AND ')}`;
            }
        }
        stmt = this.appliedFilter(widgetConfig, req, stmt);
        let uLimit = req.body.length ? req.body.length : 10;
        let uStart = req.body.start ? req.body.start : 0;
        offSetLimit = ` LIMIT ${uStart},${uLimit}`;
        return `SELECT t.*,(SELECT COUNT(*) FROM ${this.addtick(widgetConfig.customTableName)} ${countWhere}` +`) AS recordsTotal FROM  (${stmt + orderBy + offSetLimit} )t`;
    }

    private static prepareCustomTableQuery(selectFields: any[], widgetConfig, req) {
        let stmt = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.customTableName.toUpperCase()}`;
        stmt += ` WHERE 1 = 1`;
        if (widgetConfig.chartType === 'TABLE' && Array.isArray(widgetConfig.whereFields) && widgetConfig.whereFields.length > 0) {
            let innerConditions = [];
            for (const whereValue of widgetConfig.whereFields) {
                let conditionQuery = CommonUtil.getConditionalQuery(whereValue.columnName, whereValue.matchCase, whereValue.matchValue, 'normal');
                if (conditionQuery) {
                    innerConditions.push(`${conditionQuery}`);
                }
            }
            if (innerConditions.length) {
                stmt += ` AND ${innerConditions.join(' AND ')}`;
            }
        }
        stmt = this.appliedFilter(widgetConfig, req, stmt);
        return stmt;
    }

    private static appliedFilter(widgetConfig, req, stmt: string) {
        if (widgetConfig.properties && widgetConfig.properties.enableTodayDateFilter && widgetConfig.properties.todayDateFilterOn) {
            let startDate = moment().startOf('day').format('MM-DD-YYYY HH:mm:ss');
            let endDate = moment().endOf('day').format('MM-DD-YYYY HH:mm:ss');
            if (req.body.filterDate) {
                startDate = moment(req.body.filterDate).startOf('day').format('MM-DD-YYYY HH:mm:ss');
                endDate = moment(req.body.filterDate).endOf('day').format('MM-DD-YYYY HH:mm:ss');
            }
            stmt += ` AND ${widgetConfig.properties.todayDateFilterOn} >= TO_DATE('${startDate}', 'MM-DD-YYYY HH24:MI:SS')`;
            stmt += ` AND ${widgetConfig.properties.todayDateFilterOn} <= TO_DATE('${endDate}', 'MM-DD-YYYY HH24:MI:SS')`;
        }
        if (widgetConfig.operationType === 'SUM' || widgetConfig.operationType === 'COUNT') {
            stmt += ` GROUP BY ${widgetConfig.xAxis}`;
        }
        if (widgetConfig.properties && widgetConfig.properties.orderField) {
            let sortField = req.body.sortField ? req.body.sortField : "";
            if(!sortField) {
                stmt += ` ORDER BY ${widgetConfig.properties.orderField} ${widgetConfig.properties.orderByField}`;
            }
        }
        return stmt;
    }

    static async executeForms(req, widgetConfig) {
        const response: any = { status: true, data: [], error: null };
        let isPivotForTextBasedColumn=false;
        ChartExecutionUtil.is_superadmin = req.userDetails.is_superadmin === 1;

        let selectFields = widgetConfig.chartType === 'TABLE' ? ['id', 'FORM_ID', 'SUBMITTED_DATA'] : [];

        const whereClause = { FORM_ID: widgetConfig.form };
        if (widgetConfig.properties?.enableUserFilter && req.body?.userId) {
            whereClause["CREATED_BY"] = req.body?.userId;
        }

        let whereFieldsData;
        if(widgetConfig?.whereFields && widgetConfig?.whereFields.length>0){
            whereFieldsData ={
                whereFields:widgetConfig.whereFields,
                role_id:req.userDetails.role_id,
                is_superadmin:ChartExecutionUtil.is_superadmin
            }
        }
        let defaultOrderBy = '';
        if(widgetConfig?.properties?.orderField && widgetConfig?.properties?.orderByField) {
            defaultOrderBy = 'ORDER BY ' + widgetConfig.properties.orderField + ' ' + widgetConfig.properties.orderByField;
        } else if(req.body?.sortField && req.body?.sortOrder) {
            let sortField = 'Json' + req.body.sortField;
            defaultOrderBy = 'ORDER BY ' + sortField + ' ' + req.body.sortOrder;
            selectFields.push("JSON_EXTRACT(SUBMITTED_DATA, '$."+req.body.sortField+"') AS "+sortField);
        } else if (widgetConfig.operationType) {
            selectFields.push(("JSON_EXTRACT(SUBMITTED_DATA, '$."+widgetConfig.xAxis+"') AS "+widgetConfig.xAxis));
            if (widgetConfig.chartType !== 'PIE') {
                for (const yField of widgetConfig.yAxis) {
                    ChartExecutionUtil.handleOperationType(widgetConfig, selectFields, yField);
                }
                if(widgetConfig.chartType === 'TABLE') {
                    defaultOrderBy = 'ORDER BY CREATED_ON DESC';
                }else{
                defaultOrderBy = `GROUP BY JSON_EXTRACT(SUBMITTED_DATA, '$.${widgetConfig.xAxis}')`;
                if(widgetConfig.yAxisIsTextBased){
                    isPivotForTextBasedColumn = true;
                    defaultOrderBy = defaultOrderBy + `, JSON_EXTRACT(SUBMITTED_DATA, '$.${widgetConfig.yAxis[0].key}')`;
                }
                }
                if(widgetConfig.yAxisIsTextBased){
                    selectFields.push("JSON_EXTRACT(SUBMITTED_DATA, '$."+widgetConfig.yAxis[0].key+"') AS "+widgetConfig.yAxis[0].key);
                }
            } else {
                if(widgetConfig.yAxisIsTextBased){
                selectFields = [];
                selectFields.push("JSON_EXTRACT(SUBMITTED_DATA, '$."+widgetConfig.yAxis.key+"') AS "+widgetConfig.yAxis.key);
                selectFields.push(`COUNT(JSON_EXTRACT(SUBMITTED_DATA, '$.${widgetConfig.yAxis.key}')) as 'count'`);
                defaultOrderBy = `GROUP BY JSON_EXTRACT(SUBMITTED_DATA, '$.${widgetConfig.yAxis.key}')`;
                }else{
                selectFields = [];
                selectFields.push("JSON_EXTRACT(SUBMITTED_DATA, '$."+widgetConfig.xAxis+"') AS "+widgetConfig.xAxis);
                ChartExecutionUtil.handleOperationType(widgetConfig, selectFields, widgetConfig.yAxis);
                if (widgetConfig.operationType != 'DEFAULT') {
                    defaultOrderBy = `GROUP BY JSON_EXTRACT(SUBMITTED_DATA, '$.${widgetConfig.xAxis}')`;
                }else{
                    defaultOrderBy=``;
                }
                }
            }
        } else{
            defaultOrderBy = 'ORDER BY CREATED_ON DESC';
        }
        let field = '';
        let order;
        if(req.body?.sortField && req.body?.sortOrder) {
            field = req.body?.sortField;
            order = req.body?.sortOrder;
        }
        const filters = req?.body?.filters;
        let limit = req.body.length?req.body.length:10;
        let start = req.body.start?req.body.start:0;
        const tableName = `form_builder_${req.userDetails.client_id}`;
        const formBuilderRes: any = await FormBuilderExecutionUtil.executeFormBuilderQuery(tableName, selectFields, whereClause,{limit: limit, start: start}, field, order,filters, defaultOrderBy,whereFieldsData,isPivotForTextBasedColumn);
        const recordsTotal: any = await FormBuilderExecutionUtil.executeFormBuilderQuery(tableName,'count(1) as COUNT', whereClause, {start: '', limit: ''}, '', '', filters, '',null,false);
        const updatedRecords = formBuilderRes.data.map((item) => ({...item,
            recordsTotal: recordsTotal.data[0].COUNT,
        }));
        
        return this.executeFormResponse(response, widgetConfig, updatedRecords, formBuilderRes);
    }

    private static handleOperationType(widgetConfig: any, selectFields: any[], yField: any) {
        if (widgetConfig.operationType === 'SUM') {
            selectFields.push(`SUM(JSON_EXTRACT(SUBMITTED_DATA, '$.${yField.key}')) as '${yField.key}'`);
        } else if (widgetConfig.operationType === 'COUNT') {
            selectFields.push(`COUNT(JSON_EXTRACT(SUBMITTED_DATA, '$.${yField.key}')) as '${yField.key}'`);
        } else if (widgetConfig.operationType === 'AVG') {
            selectFields.push(`AVG(JSON_EXTRACT(SUBMITTED_DATA, '$.${yField.key}')) as '${yField.key}'`);
        } else if (widgetConfig.operationType === 'MIN') {
            selectFields.push(`MIN(JSON_EXTRACT(SUBMITTED_DATA, '$.${yField.key}')) as '${yField.key}'`);
        } else if (widgetConfig.operationType === 'MAX') {
            selectFields.push(`MAX(JSON_EXTRACT(SUBMITTED_DATA, '$.${yField.key}')) as '${yField.key}'`);
        } else if (widgetConfig.operationType === 'DISTINCT') {
            selectFields.push(`DISTINCT(JSON_EXTRACT(SUBMITTED_DATA, '$.${yField.key}')) as '${yField.key}'`);
        } else {
            selectFields.push(`JSON_EXTRACT(SUBMITTED_DATA, '$.${yField.key}') as '${yField.key}'`);
        }
    }

    static executeFormResponse(response, widgetConfig, updatedRecords, formBuilderRes) {
        response.status = true;
        response.cacheWidget = widgetConfig.cacheWidget || false;
        if(widgetConfig.properties){
            widgetConfig.properties.enableCustomStatement = widgetConfig.enableCustomStatement || false;
        }
        
        response.sourceType = widgetConfig.sourceType;
        response.displayType = widgetConfig.chartType;
        response.xAxis = widgetConfig.xAxis;
        response.yAxis = widgetConfig.yAxis;
        if(formBuilderRes.labelList && formBuilderRes.labelList.length>0 && widgetConfig.yAxisIsTextBased){
            widgetConfig.properties["labelList"] = formBuilderRes.labelList;
        }
        response.properties = widgetConfig.properties || {};
        response.query = formBuilderRes.query || '';
        
        if (updatedRecords?.length) {
            response.data = [];
            try {
                for (let f of updatedRecords) {
                    let parsedSubmittedData = JSON.parse(f.SUBMITTED_DATA);
                    parsedSubmittedData.id = f.id;
                    parsedSubmittedData.formId = f.FORM_ID;
                    if(f.recordsTotal){
                        parsedSubmittedData.recordsTotal = f.recordsTotal;
                    }

                    response.data.push(parsedSubmittedData);
                }
            } catch (e) {
                response.data = updatedRecords;
            }
        }

        return response;
    }

    static addtick(e) {
        return "`" + e + "`";
    }

    static async mysqlManualQueryForTable(widgetConfig, req) {
        let configurationQuery = widgetConfig.query;
        if (req.body.selectedFilter) {
            configurationQuery = req.body.selectedFilter;
        }
        let limit = req.body.length ? req.body.length : 10;
        let start = req.body.start ? req.body.start : 0;
        let sortField = req.body.sortField ? req.body.sortField : "";
        let sortOrder: 'DESC' | 'ASC' = req.body.sortOrder ? req.body.sortOrder : 'DESC';
        let orderBy = "";
        let offsetLimit = "";
        if (sortField !== "") {
            orderBy = ` ORDER BY ${this.addtick(sortField)} ${sortOrder}`;
        }
        offsetLimit = ` LIMIT ${start},${limit}`;
        return `SELECT t.*,(SELECT COUNT(*) FROM (${configurationQuery}) AS subquery) AS recordsTotal FROM (${configurationQuery + orderBy + (req.body.allData ? '' : offsetLimit)})t;`
    }

    static async addWhereBeforeString(filterConditions) {
        // Check if filterConditions is empty or undefined
        if (!filterConditions) {
            return filterConditions;
        }

        // Prepend "AND " only if the string is not empty
        return `WHERE ${filterConditions}`;
    }

    static async addAndBeforeString(filterConditions) {
        // Check if filterConditions is empty or undefined
        if (!filterConditions) {
            return filterConditions;
        }

        // Prepend "AND " only if the string is not empty
        return ` AND  ${filterConditions}`;
    }

    static async formatColumnString(columnString) {
        // Check if the string contains a period
        if (columnString.includes('.')) {
            // Split the input string by the period
            const parts = columnString.split('.');

            // Wrap each part with backticks
            const formattedParts = parts.map(part => `\`${part}\``);

            // Join the wrapped parts with a period
            return formattedParts.join('.');
        }

        // If no period is found, return the original string wrapped in backticks
        return `\`${columnString}\``;
    }

    static async formatDateString(dateString) {
        // Parse the input date string into a JavaScript Date object
        const date = new Date(dateString);

        // Extract the month, day, and year from the Date object
        const month = date.getMonth() + 1; // getMonth() returns 0-11
        const day = date.getDate();
        const year = date.getFullYear();

        // Format the date as MM/DD/YYYY
        return `${month}/${day}/${year}`;
    }

    static async checkPrimaryColumn(queryString, xAxis) {
        // Split the xaxis if it contains a dot and format it
        if (xAxis.includes('.')) {
            xAxis = `\`${xAxis.split('.').join('`.`')}\``;
        } else {
            xAxis = `\`${xAxis}\``;
        }

        // Extract the columns part of the query
        let selectIndex = queryString.indexOf('SELECT') + 6;
        let fromIndex = queryString.indexOf('FROM');
        let columnsPart = queryString.slice(selectIndex, fromIndex).trim();

        // Check if the xaxis column is already present
        if (!columnsPart.includes(xAxis)) {
            // Insert the xaxis column at the beginning of the columns part
            columnsPart = `${xAxis}, ${columnsPart}`;
            // Reconstruct the query
            queryString = `SELECT ${columnsPart} ${queryString.slice(fromIndex)}`;
        }

        return queryString;
    }
}
