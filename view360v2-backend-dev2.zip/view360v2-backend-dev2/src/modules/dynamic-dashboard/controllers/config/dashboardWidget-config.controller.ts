import { dataSource } from "core/data-source";
import { DashboardWidget } from "entities";
import { CommonHelper, ApiErrorResponse } from "utils/helpers/common.helper";
import { Post, Request, Path, Route, Security, Tags, Controller } from "tsoa";

@Route("dashboard")
@Tags("Dynamic Dashboard")
export class DashboardWidgetConfigController extends Controller {
    /**
     * Configure Widget
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */

    @Security("bearerAuth")
    @Post("configure-widget/:widgetId")
    async configureWidget(
        @Request() req: any,
        @Path() widgetId: string
    ): Promise<any> {
        try {
            req.body.widgetAccount = req.body.widgetAccount === 'VIEW360TABLES' ? null : req.body.widgetAccount;
            const queryData = {
                title: req.body.widgetTitle,
                widgetAccount: req.body.widgetAccount ? req.body.widgetAccount : null ,
                widgetConfig: JSON.stringify(req.body.widgetConfig),
                isConfigured: 1,
                isWidgetVisible: req.body.isWidgetVisible,
            };
            const result: any = await dataSource
                .createQueryBuilder()
                .update(DashboardWidget)
                .set(queryData)
                .where("ID = :id", { id: widgetId })
                .execute();
            const response: any = { status: true, data: null, message: "" };
            if (result && result.affected) {
                response.message = "Widget configured.";
                response.success = true;
                response.data = { updatedRows: result.affected };
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse(response);
            } else {
                response.message = "Oops! widget could not be configured.";
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse(response);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Permission Widget
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */

    @Security("bearerAuth")
    @Post("permission-widget/:widgetId")
    async permissionWidget(
        @Request() req: any,
        @Path() widgetId: string
    ): Promise<any> {
        try {
            const queryData = {
                mappedUser: JSON.stringify(req.body.mappedUser),
            };
            const result: any = await dataSource
                .createQueryBuilder()
                .update(DashboardWidget)
                .set(queryData)
                .where("ID = :id", { id: req.params.widgetId })
                .execute();
            const response: any = { status: true, data: null, message: "" };
            if (result && result.affected) {
                response.message = "Permission updated.";
                response.success = true;
                response.data = { updatedRows: result.updatedRows };
            } else {
                response.message = "Oops! permission could not be updated.";
            }
            this.setStatus(200);

            return CommonHelper.apiSwaggerSuccessResponse({
                message: "widgets updated",
                data: response,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
