import { ApplicationLogger } from "../../../../core/config/pino-loggers";
import { CommonHelper, ApiErrorResponse } from "../../../../utils/helpers/common.helper";
import { dataSource } from "../../../../core/data-source";
import { WidgetBuilder, DashboardWidget } from "../../../../entities";
import dbService from "../../../../services/db.service";
import {DataSource, Not} from "typeorm";
import Container from 'typedi';
import { Body, Get, Post, Request, Path, Route, Security, Tags, Delete, Patch, Controller } from 'tsoa';

@Route('dashboard')
@Tags('Dynamic Dashboard')

export class WidgetBuilderController extends Controller {


    @Security('bearerAuth')
    @Post('widget-builder-list')
    async getWidgetBuilderList(@Request() req: any): Promise<any> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };
            const selectedFields: any = [
                "id",
                "dashboard",
                "widgetAccount",
                "title",
                "widgetConfig",
                "isConfigured",
                "type",
                "createdOn",
            ];
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(DashboardWidget),
                {
                    where: { dashboard: req.body.dashboardId, id: Not(req.body.widgetId) },
                    select: selectedFields,
                    relations: ["widgetAccount"],
                }
            );

            if (results && results.length > 0) {
                apiResponse.data = results;
                apiResponse.recordsTotal = results.length;
                apiResponse.recordsFiltered = results.length;
            }
            this.setStatus(200)
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: apiResponse });
        } catch (error) {
            ApplicationLogger.error(
                "Error occurred in WidgetBuilderController getWidgetBuilderList::",
                error
            );
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }


    @Security('bearerAuth')
    @Post('widget-builder-add')
    async widgetBuilderAdd(
        @Request() req: any, @Body() requestBody: any
    ): Promise<any> {
        try {
            let apiResponse = {};

            const widgetBuilderModel = new WidgetBuilder();
            widgetBuilderModel.dashboard = requestBody.selectedDashboard;
            widgetBuilderModel.clientId = req.userDetails.client_id;
            widgetBuilderModel.title = requestBody.name;
            widgetBuilderModel.widgetConfig = JSON.stringify({
                jsonConfig: requestBody.jsonConfig,
                container_bg_color: requestBody.container_bg_color,
                selector_active_bg_color: requestBody.selector_active_bg_color,
                selector_active_text_color:
                    requestBody.selector_active_text_color,
                selector_bg_color: requestBody.selector_bg_color,
                showType: requestBody.showType,
                userId: requestBody.userId,
                userRole: requestBody.userRole,
                width_style: requestBody.width_style,
            });
            widgetBuilderModel.isShowDashboard = requestBody.isShowDashboard
                ? 1
                : 0;
            widgetBuilderModel.createdBy = req.userDetails.id;

            const result = await Container.get(DataSource).manager.save(widgetBuilderModel);
            if (result?.id) {
                apiResponse = { insertedId: result.id };
            }
            this.setStatus(200)

            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: apiResponse });

        } catch (error) {
            ApplicationLogger.error(
                "Error occurred in WidgetBuilderController widgetBuilderAdd::",
                error
            );
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }



    @Security('bearerAuth')
    @Get('widget-builder/:widgetId')
    async widgetBuilderDetails(
        @Request() req: any, @Path() widgetId: string
    ): Promise<any> {
        try {
            let apiResponse: any = {
                data: [],
            };
            let result: any = await dataSource
                .getRepository(WidgetBuilder)
                .findOne({
                    where: {
                        id: widgetId,
                        clientId: req.userDetails.client_id,
                    },
                    relations: ["widgetAccount", "dashboard"],
                });
            apiResponse.data = result;

            if (apiResponse.data) {
                apiResponse.data.widgetConfig = {};
                if (apiResponse.data.widgetConfig) {
                    apiResponse.data.widgetConfig = JSON.parse(
                        apiResponse.data.widgetConfig
                    );
                }
            }
            this.setStatus(200)
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: apiResponse });
        } catch (error) {
            ApplicationLogger.error(
                "Error occurred in WidgetBuilderController widgetBuilderDetails::",
                error
            );
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }


    @Security('bearerAuth')
    @Patch('widget-builder/:widgetId')
    async widgetBuilderUpdate(
        @Request() req: any, @Path() widgetId: string, @Body() requestBody: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };

            const payload = {
                dashboard: requestBody.selectedDashboard,
                clientId: req.userDetails.client_id,
                title: requestBody.name,
                widgetConfig: JSON.stringify({
                    jsonConfig: requestBody.jsonConfig,
                    container_bg_color: requestBody.container_bg_color,
                    selector_active_bg_color:
                        requestBody.selector_active_bg_color,
                    selector_active_text_color:
                        requestBody.selector_active_text_color,
                    selector_bg_color: requestBody.selector_bg_color,
                    showType: requestBody.showType,
                    userId: requestBody.userId,
                    userRole: requestBody.userRole,
                    width_style: requestBody.width_style,
                }),
                isShowDashboard: requestBody.isShowDashboard ? 1 : 0,
            };

            const updateResult = await dataSource
                .getRepository(WidgetBuilder)
                .update({ id: widgetId }, payload);
            apiResponse.data = updateResult;
            this.setStatus(200)

            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: apiResponse });
        } catch (error) {
            ApplicationLogger.error(
                "Error occurred in WidgetBuilderController widgetBuilderUpdate::",
                error
            );
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }



    @Security('bearerAuth')
    @Delete('widget-builder/:widgetId')
    async widgetBuilderDelete(
        @Request() req: any, @Path() widgetId: string, @Body() requestBody: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };

            const widgetResult = await dataSource
                .getRepository(WidgetBuilder)
                .delete([widgetId]);
            apiResponse.data = widgetResult;
            this.setStatus(200)
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: apiResponse });
        } catch (error) {
            ApplicationLogger.error(
                "Error occurred in WidgetBuilderController widgetBuilderDelete::",
                error
            );
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
