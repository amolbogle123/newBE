import {
    DashboardWidget,
    SecretConfiguration,
    VaultConfiguration,
    WidgetAccount,
} from "../../../../entities";
import { dataSource } from "../../../../core/data-source";
import {
    CommonHelper,
    ApiErrorResponse,
} from "../../../../utils/helpers/common.helper";
import lodash from "lodash";
import {
    Body,
    Get,
    Post,
    Request,
    Path,
    Route,
    Security,
    Tags,
    Delete,
    Controller,
    Patch, Middlewares,
} from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { VaultService } from "../../../vault/service/vault.service";
import {validateEntryCount} from "../../../../middlewares/common.middleware";

@Route("dashboard")
@Tags("Dynamic Dashboard")
export class WidgetCrudController extends Controller {
    private vaultService: VaultService = new VaultService();
    /**
     * Add Widget To Dashboard
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Middlewares(validateEntryCount)
    @Post("widget")
    async addWidgetToDashboard(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<any> {
        try {
            // if (requestBody.type == "GOOGLE_ANALYTICS") {
            //     let templates: any = [
            //         {
            //             TITLE: "Google Analytics Mobile Overview",
            //             chartType: "PIE",
            //             dimensions: "ga:deviceCategory",
            //             start_date: "2021-01-01",
            //             end_date: "2021-06-05",
            //             isSample: true,
            //             metric: "ga:users",
            //             sampleImage: "assets/img/mobile_overview.png",
            //             POSITIONX: 0,
            //             POSITIONY: 0,
            //             WIDTH: 500,
            //             HEIGHT: 350,
            //             response: {},
            //         },
            //         {
            //             TITLE: "Google Analytics Impression Overview",
            //             chartType: "LINE",
            //             dimensions: "ga:yearMonth",
            //             start_date: "2021-01-01",
            //             end_date: "2021-06-05",
            //             isSample: true,
            //             metric: "ga:impressions",
            //             sampleImage: "assets/img/impressions.png",
            //             POSITIONX: 508,
            //             POSITIONY: 0,
            //             WIDTH: 675,
            //             HEIGHT: 350,
            //             response: {},
            //         },
            //         {
            //             TITLE: "Google Analytics All Traffic",
            //             chartType: "LINE",
            //             dimensions: "ga:medium",
            //             start_date: "2021-01-01",
            //             end_date: "2021-06-05",
            //             isSample: true,
            //             metric: "ga:users",
            //             sampleImage: "assets/img/traffic.png",
            //             POSITIONX: 0,
            //             POSITIONY: 360,
            //             WIDTH: 1184,
            //             HEIGHT: 370,
            //             response: {},
            //         },
            //         {
            //             TITLE: "Google Analytics Pageviews",
            //             chartType: "BAR",
            //             dimensions: "ga:yearMonth",
            //             start_date: "2021-01-01",
            //             end_date: "2021-06-05",
            //             isSample: true,
            //             metric: "ga:pageviews",
            //             sampleImage: "assets/img/pageviews.png",
            //             POSITIONX: 0,
            //             POSITIONY: 743,
            //             WIDTH: 666,
            //             HEIGHT: 335,
            //             response: {},
            //         },
            //         {
            //             TITLE: "Google Analytics Demographic",
            //             chartType: "PIE",
            //             dimensions: "ga:userAgeBracket",
            //             start_date: "2021-01-01",
            //             end_date: "2021-06-05",
            //             isSample: true,
            //             metric: "ga:users",
            //             sampleImage: "assets/img/demographic.png",
            //             POSITIONX: 676,
            //             POSITIONY: 743,
            //             WIDTH: 508,
            //             HEIGHT: 335,
            //             response: {},
            //         },
            //     ];
            //     for (let i in templates) {
            //         const response: any = {
            //             status: false,
            //             data: [],
            //         };
            //         const dashBoardWidgetModeling = new DashboardWidget();
            //         dashBoardWidgetModeling.dashboard = requestBody.dashboard;
            //         //dashBoardWidgetModeling.WIDGET_ACCOUNT = req.body.WIDGET_ACCOUNT;
            //         dashBoardWidgetModeling.type = requestBody.type;
            //         dashBoardWidgetModeling.title = templates[i].TITLE;
            //         dashBoardWidgetModeling.isConfigured = 1;
            //         dashBoardWidgetModeling.positonX = templates[i].POSITIONX.toString();
            //         dashBoardWidgetModeling.positonY = templates[i].POSITIONY.toString();
            //         dashBoardWidgetModeling.width = templates[i].WIDTH.toString();
            //         dashBoardWidgetModeling.height = templates[i].HEIGHT.toString();
            //         dashBoardWidgetModeling.createdBy = 'Me'; //req.userDetails.id;
            //         dashBoardWidgetModeling.mappedUser = req.body.MAPPED_USER;
            //         const result: any = await Container.get(DataSource).manager.save(dashBoardWidgetModeling);

            //         if (result) {
            //             response.status = true;
            //             response.data = {
            //                 insertId: result.ID,
            //                 created: 'self',
            //             };
            //             templates[i].response = response;
            //         }
            //     }
            //     if (templates.length > 0) {
            //         try {
            //             for (let i in templates) {
            //                 let widgetConfig = {
            //                     chartType: templates[i].chartType,
            //                     dimensions: templates[i].dimensions,
            //                     end_date: templates[i].end_date,
            //                     isSample: templates[i].isSample,
            //                     metric: templates[i].metric,
            //                     start_date: templates[i].start_date,
            //                     sampleImage: templates[i].sampleImage,
            //                 };

            //                 const queryData = {
            //                     title: templates[i].TITLE,
            //                     widgetAccount: null,
            //                     widgetConfig: JSON.stringify(widgetConfig),
            //                     isConfigured: 1,
            //                     id: templates[i].response.data.insertId,
            //                 };
            //                 const result: any = await dataSource
            //                     .createQueryBuilder()
            //                     .update(DashboardWidget)
            //                     .set(queryData)
            //                     .where("ID = :id", { id: templates[i].response.data.insertId })
            //                     .execute();
            //                 const response: any = { status: true, data: null, message: "" };
            //                 if (result && result.updatedRows) {
            //                     response.message = "Widget configured.";
            //                     response.success = true;
            //                     response.data = { updatedRows: result.updatedRows };
            //                     templates[i]["isConfigured"] = response;
            //                     templates[i]["widgetConfig"] = widgetConfig;
            //                 } else {
            //                     response.message = "Oops! widget could not be configured.";
            //                 }
            //             }
            //             const finalresponse = { status: true, data: null, message: "" };
            //             finalresponse.status = true;
            //             finalresponse.data = templates;
            //             finalresponse.message = "Widgets added to dashboard.";
            //             return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //         } catch {
            //             const finalresponse: any = { status: true, data: null, message: "" };
            //             finalresponse.status = true;
            //             finalresponse.data = [];
            //             finalresponse.message = "Widget could not be configured.";
            //             return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //         }
            //     } else {
            //         const finalresponse: any = { status: true, data: null, message: "" };
            //         finalresponse.status = true;
            //         finalresponse.data = [];
            //         finalresponse.message = "Widget could not be configured.";
            //         return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //     }
            // } else if (requestBody.type == "GOOGLE_ADWORDS") {
            //     let templates: any = [
            //         {
            //             TITLE: "Google Adwords- Impressions",
            //             chartType: "BAR",
            //             dimensions: "ga:date",
            //             start_date: "2021-06-01",
            //             end_date: "2021-06-27",
            //             isSample: true,
            //             metric: "ga:impressions",
            //             sampleImage: "assets/img/adwords-impressions.png",
            //             POSITIONX: 0,
            //             POSITIONY: 0,
            //             WIDTH: 700,
            //             HEIGHT: 370,
            //             response: {},
            //         },
            //         {
            //             TITLE: "Google Adwords- Clicks",
            //             chartType: "LINE",
            //             dimensions: "ga:date",
            //             start_date: "2021-06-01",
            //             end_date: "2021-06-27",
            //             isSample: true,
            //             metric: "ga:adClicks",
            //             sampleImage: "assets/img/adwords-clicks.png",
            //             POSITIONX: 721,
            //             POSITIONY: 0,
            //             WIDTH: 488,
            //             HEIGHT: 370,
            //             response: {},
            //         },
            //         {
            //             TITLE: "Google Adwords- Click Through Ratio",
            //             chartType: "LINE",
            //             dimensions: "ga:date",
            //             start_date: "2021-06-01",
            //             end_date: "2021-06-27",
            //             isSample: true,
            //             metric: "ga:CTR",
            //             sampleImage: "assets/img/adwords-CTR.png",
            //             POSITIONX: 0,
            //             POSITIONY: 386,
            //             WIDTH: 393,
            //             HEIGHT: 350,
            //             response: {},
            //         },
            //         {
            //             TITLE: "Google Adwords- Cost Per Click",
            //             chartType: "BAR",
            //             dimensions: "ga:date",
            //             start_date: "2021-06-01",
            //             end_date: "2021-06-27",
            //             isSample: true,
            //             metric: "ga:CPC",
            //             sampleImage: "assets/img/adwords-cpc.png",
            //             POSITIONX: 0,
            //             POSITIONY: 760,
            //             WIDTH: 666,
            //             HEIGHT: 353,
            //             response: {},
            //         },
            //         {
            //             TITLE: "Google Adwords- Ad Cost",
            //             chartType: "LINE",
            //             dimensions: "ga:date",
            //             start_date: "2021-06-01",
            //             end_date: "2021-06-27",
            //             isSample: true,
            //             metric: "ga:adCost",
            //             sampleImage: "assets/img/adwords-adcost.png",
            //             POSITIONX: 405,
            //             POSITIONY: 386,
            //             WIDTH: 802,
            //             HEIGHT: 350,
            //             response: {},
            //         },
            //         {
            //             TITLE: "Google Adwords- Cost Per Conversion",
            //             chartType: "LINE",
            //             dimensions: "ga:date",
            //             start_date: "2021-06-01",
            //             end_date: "2021-06-27",
            //             isSample: true,
            //             metric: "ga:costPerConversion",
            //             sampleImage: "assets/img/adwords-costperconversion.png",
            //             POSITIONX: 682,
            //             POSITIONY: 760,
            //             WIDTH: 520,
            //             HEIGHT: 353,
            //             response: {},
            //         },
            //     ];
            //     for (let i in templates) {
            //         const response: any = {
            //             status: false,
            //             data: [],
            //         };
            //         const dashBoardWidgetModeling1 = new DashboardWidget();
            //         dashBoardWidgetModeling1.dashboard = req.body.DASHBOARD;
            //         //dashBoardWidgetModeling.WIDGET_ACCOUNT = req.body.WIDGET_ACCOUNT;
            //         dashBoardWidgetModeling1.type = req.body.TYPE;
            //         dashBoardWidgetModeling1.title = templates[i].TITLE;
            //         dashBoardWidgetModeling1.isConfigured = 1;
            //         dashBoardWidgetModeling1.positonX = templates[i].POSITIONX.toString();
            //         dashBoardWidgetModeling1.positonY = templates[i].POSITIONY.toString();
            //         dashBoardWidgetModeling1.width = templates[i].WIDTH.toString();
            //         dashBoardWidgetModeling1.height = templates[i].HEIGHT.toString();
            //         dashBoardWidgetModeling1.createdBy = 'self'; //req.userDetails.id;
            //         dashBoardWidgetModeling1.mappedUser = req.body.MAPPED_USER;
            //         const result: any = await Container.get(DataSource).manager.save(dashBoardWidgetModeling1);
            //         if (result) {
            //             response.status = true;
            //             response.data = {
            //                 insertId: result.ID,
            //                 created: req.userDetails.id,
            //             };
            //             templates[i].response = response;
            //         }
            //     }

            //     if (templates.length > 0) {
            //         try {
            //             for (let i in templates) {
            //                 let widgetConfig = {
            //                     chartType: templates[i].chartType,
            //                     dimensions: templates[i].dimensions,
            //                     end_date: templates[i].end_date,
            //                     isSample: templates[i].isSample,
            //                     metric: templates[i].metric,
            //                     start_date: templates[i].start_date,
            //                     sampleImage: templates[i].sampleImage,
            //                 };

            //                 const queryData = {
            //                     title: templates[i].TITLE,
            //                     widgetAccount: null,
            //                     widgetConfig: JSON.stringify(widgetConfig),
            //                     isConfigured: 1,
            //                     id: templates[i].response.data.insertId,
            //                 };
            //                 const result: any = await dataSource
            //                     .createQueryBuilder()
            //                     .update(DashboardWidget)
            //                     .set(queryData)
            //                     .where("ID = :id", { id: templates[i].response.data.insertId })
            //                     .execute();
            //                 const response: any = { status: true, data: null, message: "" };
            //                 if (result && result.updatedRows) {
            //                     response.message = "Widget configured.";
            //                     response.success = true;
            //                     response.data = { updatedRows: result.updatedRows };
            //                     templates[i]["isConfigured"] = response;
            //                     templates[i]["widgetConfig"] = widgetConfig;
            //                 } else {
            //                     response.message = "Oops! widget could not be configured.";
            //                 }
            //             }
            //             const finalresponse = { status: true, data: null, message: "" };
            //             finalresponse.status = true;
            //             finalresponse.data = templates;
            //             finalresponse.message = "Widgets added to dashboard.";
            //             return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //         } catch {
            //             const finalresponse: any = { status: true, data: null, message: "" };
            //             finalresponse.status = true;
            //             finalresponse.data = [];
            //             finalresponse.message = "Widget could not be configured.";
            //             return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //         }
            //     } else {
            //         const finalresponse: any = { status: true, data: null, message: "" };
            //         finalresponse.status = true;
            //         finalresponse.data = [];
            //         finalresponse.message = "Widget could not be configured.";
            //         return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //     }
            // } else if (requestBody.type == "FACEBOOK_ADS_TEMP") {
            //     let templates: any = [
            //         {
            //             TITLE: "Facebood Ads- Overview",
            //             chartType: "LINE",
            //             adAccount: "act_1581324045309389",
            //             adBreakdown: "Day",
            //             adCampaign: "23847477656350361",
            //             isSample: true,
            //             adMetrics: ["impressions", "clicks"],
            //             sampleImage: "assets/img/fb-overview.png",
            //             POSITIONX: 0,
            //             POSITIONY: 0,
            //             WIDTH: 768,
            //             HEIGHT: 355,
            //             response: {},
            //             properties: {
            //                 combinedColumn: false,
            //                 areaFill: true,
            //                 pieDesign: "2D",
            //                 barDesign: "VERTICAL",
            //             },
            //         },
            //         {
            //             TITLE: "Facebood Ads- Impressions",
            //             chartType: "LINE",
            //             adAccount: "act_1581324045309389",
            //             adBreakdown: "Day",
            //             adCampaign: "23847477656350361",
            //             isSample: true,
            //             adMetrics: ["impressions"],
            //             sampleImage: "assets/img/fb-impressions.png",
            //             POSITIONX: 822,
            //             POSITIONY: 0,
            //             WIDTH: 433,
            //             HEIGHT: 355,
            //             response: {},
            //             properties: {
            //                 combinedColumn: false,
            //                 areaFill: false,
            //                 pieDesign: "2D",
            //                 barDesign: "VERTICAL",
            //             },
            //         },
            //         {
            //             TITLE: "Facebood Ads- Clicks",
            //             chartType: "LINE",
            //             adAccount: "act_1581324045309389",
            //             adBreakdown: "Day",
            //             adCampaign: "23847477656350361",
            //             isSample: true,
            //             adMetrics: ["clicks"],
            //             sampleImage: "assets/img/fb-clicks.png",
            //             POSITIONX: 0,
            //             POSITIONY: 377,
            //             WIDTH: 395,
            //             HEIGHT: 355,
            //             response: {},
            //             properties: {
            //                 combinedColumn: false,
            //                 areaFill: false,
            //                 pieDesign: "2D",
            //                 barDesign: "VERTICAL",
            //             },
            //         },
            //         {
            //             TITLE: "Facebood Ads- Frequency",
            //             chartType: "LINE",
            //             adAccount: "act_1581324045309389",
            //             adBreakdown: "Day",
            //             adCampaign: "23847477656350361",
            //             isSample: true,
            //             adMetrics: ["frequency"],
            //             sampleImage: "assets/img/fb-frequency.png",
            //             POSITIONX: 406,
            //             POSITIONY: 377,
            //             WIDTH: 395,
            //             HEIGHT: 355,
            //             response: {},
            //             properties: {
            //                 combinedColumn: false,
            //                 areaFill: false,
            //                 pieDesign: "2D",
            //                 barDesign: "VERTICAL",
            //             },
            //         },
            //         {
            //             TITLE: "Facebood Ads- Unique Clicks",
            //             chartType: "LINE",
            //             adAccount: "act_1581324045309389",
            //             adBreakdown: "Day",
            //             adCampaign: "23847477656350361",
            //             isSample: true,
            //             adMetrics: ["unique_clicks"],
            //             sampleImage: "assets/img/fb-unique_clicks.png",
            //             POSITIONX: 821,
            //             POSITIONY: 377,
            //             WIDTH: 395,
            //             HEIGHT: 355,
            //             response: {},
            //             properties: {
            //                 combinedColumn: false,
            //                 areaFill: false,
            //                 pieDesign: "2D",
            //                 barDesign: "VERTICAL",
            //             },
            //         },
            //     ];
            //     for (let i in templates) {
            //         const response: any = {
            //             status: false,
            //             data: [],
            //         };
            //         const dashBoardWidgetModeling2 = new DashboardWidget();
            //         dashBoardWidgetModeling2.dashboard = req.body.DASHBOARD;
            //         //dashBoardWidgetModeling.WIDGET_ACCOUNT = req.body.WIDGET_ACCOUNT;
            //         dashBoardWidgetModeling2.type = req.body.TYPE;
            //         dashBoardWidgetModeling2.title = templates[i].TITLE;
            //         dashBoardWidgetModeling2.isConfigured = 1;
            //         dashBoardWidgetModeling2.positonX = templates[i].POSITIONX.toString();
            //         dashBoardWidgetModeling2.positonY = templates[i].POSITIONY.toString();
            //         dashBoardWidgetModeling2.width = templates[i].WIDTH.toString();
            //         dashBoardWidgetModeling2.height = templates[i].HEIGHT.toString();
            //         dashBoardWidgetModeling2.createdBy = 'self'; //req.userDetails.id;
            //         dashBoardWidgetModeling2.mappedUser = req.body.MAPPED_USER;
            //         const result: any = await Container.get(DataSource).manager.save(dashBoardWidgetModeling2);
            //         if (result) {
            //             response.status = true;
            //             response.data = {
            //                 insertId: result.ID,
            //                 created: req.userDetails.id,
            //             };
            //             templates[i].response = response;
            //         }
            //     }
            //     if (templates.length > 0) {
            //         try {
            //             for (let i in templates) {
            //                 let widgetConfig = {
            //                     adAccount: templates[i].adAccount,
            //                     adBreakdown: templates[i].adBreakdown,
            //                     adCampaign: templates[i].adCampaign,
            //                     adMetrics: templates[i].adMetrics,
            //                     cacheWidget: false,
            //                     chartType: templates[i].chartType,
            //                     sampleImage: templates[i].sampleImage,
            //                     isSample: templates[i].isSample,
            //                     properties: templates[i].properties,
            //                 };

            //                 const queryData = {
            //                     title: templates[i].TITLE,
            //                     widgetAccount: null,
            //                     widgetConfig: JSON.stringify(widgetConfig),
            //                     isConfigured: 1,
            //                     id: templates[i].response.data.insertId,
            //                 };
            //                 const result: any = await dataSource
            //                     .createQueryBuilder()
            //                     .update(DashboardWidget)
            //                     .set(queryData)
            //                     .where("ID = :id", { id: templates[i].response.data.insertId })
            //                     .execute();
            //                 const response: any = { status: true, data: null, message: "" };
            //                 if (result && result.updatedRows) {
            //                     response.message = "Widget configured.";
            //                     response.success = true;
            //                     response.data = { updatedRows: result.updatedRows };
            //                     templates[i]["isConfigured"] = response;
            //                     templates[i]["widgetConfig"] = widgetConfig;
            //                 } else {
            //                     response.message = "Oops! widget could not be configured.";
            //                 }
            //             }
            //             const finalresponse: any = { status: true, data: null, message: "" };
            //             finalresponse.status = true;
            //             finalresponse.data = templates;
            //             finalresponse.message = "fb Widgets added to dashboard.";
            //             return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //         } catch {
            //             const finalresponse: any = { status: true, data: null, message: "" };
            //             finalresponse.status = true;
            //             finalresponse.data = [];
            //             finalresponse.message = "Widget could not be configured.";
            //             return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //         }
            //     } else {
            //         const finalresponse: any = { status: true, data: null, message: "" };
            //         finalresponse.status = true;
            //         finalresponse.data = [];
            //         finalresponse.message = "Widget could not be configured.";
            //         return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //     }
            // } else if (requestBody.type == "COMPARE_DASHBOARD") {
            //     let templates: any = [
            //         {
            //             TITLE: "Comparison-Graph-1",
            //             TYPE: "COMPARE_DASHBOARD",
            //             adAccount: {
            //                 facebook: '4367872a-78d3-43bf-85b6-42bf691213be',
            //                 google: 'e5712493-324e-4773-a6b6-7d3ae1275b2d'
            //             },
            //             adBreakdown: "Day",
            //             adCampaign: "23847477656350361",
            //             chartType: "LINE",
            //             isSample: true,
            //             adMetrics: ["Spend"],
            //             sampleImage: "assets/img/fb-overview.png",
            //             POSITIONX: 0,
            //             POSITIONY: 0,
            //             WIDTH: 768,
            //             HEIGHT: 355,
            //             response: {},
            //             properties: {
            //                 combinedColumn: false,
            //                 areaFill: true,
            //                 pieDesign: "2D",
            //                 barDesign: "VERTICAL",
            //             },
            //         },
            //         {
            //             TITLE: "Comparison-Graph-2",
            //             TYPE: "COMPARE_DASHBOARD",
            //             adAccount: {
            //                 facebook: '4367872a-78d3-43bf-85b6-42bf691213be',
            //                 google: 'e5712493-324e-4773-a6b6-7d3ae1275b2d'
            //             },
            //             adBreakdown: "Day",
            //             adCampaign: "23847477656350361",
            //             chartType: "PIE",
            //             isSample: true,
            //             adMetrics: ["Clicks"],
            //             sampleImage: "assets/img/fb-overview.png",
            //             POSITIONX: 0,
            //             POSITIONY: 380,
            //             WIDTH: 600,
            //             HEIGHT: 355,
            //             response: {},
            //             properties: {
            //                 combinedColumn: false,
            //                 areaFill: true,
            //                 pieDesign: "2D",
            //                 barDesign: "VERTICAL",
            //             },
            //         },
            //         {
            //             TITLE: "Comparison-Graph-3",
            //             TYPE: "COMPARE_DASHBOARD",
            //             adAccount: {
            //                 facebook: '4367872a-78d3-43bf-85b6-42bf691213be',
            //                 google: 'e5712493-324e-4773-a6b6-7d3ae1275b2d'
            //             },
            //             adBreakdown: "Day",
            //             adCampaign: "23847477656350361",
            //             chartType: "Bar",
            //             isSample: true,
            //             adMetrics: ["Impressions"],
            //             sampleImage: "assets/img/fb-overview.png",
            //             POSITIONX: 676,
            //             POSITIONY: 380,
            //             WIDTH: 508,
            //             HEIGHT: 355,
            //             response: {},
            //             properties: {
            //                 combinedColumn: false,
            //                 areaFill: true,
            //                 pieDesign: "2D",
            //                 barDesign: "VERTICAL",
            //             },
            //         },
            //         {
            //             TITLE: "Comparison-Table",
            //             TYPE: "SQL_COMPARE",
            //             adAccount: {
            //                 facebook: '4367872a-78d3-43bf-85b6-42bf691213be',
            //                 google: 'e5712493-324e-4773-a6b6-7d3ae1275b2d'
            //             },
            //             adBreakdown: "Day",
            //             adCampaign: "23847477656350361",
            //             chartType: "sql",
            //             isSample: true,
            //             sampleImage: "assets/img/fb-overview.png",
            //             POSITIONX: 0,
            //             POSITIONY: 750,
            //             WIDTH: 768,
            //             HEIGHT: 355,
            //             response: {}
            //         }
            //     ];
            //     for (let i in templates) {
            //         const response: any = {
            //             status: false,
            //             data: [],
            //         };

            //         const dashBoardWidgetModeling3 = new DashboardWidget();
            //         dashBoardWidgetModeling3.dashboard = requestBody.dashboard;
            //         //dashBoardWidgetModeling.WIDGET_ACCOUNT = req.body.WIDGET_ACCOUNT;
            //         dashBoardWidgetModeling3.type = requestBody.type;
            //         dashBoardWidgetModeling3.title = templates[i].TITLE;
            //         dashBoardWidgetModeling3.isConfigured = 1;
            //         dashBoardWidgetModeling3.positonX = templates[i].POSITIONX.toString();
            //         dashBoardWidgetModeling3.positonY = templates[i].POSITIONY.toString();
            //         dashBoardWidgetModeling3.width = templates[i].WIDTH.toString();
            //         dashBoardWidgetModeling3.height = templates[i].HEIGHT.toString();
            //         dashBoardWidgetModeling3.createdBy = 'self'; //req.userDetails.id;
            //         dashBoardWidgetModeling3.mappedUser = req.body.MAPPED_USER;
            //         const result: any = await Container.get(DataSource).manager.save(dashBoardWidgetModeling3);
            //         if (result) {
            //             response.status = true;
            //             response.data = {
            //                 insertId: result.ID,
            //                 created: req.userDetails.id,
            //             };
            //             templates[i].response = response;
            //         }
            //     }
            //     if (templates.length > 0) {
            //         for (let i in templates) {
            //             let widgetConfig = {
            //                 adAccount: templates[i].adAccount,
            //                 adBreakdown: templates[i].adBreakdown,
            //                 adCampaign: templates[i].adCampaign,
            //                 adMetrics: templates[i].adMetrics,
            //                 cacheWidget: false,
            //                 chartType: templates[i].chartType,
            //                 sampleImage: templates[i].sampleImage,
            //                 isSample: templates[i].isSample,
            //                 properties: templates[i].properties,
            //             };

            //             // console.log(widgetConfig, 'widgetConfig');
            //             const queryData = {
            //                 title: templates[i].TITLE,
            //                 widgetAccount: JSON.stringify(templates[i].adAccount),
            //                 widgetConfig: JSON.stringify(widgetConfig),
            //                 isConfigured: 1,
            //                 id: templates[i].response.data.insertId,
            //             };
            //             const result: any = await dataSource
            //                 .createQueryBuilder()
            //                 .update(DashboardWidget)
            //                 .set(queryData)
            //                 .where("ID = :id", { id: templates[i].response.data.insertId })
            //                 .execute();
            //             const response: any = { status: true, data: null, message: "" };
            //             if (result && result.updatedRows) {
            //                 response.message = "Widget configured.";
            //                 response.success = true;
            //                 response.data = { updatedRows: result.updatedRows };
            //                 templates[i]["isConfigured"] = response;
            //                 templates[i]["widgetConfig"] = widgetConfig;
            //                 // //console.log(templates[i])
            //             } else {
            //                 response.message = "Oops! widget could not be configured.";
            //             }
            //         }
            //         const finalresponse: any = { status: true, data: null, message: "" };
            //         finalresponse.status = true;
            //         finalresponse.data = templates;
            //         finalresponse.message = "Custom Widgets added to dashboard.";
            //         return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //     } else {
            //         const finalresponse: any = { status: true, data: null, message: "" };
            //         finalresponse.status = true;
            //         finalresponse.data = [];
            //         finalresponse.message = "Widget could not be configured.";
            //         return CommonHelper.apiSwaggerSuccessResponse(finalresponse)
            //     }
            // } else {
            let response: any = { status: false, data: null, message: "" };

            const dashBoardWidgetModeling4 = new DashboardWidget();
            dashBoardWidgetModeling4.dashboard = req.body.dashboard;
            dashBoardWidgetModeling4.type = req.body.type;
            dashBoardWidgetModeling4.title = req.body.title;
            dashBoardWidgetModeling4.isConfigured = 0;
            dashBoardWidgetModeling4.positonX = "0";
            dashBoardWidgetModeling4.positonY = "0";
            dashBoardWidgetModeling4.width =
                dashBoardWidgetModeling4.type === "SEARCH_WIDGET" ? "8" : "4";
            dashBoardWidgetModeling4.height = "25";
            dashBoardWidgetModeling4.createdBy = req.userDetails.id;
            dashBoardWidgetModeling4.mappedUser = req.body.mappedUser;
            const result: any = await Container.get(DataSource).manager.save(
                dashBoardWidgetModeling4
            );
            if (result) {
                response.status = true;
                response.data = {
                    insertId: result.id,
                    created: req.userDetails.id,
                };
                response.message = "Widget added to dashboard.";
            }
            return CommonHelper.apiSwaggerSuccessResponse(response);
            // }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Delete Widget
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Delete("widget/:widgetId")
    async deleteWidget(
        @Request() req: any,
        @Path() widgetId: string
    ): Promise<any> {
        try {
            let IDs: any = widgetId;
            const result: any = await Container.get(DataSource)
                .getRepository(DashboardWidget)
                .delete(IDs);
            const response: any = { success: true, data: null, message: "" };
            if (result && result.affected) {
                response.data = { deletedRows: result.affected };
                response.message = "Widget deleted.";
            } else {
                response.message = "Oops! widget could not be deleted.";
            }
            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * update Widget Position
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Patch("widget/position/:id")
    async updateWidgetPosition(
        @Request() req: any,
        @Path() id: string,
        @Body()
        requestBody: { x: number; y: number; width: number; height: number }
    ): Promise<any> {
        try {
            const data = {
                positonX: typeof requestBody.x === "number" ? requestBody.x : 0,
                positonY: typeof requestBody.y === "number" ? requestBody.y : 0,
                width: requestBody.width,
                height: requestBody.height,
            };
            const updateResult: any = await dataSource
                .createQueryBuilder()
                .update(DashboardWidget)
                .set(data)
                .where("ID = :id", { id: id })
                .execute();
            const response = { success: false, data: null, message: "" };
            if (updateResult && updateResult.affected) {
                response.success = true;
                response.data = { updatedRows: updateResult.affected };
                response.message = "widget position updated.";
            } else {
                response.message =
                    "Oops! widget position could not be updated.";
            }
            return { status: "success", data: response };
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    /**
     * update Widget Size
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Patch("widget/resize/:id")
    async updateWidgetSize(
        @Request() req: any,
        @Path() id: string,
        @Body() requestBody: { width: number; height: number }
    ): Promise<any> {
        try {
            const data = {
                width: requestBody.width,
                height: requestBody.height,
            };
            const updateResult: any = await dataSource
                .createQueryBuilder()
                .update(DashboardWidget)
                .set(data)
                .where("ID = :id", { id: id })
                .execute();
            const response = { success: false, data: null, message: "" };
            if (updateResult && updateResult.affected) {
                response.success = true;
                response.data = { updatedRows: updateResult.affected };
                response.message = "widget size updated.";
            } else {
                response.message = "Oops! widget size could not be updated.";
            }
            return { status: "success", data: response };
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    /**
     * Get widget Data
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security("bearerAuth")
    @Get("widget/:widgetId")
    async getWidgetData(
        @Request() req: any,
        @Path() widgetId: string
    ): Promise<any> {
        try {
            let result;
            result = await Container.get(DataSource)
                .getRepository(DashboardWidget)
                .createQueryBuilder("DW")
                .where("DW.ID = :id", { id: widgetId })
                .getMany();
            if (result && Array.isArray(result) && result.length > 0) {
                const widgetResponse: any = result[0];
                if (widgetResponse.isConfigured <= 0) {
                    const responseData = {
                        displayType: "configure",
                        record: [],
                    };

                    return {
                        status: "success",
                        message: "Widget is not configured",
                        data: responseData,
                    };
                } else {
                    const widgetConfig = widgetResponse.widgetConfig
                        ? JSON.parse(
                              widgetResponse.widgetConfig.replace(/\\/g, "")
                          )
                        : {};
                    const response = {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: widgetConfig,
                    };
                    return { status: "success", message: null, data: response };
                }
            } else {
                const response = {
                    status: true,
                    displayType: "error",
                    message: "Could not find widget.",
                    data: [],
                };
                return { status: "success", message: null, data: response };
            }
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    /**
     * Get Widget
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Get("get-widget/:widgetId")
    async getWidget(
        @Request() req: any,
        @Path() widgetId: string
    ): Promise<any> {
        try {
            const response: any = { status: true, data: [], accounts: [] };
            let result;
            result = await Container.get(DataSource)
                .getRepository(DashboardWidget)
                .findOne({
                    where: { id: widgetId },
                    relations: ["widgetAccount"],
                });
            if (result) {
                let whereCondition = "WA.CLIENT_ID = :client_id";
                switch (req.query.accountType) {
                    case "google_analytics":
                        whereCondition +=
                            " AND WIDGET_TYPE IN ('GOOGLE_ANALYTICS')";
                        break;
                    case "google_adwords":
                        whereCondition +=
                            " AND WIDGET_TYPE IN ('GOOGLE_ADWORDS')";
                        break;
                    case "facebook":
                        whereCondition +=
                            " AND WIDGET_TYPE IN ('FACEBOOK_ADS')";
                        break;
                    default:
                        whereCondition +=
                            " AND WIDGET_TYPE IN ('FORM_CHARTS', 'SQL', 'MSSQL','MYSQL')";
                        break;
                }
                let waResult;
                waResult = await Container.get(DataSource)
                    .getRepository(WidgetAccount)
                    .createQueryBuilder("WA")
                    .where(whereCondition, {
                        client_id: req.userDetails.client_id,
                    })
                    .orderBy("WA.ID", "DESC")
                    .getMany();
                response.data = result;
                response.accounts = [];
                if (waResult) {
                    response.accounts = waResult;
                }
            }
            return {
                status: "success",
                message: null,
                data: response.data,
                accounts: response.accounts,
            };
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    @Security("bearerAuth")
    @Get("get-widget-filter/:widgetId")
    async getWidgetFilter(
        @Request() req: any,
        @Path() widgetId: string
    ): Promise<any> {
        try {
            const response: any = { status: true, data: {}, error: null };
            const result: any = await Container.get(DataSource)
                .getRepository(DashboardWidget)
                .findOne({ where: { id: widgetId } });
            if (result) {
                let filterKey = result.type;
                if (['FACEBOOK_ADS'].indexOf(result.type) > -1) {
                    filterKey = "FACEBOOK_ADS_SEARCH";
                }
                const filterResult: any = await Container.get(DataSource).getRepository(DashboardWidget).findOne({ where: { type: filterKey, dashboard: result.dashboard }, relations: ["widgetAccount"] });
                if (!filterResult || filterResult?.isConfigured <= 0) {
                    this.setStatus(201)
                    return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {
                        status: true,
                        displayType: "configure",
                        message: "Filter Widget is not configured.",
                        data: [],
                    }});
                }

                response.data = filterResult;
                if (response.data.widgetConfig) {
                    response.data.widgetConfig = JSON.parse(response.data.widgetConfig);
                } else {
                    response.data.widgetConfig = {};
                }
            }
            return {
                status: "success",
                message: null,
                data: response.data,
                accounts: response.accounts,
            };
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    /**
     * Get Widget Account
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Get("get-widget-account/:accountId")
    async getWidgetAccount(
        @Request() req: any,
        @Path() accountId: string
    ): Promise<any> {
        try {
            const apiResponse: any = {
                data: null,
            };
            const widgetAccountResult: WidgetAccount = await dataSource
                .getRepository(WidgetAccount)
                .findOneBy({ id: accountId });

            if (widgetAccountResult && !lodash.isEmpty(widgetAccountResult)) {
                if (widgetAccountResult.config.length == 0) {
                    const vaultConfig = await Container.get(DataSource)
                        .getRepository(VaultConfiguration)
                        .find({
                            where: { clientId: req.userDetails.client_id },
                        });
                    if (vaultConfig.length) {
                        const secretConfig = await Container.get(DataSource)
                            .getRepository(SecretConfiguration)
                            .find({
                                where: {
                                    clientId: req.userDetails.client_id,
                                    configurationName:
                                        widgetAccountResult.accountName,
                                },
                            });
                        const vaultData = await this.vaultService.readSecret(
                            `${vaultConfig[0].vaultUrl}:${vaultConfig[0].vaultPort}`,
                            vaultConfig[0].token,
                            secretConfig[0].secretPath
                        );
                        if (vaultData) {
                            widgetAccountResult.config = JSON.parse(
                                vaultData.data.config
                            );
                        }
                    }
                } else {
                    widgetAccountResult.config = JSON.parse(
                        widgetAccountResult.config
                    );
                }

                apiResponse.data = widgetAccountResult;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get Widget Account List
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Post("get-widget-account-list")
    async getWidgetAccountList(@Request() req: any): Promise<any> {
        try {
            const response = {
                status: true,
                records: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };

            const whereCondition: any = {
                clientId: req.userDetails.client_id,
            };
            const fieldsToBeSelected: any[] = [
                "id",
                "accountName",
                "config",
                "widgetType",
                "createdOn",
            ];

            if (req.body.type && req.body.type !== "") {
                whereCondition.widgetType = req.body.type;
            }
            const result: any = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .find({ where: whereCondition, select: fieldsToBeSelected });

            if (result) {
                response.records = result;
                response.recordsTotal = result.length;
                response.recordsFiltered = result.length;
            }
            return { status: "success", message: null, data: response };
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    /**
     * Move Widget Dashboard
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security("bearerAuth")
    @Post("move-widget-dashboard")
    async moveWidgetDashboard(
        @Request() req: any,
        @Body()
        requestBody: {
            dashboardId: string;
            widgetId: string;
            widgetTitle: string;
        }
    ): Promise<any> {
        try {
            const payload = {
                dashboard: requestBody.dashboardId,
                title: requestBody.widgetTitle,
            };

            const result = await dataSource
                .createQueryBuilder()
                .update(DashboardWidget)
                .set(payload)
                .where("ID = :id", { id: requestBody.widgetId })
                .execute();
            return { status: "success", message: null, data: result };
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    /**
     * Copy Widget Dashboard
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security("bearerAuth")
    @Post("copy-widget-dashboard")
    async copyWidgetDashboard(
        @Request() req: any,
        @Body()
        requestBody: {
            widgetId: string;
            dashboardId: string;
            widgetTitle: string;
            widgetAccount: string;
        }
    ): Promise<any> {
        try {
            let result: any, createResult;
            result = await Container.get(DataSource)
                .getRepository(DashboardWidget)
                .findOneBy({
                    id: requestBody.widgetId,
                });
            if (result) {
                const dashBoardObj = new DashboardWidget();
                dashBoardObj.dashboard = requestBody.dashboardId;
                dashBoardObj.title = requestBody.widgetTitle;
                dashBoardObj.type = result.type;
                dashBoardObj.widgetConfig = result.widgetConfig;
                dashBoardObj.width = result.width;
                dashBoardObj.height = result.height;
                dashBoardObj.positonX = result.positonX;
                dashBoardObj.positonY = result.positonY;
                dashBoardObj.isConfigured = result.isConfigured;
                dashBoardObj.mappedUser = result.mappedUser;
                dashBoardObj.widgetAccount = requestBody.widgetAccount ? requestBody.widgetAccount : null;
                dashBoardObj.createdBy = req.userDetails.id;

                createResult = await Container.get(DataSource).manager.save(
                    dashBoardObj
                );
            }
            return { status: "success", message: null, data: createResult };
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    /**
     * Get widget Data
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security("bearerAuth")
    @Post("get-widget-list")
    async getWidgetFromDashboard(
        @Request() req: any,
        @Body() requestBody: { dashboardId: string; widgetId: string }
    ): Promise<any> {
        try {
            let result;
            result = await dataSource
                .getRepository(DashboardWidget)
                .createQueryBuilder("DW")
                .where(
                    'DW.DASHBOARD = :id AND DW.ID != :widgetId AND TYPE = "SQL"',
                    {
                        id: requestBody.dashboardId,
                        widgetId: requestBody.widgetId,
                    }
                )
                .getMany();
            if (result && Array.isArray(result) && result.length > 0) {
                return { status: "success", message: null, data: result };
            } else {
                const response = {
                    status: true,
                    displayType: "error",
                    message: "Could not find widget.",
                    data: [],
                };
                return { status: "success", message: null, data: response };
            }
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    @Security("bearerAuth")
    @Patch("bp-email/:id")
    async bpEmailPatch(
        @Request() req: any,
        @Path() id: string,
        @Body() requestBody: {
            flagStatus: any;
        }
    ): Promise<any> {
        let queryRunner;

        try {
            const response: any = { success: true, data: null, message: "" };

            const connection = dataSource.manager.connection;
            queryRunner = connection.createQueryRunner();
            await queryRunner.connect();
            
            if (id) {
                if (typeof requestBody.flagStatus === "undefined") {
                    requestBody.flagStatus = 0;
                }
                let sqlQuery = "UPDATE BP_emailData SET flagStatus = '" + requestBody.flagStatus + "' WHERE ID = '" + id + "'";
                const result = await queryRunner.query(sqlQuery);
                if (result && result.affectedRows) {
                    response.data = { updated: result.affectedRows };
                    response.message = "BP data updated.";
                } else {
                    response.message = "Oops! BP data could not be find.";
                }
            } else {
                response.message = "required field is missing";
            }

            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        } finally {
            // Release the query runner
            await queryRunner.release();
        }
    }

    /**
     * Delete bp_email
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Delete("bp-email")
    async deleteBpEmail(
        @Request() req: any,
        @Body() requestBody: {
            id: string;
        }
    ): Promise<any> {
        let queryRunner;

        try {
            const response: any = { success: true, data: null, message: "" };

            const connection = dataSource.manager.connection;
            queryRunner = connection.createQueryRunner();
            await queryRunner.connect();
            
            if (requestBody?.id) {
                let sqlQuery = "DELETE FROM BP_emailData WHERE ID = '" + requestBody.id + "'";
                const result = await queryRunner.query(sqlQuery);
                if (result && result.affectedRows) {
                    response.data = { deletedRows: result.affectedRows };
                    response.message = "BP data deleted.";
                } else {
                    response.message = "Oops! BP data could not be deleted.";
                }
            } else {
                response.message = "required field is missing";
            }

            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        } finally {
            // Release the query runner
            await queryRunner.release();
        }
    }
}
