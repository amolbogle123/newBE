import { Themes, Users } from "entities";
import { ShareDashboard } from "entities/share-dashboard";
import { Controller, Get, Path, Post, Request, Route, Security, Tags } from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { v4 as uuidv4 } from 'uuid';

@Route('dashboard')
@Tags('Share Dashboard')
export class ShareDashboardController extends Controller {
    @Security('bearerAuth')
    @Post('share')
    async addSharingInfo(@Request() req: any): Promise<any> {
        try {
            const shareDashboardModel = new ShareDashboard();
            shareDashboardModel.clientId = req.userDetails.client_id;
            shareDashboardModel.dashboardId = req.body.dashboardId;
            shareDashboardModel.title = req.body.title;
            shareDashboardModel.uuid = req.body.uuid;
            shareDashboardModel.url = req.body.url;
            shareDashboardModel.urlViewOnce = req.body.urlViewOnce
            shareDashboardModel.urlExpiry = req.body.urlExpiry
            shareDashboardModel.createdBy = req.userDetails.id;

            const result = await Container.get(DataSource).manager.save(shareDashboardModel);

            this.setStatus(201)

            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: result });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('share/:id')
    async getSharingInfo(@Path() id: string): Promise<any> {
        try {
            const result = await Container.get(DataSource).manager.findOne(ShareDashboard, {
                where: { dashboardId: id }, order: { createdOn: 'ASC' }
            });

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: result });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("share-dashboard/:uuid")
    async getSharedDashboardInfo(
        @Path() uuid: string
    ): Promise<any> {
        try {

            console.log(uuid,'uuiduuid');
            const responseData = {
                dashboardInfo: {},
                themeInfo: {}
            }
            const result = await Container.get(DataSource).manager.findOne(ShareDashboard, {
                where: { uuid: uuid }
            });
            console.log(result,'result');
            if (result) {
                responseData.dashboardInfo = result;

                const userResult = await Container.get(DataSource).manager.findOne(Users, {
                    where: { id: result.createdBy }
                });

                const themeResult = await Container.get(DataSource).manager.findOne(Themes, {
                    where: { id: userResult.selectedThemeId}
                });

                responseData.themeInfo = themeResult;

                const sessionUid = uuidv4();
                this.setStatus(200);
                this.setHeader(
                    "Set-Cookie",
                    `JSESSION_ID=${sessionUid}; SameSite=None; Secure; HttpOnly; Max-Age=${60 * 60
                    }; path=/dashboard/`
                );
                await Container.get(DataSource).manager.update(ShareDashboard, { uuid: uuid }, { sessionUid: sessionUid });
                return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: responseData })
            }

            this.setStatus(400);
            return CommonHelper.apiSwaggerSuccessResponse({ message: "Incorrect information provided.", })
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}

