import { ApplicationLogger } from "core/config/pino-loggers";
import { CommonHelper, ApiErrorResponse } from "utils/helpers/common.helper";
import { formBuilderTableName } from "../../../form-builder/utils/constants/config.constant";
import { DataSource } from "typeorm";
import Container from 'typedi';
import { Body, Post, Request, Route, Security, Tags, Controller } from 'tsoa';
import {ChartExecutionUtil} from "../../utils/chartExecution.util";
import dbService from "services/db.service";
import {DataRelationBuilder} from "entities";
import {MySQLExecutorUtil} from "../../../connectors/executor-utils/mySQLExecutor.util";


@Route('dashboard')
@Tags('Dynamic Dashboard')

export class CustomDashboardController extends Controller {

    @Security('bearerAuth')
    @Post('widget-builder/count')
    async getCount(
        @Request() req: any, @Body() requestBody: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };

            if (requestBody.list?.length) {
                const tableName =
                    formBuilderTableName + req.userDetails.client_id;

                for (let whereConditionJson of req.body.list) {
                    let totalCount = 0;

                    if (whereConditionJson.dataGridId) {
                        let whereCondition = [
                            `FORM_ID = '${whereConditionJson.dataGridId}'`,
                        ];
                        let query = `SELECT "ID" FROM ${tableName.toLocaleLowerCase()} WHERE ${whereCondition.join(
                            " AND "
                        )}`;
                        const results = await Container.get(DataSource).manager.query(query);
                        if (results?.length) {
                            totalCount = results.length;
                        }
                    }
                    apiResponse.data[whereConditionJson.btnId] = totalCount;
                }
            }
            this.setStatus(201)
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: apiResponse });
        } catch (error) {
            ApplicationLogger.error(
                "Error occurred in CustomDashboardController getCount::",
                error
            );
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('relation-builder-query-execute')
    async executeRelationBuilderQuery(
        @Request() req: any, @Body() requestBody: any
    ): Promise<any> {
        try {
            const apiResponse = {data: {},status: false, message: ''};
            let mysqlData: any;
            const query = requestBody.query;
            const dataRelationBuilderId = requestBody.widgetConfig.widgetConfig.form;
            let accountConfig;
            let dataRelationBuilder: any = await dbService._findQueryService(
                Container.get(DataSource).getRepository(DataRelationBuilder),
                {
                    where: { id: dataRelationBuilderId },
                    select: ["connectorId"],
                }
            );
            if(dataRelationBuilder && Array.isArray(dataRelationBuilder) && dataRelationBuilder.length > 0) {
                const reqData = {body: {widgetAccount: dataRelationBuilder[0].connectorId} }
                accountConfig = await ChartExecutionUtil.getAccountConfig(reqData);
                if(accountConfig) {
                    return await MySQLExecutorUtil.executeMYSQLQuery(query, accountConfig.accountConfigDetails);
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: apiResponse });
        } catch (error) {
            ApplicationLogger.error(
                "Error occurred in CustomDashboardController executeRelationBuilderQuery::",
                error
            );
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
