import {
    DashboardWidget,
    PublicTables,
    WidgetAccount,
} from "../../../../entities";
import {
    CommonHelper,
    ApiErrorResponse,
} from "../../../../utils/helpers/common.helper";
import { ConnectorsUtil } from "../../../../utils/connectors.util";
import { TableChart } from "./charts/tableChart";
import mysql from "mysql";
import { toLower } from "lodash";
import Container from "typedi";
import { DataSource } from "typeorm";
import { dataSource } from "core/data-source";
import moment from "moment";
import * as jsforce from "jsforce";

export class SqlController {
    private tableChart: TableChart;

    constructor() {
        this.tableChart = new TableChart();
    }

    /**
     * Get Sql Account List
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    async getSqlAccountList(req: any, res: any, next: any): Promise<any> {
        try {
            const params: any = { client_id: req.userDetails.client_id };
            let whereCondition: any = ["CLIENT_ID = :client_id"];
            if (req.body.appId && req.body.appId !== "") {
                params["appId"] = req.body.appId;
                whereCondition.push("APP_ID = :appId");
            }
            if (req.query.type && req.query.type !== "") {
                let type = req.query.type.split(",").join("','");
                whereCondition.push(`WIDGET_TYPE IN ('${type}')`);
            }
            const result = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .createQueryBuilder("WA")
                .where(whereCondition.join(" AND "), params)
                .getMany();
            const rows = [];
            result.forEach((row) => {
                rows.push({
                    ID: row.id,
                    ACCOUNT_NAME: row.accountName,
                    WIDGET_TYPE: row.widgetType,
                    CONFIG: row.config,
                });
            });
            const response = { status: true, data: null };
            if (rows && rows.length > 0) {
                response.data = rows;
            }
            res.status(200).json(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }

    /**
     * Check Query
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    async checkQuery(req: any, res: any, next: any): Promise<any> {
        try {
            const response: any = { status: true, data: [], error: null };
            let result = await this.getWidgetAccount(req);
            if (result?.length > 0) {
                const widgetConfig: any = this.jsonParse(result[0].config);
                switch (widgetConfig.dbType) {
                    case "MSSQL":
                        const mssqlData: any = await ConnectorsUtil.connect(
                            null,
                            req.body.query,
                            widgetConfig
                        );
                        if (!mssqlData.status) {
                            response.error = mssqlData.message;
                            return CommonHelper.apiSuccessResponse(res, {
                                message: null,
                                data: response,
                            });
                        }
                        response.data = [];
                        if (
                            mssqlData?.data?.recordset &&
                            mssqlData.data.recordset.length > 0
                        ) {
                            const fields = Object.keys(
                                mssqlData.data.recordset[0]
                            ).map((obj) => {
                                return { COLUMN_NAME: `${obj}` };
                            });
                            response.data = { fields };
                        }
                        return CommonHelper.apiSuccessResponse(res, {
                            message: null,
                            data: response,
                        });
                    case "MYSQL":
                        this.executeMYSQL(widgetConfig, response, res, req);
                        return;
                    default:
                        return CommonHelper.apiSuccessResponse(res, {
                            message: null,
                            data: response,
                        });
                }
            } else {
                return CommonHelper.apiSuccessResponse(res, {
                    message: null,
                    data: response,
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }

    private executeMYSQL(widgetConfig: any, response: any, res: any, req: any) {
        const accountConfig = {
            host: widgetConfig.dbHost || "",
            user: widgetConfig.dbUser || "",
            password: widgetConfig.dbPassword || "",
            database: widgetConfig.dbName || "",
        };
        const customConnection = mysql.createConnection(accountConfig);
        customConnection.connect((err: any) => {
            if (err) {
                response.error = err;
                return CommonHelper.apiSuccessResponse(res, {
                    message: null,
                    data: response,
                });
            } else {
                customConnection.query(
                    req.body.query,
                    (
                        cQueryError: { sqlMessage: any },
                        cQueryResult: any,
                        cQueryFields: any[]
                    ) => {
                        customConnection.destroy();
                        if (cQueryError) {
                            if (cQueryError.sqlMessage) {
                                response.error = cQueryError.sqlMessage;
                            } else {
                                response.error = `Something wrong. please check your query`;
                            }
                            return CommonHelper.apiSuccessResponse(res, {
                                message: null,
                                data: response,
                            });
                        }
                        let fields = this.getFields(cQueryFields);
                        response.data = { fields, cQueryFields };
                        return CommonHelper.apiSuccessResponse(res, {
                            message: null,
                            data: response,
                        });
                    }
                );
            }
        });
    }

    private getFields(cQueryFields: any[]) {
        let fields: any = [];
        if (Array.isArray(cQueryFields) && cQueryFields.length > 0) {
            fields = cQueryFields.map((obj) => {
                return { COLUMN_NAME: `${obj.name}` };
            });
        }
        return fields;
    }

    public async getWidgetAccount(req) {
        let result;
        result = await Container.get(DataSource)
            .getRepository(WidgetAccount)
            .createQueryBuilder("WA")
            .where("WA.ID = :id", { id: req.body.connector })
            .getMany();
        if (result?.length > 0 && req.body.query) {
            const widgetConfig: any = this.jsonParse(result[0].config);
            if (!widgetConfig || !widgetConfig?.dbType) {
                result = [];
            }
        } else {
            result = [];
        }
        return result;
    }
    public jsonParse(jsonStr) {
        let response = null;
        try {
            if (jsonStr) {
                response = JSON.parse(jsonStr.replace(/\\/g, ""));
            }
        } catch (error) {}
        return response;
    }

    async getDatabaseTablesWithColumnsList(req: any, res: any, next: any): Promise<any> {
        try {
            let result, widgetConfig;
            result = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .createQueryBuilder("WA")
                .where("WA.ID = :id", { id: req.params.widgetAccountId })
                .getMany();
            if (result.length > 0) {
                widgetConfig = this.jsonParse(result[0].config);
            } else {
                if(req.params.widgetAccountId === 'VIEW360TABLES') {
                    widgetConfig = {
                        dbType: process.env.DB_TYPE,
                        dbHost: process.env.DB_HOST,
                        dbName: process.env.DB_NAME,
                        dbUser: process.env.DB_USERNAME,
                        dbPassword: process.env.DB_PASSWORD,
                    };
                    return await this.getDatabaseTablesWithColumnsListForMYSQL(
                        req,
                        widgetConfig,
                        res
                    );
                } else {
                    const response = {
                        status: true,
                        data: [],
                        error: "Could not find widget.",
                    };
                    return CommonHelper.apiSuccessResponse(res, {
                        message: null,
                        data: response,
                    });
                }
            }
            if (widgetConfig?.dbType === "MSSQL") {
                return await this.getDatabaseTablesWithColumnsListForMSSQL(
                    req,
                    widgetConfig,
                    res
                );
            } else if (widgetConfig?.dbType === "MYSQL") {
                return await this.getDatabaseTablesWithColumnsListForMYSQL(
                    req,
                    widgetConfig,
                    res
                );
            } else if (widgetConfig?.dbType === "POSTGRESQL") {
                return await this.getDatabaseTablesWithColumnsListForPostgreSQL(
                    req,
                    widgetConfig,
                    res
                );
            }
            // else if (widgetConfig?.dbType === "SALESFORCE") {
            //     return await this.getDatabaseTablesWithColumnsListForSalesForce(
            //         req,
            //         widgetConfig,
            //         res
            //     );
            // }
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: { status: true, data: [] },
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }
    private async getDatabaseTablesWithColumnsListForMYSQL(
        req: any,
        widgetConfig: any,
        res: any
    ) {
        let query: any = null;
        let queryData: any ={};
        query = `SELECT TABLE_NAME, COLUMN_NAME 
                    FROM INFORMATION_SCHEMA.COLUMNS 
                    WHERE TABLE_SCHEMA ='${widgetConfig.dbName}'`;
        const customConnection = mysql.createConnection({
            host: widgetConfig.dbHost || "",
            user: widgetConfig.dbUser || "",
            password: widgetConfig.dbPassword || "",
            database: widgetConfig.dbName || "",
        });
        customConnection.connect((err: any) => {
            if (err) {
                const response = {
                    status: true,
                    data: [],
                    error: err,
                };
                return CommonHelper.apiSuccessResponse(res, {
                    message: null,
                    data: response,
                });
            } else {
                customConnection.query(
                    query,
                    queryData,
                    (cQueryError: null, cQueryResult: any) => {
                        customConnection.destroy();
                        if (cQueryError) {
                            const response = {
                                status: true,
                                data: [],
                                error: cQueryError,
                            };
                            return CommonHelper.apiSuccessResponse(res, {
                                message: null,
                                data: response,
                            });
                        } else {
                            const response = {
                                status: true,
                                data: {},
                            };
                            if (cQueryResult && cQueryResult.length > 0) {
                                const result: { [tableName: string]: string[] } = {};
                            for(let row of cQueryResult){
                                const tableName = row.TABLE_NAME;
                                const columnName = row.COLUMN_NAME;

                                if (!result[tableName]) {
                                    result[tableName] = [];
                                }
                                result[tableName].push(columnName);
                            };
                            response.data = result;
                            }
                            
                            return CommonHelper.apiSuccessResponse(res, {
                                message: null,
                                data: response,
                            });
                        }
                    }
                );        
    

    
            }
        });
    }

    private async getDatabaseTablesWithColumnsListForPostgreSQL(
        req: any,
        widgetConfig: any,
        res: any
    ) {
        let query: any = null;
        query = `SELECT table_name as "TABLE_NAME", column_name as "COLUMN_NAME" FROM information_schema.columns WHERE table_catalog = '${widgetConfig.dbName}'`;
        const customConnection = mysql.createConnection({
            host: widgetConfig.dbHost || "",
            user: widgetConfig.dbUser || "",
            password: widgetConfig.dbPassword || "",
            database: widgetConfig.dbName || "",
        });
        customConnection.connect((err: any) => {
            if (err) {
                const response = {
                    status: true,
                    data: [],
                    error: err,
                };
                return CommonHelper.apiSuccessResponse(res, {
                    message: null,
                    data: response,
                });
            } else {
                customConnection.query(
                    query,
                    (cQueryError: null, cQueryResult: any) => {
                        customConnection.destroy();
                        if (cQueryError) {
                            const response = {
                                status: true,
                                data: [],
                                error: cQueryError,
                            };
                            return CommonHelper.apiSuccessResponse(res, {
                                message: null,
                                data: response,
                            });
                        } else {
                            const response = {
                                status: true,
                                data: [],
                            };
                            if (cQueryResult && cQueryResult.length > 0) {
                                response.data = cQueryResult;
                            }
                            return CommonHelper.apiSuccessResponse(res, {
                                message: null,
                                data: response,
                            });
                        }
                    }
                );
            }
        });
    }

    private async getDatabaseTablesWithColumnsListForMSSQL(
        req: any,
        widgetConfig: any,
        res: any
    ) {
        let query: any = null;
        query = `SELECT TABLE_NAME, COLUMN_NAME 
                    FROM INFORMATION_SCHEMA.COLUMNS 
                    WHERE TABLE_CATALOG = '${widgetConfig.dbName}'`;
        const mssqlData: any = await ConnectorsUtil.connect(
            null,
            query,
            widgetConfig
        );
        if (mssqlData.status) {
            const response = {
                status: true,
                data: [],
            };
            if (mssqlData.data && mssqlData.data.recordset) {
                response.data = mssqlData.data.recordset;
            }
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        } else {
            const response = {
                status: true,
                data: [],
                error: mssqlData.message,
            };
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        }
    }

    /**
     * Get Database TableList
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    async getDatabaseTableList(req: any, res: any, next: any): Promise<any> {
        try {
            let result;
            result = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .createQueryBuilder("WA")
                .where("WA.ID = :id", { id: req.params.widgetAccountId })
                .getMany();
            const response: any = { status: true, data: [], error: null };
            if (result?.length > 0 && req.params.info) {
                if (result[0].widgetType === "VIEW360_TABLE") {
                    if (req.params.info === "fields") {
                        const publicTableColResult = await Container.get(
                            DataSource
                        ).manager.query(
                            `SHOW COLUMNS FROM ${req.params.tableName}`
                        );
                        response.data = publicTableColResult.map((p) => {
                            return { COLUMN_NAME: p.Field };
                        });
                    } else {
                        const publicTableResult = await Container.get(DataSource)
                            .getRepository(PublicTables)
                            .createQueryBuilder("WA")
                            .where("WA.CLIENT_ID = :id", {
                                id: req.userDetails.client_id,
                            })
                            .getMany();
                        response.data = publicTableResult.map((p) => {
                            return { TABLE_NAME: p.name };
                        });
                    }
                    return CommonHelper.apiSuccessResponse(res, {
                        message: null,
                        data: response,
                    });
                }
                const widgetConfig: any = this.jsonParse(result[0].config);
                if (widgetConfig?.dbType === "MSSQL") {
                    return await this.getDatabaseTableListForMSSQL(
                        req,
                        widgetConfig,
                        response,
                        res
                    );
                } else if (widgetConfig.dbType === "MYSQL") {
                    return await this.executeMySqlQuery(req, widgetConfig, res);
                } else if (widgetConfig.dbType === "SALESFORCE") {
                    return await this.getSObjectsListForSalesForce(
                        req,
                        widgetConfig,
                        response,
                        res
                    );
                }

                return CommonHelper.apiSuccessResponse(res, {
                    message: null,
                    data: response,
                });
            } else {
                if(req.params.widgetAccountId === 'VIEW360TABLES') {
                    if (req.params.info === "fields") {
                        const publicTableColResult = await Container.get(
                            DataSource
                        ).manager.query(
                            `SHOW COLUMNS FROM ${req.params.tableName}`
                        );
                        response.data = publicTableColResult.map((p) => {
                            return { COLUMN_NAME: p.Field };
                        });
                    } else {
                        const publicTableResult = await Container.get(DataSource)
                            .getRepository(PublicTables)
                            .createQueryBuilder("WA")
                            .where("WA.CLIENT_ID = :id", { id: req.userDetails.client_id })
                            .andWhere("WA.type = :type", { type: 'View360' })
                            .getMany();
                        response.data = publicTableResult.map((p) => {
                            return { TABLE_NAME: p.name };
                        });
                    }
                    return CommonHelper.apiSuccessResponse(res, {
                        message: null,
                        data: response,
                    });
                }
            }

            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }

    /**
     * Get local Database ColumnList
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    async getLocalDatabaseColumnList(
        req: any,
        res: any,
        next: any
    ): Promise<any> {
        try {
            const response: any = { status: true, data: [], error: null };
            if (req.params.tableName) {
                const result = await Container.get(DataSource).manager.query(
                    `SHOW COLUMNS FROM ${req.params.tableName}`
                );
                response.data = result.map((p) => {
                    return { COLUMN_NAME: p.Field };
                });
            }
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }

    private mysqlAfterDistroyResponse(
        cQueryError: null,
        response: any,
        res: any,
        cQueryResult: any
    ) {
        if (cQueryError) {
            response.error = cQueryError;
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        } else {
            response.data = cQueryResult;
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        }
    }

    private getQueryForMYSQLDatabaseTableList(req: any, widgetConfig: any) {
        let query: any = null;
        let queryData: any = [];
        if (req.params.info === "fields" && req.params.tableName) {
            query =
                "SELECT column_name as 'COLUMN_NAME', column_name as 'NAME' FROM information_schema.columns WHERE table_schema = ? AND table_name = ?";
            queryData = [widgetConfig.dbName, req.params.tableName];
        } else if (
            req.params.info === "gridreportdata" &&
            req.params.tableName
        ) {
            query = "SELECT * FROM " + req.params.tableName;
            queryData = [];
        } else {
            query =
                "SELECT table_name as 'TABLE_NAME' FROM information_schema.tables WHERE table_schema = ?";
            queryData = [widgetConfig.dbName];
        }
        return { query, queryData };
    }

    public accountConfig(widgetConfig) {
        let response = null;
        if (widgetConfig) {
            response = {
                host: widgetConfig.dbHost || "",
                user: widgetConfig.dbUser || "",
                password: widgetConfig.dbPassword || "",
                database: widgetConfig.dbName || "",
            };
        }
        return response;
    }

    private async getDatabaseTableListForMSSQL(
        req: any,
        widgetConfig: any,
        response: any,
        res: any
    ) {
        let query: any = null;
        if (req.params.info === "fields" && req.params.tableName) {
            query = `SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_CATALOG = '${widgetConfig.dbName}' AND TABLE_NAME = '${req.params.tableName}' ORDER BY ORDINAL_POSITION`;
        } else if (
            req.params.info === "gridreportdata" &&
            req.params.tableName
        ) {
            query = `SELECT * FROM ${req.params.tableName}`;
        } else {
            query = `SELECT table_name as 'TABLE_NAME' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = '${widgetConfig.dbName}'`;
        }
        const mssqlData: any = await ConnectorsUtil.connect(
            null,
            query,
            widgetConfig
        );
        if (mssqlData.status) {
            response.data = [];
            if (
                mssqlData.data &&
                mssqlData.data.recordset &&
                mssqlData.data.recordset.length > 0
            ) {
                response.data = mssqlData.data.recordset;
            }
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        } else {
            response.error = mssqlData.message;
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        }
    }

    executeMySqlQuery(req, widgetConfig, res) {
        return new Promise((resolve) => {
            const response = { data: [], error: null };
            const accountConfig = this.accountConfig(widgetConfig);
            const customConnection = mysql.createConnection(accountConfig);
            customConnection.connect((err: null) => {
                if (err) {
                    response.error = err;
                    resolve(
                        CommonHelper.apiSuccessResponse(res, {
                            message: null,
                            data: response,
                        })
                    );
                } else {
                    let { query, queryData } =
                        this.getQueryForMYSQLDatabaseTableList(
                            req,
                            widgetConfig
                        );
                    customConnection.query(
                        query,
                        queryData,
                        (cQueryError: null, cQueryResult: any) => {
                            customConnection.destroy();
                            resolve(
                                this.mysqlAfterDistroyResponse(
                                    cQueryError,
                                    response,
                                    res,
                                    cQueryResult
                                )
                            );
                        }
                    );
                }
            });
        });
    }

    private async getSObjectsListForSalesForce(
        req: any,
        widgetConfig: any,
        response: any,
        res: any
    ) {
        try {
            const conn = new jsforce.Connection({
                instanceUrl: widgetConfig.token.instance_url,
                accessToken: widgetConfig.token.access_token,
            });
            if (req.params.info === "fields" && req.params.tableName) {
                const fieldsData = await conn
                    .sobject(req.params.tableName)
                    .describe();
                const fields = fieldsData.fields.map((obj) => {
                    return { COLUMN_NAME: obj.name };
                });
                response.data = fields;
                /**
             * } else if (
                req.params.info === "gridreportdata" &&
                req.params.tableName
            ) {
             */
            } else {
                const sObjects = await conn.describeGlobal();
                if (sObjects?.sobjects?.length > 0) {
                    const tableList = sObjects.sobjects.map((obj) => ({
                        TABLE_NAME: obj.name,
                    }));
                    response.data = tableList;
                }
            }

            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        } catch (error) {
            return res.status(200).json({
                error: error.message,
                dbType: widgetConfig.dbType ? widgetConfig.dbType : "",
            });
        }
    }

    /**
     * Get Sql Data
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    async getSqlData(req: any, res: any, next: any): Promise<any> {
        try {
            let widgetConfig: any, widgetAccountConfig: any;
            let widgetResponse: any = {};
            let clientId = req.userDetails.client_id;
            if (
                req.body?.fromButtonWidgetAccount?.widgetType ==
                    "VIEW360_TABLE" &&
                req.body?.fromButtonQuery
            ) {
                await this.publicManualQuery(
                    { sql: { sqlQuery: req.body.fromButtonQuery } },
                    res,
                    widgetConfig,
                    clientId
                );
                return;
            }

            if (
                req.body?.fromButtonWidgetAccount?.widgetType ==
                    "RELATION_BUILDER" &&
                req.body?.fromButtonQuery
            ) {
                let fromButtonQuery = req.body.fromButtonQuery;

                if (
                    req.body?.columnName &&
                    fromButtonQuery.includes("{DATE_FILTER_COLUMN}")
                ) {
                    let nameArr = req.body.columnName.split(".");
                    if (nameArr?.length > 1 && nameArr[1]) {
                        fromButtonQuery = fromButtonQuery.replace(
                            new RegExp("{DATE_FILTER_COLUMN}", "g"),
                            `${nameArr[1]}`
                        );
                    }
                }
                if (
                    req.body?.dateRange &&
                    (fromButtonQuery.includes("{START_DATE}") ||
                        fromButtonQuery.includes("{END_DATE}"))
                ) {
                    const dateRange = JSON.parse(req.body.dateRange);

                    if (dateRange?.length === 2) {
                        fromButtonQuery = fromButtonQuery.replace(
                            new RegExp("{START_DATE}", "g"),
                            `"${await this.formatDateString(dateRange[0])}"`
                        );
                        fromButtonQuery = fromButtonQuery.replace(
                            new RegExp("{END_DATE}", "g"),
                            `"${await this.formatDateString(dateRange[1])}"`
                        );
                    }
                }

                if (
                    req.body?.fromButtonWidgetAccount?.enableConnector &&
                    req.body?.fromButtonWidgetAccount?.relationBuilderAcc
                ) {
                    const details: any = await ConnectorsUtil.connect(
                        req.body?.fromButtonWidgetAccount?.relationBuilderAcc,
                        fromButtonQuery,
                        null
                    );
                    if (details?.status) {
                        let responseData = this.buildSuccessResponse(
                            widgetConfig,
                            details.data
                        );
                        responseData["showAmount"] = true;

                        return CommonHelper.apiSuccessResponse(
                            res,
                            responseData
                        );
                    }
                    const response = {
                        status: true,
                        displayType: "error",
                        message:
                            "Error while fetching data please check your query.",
                        data: [],
                    };
                    return CommonHelper.apiSuccessResponse(res, {
                        message: null,
                        data: response,
                    });
                }
                await this.publicManualQuery(
                    { sql: { sqlQuery: fromButtonQuery } },
                    res,
                    widgetConfig,
                    clientId
                );
                return;
            }

            if (req.params.widgetId !== "preview") {
                const details: any = await this.onLoad(
                    req,
                    widgetResponse,
                    res
                );
                widgetConfig = details.widgetConfig || {};
                widgetAccountConfig = details.widgetAccountConfig || {};
                widgetResponse = details.widgetResponse;
                if (
                    details?.widgetResponse?.widgetAccount?.widgetType ===
                    "VIEW360_TABLE"
                ) {
                    console.log("VIEW360_TABLE", widgetConfig);
                    await this.publicManualQuery(
                        { sql: { sqlQuery: widgetConfig.sqlQuery } },
                        res,
                        widgetConfig,
                        clientId
                    );
                    return;
                }
            } else {
                const widgetAccountResult = await Container.get(DataSource)
                    .getRepository(WidgetAccount)
                    .createQueryBuilder("DW")
                    .where("DW.ID = :id", { id: req.body?.widgetAccount })
                    .getOne();
                if (widgetAccountResult?.widgetType === "VIEW360_TABLE") {
                    await this.publicManualQuery(
                        req.body,
                        res,
                        { html: req.body?.sql?.html },
                        clientId
                    );
                    return;
                }

                const getDetails = await this.onPreview(req, widgetResponse);
                widgetConfig = getDetails.widgetConfig;
                widgetAccountConfig = getDetails.widgetAccountConfig;
            }
            if (req.body.sourceType === "FORMS") {
                return await this.formBuilder(req, widgetConfig, res);
            } else {
                if (
                    req.body.buttonWidget &&
                    req.body.sourceType === "ACCOUNT"
                ) {
                    widgetConfig.queryBase = "ManualQuery";
                }
                if (req.body.fromButtonWidgetAccount) {
                    widgetAccountConfig = this.jsonParse(
                        req.body.fromButtonWidgetAccount.config
                    );
                }
                if (req.body.fromButtonQuery) {
                    widgetConfig.sqlQuery = req.body.fromButtonQuery;
                }
                const accountConfig =
                    this.getAccountConfigDetails(widgetAccountConfig);
                if (widgetConfig?.queryBase === "ManualQuery") {
                    await this.manualQuery(
                        widgetConfig,
                        widgetAccountConfig,
                        res,
                        accountConfig
                    );
                } else if (
                    toLower(widgetConfig?.queryBase) ===
                    toLower("FormBaseQuery")
                ) {
                    await this.formBaseQuery(
                        widgetConfig,
                        widgetAccountConfig,
                        res,
                        widgetResponse
                    );
                }
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }

    async getSqlBuilderData(req: any, res: any, next: any): Promise<any> {
        try {
            let response: any = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                status: false,
                displayType: "configure",
                message: "Widget is not configured.",
            };

            let widgetAccount = null;
            let sqlQuery = null;
            if (req.params?.widgetId === "preview") {
                widgetAccount =
                    req.body?.widgetConfig?.sql?.widgetAccount || null;
                sqlQuery = req.body.widgetConfig.sql?.query;
            } else if (req.params?.widgetId) {
                const result = await Container.get(DataSource)
                    .getRepository(DashboardWidget)
                    .createQueryBuilder("DW")
                    .where("DW.ID = :id", { id: req.params.widgetId })
                    .getOne();
                if (result?.widgetConfig) {
                    const widgetConfig = JSON.parse(result.widgetConfig);
                    if (widgetConfig?.sql?.query) {
                        sqlQuery = widgetConfig.sql.query;
                    }
                    if (widgetConfig?.sql?.widgetAccount) {
                        widgetAccount = widgetConfig.sql.widgetAccount;
                    }
                }
            }

            if (widgetAccount === "RELATION_BUILDER" && sqlQuery) {
                await this.executeSqlBuilderQuery(sqlQuery, response);
            }

            return CommonHelper.apiSuccessResponse(res, response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }

    async executeSqlBuilderQuery(sqlQuery, response) {
        let queryRunner;
        try {
            const connection = dataSource.manager.connection;
            queryRunner = connection.createQueryRunner();
            await queryRunner.connect();
            const dataResult = await queryRunner.query(
                sqlQuery + ` LIMIT 0,10`
            );
            if (dataResult?.length) {
                response.data = dataResult;
            }

            const totalResult = await queryRunner.query(sqlQuery);
            if (totalResult?.length) {
                response.recordsTotal = totalResult.length;
                response.recordsFiltered = totalResult.length;
            }

            response.displayType = "TABLE";
            response.message = "Successfully executed.";
            response.status = true;
        } catch (error) {
            // Handle bettor ways of throwing errors
            console.log(error);
        } finally {
            // Release the query runner
            await queryRunner.release();
        }
    }

    async getUniqueColumn(req: any, res: any, next: any): Promise<any> {
        let queryRunner;
        try {
            const response = {
                data: [],
                status: false,
            };

            if (req.body.column.ColumnName && req.body?.column?.TableName) {
                const connection = dataSource.manager.connection;
                queryRunner = connection.createQueryRunner();
                await queryRunner.connect();
                const dataResult = await queryRunner.query(
                    `SELECT DISTINCT \`${req.body.column.ColumnName}\` FROM \`${
                        req.body.column.TableName
                    }\` ${
                        req.body?.searchText
                            ? "LIKE '" + req.body.searchText + "'"
                            : ""
                    }`
                );
                if (dataResult?.length) {
                    response.data = [];
                    dataResult.forEach((e: any) => {
                        for (let key in e) {
                            response.data.push(e[key]);
                        }
                    });
                    response.status = true;
                }
            }

            return CommonHelper.apiSuccessResponse(res, response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        } finally {
            // Release the query runner
            await queryRunner.release();
        }
    }

    private async onLoad(req: any, widgetResponse: any, res) {
        let result, widgetConfig, widgetAccountConfig;
        result = await Container.get(DataSource)
            .getRepository(DashboardWidget)
            .createQueryBuilder("DW")
            .leftJoinAndSelect("DW.widgetAccount", "widgetAccount")
            .where("DW.ID = :id", { id: req.params.widgetId })
            .getMany();
        if (result.length > 0) {
            widgetResponse = result[0];
            if (widgetResponse.isConfigured <= 0) {
                const response = {
                    status: false,
                    displayType: "configure",
                    message: "Widget is not configured.",
                    data: [],
                };
                return CommonHelper.apiSuccessResponse(res, response);
            }
            widgetConfig = this.jsonParse(widgetResponse.widgetConfig);
            if(widgetConfig.properties.sourceType === 'VIEW360TABLES') {
                widgetAccountConfig = {
                    dbType: process.env.DB_TYPE,
                    dbHost: process.env.DB_HOST,
                    dbName: process.env.DB_NAME,
                    dbUser: process.env.DB_USERNAME,
                    dbPassword: process.env.DB_PASSWORD,
                };
            } else {
                widgetAccountConfig = this.jsonParse(widgetResponse.widgetAccount?.config);
            }

        } else {
            const response = {
                status: false,
                displayType: "error",
                message: "Could not find widget.",
                data: [],
            };
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        }
        return { widgetConfig, widgetAccountConfig, widgetResponse };
    }

    // private async formBaseQuery(
    //     widgetConfig,
    //     widgetAccountConfig,
    //     res,
    //     widgetResponse
    // ) {
    //     if (widgetAccountConfig.dbType === "MYSQL") {
    //         const rules = widgetConfig.filterRules?.rules
    //             ? widgetConfig.filterRules.rules
    //             : "";
    //         const condition = widgetConfig.filterRules?.condition
    //             ? widgetConfig.filterRules.condition
    //             : "";
    //         const columns = this.removeDataTypeFromColumn(widgetConfig.columns);
    //         let query = this.buildMYSQLQuery(
    //             rules,
    //             condition,
    //             widgetConfig.tableName,
    //             columns
    //         );
    //         const widgetResult: any = await ConnectorsUtil.connect(
    //             widgetResponse.widgetAccount,
    //             query,
    //             widgetAccountConfig
    //         );
    //         const response = {
    //             status: true,
    //             displayType: "table",
    //             message: "Record found.",
    //             widgetConfig,
    //             data: widgetResult.data,
    //             updatedOn: moment.utc().format("MM-DD-YYYY HH:mm:ss"),
    //         };
    //         return CommonHelper.apiSuccessResponse(res, response);
    //     }
    // }

    private async formBaseQuery(
        widgetConfig: any,
        widgetAccountConfig: any,
        res: any,
        widgetResponse: any
    ) {
        try {
            // Check if the database type is MYSQL
            if (widgetAccountConfig.dbType.toLowerCase() === "MYSQL".toLowerCase()) {
                const query = this.buildFormBaseQuery(widgetConfig);

                // Execute the query and get the result
                const widgetResult = await this.executeQuery(
                    widgetResponse.widgetAccount,
                    query,
                    widgetAccountConfig
                );
                let response = null;
                if (widgetResult?.status) {
                // Prepare the response object
                    response = this.buildSuccessResponse(
                    widgetConfig,
                    widgetResult.data
                );
                } else {
                    let msg = "Error while fetching data please check your query.";
                    if (widgetResult?.message) {
                        msg = widgetResult.message;
                    }
                    response = {
                        status: false,
                        displayType: "error",
                        message: msg,
                        data: [],
                    };
                }

                // Send the response
                return CommonHelper.apiSuccessResponse(res, response);
            }
        } catch (error) {
            // Error handling logic can be added here
            return CommonHelper.apiErrorResponse(
                res,
                error.message || "Error processing query."
            );
        }
    }

    private buildFormBaseQuery(widgetConfig: any): string {
        const rules = widgetConfig.filterRules?.rules || "";
        const condition = widgetConfig.filterRules?.condition || "";
        const columns = this.removeDataTypeFromColumn(widgetConfig.columns);
        return this.buildMYSQLQuery(
            rules,
            condition,
            widgetConfig.tableName,
            columns,
            widgetConfig?.joinList
        );
    }

    private async executeQuery(
        widgetAccount: any,
        query: string,
        widgetAccountConfig: any
    ): Promise<any> {
        return await ConnectorsUtil.connect(
            widgetAccount,
            query,
            widgetAccountConfig
        );
    }

    private buildSuccessResponse(widgetConfig: any, widgetResult: any): any {
        return {
            status: true,
            displayType: "table",
            message: "Record found.",
            widgetConfig,
            data: widgetResult,
            updatedOn: moment.utc().format("MM-DD-YYYY HH:mm:ss"),
        };
    }

    private async manualQuery(
        widgetConfig,
        widgetAccountConfig,
        res,
        accountConfig
    ) {
        if (widgetAccountConfig?.dbType === "MSSQL") {
            const mssqlConnector: any = await ConnectorsUtil.connect(
                null,
                widgetConfig.sqlQuery,
                widgetAccountConfig
            );
            if (mssqlConnector.status) {
                const response = this.buildSuccessResponse(widgetConfig, []);
                if (this.checkMssqlConnector(mssqlConnector)) {
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    response.data = mssqlConnector.data.recordset;
                }
                return CommonHelper.apiSuccessResponse(res, {
                    message: null,
                    data: response,
                });
            } else {
                const response = {
                    status: true,
                    displayType: "error",
                    message: mssqlConnector.message,
                    data: [],
                };
                return CommonHelper.apiSuccessResponse(res, {
                    message: null,
                    data: response,
                });
            }
        } else if (widgetAccountConfig?.dbType === "MYSQL") {
            const customConnection = mysql.createConnection(accountConfig);
            customConnection.connect((err: any) => {
                if (err) {
                    this.onDistroySendError(err, res);
                } else {
                    let query = widgetConfig.sqlQuery;
                    customConnection.query(
                        query,
                        (error: any, results: any, fields: any) => {
                            customConnection.destroy();
                            this.onDestroySendErrorMYSQL(
                                error,
                                res,
                                results,
                                widgetConfig
                            );
                        }
                    );
                }
            });
        }
    }
    private async publicManualQuery(
        reqBody: any,
        res: any,
        widgetConfigData: any,
        clientId = null
    ) {
        try {
            const sqlQuery = this.buildSQLQuery(
                reqBody,
                widgetConfigData,
                clientId
            );
            if (!sqlQuery) {
                throw new Error("SQL query could not be built.");
            }

            const results = await this.executeSQLQuery(sqlQuery);

            this.onDestroySendErrorMYSQL(null, res, results, widgetConfigData);
        } catch (error) {
            this.onDestroySendErrorMYSQL(error, res, null, widgetConfigData);
        }
    }

    private buildSQLQuery(
        reqBody: any,
        widgetConfigData: any,
        clientId: any
    ): string | null {
        if (reqBody?.sql?.sqlQuery) {
            return this.buildDirectSQLQuery(reqBody.sql.sqlQuery, clientId);
        } else {
            return this.buildWidgetSQLQuery(reqBody?.sql, widgetConfigData);
        }
    }

    private buildDirectSQLQuery(sqlQuery: string, clientId: any): string {
        if (sqlQuery.includes("ocr_reader")) {
            return `${sqlQuery} AND ocr_reader.CLIENT_ID = ${clientId}`;
        }
        return sqlQuery;
    }

    private buildWidgetSQLQuery(
        widgetConfig: any,
        widgetConfigData: any
    ): string | null {
        if (widgetConfig?.queryBase !== "FormBaseQuery") {
            widgetConfig = widgetConfigData;
        }

        if (widgetConfig?.queryBase === "FormBaseQuery") {
            const rules = widgetConfig?.filterRules?.rules || "";
            const condition = widgetConfig?.filterRules?.condition || "";
            const columns = this.removeDataTypeFromColumn(
                widgetConfig?.columns
            );

            return this.buildMYSQLQuery(
                rules,
                condition,
                widgetConfig?.tableName,
                columns
            );
        }

        return null;
    }

    private async executeSQLQuery(query: string): Promise<any> {
        return await Container.get(DataSource).manager.query(query);
    }

    // private async publicManualQuery(
    //     reqBody: any,
    //     res: any,
    //     widgetConfigData: any,
    //     clientId = null
    // ) {
    //     let results: any = null;
    //     if (reqBody?.sql?.sqlQuery) {
    //         if (reqBody.sql.sqlQuery.includes("ocr_reader")) {
    //             reqBody.sql.sqlQuery +=
    //                 " AND ocr_reader.CLIENT_ID = " + clientId;
    //         }
    //         results = await Container.get(DataSource).manager.query(
    //             reqBody.sql.sqlQuery
    //         );
    //     } else {
    //         let widgetConfig = reqBody?.sql;
    //         if (reqBody?.sql.queryBase !== "FormBaseQuery") {
    //             widgetConfig = widgetConfigData;
    //         }
    //         if (widgetConfig.queryBase === "FormBaseQuery") {
    //             const rules = widgetConfig.filterRules?.rules
    //                 ? widgetConfig.filterRules.rules
    //                 : "";
    //             const condition = widgetConfig.filterRules?.condition
    //                 ? widgetConfig.filterRules.condition
    //                 : "";
    //             const columns = this.removeDataTypeFromColumn(
    //                 widgetConfig?.columns
    //             );
    //             let query = this.buildMYSQLQuery(
    //                 rules,
    //                 condition,
    //                 widgetConfig?.tableName,
    //                 columns
    //             );
    //             console.log(query, "eeer+++++");
    //             results = await Container.get(DataSource).manager.query(query);
    //         }
    //     }
    //     this.onDistroySendErrorMYSQL(null, res, results, widgetConfigData);
    // }
    private onDestroySendErrorMYSQL(error, res, results, widgetConfig) {
        if (error) {
            const response = {
                status: true,
                displayType: "error",
                message: "Error while fetching data please check your query.",
                data: [],
            };
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        } else {
            const response = this.buildSuccessResponse(widgetConfig, results);
            return CommonHelper.apiSuccessResponse(res, response);
        }
    }

    private checkMssqlConnector(mssqlConnector: any) {
        return mssqlConnector?.data?.recordset?.length > 0;
    }

    private async formBuilder(req: any, widgetConfig, res: any) {
        let tableResult = await this.tableChart.tableExecution(req);
        if (tableResult?.data?.length && tableResult?.status) {
            const response = this.buildSuccessResponse(
                widgetConfig,
                tableResult.data
            );
            return CommonHelper.apiSuccessResponse(res, response);
        } else {
            const response = {
                status: true,
                displayType: "table",
                message: tableResult.message,
                data: [],
                widgetConfig,
            };
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        }
    }
    private async onDistroySendError(error, res) {
        if (error) {
            const response = {
                status: true,
                displayType: "error",
                message: "Error while fetching data please check your query.",
                data: [],
            };
            return CommonHelper.apiSuccessResponse(res, {
                message: null,
                data: response,
            });
        }
    }

    private async onPreview(req: any, widgetResponse: any) {
        const widgetConfig = req.body.sql ? req.body.sql : {};
        let queryResponse;
        let widgetAccountConfig;
        if(req.body.widgetAccount === 'VIEW360TABLES') {
            widgetAccountConfig = {
                dbType: process.env.DB_TYPE,
                dbHost: process.env.DB_HOST,
                dbName: process.env.DB_NAME,
                dbUser: process.env.DB_USERNAME,
                dbPassword: process.env.DB_PASSWORD,
            };
        } else {
            queryResponse  = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .findOne({ where: { id: req.body.widgetAccount } });
            widgetAccountConfig = queryResponse.config ? JSON.parse(queryResponse.config) : {};
        }

        widgetResponse.widgetAccount = queryResponse;
        return { widgetConfig, widgetAccountConfig };
    }

    private getAccountConfigDetails(widgetAccountConfig) {
        let accountConfig = {};
        if (widgetAccountConfig) {
            accountConfig = {
                multipleStatements: true,
                host: widgetAccountConfig.dbHost || "",
                user: widgetAccountConfig.dbUser || "",
                password: widgetAccountConfig.dbPassword || "",
                database: widgetAccountConfig.dbName || "",
            };
        }
        return accountConfig;
    }

    public decodeQuery(rules, condition) {
        let expression = " ";
        for (let i = 0; i < rules.length; i++) {
            let item = rules[i];
            if (item !== null) {
                item.operator = this.assignOperatorSymbol(item.operator);
                expression =
                    expression +
                    this.mergeString(
                        "(",
                        item.field,
                        item.operator,
                        item.value,
                        ")",
                        item.isDate ? item.isDate : false
                    );
                if (i != rules.length - 1) {
                    expression = expression + " " + condition + " ";
                }
            }
        }
        return expression;
    }

    public mergeString(bracket1, field, operator, value, bracket2, isDate) {
        const dataType = typeof value;
        let mergedString;
        if (!isDate) {
            if (dataType === "number") {
                mergedString = this.numberOperator(
                    bracket1,
                    field,
                    operator,
                    value,
                    bracket2
                );
            } else if (dataType === "string") {
                mergedString = this.stringOperator(
                    bracket1,
                    field,
                    operator,
                    value,
                    bracket2
                );
            }
        } else {
            const date = new Date(value);
            const year = date.toLocaleString("default", { year: "numeric" });
            const month = date.toLocaleString("default", { month: "2-digit" });
            const day = date.toLocaleString("default", { day: "2-digit" });
            const formattedDate = year + "-" + month + "-" + day;
            mergedString =
                bracket1 +
                " " +
                "date(" +
                field +
                ")" +
                " " +
                operator +
                " " +
                "date('" +
                formattedDate +
                "')" +
                " " +
                bracket2;
        }
        return mergedString;
    }
    public stringOperator(bracket1, field, operator, value, bracket2) {
        let mergedString = "";
        if (operator === "IS NOT NULL" || operator === "IS NULL") {
            mergedString =
                bracket1 + " " + field + " " + operator + " " + bracket2;
        } else if (operator === "LIKE" || operator === "NOT LIKE") {
            mergedString =
                bracket1 +
                " " +
                field +
                " " +
                operator +
                " '%" +
                value +
                "%' " +
                bracket2;
        } else {
            mergedString =
                bracket1 +
                " " +
                field +
                " " +
                operator +
                " '" +
                value +
                "' " +
                bracket2;
        }
        return mergedString;
    }
    public numberOperator(bracket1, field, operator, value, bracket2) {
        let mergedString = "";
        if (operator === "IS NOT NULL" || operator === "IS NULL") {
            mergedString =
                bracket1 + " " + field + " " + operator + " " + bracket2;
        } else if (operator === "LIKE" || operator === "NOT LIKE") {
            mergedString = `${bracket1} ${field} ${operator} ${value} ${bracket2}`;
        } else {
            mergedString = `${bracket1} ${field} ${operator} ${value} ${bracket2}`;
        }
        return mergedString;
    }

    public buildMYSQLQuery(rules, condition, tableName, columns, joinList: any = []) { 
        let joinColumns = columns.join(",");
        let expression = this.decodeQuery(rules, condition);
        let joinQuery = this.buildJoinQuery(joinList);
        
        let query;
        if (rules && rules.length > 0) {
            query = `SELECT ${joinColumns} FROM ${tableName} ${joinQuery} WHERE ${expression}`;
        } else {
            query = `SELECT ${joinColumns} FROM ${tableName} ${joinQuery}`;
        }
        return query;
    }

    public buildJoinQuery(joinList) {
        let query = "";

        if (joinList?.length) {
            query = joinList.filter((j) => (j?.sourceColumn && j?.targetColumn && j?.joinType && j?.joinTable)).map((j) => {
                let tableNameSplit = j.sourceColumn.split(".");
                let tableName = tableNameSplit[0];
                return `${j.joinType} JOIN ${tableName} ON ${j.sourceColumn} = ${j.targetColumn}`;
            }).join(" ");
        }
        return query;
    }

    public assignOperatorSymbol(sign) {
        let operatorSign;
        switch (sign) {
            case "≠":
                operatorSign = "!=";
                break;
            case "!∅":
                operatorSign = "IS NOT NULL";
                break;
            case "∅":
                operatorSign = "IS NULL";
                break;
            case "∈":
                operatorSign = "LIKE";
                break;
            case "∉":
                operatorSign = "NOT LIKE";
                break;
            case ">":
                operatorSign = ">";
                break;
            case "<":
                operatorSign = "<";
                break;
            case "≤":
                operatorSign = "<=";
                break;
            case "≥":
                operatorSign = ">=";
                break;
            default:
                operatorSign = "=";
                break;
        }
        return operatorSign;
    }

    public removeDataTypeFromColumn(columnList) {
        let columns = [];
        columnList.forEach((item) => {
            columns.push(this.splitText(item));
        });
        return columns;
    }
    public splitText(text) {
        return text.split("(")[0].trim();
    }

    public async formatColumnString(columnString) {
        // Check if the string contains a period
        if (columnString.includes(".")) {
            // Split the input string by the period
            const parts = columnString.split(".");

            // Wrap each part with backticks
            const formattedParts = parts.map((part) => `\`${part}\``);

            // Join the wrapped parts with a period
            return formattedParts.join(".");
        }

        // If no period is found, return the original string wrapped in backticks
        return `\`${columnString}\``;
    }
    public async formatDateString(dateString) {
        // Parse the input date string into a JavaScript Date object
        const date = new Date(dateString);

        // Extract the month, day, and year from the Date object
        const month = date.getMonth() + 1; // getMonth() returns 0-11
        const day = date.getDate();
        const year = date.getFullYear();

        // Format the date as MM/DD/YYYY
        return `${month}/${day}/${year}`;
    }
}
