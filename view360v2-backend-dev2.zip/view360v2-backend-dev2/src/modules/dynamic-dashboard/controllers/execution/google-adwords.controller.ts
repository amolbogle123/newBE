import moment from "moment/moment";
import fetch from "node-fetch";
import {
    Body,
    Controller,
    Middlewares,
    Post,
    Request,
    Route,
    Security,
    Tags
} from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { DashboardWidget } from "../../../../entities";
import { commonMiddleware } from "../../../../middlewares/common.middleware";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../../utils/helpers/common.helper";
import { MissedSignInOffUtil } from "../../../../utils/missed-sign-in-off.util";

const request = require("request");
@Route("dashboard")
@Tags("Dynamic Dashboard")
export class GoogleAdwordsController extends Controller {
    /**
     *
     * get Google Details
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Post("google-adword-widget/:widgetId/:drillDownLevel")
    @Middlewares(commonMiddleware)
    async getGoogleAdwordDetails(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
                updatedOn: "",
                widgetConfig: null,
            };
            const widgetResponse: any = await this.getWidgetConfig(req);
            if (widgetResponse.length <= 0) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
            let widgetConfig = this.parseJSON(widgetResponse[0].widgetConfig);
            widgetConfig = await this.drillDownfunction(
                widgetConfig,
                req.params
            );
            let accountConfig: any;
            if (requestBody.dateRange.length > 0) {
                accountConfig = requestBody;
                widgetConfig.campaignId = requestBody.token.campaignId;
                widgetConfig.accountId = requestBody.token.accountId;
                widgetConfig.resourceId = requestBody.token.resourceId;
            } else {
                let accountArr = {
                    token: { viewId: "" },
                    widgetAccount: "",
                    dateRange: [],
                };
                accountArr.token = this.parseJSON(
                    widgetResponse[0]?.widgetAccount.config
                );
                accountArr.widgetAccount = widgetResponse[0]?.widgetAccount.id;
                accountArr.token.viewId = widgetConfig.viewId;
                accountConfig = accountArr;
            }
            const token = await this.checkTokenValidityAdword(
                accountConfig.token,
                accountConfig.widgetAccount
            );
            if (token === undefined) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }

            //table column formula start
            let accountConfigForCompare: any =
                await this.setDateRangeAsPerCompareFormula(
                    widgetConfig,
                    accountConfig
                );
            //table column formula end

            if (widgetConfig.metric) {
                const result = await this.getGoogleAdApiResults(
                    widgetConfig,
                    accountConfig,
                    token,
                    requestBody,
                    false
                );
                await this.fetchPrevDataPerFormulaAndUpdateResult(
                    accountConfigForCompare,
                    widgetConfig,
                    token,
                    requestBody,
                    result
                );
                if (result?.results) {
                    this.setStatus(200);
                    response.status = true;
                    response.data = result.results;
                    response.widgetConfig = widgetConfig;
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                } else {
                    response.status = true;
                    response.data = result;
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                }
            } else {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Post("google-adword-widget/preview/:widgetId/:drillDownLevel")
    async getGoogleAdwordDetailsPreview(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
                widgetConfig: null,
            };
            let config = JSON.stringify(requestBody.widgetConfig);
            let widgetConfig = JSON.parse(config);
            widgetConfig = await this.drillDownfunction(
                widgetConfig,
                req.params
            );
            if (req.params.drillDownLevel == 1) {
                widgetConfig.drilldown.viewId = widgetConfig.viewId;
                widgetConfig = widgetConfig.drilldown;
                widgetConfig.chartType = widgetConfig.formChart.chartType;
                widgetConfig.dimensions = widgetConfig.formChart.dimensions;
                widgetConfig.metric = widgetConfig.formChart.metric;
                widgetConfig.orderBy = widgetConfig.formChart.orderBy;
                widgetConfig.start_date = widgetConfig.formChart.start_date;
                widgetConfig.end_date = widgetConfig.formChart.end_date;
            } else if (req.params.drillDownLevel == 2) {
                widgetConfig.drilldown.drilldown.viewId = widgetConfig.viewId;
                widgetConfig = widgetConfig.drilldown.drilldown;
                widgetConfig.chartType = widgetConfig.formChart.chartType;
                widgetConfig.dimensions = widgetConfig.formChart.dimensions;
                widgetConfig.metric = widgetConfig.formChart.metric;
                widgetConfig.orderBy = widgetConfig.formChart.orderBy;
                widgetConfig.start_date = widgetConfig.formChart.start_date;
                widgetConfig.end_date = widgetConfig.formChart.end_date;
            }
            let accountConfig: any;
            if (requestBody.dateRange.length > 0) {
                accountConfig = requestBody;
                accountConfig.widgetAccount = requestBody?.widgetAccount.id;
                widgetConfig.campaignId = requestBody.token.campaignId;
                widgetConfig.accountId = requestBody.token.accountId;
            } else {
                let accountArr = {
                    token: { viewId: "" },
                    widgetAccount: "",
                    dateRange: [],
                };
                accountArr.token = JSON.parse(
                    JSON.stringify(requestBody?.widgetAccount.config)
                );
                accountArr.widgetAccount = requestBody?.widgetAccount.id;
                if (widgetConfig.viewId != "") {
                    accountArr.token.viewId = widgetConfig.viewId;
                }
                accountConfig = accountArr;
            }
            const token = await this.checkTokenValidityAdword(
                accountConfig.token,
                accountConfig.widgetAccount
            );
            if (token === undefined) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
            //table column formula start
            let accountConfigForCompare: any =
                await this.setDateRangeAsPerCompareFormula(
                    widgetConfig,
                    accountConfig
                );
            //table column formula end
            if (widgetConfig.metric) {
                const result = await this.getGoogleAdApiResults(
                    widgetConfig,
                    accountConfig,
                    token,
                    requestBody,
                    false
                );
                await this.fetchPrevDataPerFormulaAndUpdateResult(
                    accountConfigForCompare,
                    widgetConfig,
                    token,
                    requestBody,
                    result
                );
                if (result?.results) {
                    this.setStatus(200);
                    response.status = true;
                    response.data = result.results;
                    response.widgetConfig = widgetConfig;
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                } else {
                    response.status = true;
                    response.data = result;
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                }
            } else {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     *
     * get Google Details
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Post("google-adword-top-performance/:widgetId")
    @Middlewares(commonMiddleware)
    async getGoogleAdwordtopPerformanceDetails(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
                updatedOn: "",
                widgetConfig: null,
            };
            const widgetResponse: any = await this.getWidgetConfig(req);
            if (widgetResponse.length <= 0) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
            let widgetConfig = this.parseJSON(widgetResponse[0].widgetConfig);
            let accountConfig: any;
            if (requestBody?.dateRange?.length > 0) {
                accountConfig = requestBody;
                widgetConfig.campaignId = requestBody.token.campaignId;
                widgetConfig.accountId = requestBody.token.accountId;
                widgetConfig.resourceId = requestBody.token.resourceId;
            } else {
                let accountArr = {
                    token: { viewId: "" },
                    widgetAccount: "",
                    dateRange: [],
                };
                accountArr.token = this.parseJSON(
                    widgetResponse[0]?.widgetAccount.config
                );
                accountArr.widgetAccount = widgetResponse[0]?.widgetAccount.id;
                accountArr.token.viewId = widgetConfig.viewId;
                accountConfig = accountArr;
            }
            const token = await this.checkTokenValidityAdword(
                accountConfig.token,
                accountConfig.widgetAccount
            );
            console.log(token, "token");

            if (token === undefined) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
            if (widgetConfig.metric) {
                const result = await this.getGoogleAdApiResults(
                    widgetConfig,
                    accountConfig,
                    token,
                    requestBody,
                    true
                );
                if (result?.results) {
                    this.setStatus(200);
                    response.status = true;
                    response.data = result.results[0];
                    response.widgetConfig = widgetConfig;
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                } else {
                    response.status = true;
                    response.data = result[0];
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                }
            } else {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    public async drillDownfunction(widgetConfig: any, param) {
        if (param.drillDownLevel == 1) {
            widgetConfig.drilldown.viewId = widgetConfig.viewId;
            widgetConfig.drilldown.accountId = widgetConfig.accountId;
            widgetConfig.drilldown.resourceId = widgetConfig.resourceId;
            widgetConfig.drilldown.campaignId = widgetConfig.campaignId;
            widgetConfig = widgetConfig.drilldown;
            widgetConfig.chartType = widgetConfig.formChart.chartType;
            widgetConfig.dimensions = widgetConfig.formChart.dimensions;
            widgetConfig.metric = widgetConfig.formChart.metric;
            widgetConfig.orderBy = widgetConfig.formChart.orderBy;
            widgetConfig.start_date = widgetConfig.formChart.start_date;
            widgetConfig.end_date = widgetConfig.formChart.end_date;
        } else if (param.drillDownLevel == 2) {
            widgetConfig.drilldown.drilldown.viewId = widgetConfig.viewId;
            widgetConfig.drilldown.drilldown.accountId = widgetConfig.accountId;
            widgetConfig.drilldown.drilldown.resourceId =
                widgetConfig.resourceId;
            widgetConfig.drilldown.drilldown.campaignId =
                widgetConfig.campaignId;
            widgetConfig = widgetConfig.drilldown.drilldown;
            widgetConfig.chartType = widgetConfig.formChart.chartType;
            widgetConfig.dimensions = widgetConfig.formChart.dimensions;
            widgetConfig.metric = widgetConfig.formChart.metric;
            widgetConfig.orderBy = widgetConfig.formChart.orderBy;
            widgetConfig.start_date = widgetConfig.formChart.start_date;
            widgetConfig.end_date = widgetConfig.formChart.end_date;
        }
        return widgetConfig;
    }

    public async setApiData(
        widgetConfig: any,
        accountConfig: any,
        requestBody: any
    ) {
        let startDate = moment(widgetConfig.start_date, "MM-DD-YYYY").format(
            "YYYY-MM-DD"
        );
        let endDate = moment(widgetConfig.end_date, "MM-DD-YYYY").format(
            "YYYY-MM-DD"
        );
        if (accountConfig.dateRange.length > 0) {
            startDate = accountConfig.dateRange[0];
            endDate = accountConfig.dateRange[1];
        }
        let fields = Object.assign([], widgetConfig.metric);
        if (typeof widgetConfig.metric === "string") {
            fields = [widgetConfig.metric];
        }
        let adPreviewIndex = fields.indexOf("ad_preview");
        if (adPreviewIndex > -1) {
            fields.push(
                "campaign.id,campaign.name, ad_group_ad.ad.type,ad_group_ad.ad.video_responsive_ad.breadcrumb1,ad_group_ad.ad.video_responsive_ad.breadcrumb2,ad_group_ad.ad.video_responsive_ad.call_to_actions,ad_group_ad.ad.video_responsive_ad.companion_banners,ad_group_ad.ad.video_responsive_ad.descriptions,ad_group_ad.ad.video_responsive_ad.headlines,ad_group_ad.ad.video_responsive_ad.long_headlines,ad_group_ad.ad.video_responsive_ad.videos,ad_group_ad.ad.video_ad.in_feed.description1,ad_group_ad.ad.video_ad.in_feed.description2,ad_group_ad.ad.video_ad.in_feed.headline,ad_group_ad.ad.video_ad.in_feed.thumbnail,ad_group_ad.ad.video_ad.in_stream.action_button_label,ad_group_ad.ad.video_ad.in_stream.action_headline,ad_group_ad.ad.video_ad.in_stream.companion_banner.asset,ad_group_ad.ad.video_ad.non_skippable.action_button_label,ad_group_ad.ad.video_ad.non_skippable.action_headline,ad_group_ad.ad.video_ad.non_skippable.companion_banner.asset,ad_group_ad.ad.video_ad.out_stream.description,ad_group_ad.ad.video_ad.out_stream.headline,ad_group_ad.ad.responsive_search_ad.path2,ad_group_ad.ad.shopping_comparison_listing_ad.headline,ad_group_ad.ad.shopping_product_ad,ad_group_ad.ad.shopping_smart_ad,ad_group_ad.ad.smart_campaign_ad.descriptions,ad_group_ad.ad.smart_campaign_ad.headlines,ad_group_ad.ad.system_managed_resource_source,ad_group_ad.ad.text_ad.description1,ad_group_ad.ad.text_ad.description2,ad_group_ad.ad.text_ad.headline,ad_group_ad.ad.tracking_url_template,ad_group_ad.ad.travel_ad,ad_group_ad.ad.url_collections,ad_group_ad.ad.url_custom_parameters,ad_group_ad.ad.video_ad.bumper.action_button_label,ad_group_ad.ad.video_ad.bumper.action_headline,ad_group_ad.ad.video_ad.bumper.companion_banner.asset,ad_group_ad.ad.responsive_display_ad.headlines,ad_group_ad.ad.responsive_display_ad.logo_images,ad_group_ad.ad.responsive_display_ad.long_headline,ad_group_ad.ad.responsive_display_ad.main_color,ad_group_ad.ad.responsive_display_ad.marketing_images,ad_group_ad.ad.responsive_display_ad.price_prefix,ad_group_ad.ad.responsive_display_ad.promo_text,ad_group_ad.ad.responsive_display_ad.square_logo_images,ad_group_ad.ad.responsive_display_ad.square_marketing_images,ad_group_ad.ad.responsive_display_ad.youtube_videos,ad_group_ad.ad.responsive_search_ad.descriptions,ad_group_ad.ad.responsive_search_ad.headlines,ad_group_ad.ad.responsive_search_ad.path1,ad_group_ad.ad.local_ad.headlines,ad_group_ad.ad.local_ad.logo_images,ad_group_ad.ad.local_ad.marketing_images,ad_group_ad.ad.local_ad.path1,ad_group_ad.ad.local_ad.path2,ad_group_ad.ad.local_ad.videos,ad_group_ad.ad.name,ad_group_ad.ad.resource_name,ad_group_ad.ad.responsive_display_ad.accent_color,ad_group_ad.ad.responsive_display_ad.allow_flexible_color,ad_group_ad.ad.responsive_display_ad.business_name,ad_group_ad.ad.responsive_display_ad.call_to_action_text,ad_group_ad.ad.responsive_display_ad.control_spec.enable_asset_enhancements,ad_group_ad.ad.responsive_display_ad.control_spec.enable_autogen_video,ad_group_ad.ad.responsive_display_ad.descriptions,ad_group_ad.ad.responsive_display_ad.format_setting,ad_group_ad.ad.image_ad.name,ad_group_ad.ad.image_ad.pixel_height,ad_group_ad.ad.image_ad.pixel_width,ad_group_ad.ad.image_ad.preview_image_url,ad_group_ad.ad.image_ad.preview_pixel_height,ad_group_ad.ad.image_ad.preview_pixel_width,ad_group_ad.ad.legacy_app_install_ad,ad_group_ad.ad.legacy_responsive_display_ad.accent_color,ad_group_ad.ad.legacy_responsive_display_ad.allow_flexible_color,ad_group_ad.ad.legacy_responsive_display_ad.business_name,ad_group_ad.ad.legacy_responsive_display_ad.call_to_action_text,ad_group_ad.ad.legacy_responsive_display_ad.description,ad_group_ad.ad.legacy_responsive_display_ad.format_setting,ad_group_ad.ad.legacy_responsive_display_ad.logo_image,ad_group_ad.ad.legacy_responsive_display_ad.long_headline,ad_group_ad.ad.legacy_responsive_display_ad.main_color,ad_group_ad.ad.legacy_responsive_display_ad.marketing_image,ad_group_ad.ad.legacy_responsive_display_ad.price_prefix,ad_group_ad.ad.legacy_responsive_display_ad.promo_text,ad_group_ad.ad.legacy_responsive_display_ad.short_headline,ad_group_ad.ad.legacy_responsive_display_ad.square_logo_image,ad_group_ad.ad.legacy_responsive_display_ad.square_marketing_image,ad_group_ad.ad.local_ad.call_to_actions,ad_group_ad.ad.local_ad.descriptions,ad_group_ad.ad.discovery_video_responsive_ad.videos,ad_group_ad.ad.display_upload_ad.display_upload_product_type,ad_group_ad.ad.display_upload_ad.media_bundle,ad_group_ad.ad.display_url,ad_group_ad.ad.expanded_dynamic_search_ad.description,ad_group_ad.ad.expanded_dynamic_search_ad.description2,ad_group_ad.ad.expanded_text_ad.description,ad_group_ad.ad.expanded_text_ad.description2,ad_group_ad.ad.expanded_text_ad.headline_part1,ad_group_ad.ad.expanded_text_ad.headline_part2,ad_group_ad.ad.expanded_text_ad.headline_part3,ad_group_ad.ad.expanded_text_ad.path1,ad_group_ad.ad.expanded_text_ad.path2,ad_group_ad.ad.final_app_urls,ad_group_ad.ad.final_mobile_urls,ad_group_ad.ad.final_url_suffix,ad_group_ad.ad.final_urls,ad_group_ad.ad.hotel_ad,ad_group_ad.ad.id,ad_group_ad.ad.image_ad.image_asset.asset,ad_group_ad.ad.image_ad.image_url,ad_group_ad.ad.image_ad.mime_type,ad_group_ad.ad.discovery_multi_asset_ad.business_name,ad_group_ad.ad.discovery_multi_asset_ad.call_to_action_text,ad_group_ad.ad.discovery_multi_asset_ad.descriptions,ad_group_ad.ad.discovery_multi_asset_ad.headlines,ad_group_ad.ad.discovery_multi_asset_ad.lead_form_only,ad_group_ad.ad.discovery_multi_asset_ad.logo_images,ad_group_ad.ad.discovery_multi_asset_ad.marketing_images,ad_group_ad.ad.discovery_multi_asset_ad.portrait_marketing_images,ad_group_ad.ad.discovery_multi_asset_ad.square_marketing_images,ad_group_ad.ad.discovery_video_responsive_ad.breadcrumb1,ad_group_ad.ad.discovery_video_responsive_ad.breadcrumb2,ad_group_ad.ad.discovery_video_responsive_ad.business_name,ad_group_ad.ad.discovery_video_responsive_ad.call_to_actions,ad_group_ad.ad.discovery_video_responsive_ad.descriptions,ad_group_ad.ad.discovery_video_responsive_ad.headlines,ad_group_ad.ad.discovery_video_responsive_ad.logo_images,ad_group_ad.ad.discovery_video_responsive_ad.long_headlines,ad_group_ad.ad.call_ad.business_name,ad_group_ad.ad.call_ad.call_tracked,ad_group_ad.ad.call_ad.conversion_action,ad_group_ad.ad.call_ad.conversion_reporting_state,ad_group_ad.ad.call_ad.country_code,ad_group_ad.ad.call_ad.description1,ad_group_ad.ad.call_ad.description2,ad_group_ad.ad.call_ad.disable_call_conversion,ad_group_ad.ad.call_ad.headline1,ad_group_ad.ad.call_ad.headline2,ad_group_ad.ad.call_ad.path1,ad_group_ad.ad.call_ad.path2,ad_group_ad.ad.call_ad.phone_number,ad_group_ad.ad.call_ad.phone_number_verification_url,ad_group_ad.ad.device_preference,ad_group_ad.ad.discovery_carousel_ad.business_name,ad_group_ad.ad.discovery_carousel_ad.call_to_action_text,ad_group_ad.ad.discovery_carousel_ad.carousel_cards,ad_group_ad.ad.discovery_carousel_ad.description,ad_group_ad.ad.discovery_carousel_ad.headline,ad_group_ad.ad.discovery_carousel_ad.logo_image,ad_group_ad.action_items,ad_group_ad.ad.added_by_google_ads,ad_group_ad.ad.app_ad.descriptions,ad_group_ad.ad.app_ad.headlines,ad_group_ad.ad.app_ad.html5_media_bundles,ad_group_ad.ad.app_ad.images,ad_group_ad.ad.app_ad.mandatory_ad_text,ad_group_ad.ad.app_ad.youtube_videos,ad_group_ad.ad.app_engagement_ad.descriptions,ad_group_ad.ad.app_engagement_ad.headlines,ad_group_ad.ad.app_engagement_ad.images,ad_group_ad.ad.app_engagement_ad.videos,ad_group_ad.ad.app_pre_registration_ad.descriptions,ad_group_ad.ad.app_pre_registration_ad.headlines,ad_group_ad.ad.app_pre_registration_ad.images,ad_group_ad.ad.app_pre_registration_ad.youtube_videos"
            );
            fields.splice(adPreviewIndex, 1);
        }
        if (fields.indexOf("ad_group_ad.ad.name") > -1) {
            fields.push(
                " ad_group_ad.ad.type,ad_group_ad.ad.video_responsive_ad.breadcrumb1,ad_group_ad.ad.video_responsive_ad.breadcrumb2,ad_group_ad.ad.video_responsive_ad.call_to_actions,ad_group_ad.ad.video_responsive_ad.companion_banners,ad_group_ad.ad.video_responsive_ad.descriptions,ad_group_ad.ad.video_responsive_ad.headlines,ad_group_ad.ad.video_responsive_ad.long_headlines,ad_group_ad.ad.video_responsive_ad.videos,ad_group_ad.ad.video_ad.in_feed.description1,ad_group_ad.ad.video_ad.in_feed.description2,ad_group_ad.ad.video_ad.in_feed.headline,ad_group_ad.ad.video_ad.in_feed.thumbnail,ad_group_ad.ad.video_ad.in_stream.action_button_label,ad_group_ad.ad.video_ad.in_stream.action_headline,ad_group_ad.ad.video_ad.in_stream.companion_banner.asset,ad_group_ad.ad.video_ad.non_skippable.action_button_label,ad_group_ad.ad.video_ad.non_skippable.action_headline,ad_group_ad.ad.video_ad.non_skippable.companion_banner.asset,ad_group_ad.ad.video_ad.out_stream.description,ad_group_ad.ad.video_ad.out_stream.headline,ad_group_ad.ad.responsive_search_ad.path2,ad_group_ad.ad.shopping_comparison_listing_ad.headline,ad_group_ad.ad.shopping_product_ad,ad_group_ad.ad.shopping_smart_ad,ad_group_ad.ad.smart_campaign_ad.descriptions,ad_group_ad.ad.smart_campaign_ad.headlines,ad_group_ad.ad.system_managed_resource_source,ad_group_ad.ad.text_ad.description1,ad_group_ad.ad.text_ad.description2,ad_group_ad.ad.text_ad.headline,ad_group_ad.ad.tracking_url_template,ad_group_ad.ad.travel_ad,ad_group_ad.ad.url_collections,ad_group_ad.ad.url_custom_parameters,ad_group_ad.ad.video_ad.bumper.action_button_label,ad_group_ad.ad.video_ad.bumper.action_headline,ad_group_ad.ad.video_ad.bumper.companion_banner.asset,ad_group_ad.ad.responsive_display_ad.headlines,ad_group_ad.ad.responsive_display_ad.logo_images,ad_group_ad.ad.responsive_display_ad.long_headline,ad_group_ad.ad.responsive_display_ad.main_color,ad_group_ad.ad.responsive_display_ad.marketing_images,ad_group_ad.ad.responsive_display_ad.price_prefix,ad_group_ad.ad.responsive_display_ad.promo_text,ad_group_ad.ad.responsive_display_ad.square_logo_images,ad_group_ad.ad.responsive_display_ad.square_marketing_images,ad_group_ad.ad.responsive_display_ad.youtube_videos,ad_group_ad.ad.responsive_search_ad.descriptions,ad_group_ad.ad.responsive_search_ad.headlines,ad_group_ad.ad.responsive_search_ad.path1,ad_group_ad.ad.local_ad.headlines,ad_group_ad.ad.local_ad.logo_images,ad_group_ad.ad.local_ad.marketing_images,ad_group_ad.ad.local_ad.path1,ad_group_ad.ad.local_ad.path2,ad_group_ad.ad.local_ad.videos,ad_group_ad.ad.name,ad_group_ad.ad.resource_name,ad_group_ad.ad.responsive_display_ad.accent_color,ad_group_ad.ad.responsive_display_ad.allow_flexible_color,ad_group_ad.ad.responsive_display_ad.business_name,ad_group_ad.ad.responsive_display_ad.call_to_action_text,ad_group_ad.ad.responsive_display_ad.control_spec.enable_asset_enhancements,ad_group_ad.ad.responsive_display_ad.control_spec.enable_autogen_video,ad_group_ad.ad.responsive_display_ad.descriptions,ad_group_ad.ad.responsive_display_ad.format_setting,ad_group_ad.ad.image_ad.name,ad_group_ad.ad.image_ad.pixel_height,ad_group_ad.ad.image_ad.pixel_width,ad_group_ad.ad.image_ad.preview_image_url,ad_group_ad.ad.image_ad.preview_pixel_height,ad_group_ad.ad.image_ad.preview_pixel_width,ad_group_ad.ad.legacy_app_install_ad,ad_group_ad.ad.legacy_responsive_display_ad.accent_color,ad_group_ad.ad.legacy_responsive_display_ad.allow_flexible_color,ad_group_ad.ad.legacy_responsive_display_ad.business_name,ad_group_ad.ad.legacy_responsive_display_ad.call_to_action_text,ad_group_ad.ad.legacy_responsive_display_ad.description,ad_group_ad.ad.legacy_responsive_display_ad.format_setting,ad_group_ad.ad.legacy_responsive_display_ad.logo_image,ad_group_ad.ad.legacy_responsive_display_ad.long_headline,ad_group_ad.ad.legacy_responsive_display_ad.main_color,ad_group_ad.ad.legacy_responsive_display_ad.marketing_image,ad_group_ad.ad.legacy_responsive_display_ad.price_prefix,ad_group_ad.ad.legacy_responsive_display_ad.promo_text,ad_group_ad.ad.legacy_responsive_display_ad.short_headline,ad_group_ad.ad.legacy_responsive_display_ad.square_logo_image,ad_group_ad.ad.legacy_responsive_display_ad.square_marketing_image,ad_group_ad.ad.local_ad.call_to_actions,ad_group_ad.ad.local_ad.descriptions,ad_group_ad.ad.discovery_video_responsive_ad.videos,ad_group_ad.ad.display_upload_ad.display_upload_product_type,ad_group_ad.ad.display_upload_ad.media_bundle,ad_group_ad.ad.display_url,ad_group_ad.ad.expanded_dynamic_search_ad.description,ad_group_ad.ad.expanded_dynamic_search_ad.description2,ad_group_ad.ad.expanded_text_ad.description,ad_group_ad.ad.expanded_text_ad.description2,ad_group_ad.ad.expanded_text_ad.headline_part1,ad_group_ad.ad.expanded_text_ad.headline_part2,ad_group_ad.ad.expanded_text_ad.headline_part3,ad_group_ad.ad.expanded_text_ad.path1,ad_group_ad.ad.expanded_text_ad.path2,ad_group_ad.ad.final_app_urls,ad_group_ad.ad.final_mobile_urls,ad_group_ad.ad.final_url_suffix,ad_group_ad.ad.final_urls,ad_group_ad.ad.hotel_ad,ad_group_ad.ad.id,ad_group_ad.ad.image_ad.image_asset.asset,ad_group_ad.ad.image_ad.image_url,ad_group_ad.ad.image_ad.mime_type,ad_group_ad.ad.discovery_multi_asset_ad.business_name,ad_group_ad.ad.discovery_multi_asset_ad.call_to_action_text,ad_group_ad.ad.discovery_multi_asset_ad.descriptions,ad_group_ad.ad.discovery_multi_asset_ad.headlines,ad_group_ad.ad.discovery_multi_asset_ad.lead_form_only,ad_group_ad.ad.discovery_multi_asset_ad.logo_images,ad_group_ad.ad.discovery_multi_asset_ad.marketing_images,ad_group_ad.ad.discovery_multi_asset_ad.portrait_marketing_images,ad_group_ad.ad.discovery_multi_asset_ad.square_marketing_images,ad_group_ad.ad.discovery_video_responsive_ad.breadcrumb1,ad_group_ad.ad.discovery_video_responsive_ad.breadcrumb2,ad_group_ad.ad.discovery_video_responsive_ad.business_name,ad_group_ad.ad.discovery_video_responsive_ad.call_to_actions,ad_group_ad.ad.discovery_video_responsive_ad.descriptions,ad_group_ad.ad.discovery_video_responsive_ad.headlines,ad_group_ad.ad.discovery_video_responsive_ad.logo_images,ad_group_ad.ad.discovery_video_responsive_ad.long_headlines,ad_group_ad.ad.call_ad.business_name,ad_group_ad.ad.call_ad.call_tracked,ad_group_ad.ad.call_ad.conversion_action,ad_group_ad.ad.call_ad.conversion_reporting_state,ad_group_ad.ad.call_ad.country_code,ad_group_ad.ad.call_ad.description1,ad_group_ad.ad.call_ad.description2,ad_group_ad.ad.call_ad.disable_call_conversion,ad_group_ad.ad.call_ad.headline1,ad_group_ad.ad.call_ad.headline2,ad_group_ad.ad.call_ad.path1,ad_group_ad.ad.call_ad.path2,ad_group_ad.ad.call_ad.phone_number,ad_group_ad.ad.call_ad.phone_number_verification_url,ad_group_ad.ad.device_preference,ad_group_ad.ad.discovery_carousel_ad.business_name,ad_group_ad.ad.discovery_carousel_ad.call_to_action_text,ad_group_ad.ad.discovery_carousel_ad.carousel_cards,ad_group_ad.ad.discovery_carousel_ad.description,ad_group_ad.ad.discovery_carousel_ad.headline,ad_group_ad.ad.discovery_carousel_ad.logo_image,ad_group_ad.action_items,ad_group_ad.ad.added_by_google_ads,ad_group_ad.ad.app_ad.descriptions,ad_group_ad.ad.app_ad.headlines,ad_group_ad.ad.app_ad.html5_media_bundles,ad_group_ad.ad.app_ad.images,ad_group_ad.ad.app_ad.mandatory_ad_text,ad_group_ad.ad.app_ad.youtube_videos,ad_group_ad.ad.app_engagement_ad.descriptions,ad_group_ad.ad.app_engagement_ad.headlines,ad_group_ad.ad.app_engagement_ad.images,ad_group_ad.ad.app_engagement_ad.videos,ad_group_ad.ad.app_pre_registration_ad.descriptions,ad_group_ad.ad.app_pre_registration_ad.headlines,ad_group_ad.ad.app_pre_registration_ad.images,ad_group_ad.ad.app_pre_registration_ad.youtube_videos"
            );
            //ad_group_ad.ad.responsive_display_ad.headlines,ad_group_ad.ad.responsive_search_ad.headlines,
        }
        widgetConfig.metricXAxis = null;
        switch (widgetConfig.adBreakdown) {
            case "segments.date":
                fields.push("segments.date");
                widgetConfig.metricXAxis = `segments.date`;
                break;
            case "segments.month":
                fields.push("segments.month");
                widgetConfig.metricXAxis = `segments.month`;
                break;
            case "week":
                fields.push("segments.week");
                widgetConfig.metricXAxis = `segments.week`;
                break;
            case "segments.device":
                fields.push("segments.device");
                widgetConfig.metricXAxis = `segments.device`;
                break;
            case "campaign.name":
                fields.push("campaign.id");
                fields.push("campaign.name");
                widgetConfig.metricXAxis = `campaign.name`;
                break;
            // case "Ad Group":
            //     fields.push("ad_group.id");
            //     fields.push("ad_group.name");
            //     break;
            // case "Keywords":
            //     fields.push("ad_group_criterion.keyword.text");
            //     orderBy = `metrics.impressions DESC`;
            //     break;
            default:
                break;
        }
        let whereClause = [];
        if (widgetConfig.campaignId?.length > 0) {
            if (typeof widgetConfig?.campaignId === "string") {
                if (widgetConfig?.campaignId.toLowerCase() !== "all") {
                    whereClause.push(
                        `campaign.id IN ('${widgetConfig?.campaignId}')`
                    );
                }
            } else {
                let campaignValue =
                    "'" + widgetConfig.campaignId.join("','") + "'";
                whereClause.push(`campaign.id IN (${campaignValue})`);
            }
        } else if (
            requestBody.dilldownValue &&
            widgetConfig.parentSelector === "Campaign"
        ) {
            whereClause.push(`campaign.name = '${requestBody.dilldownValue}'`);
        } else if (
            requestBody.dilldownValue &&
            widgetConfig.parentSelector === "Ad Group"
        ) {
            if (fields.indexOf("ad_group.name") <= -1) {
                fields.push("ad_group.name");
            }
            whereClause.push(`ad_group.name = '${requestBody.dilldownValue}'`);
        } else if (
            requestBody.dilldownValue &&
            widgetConfig.parentSelector === "Ads"
        ) {
            if (fields.indexOf("ad_group_ad.ad.name") <= -1) {
                fields.push("ad_group_ad.ad.name");
            }
            whereClause.push(
                `ad_group_ad.ad.name = '${requestBody.dilldownValue}' OR ad_group_ad.ad.expanded_text_ad.headline_part1 = '${requestBody.dilldownValue}' OR ad_group_ad.ad.text_ad.headline = '${requestBody.dilldownValue}'`
            );
        }
        if (startDate && endDate) {
            whereClause.push(
                `segments.date BETWEEN '${startDate}' AND '${endDate}'`
            );
        }
        if (widgetConfig.adBreakdown === "Keywords") {
            whereClause.push(
                `ad_group_criterion.type = 'KEYWORD' AND campaign.status != 'REMOVED' AND ad_group_criterion.status IN ('ENABLED','PAUSED')`
            );
        }
        let resourceName = `campaign`;
        if (widgetConfig.adResource) {
            resourceName = `${widgetConfig.adResource}`;
        }

        if (
            requestBody.filterDimensions &&
            requestBody.filterDimensions.statusFilter &&
            requestBody.filterDimensions?.statusFilterValue.length > 0
        ) {
            let statusValue =
                "'" +
                requestBody.filterDimensions?.statusFilterValue.join("','") +
                "'";
            whereClause.push(`campaign.status IN (${statusValue})`);
            fields.push(`campaign.status`);
        }

        if (
            requestBody.filterDimensions &&
            requestBody.filterDimensions?.expressions &&
            requestBody.filterDimensions?.expressions?.toLowerCase() !== "all"
        ) {
            whereClause.push(
                `ad_group_criterion.keyword.text REGEXP_MATCH "(?i).*${requestBody.filterDimensions.expressions}.*"`
            );
            resourceName = `keyword_view`;
        }
        if (
            widgetConfig.properties?.filterField &&
            widgetConfig.properties?.filterValue &&
            widgetConfig.properties?.filterValue.toLowerCase() !== "all"
        ) {
            whereClause.push(
                `${widgetConfig.properties.filterField} = '${widgetConfig.properties.filterValue}'`
            );
        }
        if (
            accountConfig.filterDimensions?.country &&
            accountConfig.filterDimensions?.country.length > 0
        ) {
            let CountryArr = [];
            for (let item of accountConfig.filterDimensions?.country) {
                CountryArr.push(item.split("-")[0]);
            }

            let countryValue = "'" + CountryArr.join("','") + "'";
            whereClause.push(
                `geographic_view.country_criterion_id IN (${countryValue})`
            );
            //whereClause.push(`segments.geo_target_county = "geoTargetConstants/2840"`);
            // whereClause.push(
            //     `geographic_view.country_criterion_id =${accountConfig.filterDimensions.country}`
            // );
            //  geographic_view.country_criterion_id IN ({','.join(map(str, country_criterion_ids))})
            //${accountConfig.filterDimensions.country}'
            //whereClause.push(`geographic_view.location_type = 'LOCATION_OF_PRESENCE'`);
            resourceName = `geographic_view`;
            fields.push(`campaign.id`);
        }
        if (
            accountConfig.filterDimensions?.state &&
            accountConfig.filterDimensions?.state.length > 0
        ) {
            let StateArr = [];
            for (let item of accountConfig.filterDimensions?.state) {
                StateArr.push("geoTargetConstants/" + item);
            }
            let stateValue = "'" + StateArr.join("','") + "'";
            whereClause.push(`segments.geo_target_state IN (${stateValue})`);
            //geographic_view.country_criterion_id IN ({','.join(map(str, country_criterion_ids))})
            fields.push(`segments.geo_target_state`);
        }
        let query = `SELECT ${fields.join(",")} FROM ${resourceName}`;
        if (whereClause.length > 0) {
            query += ` WHERE ${whereClause.join(" AND ")}`;
        }

        let orderByField = fields[0];
        let orderByDirection = "ASC";
        if (widgetConfig.orderBy === "DESCENDING") {
            orderByDirection = "DESC";
        }
        if (widgetConfig.properties?.orderField) {
            orderByField = widgetConfig.properties?.orderField;
        }
        //  else {
        //     //console.log(groupOrderBy,'widdddddd',widgetConfig.adBreakdown)
        //     orderByField = groupOrderBy;
        // }
        // if(groupOrderBy!=''){
        //     fields.push(groupOrderBy);
        // }
        query += ` ORDER BY ${orderByField} ${orderByDirection}`;
        // console.log(query,'query')
        const apiPostData = {
            query,
            summary_row_setting: "NO_SUMMARY_ROW",
        };
        if (widgetConfig.resultView) {
            apiPostData.summary_row_setting = widgetConfig.resultView;
        }
        return apiPostData;
    }

    public async setApiDataTopPerformance(
        widgetConfig: any,
        accountConfig: any,
        requestBody: any
    ) {
        let startDate = moment(widgetConfig.start_date, "MM-DD-YYYY").format(
            "YYYY-MM-DD"
        );
        let endDate = moment(widgetConfig.end_date, "MM-DD-YYYY").format(
            "YYYY-MM-DD"
        );
        if (accountConfig.dateRange.length > 0) {
            startDate = accountConfig.dateRange[0];
            endDate = accountConfig.dateRange[1];
        }
        let fields = Object.assign([], widgetConfig.metric);
        if (typeof widgetConfig.metric === "string") {
            fields = [widgetConfig.metric];
        }
        fields.push(
            "campaign.id,campaign.name, ad_group_ad.ad.type,ad_group_ad.ad.video_responsive_ad.breadcrumb1,ad_group_ad.ad.video_responsive_ad.breadcrumb2,ad_group_ad.ad.video_responsive_ad.call_to_actions,ad_group_ad.ad.video_responsive_ad.companion_banners,ad_group_ad.ad.video_responsive_ad.descriptions,ad_group_ad.ad.video_responsive_ad.headlines,ad_group_ad.ad.video_responsive_ad.long_headlines,ad_group_ad.ad.video_responsive_ad.videos,ad_group_ad.ad.video_ad.in_feed.description1,ad_group_ad.ad.video_ad.in_feed.description2,ad_group_ad.ad.video_ad.in_feed.headline,ad_group_ad.ad.video_ad.in_feed.thumbnail,ad_group_ad.ad.video_ad.in_stream.action_button_label,ad_group_ad.ad.video_ad.in_stream.action_headline,ad_group_ad.ad.video_ad.in_stream.companion_banner.asset,ad_group_ad.ad.video_ad.non_skippable.action_button_label,ad_group_ad.ad.video_ad.non_skippable.action_headline,ad_group_ad.ad.video_ad.non_skippable.companion_banner.asset,ad_group_ad.ad.video_ad.out_stream.description,ad_group_ad.ad.video_ad.out_stream.headline,ad_group_ad.ad.responsive_search_ad.path2,ad_group_ad.ad.shopping_comparison_listing_ad.headline,ad_group_ad.ad.shopping_product_ad,ad_group_ad.ad.shopping_smart_ad,ad_group_ad.ad.smart_campaign_ad.descriptions,ad_group_ad.ad.smart_campaign_ad.headlines,ad_group_ad.ad.system_managed_resource_source,ad_group_ad.ad.text_ad.description1,ad_group_ad.ad.text_ad.description2,ad_group_ad.ad.text_ad.headline,ad_group_ad.ad.tracking_url_template,ad_group_ad.ad.travel_ad,ad_group_ad.ad.url_collections,ad_group_ad.ad.url_custom_parameters,ad_group_ad.ad.video_ad.bumper.action_button_label,ad_group_ad.ad.video_ad.bumper.action_headline,ad_group_ad.ad.video_ad.bumper.companion_banner.asset,ad_group_ad.ad.responsive_display_ad.headlines,ad_group_ad.ad.responsive_display_ad.logo_images,ad_group_ad.ad.responsive_display_ad.long_headline,ad_group_ad.ad.responsive_display_ad.main_color,ad_group_ad.ad.responsive_display_ad.marketing_images,ad_group_ad.ad.responsive_display_ad.price_prefix,ad_group_ad.ad.responsive_display_ad.promo_text,ad_group_ad.ad.responsive_display_ad.square_logo_images,ad_group_ad.ad.responsive_display_ad.square_marketing_images,ad_group_ad.ad.responsive_display_ad.youtube_videos,ad_group_ad.ad.responsive_search_ad.descriptions,ad_group_ad.ad.responsive_search_ad.headlines,ad_group_ad.ad.responsive_search_ad.path1,ad_group_ad.ad.local_ad.headlines,ad_group_ad.ad.local_ad.logo_images,ad_group_ad.ad.local_ad.marketing_images,ad_group_ad.ad.local_ad.path1,ad_group_ad.ad.local_ad.path2,ad_group_ad.ad.local_ad.videos,ad_group_ad.ad.name,ad_group_ad.ad.resource_name,ad_group_ad.ad.responsive_display_ad.accent_color,ad_group_ad.ad.responsive_display_ad.allow_flexible_color,ad_group_ad.ad.responsive_display_ad.business_name,ad_group_ad.ad.responsive_display_ad.call_to_action_text,ad_group_ad.ad.responsive_display_ad.control_spec.enable_asset_enhancements,ad_group_ad.ad.responsive_display_ad.control_spec.enable_autogen_video,ad_group_ad.ad.responsive_display_ad.descriptions,ad_group_ad.ad.responsive_display_ad.format_setting,ad_group_ad.ad.image_ad.name,ad_group_ad.ad.image_ad.pixel_height,ad_group_ad.ad.image_ad.pixel_width,ad_group_ad.ad.image_ad.preview_image_url,ad_group_ad.ad.image_ad.preview_pixel_height,ad_group_ad.ad.image_ad.preview_pixel_width,ad_group_ad.ad.legacy_app_install_ad,ad_group_ad.ad.legacy_responsive_display_ad.accent_color,ad_group_ad.ad.legacy_responsive_display_ad.allow_flexible_color,ad_group_ad.ad.legacy_responsive_display_ad.business_name,ad_group_ad.ad.legacy_responsive_display_ad.call_to_action_text,ad_group_ad.ad.legacy_responsive_display_ad.description,ad_group_ad.ad.legacy_responsive_display_ad.format_setting,ad_group_ad.ad.legacy_responsive_display_ad.logo_image,ad_group_ad.ad.legacy_responsive_display_ad.long_headline,ad_group_ad.ad.legacy_responsive_display_ad.main_color,ad_group_ad.ad.legacy_responsive_display_ad.marketing_image,ad_group_ad.ad.legacy_responsive_display_ad.price_prefix,ad_group_ad.ad.legacy_responsive_display_ad.promo_text,ad_group_ad.ad.legacy_responsive_display_ad.short_headline,ad_group_ad.ad.legacy_responsive_display_ad.square_logo_image,ad_group_ad.ad.legacy_responsive_display_ad.square_marketing_image,ad_group_ad.ad.local_ad.call_to_actions,ad_group_ad.ad.local_ad.descriptions,ad_group_ad.ad.discovery_video_responsive_ad.videos,ad_group_ad.ad.display_upload_ad.display_upload_product_type,ad_group_ad.ad.display_upload_ad.media_bundle,ad_group_ad.ad.display_url,ad_group_ad.ad.expanded_dynamic_search_ad.description,ad_group_ad.ad.expanded_dynamic_search_ad.description2,ad_group_ad.ad.expanded_text_ad.description,ad_group_ad.ad.expanded_text_ad.description2,ad_group_ad.ad.expanded_text_ad.headline_part1,ad_group_ad.ad.expanded_text_ad.headline_part2,ad_group_ad.ad.expanded_text_ad.headline_part3,ad_group_ad.ad.expanded_text_ad.path1,ad_group_ad.ad.expanded_text_ad.path2,ad_group_ad.ad.final_app_urls,ad_group_ad.ad.final_mobile_urls,ad_group_ad.ad.final_url_suffix,ad_group_ad.ad.final_urls,ad_group_ad.ad.hotel_ad,ad_group_ad.ad.id,ad_group_ad.ad.image_ad.image_asset.asset,ad_group_ad.ad.image_ad.image_url,ad_group_ad.ad.image_ad.mime_type,ad_group_ad.ad.discovery_multi_asset_ad.business_name,ad_group_ad.ad.discovery_multi_asset_ad.call_to_action_text,ad_group_ad.ad.discovery_multi_asset_ad.descriptions,ad_group_ad.ad.discovery_multi_asset_ad.headlines,ad_group_ad.ad.discovery_multi_asset_ad.lead_form_only,ad_group_ad.ad.discovery_multi_asset_ad.logo_images,ad_group_ad.ad.discovery_multi_asset_ad.marketing_images,ad_group_ad.ad.discovery_multi_asset_ad.portrait_marketing_images,ad_group_ad.ad.discovery_multi_asset_ad.square_marketing_images,ad_group_ad.ad.discovery_video_responsive_ad.breadcrumb1,ad_group_ad.ad.discovery_video_responsive_ad.breadcrumb2,ad_group_ad.ad.discovery_video_responsive_ad.business_name,ad_group_ad.ad.discovery_video_responsive_ad.call_to_actions,ad_group_ad.ad.discovery_video_responsive_ad.descriptions,ad_group_ad.ad.discovery_video_responsive_ad.headlines,ad_group_ad.ad.discovery_video_responsive_ad.logo_images,ad_group_ad.ad.discovery_video_responsive_ad.long_headlines,ad_group_ad.ad.call_ad.business_name,ad_group_ad.ad.call_ad.call_tracked,ad_group_ad.ad.call_ad.conversion_action,ad_group_ad.ad.call_ad.conversion_reporting_state,ad_group_ad.ad.call_ad.country_code,ad_group_ad.ad.call_ad.description1,ad_group_ad.ad.call_ad.description2,ad_group_ad.ad.call_ad.disable_call_conversion,ad_group_ad.ad.call_ad.headline1,ad_group_ad.ad.call_ad.headline2,ad_group_ad.ad.call_ad.path1,ad_group_ad.ad.call_ad.path2,ad_group_ad.ad.call_ad.phone_number,ad_group_ad.ad.call_ad.phone_number_verification_url,ad_group_ad.ad.device_preference,ad_group_ad.ad.discovery_carousel_ad.business_name,ad_group_ad.ad.discovery_carousel_ad.call_to_action_text,ad_group_ad.ad.discovery_carousel_ad.carousel_cards,ad_group_ad.ad.discovery_carousel_ad.description,ad_group_ad.ad.discovery_carousel_ad.headline,ad_group_ad.ad.discovery_carousel_ad.logo_image,ad_group_ad.action_items,ad_group_ad.ad.added_by_google_ads,ad_group_ad.ad.app_ad.descriptions,ad_group_ad.ad.app_ad.headlines,ad_group_ad.ad.app_ad.html5_media_bundles,ad_group_ad.ad.app_ad.images,ad_group_ad.ad.app_ad.mandatory_ad_text,ad_group_ad.ad.app_ad.youtube_videos,ad_group_ad.ad.app_engagement_ad.descriptions,ad_group_ad.ad.app_engagement_ad.headlines,ad_group_ad.ad.app_engagement_ad.images,ad_group_ad.ad.app_engagement_ad.videos,ad_group_ad.ad.app_pre_registration_ad.descriptions,ad_group_ad.ad.app_pre_registration_ad.headlines,ad_group_ad.ad.app_pre_registration_ad.images,ad_group_ad.ad.app_pre_registration_ad.youtube_videos"
        );

        let whereClause = [];
        if (widgetConfig.campaignId?.length > 0) {
            if (typeof widgetConfig?.campaignId === "string") {
                if (widgetConfig?.campaignId.toLowerCase() !== "all") {
                    whereClause.push(
                        `campaign.id IN ('${widgetConfig?.campaignId}')`
                    );
                }
            } else {
                let campaignValue =
                    "'" + widgetConfig.campaignId.join("','") + "'";
                whereClause.push(`campaign.id IN (${campaignValue})`);
            }
        }
        if (startDate && endDate) {
            whereClause.push(
                `segments.date BETWEEN '${startDate}' AND '${endDate}'`
            );
        }
        if (widgetConfig.adBreakdown === "Keywords") {
            whereClause.push(
                `ad_group_criterion.type = 'KEYWORD' AND campaign.status != 'REMOVED' AND ad_group_criterion.status IN ('ENABLED','PAUSED')`
            );
        }
        let resourceName = `ad_group_ad`;
        if (
            requestBody.filterDimensions &&
            requestBody.filterDimensions.statusFilter &&
            requestBody.filterDimensions?.statusFilterValue.length > 0
        ) {
            let statusValue =
                "'" +
                requestBody.filterDimensions?.statusFilterValue.join("','") +
                "'";
            whereClause.push(`campaign.status IN (${statusValue})`);
            fields.push(`campaign.status`);
        }

        if (
            requestBody.filterDimensions &&
            requestBody.filterDimensions?.expressions &&
            requestBody.filterDimensions?.expressions?.toLowerCase() !== "all"
        ) {
            whereClause.push(
                `ad_group_criterion.keyword.text REGEXP_MATCH "(?i).*${requestBody.filterDimensions.expressions}.*"`
            );
            resourceName = `keyword_view`;
        }
        if (
            widgetConfig.properties?.filterField &&
            widgetConfig.properties?.filterValue &&
            widgetConfig.properties?.filterValue.toLowerCase() !== "all"
        ) {
            whereClause.push(
                `${widgetConfig.properties.filterField} = '${widgetConfig.properties.filterValue}'`
            );
        }
        if (
            accountConfig.filterDimensions?.country &&
            accountConfig.filterDimensions?.country.length > 0
        ) {
            let CountryArr = [];
            for (let item of accountConfig.filterDimensions?.country) {
                CountryArr.push(item.split("-")[0]);
            }

            let countryValue = "'" + CountryArr.join("','") + "'";
            whereClause.push(
                `geographic_view.country_criterion_id IN (${countryValue})`
            );
            resourceName = `geographic_view`;
            fields.push(`campaign.id`);
        }
        if (
            accountConfig.filterDimensions?.state &&
            accountConfig.filterDimensions?.state.length > 0
        ) {
            let StateArr = [];
            for (let item of accountConfig.filterDimensions?.state) {
                StateArr.push("geoTargetConstants/" + item);
            }
            let stateValue = "'" + StateArr.join("','") + "'";
            whereClause.push(`segments.geo_target_state IN (${stateValue})`);
            fields.push(`segments.geo_target_state`);
        }
        let query = `SELECT ${fields.join(",")} FROM ${resourceName}`;
        if (whereClause.length > 0) {
            query += ` WHERE ${whereClause.join(" AND ")}`;
        }

        let orderByField = fields[0];
        let orderByDirection = "DESC";

        if (widgetConfig.properties?.orderField) {
            orderByField = widgetConfig.properties?.orderField;
        }

        query += ` ORDER BY ${orderByField} ${orderByDirection} LIMIT 10`;
        const apiPostData = {
            query,
            summary_row_setting: "NO_SUMMARY_ROW",
        };
        if (widgetConfig.resultView) {
            apiPostData.summary_row_setting = widgetConfig.resultView;
        }
        return apiPostData;
    }

    private async fetchPrevDataPerFormulaAndUpdateResult(
        accountConfigForCompare: any,
        widgetConfig: any,
        token: any,
        requestBody: any,
        result: any
    ) {
        if (accountConfigForCompare.length) {
            //use for of
            let wConfig = JSON.parse(JSON.stringify(widgetConfig));
            wConfig.adBreakdown = "None";
            for (let accountConfig of accountConfigForCompare) {
                const resultForCompare = await this.getGoogleAdApiResults(
                    wConfig,
                    accountConfig.accountConfig,
                    token,
                    requestBody,
                    false
                );
                if (resultForCompare?.results) {
                    if (resultForCompare?.results?.length) {
                        await result?.results?.forEach(
                            async (element, index) => {
                                if (element?.metrics) {
                                    let compareValue = parseFloat(
                                        resultForCompare?.results[0]?.metrics[
                                            accountConfig.column
                                        ]
                                    );

                                    if (compareValue) {
                                        let currentValue = parseFloat(
                                            element?.metrics[
                                                accountConfig.column
                                            ]
                                        );
                                        let changeValue =
                                            currentValue - compareValue;
                                        let percentageChange =
                                            (changeValue /
                                                Math.abs(compareValue)) *
                                            100;

                                        let change;

                                        if (percentageChange === 0) {
                                            change = "grey";
                                        } else if (percentageChange > 0) {
                                            change = "green";
                                        } else {
                                            change = "red";
                                        }
                                        let metricToAdd,
                                            metricIdToAdd,
                                            metricNameToAdd;
                                        if (
                                            accountConfig.position ===
                                            "New-Column"
                                        ) {
                                            element.metrics[
                                                accountConfig.column + "-vsPrev"
                                            ] =
                                                percentageChange.toFixed(0) +
                                                "%" +
                                                "=" +
                                                change;

                                            metricToAdd = "metrics.vsPrev";
                                            metricIdToAdd =
                                                "metrics." +
                                                accountConfig.column +
                                                "-vsPrev";
                                            metricNameToAdd =
                                                accountConfig.column +
                                                "-vsPrev";
                                            // Check if metricToAdd does not exist in widgetConfig.metric
                                            if (
                                                widgetConfig.metric.indexOf(
                                                    metricToAdd
                                                ) === -1
                                            ) {
                                                widgetConfig.metric.push(
                                                    metricToAdd
                                                );
                                            }

                                            // Check if metricIdToAdd does not exist in widgetConfig.selectedMetrics
                                            const existingMetricIndex =
                                                widgetConfig.selectedMetrics.findIndex(
                                                    (metric) =>
                                                        metric.id ===
                                                        metricIdToAdd
                                                );

                                            if (existingMetricIndex === -1) {
                                                widgetConfig.selectedMetrics.push(
                                                    {
                                                        id: metricIdToAdd,
                                                        name: metricNameToAdd,
                                                    }
                                                );
                                            }
                                        } else {
                                            //Within-Column
                                            //prefix percentage change
                                            element.metrics[
                                                accountConfig.column
                                            ] =
                                                percentageChange.toFixed(0) +
                                                "%" +
                                                "=" +
                                                change +
                                                "=" +
                                                element.metrics[
                                                    accountConfig.column
                                                ];
                                        }
                                    }
                                }
                            }
                        );
                    }
                }
            }
        }
    }

    private async setDateRangeAsPerCompareFormula(
        widgetConfig: any,
        accConfig: any
    ) {
        let accountConfigForCompare: any = [];
        let accountConfig = JSON.parse(JSON.stringify(accConfig));
        if (
            widgetConfig?.chartType === "GOOGLE_TABLE" &&
            widgetConfig?.properties?.enableTableColumnFormulae &&
            widgetConfig?.properties?.tableColumnFormulae?.length
        ) {
            await widgetConfig?.properties.tableColumnFormulae.forEach(
                async (formulae) => {
                    if (
                        formulae.formula &&
                        formulae.formula == "compare" &&
                        formulae.column &&
                        formulae.column != ""
                    ) {
                        if (
                            accountConfig?.dateRange &&
                            accountConfig?.dateRange?.length > 0
                        ) {
                            accountConfig.dateRange =
                                this.getPreviousPeriodDates(
                                    accountConfig.dateRange
                                );
                        } else {
                            accountConfig.dateRange = [
                                widgetConfig.start_date,
                                widgetConfig.end_date,
                            ];
                            accountConfig.dateRange =
                                this.getPreviousPeriodDates(
                                    accountConfig.dateRange
                                );
                        }

                        accountConfigForCompare.push({
                            column: formulae.column.replace("metrics.", ""),
                            position: formulae.position,
                            newColumnName: formulae.newColumnName
                                ? formulae.newColumnName
                                : "",
                            accountConfig: accountConfig,
                        });
                    }
                }
            );
        }
        return accountConfigForCompare;
    }
    getPreviousPeriodDates(dateRange) {
        const startDate = new Date(dateRange[0]);
        const endDate = new Date(dateRange[1]);

        // Calculate the duration in milliseconds
        const duration = endDate.getTime() - startDate.getTime();

        // Calculate the start and end dates for the previous period
        const previousEndDate = new Date(startDate.getTime() - 1); // Subtract 1 millisecond from the start date
        const previousStartDate = new Date(
            previousEndDate.getTime() - duration
        );

        // Format the dates as strings in "YYYY-MM-DD" format
        const formattedStartDate = this.formatDate(previousStartDate);
        const formattedEndDate = this.formatDate(previousEndDate);

        return [formattedStartDate, formattedEndDate];
    }

    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    }
    async getGoogleAdApiResults(
        widgetConfig: any,
        accountConfig: any,
        token: any,
        requestBody?: any,
        status?: boolean
    ) {
        let apiPostData: any;
        if (status) {
            apiPostData = await this.setApiDataTopPerformance(
                widgetConfig,
                accountConfig,
                requestBody
            );
        } else {
            apiPostData = await this.setApiData(
                widgetConfig,
                accountConfig,
                requestBody
            );
        }
        console.log(token,'token+++++');
        const url = `https://googleads.googleapis.com/v15/customers/${widgetConfig.accountId}/googleAds:search`;
        const headers = {
            "Content-Type": "application/json",
            Authorization: "Bearer " + token,
            "developer-token": process.env.GOOGLE_ADWORDS_DEVELOPER_TOKEN,
            "login-customer-id": widgetConfig.resourceId,
        };
        const apiFetchResult = await fetch(url, {
            method: "POST",
            body: JSON.stringify(apiPostData),
            headers,
        });
        return apiFetchResult.json();
    }

    @Security("bearerAuth")
    @Post("google-adwords-account-api")
    async googleAPIAccount(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
            };
            if (requestBody.token && requestBody.token.config) {
                requestBody.token.config = JSON.parse(requestBody.token.config);
            }
            const token = await this.checkTokenValidity(
                requestBody.token.config,
                requestBody.token.id
            );
            const apiFetchResult = await fetch(
                "https://googleads.googleapis.com/v15/customers:listAccessibleCustomers",
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: "Bearer " + token,
                        "developer-token":
                            process.env.GOOGLE_ADWORDS_DEVELOPER_TOKEN,
                    },
                }
            );
            const result = await apiFetchResult.json();
            const apiResult = [];
            if (result) {
                if (result.resourceNames?.length) {
                    for (const resource of result.resourceNames) {
                        const customerResult = await this.getCustomerAccount(
                            token,
                            resource
                        );
                        if (
                            customerResult?.length &&
                            customerResult[0].results?.length
                        ) {
                            for (const customerValue of customerResult[0]
                                .results) {
                                apiResult.push({
                                    resourceId: resource.replaceAll(
                                        "customers/",
                                        ""
                                    ),
                                    id: customerValue.customerClient.id,
                                    name: customerValue.customerClient
                                        .descriptiveName,
                                    status: customerValue.customerClient.status,
                                });
                            }
                        }
                    }
                }
                this.setStatus(200);
                response.status = true;
                response.data = apiResult;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            } else {
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("google-adwords-api")
    async googleAdwordsAPI(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
            };
            if (requestBody.token && requestBody.token.config) {
                requestBody.token.config = JSON.parse(requestBody.token.config);
            }
            const token = await this.checkTokenValidity(
                requestBody.token.config,
                requestBody.token.id
            );
            const query = `SELECT campaign.id,campaign.name,campaign.status FROM campaign WHERE campaign.status != 'REMOVED'`;
            const url = `https://googleads.googleapis.com/v15/customers/${requestBody.customerId}/googleAds:search`;
            const headers = {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token,
                "developer-token": process.env.GOOGLE_ADWORDS_DEVELOPER_TOKEN,
                "login-customer-id": requestBody.resourceId,
            };
            const apiFetchResult = await fetch(url, {
                method: "POST",
                body: JSON.stringify({ query }),
                headers,
            });

            const result = await apiFetchResult.json();
            if (result) {
                this.setStatus(200);
                response.status = true;
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            } else {
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Post("google-adwords-keywords")
    async googleAdwordKeywords(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
            };
            if (requestBody.token && requestBody.token.config) {
                requestBody.token.config = JSON.parse(requestBody.token.config);
            }
            const token = await this.checkTokenValidity(
                requestBody.token.config,
                requestBody.token.id
            );
            const fields = `campaign.id, ad_group.id, ad_group_criterion.criterion_id, campaign.name, ad_group.name, ad_group_criterion.keyword.text,ad_group_criterion.keyword.match_type, metrics.impressions`;
            let query = `SELECT ${fields} FROM keyword_view`;
            query += ` WHERE ad_group_criterion.type = 'KEYWORD' AND campaign.status != 'REMOVED' AND ad_group_criterion.status IN ('ENABLED','PAUSED')`;
            if (
                requestBody.campaignId &&
                requestBody.campaignId.toLowerCase() !== "all"
            ) {
                query += ` AND campaign.id = '${requestBody.campaignId}'`;
            }
            if (requestBody.keywordText) {
                query += ` AND ad_group_criterion.keyword.text REGEXP_MATCH "(?i).*${requestBody.keywordText}.*"`;
            }
            query += ` ORDER BY metrics.impressions DESC LIMIT 50`;
            const url = `https://googleads.googleapis.com/v15/customers/${requestBody.customerId}/googleAds:search`;
            const headers = {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token,
                "developer-token": process.env.GOOGLE_ADWORDS_DEVELOPER_TOKEN,
                "login-customer-id": requestBody.resourceId,
            };

            const apiFetchResult = await fetch(url, {
                method: "POST",
                body: JSON.stringify({ query }),
                headers,
            });

            const result = await apiFetchResult.json();
            if (result) {
                this.setStatus(200);
                response.status = true;
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            } else {
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    public async getWidgetConfig(req) {
        let results;
        results = await Container.get(DataSource)
            .getRepository(DashboardWidget)
            .createQueryBuilder("DW")
            .leftJoinAndSelect("DW.widgetAccount", "widgetAccount")
            .where("DW.ID = :id", { id: [req.params.widgetId] })
            .getMany();
        //console.log(results,'req.paramsreq.params')
        if (results) {
            const widgetResponse: any = results[0];
            if (widgetResponse.isConfigured <= 0) {
                results = [];
            }
        } else {
            results = [];
        }
        return results;
    }

    public parseJSON(jsonString): any {
        return jsonString ? JSON.parse(jsonString.replace(/\\/g, "")) : {};
    }

    public async checkTokenValidity(accountConfig, id) {
        let token = undefined;
        if (accountConfig?.token != undefined) {
            let status: any = await MissedSignInOffUtil.checkValidity(
                accountConfig.token.access_token
            );
            token = accountConfig.token.access_token;
            if (!status.status) {
                let freshToken: any =
                    await MissedSignInOffUtil.refreshTokenAdwords(
                        accountConfig,
                        id
                    );
                token = freshToken.token;
            }
        }
        return token;
    }

    public async getCustomerAccount(token, resource) {
        const url = `https://googleads.googleapis.com/v15/${resource}/googleAds:searchStream`;
        const query = `SELECT customer_client.id, customer_client.descriptive_name, customer_client.status FROM customer_client WHERE customer_client.status = 'ENABLED'`;
        const customerApiResult = await fetch(url, {
            method: "POST",
            body: JSON.stringify({ query }),
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token,
                "developer-token": process.env.GOOGLE_ADWORDS_DEVELOPER_TOKEN,
            },
        });
        return customerApiResult.json();
    }
    public async checkTokenValidityAdword(accountConfig, id) {
        let token = undefined;
        if (accountConfig?.token != undefined) {
            let status: any = await MissedSignInOffUtil.checkValidity(
                accountConfig.token.access_token
            );
            token = accountConfig.token.access_token;
            if (!status.status) {
                let freshToken: any =
                    await MissedSignInOffUtil.refreshTokenAdwords(
                        accountConfig,
                        id
                    );
                token = freshToken.token;
            }
        }
        return token;
    }
}
