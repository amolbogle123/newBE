import {ChartExecutionUtil} from "../../../utils/chartExecution.util";

export class MixDonutExpenseChart {

    /**
     * Get Form Chart Data
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    async mixDonutExpenseChartExecution(req: any): Promise<any> {
        try {
            let widgetConfig, accountConfigDetails,result;
            if (req.params.widgetId !== 'preview') {
                const configResult: any = await ChartExecutionUtil.getWidgetConfigAndAccountConfig(req);
                if (configResult.widgetFound && configResult.isConfigured) {
                    widgetConfig = configResult.widgetConfig;
                    accountConfigDetails = configResult.accountConfigDetails;
                } else {
                    return {status: true, displayType: "configure", message: "Widget is not configured.", data: [],};
                }
            } else if (req.params.widgetId === 'preview') {
                const accountConfig: any = await ChartExecutionUtil.getAccountConfig(req);
                widgetConfig = req.body.widgetConfig ? req.body.widgetConfig : {};
                accountConfigDetails = accountConfig.accountConfigDetails;
            }
            if (widgetConfig?.sourceType && widgetConfig.sourceType === "ACCOUNT") {
                result = await ChartExecutionUtil.executeAccountDataSource(widgetConfig, accountConfigDetails, req);
            } else if (widgetConfig?.sourceType && widgetConfig.sourceType === "CUSTOM_TABLE") {
                result = await ChartExecutionUtil.executeCustomTable(req,widgetConfig);
            } else if (widgetConfig?.sourceType && widgetConfig.sourceType === "FORM") {
                result = await ChartExecutionUtil.executeForms(widgetConfig, accountConfigDetails);
            }
            return result;
        } catch (error) {
            throw new Error(error.message);
        }
    }
}
