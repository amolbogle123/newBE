import {ChartExecutionUtil} from "../../../utils/chartExecution.util";

export class LineChart {

    /**
     * Get Form Chart Data
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    async lineChartExecution(req: any): Promise<any> {
        try {
            let widgetConfig, accountConfigDetails, result, accountConfig;
            if (req.params.widgetId !== 'preview') {
                accountConfig = await ChartExecutionUtil.getWidgetConfigAndAccountConfig(req);
                if (!(accountConfig.widgetFound && accountConfig.isConfigured)) {
                    return {status: true, displayType: "configure", message: "Widget is not configured.", data: [],};
                }
                widgetConfig = accountConfig.widgetConfig;
                accountConfigDetails = accountConfig.accountConfigDetails;
            } else if (req.params.widgetId === 'preview') {
                if(req?.body?.widgetConfig?.sourceType === 'VIEW360TABLES') {
                    accountConfigDetails = {
                        dbType: process.env.DB_TYPE,
                        dbHost: process.env.DB_HOST,
                        dbName: process.env.DB_NAME,
                        dbUser: process.env.DB_USERNAME,
                        dbPassword: process.env.DB_PASSWORD,
                    };
                    accountConfig = {accountConfigDetails: accountConfigDetails};
                    widgetConfig = req.body.widgetConfig ? req.body.widgetConfig : {};
                } else {
                    accountConfig = await ChartExecutionUtil.getAccountConfig(req);
                    widgetConfig = req.body.widgetConfig ? req.body.widgetConfig : {};
                    accountConfigDetails = accountConfig.accountConfigDetails;
                }
            }

            if (accountConfig?.widgetType === "VIEW360_TABLE") {
                result = await ChartExecutionUtil.executeView360DataSource(widgetConfig, req);
            } else if (widgetConfig?.sourceType === "ACCOUNT"  || widgetConfig.sourceType === "VIEW360TABLES") {
                result = await ChartExecutionUtil.executeAccountDataSource(widgetConfig, accountConfigDetails, req);
            } else if (widgetConfig?.sourceType === "CUSTOM_TABLE") {
                result = await ChartExecutionUtil.executeCustomTable(req,widgetConfig);
            } else if (widgetConfig?.sourceType === "FORMS") {
                result = await ChartExecutionUtil.executeForms(req,widgetConfig);
            }
            return result;
        } catch (error) {
            throw new Error(error.message);
        }
    }
}
