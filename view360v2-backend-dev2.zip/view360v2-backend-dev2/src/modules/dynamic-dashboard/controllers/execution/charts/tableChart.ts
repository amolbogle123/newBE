import { DataSource } from "typeorm";
import { dataSource } from "core/data-source";
import Container from "typedi";
import { DashboardWidget } from "../../../../../entities";
import { ChartExecutionUtil } from "../../../utils/chartExecution.util";

export class TableChart {
    /**
     * Get Form Chart Data
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    async tableChartExecution(req: any): Promise<any> {
        try {
            let widgetConfig, accountConfigDetails, result, accountConfig;
            if (req.params.widgetId !== "preview") {
                accountConfig =
                    await ChartExecutionUtil.getWidgetConfigAndAccountConfig(
                        req
                    );
                if (!(accountConfig?.widgetFound && accountConfig?.isConfigured)) {
                    return {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    };
                }
                
                widgetConfig = accountConfig.widgetConfig;
                accountConfigDetails = accountConfig.accountConfigDetails;
            } else if (req.params.widgetId === "preview") {
                if(req?.body?.widgetConfig?.sourceType === 'VIEW360TABLES') {
                    accountConfigDetails = {
                        dbType: process.env.DB_TYPE,
                        dbHost: process.env.DB_HOST,
                        dbName: process.env.DB_NAME,
                        dbUser: process.env.DB_USERNAME,
                        dbPassword: process.env.DB_PASSWORD,
                    };
                    accountConfig = {accountConfigDetails: accountConfigDetails};
                    widgetConfig = req.body.widgetConfig ? req.body.widgetConfig : {};
                } else {
                    accountConfig = await ChartExecutionUtil.getAccountConfig(req);
                    widgetConfig = req.body.widgetConfig ? req.body.widgetConfig: {};
                    accountConfigDetails = accountConfig.accountConfigDetails;
                }
            }

            return await this.tableExecuteAccount(req, accountConfig, accountConfigDetails, widgetConfig);
        } catch (error) {
            throw new Error(error.message);
        }
    }

    async tableExecuteAccount(req, accountConfig, accountConfigDetails, widgetConfig) {
        try {
            let result; 
            if (widgetConfig?.properties?.relationFormId?.extraConfig?.isMultipleConnector && widgetConfig?.sourceType === "RELATION_BUILDER" && widgetConfig?.query) {
                let columnList = []; 
                if (widgetConfig?.yAxis?.length) {
                    widgetConfig.yAxis = widgetConfig.yAxis.map((yAxis: string) => {
                        let name = yAxis.replace('.', '_');
                        columnList.push({name: name});
                        return name;
                    });
                }
                result = await ChartExecutionUtil.prepareView360RelationQueryAndExecute(
                    widgetConfig,
                    req,
                    columnList
                );
            } else if (accountConfigDetails && widgetConfig?.sourceType === "RELATION_BUILDER" && widgetConfig?.query) {
                result = await ChartExecutionUtil.executeRelationAccountDataSource(
                    widgetConfig,
                    accountConfigDetails,
                    req
                );
            } else if (accountConfig?.widgetType === "VIEW360_TABLE") {
                result = await ChartExecutionUtil.executePublicView360Table(
                    req,
                    widgetConfig
                );
            } else if (
                widgetConfig &&
                widgetConfig.sourceType &&
                (widgetConfig.sourceType === "ACCOUNT" || widgetConfig.sourceType === "VIEW360TABLES")
            ) {
                if (req.body.bucketFlag) {
                    if (req.body.selectedFilter) {
                        widgetConfig.whereFields = JSON.parse(
                            req.body.selectedFilter
                        );
                    }
                }
                result = await ChartExecutionUtil.executeAccountDataSource(
                    widgetConfig,
                    accountConfigDetails,
                    req
                );
            } else if (
                widgetConfig?.sourceType &&
                widgetConfig.sourceType === "CUSTOM_TABLE"
            ) {
                result = await ChartExecutionUtil.executeCustomTable(
                    req,
                    widgetConfig
                );
            } else if (
                widgetConfig?.sourceType &&
                widgetConfig.sourceType === "FORMS"
            ) {
                result = await ChartExecutionUtil.executeForms(
                    req,
                    widgetConfig
                );
            }
            return result;
        } catch (error) {
            throw new Error(error.message);
        }
    }

    async tableQueryExecution(req: any): Promise<any> {
        try {
            let response: any = {
                data: [],
                properties: { labelList: [] },
                status: false,
                displayType: "configure",
                message: "Widget is not configured.",
            };

            if (req.body?.sqlQuery?.selectedColumns?.length) {
                response.properties.labelList =
                    req.body.sqlQuery.selectedColumns.map((c) => {
                        return {
                            id: c.ColumnName,
                            name: c.ColumnName,
                        };
                    });
            }

            let widgetAccount = null;
            let sqlQuery = null;
            if (req.params?.widgetId === "preview") {
                widgetAccount = req.body?.sqlQuery?.widgetAccount || null;
                sqlQuery = req.body.sqlQuery?.query || "";
            } else if (req.params?.widgetId) {
                const result = await Container.get(DataSource)
                    .getRepository(DashboardWidget)
                    .createQueryBuilder("DW")
                    .where("DW.ID = :id", { id: req.params.widgetId })
                    .getOne();
                if (result?.widgetConfig) {
                    const widgetConfig = JSON.parse(result.widgetConfig);
                    if (widgetConfig?.sql?.query) {
                        sqlQuery = widgetConfig.sql.query;
                    }
                    if (widgetConfig?.sql?.widgetAccount) {
                        widgetAccount = widgetConfig.sql.widgetAccount;
                    }
                }
            }

            const queryResult: any = await this.executeSqlQuery(req, sqlQuery, widgetAccount);
            if (queryResult?.data) {
                response.data = queryResult.data;
                response.displayType = queryResult.table;
                response.message = queryResult.message;
                response.status = queryResult.status;
            }
            return response;
        } catch (error) {
            throw new Error(error.message);
        }
    }

    executeSqlQuery(req, sqlQuery, widgetAccount) {
        return new Promise(async(resolve) => {
            let queryRunner;
            const response = {status: false, data: [], displayType: "TABLE", message: "Successfully executed."};
            try {
                if (widgetAccount === "RELATION_BUILDER" && sqlQuery) {
                    let start = req.body?.start || 0;
                    let length = req.body?.length || 10;

                    const connection = dataSource.manager.connection;
                    queryRunner = connection.createQueryRunner();
                    await queryRunner.connect();

                    let recordsTotal = 0;
                    const totalResult = await queryRunner.query(sqlQuery);
                    if (totalResult?.length) {
                        recordsTotal = totalResult.length;
                    }

                    const dataResult = await queryRunner.query(
                        sqlQuery + ` LIMIT ${start},${length}`
                    );
                    if (dataResult?.length) {
                        response.data = dataResult.map((d) => {
                            d.recordsTotal = recordsTotal;
                            return d;
                        });
                    }
                    response.status = true;
                }

                resolve(response);
            } catch (error) {
                resolve(response);
            } finally {
                // Release the query runner
                await queryRunner.release();
            }
        });
    }

    async tableExecution(req: any): Promise<any> {
        const response: any = {
            status: false,
            displayType: "table",
            message: "Form data not found.",
            data: [],
        };
        try {
            let widgetConfig = req.body.formChart || {};
            let results = null;

            let selectFields = [];
            if (widgetConfig?.displayFields?.length) {
                for (let s of widgetConfig?.displayFields) {
                    selectFields.push(
                        `json_value(fb.SUBMITTED_DATA, '$.${s}') AS ${s}`
                    );
                }
            }
            let formStmt = `SELECT ${selectFields.join(
                ", "
            )} FROM form_builder_${
                req.userDetails.client_id
            } fb WHERE fb.FORM_ID = "${widgetConfig.form}"`;

            formStmt += await getWhereCondition(widgetConfig.whereCondition);

            if (widgetConfig.sortByField) {
                let type = widgetConfig.sortByType
                    ? widgetConfig.sortByType
                    : "ASC";
                formStmt += ` ORDER BY json_value(fb.SUBMITTED_DATA, '$.${widgetConfig.sortByField}') ${type}`;
            }
            if (formStmt) {
                results = await Container.get(DataSource).manager.query(
                    formStmt
                );
            }
            response.status = true;
            const data = JSON.parse(JSON.stringify(results));
            if (data?.length) {
                response.data = data;
                response.message = "";
            }
            return response;
        } catch (error) {
            return response;
        }
    }

    async updateTableExecution(req: any): Promise<any> {
        let widgetConfig, accountConfigDetails, result;
        const configResult: any =
            await ChartExecutionUtil.getWidgetConfigAndAccountConfig(req);
        if (configResult.widgetFound && configResult.isConfigured) {
            widgetConfig = configResult.widgetConfig;
            accountConfigDetails = configResult.accountConfigDetails;
        } else {
            return {
                status: true,
                displayType: "configure",
                message: "Widget is not configured.",
                data: [],
            };
        }
        return ChartExecutionUtil.executeUpdateAccountDataSource(
            widgetConfig,
            accountConfigDetails,
            req
        );
    }
}

function getWhereCondition(whereCondition) {
    return new Promise((resolve) => {
        let formStmt = "";
        if (Array.isArray(whereCondition) && whereCondition.length) {
            for (const whereValue of whereCondition) {
                if (whereValue.field && whereValue.operator) {
                    let field = whereValue.field;
                    let operator = whereValue.operator;
                    let value = whereValue.value;

                    formStmt +=
                        " AND " +
                        getConditionalQuery(
                            `json_value(fb.SUBMITTED_DATA, '$.${field}')`,
                            operator,
                            `'${value}'`
                        );
                }
            }
        }
        resolve(formStmt);
    });
}

function getConditionalQuery(left, sign, right) {
    switch (sign) {
        case "equal":
            return `${left} = ${right}`;
        case "notEqual":
            return `${left} != ${right}`;
        case "isNull":
            return `(${left} = '')`;
        case "notNull":
            return `(${left} != '')`;
        case "greaterThan":
            return `${left} > ${right}`;
        case "greaterThanEqual":
            return `${left} >= ${right}`;
        case "lessThan":
            return `${left} < ${right}`;
        case "lessThanEqual":
            return `${left} <= ${right}`;

        default:
            return "";
    }
}
