import { DashboardWidget, GeoTargets } from "../../../../entities";
import {
    CommonHelper,
    ApiErrorResponse,
} from "../../../../utils/helpers/common.helper";
import { MissedSignInOffUtil } from "../../../../utils/missed-sign-in-off.util";
import moment from "moment/moment";
import dbService from "../../../../services/db.service";
import Container from "typedi";
import { DataSource } from "typeorm";
import fetch from "node-fetch";
import {
    Post,
    Request,
    Route,
    Security,
    Tags,
    Controller,
    Body,
    Get,
    Middlewares,
} from "tsoa";
import { commonMiddleware } from "../../../../middlewares/common.middleware";
@Route("dashboard")
@Tags("Dynamic Dashboard")
export class GoogleController extends Controller {
    /**
     *
     * get Google Details
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */

    @Security("bearerAuth")
    @Post("google-widget/:widgetId/:drillDownLevel")
    @Middlewares(commonMiddleware)
    async getGoogleDetails(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
                updatedOn: "",
            };
            const widgetResponse: any = await this.getWidgetConfig(req);
            if (widgetResponse.length <= 0) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
            let widgetConfig = this.parseJSON(widgetResponse[0].widgetConfig);
            // console.log(widgetResponse[0],'widdjddkdk')
            if (req.params.drillDownLevel == 1) {
                widgetConfig.drilldown.viewId = widgetConfig.viewId;
                widgetConfig = widgetConfig.drilldown;
                widgetConfig.chartType = widgetConfig.formChart.chartType;
                widgetConfig.dimensions = widgetConfig.formChart.dimensions;
                widgetConfig.metric = widgetConfig.formChart.metric;
                widgetConfig.orderBy = widgetConfig.formChart.orderBy;
                widgetConfig.start_date = widgetConfig.formChart.start_date;
                widgetConfig.end_date = widgetConfig.formChart.end_date;
            } else if (req.params.drillDownLevel == 2) {
                widgetConfig.drilldown.drilldown.viewId = widgetConfig.viewId;
                widgetConfig = widgetConfig.drilldown.drilldown;
                widgetConfig.chartType = widgetConfig.formChart.chartType;
                widgetConfig.dimensions = widgetConfig.formChart.dimensions;
                widgetConfig.metric = widgetConfig.formChart.metric;
                widgetConfig.orderBy = widgetConfig.formChart.orderBy;
                widgetConfig.start_date = widgetConfig.formChart.start_date;
                widgetConfig.end_date = widgetConfig.formChart.end_date;
            }
            widgetConfig.dimensionfilter = [];
            let accountConfig: any;
            if (requestBody.dateRange.length > 0) {
                accountConfig = requestBody;
                if (requestBody.metricArr && requestBody.metricArr.length > 0) {
                    widgetConfig.metric = [requestBody.metricArr[0].key];
                    widgetConfig.dimensions = requestBody.metricArr[0].value;
                }

                if (
                    requestBody.filterDimensions &&
                    requestBody.filterDimensions?.enableFilter &&
                    requestBody.filterDimensions?.expressions.length
                ) {
                    if (
                        requestBody.filterDimensions?.dimensionName ===
                        "ga:city"
                    ) {
                        for (let item of requestBody.filterDimensions
                            ?.expressions) {
                            widgetConfig.dimensionfilter.push({
                                filters: {
                                    dimensionName:
                                        requestBody.filterDimensions
                                            ?.dimensionName,
                                    operator: "EXACT",
                                    expressions: [item],
                                },
                            });
                        }
                    } else {
                        widgetConfig.dimensionfilter.push({
                            filters: {
                                dimensionName:
                                    requestBody.filterDimensions?.dimensionName,
                                operator: "EXACT",
                                expressions: [
                                    requestBody.filterDimensions?.expressions,
                                ],
                            },
                        });
                    }
                }

                if (
                    requestBody.enableFilterOptions &&
                    requestBody.filterOptionDimensions
                    // requestBody.filterOptionDimensions?.expressions !== "All"
                ) {
                    for (let item of requestBody.filterOptionDimensions) {
                        if (item.selected !== "All") {
                            widgetConfig.dimensionfilter.push({
                                filters: {
                                    dimensionName: item.value,
                                    operator: "EXACT",
                                    expressions: [item.selected],
                                },
                            });
                        }
                    }
                }
            } else {
                let accountArr = {
                    token: { viewId: "" },
                    widgetAccount: "",
                    dateRange: [],
                };
                accountArr.token = this.parseJSON(
                    widgetResponse[0]?.widgetAccount.config
                );
                accountArr.widgetAccount = widgetResponse[0]?.widgetAccount.id;
                accountArr.token.viewId = widgetConfig.viewId;
                accountConfig = accountArr;
            }
            const token = await this.checkTokenValidity(
                accountConfig.token,
                accountConfig.widgetAccount
            );
            console.log(token, "tokentokentoken+++");
            if (token === undefined) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }

            if (widgetConfig.metric) {
                let startDate = moment(
                    widgetConfig.start_date,
                    "MM-DD-YYYY"
                ).format("YYYY-MM-DD");
                let endDate = moment(
                    widgetConfig.end_date,
                    "MM-DD-YYYY"
                ).format("YYYY-MM-DD");
                if (accountConfig.dateRange.length > 0) {
                    startDate = accountConfig.dateRange[0];
                    endDate = accountConfig.dateRange[1];
                }
                let dateRanges = [];
                this.setDateRangeAsPerCompareFormula(widgetConfig, dateRanges);

                const result = await this.getGoogleAnalyticsData(
                    widgetConfig,
                    accountConfig,
                    token,
                    startDate,
                    endDate
                );
                if (result?.reports) {
                    await this.fetchPrevDataPerFormulaAndUpdateResult(
                        result?.reports[0],
                        dateRanges,
                        widgetConfig,
                        accountConfig,
                        token,
                        startDate,
                        endDate
                    );
                    this.setStatus(200);
                    response.status = true;
                    response.data = result.reports[0];
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                } else {
                    response.data = result;
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                }
            } else {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    private async fetchPrevDataPerFormulaAndUpdateResult(
        result: any,
        dateRanges: any,
        widgetConfig: any,
        accountConfig: any,
        token: any,
        startDate: any,
        endDate: any
    ) {
        if (dateRanges.length) {
            for (let dateRange of dateRanges) {
                startDate = dateRange.prevStartDate;
                endDate = dateRange.prevEndDate;
                const resultForCompare: any = await this.getGoogleAnalyticsData(
                    widgetConfig,
                    accountConfig,
                    token,
                    startDate,
                    endDate
                );
                if (resultForCompare.reports) {
                    await result.data.rows.forEach(async (element, index) => {
                        if (element?.metrics) {
                            resultForCompare?.reports[0].columnHeader.metricHeader.metricHeaderEntries.forEach(
                                async (metricHeaderEntry, mindex) => {
                                    if (metricHeaderEntry?.name) {
                                        if (
                                            metricHeaderEntry.name ==
                                            "ga:" + dateRange.column
                                        ) {
                                            let compareValue = parseFloat(
                                                resultForCompare?.reports[0]
                                                    ?.data.rows[index]
                                                    .metrics[0].values[mindex]
                                            );
                                            if (compareValue) {
                                                let currentValue = parseFloat(
                                                    element?.metrics[0].values[
                                                        mindex
                                                    ]
                                                );
                                                let changeValue =
                                                    currentValue - compareValue;
                                                let percentageChange =
                                                    (changeValue /
                                                        Math.abs(
                                                            compareValue
                                                        )) *
                                                    100;

                                                let change;

                                                if (percentageChange === 0) {
                                                    change = "grey";
                                                } else if (
                                                    percentageChange > 0
                                                ) {
                                                    change = "green";
                                                } else {
                                                    change = "red";
                                                }
                                                let metricToAdd,
                                                    metricIdToAdd,
                                                    metricNameToAdd;
                                                if (
                                                    dateRange.position ===
                                                    "New-Column"
                                                ) {
                                                    const existingMetricHeaderIndex =
                                                        result.columnHeader.metricHeader.metricHeaderEntries.findIndex(
                                                            (metric) =>
                                                                metric.name ===
                                                                "ga:" +
                                                                    dateRange.newColumnName
                                                        );
                                                    if (
                                                        existingMetricHeaderIndex ===
                                                        -1
                                                    ) {
                                                        result.columnHeader.metricHeader.metricHeaderEntries.push(
                                                            {
                                                                name:
                                                                    "ga:" +
                                                                    dateRange.newColumnName,
                                                                type: "",
                                                            }
                                                        );
                                                    }
                                                    element.metrics[0].values.push(
                                                        percentageChange.toFixed(
                                                            0
                                                        ) +
                                                            "%" +
                                                            "=" +
                                                            change
                                                    );

                                                    metricToAdd =
                                                        "ga:" +
                                                        dateRange.newColumnName;
                                                    metricIdToAdd =
                                                        "ga:" +
                                                        dateRange.newColumnName;
                                                    metricNameToAdd =
                                                        dateRange.newColumnName;
                                                    // Check if metricToAdd does not exist in widgetConfig.metric
                                                    if (
                                                        widgetConfig.metric.indexOf(
                                                            metricToAdd
                                                        ) === -1
                                                    ) {
                                                        widgetConfig.metric.push(
                                                            metricToAdd
                                                        );
                                                    }

                                                    // Check if metricIdToAdd does not exist in widgetConfig.selectedMetrics
                                                    const existingMetricIndex =
                                                        widgetConfig.selectedMetrics.findIndex(
                                                            (metric) =>
                                                                metric.id ===
                                                                metricNameToAdd
                                                        );

                                                    if (
                                                        existingMetricIndex ===
                                                        -1
                                                    ) {
                                                        widgetConfig.selectedMetrics.push(
                                                            {
                                                                name: metricNameToAdd,
                                                                id: metricNameToAdd,
                                                            }
                                                        );
                                                    }
                                                } else {
                                                    //Within-Column
                                                    //prefix percentage change
                                                    element.metrics[0].values[
                                                        mindex
                                                    ] =
                                                        percentageChange.toFixed(
                                                            0
                                                        ) +
                                                        "%" +
                                                        "=" +
                                                        change +
                                                        "=" +
                                                        element.metrics[0]
                                                            .values[mindex];
                                                    result.columnHeader.metricHeader.metricHeaderEntries[
                                                        mindex
                                                    ].type = "";
                                                }
                                            }
                                        }
                                    }
                                }
                            );
                        }
                    });
                    console.log(result, "resultres");
                }
            }
        }
    }
    private setDateRangeAsPerCompareFormula(
        widgetConfig: any,
        dateRanges: any[]
    ) {
        if (
            widgetConfig?.chartType === "GOOGLE_TABLE" &&
            widgetConfig?.properties?.enableTableColumnFormulae &&
            widgetConfig?.properties?.tableColumnFormulae?.length
        ) {
            widgetConfig.properties.tableColumnFormulae.forEach(
                async (formulae) => {
                    if (
                        formulae.formula &&
                        formulae.formula == "compare" &&
                        formulae.column &&
                        formulae.column != ""
                    ) {
                        let prevDateRange = this.getPreviousPeriodDates([
                            widgetConfig.start_date,
                            widgetConfig.end_date,
                        ]);

                        dateRanges.push({
                            column: formulae.column.replace("metrics.", ""),
                            position: formulae.position,
                            newColumnName: formulae.newColumnName
                                ? formulae.newColumnName
                                : "",
                            prevStartDate: prevDateRange[0],
                            prevEndDate: prevDateRange[1],
                        });
                    }
                }
            );
        }
    }

    private async getGoogleAnalyticsData(
        widgetConfig: any,
        accountConfig: any,
        token: any,
        startDate: string,
        endDate: string
    ) {
        const received = this.fillGoogleMetrics(widgetConfig);
        let googleMetrics = received.googleMetrics;
        let apiFetchResult = await this.getOptions(
            widgetConfig,
            accountConfig.token,
            token,
            startDate,
            endDate,
            googleMetrics
        );
        return apiFetchResult.json();
    }
    getPreviousPeriodDates(dateRange) {
        const startDate = new Date(dateRange[0]);
        const endDate = new Date(dateRange[1]);

        // Calculate the duration in milliseconds
        const duration = endDate.getTime() - startDate.getTime();

        // Calculate the start and end dates for the previous period
        const previousEndDate = new Date(startDate.getTime() - 1); // Subtract 1 millisecond from the start date
        const previousStartDate = new Date(
            previousEndDate.getTime() - duration
        );

        // Format the dates as strings in "YYYY-MM-DD" format
        const formattedStartDate = this.formatDate(previousStartDate);
        const formattedEndDate = this.formatDate(previousEndDate);

        return [formattedStartDate, formattedEndDate];
    }
    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    }

    @Security("bearerAuth")
    @Post("google-widget/preview/:widgetId/:drillDownLevel")
    async getGoogleDetailsPreview(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
                updatedOn: "",
            };
            let config = JSON.stringify(requestBody.widgetConfig);
            let widgetConfig = JSON.parse(config);
            if (req.params.drillDownLevel == 1) {
                widgetConfig.drilldown.viewId = widgetConfig.viewId;
                widgetConfig = widgetConfig.drilldown;
                widgetConfig.chartType = widgetConfig.formChart.chartType;
                widgetConfig.dimensions = widgetConfig.formChart.dimensions;
                widgetConfig.metric = widgetConfig.formChart.metric;
                widgetConfig.orderBy = widgetConfig.formChart.orderBy;
                widgetConfig.start_date = widgetConfig.formChart.start_date;
                widgetConfig.end_date = widgetConfig.formChart.end_date;
            } else if (req.params.drillDownLevel == 2) {
                widgetConfig.drilldown.drilldown.viewId = widgetConfig.viewId;
                widgetConfig = widgetConfig.drilldown.drilldown;
                widgetConfig.chartType = widgetConfig.formChart.chartType;
                widgetConfig.dimensions = widgetConfig.formChart.dimensions;
                widgetConfig.metric = widgetConfig.formChart.metric;
                widgetConfig.orderBy = widgetConfig.formChart.orderBy;
                widgetConfig.start_date = widgetConfig.formChart.start_date;
                widgetConfig.end_date = widgetConfig.formChart.end_date;
            }
            widgetConfig.dimensionfilter = [];
            let accountConfig: any;
            if (requestBody.dateRange.length > 0) {
                let accountArr = {
                    token: { viewId: "" },
                    widgetAccount: "",
                    dateRange: [],
                };
                accountArr.token = JSON.parse(
                    JSON.stringify(requestBody?.widgetAccount.config)
                );
                accountArr.widgetAccount = requestBody?.widgetAccount.id;
                if (widgetConfig.viewId != "") {
                    accountArr.token.viewId = widgetConfig.viewId;
                }
                accountConfig = accountArr;
                if (requestBody.metricArr && requestBody.metricArr.length > 0) {
                    widgetConfig.metric = [requestBody.metricArr[0].key];
                    widgetConfig.dimensions = requestBody.metricArr[0].value;
                }
                if (
                    requestBody.filterDimensions &&
                    requestBody.filterDimensions?.enableFilter &&
                    requestBody.filterDimensions?.expressions !== "All"
                ) {
                    widgetConfig.dimensionfilter.push({
                        filters: {
                            dimensionName:
                                requestBody.filterDimensions?.dimensionName,
                            operator: "EXACT",
                            expressions: [
                                requestBody.filterDimensions?.expressions,
                            ],
                        },
                    });
                }

                if (
                    requestBody.filterOptionDimensions &&
                    requestBody.filterOptionDimensions?.enableFilter &&
                    requestBody.filterOptionDimensions?.expressions !== "All"
                ) {
                    widgetConfig.dimensionfilter.push({
                        filters: {
                            dimensionName:
                                requestBody.filterOptionDimensions
                                    ?.dimensionName,
                            operator: "EXACT",
                            expressions: [
                                requestBody.filterOptionDimensions?.expressions,
                            ],
                        },
                    });
                }
            } else {
                let reqParam = {
                    dashboardId: widgetConfig.dashboardId,
                    type: "GOOGLE_ANALYTICS_SEARCH",
                };

                const accountConfigResponse: any =
                    await this.getDefaultGoogleAccountConfig(reqParam);

                if (
                    Array.isArray(accountConfigResponse) &&
                    accountConfigResponse.length
                ) {
                    accountConfig = this.parseJSON(
                        accountConfigResponse[0].widgetConfig
                    );
                    accountConfig.dateRange[0] = moment(
                        accountConfig.dateRange[0]
                    ).format("YYYY-MM-DD");
                    accountConfig.dateRange[1] = moment(
                        accountConfig.dateRange[1]
                    ).format("YYYY-MM-DD");
                } else {
                    let accountArr = {
                        token: { viewId: "" },
                        widgetAccount: "",
                        dateRange: [],
                    };
                    accountArr.token = JSON.parse(
                        JSON.stringify(requestBody?.widgetAccount.config)
                    );
                    accountArr.widgetAccount = requestBody?.widgetAccount.id;
                    if (widgetConfig.viewId != "") {
                        accountArr.token.viewId = widgetConfig.viewId;
                    }
                    accountConfig = accountArr;
                }
            }
            const token = await this.checkTokenValidity(
                accountConfig.token,
                accountConfig.widgetAccount
            );
            if (token === undefined) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
            if (widgetConfig.metric) {
                let startDate = moment(
                    widgetConfig.start_date,
                    "MM-DD-YYYY"
                ).format("YYYY-MM-DD");
                let endDate = moment(
                    widgetConfig.end_date,
                    "MM-DD-YYYY"
                ).format("YYYY-MM-DD");
                if (accountConfig.dateRange.length > 0) {
                    startDate = accountConfig.dateRange[0];
                    endDate = accountConfig.dateRange[1];
                }
                let dateRanges = [];
                this.setDateRangeAsPerCompareFormula(widgetConfig, dateRanges);

                const result = await this.getGoogleAnalyticsData(
                    widgetConfig,
                    accountConfig,
                    token,
                    startDate,
                    endDate
                );
                if (result?.reports) {
                    await this.fetchPrevDataPerFormulaAndUpdateResult(
                        result?.reports[0],
                        dateRanges,
                        widgetConfig,
                        accountConfig,
                        token,
                        startDate,
                        endDate
                    );
                    this.setStatus(200);
                    response.status = true;
                    response.data = result.reports[0];
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                } else {
                    response.data = result;
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                }
            } else {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Post("google-token-verification")
    async getGoogleTokenverification(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
            };
            const apiFetchResult = await fetch(requestBody.url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            });
            const result = await apiFetchResult.json();
            if (result?.access_token) {
                this.setStatus(200);
                response.status = true;
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            } else {
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("google-account-api")
    async googleAPIAccount(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
            };
            if (requestBody.token && requestBody.token.config) {
                requestBody.token.config = JSON.parse(requestBody.token.config);
            }
            const token = await this.checkTokenValidity(
                requestBody.token.config,
                requestBody.token.id
            );
            const apiFetchResult = await fetch(
                requestBody.url + "?access_token=" + token,
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                }
            );

            const result = await apiFetchResult.json();
            if (result) {
                this.setStatus(200);
                response.status = true;
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            } else {
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    public async getOptions(
        widgetConfig,
        accountConfig,
        token,
        startDate,
        endDate,
        googleMetrics
    ) {
        let reqbOdy = {
            reportRequests: [
                {
                    viewId: "" + accountConfig.viewId,
                    //pageSize: "10",
                    dateRanges: [
                        {
                            startDate: startDate,
                            endDate: endDate,
                        },
                    ],
                    metrics: googleMetrics,
                    dimensions: [
                        {
                            name: widgetConfig.dimensions,
                        },
                    ],
                    dimensionFilterClauses: [widgetConfig.dimensionfilter],

                    orderBys:
                        widgetConfig.orderBy == "" ||
                        widgetConfig.orderBy == null
                            ? []
                            : [
                                  {
                                      fieldName: widgetConfig.dimensions,
                                      sortOrder: widgetConfig.orderBy,
                                  },
                              ],
                },
            ],
        };
        console.log(reqbOdy, "reqbOdyreqbOdyreqbOdyreqbOdyreqbOdy");
        return fetch(
            "https://analyticsreporting.googleapis.com/v4/reports:batchGet",
            {
                method: "POST",
                body: JSON.stringify(reqbOdy),
                headers: {
                    "Content-Type": "application/json",
                    Authorization: "Bearer " + token,
                },
            }
        );
    }

    public async getWidgetConfig(req) {
        let results;
        results = await Container.get(DataSource)
            .getRepository(DashboardWidget)
            .createQueryBuilder("DW")
            .leftJoinAndSelect("DW.widgetAccount", "widgetAccount")
            .where("DW.ID = :id", { id: [req.params.widgetId] })
            .getMany();
        //console.log(results,'req.paramsreq.params')
        if (results) {
            const widgetResponse: any = results[0];
            if (widgetResponse.isConfigured <= 0) {
                results = [];
            }
        } else {
            results = [];
        }
        return results;
    }

    public parseJSON(jsonString): any {
        return jsonString ? JSON.parse(jsonString.replace(/\\/g, "")) : {};
    }

    public async checkTokenValidity(accountConfig, id) {
        let token = undefined;
        if (accountConfig?.token != undefined) {
            let status: any = await MissedSignInOffUtil.checkValidity(
                accountConfig.token.access_token
            );
            token = accountConfig.token.access_token;
            if (!status.status) {
                let freshToken: any = await MissedSignInOffUtil.refreshToken(
                    accountConfig,
                    id
                );
                token = freshToken.token;
            }
        }
        return token;
    }
    public async checkTokenValidityAdword(accountConfig, id) {
        let token = undefined;
        if (accountConfig?.token != undefined) {
            let status: any = await MissedSignInOffUtil.checkValidity(
                accountConfig.token.access_token
            );
            token = accountConfig.token.access_token;
            if (!status.status) {
                let freshToken: any =
                    await MissedSignInOffUtil.refreshTokenAdwords(
                        accountConfig,
                        id
                    );
                token = freshToken.token;
            }
        }
        return token;
    }

    public fillGoogleMetrics(widgetConfig) {
        let orderBy;
        let googleMetrics = [];
        if (Array.isArray(widgetConfig.metric)) {
            orderBy = widgetConfig.metric[0];
            if (widgetConfig.metric.length > 1) {
                widgetConfig.metric.forEach((r, k) => {
                    googleMetrics.push({
                        expression: r,
                    });
                });
            } else {
                googleMetrics.push({
                    expression: widgetConfig.metric[0],
                });
            }
        } else {
            googleMetrics.push({
                expression: widgetConfig.metric,
            });
            orderBy = widgetConfig.metric;
        }
        return { googleMetrics: googleMetrics, orderBy: orderBy };
    }

    @Security("bearerAuth")
    @Post("google-trend-compare/:widgetId")
    @Middlewares(commonMiddleware)
    async getGoogleCompareDetails(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
                updatedOn: "",
            };
            const widgetResponse: any = await this.getWidgetConfig(req);
            if (widgetResponse.length <= 0) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
            let widgetConfig = this.parseJSON(widgetResponse[0].widgetConfig);
            let accountConfig: any;

            if (requestBody?.dateRange?.length) {
                accountConfig = requestBody;
            } else {
                let accountArr = {
                    token: { viewId: "" },
                    widgetAccount: "",
                };
                accountArr.token = this.parseJSON(
                    widgetResponse[0]?.widgetAccount.config
                );
                accountArr.widgetAccount = widgetResponse[0]?.widgetAccount.id;
                accountArr.token.viewId = widgetConfig.viewId;
                accountConfig = accountArr;
            }
            const token = await this.checkTokenValidity(
                accountConfig?.token,
                accountConfig?.widgetAccount
            );

            if (token === undefined) {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }

            if (widgetConfig.metric) {
                let startDate = moment().format("YYYY-MM-DD");
                let endDate = moment().format("YYYY-MM-DD");

                if (requestBody?.startDate && requestBody?.endDate) {
                    startDate = requestBody?.startDate;
                    endDate = requestBody?.endDate;
                }
                const received = this.fillGoogleMetrics(widgetConfig);
                let googleMetrics = received.googleMetrics;
                let apiFetchResult = await this.getOptions(
                    widgetConfig,
                    accountConfig.token,
                    token,
                    startDate,
                    endDate,
                    googleMetrics
                );
                const result = await apiFetchResult.json();
                if (result?.reports) {
                    this.setStatus(200);
                    response.status = true;
                    response.data = result.reports[0];
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                } else {
                    response.data = result;
                    response.updatedOn = moment
                        .utc()
                        .format("MM-DD-YYYY HH:mm:ss");
                    return CommonHelper.apiSwaggerSuccessResponse(response);
                }
            } else {
                this.setStatus(200);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: null,
                    data: {
                        status: true,
                        displayType: "configure",
                        message: "Widget is not configured.",
                        data: [],
                    },
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    public async getDefaultGoogleAccountConfig(req) {
        let results;
        results = await Container.get(DataSource)
            .getRepository(DashboardWidget)
            .createQueryBuilder("DW")
            .where("DW.DASHBOARD = :id AND TYPE = :type", {
                id: [req.dashboardId],
                type: [req.type],
            })
            .getMany();
        if (Array.isArray(results) && results.length) {
            const widgetResponse: any = results[0];
            if (widgetResponse?.isConfigured <= 0) {
                results = [];
            }
        } else {
            results = [];
        }
        return results;
    }

    @Security("bearerAuth")
    @Get("CountryList")
    @Middlewares(commonMiddleware)
    public async getCountryList(@Request() req: any): Promise<any> {
        const response = {
            status: false,
            data: [],
        };
        try {
            let countries: any = await dbService._findQueryService(
                Container.get(DataSource).getRepository(GeoTargets),
                {
                    where: { targetType: "Country" },
                    select: ["criteriaId", "name", "countryCode"],
                }
            );
            response.status = true;
            response.data = countries;
            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("StateList/:countryCode")
    public async getStateList(@Request() req: any): Promise<any> {
        const response = {
            status: false,
            data: [],
        };
        try {
            let states: any = await dbService._findQueryService(
                Container.get(DataSource).getRepository(GeoTargets),
                {
                    where: {
                        targetType: "State",
                        countryCode: req.params.countryCode,
                    },
                    select: ["criteriaId", "name", "countryCode"],
                }
            );
            response.status = true;
            response.data = states;
            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
