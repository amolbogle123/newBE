import moment from "moment/moment";
import fetch from "node-fetch";
import { Body, Controller, Middlewares, Path, Post, Request, Route, Security, Tags } from 'tsoa';
import Container from 'typedi';
import { DataSource } from 'typeorm';
import { DashboardWidget, WidgetAccount } from "../../../../entities";
import { commonMiddleware } from "../../../../middlewares/common.middleware";
import { ApiErrorResponse, CommonHelper } from "../../../../utils/helpers/common.helper";
const bizSdk = require('facebook-nodejs-business-sdk');

@Route('dashboard')
@Tags('Dynamic Dashboard')

export class FacebookController extends Controller {

    @Security('bearerAuth')
    @Post('facebook/preview')
    async getPreviewFacebookData(@Request() req: any): Promise<any> {
        try {
            const widgetResponse: any = req.body; 

            const result = await Container.get(DataSource).getRepository(WidgetAccount)
                .createQueryBuilder('DW')
                .where('DW.id = :id', { id: [widgetResponse.widgetAccount] })
                .getMany();
            if (!result || !Array.isArray(result) || !result.length) {
                this.setStatus(200)

                return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {
                    status: true,
                    displayType: "configure",
                    message: "Widget is not configured.",
                    data: [],
                }});
            }
            const accountConfig = result[0].config ? JSON.parse(result[0].config) : {};
            const widgetConfig = widgetResponse.widgetConfig;
            
            if (!widgetConfig?.adAccount || !widgetConfig?.adCampaign || !accountConfig?.accessToken) {
                this.setStatus(200)

                return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {
                    status: true,
                    displayType: "error",
                    message: "Facebook account is not configured.",
                    data: widgetResponse,
                }});
            }

            let response: any = {
                status: true,
                displayType: widgetConfig.chartType,
                message: "Widget Configured.",
                data: [],
                widgetConfig: null,
                xAxis: null,
                yAxis: widgetConfig.adMetrics
            };
            const accessToken = accountConfig.accessToken;
            const campaignId = widgetConfig.adCampaign;
            const FacebookAdsApi = bizSdk.FacebookAdsApi.init(accessToken);
            FacebookAdsApi.setDebug(false);

            let params: any = {
                'level': 'ad',
                filtering: []
            };
            let campaign = null;
            if (widgetConfig?.adSet && widgetConfig?.adSet !== 'all') {
                const AdSet = bizSdk.AdSet;
                campaign = new AdSet(widgetConfig.adSet);
                params.level = 'adset';
            } else if (widgetConfig?.adAccount) {
                const Ad = bizSdk.Ad;
                campaign = new Ad(widgetConfig?.adAccount);

                if (Array.isArray(widgetConfig?.adCampaign) && widgetConfig?.adCampaign?.length) {
                    params.filtering.push({
                        field: "campaign.id",
                        operator: "IN", 
                        value: widgetConfig.adCampaign
                    });
                }

                if (widgetConfig?.chartType && ["FACEBOOK_TABLE"].indexOf(widgetConfig?.chartType) === -1) {
                    params.level = 'account';   
                }
            } else {
                const Campaign = bizSdk.Campaign;
                campaign = new Campaign(campaignId);
            }

            if (widgetConfig?.statusType?.length) {
                params.filtering.push({
                    field: 'campaign.effective_status',
                    operator: 'IN',
                    value: widgetConfig.statusType
                });
            }

            let insightsFields = widgetConfig.adMetrics;
            if (widgetConfig?.dimention?.length) {
                insightsFields = insightsFields.concat(widgetConfig.dimention);
            }
            
            if (
                widgetResponse?.widgetConfig?.properties?.enableDateFilter
            ) {
                let startDate = null;
                let endDate = moment().toDate();
                switch (widgetResponse.widgetConfig.properties.compareWIth) {
                    case "1 Week":
                        startDate = moment().subtract(7, "days").toDate();
                        break;
                    case "1 Month":
                        startDate = moment().subtract(1, "months").toDate();
                        break;
                    case "3 Months":
                        startDate = moment().subtract(1, "months").toDate();
                        break;
                    case "1 Year":
                        startDate = moment().subtract(1, "years").toDate();
                        break;
                    case "Custom":
                        if (widgetResponse?.widgetConfig.properties?.dateRange?.length) {
                            startDate = moment(widgetConfig.properties?.dateRange[0]).toDate();
                            endDate = moment(widgetConfig.properties?.dateRange[1]).toDate();
                        }
                        break;
                }

                if (startDate && endDate) {
                    params["time_range"] = {
                        'since': moment(startDate).format("YYYY-MM-DD"),
                        'until': moment(endDate).format("YYYY-MM-DD")
                    };
                } else {
                    params["date_preset"] = "maximum";
                }
            } else if (req.body.startDate && req.body.endDate) {
                params["time_range"] = {
                    'since': req.body.startDate,
                    'until': req.body.endDate
                };
            } else {
                params["date_preset"] = "maximum";
            }
            if (widgetConfig.adBreakdown) {
                switch (widgetConfig.adBreakdown) {
                    case 'Day':
                        response.xAxis = 'date_stop';
                        params.time_increment = 1;
                        break;
                    case 'Month':
                        response.xAxis = 'date_stop';
                        params.time_increment = 30;
                        break;
                    case 'Device':
                        response.xAxis = 'impression_device';
                        params.breakdowns = 'impression_device';
                        break;
                    case 'Platform':
                        response.xAxis = 'device_platform';
                        params.breakdowns = 'device_platform';
                        break;
                    case 'Country':
                        response.xAxis = 'country';
                        params.breakdowns = 'country';
                        break;
                    case 'Region':
                            response.xAxis = 'region';
                            params.breakdowns = 'region';
                            break;
                    default:
                        response.xAxis = 'date_start';
                        break;
                }
            }
            
            this.setStatus(200)
            const campaignResp: any = await getInsights(response, widgetConfig, accountConfig, campaign, insightsFields, params);
            if (campaignResp) {
                response = campaignResp;
            }
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * get Campaign List
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */

    @Security('bearerAuth')
    @Post('facebook/campaign/:widgetAccountId')
    async getCampaignList(@Request() req: any, @Path() widgetAccountId: string): Promise<any> {
        try {
            const response = { status: true, data: [], message: '' };
            let widgetAccount: any = await Container.get(DataSource).getRepository(WidgetAccount)
                .createQueryBuilder('WA')
                .where('WA.clientId = :client_id', { client_id: req.userDetails.client_id })
                .andWhere('WA.id = :id', { id: widgetAccountId })
                .getMany();
            if (widgetAccount && widgetAccount.length > 0) {
                const config = widgetAccount[0].config ? JSON.parse(widgetAccount[0].config) : {};
                if (config?.accessToken) {
                    const accessToken = config.accessToken;
                    const accountId = req.body.adAccountId;
                    bizSdk.FacebookAdsApi.init(accessToken);
                    const AdAccount = bizSdk.AdAccount;
                    const Campaign = bizSdk.Campaign;
                    const account = new AdAccount(accountId);
                    const params = {
                        "effective_status": "[\"ACTIVE\",\"PAUSED\"]"
                    };
                    const accountData = await account.getCampaigns([Campaign.Fields.name], params);
                    if (accountData) {
                        response.data = accountData;
                    }
                } else {
                    response.data = [];
                    response.message = 'Widget Config not found.';
                }
            } else {
                response.data = [];
                response.message = 'Widget Account not found.';
            }
            this.setStatus(200)
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('facebook/adset/:widgetAccountId')
    async getCampaignAdSet(@Request() req: any, @Path() widgetAccountId: string, @Body() requestBody?: any): Promise<any> {
        try {
            const response = { status: true, data: [], message: '' };
            let widgetAccount: any = await Container.get(DataSource).getRepository(WidgetAccount)
                .createQueryBuilder('WA')
                .where('WA.clientId = :client_id', { client_id: req.userDetails.client_id })
                .andWhere('WA.id = :id', { id: widgetAccountId })
                .getMany();
            if (widgetAccount && widgetAccount.length > 0) {
                const config = widgetAccount[0].config ? JSON.parse(widgetAccount[0].config) : {};
                if (config?.accessToken && requestBody?.adCampaign) {
                    let apiVersion = process.env.FB_API_VERSION || "v18.0";
                    const url = `https://graph.facebook.com/${apiVersion}/me/adaccounts?fields=name%2Ccampaigns%7Bname%2Cadsets%7Bname%2Cads%7Bname%7D%7D%7D&access_token=${config.accessToken}`;
                    const apiFetchResult = await fetch(url, {
                        method: "GET",
                    });
                    const result = await apiFetchResult.json();
                    if (result?.data?.length) {
                        for (let a of result.data) {
                            if (a.campaigns?.data?.length) {
                                const findAdSet = a.campaigns.data.find((c) => (c.id === requestBody.adCampaign));
                                if (findAdSet?.adsets?.data?.length) {
                                    response.data = findAdSet.adsets.data.map((aSet) => {
                                        return {
                                            id: aSet.id,
                                            name: aSet.name
                                        };
                                    });
                                    break;
                                }
                            }
                        }
                    }
                } else {
                    response.data = [];
                    response.message = 'Widget Config not found.';
                }
            } else {
                response.data = [];
                response.message = 'Widget Account not found.';
            }
            this.setStatus(200)
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('facebook/insight')
    async getInsightList(@Request() req: any): Promise<any> {
        try {
            const response = { status: true, data: [], message: '' };
            let widgetAccount;
            widgetAccount = await Container.get(DataSource).getRepository(WidgetAccount)
                .createQueryBuilder('WA')
                .where('WA.clientId = :client_id', { client_id: req.userDetails.client_id })
                .andWhere('WA.id = :id', { id: req.body.widgetAccountId })
                .getMany();
            if (widgetAccount && widgetAccount.length > 0) {
                const config = widgetAccount[0].config ? JSON.parse(widgetAccount[0].config) : {};
                if (config && config.accessToken) {
                    const accessToken = config.accessToken;
                    const accountId = req.body.adAccountId;
                    const campaignId = req.body.adCampaignId;
                    const FacebookAdsApi = bizSdk.FacebookAdsApi.init(accessToken);
                    FacebookAdsApi.setDebug(true);
                    const AdAccount = bizSdk.AdAccount;
                    const Campaign = bizSdk.Campaign;
                    const AdSet = bizSdk.AdSet;
                    const account = new AdAccount(accountId);
                    const campaign = new Campaign(campaignId);

                    const adsResponse: any = await getCampaignAds(campaign, AdSet);
                    if (response) {
                        response.data = adsResponse.data;
                        response.status = adsResponse.status;
                        response.message = adsResponse.message;
                    }
                } else {
                    response.data = [];
                    response.message = 'Widget Config not found.';
                }
            } else {
                response.data = [];
                response.message = 'Widget Account not found.';
            }
            this.setStatus(200)
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('facebook/:widgetId/:drillDownLevel')
    @Middlewares(commonMiddleware)
    async getFacebookData(@Request() req: any, @Path() widgetId: string, @Body() requestBody?: any): Promise<any> {
        try {
            const result = await Container.get(DataSource).getRepository(DashboardWidget)
                .createQueryBuilder('DW')
                .leftJoinAndSelect('DW.widgetAccount', 'widgetAccount')
                .where('DW.id = :id', { id: [widgetId] })
                .getMany();
            if (!result || !Array.isArray(result) || !result.length) {
                this.setStatus(200)

                return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {
                    status: true,
                    displayType: "configure",
                    message: "Widget is not configured.",
                    data: [],
                }});
            }
            
            const widgetResponse: any = result[0]; 

            if (widgetResponse.isConfigured <= 0) {
                this.setStatus(200)
                return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {
                    status: true,
                    displayType: "configure",
                    message: "Widget is not configured.",
                    data: [],
                }});
            }

            let accountConfig: any = widgetResponse.widgetAccount.config ? JSON.parse(widgetResponse.widgetAccount.config) : {};
            if (requestBody?.widgetAccount) {
                let whereCondition = {id: requestBody.widgetAccount};
                const widgetResult: any = await Container.get(DataSource).getRepository(WidgetAccount).findOne({ where: whereCondition, select: ['config'] });
                if (widgetResult?.config) {
                    accountConfig = JSON.parse(widgetResult.config);
                }
            }
            
            let widgetConfig: any = widgetResponse.widgetConfig ? JSON.parse(widgetResponse.widgetConfig) : {};
            if (requestBody?.adAccount) {
                widgetConfig.adAccount = requestBody.adAccount;
            }
            if (requestBody?.adCampaign) {
                widgetConfig.adCampaign = requestBody.adCampaign;
            }
            if (requestBody?.adSet) {
                widgetConfig.adSet = requestBody.adSet;
            }
            if (requestBody?.statusType?.length) {
                widgetConfig.statusType = requestBody.statusType;
            }
            
            if (!widgetConfig?.adAccount || !widgetConfig?.adCampaign || !accountConfig?.accessToken) {
                this.setStatus(200)

                return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {
                    status: true,
                    displayType: "configure",
                    message: "Facebook account is not configured.",
                    data: widgetResponse,
                }});
            }
            if (req.params.drillDownLevel == 1) {
                widgetConfig.drilldown.viewId = widgetConfig.viewId;
                widgetConfig.drilldown.adAccount = widgetConfig.adAccount;
                widgetConfig.drilldown.adCampaign = widgetConfig.adCampaign;
                widgetConfig.drilldown.adBreakdown = widgetConfig.adBreakdown;
                widgetConfig = widgetConfig.drilldown;
                widgetConfig.chartType = widgetConfig.formChart.chartType;
            } else if (req.params.drillDownLevel == 2) {
                widgetConfig.drilldown.drilldown.viewId = widgetConfig.viewId;
                widgetConfig.drilldown.drilldown.adAccount = widgetConfig.adAccount;
                widgetConfig.drilldown.drilldown.adCampaign = widgetConfig.adCampaign;
                widgetConfig.drilldown.drilldown.adBreakdown = widgetConfig.adBreakdown;
                widgetConfig = widgetConfig.drilldown.drilldown;
                widgetConfig.chartType = widgetConfig.formChart.chartType;
            }
            let response: any = {
                status: true,
                displayType: widgetConfig.chartType,
                message: "Widget Configured.",
                data: [],
                widgetConfig: null,
                xAxis: null,
                yAxis: widgetConfig.adMetrics
            };
            const accessToken = accountConfig.accessToken;
            const campaignId = widgetConfig.adCampaign;
            const FacebookAdsApi = bizSdk.FacebookAdsApi.init(accessToken);
            FacebookAdsApi.setDebug(false);

            let params: any = {
                'level': 'ad', // ['ad', 'adset', 'campaign', 'account']
                'filtering': [],
            };
            if(requestBody.enableCountryStateFilter){
                if(requestBody.filterCountry && requestBody.filterCountry.length){
                    requestBody.filterCountry = requestBody.filterCountry.map((c) => c.toLowerCase());
                    params.breakdowns = 'country';

                }
                if(requestBody.filterState && requestBody.filterState.length){
                    requestBody.filterState = requestBody.filterState.map((c) => c.toLowerCase());
                    params.breakdowns = 'region';
                }

            }
            let campaign = null;
            if (widgetConfig?.adSet && widgetConfig?.adSet !== 'all') {
                const AdSet = bizSdk.AdSet;
                campaign = new AdSet(widgetConfig.adSet);
                params.level = 'adset';
            } else if (widgetConfig?.adAccount) {
                const Ad = bizSdk.Ad;
                campaign = new Ad(widgetConfig?.adAccount);

                if (Array.isArray(widgetConfig?.adCampaign) && widgetConfig?.adCampaign?.length) {
                    params.filtering.push({
                        field: "campaign.id",
                        operator: "IN", 
                        value: widgetConfig.adCampaign
                    });
                }
                
                if (widgetConfig?.chartType && ["FACEBOOK_TABLE"].indexOf(widgetConfig?.chartType) === -1) {
                    params.level = 'account';
                }
            } else {
                const Campaign = bizSdk.Campaign;
                campaign = new Campaign(campaignId);
            }

            if (widgetConfig?.statusType?.length) {
                params.filtering.push({
                    field: 'campaign.effective_status',
                    operator: 'IN',
                    value: widgetConfig.statusType
                });
            }

            let insightsFields = widgetConfig.adMetrics;
            
            if (widgetConfig?.dimention?.length) {
                insightsFields = insightsFields.concat(widgetConfig.dimention);
            }
            if (
                requestBody?.enableDateFilter && 
                requestBody?.dateRange?.length && 
                requestBody.dateRange[0] && 
                requestBody.dateRange[1]
            ) {
                params["time_range"] = {
                    'since': moment(requestBody.dateRange[0]).format("YYYY-MM-DD"),
                    'until': moment(requestBody.dateRange[1]).format("YYYY-MM-DD")
                };
            } else if (
                widgetConfig?.properties?.enableDateFilter &&
                widgetConfig?.properties?.compareWIth
            ) {
                let startDate = null;
                let endDate = moment().toDate();
                switch (widgetConfig.properties.compareWIth) {
                    case "1 Week":
                        startDate = moment().subtract(7, "days").toDate();
                        break;
                    case "1 Month":
                        startDate = moment().subtract(1, "months").toDate();
                        break;
                    case "3 Months":
                        startDate = moment().subtract(3, "months").toDate();
                        break;
                    case "1 Year":
                        startDate = moment().subtract(1, "years").toDate();
                        break;
                    case "Custom":
                        if (widgetConfig.properties?.dateRange?.length) {
                            startDate = moment(widgetConfig.properties?.dateRange[0]).toDate();
                            endDate = moment(widgetConfig.properties?.dateRange[1]).toDate();
                        }
                        break;
                }

                if (startDate && endDate) {
                    params["time_range"] = {
                        'since': moment(startDate).format("YYYY-MM-DD"),
                        'until': moment(endDate).format("YYYY-MM-DD")
                    };
                } else {
                    params["date_preset"] = "maximum";
                }
            } else {
                params["date_preset"] = "maximum";
            }
            if (widgetConfig.adBreakdown) {
                switch (widgetConfig.adBreakdown) {
                    case 'Day':
                        response.xAxis = 'date_stop';
                        params.time_increment = 1;
                        break;
                    case 'Month':
                        response.xAxis = 'date_stop';
                        params.time_increment = 30;
                        break;
                    case 'Device':
                        response.xAxis = 'impression_device';
                        params.breakdowns = 'impression_device';
                        break;
                    case 'Platform':
                        response.xAxis = 'device_platform';
                        params.breakdowns = 'device_platform';
                        break;
                    case 'Country':
                        response.xAxis = 'country';
                        params.breakdowns = 'country';
                        break;
                    default:
                        response.xAxis = 'date_start';
                        break;
                }
            }
            //start set date range as per table column compare formule
            let dateRanges = [];
            this.setDateRangeAsPerCompareFormula(widgetConfig, dateRanges);
            //end
            this.setStatus(200);
            let campaignResp: any = await getInsights(response, widgetConfig, accountConfig, campaign, insightsFields, params);
            if (campaignResp) {
                if(dateRanges.length>0){
                    const updatedCampaignResp = { ...campaignResp }; // Creating a shallow copy

                await this.fetchPrevDataPerFormulaAndUpdateResult(updatedCampaignResp,dateRanges, response, widgetConfig, accountConfig, campaign, insightsFields, params);
                campaignResp = updatedCampaignResp;
                }
                if(requestBody.enableCountryStateFilter){
                    if(requestBody.filterState && requestBody.filterState.length){
                        campaignResp.data = campaignResp.data.filter((item) => {
                            return (item._data.region && requestBody.filterState.indexOf(item._data.region.toLowerCase()) > -1);
                        });
                    } else if(requestBody.filterCountry && requestBody.filterCountry.length){
                        campaignResp.data = campaignResp.data.filter((item) => {
                            return (item._data.country && requestBody.filterCountry.indexOf(item._data.country.toLowerCase()) > -1);
                        });
                    }
                }
                response = campaignResp;
            }
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('facebook/generate-long-time-token')
    @Middlewares(commonMiddleware)
    async generateFbToken(@Request() req: any,@Body() requestBody?: any): Promise<any> {
        try {
            const result = await fbExchangeToken(requestBody?.token);

            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: result });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500)

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security('bearerAuth')
    @Post('facebook/ad-account')
    @Middlewares(commonMiddleware)
    async getAdAccountList(@Request() req: any, @Body() requestBody?: any): Promise<any> {
        try {
            const widgetAccount = await this.getWidgetAccount(req.userDetails.client_id, requestBody.widgetAccountId);
    
            if (!widgetAccount) {
                this.setStatus(404);
                return CommonHelper.apiSwaggerErrorResponse({ message : 'Widget Account not found.',error:{} }, false);
            }
    
            const config = widgetAccount[0].config ? JSON.parse(widgetAccount[0].config) : {};
            if (!config.accessToken) {
                this.setStatus(404);
                return CommonHelper.apiSwaggerErrorResponse({ message: 'Widget Config not found.',error:{} }, false);
            }
    
            const accessToken = config.accessToken;
            const user = await this.getFacebookUser(config.userID, accessToken);
    
            if (!user || !user.adaccounts || !Array.isArray(user.adaccounts.data) || user.adaccounts.data.length === 0) {
                this.setStatus(404);
                return CommonHelper.apiSwaggerErrorResponse({ message: 'No ad accounts found.',error:{} }, false);
            }
            let adAccountList = await this.filterAccountList(config.userID, user.adaccounts.data);
            const response = { status: true, data: adAccountList, message: '' };
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500)
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    async filterAccountList(facebookUserId: any,adAccountList: any) {
        const allowedAccountIds = ["act_414006902715942", "act_1841580682704343"];
        const targetFacebookUserId = "394876719710214";
    
        if (adAccountList.length > 0 && facebookUserId === targetFacebookUserId) {
            adAccountList = adAccountList.filter((account) => allowedAccountIds.includes(account.id));
        }
        return adAccountList;
    }
    async getWidgetAccount(clientId: string, widgetAccountId: string): Promise<any> {
        return Container.get(DataSource).getRepository(WidgetAccount)
            .createQueryBuilder('WA')
            .where('WA.clientId = :client_id', { client_id: clientId })
            .andWhere('WA.id = :id', { id: widgetAccountId })
            .getMany();
    }
    async getFacebookUser(userID: string, accessToken: string): Promise<any> {
        try {
            const FacebookAdsApi = bizSdk.FacebookAdsApi.init(accessToken);
            FacebookAdsApi.setDebug(true);
            return await FacebookAdsApi.call('GET', `https://graph.facebook.com/v18.0/${userID}?access_token=${accessToken}&fields=adaccounts{name}`);
        } catch (error) {
            throw new Error(error);
        }
    }
    async getFBTopPerformingAd(adAccountId: any, campaignId: any, adSetId: any, performanceField: string, timeRange: string, accessToken: string): Promise<any> {
        try {
          const FacebookAdsApi = bizSdk.FacebookAdsApi.init(accessToken);
          FacebookAdsApi.setDebug(true);
      
          let url = '';
          let fields = `ad_id,ad_name,${performanceField.split('_')[0]}`;
          const sort = `${performanceField}`;
      
          if (adAccountId && (!campaignId || campaignId === 'all' || campaignId.length==0) && (!adSetId || adSetId === 'all')) {
            url = `https://graph.facebook.com/v18.0/${adAccountId}/insights`;
          } else if (campaignId && (!adSetId || adSetId === 'all')) {
            url = `https://graph.facebook.com/v18.0/${campaignId}/insights`;
          } else if (adSetId && adSetId !== 'all') {
            url = `https://graph.facebook.com/v18.0/${adSetId}/insights`;
          }
      
          url += `?fields=${fields}&level=ad&time_range=${timeRange}&sort=['${sort}']&limit=1&access_token=${accessToken}`;
      
          return await FacebookAdsApi.call('GET', url);
        } catch (error) {
          throw new Error(error);
        }
      }
    async getFBAdPreview(adId: string, accessToken: string){
        try {
            const FacebookAdsApi = bizSdk.FacebookAdsApi.init(accessToken);
            FacebookAdsApi.setDebug(true);
            return await FacebookAdsApi.call('GET', `https://graph.facebook.com/v18.0/${adId}/previews?ad_format=DESKTOP_FEED_STANDARD&access_token=${accessToken}`);
        } catch (error) {
            throw new Error(error);
        }
    }
    @Security('bearerAuth')
    @Post('facebook/top-performing-ad')
    @Middlewares(commonMiddleware)
    async getTopPerformingAd(@Request() req: any, @Body() requestBody?:any):Promise<any>{
        let {widgetAccountId,adAccountId,campaignId,adSetId,dateRange,performanceField} = requestBody;
        //get token
        const widgetAccount = await this.getWidgetAccount(req.userDetails.client_id, widgetAccountId);
    
            if (!widgetAccount) {
                this.setStatus(404);
                return CommonHelper.apiSwaggerErrorResponse({ message : 'Widget Account not found.',error:{} }, false);
            }
    
            const config = widgetAccount[0].config ? JSON.parse(widgetAccount[0].config) : {};
            if (!config.accessToken) {
                this.setStatus(404);
                return CommonHelper.apiSwaggerErrorResponse({ message: 'Widget Config not found.',error:{} }, false);
            }
    
            const accessToken = config.accessToken;
            const FacebookAdsApi = bizSdk.FacebookAdsApi.init(accessToken);
            FacebookAdsApi.setDebug(true);
            let filterDateRange=
            {
                'since': moment(dateRange[0]).format("YYYY-MM-DD"),
                'until': moment(dateRange[1]).format("YYYY-MM-DD")
            };
            try{
            let topPerformingAd = await this.getFBTopPerformingAd(adAccountId,campaignId,adSetId,performanceField,JSON.stringify(filterDateRange), accessToken);
            if(topPerformingAd && topPerformingAd.data && topPerformingAd.data.length){
                topPerformingAd = topPerformingAd.data[0];
                if(topPerformingAd.ad_id){
                    let adPreview = await this.getFBAdPreview(topPerformingAd.ad_id,accessToken);
                    topPerformingAd.adPreview = adPreview;
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: topPerformingAd });
            }catch(error){
                return CommonHelper.apiSwaggerErrorResponse({ message: 'Error while fetching top performing ad.',error:{} }, false);
            }
    }
    
    private setDateRangeAsPerCompareFormula(widgetConfig: any, dateRange: any[]) {
        if (widgetConfig?.chartType === "FACEBOOK_TABLE" &&
            widgetConfig?.properties?.enableTableColumnFormulae &&
            widgetConfig?.properties?.tableColumnFormulae?.length) {
            widgetConfig.properties.tableColumnFormulae.forEach(async (formulae) => {
                if (formulae.formula &&
                    formulae.formula == "compare" &&
                    formulae.column &&
                    formulae.column != "") {

                    let prevDateRange = this.getPreviousPeriodDates(
                        widgetConfig.properties.dateRange
                    );


                    dateRange.push({
                        column: formulae.column.replace("metrics.", ""),
                        position: formulae.position,
                        newColumnName: formulae.newColumnName
                            ? formulae.newColumnName
                            : "",
                        prevDateRange: prevDateRange,
                    });
                }
            });
        }
    }
    private async fetchPrevDataPerFormulaAndUpdateResult(result:any,dateRanges:any,response:any, widgetConfig:any, accountConfig:any, campaign:any, insightsFields:any, params:any){
        if(dateRanges.length){
            for(let dateRange of dateRanges){
                let parameters=params;
                parameters["time_range"] = {
                    'since': dateRange.prevDateRange[0],
                    'until': dateRange.prevDateRange[1]
                };
                const resultForCompare:any = await getInsights(response, widgetConfig, accountConfig, campaign, insightsFields, parameters);
                const updatedResult = { ...result }; // Creating a shallow copy

                if (resultForCompare?.data) {
                    if (resultForCompare?.data?.length) {
                        await updatedResult?.data?.forEach(
                            async (element, index) => {
                                if (element?._data) {
                                    let compareValue = parseFloat(
                                        resultForCompare?.data[index]?._data[
                                            dateRange.column
                                        ]
                                    );

                                    if (compareValue) {
                                        let currentValue = parseFloat(
                                            element?._data[
                                                dateRange.column
                                            ]
                                        );
                                        let changeValue =
                                            currentValue - compareValue;
                                        let percentageChange =
                                            (changeValue /
                                                Math.abs(compareValue)) *
                                            100;

                                        let change;

                                        if (percentageChange === 0) {
                                            change = "grey";
                                        } else if (percentageChange > 0) {
                                            change = "green";
                                        } else {
                                            change = "red";
                                        }
                                        let metricToAdd,
                                            metricIdToAdd,
                                            metricNameToAdd;
                                        if (
                                            dateRange.position ===
                                            "New-Column"
                                        ) {
                                            element._data[
                                                dateRange.column + "-vsPrev"
                                            ] =
                                                percentageChange.toFixed(0) +
                                                "%" +
                                                "=" +
                                                change;

                                            metricToAdd = "metrics.vsPrev";
                                            metricIdToAdd =
                                                "metrics." +
                                                dateRange.column +
                                                "-vsPrev";
                                            metricNameToAdd =
                                            dateRange.column +
                                                "-vsPrev";
                                            // Check if metricToAdd does not exist in widgetConfig.metric
                                            if (
                                                widgetConfig.metric.indexOf(
                                                    metricToAdd
                                                ) === -1
                                            ) {
                                                widgetConfig.metric.push(
                                                    metricToAdd
                                                );
                                            }

                                            // Check if metricIdToAdd does not exist in widgetConfig.selectedMetrics
                                            const existingMetricIndex =
                                                widgetConfig.selectedMetrics.findIndex(
                                                    (metric) =>
                                                        metric.id ===
                                                        metricIdToAdd
                                                );

                                            if (existingMetricIndex === -1) {
                                                widgetConfig.selectedMetrics.push(
                                                    {
                                                        id: metricIdToAdd,
                                                        name: metricNameToAdd,
                                                    }
                                                );
                                            }
                                        } else {
                                            //Within-Column
                                            //prefix percentage change
                                            element._data[
                                                dateRange.column
                                            ] =
                                                percentageChange.toFixed(0) +
                                                "%" +
                                                "=" +
                                                change +
                                                "=" +
                                                element._data[
                                                    dateRange.column
                                                ];
                                        }
                                    }
                                }
                            }
                        );
                        result = updatedResult;
                    }
                }
            }
        }
    }

    getPreviousPeriodDates(dateRange) {
        const startDate = new Date(dateRange[0]);
        const endDate = new Date(dateRange[1]);
    
        // Calculate the duration in milliseconds
        const duration = endDate.getTime() - startDate.getTime();
    
        // Calculate the start and end dates for the previous period
        const previousEndDate = new Date(startDate.getTime() - 1); // Subtract 1 millisecond from the start date
        const previousStartDate = new Date(
            previousEndDate.getTime() - duration
        );
    
        // Format the dates as strings in "YYYY-MM-DD" format
        const formattedStartDate = this.formatDate(previousStartDate);
        const formattedEndDate = this.formatDate(previousEndDate);
    
        return [formattedStartDate, formattedEndDate];
    }
    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    }
}


function getCampaignAds(campaign, AdSet) {
    return new Promise((resolve) => {
        const response = { status: true, data: [], message: '' };
        campaign.getAdSets([AdSet.Fields.name]).then(async result => {
            response.message = 'then';
            const insightsFields = [
                'impressions',
                'frequency',
                'unique_clicks',
                'reach'
            ];
            // country, impression_device, device_platform
            // const insightData = await (new AdSet(adSetId)).getInsights(insightsFields, {
            const insightData = await campaign.getInsights(insightsFields, {
                'level': 'ad',
                'date_preset': 'maximum',
                "time_increment": 30
            });
            response.data = insightData;
            resolve(response);
        }).catch(err => {
            console.error('err', err);
            response.message = 'catch';
            resolve(response);
        });
    });
}
async function getInsights(response, widgetConfig, accountConfig, campaign, insightsFields, params) {
    try {
        let adCreatives = [];
        let ad_image_is_required = false;
        if(insightsFields.indexOf('ad_image') > -1){
            ad_image_is_required = true;
            const adCreativeData = await getFBAdCreatives(widgetConfig.adAccount, accountConfig.accessToken);
            if (adCreativeData?.data?.length) {
                adCreatives = adCreativeData.data;
            }
            insightsFields.splice(insightsFields.indexOf('ad_image'), 1);
        }
        
        params.limit = 25000;
        insightsFields.push('ad_id'); 
        const insightData = await campaign.getInsights(insightsFields, params);
        
        for (const element of insightData) {
            if(ad_image_is_required){
                if (element.ad_id) {
                    const ad = adCreatives.find((c) => c.id === element.ad_id);
                    let adCreative=ad?.adcreatives?.data[0];
                    if (adCreative) {
                        if(adCreative.image_url){
                            element["ad_image"] = adCreative.image_url;
                        }else if(adCreative.thumbnail_url){
                            element["ad_image"] = adCreative.thumbnail_url;
                        }
                    }

                    // let adCreativeId = null;
                    // let fbadCreative= await getFBAdCreative(element.ad_id, accountConfig.accessToken);
                    // if(fbadCreative?.creative){
                    //     adCreativeId = fbadCreative.creative.id;
                    //     const adCreative = adCreatives.find((c) => c.id === adCreativeId);
                    //     if (adCreative) {
                    //         element["ad_image"] = adCreative.image_url;
                    //     }
                    // }
                    
                }
            }
            if (element.conversions) {
                element.conversions = Number(element.conversions[0].value);
            }
            if (element.cost_per_conversion) {
                element.cost_per_conversion = Number(element.cost_per_conversion[0].value).toFixed(2);
            }
            if (element.ctr) {
                element.ctr = Number(element.ctr).toFixed(2);
            }
            if (element.cost_per_unique_click) {
                element.cost_per_unique_click = Number(element.cost_per_unique_click).toFixed(2);
            }
        }

        response.message = 'Record found.';
        response.updatedOn = moment.utc().format("MM-DD-YYYY HH:mm:ss")
        response.data = insightData;
        response.widgetConfig = widgetConfig;
        response.properties = widgetConfig.properties || {};
        response.accountConfig = accountConfig;

        return response;
    } catch (error) {
        console.error('error', error);
        response.displayType = 'error';
        response.message = 'Something wrong while getting data. please try again.';
        response.data = [];

        if (error?.response?.error?.message) {
            response.message = error?.response?.error.message; // + `<br/> since: ${params.time_range.since}, until: ${params.time_range.until}`;
        }

        return response;
    }
}
async function getFBAdCreatives(fbAccountId: string, accessToken: string){
    try {
        const FacebookAdsApi = bizSdk.FacebookAdsApi.init(accessToken);
        FacebookAdsApi.setDebug(true);
        //return await FacebookAdsApi.call('GET', `https://graph.facebook.com/v18.0/${fbAccountId}/adcreatives?fields=name,ad_id,thumbnail_url,image_url&access_token=${accessToken}`);
        return await FacebookAdsApi.call('GET', `https://graph.facebook.com/v18.0/${fbAccountId}/ads?fields=id,name,adcreatives{thumbnail_url,image_url}&access_token=${accessToken}`);
    } catch (error) {
        throw new Error(error);
    }
}
async function getFBAdCreative(adId: string, accessToken: string){
    try {
        const FacebookAdsApi = bizSdk.FacebookAdsApi.init(accessToken);
        FacebookAdsApi.setDebug(true);
        return await FacebookAdsApi.call('GET', `https://graph.facebook.com/v18.0/${adId}?fields=creative&access_token=${accessToken}`);
    } catch (error) {
        throw new Error(error);
    }
}

async function fbExchangeToken(token) {
    return new Promise(async(resolve) => {
        try {
            let result = null;
            let apiVersion = process.env.FB_API_VERSION || "v18.0";
            let appId = process.env.FB_APP_ID || "";
            let appSecret = process.env.FB_APP_SECRET || "";

            if (appId && appSecret) {
                const url = `https://graph.facebook.com/${apiVersion}/oauth/access_token?grant_type=fb_exchange_token&client_id=${appId}&client_secret=${appSecret}&fb_exchange_token=${token}`;
                const apiFetchResult = await fetch(url, {
                    method: "GET",
                });
                result = await apiFetchResult.json();
            }

            resolve(result);
        } catch (error) {
            resolve(error);
        }
    });
}