import {CommonHelper,ApiErrorResponse} from "../../../../utils/helpers/common.helper";
import {formBuilderTableName} from "../../utils/constants/api.constant";
import { ConnectorsUtil } from "../../../../utils/connectors.util";
import {BarChart} from "./charts/barChart";
import {PieChart} from "./charts/pieChart";
import {LineChart} from "./charts/lineChart";
import {MixDonutIncomeChart} from "./charts/mix-donut-incomeChart";
import {MixDonutExpenseChart} from "./charts/mix-donut-expenseChart";
import {BarLineChart} from "./charts/barLineChart";
import {TableChart} from "./charts/tableChart";
import {DrillDownBarChart} from "./charts/drill-Down-barChart";
import Container from 'typedi';
import {DataSource} from 'typeorm';
import { Post, Request, Path, Route, Security, Tags, Patch, Middlewares, Body } from 'tsoa';
import { commonMiddleware } from "../../../../middlewares/common.middleware";
import moment from "moment";
import { DashboardWidget, WidgetAccount } from "entities";
import { dataSource } from "core/data-source";
import axios from "axios";

@Route('dashboard')
@Tags('Dynamic Dashboard')

export class DashboardChartController {
    private barChart: BarChart
    private pieChart: PieChart
    private lineChart: LineChart
    private mixDonutIncomeChart: MixDonutIncomeChart
    private mixDonutExpenseChart: MixDonutExpenseChart
    private barLineChart: BarLineChart
    private tableChart: TableChart
    private drillDownBarChart: DrillDownBarChart
    constructor() {
        this.barChart = new BarChart();
        this.pieChart = new PieChart();
        this.lineChart = new LineChart();
        this.mixDonutIncomeChart = new MixDonutIncomeChart();
        this.mixDonutExpenseChart = new MixDonutExpenseChart();
        this.barLineChart = new BarLineChart();
        this.tableChart = new TableChart();
        this.drillDownBarChart = new DrillDownBarChart();
    }

    chartTypeList: any = ["PIE","BAR","LINE","MIX_DONUT_INCOME","MIX_DONUT_EXPENSE","BAR_LINE","TABLE","DRILL_DOWN_BAR_BAR",""];
    @Security('bearerAuth')
    @Post('form-chart/:widgetId')
    @Middlewares(commonMiddleware)
    async chartExecution(@Request() req: any, @Path() widgetId: string): Promise<any> {
        let result;
        if((this.chartTypeList.indexOf(req.body.chartType)  > -1) || (widgetId=== 'preview' && this.chartTypeList.indexOf(req.body.widgetConfig.chartType) > -1 && req.body.widgetAccount !== null) || (req.params.widgetId === 'preview' && this.chartTypeList.indexOf(req.body.widgetConfig.chartType) > -1 && req.body.widgetConfig.sourceType === 'FORMS') || (req.params.widgetId === 'preview' && this.chartTypeList.indexOf(req.body.widgetConfig.chartType) > -1 && req.body.widgetConfig.sourceType === 'CUSTOM_TABLE') || (req.params.widgetId === 'preview' && this.chartTypeList.indexOf(req.body.widgetConfig.chartType) > -1 && req.body.widgetConfig.sourceType === 'PUBLIC_VIEW360_TABLE') || (req.params.widgetId === 'preview' && this.chartTypeList.indexOf(req.body.widgetConfig.chartType) > -1 && req.body.widgetConfig.sourceType === 'VIEW360TABLES')) {
            result = await this.execute(req);
            if(result?.data  && result?.status){
                result.updatedOn = moment.utc().format('MM-DD-YYYY HH:mm:ss')
                return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: result });
            }
            if(result?.displayType === 'error') {
                return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {
                    status: true,
                    displayType: "error",
                    message: result.message,
                    data: [],
                }});
            }

            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {
                status: true,
                displayType: "configure",
                message: result?.message || "",
                data: [],
                updatedOn: moment.utc().format('MM-DD-YYYY HH:mm:ss')
            }});
        }
        
        return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {
            status: true,
            displayType: "configure",
            message: "Widget is not configured.",
            data: [],
        }});
    }

    @Security('bearerAuth')
    @Post('form-scheduler/:widgetId')
    @Middlewares(commonMiddleware)
    async formScheduler(@Request() req: any, @Path() widgetId: string, @Body() requestBody: any): Promise<any> {
        try {
            let response = {
                status: true,
                displayType: "configure",
                message: "Success",
                formDataConfig: [],
                formData: [],
            };

            let widgetAccountConfig = null;
            let widgetConfig = null;
            if (requestBody?.widgetConfig && requestBody?.widgetAccount) {
                widgetConfig = requestBody.widgetConfig;
                const result: any = await Container.get(DataSource).getRepository(WidgetAccount).createQueryBuilder("DW").where("DW.ID = :id", { id: requestBody.widgetAccount }).getOne();
                if (result?.config) {
                    widgetAccountConfig = result;
                }
            } else {
                const result: any = await Container.get(DataSource).getRepository(DashboardWidget).createQueryBuilder("DW").leftJoinAndSelect('DW.widgetAccount', 'widgetAccount').where("DW.ID = :id", { id: widgetId }).getOne();
                if (result?.id) {
                    widgetAccountConfig = result.widgetAccount;
                    widgetConfig = JSON.parse(result?.widgetConfig || "{}");
                }
            }
            
            if (widgetAccountConfig?.id && widgetConfig) {
                if (widgetAccountConfig?.widgetType === "MYSQL" && widgetConfig?.sourceData) {
                    const MySqlConfig = JSON.parse(widgetAccountConfig?.config || "{}");
                    let selectList = [];
                    if (widgetConfig?.extraField?.length) {
                        selectList = widgetConfig.extraField;
                    }

                    if (widgetConfig?.titleField && !selectList.includes(widgetConfig?.titleField)) {
                        selectList.push(widgetConfig.titleField);
                    }
                    if (widgetConfig?.startDateField && !selectList.includes(widgetConfig?.startDateField)) {
                        selectList.push(widgetConfig.startDateField);
                    }
                    if (widgetConfig?.endDateField && !selectList.includes(widgetConfig?.endDateField)) {
                        selectList.push(widgetConfig.endDateField);
                    }

                    let query = `SELECT ${selectList.join(", ")} FROM ${widgetConfig.sourceData}`;
                    const mySqlData: any = await ConnectorsUtil.connect(
                        null,
                        query,
                        MySqlConfig
                    );
                    if (mySqlData?.status && mySqlData?.data?.length) {
                        response.formData = mySqlData.data;
                    }
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Patch('table-chart/:widgetId')
    async tableChartUpdateExecution(@Request() req: any, @Path() widgetId: string): Promise<any> {
        return this.tableChart.updateTableExecution(req);
    }

    @Security('bearerAuth')
    @Post('weather/:widgetId')
    @Middlewares(commonMiddleware)
    async weatherWidget(@Request() req: any, @Path() widgetId: string): Promise<any> {
        try {
            const result = await Container.get(DataSource).getRepository(DashboardWidget)
                .createQueryBuilder('DW')
                .leftJoinAndSelect('DW.widgetAccount', 'widgetAccount')
                .where('DW.id = :id', { id: [widgetId] })
                .getMany();
            if (result) {
                const widgetConfig = JSON.parse(result[0].widgetConfig);
                const accountId = widgetConfig?.weatherDetails?.weatherSource;
                const widgetAccountResult: WidgetAccount = await dataSource
                    .getRepository(WidgetAccount)
                    .findOneBy({ id: accountId });

                if (widgetAccountResult) {
                    const weatherConfig = JSON.parse(widgetAccountResult?.config)
                    const apiURL = `${weatherConfig.url}?q=${widgetConfig.location}&units=${widgetConfig.unit}&appid=${weatherConfig.key}`;
                    console.log("Api URL :: ", apiURL)

                    const apiResult = await axios.get(apiURL);
                    if (apiResult) {
                        apiResult.data.updatedOn = moment.utc().format('MM-DD-YYYY HH:mm:ss');
                        return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: apiResult.data })
                    } else {
                        return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: {} })
                    }
                } else {
                    return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: []})
                }
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: []})
            }            
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    // /**
    //  * Get Form Chart Data
    //  * @param req Request from the front-end
    //  * @param res Response that will send to the front-end
    //  * @param next It will be use for passing to next method
    //  */
    // async getFormChartData(req: any, res: any, next: any): Promise<any> {
    //     try {
    //         const response: any = {status: false, displayType: "", message: "", data: []};
    //         let widgetConfig, accountConfigDetails;
    //         if (req.params.widgetId !== 'preview') {
    //             const id = req.params.widgetId;
    //             const result = await Container.get(DataSource).getRepository(DashboardWidget)
    //                 .createQueryBuilder('DW')
    //                 .leftJoinAndSelect('DW.widgetAccount', 'widgetAccount')
    //                 .where('DW.id = :id', {id: id})
    //                 .getMany();
    //             if (result && result.length > 0) {
    //                 const widgetResponse: any = result[0];
    //                 if (widgetResponse.isConfigured <= 0) {
    //                     const response = {
    //                         status: true,
    //                         displayType: "configure",
    //                         message: "Widget is not configured.",
    //                         data: [],
    //                     };
    //                     return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //                 }
    //                 widgetConfig = widgetResponse.widgetConfig ? JSON.parse(widgetResponse.widgetConfig.replace(/\\/g, "")) : {};
    //                 accountConfigDetails = widgetResponse.widgetAccount.config ? JSON.parse(widgetResponse.widgetAccount.config) : {};
    //             } else {
    //                 response.status = true;
    //                 response.displayType = "error";
    //                 response.message = "Could not find widget.";
    //                 return CommonHelper.apiSuccessResponse(res, {message: null, data: result})
    //             }
    //         } else {
    //             widgetConfig = req.body.widgetConfig ? req.body.widgetConfig : {};
    //             const queryResponse = await Container.get(DataSource).getRepository(WidgetAccount)
    //                 .findOne({where: {id: req.body.widgetAccount}});
    //             accountConfigDetails = queryResponse.config ? JSON.parse(queryResponse.config) : {};
    //         }
    //         if (widgetConfig && widgetConfig.sourceType && widgetConfig.sourceType === "ACCOUNT") {
    //             const response: any = {status: true, data: [], error: null};
    //             response.cacheWidget = widgetConfig.cacheWidget || false;
    //             response.isManualQuery = widgetConfig.isManualQuery || false;
    //             response.sourceType = widgetConfig.sourceType;
    //             response.displayType = widgetConfig.chartType;
    //             response.formField = widgetConfig.formField;
    //             response.config = widgetConfig.config ? widgetConfig.config : {};
    //             response.properties = widgetConfig.properties || {};
    //             //accountConfigDetails = widgetResponse.widgetAccount.config ? JSON.parse(widgetResponse.widgetAccount.config) : {};
    //             if (accountConfigDetails && accountConfigDetails.dbType === "MSSQL") {
    //                 let mssqlQuery = "";
    //                 if (widgetConfig.isManualQuery && widgetConfig.query) {
    //                     mssqlQuery = widgetConfig.query;
    //                 } else {
    //                     if (!Array.isArray(widgetConfig.yAxis)) {
    //                         widgetConfig.yAxis = [widgetConfig.yAxis];
    //                     }
    //                     const selectFields = [];
    //                     selectFields.push(`[${widgetConfig.xAxis}] as '${widgetConfig.xAxis}'`);
    //                     for (const yField of widgetConfig.yAxis) {
    //                         if (widgetConfig.operationType === 'SUM') {
    //                             selectFields.push(`SUM([${yField}]) as '${yField}'`);
    //                         } else if (widgetConfig.operationType === 'COUNT') {
    //                             selectFields.push(`COUNT([${yField}]) as '${yField}'`);
    //                         } else {
    //                             selectFields.push(`[${yField}]`);
    //                         }
    //                     }
    //                     mssqlQuery = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.form} GROUP BY ${widgetConfig.xAxis}`;
    //                 }
    //                 const mssqlData: any = await ConnectorsUtil.connect(null, mssqlQuery, accountConfigDetails);
    //                 if (mssqlData.status) {
    //                     response.data = [];
    //                     response.xAxis = '';
    //                     response.yAxis = [];
    //                     if (mssqlData.data && mssqlData.data.recordset && mssqlData.data.recordset.length > 0) {
    //                         const queryFields = Object.keys(mssqlData.data.recordset[0]);
    //                         response.xAxis = queryFields[0];
    //                         queryFields.splice(0, 1);
    //                         response.yAxis = queryFields;
    //                         response.data = mssqlData.data.recordset;
    //                     }
    //                     return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //                 } else {
    //                     response.error = mssqlData.message;
    //                     return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //                 }
    //             } else if (accountConfigDetails && accountConfigDetails.dbType === "MYSQL") {
    //                 const accountConfig = {
    //                     host: accountConfigDetails.dbHost || "",
    //                     user: accountConfigDetails.dbUser || "",
    //                     password: accountConfigDetails.dbPassword || "",
    //                     database: accountConfigDetails.dbName || "",
    //                 };
    //                 const customConnection = await mysql.createConnection(accountConfig);
    //                 customConnection.connect((err) => {
    //                     if (err) {
    //                         response.error = err;
    //                         return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //                     } else {
    //                         let sqlQuery = "";
    //                         if (widgetConfig.isManualQuery && widgetConfig.query) {
    //                             sqlQuery = widgetConfig.query;
    //                         } else {
    //                             if (!Array.isArray(widgetConfig.yAxis)) {
    //                                 widgetConfig.yAxis = [widgetConfig.yAxis];
    //                             }
    //                             const selectFields = [];
    //                             selectFields.push(this.addtick(widgetConfig.xAxis));
    //                             for (const yField of widgetConfig.yAxis) {
    //                                 if (widgetConfig.operationType === 'SUM') {
    //                                     selectFields.push(`SUM(${this.addtick(yField)}) as ${this.addtick(yField)}`);
    //                                 } else if (widgetConfig.operationType === 'COUNT') {
    //                                     selectFields.push(`COUNT(${this.addtick(yField)}) as ${this.addtick(yField)}`);
    //                                 } else {
    //                                     selectFields.push(`${this.addtick(yField)}`);
    //                                 }
    //                             }
    //                             sqlQuery = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)} GROUP BY ${this.addtick(widgetConfig.xAxis)}`;
    //                         }
    //                         let queryData = [];
    //                         // console.log('sqlQuery', sqlQuery);
    //                         customConnection.query(
    //                             sqlQuery,
    //                             queryData,
    //                             (cQueryError, cQueryResult, cQueryFields) => {
    //                                 customConnection.destroy();
    //                                 if (cQueryError) {
    //                                     response.error = cQueryError;
    //                                     return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //                                 } else {
    //                                     const queryFields = cQueryFields.map(obj => obj.name);
    //                                     response.xAxis = queryFields[0];
    //                                     queryFields.splice(0, 1);
    //                                     response.yAxis = queryFields;
    //                                     response.data = cQueryResult;
    //                                     return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //                                 }
    //                             }
    //                         );
    //                     }
    //                 });
    //             } else {
    //                 return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //             }
    //         } else if (widgetConfig && widgetConfig.sourceType && widgetConfig.sourceType === "CUSTOM_TABLE") {
    //             const response: any = {status: true, data: [], error: null};
    //             response.cacheWidget = widgetConfig.cacheWidget || false;
    //             response.isManualQuery = widgetConfig.isManualQuery || false;
    //             response.sourceType = widgetConfig.sourceType;
    //             response.displayType = widgetConfig.chartType;
    //             response.formField = widgetConfig.formField;
    //             response.config = widgetConfig.config ? widgetConfig.config : {};
    //             response.properties = widgetConfig.properties || {};
    //
    //             if (!Array.isArray(widgetConfig.yAxis)) {
    //                 widgetConfig.yAxis = [widgetConfig.yAxis];
    //             }
    //             const selectFields = [];
    //             selectFields.push(`DISTINCT ${widgetConfig.xAxis}`);
    //             for (const yField of widgetConfig.yAxis) {
    //                 if (widgetConfig.operationType === 'SUM') {
    //                     selectFields.push(`SUM(${yField}) ${yField}`);
    //                 } else if (widgetConfig.operationType === 'COUNT') {
    //                     selectFields.push(`COUNT(${yField}) as ${yField}`);
    //                 } else {
    //                     selectFields.push(`${yField}`);
    //                 }
    //             }
    //             let stmt = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.customTableName.toUpperCase()}`;
    //             stmt += ` WHERE 1 = 1`;
    //             if (widgetConfig.chartType === 'TABLE' && Array.isArray(widgetConfig.whereFields) && widgetConfig.whereFields.length > 0) {
    //                 let innerConditions = [];
    //                 for (const whereValue of widgetConfig.whereFields) {
    //                     let conditionQuery = this.getConditionalQuery(whereValue.columnName, whereValue.matchCase, whereValue.matchValue, 'normal');
    //                     if (conditionQuery) {
    //                         innerConditions.push(`${conditionQuery}`);
    //                     }
    //                 }
    //                 if (innerConditions.length) {
    //                     stmt += ` AND ${innerConditions.join(' AND ')}`;
    //                 }
    //             }
    //             if (widgetConfig.properties && widgetConfig.properties.enableTodayDateFilter && widgetConfig.properties.todayDateFilterOn) {
    //                 let startDate = moment().startOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                 let endDate = moment().endOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                 if (req.body.filterDate) {
    //                     startDate = moment(req.body.filterDate).startOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                     endDate = moment(req.body.filterDate).endOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                 }
    //                 stmt += ` AND ${widgetConfig.properties.todayDateFilterOn} >= TO_DATE('${startDate}', 'MM-DD-YYYY HH24:MI:SS')`;
    //                 stmt += ` AND ${widgetConfig.properties.todayDateFilterOn} <= TO_DATE('${endDate}', 'MM-DD-YYYY HH24:MI:SS')`;
    //             }
    //             if (widgetConfig.operationType === 'SUM' || widgetConfig.operationType === 'COUNT') {
    //                 stmt += ` GROUP BY ${widgetConfig.xAxis}`;
    //             }
    //             if (widgetConfig.properties && widgetConfig.properties.orderField) {
    //                 stmt += ` ORDER BY ${widgetConfig.properties.orderField} ${widgetConfig.properties.orderByField}`;
    //             }
    //
    //             console.log(stmt);
    //             let results: any = await Container.get(DataSource).manager.query(stmt); // await db_procedure.v_select(stmt);
    //             // console.log('results', results, typeof results);
    //             if (results && results.errorNum) {
    //                 response.displayType = "error";
    //                 response.message = `Error: ${results.message}`;
    //                 response.data = [];
    //             } else if (results && results.rows && results.rows.length > 0) {
    //                 response.xAxis = widgetConfig.xAxis;
    //                 response.yAxis = widgetConfig.yAxis;
    //                 response.data = results.rows;
    //             }
    //             return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //         } else {
    //             let constants: any = {};
    //             let formStmt = `SELECT fb.ID, fb.FORM_ID, fb.CREATEDON, fb.SUBMITTED_DATA FROM ${constants.formBuilderTableName}${req.userDetails.client_id} fb WHERE fb.FORM_ID = :formId`;
    //             let formStmtData: any = {formId: widgetConfig.form};
    //             let startDate = moment().startOf('day').format('MM-DD-YYYY HH:mm:ss');
    //             let endDate = moment().endOf('day').format('MM-DD-YYYY HH:mm:ss');
    //             let filterDate = moment().format('MM-DD-YYYY');
    //             if (req.body.filterDate) {
    //                 startDate = moment(req.body.filterDate).startOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                 endDate = moment(req.body.filterDate).endOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                 filterDate = moment(req.body.filterDate).format('MM-DD-YYYY');
    //             }
    //             if (widgetConfig.chartType === 'TABLE') {
    //                 if (widgetConfig.properties && widgetConfig.properties.enableTodayDateFilter && widgetConfig.properties.todayDateFilterOn === 'CREATEDON') {
    //                     formStmt += ` AND fb.CREATEDON >= TO_DATE('${startDate}', 'MM-DD-YYYY HH24:MI:SS')`;
    //                     formStmt += ` AND fb.CREATEDON <= TO_DATE('${endDate}', 'MM-DD-YYYY HH24:MI:SS')`;
    //                 }
    //                 if (Array.isArray(widgetConfig.whereFields) && widgetConfig.whereFields.length > 0) {
    //                     // let innerConditions = [];
    //                     for (const whereValue of widgetConfig.whereFields) {
    //                         if (whereValue.columnName && whereValue.matchCase, whereValue.matchValue) {
    //                             const conditionOperator = this.getConditionalQuery(null, whereValue.matchCase, null, 'operator');
    //                             formStmt += ` AND json_value(fb.SUBMITTED_DATA, '$.${whereValue.columnName}') ${conditionOperator} '${whereValue.matchValue}'`;
    //                         }
    //
    //                     }
    //
    //                 }
    //                 if (widgetConfig.enableCustomStatement && widgetConfig.customStatement) {
    //                     formStmt = widgetConfig.customStatement
    //                         .replaceAll(`{FILTER_DATE}`, filterDate)
    //                         .replaceAll(`{FILTER_DATE_START}`, startDate)
    //                         .replaceAll(`{FILTER_DATE_END}`, endDate);
    //                     formStmtData = {};
    //                 }
    //             }
    //             let results = null;
    //             if (widgetConfig.enableApiMode && widgetConfig.apiState) {
    //                 formStmt = null;
    //                 formStmtData = {};
    //                 if (widgetConfig.apiState === 'missed-sign-in') {
    //                     results = await MissedSignInOffUtil.getMissedSignIn(req.userDetails.client_id, startDate, endDate); // await pwaCtrl.getMissedSignIn(req.userDetails.client_id, startDate, endDate);
    //                 } else if (widgetConfig.apiState === 'missed-sign-off') {
    //                     results = await MissedSignInOffUtil.getMissedSignOff(req.userDetails.client_id, startDate, endDate); //await pwaCtrl.getMissedSignOff(req.userDetails.client_id, startDate, endDate);
    //                 }
    //             }
    //             if (formStmt) {
    //                 results = await Container.get(DataSource).manager.query(formStmt);// await db_procedure.v_select(formStmt, formStmtData, { fetchInfo: ["SUBMITTED_DATA"] });
    //             }
    //             response.status = true;
    //             response.cacheWidget = widgetConfig.cacheWidget || false;
    //             widgetConfig.properties.enableCustomStatement = widgetConfig.enableCustomStatement || false;
    //             response.sourceType = widgetConfig.sourceType;
    //             response.displayType = widgetConfig.chartType;
    //             response.xAxis = widgetConfig.xAxis;
    //             response.yAxis = widgetConfig.yAxis;
    //             response.properties = widgetConfig.properties || {};
    //             if (results && results.rows && results.rows.length) {
    //                 response.data = results.rows;
    //                 return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //
    //             } else {
    //                 response.data = [];
    //                 response.message = "Form data not found.";
    //                 return CommonHelper.apiSuccessResponse(res, {message: null, data: response})
    //             }
    //         }
    //     } catch (error) {
    //         const apiErrorResponse: ApiErrorResponse = {
    //             error: {
    //                 error_description: (error as Error).message
    //             }
    //         }
    //         return CommonHelper.apiErrorResponse(res, apiErrorResponse)
    //     }
    // }


    // /**
    //  * Get Form Chart Data
    //  * @param req Request from the front-end
    //  * @param res Response that will send to the front-end
    //  * @param next It will be use for passing to next method
    //  */
    // async getFormChartData(req: any, res: any, next: any): Promise<any> {
    //     try {
    //         const response: any = { status: false, displayType: "", message: "", data: [] };
    //         const id = req.params.widgetId;
    //         const result = await Container.get(DataSource).getRepository(DashboardWidget)
    //             .createQueryBuilder('DW')
    //             .leftJoinAndSelect('DW.widgetAccount', 'widgetAccount')
    //             .where('DW.id = :id', { id: id })
    //             .getMany();
    //         if (result && result.length > 0) {
    //             const widgetResponse: any = result[0];
    //             if (widgetResponse.isConfigured <= 0) {
    //                 const response = {
    //                     status: true,
    //                     displayType: "configure",
    //                     message: "Widget is not configured.",
    //                     data: [],
    //                 };
    //                 return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //             }
    //             const widgetConfig = widgetResponse.widgetConfig ? JSON.parse(widgetResponse.widgetConfig.replace(/\\/g, "")) : {};
    //             if (widgetConfig && widgetConfig.sourceType && widgetConfig.sourceType === "ACCOUNT") {
    //                 const response: any = { status: true, data: [], error: null };
    //                 response.cacheWidget = widgetConfig.cacheWidget || false;
    //                 response.isManualQuery = widgetConfig.isManualQuery || false;
    //                 response.sourceType = widgetConfig.sourceType;
    //                 response.displayType = widgetConfig.chartType;
    //                 response.formField = widgetConfig.formField;
    //                 response.config = widgetConfig.config ? widgetConfig.config : {};
    //                 response.properties = widgetConfig.properties || {};
    //                 const accountConfigDetails = widgetResponse.widgetAccount.config ? JSON.parse(widgetResponse.widgetAccount.config) : {};
    //                 if (accountConfigDetails && accountConfigDetails.dbType === "MSSQL") {
    //                     let mssqlQuery = "";
    //                     if (widgetConfig.isManualQuery && widgetConfig.query) {
    //                         mssqlQuery = widgetConfig.query;
    //                     } else {
    //                         if (!Array.isArray(widgetConfig.yAxis)) {
    //                             widgetConfig.yAxis = [widgetConfig.yAxis];
    //                         }
    //                         const selectFields = [];
    //                         selectFields.push(`[${widgetConfig.xAxis}] as '${widgetConfig.xAxis}'`);
    //                         for (const yField of widgetConfig.yAxis) {
    //                             if (widgetConfig.operationType === 'SUM') {
    //                                 selectFields.push(`SUM([${yField}]) as '${yField}'`);
    //                             } else if (widgetConfig.operationType === 'COUNT') {
    //                                 selectFields.push(`COUNT([${yField}]) as '${yField}'`);
    //                             } else {
    //                                 selectFields.push(`[${yField}]`);
    //                             }
    //                         }
    //                         mssqlQuery = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.form} GROUP BY ${widgetConfig.xAxis}`;
    //                     }
    //                     const mssqlData: any = await ConnectorsUtil.connect(null, mssqlQuery, accountConfigDetails);
    //                     if (mssqlData.status) {
    //                         response.data = [];
    //                         response.xAxis = '';
    //                         response.yAxis = [];
    //                         if (mssqlData.data && mssqlData.data.recordset && mssqlData.data.recordset.length > 0) {
    //                             const queryFields = Object.keys(mssqlData.data.recordset[0]);
    //                             response.xAxis = queryFields[0];
    //                             queryFields.splice(0, 1);
    //                             response.yAxis = queryFields;
    //                             response.data = mssqlData.data.recordset;
    //                         }
    //                         return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //                     } else {
    //                         response.error = mssqlData.message;
    //                         return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //                     }
    //                 } else if (accountConfigDetails && accountConfigDetails.dbType === "MYSQL") {
    //                     const accountConfig = {
    //                         host: accountConfigDetails.dbHost || "",
    //                         user: accountConfigDetails.dbUser || "",
    //                         password: accountConfigDetails.dbPassword || "",
    //                         database: accountConfigDetails.dbName || "",
    //                     };
    //                     const customConnection = await mysql.createConnection(accountConfig);
    //                     customConnection.connect((err) => {
    //                         if (err) {
    //                             response.error = err;
    //                             return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //                         } else {
    //                             let sqlQuery = "";
    //                             if (widgetConfig.isManualQuery && widgetConfig.query) {
    //                                 sqlQuery = widgetConfig.query;
    //                             } else {
    //                                 if (!Array.isArray(widgetConfig.yAxis)) {
    //                                     widgetConfig.yAxis = [widgetConfig.yAxis];
    //                                 }
    //                                 const selectFields = [];
    //                                 selectFields.push(this.addtick(widgetConfig.xAxis));
    //                                 for (const yField of widgetConfig.yAxis) {
    //                                     if (widgetConfig.operationType === 'SUM') {
    //                                         selectFields.push(`SUM(${this.addtick(yField)}) as ${this.addtick(yField)}`);
    //                                     } else if (widgetConfig.operationType === 'COUNT') {
    //                                         selectFields.push(`COUNT(${this.addtick(yField)}) as ${this.addtick(yField)}`);
    //                                     } else {
    //                                         selectFields.push(`${this.addtick(yField)}`);
    //                                     }
    //                                 }
    //                                 sqlQuery = `SELECT ${selectFields.join(',')} FROM ${this.addtick(widgetConfig.form)} GROUP BY ${this.addtick(widgetConfig.xAxis)}`;
    //                             }
    //                             let queryData = [];
    //                             // console.log('sqlQuery', sqlQuery);
    //                             customConnection.query(
    //                                 sqlQuery,
    //                                 queryData,
    //                                 (cQueryError, cQueryResult, cQueryFields) => {
    //                                     customConnection.destroy();
    //                                     if (cQueryError) {
    //                                         response.error = cQueryError;
    //                                         return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //                                     } else {
    //                                         const queryFields = cQueryFields.map(obj => obj.name);
    //                                         response.xAxis = queryFields[0];
    //                                         queryFields.splice(0, 1);
    //                                         response.yAxis = queryFields;
    //                                         response.data = cQueryResult;
    //                                         return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //                                     }
    //                                 }
    //                             );
    //                         }
    //                     });
    //                 } else {
    //                     return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //                 }
    //             } else if (widgetConfig && widgetConfig.sourceType && widgetConfig.sourceType === "CUSTOM_TABLE") {
    //                 const response: any = { status: true, data: [], error: null };
    //                 response.cacheWidget = widgetConfig.cacheWidget || false;
    //                 response.isManualQuery = widgetConfig.isManualQuery || false;
    //                 response.sourceType = widgetConfig.sourceType;
    //                 response.displayType = widgetConfig.chartType;
    //                 response.formField = widgetConfig.formField;
    //                 response.config = widgetConfig.config ? widgetConfig.config : {};
    //                 response.properties = widgetConfig.properties || {};
    //
    //                 if (!Array.isArray(widgetConfig.yAxis)) {
    //                     widgetConfig.yAxis = [widgetConfig.yAxis];
    //                 }
    //                 const selectFields = [];
    //                 selectFields.push(`DISTINCT ${widgetConfig.xAxis}`);
    //                 for (const yField of widgetConfig.yAxis) {
    //                     if (widgetConfig.operationType === 'SUM') {
    //                         selectFields.push(`SUM(${yField}) ${yField}`);
    //                     } else if (widgetConfig.operationType === 'COUNT') {
    //                         selectFields.push(`COUNT(${yField}) as ${yField}`);
    //                     } else {
    //                         selectFields.push(`${yField}`);
    //                     }
    //                 }
    //                 let stmt = `SELECT ${selectFields.join(',')} FROM ${widgetConfig.customTableName.toUpperCase()}`;
    //                 stmt += ` WHERE 1 = 1`;
    //                 if (widgetConfig.chartType === 'TABLE' && Array.isArray(widgetConfig.whereFields) && widgetConfig.whereFields.length > 0) {
    //                     let innerConditions = [];
    //                     for (const whereValue of widgetConfig.whereFields) {
    //                         let conditionQuery = this.getConditionalQuery(whereValue.columnName, whereValue.matchCase, whereValue.matchValue, 'normal');
    //                         if (conditionQuery) {
    //                             innerConditions.push(`${conditionQuery}`);
    //                         }
    //                     }
    //                     if (innerConditions.length) {
    //                         stmt += ` AND ${innerConditions.join(' AND ')}`;
    //                     }
    //                 }
    //                 if (widgetConfig.properties && widgetConfig.properties.enableTodayDateFilter && widgetConfig.properties.todayDateFilterOn) {
    //                     let startDate = moment().startOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                     let endDate = moment().endOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                     if (req.body.filterDate) {
    //                         startDate = moment(req.body.filterDate).startOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                         endDate = moment(req.body.filterDate).endOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                     }
    //                     stmt += ` AND ${widgetConfig.properties.todayDateFilterOn} >= TO_DATE('${startDate}', 'MM-DD-YYYY HH24:MI:SS')`;
    //                     stmt += ` AND ${widgetConfig.properties.todayDateFilterOn} <= TO_DATE('${endDate}', 'MM-DD-YYYY HH24:MI:SS')`;
    //                 }
    //                 if (widgetConfig.operationType === 'SUM' || widgetConfig.operationType === 'COUNT') {
    //                     stmt += ` GROUP BY ${widgetConfig.xAxis}`;
    //                 }
    //                 if (widgetConfig.properties && widgetConfig.properties.orderField) {
    //                     stmt += ` ORDER BY ${widgetConfig.properties.orderField} ${widgetConfig.properties.orderByField}`;
    //                 }
    //
    //                 console.log(stmt);
    //                 let results: any = await Container.get(DataSource).manager.query(stmt); // await db_procedure.v_select(stmt);
    //                 // console.log('results', results, typeof results);
    //                 if (results && results.errorNum) {
    //                     response.displayType = "error";
    //                     response.message = `Error: ${results.message}`;
    //                     response.data = [];
    //                 } else if (results && results.rows && results.rows.length > 0) {
    //                     response.xAxis = widgetConfig.xAxis;
    //                     response.yAxis = widgetConfig.yAxis;
    //                     response.data = results.rows;
    //                 }
    //                 return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //             } else {
    //                 let constants: any = {};
    //                 let formStmt = `SELECT fb.ID, fb.FORM_ID, fb.CREATEDON, fb.SUBMITTED_DATA FROM ${constants.formBuilderTableName}${req.userDetails.client_id} fb WHERE fb.FORM_ID = :formId`;
    //                 let formStmtData: any = { formId: widgetConfig.form };
    //                 let startDate = moment().startOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                 let endDate = moment().endOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                 let filterDate = moment().format('MM-DD-YYYY');
    //                 if (req.body.filterDate) {
    //                     startDate = moment(req.body.filterDate).startOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                     endDate = moment(req.body.filterDate).endOf('day').format('MM-DD-YYYY HH:mm:ss');
    //                     filterDate = moment(req.body.filterDate).format('MM-DD-YYYY');
    //                 }
    //                 if (widgetConfig.chartType === 'TABLE') {
    //                     if (widgetConfig.properties && widgetConfig.properties.enableTodayDateFilter && widgetConfig.properties.todayDateFilterOn === 'CREATEDON') {
    //                         formStmt += ` AND fb.CREATEDON >= TO_DATE('${startDate}', 'MM-DD-YYYY HH24:MI:SS')`;
    //                         formStmt += ` AND fb.CREATEDON <= TO_DATE('${endDate}', 'MM-DD-YYYY HH24:MI:SS')`;
    //                     }
    //                     if (Array.isArray(widgetConfig.whereFields) && widgetConfig.whereFields.length > 0) {
    //                         // let innerConditions = [];
    //                         for (const whereValue of widgetConfig.whereFields) {
    //                             if (whereValue.columnName && whereValue.matchCase, whereValue.matchValue) {
    //                                 const conditionOperator = this.getConditionalQuery(null, whereValue.matchCase, null, 'operator');
    //                                 formStmt += ` AND json_value(fb.SUBMITTED_DATA, '$.${whereValue.columnName}') ${conditionOperator} '${whereValue.matchValue}'`;
    //                             }
    //
    //                         }
    //
    //                     }
    //                     if (widgetConfig.enableCustomStatement && widgetConfig.customStatement) {
    //                         formStmt = widgetConfig.customStatement
    //                             .replaceAll(`{FILTER_DATE}`, filterDate)
    //                             .replaceAll(`{FILTER_DATE_START}`, startDate)
    //                             .replaceAll(`{FILTER_DATE_END}`, endDate);
    //                         formStmtData = {};
    //                     }
    //                 }
    //                 let results = null;
    //                 if (widgetConfig.enableApiMode && widgetConfig.apiState) {
    //                     formStmt = null;
    //                     formStmtData = {};
    //                     if (widgetConfig.apiState === 'missed-sign-in') {
    //                         results = await MissedSignInOffUtil.getMissedSignIn(req.userDetails.client_id, startDate, endDate); // await pwaCtrl.getMissedSignIn(req.userDetails.client_id, startDate, endDate);
    //                     } else if (widgetConfig.apiState === 'missed-sign-off') {
    //                         results = await MissedSignInOffUtil.getMissedSignOff(req.userDetails.client_id, startDate, endDate); //await pwaCtrl.getMissedSignOff(req.userDetails.client_id, startDate, endDate);
    //                     }
    //                 }
    //                 if (formStmt) {
    //                     results = await Container.get(DataSource).manager.query(formStmt);// await db_procedure.v_select(formStmt, formStmtData, { fetchInfo: ["SUBMITTED_DATA"] });
    //                 }
    //                 response.status = true;
    //                 response.cacheWidget = widgetConfig.cacheWidget || false;
    //                 widgetConfig.properties.enableCustomStatement = widgetConfig.enableCustomStatement || false;
    //                 response.sourceType = widgetConfig.sourceType;
    //                 response.displayType = widgetConfig.chartType;
    //                 response.xAxis = widgetConfig.xAxis;
    //                 response.yAxis = widgetConfig.yAxis;
    //                 response.properties = widgetConfig.properties || {};
    //                 if (results && results.rows && results.rows.length) {
    //                     response.data = results.rows;
    //                     return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //
    //                 } else {
    //                     response.data = [];
    //                     response.message = "Form data not found.";
    //                     return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
    //                 }
    //             }
    //         } else {
    //             response.status = true;
    //             response.displayType = "error";
    //             response.message = "Could not find widget.";
    //             return CommonHelper.apiSuccessResponse(res, { message: null, data: result })
    //         }
    //     } catch (error) {
    //         const apiErrorResponse: ApiErrorResponse = {
    //             error: {
    //                 error_description: (error as Error).message
    //             }
    //         }
    //         return CommonHelper.apiErrorResponse(res, apiErrorResponse)
    //     }
    // }
 
    private async execute(req) {
        let result;
        const chartType = req.params.widgetId !== 'preview' ? req.body.chartType : req.body.widgetConfig.chartType;
        if (chartType === 'PIE') {
            result = await this.pieChart.pieChartExecution(req);
        } else if (chartType === 'BAR') {
            result = await this.barChart.barChartExecution(req);
        } else if (chartType === 'LINE') {
            result = await this.lineChart.lineChartExecution(req);
        } else if (chartType === 'MIX_DONUT_INCOME') {
            result = await this.mixDonutIncomeChart.mixDonutIncomeChartExecution(req);
        } else if (chartType === 'MIX_DONUT_EXPENSE') {
            result = await this.mixDonutExpenseChart.mixDonutExpenseChartExecution(req);
        } else if (chartType === 'BAR_LINE') {
            result = await this.barLineChart.barLineChartExecution(req);
        } else if (chartType === 'TABLE' && req.body.sqlQuery?.query) {
            result = await this.tableChart.tableQueryExecution(req);
        } else if (chartType === 'TABLE') {
            result = await this.tableChart.tableChartExecution(req);
        } else if (chartType === 'DRILL_DOWN_BAR_BAR') {
            result = await this.drillDownBarChart.drillDownBarChartExecution(req);
        }
        return result;
    }

    /**
     * Get Form Folder
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be use for passing to next method
     */

    // @Security('bearerAuth')
    // @Get('form-folder/:formId')
    async getFormFolder(@Request() req: any, @Path() formId: string): Promise<any> {
        try {
            let formid = req.params.formId; // '${formid}'
            let query = `SELECT * FROM ${formBuilderTableName} + ${req.userDetails.client_id}  WHERE FORM_ID = '${formid}'`;
            const result = await Container.get(DataSource).manager.query(query);
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: result });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    public addtick(e) {
        return "`" + e + "`";
    }

    public getConditionalQuery(left, sign, right, type) {
        switch (sign) {
            case 'equals':
                switch (type) {
                    case "json":
                        return `@.${left} == "${right}"`;
                    case "operator":
                        return `=`;
                    default:
                        return `${left} = '${right}'`;
                }
            case 'greater':
                return this.queryString("<", type, left, right);
            case 'greater_equals':
                return this.queryString("<=", type, left, right);
            case 'less':
                return this.queryString(">", type, left, right);
            case 'less_equals':
                return this.queryString(">=", type, left, right);
            default:
                return '';
        }
    }
    public queryString(sign, type, left, right) {
        switch (type) {
            case "json":
                return `@.${left} ${sign} "${right}"`;
            case "operator":
                return `${sign}`;
            default:
                return `${left} ${sign} '${right}'`;
        }
    }
}
