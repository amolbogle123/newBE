import { WidgetAccount } from "entities";
import * as jsforce from 'jsforce';
import fetch from "node-fetch";
import {
    Body,
    Controller,
    Post,
    Request,
    Route,
    Security,
    Tags
} from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import dbService from "../../../../services/db.service";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../../utils/helpers/common.helper";

@Route("dashboard")
@Tags("Dynamic Dashboard")
export class SalesforceController extends Controller {
    private conn: jsforce.Connection;

    @Security("bearerAuth")
    @Post("salesforce-token-verification")
    async getSalesForceTokenVerification(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
            };
            const apiFetchResult = await fetch(requestBody.url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            });
            const result = await apiFetchResult.json();
            if (result?.access_token) {
                this.setStatus(200);
                response.status = true;
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            } else {
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("query-salesforce-data")
    async getSalesForceData(
        @Request() req: any,
        @Body() requestBody?: any
    ): Promise<any> {
        try {
            const response = {
                status: false,
                data: [],
            };
            let access_token = '';
            let widgetAccountConfig = null;
            let instance_url = '';
            if(requestBody?.widgetAccountId) {
                const widgetAccount = await dbService._findOneQueryService(
                    Container.get(DataSource).getRepository(WidgetAccount),
                    {
                        where: {
                            id: requestBody.widgetAccountId,
                        },
                        select: ["config"],
                    },
                );
                if(widgetAccount?.config) {
                    widgetAccountConfig = JSON.parse(widgetAccount.config);
                    access_token = widgetAccountConfig.token.access_token;
                    instance_url = widgetAccountConfig.token.instance_url;
                }
            }
             // Initialize jsforce.Connection object with the access token
            this.conn = new jsforce.Connection({
            accessToken: access_token,
            instanceUrl: instance_url // Replace with your Salesforce instance URL
            });
            const result = await this.conn.query(requestBody?.query);
            if (result?.records) {
                this.setStatus(200);
                response.status = true;
                response.data = result.records;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            } else {
                response.data = result;
                return CommonHelper.apiSwaggerSuccessResponse(response);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}