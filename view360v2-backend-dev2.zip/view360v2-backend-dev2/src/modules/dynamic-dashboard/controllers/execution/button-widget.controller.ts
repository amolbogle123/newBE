import { DashboardWidget } from "entities";
import { CommonHelper, ApiErrorResponse } from "utils/helpers/common.helper";
import { DataSource } from "typeorm";
import Container from 'typedi';
import { Post, Request, Path, Route, Security, Tags, Controller } from 'tsoa';



@Route('dashboard')
@Tags('Dynamic Dashboard')
export class ButtonWidgetController extends Controller {
  /**
   * Get Sql Account List
   * @param req Request from the front-end
   * @param res Response that will send to the front-end
   * @param next It will be used for passing to next method
   */
  // async getSqlAccountList(req: any, res: any, next: any): Promise<any> {
  //   try {
  //     const params: any = { client_id: req.userDetails.client_id };
  //     let whereCondition: any = ["CLIENT_ID = :client_id"];
  //     if (req.body.appId && req.body.appId !== "") {
  //       params["appId"] = req.body.appId;
  //       whereCondition.push("APP_ID = :appId");
  //     }
  //     if (req.query.type && req.query.type !== "") {
  //       let type = req.query.type.split(',').join("','");
  //       whereCondition.push(`WIDGET_TYPE IN ('${type}')`);
  //     }
  //     const result = await Container.get(DataSource).getRepository(WidgetAccount)
  //       .createQueryBuilder('WA')
  //       .where(whereCondition.join(" AND "), params)
  //       .getMany();
  //     const rows = [];
  //     result.forEach((row) => {
  //       rows.push({
  //         ID: row.id,
  //         ACCOUNT_NAME: row.accountName
  //       });
  //     });
  //     const response = { status: true, data: null };
  //     if (rows && rows.length > 0) {
  //       response.data = rows;
  //     }
  //     res.status(200).json(response);
  //   } catch (error) {
  //     const apiErrorResponse: ApiErrorResponse = {
  //       error: {
  //         error_description: (error as Error).message
  //       }
  //     }
  //     this.setStatus(500)
  //     return CommonHelper.apiErrorResponse(res, apiErrorResponse)
  //   }
  // }

  /**
   * Check Query
   * @param req Request from the front-end
   * @param res Response that will send to the front-end
   * @param next It will be used for passing to next method
   */
  // async checkQuery(req: any, res: any, next: any): Promise<any> {
  //   try {
  //     let result;
  //     result = await Container.get(DataSource).getRepository(WidgetAccount)
  //       .createQueryBuilder('WA')
  //       .where('WA.ID = :id', { id: req.body.id })
  //       .getMany();
  //     const response: any = { status: true, data: [], error: null };
  //     if (result && result.length > 0 && req.body.query) {
  //       const widgetConfig = result[0].config ? JSON.parse(result[0].config.replace(/\\/g, "")) : null;
  //       if (widgetConfig && widgetConfig.dbType === 'MSSQL') {
  //         let query = req.body.query;
  //         const mssqlData: any = await ConnectorsUtil.connect(null, query, widgetConfig);
  //         if (mssqlData.status) {
  //           response.data = [];
  //           if (mssqlData.data && mssqlData.data.recordset && mssqlData.data.recordset.length > 0) {
  //             const fields = Object.keys(mssqlData.data.recordset[0]).map(obj => {
  //               return { COLUMN_NAME: `${obj}` };
  //             });
  //             response.data = { fields };
  //           }
  //           this.setStatus(200)
  //
  //           return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
  //         } else {
  //           response.error = mssqlData.message;
  //           this.setStatus(400)
  //
  //           return CommonHelper.apiSwaggerErrorResponse(response)
  //         }
  //       } else if (widgetConfig && widgetConfig.dbType === "MYSQL") {
  //         const accountConfig = {
  //           host: widgetConfig.dbHost || "",
  //           user: widgetConfig.dbUser || "",
  //           password: widgetConfig.dbPassword || "",
  //           database: widgetConfig.dbName || "",
  //         };
  //         const customConnection = mysql.createConnection(accountConfig);
  //         customConnection.connect((err: any) => {
  //           if (err) {
  //             response.error = err;
  //             this.setStatus(200)
  //
  //             return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
  //           } else {
  //             let query = req.body.query;
  //             customConnection.query(
  //               query,
  //               (cQueryError: { sqlMessage: any; }, cQueryResult: any, cQueryFields: any[]) => {
  //                 customConnection.destroy();
  //                 if (cQueryError) {
  //                   if (cQueryError.sqlMessage) {
  //                     response.error = cQueryError.sqlMessage;
  //                   } else {
  //                     response.error = `Something wrong. please check your query`;
  //                   }
  //                   this.setStatus(200)
  //
  //                   return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
  //                 } else {
  //                   let fields: any = [];
  //                   if (Array.isArray(cQueryFields) && cQueryFields.length > 0) {
  //                     fields = cQueryFields.map(obj => {
  //                       return { COLUMN_NAME: `${obj.name}` };
  //                     });
  //                   }
  //                   response.data = { fields, cQueryFields };
  //                   this.setStatus(200)
  //
  //                   return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
  //                 }
  //               }
  //             );
  //           }
  //         });
  //       } else {
  //         this.setStatus(200)
  //
  //         return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
  //       }
  //     } else {
  //       this.setStatus(200)
  //
  //       return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
  //     }
  //   } catch (error) {
  //     const apiErrorResponse: ApiErrorResponse = {
  //       error: {
  //         error_description: (error as Error).message
  //       }
  //     }
  //     this.setStatus(500)
  //
  //     return CommonHelper.apiErrorResponse(res, apiErrorResponse)
  //   }
  // }

  /**
   * Get Database TableList
   * @param req Request from the front-end
   * @param res Response that will send to the front-end
   * @param next It will be used for passing to next method
   */
  // async getDatabaseTableList(req: any, res: any, next: any): Promise<any> {
  //   try {
  //     let result;
  //     result = await Container.get(DataSource).getRepository(WidgetAccount)
  //       .createQueryBuilder('WA')
  //       .where('WA.ID = :id', { id: req.params.widgetAccountId })
  //       .getMany();
  //     const response: any = { status: true, data: [], error: null };
  //     if (result && result.length > 0 && req.params.info) {
  //       const widgetConfig = result[0].config ? JSON.parse(result[0].config.replace(/\\/g, "")) : null;
  //       if (widgetConfig && toLower(widgetConfig.dbType) === toLower('MSSQL')) {
  //         let query: any = null;
  //         if (req.params.info === "fields" && req.params.tableName) {
  //           query = `SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_CATALOG = '${widgetConfig.dbName}' AND TABLE_NAME = '${req.params.tableName}' ORDER BY ORDINAL_POSITION`;
  //         } else if (req.params.info === "gridreportdata" && req.params.tableName) {
  //           query = `SELECT * FROM ${req.params.tableName}`;
  //         } else {
  //           query = `SELECT table_name as 'TABLE_NAME' FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_CATALOG = '${widgetConfig.dbName}'`;
  //         }
  //         const mssqlData: any = await ConnectorsUtil.connect(null, query, widgetConfig);
  //         if (mssqlData.status) {
  //           response.data = [];
  //           if (mssqlData.data && mssqlData.data.recordset && mssqlData.data.recordset.length > 0) {
  //             response.data = mssqlData.data.recordset;
  //           }
  //           this.setStatus(200)
  //
  //           return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
  //         } else {
  //           response.error = mssqlData.message;
  //           this.setStatus(400)
  //
  //           return CommonHelper.apiSwaggerErrorResponse(response)
  //         }
  //       } else if (widgetConfig && toLower(widgetConfig.dbType) === toLower("MYSQL")) {
  //         const accountConfig = {
  //           host: widgetConfig.dbHost || "",
  //           user: widgetConfig.dbUser || "",
  //           password: widgetConfig.dbPassword || "",
  //           database: widgetConfig.dbName || "",
  //         };
  //         const customConnection = mysql.createConnection(accountConfig);
  //         customConnection.connect((err: null) => {
  //           if (err) {
  //             response.error = err;
  //
  //             this.setStatus(400)
  //
  //             return CommonHelper.apiSwaggerErrorResponse(response)
  //           } else {
  //             let query: any = null;
  //             let queryData: any = [];
  //             if (req.params.info === "fields" && req.params.tableName) {
  //               query =
  //                 "SELECT CONCAT(column_name, ' (', data_type, ')') as 'COLUMN_NAME' FROM information_schema.columns WHERE table_schema = ? AND table_name = ?";
  //               queryData = [widgetConfig.dbName, req.params.tableName];
  //             } else if (req.params.info === "gridreportdata" && req.params.tableName) {
  //               query =
  //                 "SELECT * FROM " + req.params.tableName;
  //               queryData = [];
  //             } else {
  //               query =
  //                 "SELECT table_name as 'TABLE_NAME' FROM information_schema.tables WHERE table_schema = ?";
  //               queryData = [widgetConfig.dbName];
  //             }
  //             customConnection.query(
  //               query,
  //               queryData,
  //               (cQueryError: null, cQueryResult: any) => {
  //                 customConnection.destroy();
  //                 if (cQueryError) {
  //                   response.error = cQueryError;
  //                   this.setStatus(400)
  //
  //                   return CommonHelper.apiSwaggerErrorResponse(response)
  //                 } else {
  //                   response.data = cQueryResult;
  //                   this.setStatus(400)
  //
  //                   return CommonHelper.apiSwaggerErrorResponse(response)
  //                 }
  //               }
  //             );
  //           }
  //         });
  //       } else {
  //         return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
  //       }
  //     } else {
  //       return CommonHelper.apiSuccessResponse(res, { message: null, data: response })
  //     }
  //   } catch (error) {
  //     const apiErrorResponse: ApiErrorResponse = {
  //       error: {
  //         error_description: (error as Error).message
  //       }
  //     }
  //     return CommonHelper.apiErrorResponse(res, apiErrorResponse)
  //   }
  // }

  /**
   * Get Button Widget Data
   * @param req Request from the front-end
   * @param res Response that will send to the front-end
   * @param next It will be use for passing to next method
   */

  @Security('bearerAuth')
  @Post('button-widget/:widgetId')
  async getButtonWidgetData(@Request() req: any, @Path() widgetId: string): Promise<any> {
    try {
      let result;
      let widgetResponse: any = {}
      result = await Container.get(DataSource).getRepository(DashboardWidget)
        .createQueryBuilder('DW')
        .leftJoinAndSelect('DW.widgetAccount', 'widgetAccount')
        .where('DW.ID = :id', { id: widgetId })
        .getMany();
      if (result && Array.isArray(result) && result.length > 0) {
        widgetResponse = result[0];
        if (widgetResponse.widgetConfig) {
          widgetResponse.widgetConfig = JSON.parse(widgetResponse.widgetConfig);
        } else {
          widgetResponse.widgetConfig = {};
        }
        return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: widgetResponse });
      } else {
        const response = {
          status: false,
          displayType: "error",
          message: "Could not find widget.",
          data: [],
        };
        return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response });
      }
    } catch (error) {
      const apiErrorResponse: ApiErrorResponse = {
        error: {
          error_description: (error as Error).message
        }
      }
      return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
    }
  }

  public decodeQuery(rules, condition) {
    let expression = " ";
    for (let i = 0; i < rules.length; i++) {
      let item = rules[i];
      if (item !== null) {
        item.operator = this.assignOperatorSymbol(item.operator);
        expression = expression + this.mergeString("(", item.field, item.operator, item.value, ")", item.isDate ? item.isDate : false);
        if (i != rules.length - 1) {
          expression = expression + " " + condition + " ";
        }
      }
    }
    return expression;
  }

  public mergeString(bracket1, field, operator, value, bracket2, isDate) {
    const dataType = typeof value;
    let mergedString = "";
    if (!isDate) {
      if (dataType === "number") {
        mergedString = this.numberOperator(bracket1, field, operator, value, bracket2);
      } else if (dataType === "string") {
        mergedString = this.stringOperator(bracket1, field, operator, value, bracket2);
      } 
    } else {
      const date = new Date(value);
      const year = date.toLocaleString("default", { year: "numeric" });
      const month = date.toLocaleString("default", { month: "2-digit" });
      const day = date.toLocaleString("default", { day: "2-digit" });
      const formattedDate = year + "-" + month + "-" + day;
      mergedString = bracket1 + " " + "date(" + field + ")" + " " + operator + " " + "date('" + formattedDate + "')" + " " + bracket2;
    }
    return mergedString;
  }
  public numberOperator(bracket1, field, operator, value, bracket2) {
    let mergedString = '';
    if (operator === 'IS NOT NULL' || operator === 'IS NULL') {
      mergedString = bracket1 + " " + field + " " + operator + " " + bracket2;
    } else if (operator === 'LIKE' || operator === 'NOT LIKE') {
      mergedString = bracket1 + " " + field + " " + operator + " " + value + " " + bracket2;
    } else {
      mergedString = bracket1 + " " + field + " " + operator + " " + value + " " + bracket2;
    }
    return mergedString;
  }
  public stringOperator(bracket1, field, operator, value, bracket2) {
    let mergedString = '';
    if (operator === 'IS NOT NULL' || operator === 'IS NULL') {
      mergedString = bracket1 + " " + field + " " + operator + " " + bracket2;
    } else if (operator === 'LIKE' || operator === 'NOT LIKE') {
      mergedString = bracket1 + " " + field + " " + operator + " '%" + value + "%' " + bracket2;
    } else {
      mergedString = bracket1 + " " + field + " " + operator + " '" + value + "' " + bracket2;
    }
    return mergedString;
  }

  public buildMYSQLQuery(rules, condition, tableName, columns) {
    let joinColumns = columns.join(',');
    let expression = this.decodeQuery(rules, condition);
    let query;
    if (rules && rules.length > 0) {
      query = `SELECT ${joinColumns} FROM ${tableName} WHERE ${expression}`;
    } else {
      query = `SELECT ${joinColumns} FROM ${tableName}`;
    }
    return query;
  }

  public assignOperatorSymbol(sign) {
    let operatorSign;
    switch (sign) {
      case '≠':
        operatorSign = '!=';
        break;
      case '!∅':
        operatorSign = 'IS NOT NULL';
        break;
      case '∅':
        operatorSign = 'IS NULL';
        break;
      case '∈':
        operatorSign = 'LIKE';
        break;
      case '∉':
        operatorSign = 'NOT LIKE';
        break;
      case '>':
        operatorSign = '>';
        break;
      case '<':
        operatorSign = '<';
        break;
      case '≤':
        operatorSign = '<=';
        break;
      case '≥':
        operatorSign = '>=';
        break;
      default:
        operatorSign = '=';
        break;
    }
    return operatorSign;
  }

  public removeDataTypeFromColumn(columnList) {
    let columns = [];
    columnList.forEach((item) => {
      columns.push(this.splitText(item));
    });
    return columns;
  }
  public splitText(text) {
    return text.split('(')[0].trim();
  }
}
