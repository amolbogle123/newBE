import {Body, Post, Request, Route, Security, Tags} from "tsoa";
import {MySQLExecutorUtil} from "../../../connectors/executor-utils/mySQLExecutor.util";
import {ApiErrorResponse, CommonHelper} from "utils/helpers/common.helper";
import {ApplicationLogger} from "core/config/pino-loggers";

@Route('dashboard')
@Tags('Dynamic Dashboard')
export class DrillDownController {
    @Security('bearerAuth')
    @Post('drill-down')
    async executeDrillDownQuery(@Request() req: any, @Body() requestBody: any): Promise<any> {
        try {
            const response: any = { status: true, data: [], message: "" , error: null};
            if(req.body.dbType === 'MYSQL') {
                response.data = await MySQLExecutorUtil.executeMYSQLQuery(req.body.query, req.body.accountConfigDetails);
            }
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response.data.data });
        } catch (error) {
            ApplicationLogger.error(
                "Error occurred in DrillDownController executeDrillDownQuery::",
                error
            );
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
