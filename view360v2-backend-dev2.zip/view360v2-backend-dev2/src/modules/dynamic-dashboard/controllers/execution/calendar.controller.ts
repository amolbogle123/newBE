import {DashboardWidget} from "../../../../entities";
import {formBuilderTableName} from "../../utils/constants/api.constant";
import {CommonHelper,ApiErrorResponse} from "../../../../utils/helpers/common.helper";
import Container from 'typedi';
import {DataSource} from 'typeorm';
import { Post, Request, Path, Route, Security, Tags, Controller } from 'tsoa';

@Route('dashboard')
@Tags('Dynamic Dashboard')

export class CalendarController extends Controller {

    /**
     * calendar Event List
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */

    @Security('bearerAuth')
    @Post('calendar-events/:widgetId')
    async calendarEventList(@Request() req: any, @Path() widgetId: string): Promise<any> {
        try {
            const response:any = {status: true, data: []};

            let result;
            result = await Container.get(DataSource).getRepository(DashboardWidget)
                .createQueryBuilder('DW')
                .where('DW.id = :id', {id: req.body.id})
                .getMany();
            if (result?.length > 0) {
                try {
                    const widgetConfig = JSON.parse(result[0]["WIDGET_CONFIG"].replace(/\\/g, ""));
                    if (widgetConfig?.form) {
                        let query = `SELECT * FROM ${formBuilderTableName} + ${req.userDetails.client_id}  WHERE FORM_ID = '${widgetConfig.form}'`;
                        const resultEntry = await Container.get(DataSource).manager.query(query);
                        if (resultEntry?.length) {
                            response.data = await this.resultEntry(widgetConfig, resultEntry);
                        }
                    }
                } catch (error) {
                }
            }
            this.setStatus(200)

            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500)
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    public resultEntry(widgetConfig, resultEntry) {
        return new Promise((resolve) => {
            let response = [];
            resultEntry.forEach((rows) => {
                const dataSet = JSON.parse(rows["SUBMITTED_DATA"]);
                let title = "";
                if (widgetConfig.titleField) {
                    title = dataSet[widgetConfig.titleField];
                }
                let event_date = "";
                if (widgetConfig.dateField) {
                    event_date = dataSet[widgetConfig.dateField];
                }
                let description = "";
                if (widgetConfig.detailsField) {
                    description = dataSet[widgetConfig.detailsField];
                }
                response.push({
                    id: rows.ID,
                    title: title,
                    event_date: event_date,
                    description: description,
                });
            });
            resolve(response);
        });
    }
}
