import { GlobalFilter } from "entities";
import { Body, Controller, Delete, Get, Patch, Path, Post, Request, Route, Security, Tags } from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";

@Route('dashboard')
@Tags('Global Filter')
export class GlobalFilterController extends Controller {
    @Security('bearerAuth')
    @Post('global-filter')
    async addGlobalFilter(@Request() req: any): Promise<any> {
        try {
            const checkExisting = await Container.get(DataSource).manager.findOne(GlobalFilter, { where: { filterType: req.body.filterType, dashboardId: req.body.dashboardId }});
            if (checkExisting) {
                const apiErrorResponse: ApiErrorResponse = {
                    error: {
                        error_description: `Selected filter type is already configured in ${checkExisting.filterName}.`
                    }
                }
                this.setStatus(400);
                return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
            }
            
            const globalFilterModel = new GlobalFilter();
            globalFilterModel.clientId = req.userDetails.client_id;
            globalFilterModel.dashboardId = req.body.dashboardId;
            globalFilterModel.filterName = req.body.filterName;
            globalFilterModel.filterType = req.body.filterType;
            globalFilterModel.filter = req.body.filter;
            globalFilterModel.createdBy = req.userDetails.id;

            const result = await Container.get(DataSource).manager.save(globalFilterModel);

            this.setStatus(201)

            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: result });
        } catch (error) {
            console.log("Error while saving :: ", error)
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('global-filter/:id')
    async getGlobalFilter(@Path() id: string): Promise<any> {
        try {
            const result = await Container.get(DataSource).manager.find(GlobalFilter, {
                where: { dashboardId: id }, order: { createdOn: 'ASC'}
            });

            result.forEach((element) => {
                element.filter = JSON.parse(element.filter);
            })

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({ message: null, data: result });
        } catch (error) {
            console.log("Error while saving :: ", error)
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Delete('global-filter/:id')
    async deleteGlobalFilter(@Path() id: string): Promise<any> {
        try {
            const result = await Container.get(DataSource).manager.delete(GlobalFilter, { id: id });

            if (result) {
                if (result.affected > 0) {
                    this.setStatus(200);
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "Filter deleted successfully",
                    });
                } else {
                    this.setStatus(404);
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "No Filter Found with given id.",
                    });
                }
            }
        } catch (error) {
            console.log("Error while saving :: ", error)
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Patch('global-filter/:id')
    async updateGlobalFilter(@Path() id: string, @Body() requestBody: any): Promise<any> {
        try {
            const patchData = {
                filterName: requestBody.filterName,
                filter: JSON.stringify(requestBody)
            }
            const result = await Container.get(DataSource).manager.update(GlobalFilter, { id: id }, patchData)
            if (result) {
                if (result.affected > 0) {
                    this.setStatus(200);
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "Filter updated successfully",
                    });
                } else {
                    this.setStatus(404);
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "No Filter Found with given id.",
                    });
                }
            }
        } catch (error) {
            console.log("Error while saving :: ", error)
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
