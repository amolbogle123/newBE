import { ClientDashboard, DashboardWidget } from "entities";
import { CommonHelper, ApiErrorResponse } from "utils/helpers/common.helper";
import { Not, DataSource } from "typeorm";
import Container from "typedi";
import { cacheResponseData } from "utils/redis.middleware";
import {
    Body,
    Get,
    Post,
    Request,
    Path,
    Route,
    Security,
    Tags,
    Delete,
    Put,
    Controller,
    Query,
    Middlewares,
} from "tsoa";
import { DashboardCrudAddReponse } from "../../../user/doc/dynamic-dasboard.interface";
import {
    commonMiddleware,
    validateEntryCount,
    permissionMiddleware,
} from "../../../../middlewares/common.middleware";
import axios from "axios";

@Route("dashboard")
@Tags("Dynamic Dashboard")
export class DashboardCrudController extends Controller {
    /**
     * Add Dashboard
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Post("dashboard")
    @Middlewares(commonMiddleware)
    @Middlewares(validateEntryCount)
    @Middlewares(permissionMiddleware)
    async addDashboard(
        @Body() requestBody: any,
        @Request() req: any
    ): Promise<DashboardCrudAddReponse> {
        try {
            const clientDashModel = new ClientDashboard();
            clientDashModel.title = req.body.title;
            clientDashModel.widgetSpace = req.body.widgetSpace;
            clientDashModel.clientId = req.userDetails.client_id;
            clientDashModel.createdBy = req.userDetails.id;
            clientDashModel.filterConfig = req.body.filterConfig;
            clientDashModel.dashboardConfig = req.body.dashboardConfig;
            if (req.body.mappedUser) {
                clientDashModel.mappedUser = JSON.stringify(
                    req.body.mappedUser
                );
            }
            const result = await Container.get(DataSource).manager.save(
                clientDashModel
            );
            this.setStatus(200);

            return CommonHelper.apiSwaggerSuccessResponse({
                message: null,
                data: result,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Edit Dashboard
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */

    @Security("bearerAuth")
    @Put("dashboard/:id")
    @Middlewares(commonMiddleware)
    @Middlewares(permissionMiddleware)
    async editDashboard(
        @Body() requestBody: any,
        @Request() req: any,
        @Path() id: string
    ): Promise<DashboardCrudAddReponse> {
        try {
            let payload: Partial<ClientDashboard> = {}; // Use Partial to define optional properties

            if (requestBody.defaultId) {
                // For making default Dashboard updating defaultId = 0 for all rows but not in selected row
                await Container.get(DataSource)
                    .getRepository(ClientDashboard)
                    .update(
                        {
                            id: Not(requestBody.defaultId),
                            clientId: req.userDetails.client_id,
                        },
                        { defaultId: 0 }
                    );
                await Container.get(DataSource)
                    .getRepository(ClientDashboard)
                    .update(
                        {
                            id: requestBody.defaultId,
                            clientId: req.userDetails.client_id,
                        },
                        { defaultId: 1 }
                    );
            }

            if (requestBody.title) {
                payload.title = requestBody.title;
            }
            if (requestBody.widgetSpace) {
                payload.widgetSpace = requestBody.widgetSpace;
            }
            if (requestBody.mappedUser) {
                payload.mappedUser = JSON.stringify(requestBody.mappedUser);
            }
            if (requestBody.filterConfig) {
                payload.filterConfig = requestBody.filterConfig;
            }
            if (requestBody.dashboardConfig) {
                payload.dashboardConfig = requestBody.dashboardConfig;
            }

            // Perform the update operation
            const updateResult = await Container.get(DataSource)
                .getRepository(ClientDashboard)
                .update({ id: id }, payload);

            return CommonHelper.apiSwaggerSuccessResponse({
                message: null,
                data: updateResult,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Delete Dashboard
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */

    @Security("bearerAuth")
    @Delete("dashboard/:id") // Use @Delete() and specify the route parameter
    @Middlewares(commonMiddleware)
    @Middlewares(permissionMiddleware)
    async deleteDashboard(
        @Request() req: any,
        @Path() id: string // Use @Path() decorator for route parameter
    ): Promise<DashboardCrudAddReponse> {
        try {
            const IDs: any = id;
            const ClientDashBoardResult = await Container.get(DataSource)
                .getRepository(ClientDashboard)
                .delete(IDs);

            let DashboardWidgetResult = null;
            const widgetResult = await Container.get(DataSource)
                .getRepository(DashboardWidget)
                .find({
                    where: { dashboard: IDs },
                });
            if (widgetResult?.length) {
                let widgetId = widgetResult.map((w) => {
                    return w.id;
                });
                DashboardWidgetResult = await Container.get(DataSource)
                    .getRepository(DashboardWidget)
                    .delete(widgetId);
            }

            const result = {
                clientDashBoardResult: ClientDashBoardResult,
                dashBoardWidgetResult: DashboardWidgetResult,
            };
            return { status: true, message: null, data: result };
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get Client Dashboard
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security("bearerAuth")
    @Get("dashboard")
    @Middlewares(commonMiddleware)
    @Middlewares(permissionMiddleware)
    async getClientDashboard(
        @Request() req: any
    ): Promise<DashboardCrudAddReponse> {
        try {
            const response = { status: true, data: [] };
            let result: any;
            const client_ID = req.userDetails.client_id;
            result = await Container.get(DataSource)
                .getRepository(ClientDashboard)
                .createQueryBuilder("CB")
                .where("CB.clientId = :id", { id: client_ID })
                .orderBy("CB.createdOn", "DESC")
                .getMany();

            if (result?.length > 0) {
                response.data = [];
                result.forEach(async (item: any) => {
                    let dataSet = item;
                    let userPermission: any = jsonParse(dataSet.mappedUser);

                    let permissionList = [
                        "viewDashboard",
                        "addWidget",
                        "editDashboard",
                        "deleteDashboard",
                    ];
                    dataSet["permission"] = await validateUserPermission(
                        req.userDetails,
                        userPermission,
                        permissionList
                    );

                    if (
                        !dataSet.permission ||
                        dataSet.permission.viewDashboard
                    ) {
                        response.data.push(dataSet);
                    }
                });
            }
            await axios.post(`${process.env.MASTER_SITE_URL}client-config/renewal-date`,{clientId: client_ID}).then((res) => {
            }).catch((error) => {
                console.log(error);
            });
            await cacheResponseData(req.originalUrl, response);
            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            return {
                error: {
                    error_description: (error as Error).message,
                },
            } as ApiErrorResponse;
        }
    }

    /**
     * Get Dashboard
     * @param req Request from the front-end
     * @param res Response that will send to the front-end
     * @param next It will be used for passing to next method
     */
    @Security("bearerAuth")
    @Get("dashboard/:id")
    @Middlewares(commonMiddleware)
    @Middlewares(permissionMiddleware)
    async getDashboard(
        @Request() req: any,
        @Path() id: string,
        @Query() hiddenWidget?: boolean
    ): Promise<DashboardCrudAddReponse> {
        try {
            const response: any = { status: true, data: [] };
            let whereCondition = "DW.DASHBOARD = :dashboard";
            let params: any = { dashboard: id };
            if (typeof hiddenWidget !== "undefined") {
                whereCondition +=
                    " AND DW.IS_WIDGET_VISIBLE = :isWidgetVisible";
                params.isWidgetVisible = hiddenWidget;
            }
            let result: any;
            result = await Container.get(DataSource)
                .getRepository(DashboardWidget)
                .createQueryBuilder("DW")
                .where(whereCondition, params)
                .getMany();
            if (result?.length > 0) {
                response.data = [];
                result.forEach(async (row: any) => {
                    let dataSet = row;
                    let userPermission: any = jsonParse(dataSet.mappedUser);

                    let permissionList = [
                        "viewWidget",
                        "configureWidget",
                        "permissionWidget",
                        "cloneWidget",
                        "moveWidget",
                        "refreshWidget",
                        "deleteWidget",
                    ];
                    dataSet["permission"] = await validateUserPermission(
                        req.userDetails,
                        userPermission,
                        permissionList
                    );

                    if (!dataSet.permission || dataSet.permission.viewWidget) {
                        response.data.push(dataSet);
                    }
                });
            }
            await cacheResponseData(req.originalUrl, response);
            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Get("populate-table/:table")
    @Middlewares(commonMiddleware)
    @Middlewares(permissionMiddleware)
    async populateCustomTable(
        @Request() req: any,
        @Path() table: string
    ): Promise<any> {
        try {
            const tableName = table;
            const columnList =
                Container.get(DataSource).getMetadata(tableName).columns;
            const result = this.sortColumnName(columnList);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: null,
                data: result,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    public sortColumnName(columnNameList: any) {
        let result: any = [];
        if (columnNameList?.length) {
            for (let col of columnNameList) {
                let columnName = col.databaseName;
                result.push(columnName);
            }
        }
        return result;
    }
}

function jsonParse(jsonStr) {
    let response = [];
    try {
        if (jsonStr) {
            response = JSON.parse(jsonStr.replace(/\\/g, ""));
        }
    } catch (error) {}
    return response;
}

function validateUserPermission(userDetails, userPermission, permissionList) {
    return new Promise((resolve) => {
        let permission = {};

        if (userDetails?.is_superadmin === 1) {
            for (let p of permissionList) {
                permission[p] = true;
            }
        } else {
            const findPermission = userPermission.findIndex(
                (u: any) => u.userId === userDetails.id
            );
            if (findPermission > -1) {
                permissionList.forEach((p, k) => {
                    permission[p] =
                        userPermission[findPermission]["permission"][k] === "1";
                });
            } else if (userPermission && userPermission.length === 0) {
                permission = null;
            }
        }

        resolve(permission);
    });
}
