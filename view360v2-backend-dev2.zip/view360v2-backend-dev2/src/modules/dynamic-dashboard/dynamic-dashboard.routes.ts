import {AppRoutes} from "../../app.routes";
import {DashboardCrudController} from "./controllers/dashboard-crud/dashboard-crud.controller";
import {WidgetCrudController} from "./controllers/widgets-crud/widget-crud.controller";
import {DashboardWidgetConfigController} from "./controllers/config/dashboardWidget-config.controller";
import {SqlController} from "./controllers/execution/sql.controller";
import {ButtonWidgetController} from "./controllers/execution/button-widget.controller";
import {CalendarController} from "./controllers/execution/calendar.controller";
import {FacebookController} from "./controllers/execution/facebook.controller";
import {GoogleController} from "./controllers/execution/google.controller";
import {DashboardChartController} from "./controllers/execution/dashboardchart.controller";
import {WidgetBuilderController} from "./controllers/widget-builder/widget-builder.controller";
import {CustomDashboardController} from "./controllers/custom-dashboard/custom-dashboard.controller";
import { commonMiddleware } from "../../middlewares/common.middleware";

export class DynamicDashBoardRoutes extends AppRoutes {

    private dashboardCrudController: DashboardCrudController;
    private widgetCrudController: WidgetCrudController;
    private dashboardWidgetConfigController: DashboardWidgetConfigController;
    private sqlController: SqlController;
    private buttonWidgetController: ButtonWidgetController;
    private calendarController: CalendarController;
    private facebookController: FacebookController;
    private googleController: GoogleController;
    private dashboardchartController: DashboardChartController;
    private widgetBuilderController: WidgetBuilderController;
    private customDashboardController: CustomDashboardController;

    public route_prefix = '/dynamic-dashboard';

    constructor() {
        super();
        this.dashboardCrudController = new DashboardCrudController();
        this.widgetCrudController = new WidgetCrudController();
        this.dashboardWidgetConfigController = new DashboardWidgetConfigController();
        this.sqlController = new SqlController();
        this.buttonWidgetController = new ButtonWidgetController();
        this.calendarController = new CalendarController();
        this.facebookController = new FacebookController();
        this.googleController = new GoogleController();
        this.dashboardchartController = new DashboardChartController();
        this.widgetBuilderController = new WidgetBuilderController();
        this.customDashboardController = new CustomDashboardController();
        this.initRoutes();
    }

    initRoutes(): void {
        /* 
        //Dashboard CRUD
         * this.router.get('/dynamic-dashboard/client-dashboard', (req, res, next) => this.dashboardCrudController.getClientDashboard(req, res, next).catch(next));
         * this.router.get('/dynamic-dashboard/dashboard/:dashboardId', (req, res, next) => this.dashboardCrudController.getDashboard(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/add-dashboard', (req, res, next) => this.dashboardCrudController.addDashboard(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/edit-dashboard/:id', (req, res, next) => this.dashboardCrudController.editDashboard(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/delete-dashboard', (req, res, next) => this.dashboardCrudController.deleteDashboard(req, res, next).catch(next));

        //Widget CRUD
         * this.router.get('/dynamic-dashboard/list', (req, res, next) => this.widgetCrudController.widgetAccountList(req, res, next).catch(next));
         * this.router.get('/dynamic-dashboard/widget/:widgetId', (req, res, next) => this.widgetCrudController.getWidgetData(req, res, next).catch(next));
         * this.router.get('/dynamic-dashboard/get-widget/:widgetId', (req, res, next) => this.widgetCrudController.getWidget(req, res, next).catch(next));
         * this.router.get('/dynamic-dashboard/get-widget-account/:accountId', (req, res, next) => this.widgetCrudController.getWidgetAccount(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/move-widget-dashboard', (req, res, next) => this.widgetCrudController.moveWidgetDashboard(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/copy-widget-dashboard', (req, res, next) => this.widgetCrudController.copyWidgetDashboard(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/add-widget', (req, res, next) => this.widgetCrudController.addWidgetToDashboard(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/get-widget-account-list', (req, res, next) => this.widgetCrudController.getWidgetAccountList(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/add-widget-account', (req, res, next) => this.widgetCrudController.addWidgetAccount(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/update-widget-account', (req, res, next) => this.widgetCrudController.updateWidgetAccount(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/delete-widget/:widgetId', (req, res, next) => this.widgetCrudController.deleteWidget(req, res, next).catch(next));
         * this.router.delete('/dynamic-dashboard/delete-widget-account', (req, res, next) => this.widgetCrudController.deleteWidgetAccount(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/widget-position/:widgetId', (req, res, next) => this.widgetCrudController.updateWidgetPosition(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/widget-resize/:widgetId', (req, res, next) => this.widgetCrudController.updateWidgetSize(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/get-widget-list', (req, res, next) => this.widgetCrudController.getWidgetFromDashboard(req, res, next).catch(next));

        // Configure & Permission
         * this.router.post('/dynamic-dashboard/permission-widget/:widgetId', (req, res, next) => this.dashboardWidgetConfigController.permissionWidget(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/configure-widget/:widgetId', (req, res, next) => this.dashboardWidgetConfigController.configureWidget(req, res, next).catch(next));
         */

        // SQL
        this.router.post('/dashboard/sql/check-query', (req, res, next) => this.sqlController.checkQuery(req, res, next).catch(next));
        this.router.get('/dashboard/sql/account-list', (req, res, next) => this.sqlController.getSqlAccountList(req, res, next).catch(next));
        this.router.get('/dashboard/sql/get-db-info/:info/:widgetAccountId/:tableName?', (req, res, next) => this.sqlController.getDatabaseTableList(req, res, next).catch(next));
        this.router.get('/dashboard/sql/get-db-info/:tableName', (req, res, next) => this.sqlController.getLocalDatabaseColumnList(req, res, next).catch(next));
        this.router.post('/dashboard/sql/:widgetId', commonMiddleware, (req, res, next) => this.sqlController.getSqlData(req, res, next).catch(next));
        this.router.post('/dashboard/sql-builder/:widgetId', commonMiddleware, (req, res, next) => this.sqlController.getSqlBuilderData(req, res, next).catch(next));
        this.router.post('/dashboard/unique-column', commonMiddleware, (req, res, next) => this.sqlController.getUniqueColumn(req, res, next).catch(next));
        this.router.post('/dashboard/sql/tables-columns/:widgetAccountId', (req, res, next) => this.sqlController.getDatabaseTablesWithColumnsList(req, res, next).catch(next));

        /*
        //Calendar
         * this.router.get('/dynamic-dashboard/calendar-event-list/:widgetId', (req, res, next) => this.calendarController.calendarEventList(req, res, next).catch(next));

        //Facebook
         * this.router.get('/dynamic-dashboard/facebook/:widgetId', (req, res, next) => this.facebookController.getFacebookData(req, res, next).catch(next));
         * this.router.post('/dynamic-dashboard/facebook/campaign-list', (req, res, next) => this.facebookController.getCampaignList(req, res, next).catch(next));

        //Google
         * this.router.get('/dynamic-dashboard/google-widget/:widgetId', (req, res, next) => this.googleController.getGoogleDetails(req, res, next).catch(next));

        //Chart this is not done - need to fix 
         * this.router.post('/dynamic-dashboard/form-chart/:widgetId', (req, res, next) => this.chartController.chartExecution(req, res, next).catch(next));
         * this.router.get('/dynamic-dashboard/form-folder/:formId', (req, res, next) => this.chartController.getFormFolder(req, res, next).catch(next));

        //Button
         * this.router.post('/dynamic-dashboard/button-widget/:widgetId', (req, res, next) => this.buttonWidgetController.getButtonWidgetData(req, res, next).catch(next));

        // Widget Builder
         * this.router.post(this.route_prefix + '/widget-builder-list',  (req, res, next) => this.widgetBuilderController.getWidgetBuilderList(req, res, next).catch(next) );
         * this.router.post(this.route_prefix + '/widget-builder-add',  (req, res, next) => this.widgetBuilderController.widgetBuilderAdd(req, res, next).catch(next) );
         * this.router.get(this.route_prefix + '/widget-builder-details/:widgetId',  (req, res, next) => this.widgetBuilderController.widgetBuilderDetails(req, res, next).catch(next) );
         * this.router.post(this.route_prefix + '/widget-builder-update/:widgetId',  (req, res, next) => this.widgetBuilderController.widgetBuilderUpdate(req, res, next).catch(next) );
         * this.router.post(this.route_prefix + '/widget-builder-delete',  (req, res, next) => this.widgetBuilderController.widgetBuilderDelete(req, res, next).catch(next) );

        // Custom Dashboard
         * this.router.post('/dynamic-dashboard/widget-builder-get-count', (req, res, next) => this.customDashboardController.getCount(req, res, next).catch(next));
         */
    }
}
