import { SettingConfig } from "../../../entities";
import dbService from "../../../services/db.service";
import Container from 'typedi';
import {DataSource} from 'typeorm';

export class OpenApiService {

    async saveSettingConfig(payload: any): Promise<SettingConfig | null> {
        return dbService._createQueryService(Container.get(DataSource).getRepository(SettingConfig), payload);
    }

    async getConfig(condition: any, fields: any[] = []): Promise<SettingConfig | null> {
        return dbService._findOneQueryService(Container.get(DataSource).getRepository(SettingConfig), { where: condition, select: fields });
    }
}
