import multer from 'multer';
import { AppRoutes } from "../../app.routes";
import { OpenApiController } from './controllers/open-api.controller';

const s3Storage = multer.memoryStorage();

const s3Uploads = multer({
    storage: s3Storage,
    limits: {
        fileSize: 8000000 // 8MB
    }
})

export class OpenApiRoutes extends AppRoutes {
    public route_prefix = '/open-apis';
    private openApiController: OpenApiController;
    
    constructor() {
        super();
        this.openApiController = new OpenApiController();
        this.initRoutes();
    }

    initRoutes() {
        this.router.post('/open-apis/s3upload-file', s3Uploads.single("file"), (req: any, res, next) =>
            this.openApiController.uploadFile(req, res, next).catch(next)
        );
        this.router.get('/validateVehicle/:chesisNo', (req, res, next) =>
            this.openApiController.validateVehicle(req, res, next).catch(next)
        );
        this.router.get('/open-apis/mapBoxData/:type', (req, res, next) =>
            this.openApiController.getMapBoxData1(req, res, next).catch(next)
        );
        this.router.post('/executeScript', (req, res, next) =>
            this.openApiController.executeScript(req, res, next).catch(next)
        );
        this.router.get('/open-apis/predictBurntArea', (req, res, next) =>
            this.openApiController.predictBurntArea(req, res, next).catch(next)
        );
    }
}
