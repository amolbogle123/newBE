export interface KeyResponse {
    status: boolean;
    data?: any;
    message?: string;
}