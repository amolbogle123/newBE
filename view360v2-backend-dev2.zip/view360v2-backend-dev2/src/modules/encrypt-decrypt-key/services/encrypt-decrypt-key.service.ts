import crypto from "crypto";
import fs from "fs";

export class EncryptDecryptKeyService {
    async generatePemFile() {
        return new Promise(async (resolve) => {
            try {
                crypto.generateKeyPair(
                    "rsa",
                    {
                        modulusLength: 2048,
                        publicKeyEncoding: { type: "spki", format: "pem" }, //'pem', 'der', or 'jwk'.
                        privateKeyEncoding: { type: "pkcs8", format: "pem" },
                    },
                    async (err, publicKey, privateKey) => {
                        if (err) {
                            resolve(false);
                            return;
                        }

                        const base64UploadDir = "./public/encrypt-crypto-file/";
                        if (!fs.existsSync(base64UploadDir)) {
                            fs.mkdirSync(base64UploadDir);
                        }
                        fs.writeFileSync(
                            `${base64UploadDir}public.pem`,
                            publicKey
                        );
                        fs.writeFileSync(
                            `${base64UploadDir}private.pem`,
                            privateKey
                        );

                        // For test this pem file
                        /**
                         * let data = "Hi, hello";
                        console.log(
                            "err, publicKey, privateKey",
                            err,
                            publicKey.toString()
                        );
                        console.log(
                            " ----------> private key",
                            privateKey.toString()
                        );

                        console.log(" ---------->data", data);
                        const encryptedData = await crypto.publicEncrypt(
                            publicKey,
                            Buffer.from(data)
                        );
                        let encrypted = encryptedData.toString("base64");
                        console.log("encrypted--------->string", encrypted);

                        const decryptedData = await crypto.privateDecrypt(
                            privateKey,
                            Buffer.from(encrypted, "base64")
                        );
                        let decrypted = decryptedData.toString();
                        console.log("decrypted--------->string", decrypted);
                        */

                        resolve(true);
                    }
                );
            } catch (error) {
                resolve(false);
                return;
            }
        });
    }
}
