import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import fs from "fs";
import { Controller, Get, Hidden, Request, Route, Security, Tags } from "tsoa";
import { KeyResponse } from "../doc/encrypt-decrypt-key-interface";
import { EncryptDecryptKeyService } from "../services/encrypt-decrypt-key.service";

@Route("encrypt-decrypt-key")
@Tags("Encrypt Decrypt Key")
export class EncryptDecryptKeyController extends Controller {
    public encryptDecryptKeyService = new EncryptDecryptKeyService();

    @Security("bearerAuth")
    @Get("public-key")
    @Hidden()
    async getPublicKey(
        @Request() request: any
    ): Promise<KeyResponse | unknown> {
        try {
            const apiResponse = {
                data: null,
            };

            if (process.env.PUBLIC_PEM_KEY_PATH) {
                const readPemFile = fs.readFileSync(
                    process.env.PUBLIC_PEM_KEY_PATH,
                    "utf8"
                );
                if (readPemFile) {
                    apiResponse.data = readPemFile
                        .replace(/-----BEGIN PRIVATE KEY-----/g, "")
                        .replace(/-----END PRIVATE KEY-----/g, "")
                        .replace(/\n/g, "");
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("generate-key")
    @Hidden()
    async generateKey(@Request() request: any): Promise<KeyResponse | unknown> {
        try {
            const apiResponse = {
                data: null,
            };

            if (process.env.PUBLIC_PEM_KEY_PATH) {
                fs.unlinkSync(process.env.PUBLIC_PEM_KEY_PATH);
            }
            if (process.env.PRIVATE_PEM_KEY_PATH) {
                fs.unlinkSync(process.env.PRIVATE_PEM_KEY_PATH);
            }

            const details =
                await this.encryptDecryptKeyService.generatePemFile();
            if (!details) {
                this.setStatus(500);
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description: "Unable to generate key",
                    },
                });
            }
            apiResponse.data = {
                publicKeyPath: process.env.PUBLIC_PEM_KEY_PATH,
                privateKeyPath: process.env.PRIVATE_PEM_KEY_PATH,
            };

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
