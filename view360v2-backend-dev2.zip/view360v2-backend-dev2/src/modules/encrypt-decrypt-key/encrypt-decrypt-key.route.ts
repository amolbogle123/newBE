import { AppRoutes } from "../../app.routes";
import { EncryptDecryptKeyController } from "./controllers/encrypt-decrypt-key.controller";

export class EncryptDecryptKeyRoutes extends AppRoutes {
    private encryptDecryptKeyController: EncryptDecryptKeyController;

    constructor() {
        super();
        this.encryptDecryptKeyController = new EncryptDecryptKeyController();
    }
}
