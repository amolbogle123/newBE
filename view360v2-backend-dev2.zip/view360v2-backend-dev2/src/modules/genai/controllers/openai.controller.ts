import axios from "axios";
import {
    Body,
    Controller,
    Get,
    Path,
    Post,
    Request,
    Route,
    Tags
} from "tsoa";
import Container from "typedi";
import { DataSource, In } from "typeorm";
import {
    GenAIHistory
} from "../../../entities";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";

import OpenAI from "openai";
import dbService from "services/db.service";

const openai = new OpenAI({
   // apiKey: "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",
    apiKey: "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",
});

@Route("genai")
@Tags("Generative AI ")
export class OpenAIController extends Controller {
    @Post("generate-image")
    async generateImage(
        @Request() request: any,
        @Body() requestBody: any
    ): Promise<any> {
        try {
            const { prompt, size } = requestBody;

            console.log(requestBody);

            const imageSize =
                size === "small"
                    ? "256x256"
                    : size === "medium"
                    ? "512x512"
                    : "1024x1024";

            const response: any = await openai.images.generate({
                prompt,
                n: 1,
                size: imageSize,
            });

            console.log(response);

            // save history
            const genAIObject = new GenAIHistory();
            genAIObject.type = "image";
            genAIObject.clientId = request.userDetails
                ? request.userDetails.client_id
                : 1;
            genAIObject.question = prompt;
            genAIObject.answer = response.data[0].url;

            await Container.get(DataSource).manager.save(genAIObject);

            return CommonHelper.apiSwaggerSuccessResponse({
                data: response.data[0].url,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: error.message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("generate-text")
    async generateText(
        @Request() request: any,
        @Body() requestBody: any
    ): Promise<any> {
        try {
            const { prompt } = requestBody;

            const response: any = await openai.completions.create({
                prompt,
                n: 1,
                model: "gpt-3.5-turbo-0301",
                max_tokens: 500,
            });

            console.log(request.userDetails);

            //save history

            const genAIObject = new GenAIHistory();
            genAIObject.type = "text";
            genAIObject.clientId = request.userDetails
                ? request.userDetails.client_id
                : 1;
            genAIObject.question = prompt;
            genAIObject.answer = response.choices[0].text;

            await Container.get(DataSource).manager.save(genAIObject);

            return CommonHelper.apiSwaggerSuccessResponse({
                data: response.choices,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: error.message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("sentiment-analysis")
    async sentiMentAnalysis(
        @Request() request: any,
        @Body() requestBody: any
    ): Promise<any> {
        try {
            const { prompt } = requestBody;

            const response: any = await openai.completions.create({
                prompt: `Analyze the sentiment of the following text:\n\n"${prompt}"\n\nSentiment:`,
                n: 1,
                model: "text-davinci-003",
                temperature: 0,
                max_tokens: 500,
            });

            console.log(response);

            const textResponse = response.choices;
            const sentiment = response.choices[0].text.trim();
            // Map sentiment to emoji
            let emoji;
            if (sentiment.toLowerCase().includes("positive")) {
                emoji = "😊";
            } else if (sentiment.toLowerCase().includes("negative")) {
                emoji = "😞";
            } else {
                emoji = "😐";
            }

            return CommonHelper.apiSwaggerSuccessResponse({
                data: { textResponse, sentiment },
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: error.message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("genai-history/:type")
    async getGenAIHistory(
        @Request() request: any,
        @Path() type: string
    ): Promise<any> {
        try {
            const { clientId } = request.userDetails.client_id;

            const response = await Container.get(DataSource).manager.find(
                GenAIHistory,
                {
                    where: {
                        clientId: clientId,
                        type: type,
                    },
                    order: {
                        createdOn: "DESC",
                    },
                }
            );

            return CommonHelper.apiSwaggerSuccessResponse({ data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: error.message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("genai-history/delete")
    async deleteMultipleGenAIHistory(@Body() ids: string[]): Promise<any> {
        try {
            console.log(ids);
            // Check if IDs array is empty
            if (!ids || ids.length === 0) {
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description: "No IDs provided for deletion.",
                    },
                });
            }

            // Delete multiple records using an IN clause
            const deletedData = await dbService._deleteQueryService(
                Container.get(DataSource).getRepository(GenAIHistory),
                {
                    id: In(ids),
                }
            );

            if (deletedData.affected === 0) {
                // If no data was deleted, handle the case accordingly
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description:
                            "No matching records found for the provided IDs.",
                    },
                });
            }

            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Records deleted successfully.",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: error.message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("world")
    async getWorldData(@Request() request: any): Promise<any> {
        try {
            const apiUrl =
                "https://echarts.apache.org/examples/data/asset/geo/world.json";
            let resp;
            // Make an HTTP GET request to the external API
            await axios
                .get(apiUrl)
                .then((response) => {
                    // Handle the API response data
                    const responseData = response.data;
                    resp = response.data;
                    console.log("API Response:", responseData);
                })
                .catch((error) => {
                    // Handle errors
                    console.error("Error:", error.message);
                });

            return CommonHelper.apiSwaggerSuccessResponse({ data: resp });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: error.message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
