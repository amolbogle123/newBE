import { CommonHelper,ApiErrorResponse } from "../../../utils/helpers/common.helper";
import { DataSource } from "typeorm";
import Container from "typedi";
import { CustomHeader } from "../../../entities";
import { Body, Delete, Get, Post, Request, Route, Security, Tags, Controller, Patch } from "tsoa";
import { AddUpdateCustomHeaderRequestBody, AddCustomHeaderResponse, GetCustomHeaderResponse, CustomHeaderMessageResponse, CustomHeaderApiErrorResponse, DeleteCustomHeaderRequestBody } from "../doc/custom-header.interface";
@Route("custom-header")
@Tags("Custom Header")
export class CustomHeaderController extends Controller {
    /**
     * get CustomHeader Objects
     */
    @Security('bearerAuth')
    @Get("/")
    async get(
        @Request() req: any
    ): Promise<GetCustomHeaderResponse | CustomHeaderApiErrorResponse> {
        try {
            let Objects = await Container.get(DataSource)
                .getRepository(CustomHeader)
                .findOneBy({
                    clientId: req.userDetails.client_id,
                });
            if (Objects) {
                if (Objects?.config) {
                    Objects.config = JSON.parse(Objects.config);
                }
                
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: Objects,
                });
            } else {
                this.setStatus(204);
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "No records has been found!.",
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update CustomHeader Objects
     */
    @Security('bearerAuth')
    @Patch("/")
    async update(
        @Request() request: any,
        @Body() body: AddUpdateCustomHeaderRequestBody
    ): Promise<CustomHeaderMessageResponse | CustomHeaderApiErrorResponse> {
        try {
            let customHeader: any = body;
            let result = await Container.get(DataSource)
                .getRepository(CustomHeader)
                .update(
                    { clientId: request.userDetails.client_id },
                    customHeader
                );

            if (result.affected > 0) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Custom Header updated successfully",
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Custom Header Not Found",
                });
            }
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Add CustomHeader Objects
     */
    @Security('bearerAuth')
    @Post("/")
    async add(
        @Request() req: any,
        @Body() body: AddUpdateCustomHeaderRequestBody
    ): Promise<AddCustomHeaderResponse | CustomHeaderApiErrorResponse> {
        try {
            const customHeaderObj = new CustomHeader();
            customHeaderObj.config = body.config;
            customHeaderObj.active = body.active;
            customHeaderObj.clientId = req.userDetails.client_id;
            customHeaderObj.createdBy = req.userDetails.id;

            const result = await Container.get(DataSource).manager.save(
                customHeaderObj
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({ data: result });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Delete("/")
    async delete(
        @Request() request: any,
        @Body() body: DeleteCustomHeaderRequestBody
    ): Promise<CustomHeaderMessageResponse | CustomHeaderApiErrorResponse> {
        try {
            const result = await Container.get(DataSource)
                .getRepository(CustomHeader)
                .delete({ id: body.id, clientId: request.userDetails.client_id });

            if (result.affected > 0) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Record deleted successfully"
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "No Record Found",
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
