export interface AddUpdateCustomHeaderRequestBody {
    active:number;
    config:string;
}
export interface DeleteCustomHeaderRequestBody {
    id:string;
}
export interface GetCustomHeaderResponse {
    status:boolean;
    message:string;
    data:CustomHeader[];
}
export interface AddCustomHeaderResponse {
    status:boolean;
    message:string;
    data:CustomHeader;
}
export interface CustomHeader {
    id:string;
    clientId:string;
    config:unknown | string,
    active:number;
    createdBy:string;
    createdOn:string;
}
export interface CustomHeaderMessageResponse {
    message:string;
}
export interface CustomHeaderApiErrorResponse {
    status:boolean;
    message:string;
    error:{
        error_description:string;
    };
}