import { AppRoutes } from "../../app.routes";
import { CustomHeaderController } from "./controllers/custom-header.controller";

export class CustomHeaderRoutes extends AppRoutes {
    customHeaderService: CustomHeaderController;

    constructor() {
        super();
        this.customHeaderService = new CustomHeaderController();
        this.initRoutes();
    }

    initRoutes() {
        /*
         * this.router.get("/custom-header", (req, res, next) => this.customHeaderService.getDetails(req, res, next).catch(next));
         * this.router.post("/custom-header", (req, res, next) => this.customHeaderService.addCustomHeader(req, res, next).catch(next));
         * this.router.put("/custom-header", (req, res, next) => this.customHeaderService.updateCustomHeader(req, res, next).catch(next));
         * this.router.delete("/custom-header", (req, res, next) => this.customHeaderService.deleteRouter(req, res, next).catch(next));
         */
    }
}
