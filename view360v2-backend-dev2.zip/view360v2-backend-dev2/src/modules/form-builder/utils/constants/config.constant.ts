

export const formBuilderTableName: string = 'form_builder_';
export const customFormTableName: string ='CUSTOM_FORM_';
export const formIoIgnoreFields: any [] =[];
