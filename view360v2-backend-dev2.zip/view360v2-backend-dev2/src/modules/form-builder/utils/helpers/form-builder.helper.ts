import { DatabaseConnection } from "../../../../core/data-source";
import {
    createFormBuilder,
    createFormBuilderHistory,
    createFormBuilderPdf,
    FormBuilder,
    formBuilderEntity,
    FormBuilderHistory,
    formBuilderHistoryEntity, FormBuilderPdf,
    formBuilderPdfEntity
} from "../../../../entities/create-form-builder";
import {DataSource, EntityMetadata, Repository} from "typeorm";
import Container from 'typedi';

export class FormBuilderHelper {

    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    static async setOrigin(headerOrigin: any, status: boolean): Promise<any> {
        // TO_DO: need to work (don't have this in old source code)
        return headerOrigin;
    }

    static async generateFormBuilderEntity(client_id: number, entity?: any): Promise<DataSource> {

        try {
            let listEntities: any = [];

            // create form builder for mdb client
            const fbEntity = createFormBuilder(client_id);
            const fbHistoryEntity = createFormBuilderHistory(client_id);
            const fbPdf = createFormBuilderPdf(client_id);

            switch (entity) {
                case formBuilderEntity:
                    listEntities.push(fbEntity); break;
                case formBuilderHistoryEntity:
                    listEntities.push(fbHistoryEntity); break;
                case formBuilderPdfEntity:
                    listEntities.push(fbPdf); break;
                default:
                    listEntities = [fbEntity, fbHistoryEntity, fbPdf];
            }

            // re-initializing the db connection (because new entities has been added)
            const dataSourceConnection: DatabaseConnection = new DatabaseConnection();
            return await dataSourceConnection.setDbOption(listEntities);
        } catch (e) {
            FormBuilderHelper.throwError(e.message);
        }
    }

    static async getEntityMetaData(client_id: number, entityName: string): Promise<EntityMetadata> {
        if (!Container.get(DataSource).hasMetadata(entityName)) {
            return (await FormBuilderHelper.generateFormBuilderEntity(client_id, entityName)).getMetadata(entityName);
        }
        return Container.get(DataSource).getMetadata(entityName);
    }

    static async getTableName(client_id: number, entityName: string): Promise<string> {
        if (!Container.get(DataSource).hasMetadata(entityName)) {
            return (await FormBuilderHelper.generateFormBuilderEntity(client_id, entityName))
                .getMetadata(entityName).tableName;
        }
        return (Container.get(DataSource).getRepository(entityName) as unknown as EntityMetadata).tableName;
    }

    static async formBuilderRepo(client_id: number, referenceId?: string): Promise<Repository<FormBuilder>> {
        if (!Container.get(DataSource).hasMetadata(formBuilderEntity)) {
            return (await FormBuilderHelper.generateFormBuilderEntity(client_id, formBuilderEntity))
                .getRepository(formBuilderEntity);
        }
        return Container.get(DataSource).getRepository(formBuilderEntity);
    }    

    static async formBuilderHistoryRepo(client_id: number, referenceId?: string): Promise<Repository<FormBuilderHistory>> {
        if (!Container.get(DataSource).hasMetadata(formBuilderHistoryEntity)) {
            return (await FormBuilderHelper.generateFormBuilderEntity(client_id, formBuilderHistoryEntity))
                .getRepository(formBuilderHistoryEntity);
        }
        return Container.get(DataSource).getRepository(formBuilderHistoryEntity);
    }

    static async formBuilderPdfRepo(client_id: number): Promise<Repository<FormBuilderPdf>> {
        if (!Container.get(DataSource).hasMetadata(formBuilderPdfEntity)) {
            return (await FormBuilderHelper.generateFormBuilderEntity(client_id, formBuilderPdfEntity))
                .getRepository(formBuilderPdfEntity);
        }
        return Container.get(DataSource).getRepository(formBuilderPdfEntity);
    }
}