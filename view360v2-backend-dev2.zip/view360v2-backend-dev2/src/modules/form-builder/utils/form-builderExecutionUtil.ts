import {MySQLExecutorUtil} from "../../connectors/executor-utils/mySQLExecutor.util";
import {CommonUtil} from "utils/common.util";


export class FormBuilderExecutionUtil {

    static async executeFormBuilderQuery(table,fields, whereClauseValues, pagination, field, order, filters, defaultOrderBy,whereFieldsData:any,isPivotForTextBasedColumn) {
        let accountConfigDetails = {
            dbType: process.env.DB_TYPE || "",
            dbHost: process.env.DB_HOST || "",
            dbPort: process.env.DB_PORT || "",
            dbUser: process.env.DB_USERNAME || "",
            dbPassword: process.env.DB_PASSWORD || "",
            dbName: process.env.DB_NAME || ""
        }
        let labelList = [];//to be used in case of pivot for text based column
        let whereClause = await this.prepareWhereClauseValues(whereClauseValues);
        let mysqlQuery = '';
        let limitQuery = '';
        let offsetQuery = ' OFFSET 0';
        if (pagination.start === '') {
            offsetQuery = '';
        } else if (pagination.start > 0) {
            offsetQuery = ' OFFSET ' + pagination.start;
        }
        if (pagination?.limit) {
            limitQuery = ' LIMIT ' + pagination.limit;
        }
        const filterConditions = await this.checkFilterWhereCondition(filters);
        const filterWithANDCondition = await this.addAndBeforeString(filterConditions);
      if(whereFieldsData?.whereFields.length>0 && whereFieldsData?.whereFields[0].matchValue) {
            const whereClauses = whereFieldsData?.whereFields.map((whereClause) => {
                if (whereClause.matchValue.startsWith(".roleid") && !whereFieldsData?.is_superadmin) {
                    const nestedFieldName = whereClause.matchValue.replace(".", "");
                    const nestedFieldValue = whereFieldsData?.role_id;
                    return ` AND JSON_EXTRACT(JSON_EXTRACT(SUBMITTED_DATA, '$.${whereClause.columnName}'), '$.${nestedFieldName}') = '${nestedFieldValue}'`;
                } else {
                    if(!whereFieldsData?.is_superadmin){
                    return ` AND JSON_EXTRACT(SUBMITTED_DATA, '$.${whereClause.columnName}') = '${whereClause.matchValue}'`;
                    }
                }
            });
          whereClause = whereClause ? whereClause + whereClauses.join(" ") : ``;
        }

        if(isPivotForTextBasedColumn){
            // Step 1: Construct the query to get distinct yAxis column values
            const yAxisDataQuery = `SELECT DISTINCT ${fields[2]} FROM form_builder_1 WHERE ${whereClause};`;

            // Step 2: Execute the query and get the distinct yAxis values
            const yAxisData: any = await MySQLExecutorUtil.executeMYSQLQuery(yAxisDataQuery, accountConfigDetails);

            // Step 3: Construct the dynamic SQL query for aggregating the counts based on distinct yAxis values
            const dynamicColumns = yAxisData.data
                .map((status: any) => {
                    let columnValue = status[Object.keys(status)[0]];
                    columnValue = columnValue.replace(/^"|"$/g, '');  // Removes surrounding double quotes
                    labelList.push({id: columnValue, name: columnValue});
                    return `SUM(CASE WHEN ${fields[2].split("AS")[0]} = '${columnValue}' THEN 1 ELSE 0 END) AS \`${columnValue}\``;
                })
                .join(', ');

            // Step 4: Construct the final SQL query with the dynamic columns
            mysqlQuery = `
                SELECT ${fields[0]}, ${dynamicColumns}
                FROM form_builder_1
                WHERE ${whereClause} ${filterWithANDCondition} ${defaultOrderBy} ${limitQuery} ${offsetQuery};
            `;
        }else{
            mysqlQuery = `SELECT ${fields} FROM ${table} WHERE ${whereClause} ${filterWithANDCondition} ${defaultOrderBy} ${limitQuery} ${offsetQuery}`;
        }
        const mysqlData: any = await MySQLExecutorUtil.executeMYSQLQuery(mysqlQuery, accountConfigDetails);
        if(field && order) {
            const sortedData = await this.sortBySubmittedData(mysqlData.data, field, order);
            mysqlData.data = [];
            mysqlData.data = sortedData;
        }
        mysqlData['labelList'] = labelList;
        if (mysqlData.status) {
            mysqlData.query = mysqlQuery;
            return mysqlData;
        } else {
            return mysqlData
        }
    }

   static async addAndBeforeString(filterConditions) {
        // Check if filterConditions is empty or undefined
        if (!filterConditions) {
            return filterConditions;
        }

        // Prepend "AND " only if the string is not empty
        return `AND ${filterConditions}`;
    }

    static async sortBySubmittedData(data, field, order) {
        try {
            return data.sort((a, b) => {
                const valueA = JSON.parse(a.SUBMITTED_DATA)[field];
                const valueB = JSON.parse(b.SUBMITTED_DATA)[field];

                return this.sortingMethod(valueA, valueB, order);
            });
        } catch (e) {
            console.error('Error :: ' + e);
        }
    }

    static sortingMethod(order, valueA, valueB) {
        if (order === 'ASC') {
            if (valueA < valueB) return -1;
            if (valueA > valueB) return 1;
            return 0;
        } else if (order === 'DESC') {
            if (valueA < valueB) return 1;
            if (valueA > valueB) return -1;
            return 0;
        }
    }

    static async prepareWhereClauseValues(whereClauseValues) {
        let whereClause = '';
        if (whereClauseValues) {
            for (let key in whereClauseValues) {
                if(whereClauseValues[key]) {
                    whereClause += whereClause.length > 0 ? ' AND' : '';
                    if (key === 'CLIENT_ID') {
                        whereClause += `${key} = ${whereClauseValues[key]}`
                    } else {
                        whereClause += ` ${key} = '${whereClauseValues[key]}'`
                    }
                }
            }
        }
        return whereClause;
    }

    static async checkFilterWhereCondition(filters) {
        let filterWhere = '';
        filterWhere = await CommonUtil.applyFilterToForms(
            filters,
            filterWhere
        );
        return filterWhere;
    }
}
