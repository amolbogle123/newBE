import { AppRoutes } from "../../app.routes";
import { CommentController } from "./controllers/comment.controller";
import { TimeLogController } from "./controllers/time-log.controller";
import { FormBuilderController } from "./controllers/form-builder.controller";
import { FormBuilderEntryController } from "./controllers/form-builder-entry.controller";
import { FormBuilderHistoryController } from "./controllers/form-builder-history.controller";



export class FormBuilderRoutes extends AppRoutes {

    private commentController: CommentController;
    private timeLogController: TimeLogController;
    private formBuilderController: FormBuilderController;
    private formBuilderEntryController: FormBuilderEntryController;
    private formBuilderHistoryController: FormBuilderHistoryController;

    constructor() {
        super();
        this.commentController = new CommentController();
        this.timeLogController = new TimeLogController();
        this.formBuilderController = new FormBuilderController();
        this.formBuilderEntryController = new FormBuilderEntryController();
        this.formBuilderHistoryController = new FormBuilderHistoryController();

        this.initRoutes();
    }


    initRoutes() {
        /*
         * // document controllers apis
         * this.router.post('/form-builder/add-document', (req, res, next) => this.documentController.insertDocument(req, res, next).catch(next));
         * this.router.post('/form-builder/update-document', (req, res, next) => this.documentController.updateDocument(req, res, next).catch(next));
         * this.router.post('/form-builder/delete-document', (req, res, next) => this.documentController.deleteDocument(req, res, next).catch(next));
         * this.router.post('/form-builder/update-document-user', (req, res, next) => this.documentController.updateDocumentUser(req, res, next).catch(next));
         * this.router.get('/form-builder/act-deact-form-folder/:id/:action', (req, res, next) => this.documentController.setFolderActivityStatus(req, res, next).catch(next));
         * this.router.get('/form-builder/document-details/:id', (req, res, next) => this.documentController.documentDetails(req, res, next).catch(next));
         * this.router.get('/form-builder/document-list', (req, res, next) => this.documentController.documentList(req, res, next).catch(next));
         * this.router.get('/form-builder/all-custom-forms', (req, res, next) => this.documentController.getDocumentWithFormList(req, res, next).catch(next));

        // comment controllers apis
         * this.router.post('/form-builder/add-comment', (req, res, next) => this.commentController.insertComment(req, res, next).catch(next));
         * this.router.post('/form-builder/get-all-comments/:formId/:entryId', (req, res, next) => this.commentController.getCommentsList(req, res, next).catch(next));

        // timers controllers apis
         * this.router.get('/form-builder/get-time-logs/:formId/:entryId', (req, res, next) => this.timeLogController.getTimeLogs(req, res, next).catch(next));
         * this.router.get('/form-builder/check-filling-availability/:formId/:entryId', (req, res, next) => this.timeLogController.checkFillingAvailability(req, res, next).catch(next));
         * this.router.post('/form-builder/update-filling-availability', (req, res, next) => this.timeLogController.updateFillingAvailability(req, res, next).catch(next));

        // form builder controllers apis
         * this.router.post('/form-builder/create-custom-form', (req, res, next) => this.formBuilderController.createFormBuilder(req, res, next).catch(next));
         * this.router.post('/form-builder/edit-custom-form', (req, res, next) => this.formBuilderController.updateFormBuilder(req, res, next).catch(next));
         * this.router.post('/form-builder/custom-forms-list', (req, res, next) => this.formBuilderController.getCustomFormList(req, res, next).catch(next));
         * this.router.get('/form-builder/get-custom-form/:id', (req, res, next) => this.formBuilderController.getCustomForm(req, res, next).catch(next));
         * this.router.get('/form-builder/all-form', (req, res, next) => this.formBuilderController.getAllFormList(req, res, next).catch(next));
         * this.router.post('/form-builder/sent-form', (req, res, next) => this.formBuilderController.sentForm(req, res, next).catch(next));
         * this.router.put('/form-builder/update-form-mapped-user', (req, res, next) => this.formBuilderController.updateFormMappedUser(req, res, next).catch(next));
         * this.router.delete('/form-builder/delete-custom-forms', (req, res, next) => this.formBuilderController.deleteFormBuilder(req, res, next).catch(next));

        // form builder entry controllers apis
         * this.router.get('/form-builder/saved-forms-list/:id', (req, res, next) => this.formBuilderEntryController.entryList(req, res, next).catch(next));
         * this.router.get('/form-builder/get-filled-form/:formId/:id', (req, res, next) => this.formBuilderEntryController.entryDetails(req, res, next).catch(next));
         * this.router.post('/form-builder/submit-custom-form', (req, res, next) => this.formBuilderEntryController.insertEntryForm(req, res, next).catch(next));
         * this.router.post('/form-builder/update-custom-form', (req, res, next) => this.formBuilderEntryController.updateEntryForm(req, res, next).catch(next));
         * this.router.delete('/form-builder/delete-forms-entry', (req, res, next) => this.formBuilderEntryController.deleteEntryForm(req, res, next).catch(next));

        //this.router.get('/form-builder/get-self-registration-custom-form/:client_id/:form_id', (req, res, next) => this.formBuilderController.getSelfRegistrationCustomForm(req, res, next).catch(next));
        //this.router.post('/form-builder/submit-self-registration-custom-form', (req, res, next) => this.formBuilderEntryController.insertSelfRegistrationCustomForm(req, res, next).catch(next));

        //this.router.post('/form-builder/report-form-entries', (req, res, next) => this.formBuilderEntryController.formReportEntryDataTableList(req, res, next).catch(next));
        //this.router.post('/charts/chart-data', (req, res, next) => this.formBuilderEntryController.getChartData(req, res, next).catch(next));
        //this.router.post('/form-builder/export-report-entries', (req, res, next) => this.formBuilderEntryController.exportFormReportEntryData(req, res, next).catch(next));

        // Form Builder Dashboard
         * this.router.post('/form-builder/custom-forms-dashboard', (req, res, next) => this.formBuilderController.customFormsDashboard(req, res, next).catch(next));
         * this.router.post('/form-builder/form-entries', (req, res, next) => this.formBuilderEntryController.formEntries(req, res, next).catch(next));

        // Excel Mapper
         * this.router.post('/form-builder/excel-mapper-list', (req, res, next) => this.excelMapperController.excelMapperList(req, res, next).catch(next));
         * this.router.get('/form-builder/get-all-excel-mapper', (req, res, next) => this.excelMapperController.getAllExcelMapper(req, res, next).catch(next));
         * this.router.post('/form-builder/save-excel-mapper', (req, res, next) => this.excelMapperController.saveExcelMapper(req, res, next).catch(next));
         * this.router.get('/form-builder/get-excel-mapper/:id', (req, res, next) => this.excelMapperController.getExcelMapper(req, res, next).catch(next));
         * this.router.post('/form-builder/update-excel-mapper/:id', (req, res, next) => this.excelMapperController.updateExcelMapper(req, res, next).catch(next));
         * this.router.post('/form-builder/delete-excel-mapper', (req, res, next) => this.excelMapperController.deleteExcelMapper(req, res, next).catch(next));
        //this.router.post('/form-builder/submit-mapper-custom-form', (req, res, next) => this.formBuilderEntryController.submitMapperCustomForm(req, res, next).catch(next));

        // Form Builder Version History
         * this.router.get('/form-builder/version-history/:formId/:entryId', (req, res, next) => this.formBuilderHistoryController.getVersionHistory(req, res, next).catch(next));
        */
    }

}
