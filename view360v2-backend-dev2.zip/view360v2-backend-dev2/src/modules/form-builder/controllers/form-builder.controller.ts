import * as constants from '../utils/constants/config.constant';
import { CustomForms, FormMapper, MdbClient, RequestForm } from "../../../entities";
import { FormBuilderService } from "../services/form-builder.service";
import { DocumentService } from "../../documents/services/document.service";
import * as txt from '../utils/constants/api.constant';
import * as crypto from "crypto";
import { FormBuilderHelper } from "../utils/helpers/form-builder.helper";
import { CommonHelper, ApiErrorResponse } from "../../../utils/helpers/common.helper";
import { dataSource } from "../../../core/data-source";
import { DataSource, In } from "typeorm";
import lodash from "lodash";
import { CommunicationHelper } from "../../../utils/helpers/communication.helper";
import { Body, Delete, Get, Path, Post, Patch, Request, Route, Security, Tags, Controller, Query, Middlewares } from "tsoa";
import { CreateFormBuilderRequest, CreateFormBuilderResponse, EditCustomFormRequest, GetCustomFormListResponse, GetCustomFormResponse } from "../doc/formBuilder-interface";
import { UserType } from "../../../models/enums";
import { cacheResponseData } from "../../../utils/redis.middleware";
import Container from 'typedi';
import { CommonUtil } from 'utils/common.util';
import { commonMiddleware } from '../../../middlewares/common.middleware';
import dbService from 'services/db.service';
import fs from "fs";
import xlsx from "xlsx";

@Route('form-builder')
@Tags('Form Builder')
export class FormBuilderController extends Controller {

    private formBuilderService: FormBuilderService = new FormBuilderService();
    private documentService: DocumentService = new DocumentService();
    private communicationHelperService: CommunicationHelper = new CommunicationHelper();

    @Security('bearerAuth')
    @Post('form')
    @Middlewares(commonMiddleware)
    async createFormBuilder(
        @Body() requestBody: CreateFormBuilderRequest,
        @Request() request: any
    ): Promise<CreateFormBuilderResponse | unknown> {
        try {
            const dataSet: any = requestBody;
            const formDataConfig = this.extractFormDataConfig(dataSet.formFields);
            const dataInsert = this.buildDataInsert(dataSet, formDataConfig, request);

            const dataSaveResponse = await this.formBuilderService.saveCustomForms(dataInsert);

            if(dataInsert?.isEnableExcelUpload) {
               const isFileCreated = await this.createUpdateExcelTemplate(dataInsert,dataSaveResponse.id, '');
            }

            await FormBuilderHelper.formBuilderRepo(request.userDetails.client_id, dataSaveResponse.referenceId);
            await FormBuilderHelper.formBuilderHistoryRepo(request.userDetails.client_id, dataSaveResponse.referenceId);

            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({ data: dataSaveResponse, message: txt.FORM_SAVED_SUCCESS });
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }

    @Security('bearerAuth')
    @Patch('form')
    @Middlewares(commonMiddleware)
    async updateFormBuilder(
        @Body() requestBody: EditCustomFormRequest,
        @Request() request: any
    ): Promise<string | unknown> {
        try {
            let updateDataSet: any = requestBody;
            const formDataConfig: any[] = [];
            Object.keys(updateDataSet.formFields).forEach((d) => {
                if (d && updateDataSet.formFields[d].key &&
                    constants.formIoIgnoreFields.indexOf(updateDataSet.formFields[d].key) === -1
                ) {
                    formDataConfig.push({
                        label: updateDataSet.formFields[d].label,
                        key: updateDataSet.formFields[d].key,
                        type: updateDataSet.formFields[d].type,
                        showOnGrid: updateDataSet.formFields[d].showongrid,
                    });
                }
            });

            const dataInsert = {
                clientId: request.userDetails.client_id,
                docId: updateDataSet.formGroupId,
                formName: updateDataSet.name,
                formDescription: updateDataSet.description,
                isTimerBased: updateDataSet.isTimerBased ? 1 : 0,
                isShowDashboard: updateDataSet.formShowDashboard ? 1 : 0,
                formData: JSON.stringify(updateDataSet.data),
                isVersionControl: updateDataSet.isVersionBased ? 1 : 0,
                isCommanable: updateDataSet.isCommunicationBased ? 1 : 0,
                isAssignment: updateDataSet.isAssignment ? 1 : 0,
                assignedUser: updateDataSet.selectedRole,
                isApproval: updateDataSet.isApproval ? 1 : 0,
                approvalData: JSON.stringify(updateDataSet.approvals),
                approvalSetting: JSON.stringify(updateDataSet.approvalsetting),
                formControls: updateDataSet.form_controls ? JSON.stringify(updateDataSet.form_controls) : '',
                formDataConfig: JSON.stringify(formDataConfig),
                createdBy: request.userDetails.id,
                isEnableExcelUpload: updateDataSet.isEnableExcelUpload ? 1 : 0,
            } as unknown as CustomForms;

            const message = txt.FORM_UPDATED_SUCCESS;
            const dataSaveResponse = await this.formBuilderService
                .updateCustomForms({ id: request.body.id }, dataInsert)
            if(dataInsert?.isEnableExcelUpload) {
                const isFileUpdated = await this.createUpdateExcelTemplate(dataInsert,request.body.id, '');
            }
            return CommonHelper.apiSwaggerSuccessResponse({ data: dataSaveResponse, message });

        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    // // Unknown API
    @Security('bearerAuth')
    @Post('form/send')
    @Middlewares(commonMiddleware)
    async sentForm(
        @Request() request: any
    ): Promise<any> {
        try {
            const currentDate = new Date().valueOf().toString();

            let origin = await FormBuilderHelper.setOrigin(request.headers.origin, false);
            let requestDataSet: any[] = [];
            let toEmail: any[] = [];

            switch (request.body.type) {
                case "email":
                    let random = crypto.randomBytes(1).toString();
                    let urlPath = crypto
                        .createHash("sha256")
                        .update(currentDate + random)
                        .digest("hex");

                    let reqConfig: any = {
                        urlPath: urlPath,
                        request_config: {
                            type: request.body.type,
                            email: request.body.email,
                            name: "",
                            expTime: request.body.expTime,
                        },
                        params: {
                            clientId: request.userDetails.client_id,
                            urlPath: urlPath,
                            formId: request.body.formId,
                            requestConfig: {},
                            createdBy: request.userDetails.id,
                            formName: request.body.formName
                        },
                    };
                    const criteria: any = { email: request.body.email, clientId: request.userDetails.client_id };
                    const fields: any[] = ['id', 'username'];
                    const result = await this.formBuilderService.getUsers(criteria, fields);

                    if (result?.length > 0) {
                        reqConfig.request_config.name = result[0].username;
                        reqConfig.params.requestConfig = reqConfig.request_config;
                        reqConfig.params.requestConfig.id = result[0].id;
                    } else {
                        let emailArr = request.body.email.split("@");
                        if (emailArr?.length) {
                            reqConfig.request_config.name = emailArr[0];
                        }
                        reqConfig.params.requestConfig = reqConfig.request_config;
                    }
                    reqConfig.params.requestConfig = JSON.stringify(
                        reqConfig.params.requestConfig
                    );

                    requestDataSet.push(reqConfig);
                    break;
                case "user":
                    request.body.email.forEach((v: any, k: any) => {
                        toEmail.push(v.email);
                        let userRandom = crypto.randomBytes(1).toString();
                        let userUrlPath = crypto
                            .createHash("sha256")
                            .update(currentDate + userRandom)
                            .digest("hex");

                        requestDataSet.push({
                            urlPath: userUrlPath,
                            request_config: {
                                type: request.body.type,
                                email: v.email,
                                name: v.name,
                                expTime: request.body.expTime,
                            },
                            params: {
                                clientId: request.userDetails.client_id,
                                urlPath: userUrlPath,
                                formId: request.body.formId,
                                requestConfig: JSON.stringify({
                                    type: request.body.type,
                                    email: v.email,
                                    id: v.id,
                                    name: v.name,
                                    expTime: request.body.expTime,
                                }),
                                // userId: v.id,
                                createdBy: request.userDetails.id,
                                formName: request.body.formName
                            },
                        });
                    });
                    break;
            }

            if (requestDataSet?.length) {
                let type = "html";
                let key = `<div style='text-align:justify; text-justify: inter-word;line-height: 2'>Hi, <br/>A new form has been shared with you. <br/>Click on the link below to this form. <br/>@JobLink <br/><br/>Regards<br/>View360 Team</div>`;

                if (request.body.mailTempId) {
                    type = "id";
                    key = request.body.mailTempId;
                }

                for (let dataset of requestDataSet) {
                    let configData = {
                        JobLink: origin + "/request/form/" + dataset.urlPath,
                    };
                    await Container.get(DataSource).getRepository(RequestForm).save(dataset.params)

                    const mailTemplate = await this.communicationHelperService.htmlReplace(key, type, request.userDeatils, configData);
                        
                    const mailParams: any = {
                        subject: mailTemplate.subject ?? 'View360 Form Request',
                        html: mailTemplate.htmlString,
                        clientId: request.userDetails.client_id,
                        to: toEmail.join(",")
                    }

                    await this.communicationHelperService.nodeMailerService(mailParams);
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse({ data: {} });
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }

    }

    @Security('bearerAuth')
    @Patch('form/mapped-user')
    @Middlewares(commonMiddleware)
    async updateFormMappedUser(
        @Body() requestBody: { formId: string, mappedUser: { [key: string]: any }[] },
    ): Promise<string | unknown> {
        try {

            await this.formBuilderService
                .updateCustomForms({ id: requestBody.formId }, { mappedUser: requestBody.mappedUser })

            return CommonHelper.apiSwaggerSuccessResponse({ message: txt.FORM_UPDATED_SUCCESS })
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Delete('form')
    @Middlewares(commonMiddleware)
    async deleteFormBuilder(
        @Body() requestBody: { formId: string[] },
        @Request() request: any,
    ): Promise<{ message: string } | unknown> {
        try {
            const listOfFormIds = In(requestBody.formId);
            const clientId = request.userDetails.client_id;
            const formVaules = [];

            // Getting Reference Id for Each formId
            for (let i in request.body.formId) {
                const referenceId = await this.getReferenceId(request.userDetails.client_id, request.body.formId[i]);
                formVaules.push({ formId: request.body.formId[i], referenceId: referenceId });
            }

            const delResult = await this.formBuilderService.deleteCustomForms({ id: listOfFormIds, clientId });

            if (delResult.affected) {
                // Added by Pranav to Delete Records from Form Builder Dynamic Table
                for (let i in formVaules) {
                    await this.formBuilderService.deleteFormBuilder(clientId, formVaules[i].referenceId, { formId: formVaules[i].formId })
                    await this.formBuilderService.deleteFormBuilderHistory(clientId, formVaules[i].referenceId, { formId: formVaules[i].formId })
                }

                // await this.formBuilderService.deleteFormBuilder(clientId, { formId: listOfFormIds })
                // await this.formBuilderService.deleteFormBuilderHistory(clientId, { formId: listOfFormIds })

                return CommonHelper.apiSwaggerSuccessResponse({ message: txt.FORM_DELETED_SUCCESS })
            }
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('forms')
    @Middlewares(commonMiddleware)
    async getCustomFormList(
        @Request() request: any,
        @Query('page') page: number = 1,
        @Query('pageSize') pageSize: number = 10,
        @Query('sortOrder') sortOrder?: number,
        @Query('sortField') sortField?: string,
        @Query('filters') filters?: string
    ): Promise<GetCustomFormListResponse | unknown> {
        try {
            let whereCondition = { clientId: request.userDetails.client_id, docId: request.body.id };
            const fieldsToBeSelected = ['id', 'docId', 'formName', 'formDescription', 'formData', 'mappedUser', 'createdBy', 'referenceId','formControls'];
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            }; 

            whereCondition = await CommonUtil.applyFilter(filters, whereCondition);

            const sortObject: any = {createdOn: sortOrder};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            }

            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(CustomForms),
                {
                    where: whereCondition,
                }
            );
         
            const results = await this.formBuilderService.getCustomForms(whereCondition,
                fieldsToBeSelected,
                pageSize,
                (page - 1) * pageSize,
                sortObject);

            if (results.length && !lodash.isEmpty(results)) {
                apiResponse.recordsTotal = apiResponse.recordsFiltered = totalRecordCount;
                apiResponse.data = results.map(row => {
                    const dataSet: any = { ...row, mappedUser: JSON.parse(row.mappedUser || '[]') };
                    const userPermission = dataSet.mappedUser || [];

                    dataSet.permission = request.userDetails.is_superadmin === 1 ? {
                        viewForm: true, editForm: true, manageUserForm: true, deleteForm: true,
                        formShare: true, formEmbed: true, formsEntryCreate: true, formsEntryList: true
                    } : (userPermission.find(u => u.userID === request.userDetails.id) || { permission: [] }).permission.reduce((acc, p, i) => ({ ...acc, [this.getPermissionName(i)]: p === "1" }), null);

                    return dataSet.permission === null || dataSet.permission.viewForm ? dataSet : null;
                }).filter(Boolean);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (err) {
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: (err as Error).message } });
        }
    }

    @Security('bearerAuth')
    @Get('form/:id')
    @Middlewares(commonMiddleware)
    async getCustomForm(
        @Path() id: string,
        @Request() request: any
    ): Promise<{ data: GetCustomFormResponse } | unknown> {
        try {
            const apiResponse = { data: null };

            const fields = ["id", "docId", "formName", "formDescription", "isShowDashboard", "isTimerBased", "isVersionControl", "isCommanable", "isAssignment", "isApproval", "formControls", "statusBoxes", "approvalData", "approvalSetting", "assignedUser", "formData", "formDataConfig", "permissionConfig", "referenceId", "isEnableExcelUpload"];
            const whereCondition = { id, clientId: request.userDetails.client_id };
            const results = await this.formBuilderService.getCustomForms(whereCondition, fields);

            if (results && results.length) {
                const result = results[0];

                const mapperResults = await dataSource
                    .getRepository(FormMapper)
                    .find({
                        where: {
                            formId: request.params.id,
                            clientId: request.userDetails.client_id,
                        },
                    });

                const excelMapperDetails = mapperResults.find(m => m.type === 'excel') || null;
                const pdfMapperDetails = mapperResults.find(m => m.type === 'pdf') || null;

                apiResponse.data = {
                    ...result,
                    isExcelMapperForm: !!excelMapperDetails,
                    excelMapperDetails: excelMapperDetails ? { id: excelMapperDetails.id, columnHeader: excelMapperDetails.columnHeader } : null,
                    pdfMapperDetails: pdfMapperDetails ? { id: pdfMapperDetails.id, config: JSON.parse(pdfMapperDetails.config) } : null,
                    formData: this.tryParseJSON(result.formData),
                    formDataConfig: this.tryParseJSON(result.formDataConfig),
                    approvalData: this.tryParseJSON(result.approvalData),
                };
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('forms')
    @Middlewares(commonMiddleware)
    async getAllFormList(
        @Request() request: any
    ): Promise<any> {
        try {
            const apiResponse: any = {
                data: null
            };
            const fields: any[] = ["id", "docId", "formName", "formDescription", "formData", "formDataConfig"];

            const resultData: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: request.userDetails.client_id }, fields);

            if (resultData && resultData.length > 0) {
                apiResponse.data = resultData;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);

        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get('forms-list')
    @Middlewares(commonMiddleware)
    async getAllTokenFormList(
        @Request() request: any
    ): Promise<any> {
        try {
            let origin: any = await CommonUtil.getOriginUrl(request.headers.origin);
            const clientDetails = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MdbClient),
                {
                    where: [
                        { websiteUrl: origin },
                        { pwaUrl: origin },
                    ]
                }
            );
            if (!clientDetails?.length || !clientDetails[0]?.id) {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: 'Bad Request: Client is Required!!' } });
            }
            
            const apiResponse: any = {
                data: null
            };
            const fields: any[] = ["id", "docId", "formName", "formDescription", "formData", "formDataConfig"];

            const resultData: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: clientDetails[0].id }, fields);

            if (resultData && resultData.length > 0) {
                apiResponse.data = resultData;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);

        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('forms/dashboard/:formId')
    @Middlewares(commonMiddleware)
    async customFormsDashboard(
        @Request() request: any,
        @Path() formId: string
    ): Promise<any> {
        try {
            const apiResponse: any = {
                data: null
            };
            const fields: any[] = ["id", "docId", "formName", "mappedUser", "createdOn", "formDataConfig", "createdBy"];

            const resultData: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: request.userDetails.client_id, id: formId }, fields);

            if (resultData && resultData.length > 0) {
                apiResponse.data = resultData[0];

                if (apiResponse.data['formDataConfig']) {
                    apiResponse.data['formDataConfig'] = JSON.parse(apiResponse.data['formDataConfig']);
                } else {
                    apiResponse.data['formDataConfig'] = [];
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);

        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }

    async getReferenceId(clientId: number, formId: string): Promise<string> {
        const results: CustomForms[] = await this.formBuilderService
            .getCustomForms({ clientId: clientId, id: formId }, ["referenceId"]);
        return results[0].referenceId;
    }

    @Get('forms/self-registration/:client_id/:form_id')
    /**
        * Get Custom Form
        */
    @Middlewares(commonMiddleware)
    async getSelfRegistrationCustomForm(
        @Request() request: any,
    ): Promise<any> {
        try {
            const apiResponse = {
                data: null,
            };

            const fields: any[] = ["id", "docId", "formName", "formDescription", "isShowDashboard",
                "isTimerBased", "isVersionControl", "isCommanable", "isAssignment", "isApproval", "formControls", "statusBoxes",
                "approvalData", "approvalSetting", "assignedUser", "formData", "formDataConfig", "permissionConfig"
            ];
            const whereCondition: any = { id: request.params.form_id, clientId: request.params.client_id }
            const results: CustomForms[] = await this.formBuilderService.getCustomForms(whereCondition, fields);


            if (results && results.length) {
                apiResponse.data = results[0];
                try {
                    apiResponse.data.formData = JSON.parse(apiResponse.data.formData);
                } catch (error) {
                    apiResponse.data.formData = [];
                }
                try {
                    apiResponse.data.formDataConfig = JSON.parse(apiResponse.data.formDataConfig);
                } catch (error) {
                    apiResponse.data.formDataConfig = [];
                }
                try {
                    apiResponse.data.approvalData = JSON.parse(apiResponse.data.approvalData);
                } catch (error) {
                    apiResponse.data.approvalData = [];
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }

    @Security('bearerAuth')
    @Get('forms/documents')
    @Middlewares(commonMiddleware)
    async getDocumentWithFormList(
        @Request() request: any,
        @Query('rbav') rbav?: string
    ): Promise<any> {
        try {

            let whereCondition: any = {
                status: 2, clientId: request.userDetails.client_id
            };
            if (rbav === UserType.OWNER) {
                whereCondition.createdBy = request.userDetails.id;
            }
            const fields = ["id", "name", "mappedUser", "docs"];
            const results: any[] = await this.documentService.getFormGroupWithRelations(whereCondition, fields, ["docs"]);

            if (results.length) {

                const mapDocList = (i => ({ ...i, formId: i.id }));

                const data = results.map(d => {
                    return { docId: d.id, docName: d.name, formList: d.docs.map(mapDocList) }
                });
                const updatedData = CommonHelper.transformToSnakeCase(data);
                await cacheResponseData(request.originalUrl, { data: updatedData });
                return CommonHelper.apiSwaggerSuccessResponse({ data: updatedData });

            } else {
                return CommonHelper.apiSwaggerSuccessResponse({ data: [] });
            }

        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    private extractFormDataConfig(formFields: any): any[] {
        const formDataConfig: any[] = [];
        Object.keys(formFields).forEach((d) => {
            if (d && formFields[d].key && constants.formIoIgnoreFields.indexOf(formFields[d].key) === -1) {
                formDataConfig.push({
                    label: formFields[d].label,
                    key: formFields[d].key,
                    type: formFields[d].type,
                    showOnGrid: formFields[d].showongrid,
                });
            }
        });
        return formDataConfig;
    }

    private buildDataInsert(dataSet: any, formDataConfig: any, request: any): CustomForms {
        return {
            clientId: request.userDetails.client_id,
            docId: dataSet.formGroupId,
            formName: dataSet.name,
            formDescription: dataSet?.description || '',
            isTimerBased: dataSet?.isTimerBased || 0,
            isShowDashboard: dataSet?.showDashboard || 0,
            formData: JSON.stringify(dataSet.data),
            isVersionControl: dataSet.isVersionControl ? 1 : 0,
            isCommanable: dataSet.isCommEnabled ? 1 : 0,
            isAssignment: dataSet.isAssignment ? 1 : 0,
            isEnableExcelUpload: dataSet.isEnableExcelUpload ? 1 : 0,
            assignedUser: dataSet.selectedRole,
            isApproval: dataSet.isApproval ? 1 : 0,
            approvalData: JSON.stringify(dataSet.approvals),
            approvalSetting: dataSet.approvalsetting ? JSON.stringify(dataSet.approvalsetting) : '',
            formDataConfig: JSON.stringify(formDataConfig),
            createdBy: request.userDetails.id,
            formControls: dataSet.form_controls ? JSON.stringify(dataSet.form_controls) : '',
            statusBoxes: dataSet.statusBoxes ? JSON.stringify(dataSet.statusBoxes) : '',
            permissionConfig: dataSet.permissionConfig ? JSON.stringify(dataSet.permissionConfig) : '',
            mappedUser: dataSet.mappedUser ? JSON.stringify(dataSet.mappedUser) : '',
            formType: dataSet.formType ? JSON.stringify(dataSet.formType) : '',
            referenceId: crypto.randomBytes(4).toString('hex').toUpperCase(),
        } as unknown as CustomForms;
    }

    private getPermissionName(index: number): string {
        return [
            'viewForm', 'editForm', 'manageUserForm', 'deleteForm',
            'formShare', 'formEmbed', 'formsEntryCreate', 'formsEntryList'
        ][index];
    }

    private tryParseJSON(data: string): any {
        try {
            return JSON.parse(data);
        } catch (error) {
            return [];
        }
    }

    async createUpdateExcelTemplate(data, formID, tableName) {
        try{
            let excelHeaders;
            if(!tableName) {
                excelHeaders = await this.collectFields(data);
            } else if (tableName) {
                excelHeaders = await this.tableCollectFields(data);
            }
            const fileName = formID ? formID : tableName + '_Template';
            const xlsxParserUploadDir = "./public/form-builder-xls-template/";
            if (!fs.existsSync(xlsxParserUploadDir)) {
                fs.mkdirSync(xlsxParserUploadDir);
            }
            const workbook = xlsx.utils.book_new();
            const worksheetData = [excelHeaders];
            const worksheet = xlsx.utils.aoa_to_sheet(worksheetData);
            xlsx.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
            xlsx.writeFile(workbook, xlsxParserUploadDir + fileName + '.xlsx');
            return true;
        } catch (e) {
            return false;
        }
    }

    async collectFields(data) {
        let filedList = [];
        const formDataList = JSON.parse(data.formDataConfig);
        formDataList.forEach((item) => {
            if(item.type !== 'button') {
                filedList.push(item.label);
            }
        });
        return filedList;
    }
    async tableCollectFields(fields) {
        const result: string[] = [];

        fields.forEach(field => {
            if (field.Field !== 'id') {
                result.push(field.Field);
            }
        });

        return result;
    }
}
