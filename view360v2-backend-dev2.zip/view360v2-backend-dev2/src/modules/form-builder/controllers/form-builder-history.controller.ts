import loadsh from 'lodash';
import { FormBuilderService } from '../services/form-builder.service';
import { DataSource } from 'typeorm';
import Container from 'typedi';
import { Users, CustomForms } from '../../../entities';
import dbService from '../../../services/db.service';
import { CommonHelper, ApiErrorResponse } from '../../../utils/helpers/common.helper';
import { Controller, Get, Path, Request, Route, Security, Tags } from 'tsoa';
import { FBHistoryResponse } from '../doc/form-builder-history-interface';

@Route('form-builder')
@Tags('Form Builder')
export class FormBuilderHistoryController extends Controller {
    private formBuilderService: FormBuilderService = new FormBuilderService()

    static throwError(errorMessage: string | null): void {
        throw Error(errorMessage)
    }

    @Security('bearerAuth')
    @Get('version-history/:formId/:entryId')
    async getVersionHistory(
        @Path() formId: string,
        @Path() entryId: string,
        @Request() request: any
    ): Promise<FBHistoryResponse | ApiErrorResponse> {
        try {
            const userDetails = request.userDetails;
            const payload = [{ formId: formId, entryId: entryId }]
            const orderBy = { createdOn: 'ASC' }

            const results: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: userDetails.client_id, id: formId }, ["referenceId"]);

            const fbHistoryResponse: any = await this.formBuilderService.getVersionHistory(userDetails.client_id,results[0].referenceId, payload, orderBy);

            for (const row of fbHistoryResponse) {
                row.submittedData = JSON.parse(row.submittedData);
                row.userInfo = await this.resolveUserId(row.createdBy);
            }

            if (loadsh.isEmpty(fbHistoryResponse)) {
                FormBuilderHistoryController.throwError('Unable to save entry in form');
            }

            let difference = [];
            if (fbHistoryResponse.length > 1) {
                for (let i = 0; i < fbHistoryResponse.length; i++) {
                    if (i + 1 < fbHistoryResponse.length) {
                        difference.push(
                            this.deepObjectCompare(
                                fbHistoryResponse[i].submittedData, 
                                fbHistoryResponse[i + 1].submittedData, 
                                fbHistoryResponse[i + 1].userInfo,
                                fbHistoryResponse[i + 1].createdOn
                            )
                        );
                    }
                }
            }
            
            return CommonHelper.apiSwaggerSuccessResponse({ data: difference });

        } catch (e) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (e as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    async resolveUserId(userId: string) {
        const selectedFields: any = [
            "firstName",
            "lastName",
            "username"
        ];
        const results = await dbService._findQueryService(Container.get(DataSource).getRepository(Users), {
            where: { id: userId },
            select: selectedFields,
        });

        if (results.length == 0) {
            return {
                firstName: '',
                lastName: '',
                username: ''
            };
        }

        return results[0];
    }
    
    deepObjectCompare(obj1, obj2, userInfo, createdOn) {
        for (let key in obj1) {
            if (typeof obj2[key] === 'undefined') {
                // Key exists in obj1 but not in obj2, indicating a deleted key.
                return { 
                    key, 
                    fieldName: loadsh.startCase(key),
                    status: 'Deleted', 
                    oldValue: obj1[key], 
                    newValue: undefined,
                    submittedData: obj2,
                    createdOn: createdOn,
                    createdBy: userInfo.firstName + ' ' + userInfo.lastName
                };
            } else if (typeof obj1[key] === 'object' && typeof obj2[key] === 'object') {
                // Recursively compare nested objects.
                const nestedDiffs = [];
                const result = this.deepObjectCompare(obj1[key], obj2[key], userInfo, createdOn);
                if (result) {
                    nestedDiffs.push(result);
                }

                if (nestedDiffs.length > 0) {
                    return {...nestedDiffs};
                }
            } else if (obj1[key] !== obj2[key]) {
                // Values are different for the same key.
                return { 
                    key, 
                    fieldName: loadsh.startCase(key),
                    status: 'Updated', 
                    oldValue: obj1[key], 
                    newValue: obj2[key],
                    submittedData: obj2,
                    createdOn: createdOn,
                    createdBy: userInfo.firstName + ' ' + userInfo.lastName 
                };
            }
        }
    
        for (let key in obj2) {
            if (typeof obj1[key] === 'undefined') {
                // Key exists in obj2 but not in obj1, indicating a new key.
                return { 
                    key, 
                    fieldName: loadsh.startCase(key),
                    status: 'Added', 
                    oldValue: undefined, 
                    newValue: obj2[key],
                    submittedData: obj2,
                    createdOn: createdOn,
                    createdBy: userInfo.firstName + ' ' + userInfo.lastName
                };
            }
        }    
    }
}
