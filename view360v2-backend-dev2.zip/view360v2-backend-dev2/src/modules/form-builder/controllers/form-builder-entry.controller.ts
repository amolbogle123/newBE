import * as bcrypt from "bcryptjs";
import lodash from "lodash";
import { Body, Controller, Delete, Get, Patch, Path, Post, Query, Request, Route, Security, Tags } from "tsoa";
import Container from 'typedi';
import dbService from "../../../services/db.service";
import { DataSource, In, UpdateResult } from "typeorm";
import { BusinessProcessModelingExecute, CustomForms, FormBuilderTimeLog, FormMapper, MdbClient, Users } from "../../../entities";
import { FormBuilder } from "../../../entities/create-form-builder";
import { UserType } from "../../../models/enums";
import { ApiErrorResponse, CommonHelper } from "../../../utils/helpers/common.helper";
import { ProcessBuilderHelper } from "../../process-builder-v2/utils/helpers/process-builder.helper";
import { ProcessStatus } from "../../process-builder/models";
import { UserService } from "../../user/services/user.service";
import { SubmitCustomFormRequest, UpdateCustomFormRequest } from "../doc/formBuilderEntry-interface";
import { FormBuilderService } from "../services/form-builder.service";
import { FormBuilderEntryService } from "../services/form-builder-entry.service";
import { formBuilderTableName } from "../utils/constants/config.constant";
import { CommonUtil } from "utils/common.util";

@Route('form-builder')
@Tags('Form Builder')
export class FormBuilderEntryController extends Controller {
    private formBuilderService: FormBuilderService = new FormBuilderService();
    private formBuilderEntryService: FormBuilderEntryService = new FormBuilderEntryService();
    private processBuilderHelper: ProcessBuilderHelper = new ProcessBuilderHelper();
    private userService: UserService = new UserService();

    static throwError(errorMessage: string | null): void {
        throw Error(errorMessage)
    }

    @Security('bearerAuth')
    @Get('form/dynamic/:id')
    async entryList(
        @Path() id: string,
        @Query() rbav: string,
        @Request() request: any
    ): Promise<unknown> {
        try {
            const reqData = request.userDetails;

            if (!reqData || !reqData.client_id || !id) {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: 'Bad Request: Client Or Doc is Required!!' } });
            }

            const apiResponse: any = {
                data: {
                    formData: [],
                    formDataConfig: [],
                    name: { formName: '' }
                },
                recordsFiltered: 0,
                recordsTotal: 0
            };

            const results = await this.formBuilderService.getCustomForms(
                { clientId: reqData.client_id, id },
                ['formName', 'formDataConfig', 'referenceId']
            );

            if (!results || results.length === 0) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            const customForm = results[0];
            apiResponse.data.name.formName = customForm.formName;

            try {
                customForm.formDataConfig = JSON.parse(customForm.formDataConfig);
            } catch (e) { }

            apiResponse.data.formDataConfig = customForm.formDataConfig;

            const whereClause: any = { formId: id };

            if (rbav === UserType.OWNER) {
                whereClause.createdBy = reqData.id;
            }

            const fields = ['id', 'submittedData', 'createdBy', 'createdOn'];
            const orderBy = { createdOn: 'DESC' };

            const formDataResp = await this.formBuilderService.getFormBuilderList(
                reqData.client_id,
                customForm.referenceId,
                whereClause,
                fields,
                orderBy
            );

            if (formDataResp && formDataResp.length > 0) {
                apiResponse.recordsTotal = formDataResp.length;
                apiResponse.recordsFiltered = formDataResp.length;

                apiResponse.data.formData = formDataResp.map(rows => {
                    const dataSet: any = { id: rows.id, createdBy: rows.createdBy };
                    try {
                        dataSet.submittedData = JSON.parse(rows.submittedData);
                    } catch (error) {
                        dataSet.submittedData = [];
                    }
                    return dataSet;
                });

                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get('form/get-entries/:formId')
    async getFormEntries(
        @Path() formId: string,
        @Request() request: any
    ): Promise<unknown> {
        try {
            const finalResponse = [];
            const tableName = `form_builder_${request.userDetails.client_id}`;
            const whereClause = ` WHERE FORM_ID = '${formId}'`;
            const query = `SELECT id, FORM_ID AS formId, SUBMITTED_DATA AS submittedData, CREATED_BY AS createdBy, CREATED_ON AS createdOn, 
                BEING_FILLED_BY AS beingFilledBy FROM ${tableName}` + whereClause;
            const results = await Container.get(DataSource).manager.query(query);

            if (results?.length) {
                for (let entry of results) {
                    if (entry.submittedData) {
                        try {
                            entry.submittedData = JSON.parse(entry.submittedData);
                        } catch (error) {
                            console.error('Error parsing SUBMITTED_DATA:', error);
                            entry.SUBMITTED_DATA = {};
                        }
            
                        // Merge SUBMITTED_DATA into the parent object and exclude it from the final response
                        const { submittedData, ...rest } = entry;
                        finalResponse.push({ ...rest, ...submittedData });
                    }
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse({ data: finalResponse });
        } catch (e) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (e as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }

    @Security('bearerAuth')
    @Post('form/dynamic-all/:id')
    async entryAllList(
        @Path() id: string,
        @Request() request: any,
        @Query('page') page: number = 1,
        @Query('pageSize') pageSize: number = 10,
        @Query('sortOrder') sortOrder?: number,
        @Query('sortField') sortField?: string,
        @Query('filters') filters?: string,
        @Query('search') search?: string,
    ): Promise<unknown> {
        try {
            const Id = request.body.Id;
            const reqData = request.userDetails;

            if (!reqData?.client_id || !Id) {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: 'Bad Request: Client Or Doc is Required!!' } });
            }

            const apiResponse: any = {
                data: {
                    formData: [],
                    formDataConfig: [],
                    name: { formName: '' }
                },
                recordsFiltered: 0,
                recordsTotal: 0
            };

            const results = await this.formBuilderService.getCustomForms(
                { clientId: reqData.client_id, id: Id },
                ['formName', 'formDataConfig', 'referenceId']
            );

            if (!results?.length) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            const customForm = results[0];
            apiResponse.data.name.formName = customForm.formName;

            try {
                customForm.formDataConfig = JSON.parse(customForm.formDataConfig);
            } catch (e) { }

            apiResponse.data.formDataConfig = customForm.formDataConfig;

            let field = '';
            let sortOrderVal;
            if (request.body?.eve?.sortField && request.body?.eve.sortOrder) {
                field = request.body?.eve.sortField;
                sortOrderVal = request.body.eve.sortOrder === 1 ? 'ASC' : 'DESC';
            }
            const start = request.body?.eve?.first || 0;
            const limit = request.body?.eve?.rows || 10;
            let offsetLimit = ` LIMIT ${start},${limit}`;
            const order = ` ORDER BY CREATED_ON DESC`;
            let whereCondition = ` WHERE FORM_ID = '${Id}' `;
            if (search && apiResponse?.data?.formDataConfig) {
                search = search.toLocaleLowerCase();
                let searcWhere = [];
                for (let s of apiResponse.data.formDataConfig) {
                    if (s?.showOnGrid && s?.key) {
                        searcWhere.push(` LOWER(SUBMITTED_DATA->"$.${s.key}") LIKE '%${search}%'`);
                    }
                }
                whereCondition += ` AND (${searcWhere.join(' OR ')})`;
            }
            
            if (request.body?.eve?.filters && Object.keys(request.body?.eve?.filters).length > 0) {
                const filterString = JSON.stringify(request.body?.eve?.filters);
                const filter = await CommonUtil.applyFilterToForms(filterString, '');
                if (filter && filter !== '') {
                    whereCondition += ` AND ${filter}`;
                }
            }
            
            // const whereCondition = ` WHERE FORM_ID = '${Id}' `
            const tableName = `form_builder_${request.userDetails.client_id}`;
            let query = `SELECT id, SUBMITTED_DATA AS submittedData, CREATED_BY AS createdBy, CREATED_ON AS createdOn FROM ${tableName}` + whereCondition;
            let updateQueryForTotalRecordCounts = `SELECT t.*,(SELECT COUNT(*) FROM form_builder_1 ` + whereCondition + `) AS recordsTotal FROM (${query + order + offsetLimit})t`;

            let formDataResp: any = await Container.get(DataSource).manager.query(updateQueryForTotalRecordCounts);
            await this.formatFormData(apiResponse, formDataResp, request, field, sortOrderVal);

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    // @Security('bearerAuth')
    @Get('form/dynamic-all-entry/:id')
    async allEntryList(
        @Path() id: string,
        @Request() request: any
    ): Promise<unknown> {
        try {
            let origin: any = await CommonUtil.getOriginUrl(request.headers.origin);
            const clientDetails = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MdbClient),
                {
                    where: [
                        { websiteUrl:origin },
                        { pwaUrl:origin },
                    ]
                }
            );
            if (!clientDetails?.length || !clientDetails[0]?.id) {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: 'Bad Request: Client is Required!!' } });
            }

            const apiResponse: any = {
                data: [],
            };

            const order = ` ORDER BY CREATED_ON DESC`;
            let whereCondition = ` WHERE FORM_ID = '${id}' `;
            const tableName = `form_builder_${clientDetails[0].id}`;
            let query = `SELECT id, SUBMITTED_DATA AS submittedData FROM ${tableName}` + whereCondition + order;

            let formDataResp: any = await Container.get(DataSource).manager.query(query);
            if (formDataResp?.length) {
                for (let entry of formDataResp) {
                    try {
                        let submitData = JSON.parse(entry.submittedData);
                        submitData.entryId = entry.id;
                        apiResponse.data.push(submitData);
                    } catch (error) {}
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    async formatFormData(apiResponse, formDataResp, request, field, sortOrderVal) {
        return new Promise(async (resolve) => {
            if (formDataResp?.length > 0) {
                apiResponse.recordsTotal = formDataResp[0].recordsTotal;
                apiResponse.recordsFiltered = formDataResp[0].recordsTotal;
                if (request.body?.eve?.sortField && request.body?.eve?.sortOrder) {
                    formDataResp = await this.sortBySubmittedData(formDataResp, field, sortOrderVal);
                }
                apiResponse.data.formData = formDataResp.map(row => {
                    const fData: any = { id: row.id, createdBy: row.createdBy };
                    try {
                        fData.submittedData = JSON.parse(row.submittedData);
                    } catch (error) {
                        fData.submittedData = [];
                    }
                    return fData;
                });
            }

            resolve(true);
        });
    }

    async sortBySubmittedData(data, field, order) {
        try {
            return data.sort((a, b) => {
                const valueA = JSON.parse(a.submittedData)[field];
                const valueB = JSON.parse(b.submittedData)[field];

                return this.sortingMethod(order, valueA, valueB);
            });
        } catch (e) {
            console.error('Error :: ' + e);
        }
    }

    sortingMethod(order, valueA, valueB) {
        if (order === 'ASC') {
            if (valueA < valueB) return -1;
            if (valueA > valueB) return 1;
            return 0;
        } else if (order === 'DESC') {
            if (valueA < valueB) return 1;
            if (valueA > valueB) return -1;
            return 0;
        }
    }

    @Security('bearerAuth')
    @Get('form/dynamic/:formId/:id')
    async entryDetails(
        @Path() formId: string,
        @Path() id: string,
        @Request() request: any
    ): Promise<unknown> {
        try {
            const apiResponse: any = {
                status: 'error',
                data: { bpmn: [], submittedData: [] },
            }

            const results: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: request.userDetails.client_id, id: request.params.formId }, ["referenceId"]);

            const whereClause: any = { id: id, formId: formId }

            const formBuilderRes: FormBuilder = await this.formBuilderService
                .getFormBuilder(request.userDetails.client_id, results[0].referenceId, whereClause, ['id', 'submittedData']);

            if (!lodash.isEmpty(formBuilderRes)) {
                apiResponse.status = 'success';
                const criteria = { entryId: id, formId: formId };

                const bpmnExecData: BusinessProcessModelingExecute[] =
                    await this.formBuilderService.bpmnExecDetails(criteria, [], { id: 'desc' }, ["bpmn"]);
                if (bpmnExecData && bpmnExecData.length > 0) {
                    apiResponse.data.bpmn = bpmnExecData;
                }
                try {
                    apiResponse.data.submittedData = JSON.parse(formBuilderRes.submittedData);
                } catch (e) { }

                return CommonHelper.apiSwaggerSuccessResponse({ data: apiResponse.data });
            }
            return CommonHelper.apiSwaggerSuccessResponse({ data: apiResponse.data });
        } catch (e) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (e as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('form/dynamic')
    async insertEntryForm(
        @Body() requestBody: SubmitCustomFormRequest,
        @Request() request: any
    ): Promise<unknown> {
        const apiResponse: any = {
            data: {},
        };
        try {
            const createdBy = request.userDetails.id;
            const clientId = request.userDetails.client_id;
            const formEntries: any[] = [];
            const formHistoryEntries: any[] = [];

            formEntries.push({
                formId: requestBody.formId,
                submittedData: JSON.stringify(requestBody.data),
                beingFilledBy: createdBy,
                createdBy
            });

            formHistoryEntries.push({
                formId: requestBody.formId,
                entryId: "",
                submittedData: JSON.stringify(requestBody.data),
                beingFilledBy: createdBy,
                username: request.userDetails.username,
                createdBy
            });

            for (const data of requestBody.additionalData || []) {
                formEntries.push({
                    formId: requestBody.formId,
                    submittedData: JSON.stringify(data),
                    beingFilledBy: createdBy,
                    createdBy
                });

                formHistoryEntries.push({
                    formId: requestBody.formId,
                    entryId: "",
                    submittedData: JSON.stringify(data),
                    beingFilledBy: createdBy,
                    username: request.userDetails.username,
                    createdBy
                });
            }

            const [savedEntries, savedHistoryEntries] = await Promise.all([
                this.formBuilderService.fbInsertEntry(clientId, formEntries, request.body.referenceId),
                this.formBuilderService.fbHistoryInsertEntry(clientId, formHistoryEntries, request.body.referenceId)
            ]);

            // Update formHistoryEntries with the newly created IDs
            for (let i = 0; i < savedEntries.length; i++) {
                savedHistoryEntries[i].entryId = savedEntries[i].id;
            }

            // Now save the updated formHistoryEntries to the database
            this.formBuilderService.fbUpdateHistoryEntries(clientId, savedHistoryEntries, request.body.referenceId);
            if (requestBody.isTimerBased) {
                const timeLogs = savedEntries.map(entry => ({
                    formId: requestBody.formId,
                    entryId: entry.id,
                    clientId,
                    type: "Insert Entry",
                    beingFilledBy: createdBy,
                    submissionTime: requestBody.time,
                    createdBy,
                }));

                await Container.get(DataSource).getRepository(FormBuilderTimeLog).save(timeLogs);
            }

            for (const entry of savedEntries) {
                // ***** BPMN EXECUTION *****
                this.processBuilderHelper.execute(
                    clientId, requestBody.formId, entry.id, request.body.referenceId, null, null, { type: ProcessStatus.FORM_SUBMIT }
                );
            }
            
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({ data: apiResponse.data });

        } catch (e) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (e as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }

    }

    private async saveFormEntry(clientId: any, dataPayload: { formId: string; submittedData: string; beingFilledBy: any; username: any; createdBy: any; }, request: any, apiResponse: any, requestBody: SubmitCustomFormRequest, createdBy: any) {
        const fbEntryResponse: FormBuilder = await this.formBuilderService.fbInsertEntry(clientId, dataPayload, request.body.referenceId);

        if (lodash.isEmpty(fbEntryResponse)) {
            FormBuilderEntryController.throwError('Unable to save entry in form');
        }
        apiResponse.data = fbEntryResponse;

        const historyDataPayload = {
            formId: requestBody.formId,
            entryId: fbEntryResponse.id,
            submittedData: JSON.stringify(requestBody.data),
            beingFilledBy: createdBy,
            username: request.userDetails.username,
            createdBy
        };
        await this.formBuilderService.fbHistoryInsertEntry(clientId, historyDataPayload, request.body.referenceId);

        if (requestBody.isTimerBased) {
            const insertTimeLog = {
                formId: requestBody.formId,
                entryId: fbEntryResponse.id,
                clientId,
                type: "Insert Entry",
                beingFilledBy: createdBy,
                submissionTime: requestBody.time,
                createdBy
            };
            await Container.get(DataSource).getRepository(FormBuilderTimeLog).save(insertTimeLog);
        }

        // ***** BPMN EXECUTION *****
        await this.processBuilderHelper.execute(
            clientId, request.body.formId, fbEntryResponse.id, request.body.referenceId, null, null, { type: ProcessStatus.FORM_SUBMIT }
        );
    }

    @Security('bearerAuth')
    @Patch('form/dynamic')
    async updateEntryForm(
        @Body() requestBody: UpdateCustomFormRequest,
        @Request() request: any
    ): Promise<unknown> {
        try {
            const createdBy = request.userDetails.id;
            const clientId = request.userDetails.client_id;

            const dataPayload = {
                submittedData: JSON.stringify(requestBody.data),
            };
            const whereClause: any = { id: requestBody.submissionId }

            const results: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: request.userDetails.client_id, id: request.body.formId }, ["referenceId"]);

            const updateResponse: UpdateResult = await this.formBuilderService.updateFormBuilder(clientId, results[0].referenceId, whereClause, dataPayload);

            if (!lodash.isEmpty(updateResponse) && updateResponse.affected === 1) {

                const historyDataPayload = {
                    formId: requestBody.formId,
                    entryId: whereClause.id,
                    submittedData: JSON.stringify(requestBody.data),
                    createdBy,
                };
                await this.formBuilderService.fbHistoryInsertEntry(clientId, historyDataPayload, results[0].referenceId);

                if (requestBody.isTimerBased) {
                    const insertTimeLog = {
                        formId: requestBody.formId,
                        entryId: whereClause.id,
                        clientId,
                        type: "Update Entry",
                        createdBy,
                        submissionTime: requestBody.time,
                    };
                    await Container.get(DataSource).getRepository(FormBuilderTimeLog).save(insertTimeLog);
                }
                return CommonHelper.apiSwaggerSuccessResponse({ message: 'Form entry updated successfully' });
            }
            return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: 'Unable to update form entry, something went wrong!!' } });
        } catch (e) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (e as Error).message
                }
            }
            this.setStatus(500)
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }

    }

    @Security('bearerAuth')
    @Delete('form/dynamic')
    async deleteEntryForm(
        @Body() requestBody: { id: string[], formId: string },
        @Request() request: any
    ): Promise<unknown> {
        try {
            const clientId = request.userDetails.client_id;
            const formId = requestBody.formId;
            const entryIds = requestBody.id;
            const whereClause = {
                id: In(requestBody.id),
                formId: requestBody.formId
            };

            // const customForms = await this.formBuilderService.getCustomForms({ clientId, id: formId }, ["referenceId"]);
            // const customForm = customForms[0];

            // if (!customForm) {
            //     return FormBuilderEntryController.throwError('Form not found');
            // }

            const [deleteResponse] = await Promise.all([
                this.formBuilderService.deleteFormBuilder(clientId, "", whereClause)
            ]);


            if (lodash.isEmpty(deleteResponse) || deleteResponse.affected === 0) {
                return FormBuilderEntryController.throwError('Unable to delete form entry, something went wrong!!');
            }

            // 3. Delete associated FormBuilderHistory entries
            const whereCondition = {
                formId: formId,
                entryId: In(entryIds) // Use In for multiple entryIds
            };
            this.formBuilderService.deleteFormBuilderHistory(clientId, "", whereCondition);

            return CommonHelper.apiSwaggerSuccessResponse({ message: 'Form entry deleted successfully' });
        } catch (e) {
            // ... (error handling remains the same)
        }
    }

    // @Security('bearerAuth')
    // @Get('forms/dynamic')
    // async formReportEntryDataTableList(
    //     @Request() req: any,
    // ): Promise<any> {
    //     try {
    //         const response = {
    //             status: false,
    //             data: [],
    //             recordsTotal: 0,
    //             recordsFiltered: 0,
    //         };
    //         const tableName = formBuilderTableName + req.userDetails.client_id;
    //         let whereClause = [`FORM_ID = '${req.body.formId}'`];
    //         if (Array.isArray(req.body.columns) && req.body.columns.length) {
    //             req.body.columns = req.body.columns.map(obj => {
    //                 obj.data = `"SUBMITTED_DATA" ->> '${obj.data}'`;
    //                 return obj;
    //             });
    //         }
    //         if (req.body.whereCondition.startDate) {
    //             let startDate = moment(req.body.whereCondition.startDate).format('MM-DD-YYYY HH:mm:ss');
    //             whereClause.push(`"CREATEDON"::timestamp without time zone >= '${startDate}'::timestamp without time zone`);
    //         }

    //         if (req.body.whereCondition.endDate) {
    //             let endDate = moment(req.body.whereCondition.endDate).format('MM-DD-YYYY HH:mm:ss');
    //             whereClause.push(`"CREATEDON"::timestamp without time zone <= '${endDate}'::timestamp without time zone`);
    //         }
    //         if (Array.isArray(req.body.whereCondition.filter) && req.body.whereCondition.filter.length > 0) {
    //             for (const whereValue of req.body.whereCondition.filter) {
    //                 if (whereValue.field && whereValue.type && whereValue.operator) {
    //                     if (whereValue.type != 'datetime' && whereValue.value) {
    //                         whereClause.push(`AND LOWER(SUBMITTED_DATA -> '$.${whereValue.field}') LIKE LOWER('%${whereValue.value}%')`);
    //                     } else if (whereValue.type === 'datetime' && (whereValue.startDate || whereValue.endDate)) {
    //                         whereClause.push(`("SUBMITTED_DATA" ->> '${whereValue.field}') <> ''`);
    //                         if (whereValue.startDate) {
    //                             let startDate = moment(whereValue.startDate).format('MM-DD-YYYY HH:mm:ss');
    //                             whereClause.push(`("SUBMITTED_DATA" ->> '${whereValue.field}')::timestamp without time zone >= '${startDate}'::timestamp without time zone`);
    //                         }
    //                         if (whereValue.endDate) {
    //                             let endDate = moment(whereValue.endDate).format('MM-DD-YYYY HH:mm:ss');
    //                             whereClause.push(`("SUBMITTED_DATA" ->> '${whereValue.field}')::timestamp without time zone <= '${endDate}'::timestamp without time zone`);
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //         let query = `SELECT ${["ID", "FORM_ID", "SUBMITTED_DATA", "CREATED_ON"]} FROM ${tableName} WHERE ${whereClause.join(' ')}`;
    //         const results = await Container.get(DataSource).manager.query(query);
    //         if (results.length > 0) {
    //             response.status = true;
    //             response.data = results;
    //             response.recordsTotal = results.length;
    //             response.recordsFiltered = results.length;
    //         }
    //         return CommonHelper.apiSwaggerSuccessResponse({ data: response });
    //     } catch (e) {
    //         const apiErrorResponse: ApiErrorResponse = {
    //             error: {
    //                 error_description: (e as Error).message
    //             }
    //         }
    //         return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
    //     }
    // }

    // @Security('bearerAuth')
    // @Post('forms/dynamic/chart-data')
    // async getChartData(
    //     @Request() req: any,
    // ): Promise<any> {
    //     try {
    //         const response: any = { status: false, data: [] };
    //         const config = req.body.config;
    //         const tableName = formBuilderTableName + req.userDetails.client_id;
    //         const selectFields = [];
    //         const tableFields = ["ID", "CREATEDON", "RECORD_ID", "STATUS"];
    //         let xAxis = `SUBMITTED_DATA AS "${config.xAxis}"`;
    //         let groupBy = 'SUBMITTED_DATA'; //`'${config.xAxis}'`;
    //         if (config.xAxisType === 'datetime') {
    //             // xAxis = `CASE WHEN ("SUBMITTED_DATA" ->> '${config.xAxis}') IS NULL THEN '' ELSE ("SUBMITTED_DATA" ->> '${config.xAxis}') END AS "${config.xAxis}"`;
    //             xAxis = `CASE WHEN nullif("SUBMITTED_DATA"->>'${config.xAxis}', '') IS NULL THEN '' ELSE TO_CHAR(("SUBMITTED_DATA" ->> '${config.xAxis}')::date, 'MM-DD-YYYY') END AS "${config.xAxis}"`;
    //             groupBy = `CASE WHEN nullif("SUBMITTED_DATA"->>'${config.xAxis}', '') IS NULL THEN '' ELSE TO_CHAR(("SUBMITTED_DATA" ->> '${config.xAxis}')::date, 'MM-DD-YYYY') END`;
    //         }
    //         if (tableFields.indexOf(config.xAxis) > -1) {
    //             xAxis = `"${config.xAxis}"`
    //             groupBy = `"${config.xAxis}"`
    //         }
    //         selectFields.push(xAxis);
    //         if (tableFields.indexOf(config.yAxis) > -1) {
    //             selectFields.push(`COUNT(${config.yAxis}) AS "${config.yAxis}"`);
    //         } else {
    //             selectFields.push(`COUNT('${config.yAxis}') AS "${config.yAxis}"`);
    //         }
    //         let sqlStmt = `SELECT ${selectFields.join(',')} FROM ${tableName}`;
    //         let whereClause = [`FORM_ID = '${req.body.formId}'`];
    //         if (Array.isArray(req.body.whereCondition.filter) && req.body.whereCondition.filter.length > 0) {
    //             for (const whereValue of req.body.whereCondition.filter) {
    //                 if (whereValue.field && whereValue.type && whereValue.operator) {
    //                     if (whereValue.type != 'datetime' && whereValue.value) {
    //                         whereClause.push(`LOWER("SUBMITTED_DATA" ->> '${whereValue.field}') LIKE LOWER('%${whereValue.value}%')`);
    //                     } else if (whereValue.type === 'datetime' && (whereValue.startDate || whereValue.endDate)) {
    //                         whereClause.push(`("SUBMITTED_DATA" ->> '${whereValue.field}') <> ''`);
    //                         if (whereValue.startDate) {
    //                             let startDate = moment(whereValue.startDate).format('MM-DD-YYYY HH:mm:ss');
    //                             whereClause.push(`("SUBMITTED_DATA" ->> '${whereValue.field}')::timestamp without time zone >= '${startDate}'::timestamp without time zone`);
    //                         }
    //                         if (whereValue.endDate) {
    //                             let endDate = moment(whereValue.endDate).format('MM-DD-YYYY HH:mm:ss');
    //                             whereClause.push(`("SUBMITTED_DATA" ->> '${whereValue.field}')::timestamp without time zone <= '${endDate}'::timestamp without time zone`);
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //         sqlStmt += ` WHERE ${whereClause.join(" AND ")} GROUP BY ${groupBy}`;
    //         const result = await Container.get(DataSource).manager.query(sqlStmt);
    //         if (result && result.length > 0) {
    //             result.forEach((item) => {
    //                 if (item && item.divisionOfficeName) {
    //                     const obj = JSON.parse(item.divisionOfficeName);
    //                     item.divisionOfficeName = obj.divisionOfficeName;
    //                 } else {
    //                     const objKey = Object.keys(item);
    //                     const parseObj = JSON.parse(item[objKey[0]]);
    //                     item[objKey[0]] = parseObj[objKey[0]];
    //                 }
    //             });
    //             response.status = true;
    //             const queryFields = Object.keys(result[0]);
    //             response.xAxis = queryFields[0];
    //             queryFields.splice(0, 1);
    //             response.yAxis = queryFields;
    //             response.data = result;
    //         }
    //         return CommonHelper.apiSwaggerSuccessResponse( { data: response });
    //     } catch (e) {
    //         const apiErrorResponse: ApiErrorResponse = {
    //             error: {
    //                 error_description: (e as Error).message
    //             }
    //         }
    //         return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
    //     }
    // }

    @Security('bearerAuth')
    @Post('forms/dynamic/entries')
    async formEntries(
        @Request() request: any,

    ): Promise<any> {
        try {
            const tableName = formBuilderTableName + request.userDetails.client_id;
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };
            let whereClause = [`FORM_ID = '${request.body.formId}'`];

            if (Array.isArray(request.body.columns) && request.body.columns.length) {
                request.body.columns = request.body.columns.filter(obj => obj.data !== 'commentSection').map(obj => {
                    obj.data = `"SUBMITTED_DATA" ->> '${obj.data}'`;
                    return obj;
                });
            }

            let query = `SELECT ${["ID", "FORM_ID", "SUBMITTED_DATA", "CREATED_ON"]} FROM ${tableName.toLocaleLowerCase()} WHERE ${whereClause.join(' AND ')}`;
            const results = await Container.get(DataSource).manager.query(query);
            if (results?.length) {
                apiResponse.data = results;
                apiResponse.recordsTotal = results.length;
                apiResponse.recordsFiltered = results.length;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }

    /**
     * 
     * @Security('bearerAuth')
    @Post('form/dynamic/export')
    async exportFormReportEntryData(
        @Request() req: any,
    ): Promise<any> {
        try {
            let response = {
                status: false,
                file: '',
                fileName: ''
            };
            const tableName = formBuilderTableName + req.userDetails.client_id;
            let whereClause = [`FORM_ID = '${req.body.formId}'`];
            let query = `SELECT ${["ID", "FORM_ID", "SUBMITTED_DATA", "CREATED_ON"]} FROM ${tableName} WHERE ${whereClause} ORDER BY CREATED_ON DESC`;
            const results = await Container.get(DataSource).manager.query(query);
            if (req.body.type === "exported") {
                let excelData = [];
                if (req.body.reportTitle) {
                    excelData.push([
                        { v: `${req.body.reportTitle}`, s: { font: { bold: true } } }
                    ])
                }

                if (!req.body.reportTitle) {
                    // excelData.push([req.body.reportTitle]);
                    excelData.push([
                        { v: `AD HOC REPORT ${moment().format('MMMM DD, YYYY')}`, s: { font: { bold: true } } }
                    ])
                }

                if (req.body.searchTexts) {
                    excelData.push(
                        [`This report is created on ${req.body.reportTime}`]
                    )
                }

                // add blank row
                excelData.push([{ v: `` }]);


                // excelData.push(req.body.tableColumns.map(obj2 => obj2.label));
                excelData.push(
                    req.body.tableColumns.map((obj2) => {
                        return {
                            v: obj2.label,
                            s: { font: { bold: true } }
                        }
                    })
                );

                if (results && results.length > 0) {
                    response.status = true;
                    for (const resValue of results) {
                        let submittedDataResValue = JSON.parse(resValue.SUBMITTED_DATA);
                        let values = [];
                        for (const fieldKey of req.body.tableColumns) {
                            if (fieldKey.type == 'datetime') {
                                values.push(`${submittedDataResValue.SUBMITTED_DATA[fieldKey.data] ? moment(resValue.SUBMITTED_DATA[fieldKey.data]).format('MM-DD-YYYY') : ''}`);
                            } else {
                                values.push(`${submittedDataResValue[fieldKey.data] || ''}`);
                            }
                        }
                        excelData.push(values);
                    }
                }

                // add blank row
                if (req.body.reportTitle) {
                    excelData.push([
                        { v: `` }
                    ])
                }

                if (req.body.searchTexts) {
                    excelData.push(
                        [`${req.body.searchTexts}`]
                    )
                }
                // const sheetOptions = { '!cols': [{ wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 15 }, { wch: 40 }] };
                // var buffer = xlsx.build([{ name: 'Sheet 1', data: excelData }], sheetOptions); // Returns a buffer
                const wb = XLSX_STYLE.utils.book_new();
                const ws = XLSX_STYLE.utils.aoa_to_sheet(excelData);
                XLSX_STYLE.utils.book_append_sheet(wb, ws, "Sheet 1");
                // let fileName = `Ad hoc Report ${moment().format('MM-DD-YYYY')}.xlsx`;
                let fileName = `Ad_Hoc_Report-${moment().format('MMMM-DD-YYYY')}.xlsx`;
                const filePath = `./public/reports/${fileName}`;
                XLSX_STYLE.writeFile(wb, filePath);
                response.file = `${process.env.BASE_URL}/public/reports/${fileName}`;
                response.fileName = fileName;
                return CommonHelper.apiSwaggerSuccessResponse({ data: response });
            }
            return CommonHelper.apiSwaggerSuccessResponse({ data: response });
        } catch (e) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (e as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }
     */

    @Security('bearerAuth')
    @Post('form/dynamic/mapper')
    async submitMapperCustomForm(
        @Request() request: any
    ): Promise<unknown> {
        const apiResponse: any = {
            data: {},
            error: null
        };
        try {
            const dataSet = request.body;

            const mapperResult: any = await Container.get(DataSource).getRepository(FormMapper)
                .findOne({
                    where: {
                        formId: dataSet.formId,
                        clientId: request.userDetails.client_id,
                        type: 'excel'
                    },
                });
            if (mapperResult) {
                let mapperConfig = mapperResult["config"] ? JSON.parse(mapperResult["config"]) : [];

                let entryDataSet = {
                    formId: dataSet.formId,
                    data: {},
                };

                let isValidData = true;
                const dataResult: any = await this.formBuilderEntryService.submitMapperValidate(dataSet, mapperConfig, entryDataSet, isValidData);
                if (dataResult) {
                    isValidData = dataResult.isValidData;
                    entryDataSet.data = dataResult.entryDataSet.data;
                    apiResponse.error = dataResult.error;
                }

                if (isValidData) {
                    const dataPayload = {
                        formId: request.body.formId,
                        submittedData: JSON.stringify(entryDataSet.data),
                        beingFilledBy: request.userDetails.id,
                        createdBy: request.userDetails.id,
                    };

                    const results: CustomForms[] = await this.formBuilderService
                        .getCustomForms({ clientId: request.userDetails.client_id, id: request.body.formId }, ["referenceId"]);

                    const fbEntryResponse: FormBuilder = await this.formBuilderService.fbInsertEntry(request.userDetails.client_id, dataPayload, results[0].referenceId);
                    if (fbEntryResponse) {
                        apiResponse.data = { insertId: fbEntryResponse.id };

                        const historyDataPayload = {
                            formId: request.body.formId,
                            entryId: fbEntryResponse.id,
                            submittedData: JSON.stringify(entryDataSet.data),
                            beingFilledBy: request.userDetails.id,
                            createdBy: request.userDetails.id,
                            username: request.userDetails.username,
                        };
                        await this.formBuilderService.fbHistoryInsertEntry(request.userDetails.client_id, historyDataPayload, results[0].referenceId);
                    }
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (e) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (e as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }

    }

    /**
     * Insert self registration custom form entry in custom form and user table
     */
    @Post('form/dynamic/self-registration')
    async insertSelfRegistrationCustomForm(
        @Request() request: any
    ): Promise<unknown> {
        try {
            const { client_id: clientId, data, form_Id: formId, role_Id: roleId, ...rest } = request.body;
            const email = data.email;
            const createdBy = 'self-registration';
            const isUserExist = await this.userService.checkUserExist(email, clientId);

            if (isUserExist) {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "User email already exists" } });
            }

            const salt = bcrypt.genSaltSync();
            data.password = bcrypt.hashSync(data.password, salt);

            const insertData = {
                clientId,
                roleId: roleId || null,
                isSuperAdmin: 0,
                username: email,
                password: data.password,
                address: '',
                country: '',
                department: '',
                mobile: '',
                ...data,
                ...rest
            } as Users;

            const formPayload = {
                formId,
                submittedData: JSON.stringify(data),
                beingFilledBy: createdBy,
                createdBy: createdBy
            };

            const [customForm] = await this.formBuilderService.getCustomForms({ clientId, id: formId }, ["referenceId"]);
            const fbEntryResponse = await this.formBuilderService.fbInsertEntry(clientId, formPayload, customForm.referenceId);

            if (!fbEntryResponse) {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "Unable to save entry in form" } })
            }

            const historyDataPayload = {
                formId,
                entryId: fbEntryResponse.id,
                submittedData: JSON.stringify(data),
                beingFilledBy: createdBy,
                createdBy: createdBy
            };

            await this.formBuilderService.fbHistoryInsertEntry(clientId, historyDataPayload, customForm.referenceId);

            const users = await this.userService.createUser(insertData);

            if (!users) {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "Unable to save user in Users" } })
            }

            this.setStatus(201);

            return CommonHelper.apiSwaggerSuccessResponse({ data: { ...fbEntryResponse } });
        } catch (e) {
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: (e as Error).message } });
        }
    }
}
