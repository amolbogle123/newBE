import { CommonHelper, ApiErrorResponse } from "../../../utils/helpers/common.helper";
import dbService from '../../../services/db.service';
import { Body, Path, Post, Request, Route, Security, Tags, Controller, Get } from "tsoa";
import { InsertCommentRequest } from "../doc/comment-interface";
import Container from 'typedi';
import { DataSource } from 'typeorm';
import { Users, CustomFormCommunication } from "../../../entities";

@Route('form-builder')
@Tags('Form Builder')
export class CommentController extends Controller {
    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    @Security('berarerAuth')
    @Post('comment')
    async insertComment(
        @Request() request: any,
        @Body() requestBody: InsertCommentRequest
    ): Promise<any> {
        const { formId, entryId, comment } = requestBody;
        const clientId = request.userDetails.client_id;
        const userId = request.userDetails.id;
        try {
            if (clientId) {
                const selectedFields: any = [
                    "firstName",
                    "lastName"
                ];
                const results = await dbService._findQueryService(Container.get(DataSource).getRepository(Users), {
                    where: { id: userId },
                    select: selectedFields,
                });

                const commentData = {
                    formId: formId,
                    entryId: entryId,
                    comments: comment,
                    createdBy: userId,
                    clientId: clientId,
                    firstName: results[0].firstName,
                    lastName: results[0].lastName
                }

                const result = await dbService._createQueryService(Container.get(DataSource).getRepository(CustomFormCommunication), commentData);
                if (result && result.id) {
                    this.setStatus(201);
                    return CommonHelper.apiSwaggerSuccessResponse({ data: result });
                }
            } else {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "Client Id Required!" } });
            }
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('comments/:formId/:entryId')
    async getCommentsList(
        @Request() request: any,
        @Path() formId: string,
        @Path() entryId: string,
    ): Promise<any> {
        const clientId = request.userDetails.client_id;
        try {
            if (clientId && formId && entryId) {
                const result = await dbService._findQueryService(Container.get(DataSource).getRepository(CustomFormCommunication), {
                    where: {
                        clientId,
                        formId,
                        entryId
                    }
                });

                if (result && result.length > 0) {
                    return CommonHelper.apiSwaggerSuccessResponse({ data: result });
                } else {
                    this.setStatus(204);
                    return CommonHelper.apiSwaggerSuccessResponse({ data: null, message: 'No Data Found!' });
                }
            } else {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "Client Id Required!" } });
            }
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}