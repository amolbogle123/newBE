import { CustomForms, Users, FormBuilderTimeLog } from "../../../entities";
import { ApiErrorResponse, CommonHelper } from "../../../utils/helpers/common.helper";
import {FormBuilderService} from "../services/form-builder.service";
import {UpdateResult, DataSource} from "typeorm";
import {Body, Controller, Get, Hidden, Patch, Path, Request, Route, Security, Tags} from "tsoa";
import Container from 'typedi';

@Route('form-builder')
@Tags('Time Log')
export class TimeLogController extends Controller {

    private formBuilderService: FormBuilderService = new FormBuilderService();

    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    //Done
    @Security('bearerAuth')
    @Hidden()
    @Get('time-logs/:formId/:entryId')
    async getTimeLogs(
        @Path() formId: string,
        @Path() entryId: string
    ): Promise<any> {
        try {
            if (formId && entryId) {
                const results = await Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder("FBT")
                    .leftJoinAndSelect(Users, "users", "users.ID=FBT.CREATED_BY")
                    .select("FORM_ID,ENTRY_ID,FBT.CREATEDON,CREATED_BY,DESSC")
                    .where("ENTRY_ID=:entryId", { entryId: Number(entryId) })
                    .andWhere("FORM_ID=:formId", { formId: Number(formId) })
                    .orderBy('FBT.CREATEDON', 'DESC')
                    .execute();


                if (results && results.length) {
                    return CommonHelper.apiSwaggerSuccessResponse({ data: results,message: "TimeLog Fetched Successfully!!!" });
                } else {
                    return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "User Doesn\'t Exist!!!" } });
                }

            }
            else {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "Entry and Form ID is Required!" } });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Hidden()
    @Get('filling-availability/:formId/:entryId')
    async checkFillingAvailability(
        @Request() req: any,
        @Path() formId: string,
        @Path() entryId: string,
    ): Promise<any> {
        try {
            if (formId && entryId) {

                const results = await Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder("FBT")
                    .leftJoinAndSelect(Users, "users", "users.ID=FBT.BEING_FILLED_BY")
                    .select("users.ID,users.USERNAME")
                    .where("FORM_ID=:formId", { formId: formId })
                    .andWhere("ENTRY_ID=:entryId", { entryId: entryId })
                    .andWhere("CLIENT_ID=:clientId", { clientId: req.userDetails.clientId })
                    .andWhere({ BEING_FILLED_BY: !null })
                    .execute();

                if (results && results.length > 0) {
                    return CommonHelper.apiSwaggerSuccessResponse({ data: results, message: "Data Fetched Successfully !!!" }); 
                } else {
                    return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "Form Doesn\'t Exist !!!" } });   
                }
            } else {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "Form And Entry Id Required!" } });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Hidden()
    @Patch('filling-availability')
    async updateFillingAvailability(
        @Body() requestBody: {
            type: string,
            formId: string,
            entryId: string
        },
        @Request() request: any
    ): Promise<any> {
        try {
            if (requestBody && request.userDetails.client_id) {
                const updateDataSet = {
                    beingFilledBy: (requestBody.type && requestBody.type === "set") ? request.userDetails?.id : null
                };
                const whereClause: any = { formId: requestBody.formId, id: requestBody.entryId }

                const results: CustomForms[] = await this.formBuilderService
                    .getCustomForms({ clientId: request.userDetails.client_id, id: request.body.formId }, ["referenceId"]);

                const updateRes: UpdateResult = await this.formBuilderService
                    .updateFormBuilder(request.userDetails.client_id, results[0].referenceId, whereClause, updateDataSet);

                if (updateRes && updateRes.affected === 1) {
                    return CommonHelper.apiSwaggerSuccessResponse({ data: updateRes, message: "Successfully Updated !!!" });
                }
            }
            return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: "Client Doesn\'t Exist !!!" } });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
