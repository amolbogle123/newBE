import { Post, Request, Route, Security, Tags, Controller, Hidden } from "tsoa";
import { formBuilderTableName } from "../utils/constants/config.constant";
import moment from "moment/moment";
import { dataSource } from "../../../core/data-source";
import { ApiErrorResponse, CommonHelper } from "../../../utils/helpers/common.helper";

@Route('charts')
@Tags('Chart')
export class ChartController extends Controller {
    @Security('bearerAuth')
    @Post('chart-data')
    @Hidden()
    async getChartData(@Request() req: any): Promise<any> {
        try {
            const response: any = { status: false, data: [] };
            const config = req.body.config;
            const tableName = formBuilderTableName + req.userDetails.client_id;
    
            const { xAxis, groupBy } = this.buildXAxisAndGroupBy(config);
    
            const selectFields = [`COUNT(${config.yAxis}) AS "${config.yAxis}"`, xAxis];
            const sqlStmt = `SELECT ${selectFields.join(',')} FROM ${tableName} WHERE ${this.buildWhereClause(req.body.whereCondition.filter)} GROUP BY ${groupBy}`;
    
            const result = await dataSource.manager.query(sqlStmt);
    
            if (result && result.length > 0) {
                this.transformData(result);
                response.status = true;
                const queryFields = Object.keys(result[0]);
                [response.xAxis, ...response.yAxis] = queryFields.slice(1);
                response.data = result;
            }
    
            return CommonHelper.apiSwaggerSuccessResponse({ data: response, message: "Successfully executed." });
        } catch (e) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (e as Error).message
                }
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    
    private buildXAxisAndGroupBy(config) {
        if (config.xAxisType === 'datetime') {
            const field = `"SUBMITTED_DATA"->>'${config.xAxis}'`;
            return {
                xAxis: `COALESCE(TO_CHAR(${field}::date, 'MM-DD-YYYY'), '') AS "${config.xAxis}"`,
                groupBy: `COALESCE(TO_CHAR(${field}::date, 'MM-DD-YYYY'), '')`
            };
        } else if (["ID", "CREATEDON", "RECORD_ID", "STATUS"].includes(config.xAxis)) {
            return { xAxis: `"${config.xAxis}"`, groupBy: `"${config.xAxis}"` };
        }
    
        throw new Error(`Invalid config.xAxis: ${config.xAxis}`);
    }
    
    private buildWhereClause(filter) {
        return (Array.isArray(filter) && filter.length > 0) ? filter.map(this.buildFilterCondition).filter(Boolean).join(" AND ") : "";
    }
    
    private buildFilterCondition(whereValue) {
        if (whereValue.field && whereValue.type && whereValue.operator) {
            const field = `"SUBMITTED_DATA"->>'${whereValue.field}'`;
    
            if (whereValue.type !== 'datetime' && whereValue.value) {
                return `LOWER(${field}) LIKE LOWER('%${whereValue.value}%')`;
            } else if (whereValue.type === 'datetime' && (whereValue.startDate || whereValue.endDate)) {
                const clauses = [];
                clauses.push(`(${field} IS NOT NULL)`);
                if (whereValue.startDate) {
                    const startDate = moment(whereValue.startDate).format('MM-DD-YYYY HH:mm:ss');
                    clauses.push(`(${field})::timestamp >= '${startDate}'::timestamp`);
                }
                if (whereValue.endDate) {
                    const endDate = moment(whereValue.endDate).format('MM-DD-YYYY HH:mm:ss');
                    clauses.push(`(${field})::timestamp <= '${endDate}'::timestamp`);
                }
                return clauses.join(" AND ");
            }
        }
        return "";
    }
    
    private transformData(result) {
        result.forEach(item => {
            if (item && item.divisionOfficeName) {
                const obj = JSON.parse(item.divisionOfficeName);
                item.divisionOfficeName = obj.divisionOfficeName;
            } else {
                const objKey = Object.keys(item);
                const parseObj = JSON.parse(item[objKey[0]]);
                item[objKey[0]] = parseObj[objKey[0]];
            }
        });
    }
}
