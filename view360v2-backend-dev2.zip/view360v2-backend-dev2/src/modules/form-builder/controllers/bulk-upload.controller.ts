import {Controller, Request, Route, Tags} from "tsoa";
import {Response} from "express";
import {ApiErrorResponse, CommonHelper} from "utils/helpers/common.helper";
import fs from "fs";
import XLSX from "xlsx";
import {v4 as generateUuid} from "uuid";
import Container from "typedi";
import {DataSource} from "typeorm";
import {CustomForms, PublicTables} from "entities";
import {dataSource} from "core/data-source";
import {ProcessStatus} from "../../process-builder/models";
import {ProcessBuilderHelper} from "../../process-builder-v2/utils/helpers/process-builder.helper";
import {View360DatabaseService} from "../../within-view360-table/services/view360-database.service";

@Route("bulk-upload")
@Tags("bulk-upload")
export class BulkUploadController extends Controller {
    private processBuilderHelper: ProcessBuilderHelper = new ProcessBuilderHelper();
    private errorMessages = [];
    constructor() {
        super();
    }

    async bulkUpload(request: Request | any, response: Response, next: any): Promise<any> {
        try {
            this.errorMessages = [];
            const apiResponse: any = {status: false, error: [], missingColumn: [], extraColumn: [] };
            if (request.file) {
                const formId = request.body.formID;
                const uploadedFilePath = request.file.destination + request.file.filename;
                if (fs.existsSync(uploadedFilePath)) {
                    const formData = await Container.get(DataSource).getRepository(CustomForms)
                        .findOne({where: {id: formId}});

                    const workbook = XLSX.readFile(uploadedFilePath);

                    // Get the first sheet
                    const sheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[sheetName];

                    // Convert the sheet to JSON using the first row as keys
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                    // Get the first row as keys
                    const keys: any = jsonData[0];

                    const formDataObject: any = JSON.parse(formData.formDataConfig);

                    const formKeys = formDataObject
                        .filter(item => item.type !== 'button')
                        .map(item => item.label);

                    //checking missing column from excel
                    const missingFromExcel = formKeys.filter(item => !keys.includes(item));
                    apiResponse.missingColumn = missingFromExcel;

                    //checking extra columns in excel.
                    const extraInExcel = keys.filter(item => !formKeys.includes(item));
                    apiResponse.extraColumn = extraInExcel;
                    if(missingFromExcel && missingFromExcel.length > 0 || extraInExcel && extraInExcel.length > 0) {
                        apiResponse.status = false;
                        return CommonHelper.apiSuccessResponse(response, apiResponse);
                    }


                    const jsonObjects = jsonData.slice(1).filter(row => !this.isBlankRow(row as string[])).map((row, rowIndex) => {
                        let obj = {};
                        const rowNumber = rowIndex + 2;
                        keys.forEach(async (key, index) => {
                            const formDataParse = JSON.parse(formData.formDataConfig);
                            const formDataValidationsObjects = JSON.parse(formData.formData);
                            const formDataValObj = formDataValidationsObjects.find(item => item.label === key);
                            const formDataObj = formDataParse.find(item => item.label === key);
                            const valueType = formDataObj.type;
                            let value = row[index];
                            if (valueType === 'datetime') {
                                if (typeof value !== 'string' && !isNaN(value)) {
                                    const jsDate = new Date(value);
                                    const newDate = jsDate.toISOString().slice(0, 10);
                                    const stringDate = newDate + 'T12:00:00+05:30';
                                    value = newDate + 'T12:00:00+05:30';
                                    value = new Date(value);
                                    obj[formDataObj.key] = stringDate;
                                }
                            } else {
                                obj[formDataObj.key] = row[index];
                            }
                            await this.validationOfData(valueType, value, formDataObj.label, rowNumber, formDataValObj);
                        });
                        // Add additional keys
                        obj['submit'] = true;
                        obj['extraParams'] = {};
                        return obj;
                    });
                    if(this.errorMessages.length === 0) {
                        const result = await this.saveFormEntries(request,formId,jsonObjects);
                        apiResponse.status = result;
                    } else {
                        apiResponse.status = false;
                        apiResponse.error = this.errorMessages;
                    }
                }
            }
            return CommonHelper.apiSuccessResponse(response, apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(response, apiErrorResponse);
        }
    }

    async dynamicTableBulkImport(request: Request | any, response: Response, next: any): Promise<any> {
        try {
            this.errorMessages = [];
            const apiResponse: any = {status: false, error: [], missingColumn: [], extraColumn: [], errorCount: 0 };
            if (request.file) {
                const tableName = request.body.tableName;
                const tableConfig = JSON.parse(request.body.tableConfig);
                const uploadedFilePath = request.file.destination + request.file.filename;
                if (fs.existsSync(uploadedFilePath)) {
                    let defaultValues;
                    const publicTablesValues = await Container.get(DataSource).getRepository(PublicTables).find({
                        where: { type: 'View360', client_id: request.userDetails.client_id, name: tableName }
                    });
                    if (publicTablesValues?.[0]?.config) {
                        defaultValues = JSON.parse(publicTablesValues[0].config);

                        if (defaultValues?.length) {
                            tableConfig.forEach(item => {
                                const values = defaultValues.find(itm => itm.name === item.Field);
                                if(item.Field.toLowerCase() !== 'id'.toLowerCase()) {
                                    item.Default = values?.default || null;
                                }
                            });
                        }
                    }

                    const workbook = XLSX.readFile(uploadedFilePath);

                    // Get the first sheet
                    const sheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[sheetName];

                    // Convert the sheet to JSON using the first row as keys
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                    // Get the first row as keys
                    const keys: any = jsonData[0];

                    const formDataObject: any = tableConfig.filter(field => field.Field !== 'id');

                    const formKeys = formDataObject.filter(item => item.Field !== 'id')
                        .map(item => item.Field);

                    //checking missing column from excel
                    const missingFromExcel = formKeys.filter(item => !keys.includes(item));
                    apiResponse.missingColumn = missingFromExcel;

                    //checking extra columns in excel.
                    const extraInExcel = keys.filter(item => !formKeys.includes(item));
                    apiResponse.extraColumn = extraInExcel;
                    if(missingFromExcel && missingFromExcel.length > 0 || extraInExcel && extraInExcel.length > 0) {
                        apiResponse.status = false;
                        return CommonHelper.apiSuccessResponse(response, apiResponse);
                    }


                    const jsonObjects = jsonData.slice(1).filter(row => !this.isBlankRow(row as string[])).map((row, rowIndex) => {
                        let obj = {};
                        const rowNumber = rowIndex + 2;
                        keys.forEach(async (key, index) => {
                            if(formDataObject[index].Type.toLowerCase() === 'varchar(255)' || formDataObject[index].Type.toLowerCase() === 'longtext') {
                                if(formDataObject[index].Null === 'YES') {
                                    obj[formDataObject[index].Field] = row[index];
                                } else if(formDataObject[index].Null === 'NO') {
                                    if(row[index]) {
                                        obj[formDataObject[index].Field] = row[index];
                                    } else if(formDataObject[index].Default !== null || formDataObject[index].Default !== '') {
                                        obj[formDataObject[index].Field] = formDataObject[index].Default;
                                    } else {
                                        this.errorMessages.push('The value is required on row ' + rowNumber + ' of column "' + formDataObject[index].Field + '".');
                                    }
                                }
                            }
                            if(formDataObject[index].Type.toLowerCase() === 'int') {
                                if(formDataObject[index].Null === 'YES') {
                                    if (isNaN(row[index])) {
                                        this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + formDataObject[index].Field + '" is invalid.');
                                    } else {
                                        obj[formDataObject[index].Field] =  row[index];
                                    }
                                } else if(formDataObject[index].Null === 'NO') {
                                    if(row[index]) {
                                        if (isNaN(row[index])) {
                                            this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + formDataObject[index].Field + '" is invalid.');
                                        } else {
                                            obj[formDataObject[index].Field] =  row[index];
                                        }
                                    } else if(formDataObject[index].Default !== null || formDataObject[index].Default !== '') {
                                        obj[formDataObject[index].Field] = formDataObject[index].Default;
                                    } else {
                                        this.errorMessages.push('The value is required on row ' + rowNumber + ' of column "' + formDataObject[index].Field + '".');
                                    }
                                }
                            }
                            if(formDataObject[index].Type.toLowerCase() === 'datetime') {
                                if(formDataObject[index].Null === 'YES') {
                                    if(typeof row[index] !== 'string') {
                                        const utc_days = Math.floor(row[index] - 25569);
                                        const utc_value = utc_days * 86400; // seconds in a day
                                        const date_info = new Date(utc_value * 1000); // milliseconds

                                        // Correct for timezone offset (subtract the timezone offset)
                                        if(!isNaN(date_info.getTime())) {
                                            const date = new Date(date_info.getFullYear(), date_info.getMonth(), date_info.getDate());
                                            obj[formDataObject[index].Field] =  date;
                                        } else {
                                            obj[formDataObject[index].Field] = null
                                        }
                                    } else {
                                        this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + formDataObject[index].Field + '" is invalid.');
                                    }
                                } else if(formDataObject[index].Null === 'NO') {
                                    if(row[index]) {
                                        if(typeof row[index] !== 'string') {
                                            const utc_days = Math.floor(row[index] - 25569);
                                            const utc_value = utc_days * 86400; // seconds in a day
                                            const date_info = new Date(utc_value * 1000); // milliseconds

                                            if(!isNaN(date_info.getTime())) {
                                                const date = new Date(date_info.getFullYear(), date_info.getMonth(), date_info.getDate());
                                                obj[formDataObject[index].Field] =  date;
                                            } else {
                                                this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + formDataObject[index].Field + '" is invalid.');
                                            }
                                        } else {
                                            this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + formDataObject[index].Field + '" is invalid.');
                                        }
                                    } else if(formDataObject[index].Default !== null || formDataObject[index].Default !== '') {
                                        obj[formDataObject[index].Field] = formDataObject[index].Default;
                                    } else {
                                        this.errorMessages.push('The value is required on row ' + rowNumber + ' of column "' + formDataObject[index].Field + '".');
                                    }
                                }
                            }
                            if(formDataObject[index].Type.toLowerCase() === 'json') {
                                if(formDataObject[index].Null === 'YES') {
                                    const parsed = JSON.parse(row[index]);
                                    if(typeof parsed !== 'object') {
                                        this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + formDataObject[index].Field + '" is invalid.');
                                    } else {
                                        obj[formDataObject[index].Field] = parsed;
                                    }
                                } else if(formDataObject[index].Null === 'NO') {
                                    if(row[index]) {
                                        const parsed = JSON.parse(row[index]);
                                        if(typeof parsed !== 'object') {
                                            this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + formDataObject[index].Field + '" is invalid.');
                                        } else {
                                            obj[formDataObject[index].Field] = parsed;
                                        }
                                    } else if(formDataObject[index].Default !== null || formDataObject[index].Default !== '') {
                                        obj[formDataObject[index].Field] = formDataObject[index].Default;
                                    } else {
                                        this.errorMessages.push('The value is required on row ' + rowNumber + ' of column "' + formDataObject[index].Field + '".');
                                    }
                                }
                            }
                        });

                        return obj;
                    });
                    if(this.errorMessages.length > 0) {
                        apiResponse.status = false;
                        apiResponse.error = this.errorMessages;
                    } else {
                        const createDetails = await View360DatabaseService.addRowTable(tableName,jsonObjects, 'BulkInsert');
                        apiResponse.status = createDetails.status;
                        apiResponse.error = createDetails.error;
                        apiResponse.errorCount = createDetails.errorCount;
                    }
                }
            }
            return CommonHelper.apiSuccessResponse(response, apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(response, apiErrorResponse);
        }
    }
    async excelDateToJSDate(serial) {
        const utc_days = Math.floor(serial - 25569);
        const utc_value = utc_days * 86400; // seconds in a day
        const date_info = new Date(utc_value * 1000); // milliseconds

        // Correct for timezone offset (subtract the timezone offset)
        const date = new Date(date_info.getFullYear(), date_info.getMonth(), date_info.getDate());

        return date;
    }

    private isBlankRow(row: string[]): boolean {
        // Check if all values in the row are undefined or empty strings
        //return row.every(cell => cell === undefined || cell.trim() === '');
        return row.every(cell => cell === undefined || cell === null || (typeof cell === 'string' && cell.trim() === ''));
    }

    async validationOfData(valueType, value, col, rowNumber, formDataValObj) {
        switch (valueType) {

            case 'number':
                if (isNaN(value)) {
                    this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + col + '" is invalid.');
                }
                break;

            case 'phoneNumber':
                if (isNaN(value)) {
                    this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + col + '" is invalid.');
                }
                break;

            case 'datetime':

                if (typeof value !== 'string') {
                    const date = new Date(value);
                    const result = date instanceof Date && !isNaN(date.getTime());
                    if (!result) {
                        this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + col + '" is invalid.');
                    }
                } else {
                    this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + col + '" is invalid.');
                }

                break;

            case 'radio':

                const checkValueExist = formDataValObj.values.filter(item => item.value === value)
                if (checkValueExist.length === 0) {
                    this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + col + '" is invalid.');
                }
                break;

            case 'checkbox':

                if (value !== true && value !== false) {
                    this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + col + '" is invalid.');
                }
                break;

            case 'select':

                const checkValue = formDataValObj.data.values.filter(item => item.value === value)
                if (checkValue.length === 0) {
                    this.errorMessages.push('The value in row ' + rowNumber + ' of column "' + col + '" is invalid.');
                }
                break;

            default:
                // Optional: Handle unknown valueType
                break;
        }
    }

    async saveFormEntries(request,formId,jsonObjects) {
        try {
            if(jsonObjects.length > 0) {
                const createdBy = request.userDetails.id;
                const clientId = request.userDetails.client_id;
                const formBuilderTableName = 'form_builder_' + clientId;
                const formBuilderHistoryTableName = 'form_builder_' + clientId + '_history';
                for (const item of jsonObjects) {
                    const id = await generateUuid();
                    const submittedData = JSON.stringify(item);
                    // Inserting the record in Form
                    const insertFormQuery = `INSERT INTO ${formBuilderTableName} (id,FORM_ID,SUBMITTED_DATA,CREATED_BY,BEING_FILLED_BY) VALUES ('${id}','${formId}','${submittedData}','${createdBy}','${createdBy}');`;
                    await dataSource.manager.query(insertFormQuery);
                    // Inserting the record in Form History
                    const getInsertedRecordResult = await dataSource.manager.query(`SELECT * FROM ${formBuilderTableName} WHERE id= '${id}'`);
                    if(getInsertedRecordResult.length > 0) {
                        const idFormHistory = await generateUuid();
                        const newFormID = getInsertedRecordResult[0].id
                        const insertFormHistoryQuery = `INSERT INTO ${formBuilderHistoryTableName} (id,FORM_ID,SUBMITTED_DATA,CREATED_BY,ENTRY_ID) VALUES ('${idFormHistory}','${formId}','${submittedData}','${createdBy}','${newFormID}');`;
                        const insertFormHistoryResult = await dataSource.manager.query(insertFormHistoryQuery);
                        const result = await this.processBuilderHelper.execute(clientId, formId, id, '', null, null, { type: ProcessStatus.FORM_SUBMIT });
                    }
                }
            }
            return true;
        } catch (e) {
            return false;
        }
    }
}
