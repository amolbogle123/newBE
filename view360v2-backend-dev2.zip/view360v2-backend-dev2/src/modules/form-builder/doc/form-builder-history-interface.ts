import { ApiSuccessResponse } from "../../../utils/helpers/common.helper";

export interface FBHistoryResponse extends ApiSuccessResponse {
    data: ResponseData[];
}

interface ResponseData {
    id: string;
    formId: string;
    submittedData: DynamicFields;
    createdBy: string;
    createdOn: string;
    entryId: string;
}

interface DynamicFields {
    [key: string]: any
}