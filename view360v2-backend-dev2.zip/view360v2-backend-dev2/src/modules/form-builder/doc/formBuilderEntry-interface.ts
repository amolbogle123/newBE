export interface SubmitCustomFormRequest {
    data: DynamicField;
    additionalData?: any | null;
    formId: string;
    userid: string;
    time: any;
    isTimerBased: boolean;
    referenceId: string;
}

export interface UpdateCustomFormRequest {
    data: DynamicField;
    submissionId: string;
    formId: string;
    time: unknown;
    isTimerBased: boolean;
}

interface DynamicField {
    [key: string]: any;
}