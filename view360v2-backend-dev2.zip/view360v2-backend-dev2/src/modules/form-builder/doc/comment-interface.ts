export interface InsertCommentRequest {
    formId: string;
    entryId: string;
    comment: string;
    createdById?: string;
    clientId?: string;
}