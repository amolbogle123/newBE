export interface ReportFormEntries {
    draw: number;
    columns: Columns[];
    order: DynamicObject[];
    start: number;
    length: number;
    search: Search;
    formId: string;
    whereCondition: WhereCondition;
}

interface Columns {
    data: string;
    name: string;
    searchable: boolean;
    orderable: boolean;
    search: Search
}

interface Search {
    value: string;
    regex: boolean
}

interface DynamicObject {
    [key: string]: any;
}

interface WhereCondition {
    startDate: any;
    endDate: any;
    displayColumn: boolean;
    filter: DynamicObject[];
}
