export interface InsertDocumentRequest {
    id?: string;
    projectName: string;
    projectDiscription: string;
    projectManager: string;
    projectshortName: string;
    mapped_user?: MappedUser[];
}

interface MappedUser { }

export interface InsertDocumentResponse {
    clientId: number;
    shortName: string;
    name: string;
    projectManager: string;
    mappedUser: MappedUser;
    description: string;
    status: number;
    username: string;
    createdBy: string;
    id: string;
    appId: number;
    createdOn?: Date;
}

export interface DocumentListResponse {
    id: string,
    clientId: number,
    shortName: string,
    name: string,
    projectManager: string,
    mappedUser: MappedUser[],
    description: string,
    status: number,
    appId: string,
    username: string,
    createdBy: string,
    createdOn: string,
    permission: Permission,
    totalForm: number,
    allForms: Form[]
}

interface Permission {
    viewDocument: boolean,
    editDocument: boolean,
    manageUserDocument: boolean,
    deleteDocument: boolean,
    createForms: boolean,
    formList: boolean
}

interface Form {
    id: string,
    formName: string
}

export interface UpdateDocumentUser {
    id: number;
    mapped_user: MappedUser[];
}

export interface DeleteDocument {
    id: string | string[];
}