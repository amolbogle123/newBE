export interface CreateFormBuilderRequest {
    formGroupId: string
    name: string
    description?: string;
    approvals: Approvals[];
    approvalSetting: ApprovalSetting;
    form_controls: FormControls[];
    statusBoxes: StatusBoxes[];
    formFields: DynamicFields;
    data: DynamicFields[];
    isCommEnabled?: boolean;
    isVersionControl?: boolean;
    isEnableExcelUpload?: boolean;
}

export interface CreateFormBuilderResponse {
    clientId: number;
    docId: string;
    formName: string;
    formDescription?: string;
    isTimerBased: number;
    isShowDashboard: number;
    formData: string;
    isVersionControl: number;
    isCommanable: number;
    isAssignment: number;
    assignedUser: number;
    isApproval: number;
    approvalData: string;
    createdBy: string;
    formControls: string;
    statusBoxes: string;
    permissionConfig: string;
    mappedUser: string;
    formType: string;
    id: string;
    createdOn: string
}

export interface GetCustomFormListRequest {
    draw: number;
    columns: Columns[];
    order: Order[];
    start: number;
    length: number;
    search: Search;
}

export interface GetCustomFormListResponse {
    recordsTotal: number;
    recordsFiltered: number;
    records: Records[]
}

export interface GetCustomFormResponse {
    id: string;
    docId: string;
    formName: string;
    formDescription?: string;
    isShowDashboard: number;
    isTimerBased: number;
    isVersionControl: number;
    isCommanable: number;
    isAssignment: number;
    isApproval: number;
    formControls: string;
    statusBoxes: string;
    approvalData: Approvals[]
    approvalSetting: string;
    assignedUser: any;
    formData: DynamicFields[];
    formDataConfig: DynamicFields[];
    permissionConfig: string;
    isExcelMapperForm: boolean;
    excelMapperDetails: ExcelMapperDetails;
    isEnableExcelUpload: number;
}

export interface EditCustomFormRequest {
    id: string;
    name: string;
    description?: string;
    data: DynamicFields[];
    formShowDashboard: number;
    isTimerBased: number;
    isVersionBased?: boolean | number;
    isCommunicationBased?: boolean | number;
    isAssignment: number;
    selectedRole: any;
    approvals: Approvals[]
    isApproval: number;
    approvalSetting: ApprovalSetting;
    form_controls: FormControls [];
    statusBoxes: StatusBoxes[];
    formFields: DynamicFields;
    formGroupId: string;
    isEnableExcelUpload?: boolean | number;
}

interface FormControls {
    name: string;
    variable: string;
    value: boolean
}

interface ApprovalSetting {
    mail: any;
    notification: any
}

interface Approvals {
    user: any;
    status: any;
    mtype: any;
    ntype: any;
    mtemplate: any;
    ntemplate: any;
}

interface DynamicFields {
    [key: string]: any
}

interface StatusBoxes {

}

interface Columns {
    data: string;
    name: string;
    searchable: boolean;
    orderable: boolean;
    search: Search
}

interface Search {
    value: string;
    regex: boolean
}

interface Order {
    column: number;
    dir: string
}

interface Records {
    id: string;
    docId: string;
    formName: string;
    formDescription?: string;
    formData: string;
    createdBy: string;
    mappedUser: DynamicFields[];
    permission: Permission
}

interface Permission {
    viewForm: boolean;
    editForm: boolean;
    manageUserForm: boolean;
    deleteForm: boolean;
    formShare: boolean;
    formEmbed: boolean;
    formsEntryCreate: boolean;
    formsEntryList: boolean;
}

interface ExcelMapperDetails {

}
