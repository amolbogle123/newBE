interface Columns {
    data: string;
    name: string;
    searchable: boolean;
    orderable: boolean;
    search: Search;
}
interface Search {
    value: string;
    regex: boolean;
}

interface Order {
    column: number;
    dir: string;
}

export interface GetMapperListRequest {
    draw: number;
    columns: Columns[];
    order: Order[];
    start: number;
    length: number;
    search: Search;
    type: string;
}

export interface InsertMapperRequest {
    formDetails?: any;
    formId?: string;
    config: any;
    columnHeader?: number;
    fileConfig?: any;
    type: string;
}

export interface UpdateMapperRequest {
    formDetails?: any;
    formId: string;
    config: any;
    columnHeader?: number;
    fileConfig?: any;
    type?: string;
}

export interface DeleteMapper {
    id: string;
}

export interface MapperListResponse {
    status: string | boolean;
    data?: any;
    message?: string;
    recordsTotal?: number;
    recordsFiltered?: number;
}

export interface AllMapperListResponse {
    status: string | boolean;
    data?: any;
    message?: string;
}

export interface SaveMapperResponse {
    status: string | boolean;
    data?: any;
    message?: string;
}

export interface MapperDetailsResponse {
    status: string | boolean;
    data?: any;
    message?: string;
}

export interface UpdateMapperResponse {
    status: string | boolean;
    data?: any;
    message?: string;
}

export interface DeleteMapperResponse {
    status: string | boolean;
    data?: any;
    message?: string;
}