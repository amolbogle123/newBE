import { DeleteResult, UpdateResult, DataSource } from "typeorm";
import { CustomFormsGroup, CustomForms, Users, BusinessProcessModelingExecute } from "../../../entities";
import Container from 'typedi';
import { FormBuilderHelper } from "../utils/helpers/form-builder.helper";
import { FormBuilder, FormBuilderHistory } from "../../../entities/create-form-builder";

export class FormBuilderService {

    async isCustomFormGroupExist(condition: any): Promise<boolean> {
        return await Container.get(DataSource).getRepository(CustomFormsGroup).count(condition) > 0;
    }

    async getFormBuilderList(client_id: number, referenceId: string, condition: any = [], fields: any = [], order: any = {}): Promise<FormBuilder[]> {
        const formBuilder = await FormBuilderHelper.formBuilderRepo(client_id, referenceId);
        return formBuilder.find({where: condition, select: fields, order});
    }

    async getFormBuilderList_Paging(client_id: number, referenceId: string, condition: any = [], fields: any = [],
        start = 0, limit = 10): Promise<any> {
        const formBuilder = await FormBuilderHelper.formBuilderRepo(client_id, referenceId);

        let result = await formBuilder.find({where: condition, select: fields, take:limit, skip:start});
        
        let totalResult =await formBuilder.count({where: condition, select: fields});
        return result.map((item) => ({
            ...item,    
            recordsTotal: totalResult,  
        }));
    }
    

    async getFormBuilder(client_id: number,referenceId: string, condition: any = [], fields: any = []): Promise<FormBuilder> {
        const formBuilder = await FormBuilderHelper.formBuilderRepo(client_id, referenceId);
        return formBuilder.findOne({where: condition, select: fields});
    }

    async fbInsertEntry(client_id: number, payload: any, referenceId: string): Promise<any> {
        const repository = await FormBuilderHelper.formBuilderRepo(client_id, referenceId)
        return repository.save(payload);
    }

    async fbHistoryInsertEntry(client_id: number, payload: any, referenceId: string): Promise<any> {
        const repository = await FormBuilderHelper.formBuilderHistoryRepo(client_id, referenceId);
        return repository.save(payload);
    }

    async fbUpdateHistoryEntries(clientId: number, historyEntries: FormBuilderHistory[], referenceId?: string): Promise<FormBuilderHistory[]> {
        const repository = await FormBuilderHelper.formBuilderHistoryRepo(clientId, referenceId);
        return repository.save(historyEntries); // Assuming 'save' handles batch updates
    }

    async getVersionHistory(client_id: number, referenceId: string,condition: any = [], order: any = {}): Promise<FormBuilderHistory[]> {
        const repository = await FormBuilderHelper.formBuilderHistoryRepo(client_id, referenceId);
        return repository.find({where: condition, order});
    }

    async updateFormBuilder(client_id: number, referenceId: string, condition: any = [], updateSet: any = []): Promise<UpdateResult> {
        const repository = await FormBuilderHelper.formBuilderRepo(client_id, referenceId);
        return repository.update(condition, updateSet);
    }

    async deleteFormBuilder(client_id: number, referenceId: string, condition: any = []): Promise<DeleteResult> {
        const repository = await FormBuilderHelper.formBuilderRepo(client_id, referenceId);
        return repository.delete(condition);
    }

    async deleteFormBuilderHistory(client_id: number, referenceId: string, condition: any = []): Promise<DeleteResult> {
        const repository = await FormBuilderHelper.formBuilderHistoryRepo(client_id, referenceId);
        return repository.delete(condition);
    }

    async getFormGroup(condition: any, fields: any[] = []): Promise<CustomFormsGroup | null> {
        return Container.get(DataSource).getRepository(CustomFormsGroup).findOne({ where: condition, select: fields });
    }

    async getFormGroups(condition: any, fields: any[] = []): Promise<CustomFormsGroup[]> {
        return Container.get(DataSource).getRepository(CustomFormsGroup).find({ where: condition, select: fields });
    }

    async saveCustomForms(payload: any): Promise<CustomForms | null> {
        return Container.get(DataSource).getRepository(CustomForms).save(payload);
    }

    async updateCustomForms(condition: any, payload: any): Promise<UpdateResult> {
        return Container.get(DataSource).getRepository(CustomForms).update(condition, payload);
    }

    async deleteFormGroup(condition: any): Promise<DeleteResult> {
        return Container.get(DataSource).getRepository(CustomFormsGroup).delete(condition);
    }

    async getCustomForms(condition: any, fields: any[] = [],take?:number,skip?:number,order?:{}): Promise<CustomForms[]> {
        return Container.get(DataSource).getRepository(CustomForms).find({ where: condition, select: fields ,take,skip,order});
    }

    async deleteCustomForms(condition: any): Promise<DeleteResult> {
        return Container.get(DataSource).getRepository(CustomForms).delete(condition);
    }

    async getUsers(condition: any, fields: any[] = []): Promise<Users[]> {
        return Container.get(DataSource).getRepository(Users).find({ where: condition, select: fields });
    }

    async getFormGroupWithRelations(condition: any, fields: any[] = [], relations: any = []): Promise<CustomFormsGroup[]> {
        return Container.get(DataSource).getRepository(CustomFormsGroup).find({ where: condition, select: fields, relations: relations });
    }

    async customFormDetails(payload: any): Promise<any> {
        let query = `SELECT * FROM custom_forms  WHERE ID = '${payload.id}' AND DOC_ID = '${payload.formId}'`;

        return Container.get(DataSource).getRepository(CustomForms).query(query);
    }

    async bpmnExecDetails(condition: any = [], fields: any = [], order: any = {}, relations: any = []): Promise<BusinessProcessModelingExecute[]> {
        return Container.get(DataSource).getRepository(BusinessProcessModelingExecute).find({where: condition, select: fields, order, relations})
    }
}
