import moment from "moment/moment";

export class FormBuilderEntryService {
    async submitMapperValidate(dataSet, mapperConfig, entryDataSet, isValidData) {
        return new Promise(async (resolve) => {
            let apiResponse = {
                entryDataSet: entryDataSet,
                isValidData: isValidData,
                error: null
            };
            Object.keys(dataSet.data).forEach((col) => {
                let findMapper = mapperConfig.find((m) => m.label === col);
                if (findMapper?.isUse && findMapper?.fieldObj?.key) {
                    if (['datetime', 'date', 'day'].indexOf(findMapper.fieldObj.type) > -1) {
                        const dateF = moment(dataSet.data[col], "MM-DD-YYYY");
                        if (dateF.isValid()) {
                            apiResponse.entryDataSet.data[findMapper.fieldObj.key] = dateF.toISOString();
                        } else {
                            apiResponse.isValidData = false;
                            apiResponse.error = [`Date format not valid for ${col} column`];
                        }
                    } else {
                        apiResponse.entryDataSet.data[findMapper.fieldObj.key] = dataSet.data[col];
                    }
                }
            });

            resolve(apiResponse);
        });
    }
}
