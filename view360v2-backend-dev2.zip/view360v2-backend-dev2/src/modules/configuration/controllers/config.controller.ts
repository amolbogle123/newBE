import ApplicationController from "controllers/application.controller";
import fs from "fs";
import dotenv from "dotenv";
import { Request, Response } from "express";
import { CommonHelper } from "utils/helpers/common.helper";
import { reloadSetDataSource, setDataSource } from "core/data-source";

export default class ConfigController extends ApplicationController {
    static saveDBSettings(request: Request | any, response: Response): void {

        try {
            const reloadEnv = () => {
                const envProcessConfig = dotenv.parse(fs.readFileSync('.env'))

                for (const key in envProcessConfig) {
                    process.env[key] = envProcessConfig[key]
                }
                console.log('reloaded')
            }
            const config = request.body.config;

            dotenv.config({override:true,path: '.env' });

            process.env.INITIAL_SETUP = String(true);
            process.env.DB_TYPE = config.dbType;
            process.env.DB_HOST = config.dbHost;
            process.env.DB_PORT = config.dbPort;
            process.env.DB_USERNAME = config.dbUser;
            process.env.DB_PASSWORD = config.dbPass;
            process.env.DB_NAME = config.dbName;
            process.env.DB_SYNCHRONIZE = String(true); // this shouldn't be turned on in production
            process.env.DB_LOGGING = String(false);

            // Convert the environment variables to a string
            const envConfig = dotenv.parse(fs.readFileSync('.env'));

            // Update the environment variables with your changes
            Object.keys(envConfig).forEach((key) => {
                envConfig[key] = process.env[key];
            });

            // Convert the environment variables back to a string
            const envConfigString = Object.keys(envConfig).map((key) => `${key}="${envConfig[key]}"`).join('\n');

            // Write the updated environment variables to the .env file
            //fs.writeFileSync('.env', envConfigString);

             fs.writeFile('.env', envConfigString, async(err) => {
                // Checking for errors
                if (err) throw err;

                delete process.env.INITIAL_SETUP;
                delete process.env.DB_TYPE;
                delete process.env.DB_HOST;
                delete process.env.DB_PORT;
                delete process.env.DB_USERNAME;
                delete process.env.DB_PASSWORD;
                delete process.env.DB_NAME;
                delete process.env.DB_SYNCHRONIZE;
                delete process.env.DB_LOGGING;
                delete process.env.ENABLE_APPLICATION_INSIGHTS;
                dotenv.config({override:true})
                reloadEnv();
                //await dataSource.destroy();
                //const dataSource2: DataSource = new DatabaseConnection().initialize();

                await setDataSource(await reloadSetDataSource());
                 //await dataSource.initialize();
                 setTimeout(() => {
                    CommonHelper.apiSuccessResponse(response, {
                        data: { setup: true },
                        message: 'File updated successfully.',
                    });
                 }, 1000);
            });
        } catch (error) {
            ConfigController.handleError(response, error.message);
        }
    }
}