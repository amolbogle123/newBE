import { AppRoutes } from "../../app.routes";
import ConfigController from "./controllers/config.controller";

export class ConfigRoutes extends AppRoutes {
    constructor() {
        super();
        this.initRoutes();
    }

    initRoutes(): void {
        this.router.post('/new-config/set-db-settings', ConfigController.saveDBSettings);
    }
}
