export interface ReadFileResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DatabaseListResponse {
    status: boolean;
    data?: any;
    message?: string;
    recordsTotal?: number;
    recordsFiltered?: number;
}

export interface AllListResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface InsertRelationRequest {
    name: string;
    config?: any;
    extraConfig?: any;
    connectorId?: string | null;
    syncConfig?: any;
    syncMetaConfig?: any;
}

export interface UpdateRelationRequest {
    name: string;
    config?: any;
    extraConfig?: any;
    connectorId?: string | null;
    oldTableName?: string | null;
}

export interface SyncDataRelationRequest {
    syncType: string;
    syncTableConfig: any;
}

export interface UpdateResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DeleteRelation {
    id: string[];
    deleteTable?: boolean;
}

export interface SaveResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface TableDetails {
    tables: any[];
}

export interface TableResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface ApiResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DetailsResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DeleteResponse {
    status: boolean;
    data?: any;
    message?: string;
}