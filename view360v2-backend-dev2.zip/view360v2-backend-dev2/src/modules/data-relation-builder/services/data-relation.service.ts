import { DataSource } from "typeorm";
import { dataSource } from "core/data-source";

export class DataRelationService {
    static async createMigrationTable(requestBody): Promise<any> {
        return new Promise(async (resolve) => {
            const response = { status: true, error: null };
            let columnList = [];

            if (requestBody?.config?.tables?.length) {
                columnList = await this.getColumnList(requestBody.config);

                columnList = columnList.map((c) => {
                    return `${c.TableName}_${c.ColumnName} ${c.DataType} DEFAULT NULL`;
                });
            }

            if (columnList?.length) {
                let createTableQuery = `CREATE TABLE \`${requestBody.extraConfig.tableSubName}${
                    requestBody.extraConfig.tableName
                }\` (\`id\` INT AUTO_INCREMENT NOT NULL, ${columnList.join(", ")}, PRIMARY KEY (\`id\`))`;
                
                let res: any = await this.executeQuery(createTableQuery);
                if (!res.status) {
                    response.status = false;
                    response.error = res.error;
                }
            }
            resolve(response);
        });
    }

    static async getColumnList(config: any): Promise<any[]> {
        return new Promise(async (resolve) => {
            let columns = [];
            let ignoreColumn = [];

            // if (config?.connections?.length) {
            //     for (let c of config.connections) {
            //         if (c?.target?.ColumnName && c?.target?.TableName && c?.target?.ConnectionID) {
            //             ignoreColumn.push({
            //                 TableName: c.target.TableName,
            //                 ColumnName: c.target.ColumnName,
            //                 ConnectionID: c.target.ConnectionID
            //             });
            //         }
            //     }
            // }
            if (config?.tables?.length) {
                for (let t of config.tables) {
                    if (t?.columns?.length) {
                        for (let c of t.columns) {
                            // if (!ignoreColumn.find(e => e.TableName == t.TableName && e.ColumnName == c.ColumnName && e.ConnectionID == c.ConnectionID)) {
                                let dataSet = c;
                                dataSet['connectorId'] = t.connectionId;
                                columns.push(dataSet);
                            // }
                        }
                    }
                }
            }
            resolve(columns);
        });
    }

    static async executeQuery(query): Promise<any> {
        return new Promise(async (resolve) => {
            const response = { status: false, error: null };
            // Get the existing connection
            const connection: DataSource = dataSource.manager.connection;

            // Create a new query runner
            const queryRunner = connection.createQueryRunner();

            // Connect to the database
            await queryRunner.connect();

            // Start a new transaction
            await queryRunner.startTransaction();

            try {
                // Run the SQL query to create a new table
                await queryRunner.query(query);

                // Commit the transaction
                await queryRunner.commitTransaction();
                console.log("Query executed successfully");
                response.status = true;
            } catch (error) {
                console.log("Query executed error", error);
                if (error?.sqlMessage) {
                    response.error = error.sqlMessage;
                }
                // If there's an error, roll back the transaction
                await queryRunner.rollbackTransaction();
            } finally {
                // Release the query runner
                await queryRunner.release();
                resolve(response);
            }
        });
    }
}
