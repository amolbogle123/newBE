import { DataSource } from "typeorm";
import Container from "typedi";
import lodash from "lodash";
import { dataSource } from "core/data-source";
import dbService from "../../../services/db.service";
import {
    DataRelationBuilder,
    DataRelationBuilderHistory,
    WidgetAccount,
} from "../../../entities";
import { ConnectorsUtil } from "../../../utils/connectors.util";
import { DataRelationService } from "./data-relation.service";
import moment from "moment";

export class DataGenerateService {
    static async generateTableData(
        dataRelationId,
        clientId,
        tableName,
        relationConfig,
        fnConfig: any = {}
    ): Promise<any> {
        return new Promise(async (resolve) => {
            const { extraConfig, config, syncConfig, syncMetaConfig } =
                relationConfig;
            fnConfig.syncMetaConfig = syncMetaConfig;

            let response = {
                status: true,
                data: [],
                tableData: [],
                calculateColumns: [],
                lastEntryDetails: null,
                error: null,
            };

            try {
                if (extraConfig?.apiConnectorDetail?.length) {
                    for (let t of config.tables) {
                        const findAPIDetail =
                            extraConfig.apiConnectorDetail.find(
                                (a) => a.connectorId === t.connectionId
                            );
                        if (findAPIDetail) {
                            t.dataPath = findAPIDetail.dataPath;
                        }
                    }
                }

                let calculateColumns = await DataRelationService.getColumnList(
                    config
                );
                response.calculateColumns = calculateColumns;
                let tableData = await this.getAllTableData(
                    config.tables,
                    calculateColumns,
                    fnConfig
                );
                if (tableData) {
                    response.tableData = tableData;

                    for (let c of config.connections) {
                        if (c?.target?.ConnectionID) {
                            let contSpit = c.target.ConnectionID.split("-");
                            contSpit.pop();
                            if (contSpit.length > 0) {
                                c.target.connectorId = contSpit.join("-");
                            }
                        }
                        if (c?.source?.ConnectionID) {
                            let contSpit = c.source.ConnectionID.split("-");
                            contSpit.pop();
                            if (contSpit.length > 0) {
                                c.source.connectorId = contSpit.join("-");
                            }
                        }
                    }
                    let joinedData: any = await this.generateJoinData(
                        config.connections,
                        tableData,
                        extraConfig?.allData
                    );
                    joinedData = await this.removeConIdAndTableName(joinedData);

                    response.data = joinedData;

                    if (fnConfig?.isInsertData && joinedData?.length) {
                        const executionResult = await this.executeInsertQuery(
                            tableName,
                            calculateColumns,
                            joinedData
                        );
                        if (executionResult?.error?.length) {
                            response.error = executionResult.error;
                        } else {
                            response.lastEntryDetails =
                                await this.createSyncMetaConfig(
                                    tableData,
                                    syncConfig
                                );
                        }
                    }
                }
            } catch (error) {
                console.error("error", error);
            } finally {
                if (!fnConfig?.skipHistory) {
                    await this.createHistory(
                        dataRelationId,
                        clientId,
                        response?.data?.length,
                        response?.error
                    );
                }

                let updateData: any = {
                    isSyncData: 1,
                };
                if (response.lastEntryDetails) {
                    updateData.syncMetaConfig = JSON.stringify({
                        lastEntryDetails: response.lastEntryDetails,
                    });
                }
                await dataSource
                    .getRepository(DataRelationBuilder)
                    .update({ id: dataRelationId }, updateData);
                resolve(response);
            }

            resolve(response);
        });
    }

    static async createHistory(
        dataRelationId,
        clientId,
        totalRecord,
        errorResponse
    ) {
        let insertData = {
            relationId: dataRelationId,
            clientId: clientId,
            status: "failedProcess",
            executionConfig: JSON.stringify({
                totalInsertRecords: totalRecord,
                errors: errorResponse,
            }),
        };
        if (!errorResponse?.length) {
            insertData.status = "completedProcess";
        }
        return dataSource
            .getRepository(DataRelationBuilderHistory)
            .insert(insertData);
    }

    static async createSyncMetaConfig(tableData, syncConfig) {
        return new Promise(async (resolve) => {
            let response = { lastEntryDetails: [] };
            for (let t of tableData) {
                let lastDataSet = {
                    tableName: t.TableName,
                    connectionId: t.connectorId,
                    lastData: null,
                };

                if (t?.TableData?.length && syncConfig?.tableDetails?.length) {
                    let lastData = t.TableData[t.TableData.length - 1];

                    let row: any = {};
                    for (let key in lastData) {
                        let columnName: string = await this.findColumnName(key);
                        row[columnName] = lastData[key];
                    }

                    let findTableSyncConfig = syncConfig.tableDetails.find(
                        (s) =>
                            s.tableName === lastDataSet.tableName &&
                            s.connectionId === lastDataSet.connectionId
                    );
                    if (
                        findTableSyncConfig?.primaryField &&
                        row[
                            `${findTableSyncConfig.tableName}_${findTableSyncConfig.primaryField}`
                        ]
                    ) {
                        lastDataSet.lastData = {};
                        lastDataSet.lastData[findTableSyncConfig.primaryField] =
                            row[
                                `${findTableSyncConfig.tableName}_${findTableSyncConfig.primaryField}`
                            ];
                    }
                    if (
                        findTableSyncConfig?.autoIncrementField &&
                        row[
                            `${findTableSyncConfig.tableName}_${findTableSyncConfig.autoIncrementField}`
                        ]
                    ) {
                        if (lastDataSet.lastData === null) {
                            lastDataSet.lastData = {};
                        }
                        lastDataSet.lastData[
                            findTableSyncConfig.autoIncrementField
                        ] =
                            row[
                                `${findTableSyncConfig.tableName}_${findTableSyncConfig.autoIncrementField}`
                            ];
                    }
                }

                response.lastEntryDetails.push(lastDataSet);
            }
            resolve(response);
        });
    }

    static async removeConIdAndTableName(data: []) {
        return new Promise(async (resolve) => {
            let result: any[] = [];

            for (let r of data) {
                let e: any = r;
                let row: any = {};
                for (let key in e) {
                    let columnName: string = await this.findColumnName(key);

                    row[columnName] = e[key];
                }
                result.push(row);
            }

            resolve(result);
        });
    }

    static async findColumnName(key): Promise<any> {
        return new Promise(async (resolve) => {
            let keySplit = key.split("|");
            let name = `${keySplit[keySplit.length - 2]}_${
                keySplit[keySplit.length - 1]
            }`;

            resolve(name);
        });
    }

    static async executeInsertQuery(
        tableName,
        calculateColumns,
        joinedData
    ): Promise<any> {
        return new Promise(async (resolve) => {
            const response = { status: false, error: [], data: [] };
            // Get the existing connection
            const connection: DataSource = dataSource.manager.connection;

            // Create a new query runner
            const queryRunner = connection.createQueryRunner();

            // Connect to the database
            await queryRunner.connect();

            try {
                for (let j of joinedData) {
                    let columns = calculateColumns
                        .map(
                            (column) =>
                                `\`${column.TableName}_${column.ColumnName}\``
                        )
                        .join(", ");
                    let values = [];
                    calculateColumns.forEach((e: any) => {
                        if (e?.DataType.includes("timestamp")) {
                            if (j[`${e.TableName}_${e.ColumnName}`]) {
                                let currentTime = moment(
                                    j[`${e.TableName}_${e.ColumnName}`]
                                ).format();
                                values.push(`"${currentTime}"`);
                            } else {
                                values.push(`NULL`);
                            }
                        } else if (e?.DataType.includes("int")) {
                            if (
                                typeof j[`${e.TableName}_${e.ColumnName}`] ==
                                "number"
                            ) {
                                values.push(
                                    j[`${e.TableName}_${e.ColumnName}`]
                                );
                            } else {
                                values.push(`NULL`);
                            }
                        } else if (j[`${e.TableName}_${e.ColumnName}`]) {
                            const columnName = `${e.TableName}_${e.ColumnName}`;
                            values.push(`'${j[columnName]}'`);
                        } else {
                            values.push(`""`);
                        }
                    });

                    let inserQuery =
                        "INSERT INTO " +
                        tableName +
                        "(" +
                        columns +
                        ") VALUES (" +
                        values.join(",") +
                        ")";

                    // Run the SQL query to create a new table
                    const insertResult = await queryRunner.query(inserQuery);
                    if (insertResult?.insertId) {
                        response.data.push(insertResult.insertId);
                    }
                }

                response.status = true;
            } catch (error) {
                console.error("Query executed error", error);
                if (error?.sqlMessage) {
                    response.error.push(error.sqlMessage);
                }
            } finally {
                // Release the query runner
                await queryRunner.release();
                resolve(response);
            }
        });
    }

    static async getView360TableDetail(query): Promise<any> {
        return new Promise(async (resolve) => {
            const response = { status: false, data: null, error: null };
            // Get the existing connection
            const connection: DataSource = dataSource.manager.connection;

            // Create a new query runner
            const queryRunner = connection.createQueryRunner();

            // Connect to the database
            await queryRunner.connect();

            try {
                // Run the SQL query to create a new table
                response.data = await queryRunner.query(query);

                console.log("Query executed successfully");
                response.status = true;
            } catch (error) {
                console.error("Query executed error", error);
                if (error?.sqlMessage) {
                    response.error = error.sqlMessage;
                }
            } finally {
                // Release the query runner
                await queryRunner.release();
                resolve(response);
            }
        });
    }

    static async getAllTableData(
        lTables: any[],
        columns: any[],
        fnConfig: any = {}
    ): Promise<any[]> {
        const result = [];
        return new Promise(async (resolve) => {
            const tables: any = await this.getTableFromColumns(
                columns,
                lTables
            );
            for (let i = 0; i < tables.length; i++) {
                const dataConfig = {
                    schemaType: tables[i].schemaType,
                    dataPath: tables[i]?.dataPath || null,
                };
                const tableData = await this.getTableData(
                    tables[i].connectorId,
                    tables[i].TableName,
                    dataConfig,
                    fnConfig
                );
                result.push({
                    TableName: tables[i].TableName,
                    TableData: tableData,
                    connectorId: tables[i].connectorId,
                });
            }
            resolve(result);
        });
    }

    static getTableFromColumns(columns: any[], tables: any[]) {
        let result: any[] = [];
        return new Promise(async (resolve) => {
            columns.forEach((c) => {
                const t = tables.find(
                    (e) =>
                        e.name === c.TableName &&
                        e.connectionId === c.connectorId
                );
                if (
                    t &&
                    !result.some(
                        (e) =>
                            e.TableName === t.name &&
                            e.connectorId === t.connectionId
                    )
                ) {
                    result.push({
                        connectorId: t.connectionId,
                        TableName: t.name,
                        dataPath: t?.dataPath || null,
                        schemaType: t?.schemaType,
                    });
                }
            });
            resolve(result);
        });
    }

    static async getTableData(
        id: any,
        tableName: string,
        dataConfig: any,
        fnConfig = {}
    ) {
        return new Promise(async (resolve) => {
            let rowList = [];

            let result: any = [];
            // console.log(
            //     "dataConfig---->>>>>>>>>>",
            //     JSON.stringify(dataConfig, null, 2)
            // );
            // console.log("tableName---->>>>>>>>>>", tableName);
            // console.log("id---->>>>>>>>>>", id);
            // console.log(
            //     "fnConfig---->>>>>>>>>>",
            //     JSON.stringify(fnConfig, null, 2)
            // );
            if (["API"].includes(dataConfig?.schemaType)) {
                let whereCondition = { id: id };
                const widgetResult = await dbService._findQueryService(
                    Container.get(DataSource).getRepository(WidgetAccount),
                    { where: whereCondition }
                );
                if (widgetResult?.length && widgetResult[0]?.config) {
                    let config = JSON.parse(widgetResult[0].config);
                    const APIResults =
                        await ConnectorsUtil.apiConnectorWithConfig(config);
                    if (APIResults?.status && APIResults?.data) {
                        result = {
                            status: true,
                            data: [],
                        };
                        if (dataConfig?.dataPath) {
                            let apiData = lodash.get(
                                APIResults.data,
                                dataConfig.dataPath
                            );
                            if (apiData) {
                                result.data = apiData;
                            }
                        } else {
                            result.data = APIResults.data;
                        }
                    }
                }
            } else if (id === "DATA_MIGRATION") {
                let query = await this.buildQuery(id, tableName, fnConfig);
                result = await this.getView360TableDetail(query);
            } else {
                let query = await this.buildQuery(id, tableName, fnConfig);
                result = await ConnectorsUtil.connect(id, query, null);
            }
            // console.log("result", JSON.stringify(result, null, 2));
            if (result?.status && result?.data?.length) {
                rowList = result.data;
            }
            rowList = this.addConIdAndTableNameWithColName(
                rowList,
                id,
                tableName
            );
            resolve(rowList);
        });
    }

    static buildQuery(id, tableName, fnConfig) {
        return new Promise((resolve) => {
            let query = `SELECT * FROM ${tableName}`;
            if (
                fnConfig?.syncType === "syncNewlyData" &&
                fnConfig?.syncTableConfig?.length &&
                fnConfig?.syncMetaConfig?.lastEntryDetails?.length
            ) {
                let findTableDetails = fnConfig.syncTableConfig.find(
                    (e) => e.connectionId === id && e.tableName === tableName
                );
                let findLastData =
                    fnConfig.syncMetaConfig.lastEntryDetails.find(
                        (e) =>
                            e?.connectionId === id &&
                            e?.tableName === tableName &&
                            e?.lastData
                    );
                if (findLastData && findTableDetails) {
                    if (
                        findTableDetails?.primaryField &&
                        findTableDetails?.primaryFieldType === "int" &&
                        findTableDetails?.autoIncrementField ===
                            findTableDetails.primaryField &&
                        findLastData?.lastData &&
                        findLastData.lastData[findTableDetails.primaryField]
                    ) {
                        query += ` WHERE ${findTableDetails.primaryField} > ${
                            findLastData.lastData[findTableDetails.primaryField]
                        } ORDER BY ${findTableDetails.primaryField} ASC`;
                    }
                }
            }
            resolve(query);
        });
    }

    static addConIdAndTableNameWithColName(
        data: any[],
        conId: number,
        tableName: string
    ) {
        return data.map((e) => {
            let row: any = {};
            for (let key in e) {
                if (e.hasOwnProperty(key)) {
                    const colName = `c${conId}|${tableName}|${key}`;
                    row[colName] = e[key];
                }
            }
            return row;
        });
    }

    static generateJoinData(
        connections: any,
        tables: any,
        allData: boolean
    ): Promise<any[]> {
        let joinedData = [];
        return new Promise(async (resolve) => {
            if (tables.length > 1) {
                let groupedConnections = this.groupMultipleCondtions(
                    connections,
                    tables
                );
                let table = tables.find(
                    (e: any) =>
                        e.connectorId ==
                            groupedConnections[0][0].source.connectorId &&
                        e.TableName == groupedConnections[0][0].source.TableName
                );

                joinedData = await this.innerJoinData(
                    groupedConnections,
                    table,
                    tables,
                    allData
                );
            } else {
                joinedData = tables[0].TableData;
            }
            resolve(joinedData);
        });
    }

    static groupMultipleCondtions(connections: any[], connectedTables: any[]) {
        let results: any[] = [];
        connections.forEach((e) => {
            if (
                !this.isAlreadyGrouped(e, results) &&
                this.isTableIsInQuery(connectedTables, e)
            ) {
                results.push(
                    connections.filter(
                        (item) =>
                            e.target.TableName === item.target.TableName &&
                            e.source.TableName === item.source.TableName &&
                            e.target.ConnectionID ===
                                item.target.ConnectionID &&
                            e.source.ConnectionID === item.source.ConnectionID
                    )
                );
            }
        });
        return results;
    }

    static isTableIsInQuery(connectedTables, connection: any) {
        return connectedTables.some(
            (e) =>
                (e.TableName === connection.source.TableName &&
                    e.connectorId === connection.source.connectorId) ||
                (e.name === connection.target.TableName &&
                    e.connectorId === connection.target.connectorId)
        );
    }

    static isAlreadyGrouped(connection: any, groupedArray: any[] = []) {
        return groupedArray.some(
            (e) =>
                e[0].target.TableName === connection.target.TableName &&
                e[0].source.TableName === connection.source.TableName &&
                e[0].target.ConnectionID === connection.target.connectorId &&
                e[0].source.ConnectionID === connection.source.connectorId
        );
    }

    static innerJoinData(
        groupedConnections: any[],
        sourceTable: any,
        tables: any[],
        allData: boolean
    ): Promise<any[]> {
        return new Promise(async (resolve) => {
            let isAlreadyJoined: any[] = [];
            let joinedData: any[] = sourceTable.TableData;
            isAlreadyJoined.push(
                `${sourceTable.connectorId}_${sourceTable.TableName}`
            );
            joinedData = await this.innerJoinRecursive(
                joinedData,
                groupedConnections,
                sourceTable,
                tables,
                isAlreadyJoined,
                allData
            );

            resolve(joinedData);
        });
    }

    static findConditionsNotAdded(groupedConnections) {
        return groupedConnections.filter((e) => !e[0].isAlreadyJoined);
    }

    static innerJoinRecursive(
        joinedData,
        groupedConnections,
        sourceTable,
        tables,
        isAlreadyJoined,
        allData
    ): Promise<any[]> {
        return new Promise(async (resolve) => {
            let conditionsTableAsSource = this.getConditionsTableAsSource(
                groupedConnections,
                sourceTable
            );
            for (let con of conditionsTableAsSource) {
                con[0].isAlreadyJoined = true;

                if (this.isAnyColumnSelectedFromTheTable(tables, con[0])) {
                    let targetTableName = `${con[0].target.connectorId}_${con[0].target.TableName}`;
                    let tableToJoin = tables.find(
                        (e) =>
                            e.connectorId == con[0].target.connectorId &&
                            e.TableName == con[0].target.TableName
                    ).TableData;
                    let sourceTableAlreadyJoined = false;
                    if (isAlreadyJoined.some((e) => e == targetTableName)) {
                        targetTableName = `${con[0].source.connectorId}_${con[0].source.TableName}`;
                        tableToJoin = tables.find(
                            (e) =>
                                e.connectorId == con[0].source.connectorId &&
                                e.TableName == con[0].source.TableName
                        ).TableData;
                        sourceTableAlreadyJoined = true;
                        if (isAlreadyJoined.some((e) => e == targetTableName)) {
                            targetTableName = "";
                        }
                    }
                    if (sourceTableAlreadyJoined) {
                        joinedData = this.innerJoin(
                            tableToJoin,
                            joinedData,
                            con,
                            allData
                        );
                    } else {
                        joinedData = this.innerJoin(
                            joinedData,
                            tableToJoin,
                            con,
                            allData
                        );
                    }
                    if (targetTableName) {
                        isAlreadyJoined.push(targetTableName);
                    }
                }
            }

            groupedConnections =
                this.findConditionsNotAdded(groupedConnections);
            if (groupedConnections.length) {
                sourceTable = groupedConnections[0][0].source;
                joinedData = await this.innerJoinRecursive(
                    joinedData,
                    groupedConnections,
                    sourceTable,
                    tables,
                    isAlreadyJoined,
                    allData
                );
            }

            resolve(joinedData);
        });
    }

    static innerJoin(
        array1: any[],
        array2: any[],
        conditions: any[],
        allData: boolean
    ) {
        var results = [];

        let insertArray1Key = [];
        let insertArray2Key = [];
        for (var i = 0; i < array1.length; i++) {
            for (var j = 0; j < array2.length; j++) {
                let isMatch = false;
                for (var k = 0; k < conditions.length; k++) {
                    isMatch = false;

                    if (
                        array1[i][
                            `c${conditions[k].source.connectorId}|${conditions[k].source.TableName}|${conditions[k].source.ColumnName}`
                        ] ===
                        array2[j][
                            `c${conditions[k].target.connectorId}|${conditions[k].target.TableName}|${conditions[k].target.ColumnName}`
                        ]
                    ) {
                        isMatch = true;
                    } else {
                        break;
                    }
                }
                if (isMatch) {
                    results.push({ ...array1[i], ...array2[j] });
                    insertArray1Key.push(i);
                    insertArray2Key.push(j);
                }
            }
        }

        if (allData) {
            if (insertArray1Key.length < array1.length) {
                let array2Columns = {};
                Object.keys(array2[0]).forEach((key) => {
                    array2Columns[key] = null;
                });
                array1.forEach((e, k1) => {
                    if (!insertArray1Key.includes(k1)) {
                        results.push(Object.assign({ ...e }, array2Columns));
                    }
                });
            }
            if (insertArray2Key.length < array2.length) {
                let array1Columns = {};
                Object.keys(array1[0]).forEach((key) => {
                    array1Columns[key] = null;
                });
                array2.forEach((e, k2) => {
                    if (!insertArray2Key.includes(k2)) {
                        results.push(Object.assign({ ...e }, array1Columns));
                    }
                });
            }
        }
        return results;
    }

    static isAnyColumnSelectedFromTheTable(
        connectedTables: any[],
        connection: any
    ) {
        return (
            connectedTables.some(
                (e) =>
                    e.TableName === connection.target.TableName &&
                    e.connectorId === connection.target.connectorId
            ) &&
            connectedTables.some(
                (e) =>
                    e.TableName === connection.source.TableName &&
                    e.connectorId === connection.source.connectorId
            )
        );
    }

    static getConditionsTableAsSource(groupedConnections: any[], table: any) {
        return groupedConnections.filter(
            (e) =>
                e[0].source.TableName === table.TableName &&
                e[0].source.connectorId === table.connectorId
        );
    }
}
