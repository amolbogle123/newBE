import { DataGenerateService } from "./data-generate.service";
import { ConnectorsUtil } from "../../../utils/connectors.util";
import { chunk } from "lodash";
import { dataSource } from "core/data-source";
import { DataSource } from "typeorm";
import { DataRelationBuilder } from "../../../entities";

export class DataSyncService {
    static async getSyncConfig(tableConfig) {
        return new Promise(async (resolve) => {
            let response = { tableDetails: [] };
            for (let t of tableConfig) {
                let dataSet = {
                    connectionId: t?.connectionId,
                    schemaType: t?.schemaType,
                    tableName: t?.name,
                    primaryField: null,
                    primaryFieldType: null,
                    autoIncrementField: null,
                };

                let result: any = null;
                if (t?.connectionId === "DATA_MIGRATION") {
                    result = await this.executeQuery(
                        `SHOW COLUMNS FROM ${t.name}`
                    );
                } else if (
                    t?.schemaType === "mySql" &&
                    t?.connectionId &&
                    t?.name
                ) {
                    result = await ConnectorsUtil.connect(
                        t.connectionId,
                        `SHOW COLUMNS FROM ${t.name}`,
                        null
                    );
                }
                if (result?.status && result?.data?.length) {
                    const findPrimaryKey = result.data.find(
                        (e) => e?.Key === "PRI"
                    );
                    if (findPrimaryKey?.Field) {
                        dataSet.primaryField = findPrimaryKey.Field;
                        dataSet.primaryFieldType = findPrimaryKey.Type;
                    }
                    const findIncrementKey = result.data.find(
                        (e) => e?.Extra === "auto_increment"
                    );
                    if (findIncrementKey?.Field) {
                        dataSet.autoIncrementField = findIncrementKey.Field;
                    }
                }
                response.tableDetails.push(dataSet);
            }
            resolve(response);
        });
    }

    static async startSyncData(
        syncType,
        relationResult,
        syncTableConfig,
        clientId
    ): Promise<any> {
        return new Promise(async (resolve) => {
            const response = {
                status: true,
                data: [],
                calculateColumns: [],
                error: null,
            };

            try {
                const getAllData = await DataGenerateService.generateTableData(
                    relationResult.id,
                    clientId,
                    relationResult.extraConfig?.tableName,
                    relationResult,
                    {
                        isInsertData: false,
                        skipHistory: true,
                        syncType: syncType,
                        syncTableConfig: syncTableConfig,
                    }
                );
                response.data = getAllData?.data || [];
                response.calculateColumns = getAllData?.calculateColumns || [];

                if (response.data?.length) {
                    let totalInsertData = 0;
                    let totalError = [];
                    const insertResult = await this.findNewDataWithRelation(
                        relationResult,
                        syncTableConfig,
                        response.data,
                        response.calculateColumns
                    );
                    if (insertResult?.data?.length) {
                        totalInsertData = insertResult.data.length;
                    }
                    if (insertResult?.error?.length) {
                        totalError = insertResult.error;
                    }
                    // console.log(
                    //     "insertResult-----findNewDataWithRelation",
                    //     JSON.stringify(insertResult, null, 2)
                    // );
                    await DataGenerateService.createHistory(
                        relationResult.id,
                        clientId,
                        totalInsertData,
                        totalError
                    );

                    if (!insertResult?.error?.length) {
                        const lastEntryResult: any =
                            await DataGenerateService.createSyncMetaConfig(
                                getAllData?.tableData || [],
                                { tableDetails: syncTableConfig }
                            );
                        if (lastEntryResult?.lastEntryDetails) {
                            let params = {
                                syncMetaConfig: JSON.stringify(lastEntryResult),
                            };
                            await dataSource
                                .getRepository(DataRelationBuilder)
                                .update({ id: relationResult.id }, params);
                        }
                    }
                }
            } catch (error) {
            } finally {
                resolve(response);
            }
        });
    }

    static async findNewDataWithRelation(
        relationResult,
        syncTableConfig,
        getAllData,
        calculateColumns
    ): Promise<any> {
        return new Promise(async (resolve) => {
            let response = { status: true, data: [], error: [] };
            let matchColumns = [];
            let tableName = null;
            if (
                relationResult?.extraConfig?.tableSubName &&
                relationResult?.extraConfig?.tableName
            ) {
                tableName = `${relationResult?.extraConfig?.tableSubName}${relationResult.extraConfig.tableName}`;
            }

            if (
                syncTableConfig?.length &&
                syncTableConfig[0].uniqueColumn &&
                syncTableConfig[0].tableName
            ) {
                matchColumns.push(
                    `${syncTableConfig[0].tableName}_${syncTableConfig[0].uniqueColumn}`
                );
            }

            let chunkAllData = chunk(getAllData, 10);
            for (let dataSet of chunkAllData) {
                let selectField = [];
                let whereCondition = [];
                for (let c of matchColumns) {
                    let findVal = dataSet
                        .map((d) => `${d[c]}`)
                        .filter((d) => d);
                    whereCondition.push(`${c} IN ('${findVal.join("','")}')`);
                    selectField.push(c);
                }
                if (dataSet.length) {
                    const insertResult: any = await this.findAndInsert(
                        tableName,
                        dataSet,
                        selectField,
                        whereCondition,
                        calculateColumns
                    );
                    if (insertResult?.data?.length) {
                        response.data = response.data.concat(insertResult.data);
                    }
                    if (insertResult?.error?.length) {
                        response.error = response.error.concat(
                            insertResult.error
                        );
                    }
                }
            }

            resolve(response);
        });
    }

    static async findAndInsert(
        tableName,
        dataSet,
        selectField,
        whereCondition,
        calculateColumns
    ) {
        return new Promise(async (resolve) => {
            let response = { status: false, data: null, error: null };
            try {
                let query = `SELECT ${selectField.join(
                    ", "
                )} FROM ${tableName}`;
                if (whereCondition?.length) {
                    query += ` WHERE ${whereCondition.join(" OR ")}`;
                }
                let oldInsertData = [];
                // Run the SQL query to create a new table
                const result: any = await this.executeQuery(query);
                if (result?.status && result?.data?.length) {
                    oldInsertData = result.data;
                }
                let findNewEntry = dataSet.filter(
                    (d) =>
                        !oldInsertData.find((r) => {
                            let isMatch = true;
                            for (let s of selectField) {
                                if (d[s] !== r[s]) {
                                    isMatch = false;
                                    break;
                                }
                            }
                            return isMatch;
                        })
                );
                if (findNewEntry?.length) {
                    response = await DataGenerateService.executeInsertQuery(
                        tableName,
                        calculateColumns,
                        findNewEntry
                    );
                }
            } catch (error) {
            } finally {
                resolve(response);
            }
        });
    }

    static async executeQuery(query) {
        return new Promise(async (resolve) => {
            const response = { status: false, data: null, error: null };
            // Get the existing connection
            const connection: DataSource = dataSource.manager.connection;

            // Create a new query runner
            const queryRunner = connection.createQueryRunner();

            // Connect to the database
            await queryRunner.connect();
            try {
                // Run the SQL query to create a new table
                response.data = await queryRunner.query(query);
                response.status = true;
            } catch (error) {
            } finally {
                // Release the query runner
                await queryRunner.release();

                resolve(response);
            }
        });
    }
}
