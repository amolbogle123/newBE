import { ApiErrorResponse, CommonHelper } from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import { DataRelationBuilder, DataRelationBuilderHistory, PublicTables, WidgetAccount } from "../../../entities";
import { ConnectorHelper } from "../../../utils/helpers/connector.helper";
import Container from 'typedi';
import lodash from "lodash";
import { DataSource, In } from 'typeorm';
import { dataSource } from "../../../core/data-source";
import { Body, Controller, Get, Post, Query, Request, Route, Security, Tags, Path, Put, Delete } from "tsoa";
import { DatabaseListResponse, DeleteRelation, AllListResponse, DeleteResponse, InsertRelationRequest, DetailsResponse, SaveResponse, UpdateRelationRequest, UpdateResponse, TableDetails, TableResponse, SyncDataRelationRequest } from "../doc/relation-builder-interface";
import { CommonUtil } from "utils/common.util";
import { ConnectorsUtil } from "utils/connectors.util";
import { DataRelationService } from "../services/data-relation.service";
import { DataGenerateService } from "../services/data-generate.service";
import { DataSyncService } from "../services/data-sync.service";

@Route('')
@Tags('Data Relation Builder/CRUD')
export class DataRelationBuilderController extends Controller {

    @Security('bearerAuth')
    @Get('data-relation-builder')
    async getRelationList(
        @Request() request: any,
        @Query('page') page: number = 1,
        @Query('pageSize') pageSize: number = 10,
        @Query('sortOrder') sortOrder?: number,
        @Query('sortField') sortField?: string,
        @Query('filters') filters?: string
    ): Promise<DatabaseListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };
            let whereCondition = { clientId: request.userDetails.client_id };

            whereCondition = await CommonUtil.applyFilter(filters, whereCondition);

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject['createdOn'] = sortOrder;
            }


            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(DataRelationBuilder),
                {
                    where: whereCondition,
                }
            );

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(DataRelationBuilder),
                {
                    where: whereCondition,  // Use queryObj directly instead of spreading it
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                },
            );

            if (results?.length > 0) {
                apiResponse.data = results;
                apiResponse.recordsTotal = totalRecordCount;
                apiResponse.recordsFiltered = totalRecordCount;
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('data-relation-builder/history/:relationId')
    async getRelationHistoryList(
        @Path() relationId: string,
        @Request() request: any,
        @Query('page') page: number = 1,
        @Query('pageSize') pageSize: number = 10,
        @Query('sortOrder') sortOrder?: number,
        @Query('sortField') sortField?: string,
        @Query('filters') filters?: string
    ): Promise<DatabaseListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };
            let whereCondition = { clientId: request.userDetails.client_id, relationId: relationId };

            whereCondition = await CommonUtil.applyFilter(filters, whereCondition);

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject['createdOn'] = sortOrder;
            }

            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(DataRelationBuilderHistory),
                {
                    where: whereCondition,
                }
            );
            
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(DataRelationBuilderHistory),
                {
                    where: whereCondition,  // Use queryObj directly instead of spreading it
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                },
            );

            if (results?.length > 0) {
                apiResponse.data = results;
                apiResponse.recordsTotal = totalRecordCount;
                apiResponse.recordsFiltered = totalRecordCount;
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('data-relation-builder/table-list/:widgetId')
    async getAllTableList(
        @Path() widgetId: string,
        @Request() request: any,
    ): Promise<AllListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                dbName: null,
            };
            let whereCondition = { clientId: request.userDetails.client_id, id: widgetId };
            const widgetResult = await dbService._findQueryService(
                Container.get(DataSource).getRepository(WidgetAccount),
                {
                    where: whereCondition,
                },
            );
            
            if (widgetResult?.length && widgetResult[0]?.config) {
                let config = JSON.parse(widgetResult[0].config);
                
                if (widgetResult[0].widgetType === "API") {
                    apiResponse.data.push({TABLE_NAME: widgetResult[0].accountName});
                } else if (widgetResult[0].widgetType === "MYSQL") {
                    if (config?.dbName) {
                        apiResponse.dbName = config.dbName;
                        let query = "SELECT table_name FROM information_schema.tables WHERE table_schema = '"+config.dbName+"';";
                        const results = await ConnectorHelper.connect(widgetId, query);
                        if (results?.status == 'success' && results?.data?.length) {
                            apiResponse.data = results.data;
                        }
                    }
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security('bearerAuth')
    @Get('data-relation-builder/table-column/:widgetId/:tableName')
    async getAllTableNameList(
        @Path() widgetId: string,
        @Path() tableName: string,
        @Request() request: any,
    ): Promise<AllListResponse | unknown> {
        try {
            const apiResponse = {
                data: {
                    schema: null,
                    schemaType: "mySql",
                    columnList: [],
                }
            };

            let whereCondition = { clientId: request.userDetails.client_id, id: widgetId };
            const widgetResult = await dbService._findQueryService(
                Container.get(DataSource).getRepository(WidgetAccount),
                {
                    where: whereCondition,
                },
            );
            
            if (widgetResult?.length && widgetResult[0]?.config) {
                let config = JSON.parse(widgetResult[0].config);
                if (widgetResult[0].widgetType === "API") {
                    apiResponse.data.schemaType = "API";
                    const results = await ConnectorsUtil.apiConnectorWithConfig(config);
                    
                    if (results?.status && results?.data) {
                        let dataSet = [];
                        if (request?.query?.dataPath) {
                            let apiData = lodash.get(results.data, request.query.dataPath);
                            if (apiData?.length) {
                                dataSet = apiData[0];
                            }
                        } else if (results.data?.length) {
                            dataSet = results.data[0];
                        }
                        let keys = Object.keys(dataSet);
                        keys.forEach((c) => {
                            let dataType = {
                                name: c,
                                type: "text",
                                generateDataType: "string"
                            };

                            if (dataSet[c] && typeof dataSet[c] === "number") {
                                dataType.generateDataType = "number";
                                dataType.type = "int";
                            }
                            apiResponse.data.columnList.push(dataType);
                        });
                    }
                } else if (widgetResult[0].widgetType === "MYSQL") {
                    let query = `SHOW COLUMNS FROM ${tableName}`;
                    const results = await ConnectorHelper.connect(widgetId, query);
                    if (results?.status == 'success' && results?.data?.length) {
                        apiResponse.data.columnList = results.data.map((c) => {
                            return {
                                name: c.Field,
                                type: c.Type,
                                generateDataType: ["int", "float", "double", "bigint", "decimal"].indexOf(c.Type.toLowerCase()) > -1 ? "number" : "string",
                            }
                        });
                    }
                }
            }
            
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('data-relation-builder/all-list')
    async getRelationAllList(
        @Request() request: any,
    ): Promise<AllListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(DataRelationBuilder),
                {
                    where: { clientId: request.userDetails.client_id },
                    order: { createdOn: 'DESC' },
                },
            );

            if (results?.length > 0) {
                apiResponse.data = results;
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('data-relation-builder/get-tables-rows')
    async getTableRows(
        @Body() requestBody: TableDetails,
        @Request() request: any
    ): Promise<TableResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };

            if (requestBody?.tables?.length) {
                for (let t of requestBody.tables) {
                    const dataConfig = {
                        schemaType: t?.schemaType,
                        dataPath: t?.dataPath
                    };
                    const tableList: any = await DataGenerateService.getTableData(t.connectionId, t.name, dataConfig);
                    apiResponse.data.push(Object.assign({totalRows: tableList?.length || 0}, t));
                }
            }
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('data-relation-builder')
    async saveRelation(
        @Body() requestBody: InsertRelationRequest,
        @Request() request: any
    ): Promise<SaveResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            const dataRelationBuilder = new DataRelationBuilder();
            dataRelationBuilder.clientId = request.userDetails.client_id;
            dataRelationBuilder.config = JSON.stringify(requestBody.config);
            dataRelationBuilder.name = requestBody.name;
            dataRelationBuilder.connectorId = requestBody.connectorId;
            dataRelationBuilder.createdBy = request.userDetails.id;
            dataRelationBuilder.syncConfig = null;
            dataRelationBuilder.syncMetaConfig = null;

            if (requestBody?.extraConfig?.isMultipleConnector && requestBody?.extraConfig?.tableName) {
                const createTableResult = await DataRelationService.createMigrationTable(requestBody);
                if (createTableResult?.status) {
                    const tableName = `${requestBody.extraConfig.tableSubName}${requestBody.extraConfig.tableName}`;

                    const publicTableModel = new PublicTables();
                    publicTableModel.type = "relationBuilder";
                    publicTableModel.client_id = request.userDetails.client_id;
                    publicTableModel.name = tableName;
    
                    const publicTableResult = await Container.get(DataSource).manager.save(
                        publicTableModel
                    );
                    if (publicTableResult?.id) {
                        requestBody.extraConfig['publicTableId'] = publicTableResult.id;
                    }
                }

                const syncConfig = await DataSyncService.getSyncConfig(requestBody.config.tables);
                dataRelationBuilder.syncConfig = JSON.stringify(syncConfig);
                requestBody.syncConfig = syncConfig;
            }
            dataRelationBuilder.extraConfig = JSON.stringify(requestBody.extraConfig);

            const result = await Container.get(DataSource).manager.save(
                dataRelationBuilder
            );
            if (result?.id) {
                apiResponse.data = { insertedId: result.id };

                if (requestBody?.extraConfig?.isMultipleConnector && requestBody?.extraConfig?.tableName) {
                    const tableName = `${requestBody.extraConfig.tableSubName}${requestBody.extraConfig.tableName}`;
                    DataGenerateService.generateTableData(result.id, request.userDetails.client_id, tableName, requestBody, {isInsertData: true, skipHistory: true});
                }
                this.setStatus(201);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('data-relation-builder/:id')
    async getRelation(
        @Path() id: string,
        @Request() request: any
    ): Promise<DetailsResponse | unknown> {
        try {
            const apiResponse = {
                data: null,
            };
            let result: any = await dataSource
                .getRepository(DataRelationBuilder)
                .findOne({
                    where: {
                        id: id,
                        clientId: request.userDetails.client_id,
                    },
                });
            apiResponse.data = result;

            if (apiResponse.data) {
                if (apiResponse.data["config"]) {
                    apiResponse.data["config"] = JSON.parse(
                        apiResponse.data["config"]
                    );
                } else {
                    apiResponse.data["config"] = {};
                }
                if (apiResponse.data["extraConfig"]) {
                    apiResponse.data["extraConfig"] = JSON.parse(
                        apiResponse.data["extraConfig"]
                    );
                } else {
                    apiResponse.data["extraConfig"] = {};
                }
            } else {
                this.setStatus(204);
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Put('data-relation-builder/:id')
    async updateRelation(
        @Path() id: string,
        @Body() requestBody: UpdateRelationRequest,
        @Request() request: any
    ): Promise<UpdateResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
                data1: []
            };

            let payload: any = {}

            if (requestBody?.name) {
                payload.name = requestBody.name;
            }
            if (requestBody?.connectorId) {
                payload.connectorId = requestBody.connectorId;
            }
            if (requestBody?.config) {
                payload.config = JSON.stringify(requestBody.config);
            }

            if (requestBody?.extraConfig && requestBody?.config?.tables?.length) {
                if (requestBody?.extraConfig?.tableName && requestBody?.extraConfig?.isMultipleConnector) {
                    const tableName = `${requestBody.extraConfig.tableSubName}${requestBody.extraConfig.tableName}`;
                    if (requestBody?.extraConfig?.publicTableId && requestBody?.oldTableName !== tableName) {
                        await dataSource.getRepository(PublicTables).update({ id: requestBody?.extraConfig?.publicTableId }, { name: tableName });
                        await DataRelationService.executeQuery(`RENAME TABLE ${requestBody.oldTableName} TO ${tableName}`);
                    }

                    const syncConfig = await DataSyncService.getSyncConfig(requestBody.config.tables);
                    payload.syncConfig = JSON.stringify(syncConfig);
                }
                payload.extraConfig = JSON.stringify(requestBody.extraConfig);
            }

            const updateResult = await dataSource
                .getRepository(DataRelationBuilder)
                .update({ id: request.params.id }, payload);
            apiResponse.data = updateResult;

            if (!updateResult?.affected) {
                this.setStatus(204);
            } else {
                this.setStatus(200);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Delete('data-relation-builder')
    async deleteRelation(
        @Body() requestBody: DeleteRelation,
        @Request() request: any
    ): Promise<DeleteResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };
            
            const deleteTableDetails = [];
            if (requestBody?.deleteTable) {
                const results = await dbService._findQueryService(
                    Container.get(DataSource).getRepository(DataRelationBuilder),
                    {
                        where: {id: In(requestBody.id)}
                    },
                );
                if (results?.length > 0) {
                    for (let r of results) {
                        let extraConfig = JSON.parse(r.extraConfig);
                        if (extraConfig?.isMultipleConnector && extraConfig?.tableName) {
                            let tableName = extraConfig.tableName;
                            if (extraConfig?.tableSubName) {
                                tableName = `${extraConfig.tableSubName}${extraConfig.tableName}`;
                            }
                            deleteTableDetails.push(tableName);
                        }
                    }
                }
            }

            const widgetResult = await dataSource.getRepository(DataRelationBuilder).delete(requestBody.id);
            apiResponse.data = widgetResult;

            if (deleteTableDetails?.length) {
                for (let tableName of deleteTableDetails) {
                    await DataRelationService.executeQuery(`DROP TABLE IF EXISTS ${tableName}`);
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Put('data-relation-builder/sync-data/:id')
    async syncData(
        @Path() id: string,
        @Body() requestBody: SyncDataRelationRequest,
        @Request() request: any
    ): Promise<SaveResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},  
                relationResult: null,  
            };

            const relationResult: any = await dataSource.getRepository(DataRelationBuilder).findOne({
                where: {
                    id: id,
                    clientId: request.userDetails.client_id,
                },
            });
            if (!relationResult?.id) {
                const apiErrorResponse: ApiErrorResponse = {
                    error: {
                        error_description: "Data not found",
                    },
                };
                this.setStatus(500);
                return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
            }

            if (relationResult?.config) {
                relationResult.config = JSON.parse(
                    relationResult.config
                );
            } else {
                relationResult.config = {};
            }
            if (relationResult?.extraConfig) {
                relationResult.extraConfig = JSON.parse(
                    relationResult.extraConfig
                );
            } else {
                relationResult.extraConfig = {};
            }
            if (relationResult?.syncConfig) {
                relationResult.syncConfig = JSON.parse(
                    relationResult.syncConfig
                );
            } else {
                relationResult.syncConfig = {};
            }
            if (relationResult?.syncMetaConfig) {
                relationResult.syncMetaConfig = JSON.parse(
                    relationResult.syncMetaConfig
                );
            } else {
                relationResult.syncMetaConfig = {};
            }

            apiResponse.relationResult = relationResult;

            if (["syncAllData", "syncNewlyData"].indexOf(requestBody?.syncType) > -1) {
                apiResponse.data = await DataSyncService.startSyncData(requestBody.syncType, relationResult, requestBody?.syncTableConfig, request.userDetails.client_id);
            } else if (requestBody?.syncType === "forceFully") {
                let tableName = `${apiResponse.relationResult?.extraConfig?.tableSubName}${apiResponse.relationResult?.extraConfig?.tableName}`;
                await dataSource.getRepository(DataRelationBuilder).update({ id: request.params.id }, { isSyncData: 0 });
                await DataRelationService.executeQuery(`DROP TABLE IF EXISTS ${tableName}`);
                await DataRelationService.createMigrationTable(apiResponse.relationResult);
                DataGenerateService.generateTableData(
                    request.params.id, 
                    request.userDetails.client_id,
                    tableName, 
                    apiResponse.relationResult,
                    { isInsertData: true }
                );
            }

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
