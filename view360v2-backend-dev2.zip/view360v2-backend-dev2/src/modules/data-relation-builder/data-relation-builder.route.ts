import { AppRoutes } from "../../app.routes";

export class DataRelationBuilderRoutes extends AppRoutes {

    constructor() {
        super();
    }
}
