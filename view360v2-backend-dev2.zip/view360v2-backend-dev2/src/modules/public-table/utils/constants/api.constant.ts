import { SentimentalMailMapper } from "../../../../entities";

export const SUCCESS_EXECUTED: string = "Successfully executed.";

export const publicTables = [
    {
        id: "sentinalMailMapper",
        name: "Sentinal Mail",
        tableEntities: SentimentalMailMapper,
    },
];
