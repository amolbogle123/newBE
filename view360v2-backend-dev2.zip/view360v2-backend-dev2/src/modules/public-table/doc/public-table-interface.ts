export interface PublicTableListResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface PublicTableColumnListResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface PublicTableResponse {
    status: boolean;
    data?: any;
    message?: string;
}