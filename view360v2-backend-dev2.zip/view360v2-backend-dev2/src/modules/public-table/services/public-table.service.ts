import Container from "typedi";
import { DataSource, Not } from "typeorm";
import { dataSource } from "core/data-source";
import { PublicTables } from "../../../entities";

export class PublicTableService {
    async getAllTable(request): Promise<any> {
        let whereCondition = {};
        if (request?.query?.listType) {
            whereCondition["where"] = { type: Not(request.query.listType) };
        }
        const publicTables = await Container.get(DataSource).getRepository(PublicTables).find(whereCondition);
        return new Promise((resolve) => resolve(
            publicTables.map((item) => {
                return {
                    id: item.name,
                    name: item.name,
                };
            })
        ));
    }

    async checkTable(tableName) {
        // Get the existing connection
        const connection = dataSource.manager.connection;
        let database = dataSource.manager.connection.options.database;
        // Create a new query runner
        const queryRunner = connection.createQueryRunner();
    
        // Connect to the database
        await queryRunner.connect();

        return new Promise(async (resolve) => {
            let response = {
                isTableExists: true,
            };
            try {
                // Assuming queryRunner is your database connection object
                const tableExistsQuery = `SELECT table_name as 'TABLE_NAME' FROM information_schema.tables WHERE table_schema = '${database}' AND table_name = '${tableName}'`;
                const result = await queryRunner.query(tableExistsQuery);
                if (result?.length == 0) {
                    response.isTableExists = false;
                }
                // Extract column names from the result
                resolve(response);
            } catch (error) {
                console.log(error);
                resolve(response);
            } finally {
                // Release the query runner
                await queryRunner.release();
            }
        });
    }

    async getColumns(tableName,queryRunner) {
        try {
            // Assuming queryRunner is your database connection object
            const result = await queryRunner.query(`SHOW COLUMNS FROM \`${tableName}\``);
            // Extract column names from the result
            return result.map(row => row.Field);
        } catch (error) {
            console.error('Error retrieving column names:', error);
            return [];
        }
    }
    
    async getTableColumns(tableName): Promise<any>{
        // Get the existing connection
        const connection = dataSource.manager.connection;
    
        // Create a new query runner
        const queryRunner = connection.createQueryRunner();
    
        // Connect to the database
        await queryRunner.connect();

        return new Promise(async (resolve) => {
            let response = [];
            try {
                let publicTables = await Container.get(DataSource).getRepository(PublicTables).find();
                const findTable = publicTables.find((item) => item.name === tableName);
                if (findTable) {
                    if (tableName === 'vendorData') {
                    const columnList = await this.getColumns(tableName,queryRunner);
    
                    const tableData = await queryRunner.query(`SELECT * FROM ${findTable.name}`);

                    const addedKeys = new Set(); // Track added keys
                    for (let row of tableData) {
                        const group = row["docName"]; // Assuming there's a 'group' column in your table
                        if (!group) {
                            continue; // Skip rows without group information
                        }
    
                        for (let c of columnList) {
                            if (["createdBy"].indexOf(c.propertyName) === -1) {
                                // Add the column itself to the response if not added already
                                const columnEntry = {
                                    id: c,
                                    name: c,
                                    group: group,
                                };
                                if (!addedKeys.has(columnEntry.id)) {
                                    response.push(columnEntry);
                                    addedKeys.add(columnEntry.id);
                                }
                                // If the column is 'config', retrieve actual data for each row
                                if (c.propertyName === 'config') {
                                    if (row[c.databaseName.toLowerCase()]) {
                                        const configData = JSON.parse(row[c.databaseName.toLowerCase()]);
                                        Object.keys(configData).forEach((key) => {
                                            const configEntry = {
                                                id: `${group}~CONFIG~${key}`,
                                                name: key,
                                                group: group,
                                            };
                                            if (!addedKeys.has(configEntry.id)) {
                                                response.push(configEntry);
                                                addedKeys.add(configEntry.id);
                                            }
                                        });
                                    }
                                }
                            }
                        }
                    }
                    }else{
                        const columnList = await this.getColumns(tableName,queryRunner);
                        for (let c of columnList) {
                            if (["createdBy"].indexOf(c.propertyName) === -1) {
                                response.push({
                                    id: c,
                                    name: c,
                                });
                            }
                        }
                    }
                }
    
                resolve(response);
            } catch (error) {
                console.log(error);
                resolve(response);
            } finally {
                // Release the query runner
                await queryRunner.release();
            }
        });
    }

    async getTableDetails(tableName): Promise<any>{
        const connection = dataSource.manager.connection;
    
        // Create a new query runner
        const queryRunner = connection.createQueryRunner();
    
        // Connect to the database
        await queryRunner.connect();

        return new Promise(async (resolve) => {
            let response = {
                schema: null,
                schemaType: "mySql",
                columnList: [],
            };
            try {
                const schemaResult = await queryRunner.query("SELECT `table_schema` FROM `information_schema`.`tables` WHERE `table_name` = '"+tableName+"'");
                if (schemaResult?.length && schemaResult[0].TABLE_SCHEMA) {
                    response.schema = schemaResult[0].TABLE_SCHEMA;
                }
                const result = await queryRunner.query(`SHOW COLUMNS FROM ${tableName}`);
                for (let c of result) {
                    response.columnList.push({
                        name: c.Field,
                        type: c.Type,
                        generateDataType: ["int", "float", "double", "bigint", "decimal"].indexOf(c.Type.toLowerCase()) > -1 ? "number" : "string",
                    });
                }

                resolve(response);
            } catch (error) {
                console.log(error);
                resolve(response);
            } finally {
                // Release the query runner
                await queryRunner.release();
            }
        });
    }
}
