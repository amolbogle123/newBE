import { AppRoutes } from "../../app.routes";
import { PublicTableController } from "./controllers/public-table.controller";

export class PublicTableRoutes extends AppRoutes {
    private publicTableController: PublicTableController;

    constructor() {
        super();
        this.publicTableController = new PublicTableController();
    }
}
