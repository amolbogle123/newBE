import { Controller, Get, Path, Request, Route, Security, Tags } from "tsoa";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import {
    PublicTableColumnListResponse,
    PublicTableListResponse,
    PublicTableResponse
} from "../doc/public-table-interface";
import { PublicTableService } from "../services/public-table.service";
import Container from "typedi";
import {DataSource, In} from "typeorm";
import {PublicTables} from "entities";

@Route("")
@Tags("Public Table")
export class PublicTableController extends Controller {
    private publicTableService: PublicTableService = new PublicTableService();

    @Security("bearerAuth")
    @Get("public-table/check-table/:tableName")
    async checkTable(
        @Request() request: any,
        @Path() tableName: string
    ): Promise<PublicTableResponse | unknown> {
        try {
            const apiResponse = {
                data: await this.publicTableService.checkTable(tableName),
            };
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("public-table")
    async publicTableList(
        @Request() request: any,
    ): Promise<PublicTableListResponse | unknown> {
        try {
            const apiResponse = {
                data: await this.publicTableService.getAllTable(request),
            };
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("public-table/:tableName")
    async publicTableColumnList(
        @Request() request: any,
        @Path() tableName: string
    ): Promise<PublicTableColumnListResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: []
            };

            const result = await this.publicTableService.getTableColumns(tableName);
            if (result?.length) {
                apiResponse.data = result;
            }
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("public-table-details/:tableName")
    async publicTableDetailsList(
        @Request() request: any,
        @Path() tableName: string
    ): Promise<PublicTableColumnListResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: null
            };

            const result = await this.publicTableService.getTableDetails(tableName);
            if (result) {
                apiResponse.data = result;
            }
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("database-public-tables")
    async publicTables(
        @Request() request: any,
    ): Promise<any | unknown> {
        try {
            const apiResponse = {
                data: null,
                allPublicTables: null
            };
            const publicTables = await Container.get(DataSource).getRepository(PublicTables).find({
                where: { type: 'View360', client_id: request.userDetails.client_id },
                order: {
                    created_on: 'DESC' // Order by created_date in descending order
                },
                take: 5
            });
            const allPublicTables = await Container.get(DataSource).getRepository(PublicTables).find({
                where: { type: 'View360', client_id: request.userDetails.client_id },
                order: {
                    created_on: 'DESC' // Order by created_date in descending order
                }
            });
            if(publicTables && allPublicTables) {
                apiResponse.data = publicTables;
                apiResponse.allPublicTables = allPublicTables;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
