export interface AddEmailBuilderRequestBody {
    title: string;
    message: string;
    bodyStyle: string;
    config: string;
    isPublish: number;
    htmlContext:string;
    layout: "fullLayout" | "mainLayout";
}

export interface UpdateEmailBuilderRequestBody {
    title: string;
    message: string;
    bodyStyle: string;
    config: string;
    isPublish: number;
    htmlContext:string;
    layout: "fullLayout" | "mainLayout";
}

export interface EmailBuilderMessageResponse {
    message: string;
}

export interface EmailBuilderApiErrorResponse {
    status: boolean;
    message: string;
    error: {
        error_description: string;
    };
}
