import dbService from "services/db.service";
import {
    Body,
    Controller,
    Delete,
    Get,
    Patch,
    Path,
    Post,
    Request,
    Route,
    Security,
    Tags,
    Query,
} from "tsoa";
import { Container } from "typedi";
import { DataSource, In } from "typeorm";
import { EmailBuilderPage } from "../../../entities/emailbuilder";
import {
    ApiErrorResponse,
    CommonHelper,
    SetResponse,
} from "../../../utils/helpers/common.helper";
import {
    AddEmailBuilderRequestBody,
    UpdateEmailBuilderRequestBody,
    EmailBuilderApiErrorResponse,
    EmailBuilderMessageResponse,
} from "../doc/email-builder.interface";
import { StatusType } from "../../../models/enums";
import * as txt from "../utils/constants/api.constant";
import { CommonUtil } from "utils/common.util";
@Route("email-builder")
@Tags("EmailBuilderPage")
export class EmailBuilderPageController extends Controller {
    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    @Security("bearerAuth")
    @Get("/")
    async emailList(
        @Request() request: any,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<any> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };
            let whereCondition: any = {
                clientId: request.userDetails.client_id,
            };
            if (request.query?.isPublish === "true") {
                whereCondition.isPublish = 1;
            }

            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["createdOn"] = sortOrder;
            }
            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(EmailBuilderPage),
                {
                    where: whereCondition,
                }
            );

            const pageList: EmailBuilderPage[] =
                await dbService._findQueryService(
                    Container.get(DataSource).getRepository(EmailBuilderPage),
                    {
                        where: whereCondition, // Use queryObj directly instead of spreading it
                        take: pageSize,
                        skip: (page - 1) * pageSize,
                        order: sortObject,
                    }
                );
            if (pageList?.length > 0) {
                apiResponse.data = pageList;
                apiResponse.recordsTotal = totalRecordCount;
                apiResponse.recordsFiltered = totalRecordCount;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("all")
    async getAllemailList(@Request() request: any): Promise<unknown> {
        try {
            const apiResponse = {
                data: [],
            };
            const selectedFields: any = [
                "id",
                "title",
                "message",
                "bodyStyle",
                "config",
                "layout",
            ];
            let whereCondition = {
                clientId: request.userDetails.client_id,
                isPublish: 1,
            };
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(EmailBuilderPage),
                {
                    where: whereCondition,
                    select: selectedFields,
                }
            );

            if (results?.length) {
                apiResponse.data = results;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("/:id")
    async getEmailBuilderPage(@Request() request: any): Promise<unknown> {
        try {
            const apiResponse = {
                data: {},
            };
            const selectedFields: any = [
                "id",
                "title",
                "message",
                "bodyStyle",
                "config",
                "isPublish",
                "layout",
            ];
            let whereCondition = {
                clientId: request.userDetails.client_id,
                id: request.params.id,
            };
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(EmailBuilderPage),
                {
                    where: whereCondition,
                    select: selectedFields,
                }
            );

            if (results?.length) {
                apiResponse.data = results[0];
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Patch("/:id")
    async updateEmailBuilderPage(
        @Path() id: string,
        @Request() request: any,
        @Body() body: UpdateEmailBuilderRequestBody
    ): Promise<EmailBuilderMessageResponse | EmailBuilderApiErrorResponse> {
        try {
            let EmailBuilderPageNew: any = body;
            let result = await Container.get(DataSource)
                .getRepository(EmailBuilderPage)
                .update(
                    {
                        clientId: request.userDetails.client_id,
                        id: id,
                    },
                    EmailBuilderPageNew
                );

            if (result.affected > 0) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: txt.PAGE_TEMPLATE_UPDATED,
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: txt.PAGE_TEMPLATE_NO_FOUND,
                });
            }
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("/")
    async createEmailBuilderPage(
        @Body() requestBody: AddEmailBuilderRequestBody,
        @Request() request: any
    ): Promise<any> {
        try {
            let payload: any = requestBody;
            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;
            payload.updatedBy = request.userDetails.id;
            const EmailBuilderPageResponse =
                await dbService._createQueryService(
                    Container.get(DataSource).getRepository(EmailBuilderPage),
                    payload
                );
            return CommonHelper.apiSwaggerSuccessResponse({
                data: {
                    lastInsertId: EmailBuilderPageResponse.id || "",
                    message: txt.PAGE_TEMPLATE_SAVED,
                },
            });
        } catch (error) {
            console.log(error, "errr");
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("/")
    async deleteEmailTemplate(@Body() requestBody: any): Promise<any> {
        try {
            const deleteTemplateResponse: SetResponse =
                await dbService._deleteQueryService(
                    Container.get(DataSource).getRepository(EmailBuilderPage),
                    {
                        id: In(requestBody.id),
                    }
                );

            if (deleteTemplateResponse.status === StatusType.ERROR) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: {},
                    message: txt.PAGE_TEMPLATE_NO_DATA,
                });
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: { deletedRows: deleteTemplateResponse.affected || 0 },
                message: txt.PAGE_TEMPLATE_DELETED,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
