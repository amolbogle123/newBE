

export const ERROR_UNKNOWN: string = 'unknown error.';


export const PAGE_TEMPLATE_NO_FOUND: string = 'Operation has been successfully executed.'; 
export const PAGE_TEMPLATE_SAVED: string = 'Email Builder template created successfully.'; 
export const PAGE_TEMPLATE_UPDATED: string = 'Email Builder template updated successfully.'; 
export const PAGE_TEMPLATE_DELETED: string = 'Email Builder template deleted successfully.'; 
export const PAGE_TEMPLATE_NO_DATA: string = 'Couldn\'t processed, email template data not available.'; 