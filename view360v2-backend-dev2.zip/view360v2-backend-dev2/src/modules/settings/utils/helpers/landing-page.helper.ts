import dbService from "../../../../services/db.service";
import { ClientNavigation } from "../../../../entities";
import Container from "typedi";
import { DataSource } from "typeorm";

const LANDING_DEFAULT_URL = "/dashboard";

export class LandingPageHelper {
    getDefaultUrl(config, userDetails): Promise<string> {
        return new Promise(async (resolve) => {
            let response = LANDING_DEFAULT_URL;
            if (config?.length) {
                for (let c of config) {
                    if (c.config) {
                        const pageConfig = JSON.parse(c.config);
                        if (
                            (!pageConfig?.userId?.length &&
                                !pageConfig?.roleId?.length) ||
                            (pageConfig?.roleId?.length &&
                                pageConfig.roleId.indexOf(userDetails.role_id) >
                                    -1) ||
                            (pageConfig?.userId?.length &&
                                pageConfig.userId.indexOf(userDetails.id) > -1)
                        ) {
                            response = await this.getPageUrl(
                                pageConfig.urlType,
                                pageConfig.selectedId,
                                userDetails,
                                pageConfig
                            );
                        }
                    }
                }
            }

            resolve(response);
        });
    }

    getPageUrl(urlType, selectedId, userDetails, pageConfig): Promise<string> {
        return new Promise(async (resolve) => {
            let url = LANDING_DEFAULT_URL;
            try {
                if (urlType === "leftMenu") {
                    const whereClause = { clientId: userDetails.client_id };
                    const results = await dbService._findOneQueryService(
                        Container.get(DataSource).getRepository(
                            ClientNavigation
                        ),
                        { where: whereClause, select: ["menu"] }
                    );
                    if (results) {
                        url = await this.getSelectedMenuUrl(results.menu, selectedId);
                    }
                } else if (urlType === "customUrl") {
                    url = pageConfig.customURL;
                } else if (urlType === "pageBuilder") {
                    url = `/pages/${selectedId}`;
                }
            } catch (error) {}
            resolve(url);
        });
    }
    getSelectedMenuUrl(menuList, selectedId): Promise<string> {
        return new Promise(async (resolve) => {
            let url = LANDING_DEFAULT_URL;
            menuList = JSON.parse(menuList);

            for (let s of menuList) {
                for (let m of s.menuItems) {
                    if (m?.components?.length) {
                        let findUrl = m.components.find(
                            (c) =>
                                c?.tempId === selectedId &&
                                m?.routerLink
                        );
                        if (findUrl) {
                            url = findUrl.routerLink;
                        }
                    } else if (
                        m?.tempId === selectedId &&
                        m?.routerLink
                    ) {
                        url = m.routerLink;
                    }
                }
            }
            resolve(url);
        });
    }
}
