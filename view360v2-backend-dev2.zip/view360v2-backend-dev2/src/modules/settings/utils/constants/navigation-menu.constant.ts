import { NavigationMenu } from "../../../../models/navigation-menu"

export const ALL_PERMISSION: string = "{\"dashboard\":{\"widget\":{\"view\":true,\"add\":true,\"configure\":true,\"permission\":true,\"clone\":true,\"move\":true,\"refresh\":true,\"delete\":true},\"dashboard\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true}},\"documents\":{\"document\":{\"view\":true,\"add\":true,\"edit\":true,\"manageUser\":false,\"delete\":true,\"filters\":false,\"viewall\":true},\"form\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"formEmbed\":false,\"formShare\":false,\"viewall\":true},\"formEntry\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true}},\"pdf\":{\"pdfForm\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true},\"pdfFormEntry\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true}},\"automation\":{\"mailTemplate\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true},\"notificationTemplate\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true},\"processBuilder\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true}},\"setting\":{\"general\":{\"view\":true,\"edit\":true},\"childCompanies\":{\"view\":true,\"add\":true,\"delete\":true},\"department\":{\"view\":true,\"add\":true,\"delete\":true},\"location\":{\"view\":true,\"add\":true,\"delete\":true},\"connectors\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true}},\"users\":{\"user\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true}},\"roles\":{\"role\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true}},\"reports\":{\"report\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true}},\"gridReports\":{\"report\":{\"view\":true,\"add\":true,\"edit\":true,\"delete\":true,\"viewall\":true}}}"

// New Navigation Menu
export const dashboard: NavigationMenu = {
    name: 'Dashboard',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Dashboard-1624444146283283',
    faClass: 'briefcase',
    components: [],
    parantTmpId: null,
    routerLink: 'dynamic-dashboard/dashboard'
}

export const manageUsers: NavigationMenu = {
    name: 'Manage Users',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'User Information-1624446506890890',
    faClass: 'user-check',
    components: [],
    parantTmpId: 'Admin-1682599603732732',
    routerLink: 'users'
}

export const manageRoles: NavigationMenu = {
    name: 'Manage Roles',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Roles-1624446523338338',
    faClass: 'users',
    components: [],
    parantTmpId: 'Admin-1682599603732732',
    routerLink: 'roles'
}

export const settings: NavigationMenu = {
    name: 'Settings',
    order: 0,
    roles: '2',
    active: 1,
    tempId: 'Setting-1624446480915915',
    faClass: 'settings',
    components: [],
    parantTmpId: 'Admin-1682599603732732',
    routerLink: 'setting/view/general'
}

export const workflowManagement: NavigationMenu = {
    name: 'Workflow Management',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Process Builder-1624446295506506',
    faClass: 'cpu',
    components: [],
    parantTmpId: 'Analytics-1682599649957957',
    routerLink: 'workflow-builder'
}

export const documents: NavigationMenu = {
    name: 'Documents',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Documents-1624445918458458',
    faClass: 'folder',
    components: [],
    parantTmpId: 'Analytics-1682599649957957',
    routerLink: 'documents'
}

export const formBuilder: NavigationMenu = {
    name: 'Form Builder',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Form Builder-1624446037355355',
    faClass: 'file',
    components: [],
    parantTmpId: 'Analytics-1682599649957957',
    routerLink: 'forms-builder/add-form-builder/-1/-1'
}

export const templateBuilder: NavigationMenu = {
    name: 'Template Builder',
    order: 0,
    roles: '2c8be754-3318-4616-826c-11f2c209feaa',
    active: 1,
    tempId: 'Template Builder-1624446110985985',
    faClass: 'file-plus',
    components: [],
    parantTmpId: 'Analytics-1682599649957957',
    routerLink: 'templates'
}

export const analyticsSubmenu: NavigationMenu = {
    name: 'Analytics',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Analytics-1682599649957957',
    faClass: 'message-square',
    components: [],
    parantTmpId: null,
    routerLink: ''
}

export const administrationSubmenu: NavigationMenu = {
    name: 'Administration',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Admin-1682599603732732',
    faClass: 'user',
    components: [],
    parantTmpId: null,
    routerLink: ''
}

export const mapperSubmenu: NavigationMenu = {
    name: 'Form Mapper',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'mapper-1682599603732732',
    faClass: 'user',
    components: [],
    parantTmpId: null,
    routerLink: ''
}

export const customSkinning: NavigationMenu = {
    name: 'Custom Skinning',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Custom Skinning-1687519203546546',
    faClass: 'edit',
    components: [],
    parantTmpId: null,
    routerLink: '/custom-skinning'
}

export const excelMapper: NavigationMenu = {
    name: 'Excel',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Excel-1687519203546546',
    faClass: 'edit',
    components: [],
    parantTmpId: 'mapper-1682599603732732',
    routerLink: '/excel-mapper'
}

export const pdfMapper: NavigationMenu = {
    name: 'Pdf',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Pdf-1687519203546546',
    faClass: 'edit',
    components: [],
    parantTmpId: 'mapper-1682599603732732',
    routerLink: '/pdf-mapper'
}

export const ocr: NavigationMenu = {
    name: 'OCR',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'ocr-1682599603732732',
    faClass: 'activity',
    components: [],
    parantTmpId: null,
    routerLink: ''
}

export const ocrReader: NavigationMenu = {
    name: 'OCR Reader',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'ocr-reader-1682599603732732',
    faClass: 'activity',
    components: [],
    parantTmpId: 'ocr-1682599603732732',
    routerLink: '/ocr-reader'
}

export const ocrSyncAccount: NavigationMenu = {
    name: 'Sync Account Files',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'ocr-syc-1682599603732732',
    faClass: 'activity',
    components: [],
    parantTmpId: 'ocr-1682599603732732',
    routerLink: '/ocr-reader/sync-account-files'
}

export const connectors: NavigationMenu = {
    name: 'Connector',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Connectors-1682599603732732',
    faClass: 'activity',
    components: [],
    parantTmpId: 'Analytics-1682599649957957',
    routerLink: 'connector'
}
