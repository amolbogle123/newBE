import { AppRoutes } from "../../app.routes";
import { ChildCompanyController } from "./controllers/child-company.controller";
import { ClientGeneralController } from "./controllers/client-general.controller";
import { ClientSystemController } from "./controllers/client-system.controller";
import { CompanyDepartmentController } from "./controllers/company-department.controller";
import { LocationController } from "./controllers/location.controller";
import { ModuleController } from "./controllers/module.controller";
import { SettingConfigController } from "./controllers/setting-config.controller";
import { ClientNavigationController } from "./controllers/client-navigation.controller";
import { ClientLandingPageController } from "./controllers/client-landing-page.controller";
import { TimezoneController } from "./controllers/timezone.controller";
import { MaintenanceController } from "./controllers/maintenance.controller";
import { ActiveSessionController } from "./controllers/active-sessions.controller";

export class SettingsRoutes extends AppRoutes {
    private ROUTER_PREFIX: string = "/settings";

    private childCompanyController: ChildCompanyController;
    private clientGeneralController: ClientGeneralController;
    private clientSystemController: ClientSystemController;
    private companyDepartmentController: CompanyDepartmentController;
    private locationController: LocationController;
    private moduleController: ModuleController;
    private settingConfigController: SettingConfigController;
    private clientNavigationController: ClientNavigationController;
    private clientLandingPageController: ClientLandingPageController;
    private timezoneController: TimezoneController;
    private activeSessionController: ActiveSessionController;
    private maintenanceController: MaintenanceController;

    constructor() {
        super();
        this.childCompanyController = new ChildCompanyController();
        this.clientGeneralController = new ClientGeneralController();
        this.clientSystemController = new ClientSystemController();
        this.companyDepartmentController = new CompanyDepartmentController();
        this.locationController = new LocationController();
        this.moduleController = new ModuleController();
        this.settingConfigController = new SettingConfigController();
        this.clientNavigationController = new ClientNavigationController();
        this.clientLandingPageController = new ClientLandingPageController();
        this.timezoneController = new TimezoneController();
        this.activeSessionController = new ActiveSessionController();
        this.maintenanceController = new MaintenanceController();
        this.initRoutes();
    }

    initRoutes() {
        // Child Company Routes
        /**
         * this.router.post("/settings/child-company/add", (req, res, next) =>
            this.childCompanyController.addChildCompany(req, res, next).catch(next)
        );
        this.router.get("/settings/child-company/list", (req, res, next) =>
            this.childCompanyController.getAllChildCompanies(req, res, next).catch(next)
        );
        this.router.get("/settings/child-company/:id", (req, res, next) =>
            this.childCompanyController.getChildCompanyById(req, res, next).catch(next)
        );
        this.router.post("/settings/child-company/multiple-delete", (req, res, next) =>
            this.childCompanyController.deleteMultipleChildCompanies(req, res, next).catch(next)
        );
        this.router.post("/settings/child-company/:id", (req, res, next) =>
            this.childCompanyController.deleteChildCompany(req, res, next).catch(next)
        );
         */

        // Client General Routes
        /**
         * this.router.post("/settings/general/update", (req, res, next) =>
            this.clientGeneralController.updateClientGeneral(req, res, next).catch(next)
        );
        this.router.get("/settings/general/list", (req, res, next) =>
            this.clientGeneralController.getAllClientGenerals(req, res, next).catch(next)
        );
         */

        // Client System Routes
        /**
         * this.router.put("/settings/client-systems/:id", (req, res, next) =>
            this.clientSystemController
                .updateClientSystem(req, res, next)
                .catch(next)
        );
        this.router.get("/settings/client-systems", (req, res, next) =>
            this.clientSystemController
                .getAllClientSystems(req, res, next)
                .catch(next)
        );
         */

        // Client Theme Routes
        /**
         * this.router.put("/settings/client-themes/:id", (req, res, next) =>
            this.clientThemeController
                .updateClientTheme(req, res, next)
                .catch(next)
        );
        this.router.get("/settings/client-themes", (req, res, next) =>
            this.clientThemeController
                .getAllClientThemes(req, res, next)
                .catch(next)
        );
         */

        // Company Department Routes
        /**
         * this.router.post("/settings/department/add", (req, res, next) =>
            this.companyDepartmentController.addCompanyDepartment(req, res, next).catch(next)
        );
        this.router.get("/settings/department/list", (req, res, next) =>
            this.companyDepartmentController.getAllCompanyDepartments(req, res, next).catch(next)
        );
        this.router.get("/settings/department/:id", (req, res, next) =>
            this.companyDepartmentController.getCompanyDepartmentById(req, res, next).catch(next)
        );
        this.router.post("/settings/department/multiple-delete", (req, res, next) =>
            this.companyDepartmentController.deleteMultipleCompanyDepartments(req, res, next).catch(next)
        );
        this.router.post("/settings/department/delete", (req, res, next) =>
            this.companyDepartmentController.deleteCompanyDepartment(req, res, next).catch(next)
        );
         */

        // Location Routes
        /**
         * this.router.post("/settings/location/add", (req, res, next) =>
            this.locationController.addLocation(req, res, next).catch(next)
        );
        this.router.get("/settings/location/list", (req, res, next) =>
            this.locationController.getAllLocations(req, res, next).catch(next)
        );
        this.router.get("/settings/location/:id", (req, res, next) =>
            this.locationController.getLocationById(req, res, next).catch(next)
        );
        this.router.get("/settings/get-locations-by-company-id", (req, res, next) =>
            this.locationController.getLocationByCompany(req, res, next).catch(next)
        );
        this.router.post("/settings/location/multiple-delete", (req, res, next) =>
            this.locationController.deleteMultipleLocations(req, res, next).catch(next)
        );
        this.router.post("/settings/location/delete", (req, res, next) =>
            this.locationController.deleteLocation(req, res, next).catch(next)
        );
         */

        // Module Routes
        /**
         * this.router.post("/settings/module/add", (req, res, next) =>
            this.moduleController.addModule(req, res, next).catch(next)
        );
        this.router.post("/settings/module/update-status/:id", (req, res, next) =>
            this.Controller.updateModule(req, res, next).catch(next)
        );
        this.router.post("/settings/module/edit/:id", (req, res, next) =>
            this.moduleController.updateModule(req, res, next).catch(next)
        );
        this.router.get("/settings/module/list", (req, res, next) =>
            this.moduleController.getAllModules(req, res, next).catch(next)
        );
        this.router.get("/settings/module/:id", (req, res, next) =>
            this.moduleController.getModuleById(req, res, next).catch(next)
        );
        this.router.get("/settings/module/self-registration/:siteurl", (req, res, next) =>
            this.moduleController.getModuleByName(req, res, next).catch(next)
        );
        this.router.post("/settings/module/multiple-delete", (req, res, next) =>
            this.moduleController.deleteMultipleModules(req, res, next).catch(next)
        );
        this.router.post("/settings/module/delete", (req, res, next) =>
            this.moduleController.deleteModule(req, res, next).catch(next)
        );
         */

        // Setting Configs Routes
        /**
         * this.router.post("/settings/setting-config/add", (req, res, next) =>
            this.settingConfigController.addSettingConfig(req, res, next).catch(next)
        );
        this.router.post("/settings/setting-config/update/:id", (req, res, next) =>
            this.settingConfigController.updateSettingConfig(req, res, next).catch(next)
        );
        this.router.get("/settings/setting-config/list/:type", (req, res, next) =>
            this.settingConfigController.getAllSettingConfigs(req, res, next).catch(next)
        );
        this.router.get("/settings/setting-config/:id", (req, res, next) =>
            this.settingConfigController.getSettingConfigById(req, res, next).catch(next)
        );
        this.router.post("/settings/setting-config/:id", (req, res, next) =>
            this.settingConfigController.deleteSettingConfig(req, res, next).catch(next)
        );
         */

        // Setting Navigation Routes
        /**
         * this.router.get('/settings/navigation/list', (req, res, next) =>
            this.clientNavigationController.getAllClientNavigations(req, res, next).catch(next)
        );
        this.router.post('/settings/navigation/update', (req, res, next) =>
            this.clientNavigationController.updateClientNavigation(req, res, next).catch(next)
        );
        this.router.get('/settings/navigation/get-menu-setting', (req, res, next) =>
            this.clientNavigationController.getMenuSetting(req, res, next).catch(next)
        );
        this.router.post('/settings/navigation/update-login-redirect-url', (req, res, next) =>
            this.clientNavigationController.updateLoginRedirectUrl(req, res, next).catch(next)
        );
         */

        // Setting Navigation Routes for reset to default
        /**
         * this.router.put('/settings/navigation/reset-menu', (req, res, next) =>
            this.clientNavigationController.setMenuSettingsToDefault(req,res,next).catch(next)
        );
         */
        
        // Theme Builder
        /**
         * this.router.get("/settings/theme-builder", (req, res, next) =>
            this.themeBuilderController.getDeatils(req, res, next).catch(next)
        );
        this.router.put("/settings/theme-builder", (req, res, next) =>
            this.themeBuilderController
                .updateDeatils(req, res, next)
                .catch(next)
        );
        this.router.get(
            "/settings/theme-builder/all-themes",
            (req, res, next) =>
                this.themeBuilderController
                    .getAllThemes(req, res, next)
                    .catch(next)
        );
        this.router.delete("/settings/theme-builder", (req, res, next) =>
            this.themeBuilderController
                .deleteSetting(req, res, next)
                .catch(next)
        );
         */

        // Custom Component Enhancer
        /**
         * this.router.get(
            "/settings/custom-component-enhancer",
            (req, res, next) =>
                this.customComponentEnhancerController
                    .get(req, res, next)
                    .catch(next)
        );
        this.router.post(
            "/settings/custom-component-enhancer",
            (req, res, next) =>
                this.customComponentEnhancerController
                    .save(req, res, next)
                    .catch(next)
        );
        this.router.put(
            "/settings/custom-component-enhancer/css",
            (req, res, next) =>
                this.customComponentEnhancerController
                    .updateCss(req, res, next)
                    .catch(next)
        );
        this.router.put(
            "/settings/custom-component-enhancer",
            (req, res, next) =>
                this.customComponentEnhancerController
                    .update(req, res, next)
                    .catch(next)
        );
         */

        // Maintence
        /**
         * this.router.get(
            "/settings/maintenance/details",
            (req, res, next) =>
                this.maintenanceController
                    .getData(req, res, next)
                    .catch(next)
        );
        this.router.get(
            "/settings/maintenance",
            (req, res, next) =>
                this.maintenanceController
                    .getData(req, res, next)
                    .catch(next)
        );
        this.router.put(
            "/settings/maintenance",
            (req, res, next) =>
                this.maintenanceController
                    .update(req, res, next)
                    .catch(next)
        );
         */

        
        // TimeZone 
        this.router.get('/settings/timezone', (req, res, next) =>
            this.timezoneController.list(req,res,next).catch(next)
        );
    }
}
