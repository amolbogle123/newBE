export interface SettingConfig {
    id: string;
    type: string;
    config: string;
    createdOn: Date;
    clientId: number;
    createdBy: string;
}
export interface AetSettingConfigResponse {
    status: boolean;
    data: SettingConfig[];
    error: {
        error_description: string;
    };
}
export interface AddSettingConfigResponse {
    status: boolean;
    data: SettingConfig;
    error: {
        error_description: string;
    };
}
export interface UpdateSettingConfigResponse {
    status: boolean;
    data: {
        generatedMaps: any[];
        raw: any[];
        affected: number;
    };
    error: {
        error_description: string;
    };
}
export interface DeleteResponse {
    status: boolean;
    data: {
        raw: any[];
        affected: number;
    };
    error: {
        error_description: string;
    };
}

export interface AddUpdateSettingConfigRequest {
    type: string;
    config: any;
}
export interface DeleteSettingConfigRequest {
    id: string;
}

interface Conf {
    emailId?: string;
    host?: string;
    password?: string;
    port?: number;
    secure?: string;
    username?: string;
    accountSID?: string;
    authToken?: string;
    from?: number;
    analystLdapURL?: string;
    analystLdapUser?: string;
    analystLdapPassword?: string;
    enableAnalystAD?: boolean;
    apiKey?: string;
    token?: any;
    accessCode?: string;
    accountId?: string | null;
    email?: string;
    sentimentalAPI?: string | null;
    bpmnId?: string | null;
    formId?: string | null;
    formEmailId?: string | null;
    modelType?: string; 
    modelName?: string;
    authKey?: string | null;
    pwaLandingPage?: string | null;
    startDate?: string | null;
}

export interface AddLocationRequest {
    name: string;
    clientId?: number;
}
export interface AddLocationResponse {
    status: boolean;
    data: Locations;
    error: {
        error_description: string;
    };
}
export interface Locations {
    id: string;
    name: string;
    clientId: number;
    createdOn: Date;
}

export interface LocationResponse {
    status: boolean;
    data: Locations[];
    error: {
        error_description: string;
    };
}
export interface DeleteLocationRequest {
    id: number;
}
export interface MultipleDeleteLocationRequest {
    id: number[];
}
export interface AddDepartmentRequest {
    name: string;
    child_companies: string[];
}
interface ChildCompanies {}
export interface DeleteDepartmentRequest {
    id: string;
}
export interface MultipleDeleteDepartmentRequest {
    id: string[];
}
export interface Departments {
    id: string;
    name: string;
    childCompanies: string[];
    client_id: number;
    createdOn: Date;
}
export interface GetDepartmentResponse {
    status: boolean;
    data: Departments[];
    error: {
        error_description: string;
    };
}
export interface AddDepartmentResponse {
    status: boolean;
    data: Departments;
    error: {
        error_description: string;
    };
}

export interface UpdateMaintenance {
    enableMaintenance: boolean;
    config: any;
}
