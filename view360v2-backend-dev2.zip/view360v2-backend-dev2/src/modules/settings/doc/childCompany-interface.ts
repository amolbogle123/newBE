export interface CreateChildCompany {
    name: string;
    locations: number[];
    clientId?: string;
}
export interface DeleteChildCompany {
    id: string;
}

export interface DeleteMultipleChildCompanies {
    id: string[];
}

export interface DeleteResponse {
    status: boolean;
    data: {
        raw: any[],
        affected: number
    }
    error: {
        error_description: string
    }
}