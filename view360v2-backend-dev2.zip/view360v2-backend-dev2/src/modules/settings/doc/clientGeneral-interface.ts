export interface UpdateClientGeneral {
    client_id?: number;
    company_name?: string;
    legal_name?: string;
    contact_person?: string;
    comp_address?: string;
    zip?: string;
    city?: string;
    state?: string;
    country?: string;
    comp_phone?: string;
    comp_phone2?: string;
    company_email?: string;
    mobile?: string;
    fax?: string;
    website?: string;
    comp_registration?: string;
    tax_no?: string;
}
