export interface AddModules {
    isActive: number;
    clientId?: number | string;
}

export interface DeleteModules {
    id: string;
}

export interface DeleteMultipleModules {
    id: string[];
}
