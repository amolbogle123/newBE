export interface CreateActiveSession {
    expiryDate: string;
}

export interface UpdateActiveSession {
    expiryDate: string
}