export interface UpdateClientNavigation {
    menu: string;
}