export interface UpdateLoginRedirectUrl {
    loginRedirectConfig: string;
}

export interface CreateLandingPage {
    name: string;
    config?: any;
    active: number;
}

export interface DeleteMultiple {
    id: string[];
}