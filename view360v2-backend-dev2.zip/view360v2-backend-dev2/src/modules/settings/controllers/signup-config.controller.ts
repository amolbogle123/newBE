import {
    Body,
    Get,
    Route,
    Security,
    Tags,
    Request,
    Controller,
    Patch,
    Post,
} from "tsoa";
import {
    CommonHelper,
    ApiErrorResponse,
} from "../../../utils/helpers/common.helper";
import { dataSource } from "../../../core/data-source";
import { SignupConfig } from "../../../entities";
import Container from "typedi";
import dbService from "services/db.service";
import { DataSource } from "typeorm";

@Route("")
@Tags("Signup Config")
export class SignupConfigController extends Controller {
    /**
     * Get theme
     * @param req
     * @param res
     * @param next
     */

    @Get("signup-config")
    async getDeatils(@Request() request: any): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };

            let themeResult: any = await dataSource
                .getRepository(SignupConfig)
                .findOne({
                    where: {},
                });
            if (themeResult) {
                apiResponse.data = themeResult;
            }
            if (apiResponse.data && apiResponse.data["config"]) {
                apiResponse.data["config"] = JSON.parse(
                    apiResponse.data["config"]
                );
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update theme
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Patch("signup-config")
    async updateDeatils(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };
            const payload = {
                config: JSON.stringify(requestBody.config),
                client_id: request.userDetails.client_id,
            };

            // const insertResult = await dbService._createQueryService(
            //     Container.get(DataSource).getRepository(SignupConfig),
            //     payload
            // );
            const updateResult = await dataSource
                .getRepository(SignupConfig)
                .update({ client_id: request.userDetails.client_id }, payload);
            apiResponse.data = updateResult;
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update theme
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Post("signup-config")
    async postDeatils(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };
            const payload = {
                config: JSON.stringify(requestBody.config),
                client_id: request.userDetails.client_id,
            };

            const results = await dbService._createQueryService(
                Container.get(DataSource).getRepository(SignupConfig),
                payload
            );
            apiResponse.data = results;
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
