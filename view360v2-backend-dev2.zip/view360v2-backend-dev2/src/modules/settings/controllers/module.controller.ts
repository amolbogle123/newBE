import {
    Body,
    Controller,
    Delete,
    Get,
    Hidden,
    Patch,
    Path,
    Post,
    Query,
    Request,
    Route,
    Security,
    Tags,
} from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { ClientNavigation, MdbClient, MenuModule } from "../../../entities";
import dbService from "../../../services/db.service";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import {
    AddModules,
    DeleteMultipleModules,
} from "../doc/clientModules-interface";

type queryParams = {
    where?: {
        isActive?: number;
        type?: string;
    };
};

@Route("")
@Tags("Module Activator")
export class ModuleController extends Controller {
    /**
     * Add Module
     * @param req
     * @param res
     * @param next
     */
    @Security("berarerAuth")
    @Post("module")
    async addModule(
        @Body() requestBody: AddModules,
        @Request() req: any
    ): Promise<any> {
        try {
            const body = requestBody;
            body["isActive"] = +body.isActive;
            requestBody["clientId"] = req.userDetails.client_id;
            const results = await dbService._createQueryService(
                Container.get(DataSource).getRepository(MenuModule),
                {
                    ...requestBody,
                }
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: results,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Update Module
     * @param req
     * @param res
     * @param next
     */
    @Security("berarerAuth")
    @Patch("module/:id")
    async updateModule(
        @Path() id: string,
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        try {
            if (
                requestBody.type == "navigation" ||
                requestBody.type == "default"
            ) {
                const criteria: any = {
                    clientId: request.userDetails.client_id,
                };
                
                /**
                 * const whereClause = { clientId: request.userDetails.client_id };
                const hasNavData: boolean =
                    (await dbService._countQueryService(
                        Container.get(DataSource).getRepository(
                            ClientNavigation
                        ),
                        { where: whereClause }
                    )) > 0;
                 */

                const results = await dbService._findOneQueryService(
                    Container.get(DataSource).getRepository(ClientNavigation),
                    { where: criteria, select: ["menu"] }
                );
                let menuItems = JSON.parse(results.menu);

                menuItems = menuItems[0].menuItems;

                for (let i = 0; i < menuItems.length; i++) {
                    let menuItem = menuItems[i];
                    // return menuItem;
                    if (menuItem.tempId == id) {
                        menuItem.active = requestBody.isActive;
                    }
                }
                const updateData: any = {
                    menu: JSON.stringify([
                        {
                            name: "Analytics",
                            type: "section",
                            sectionTextColor: "#212529",
                            sectionBgColor: "#fff",
                            menuItems: menuItems,
                        },
                    ]),
                    updatedBy: request.userDetails.id,
                    active: 1,
                };
                let resultUpdated = await Container.get(DataSource)
                    .getRepository(ClientNavigation)
                    .update(
                        { clientId: request.userDetails.client_id },
                        updateData
                    );
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: resultUpdated,
                });
            }

            const moduleInstance = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(MenuModule),
                { id: id, ...requestBody }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                data: moduleInstance,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Delete Multiple Modules
     * @param req
     * @param res
     * @param next
     */
    @Security("berarerAuth")
    @Delete("module")
    @Hidden()
    async deleteMultipleModules(
        @Body() requestBody: DeleteMultipleModules
    ): Promise<any> {
        try {
            const { id: ids } = requestBody;
            const results = await dbService._deleteMultipleQueryService(
                Container.get(DataSource).getRepository(MenuModule),
                { id: ids }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                data: results,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Get child comapnies By ID
     * @param req
     * @param res
     * @param next
     */
    @Security("berarerAuth")
    @Get("module/:id")
    async getModuleById(@Path() id: string): Promise<any> {
        try {
            const results = await dbService._findOneQueryService(
                Container.get(DataSource).getRepository(MenuModule),
                { id: id }
            );
            if (results) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: results,
                });
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: null,
                message: "No such module exists",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Get All Modules
     * @param req
     * @param res
     * @param next
     */
    @Security("berarerAuth")
    @Get("module")
    async getAllModules(
        @Query() type: any,
    ): Promise<any> {
        try {
            const queryObj: any = {};
            let whereCondition = {};
            if (type) {
                whereCondition["type"] = type;
                queryObj["where"] = whereCondition;
            }
            const modules = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MenuModule),
                { ...queryObj }
            );

            return CommonHelper.apiSwaggerSuccessResponse({ data: modules });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("module/self-registration/:siteurl")
    @Hidden()
    async getModuleByName(@Path() siteurl: string): Promise<any> {
        try {
            const client = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MdbClient),
                { where: { websiteUrl: siteurl } }
            );
            if (client) {
                const results = await dbService._findQueryService(
                    Container.get(DataSource).getRepository(MenuModule),
                    {
                        where: {
                            moduleName: "self_registration_custom_form",
                            clientId: client.id,
                        },
                    }
                );
                if (results) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        data: results,
                    });
                }
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: null,
                    message: "No such module exists",
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("client-list")
    async getClientList(): Promise<void> {
        try {
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MdbClient),
                {}
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
