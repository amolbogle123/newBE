import lodash from "lodash";
import {
    Body,
    Get,
    Request,
    Route,
    Security,
    Tags,
    Patch,
    Controller,
    Post,
} from "tsoa";
import { ClientGeneral } from "../../../entities";
import {
    CommonHelper,
    ApiErrorResponse,
} from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import { UpdateClientGeneral } from "../doc/clientGeneral-interface";
import Container from "typedi";
import { DataSource } from "typeorm";

@Route("")
@Tags("Client General")
export class ClientGeneralController extends Controller {
    static async throwError(errorMessage: string): Promise<void> {
        throw Error(errorMessage);
    }

    /**
     * Add Client General
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Post("general")
    async addClientGeneral(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        try {
            const payload: any = requestBody;
            payload.client_id = request.userDetails.client_id;
            const result = await dbService._createQueryService(
                Container.get(DataSource).getRepository(ClientGeneral),
                payload
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: result,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Update Client General
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Patch("general")
    async updateClientGeneral(
        @Body() requestBody: UpdateClientGeneral,
        @Request() req: any
    ): Promise<any> {
        console.log(req.userDetails, "req.userDetailsreq.userDetails");
        try {
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ClientGeneral),
                { where: { client_id: req.userDetails.client_id } }
            );
            if (results.length && !lodash.isEmpty(results)) {
                const [clientGenerals] = results;
                await dbService._updateQueryService(
                    Container.get(DataSource).getRepository(ClientGeneral),
                    {
                        id: clientGenerals.id,
                        ...requestBody,
                    }
                );
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: { id: clientGenerals.id, ...requestBody },
                });
            }
            await ClientGeneralController.throwError(
                `Data not found of client Id ${req.userDetails.client_id}`
            );
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Get All Client Generals
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("general")
    async getAllClientGenerals(@Request() req: any): Promise<any> {
        try {
            const clientGenerals = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ClientGeneral),
                { where: { client_id: req.userDetails.client_id } }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                data: clientGenerals,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
