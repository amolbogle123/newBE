import {
    Body,
    Delete,
    Get,
    Path,
    Post,
    Request,
    Route,
    Security,
    Tags,
    Controller,
    Query,
} from "tsoa";
import { Location } from "../../../entities";
import dbService from "../../../services/db.service";
import Container from "typedi";
import { DataSource } from "typeorm";
import {
    AddLocationRequest,
    LocationResponse,
    MultipleDeleteLocationRequest,
    AddLocationResponse,
    DeleteResponse,
} from "../settings.interface";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import { CommonUtil } from "utils/common.util";
@Route("")
@Tags("Location")
export class LocationController extends Controller {
    /**
     * Add Location
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Post("location")
    async addLocation(
        @Body() requestBody: AddLocationRequest,
        @Request() request: any
    ): Promise<AddLocationResponse | unknown> {
        try {
            requestBody.clientId = request.userDetails.client_id;
            const results = await dbService._createQueryService(
                Container.get(DataSource).getRepository(Location),
                requestBody
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Delete Multiple Locations
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Delete("location")
    async deleteMultipleLocations(
        @Body() requestBody: MultipleDeleteLocationRequest
    ): Promise<DeleteResponse | unknown> {
        try {
            const { id: ids } = requestBody;
            const results = await dbService._deleteMultipleQueryService(
                Container.get(DataSource).getRepository(Location),
                { id: ids }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get All Locations
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("location")
    async getAllLocations(
        @Request() request: any,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<LocationResponse | unknown> {
        try {
            let whereCondition: any = {
                clientId: request.userDetails.client_id,
            };
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };

            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["createdOn"] = sortOrder;
            }
            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(Location),
                {
                    where: whereCondition,
                }
            );

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Location),
                {
                    where: whereCondition,
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );

            apiResponse.data = results;
            apiResponse.recordsTotal = totalRecordCount;
            apiResponse.recordsFiltered = pageSize;

            const totalPages = Math.ceil(totalRecordCount / pageSize);
            apiResponse.totalPages = totalPages;
            if (results) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }
            this.setStatus(204);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "No such location exists",
            });
        } catch (error) {
            console.log(error, "error");
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get location By ID
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("location/:id")
    async getLocationById(
        @Path() id: string
    ): Promise<LocationResponse | unknown> {
        try {
            const locations = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Location),
                { where: { id: Number(id) } }
            );
            if (locations) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: locations,
                });
            }
            this.setStatus(204);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "No such location exists",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
