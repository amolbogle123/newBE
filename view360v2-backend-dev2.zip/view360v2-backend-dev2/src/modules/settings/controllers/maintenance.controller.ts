import { ClientMaintenance } from "../../../entities";
import {
    Body,
    Get,
    Route,
    Security,
    Tags,
    Request,
    Patch,
    Controller,
} from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { UpdateMaintenance } from "../settings.interface";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import { dataSource } from "../../../core/data-source";

@Route("")
@Tags("Maintenance")
export class MaintenanceController extends Controller {
    /**
     * Get All mainatince
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("maintenance")
    async getData(@Request() request: any): Promise<any> {
        try {
            let whereCondition = { clientId: request.userDetails.client_id };
            const results = await dataSource
                .getRepository(ClientMaintenance)
                .findOne({
                    where: whereCondition,
                });

            return CommonHelper.apiSwaggerSuccessResponse({
                data: results,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get All mainatince
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Patch("maintenance")
    async update(
        @Body() requestBody: UpdateMaintenance,
        @Request() request: any
    ): Promise<any> {
        try {
            let responseResult = null;
            const results = await dataSource
                .getRepository(ClientMaintenance)
                .findOne({
                    where: {
                        clientId: request.userDetails.client_id,
                    },
                });

            if (results) {
                const payload = {
                    enable: requestBody.enableMaintenance ? 1 : 0,
                    config: requestBody.config ? JSON.stringify(requestBody.config) : null,
                };
                responseResult = await dataSource
                    .getRepository(ClientMaintenance)
                    .update(
                        { clientId: request.userDetails.client_id },
                        payload
                    );
            } else {
                const clientMaintenance = new ClientMaintenance();
                clientMaintenance.clientId = request.userDetails.client_id;
                clientMaintenance.createdBy = request.userDetails.id;
                clientMaintenance.enable = requestBody.enableMaintenance ? 1 : 0;
                clientMaintenance.config = requestBody.config ? JSON.stringify(requestBody.config) : null;

                responseResult = await Container.get(DataSource).manager.save(
                    clientMaintenance
                );
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: responseResult,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
