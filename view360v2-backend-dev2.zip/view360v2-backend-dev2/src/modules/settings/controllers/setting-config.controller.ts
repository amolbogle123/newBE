import {
    Body,
    Controller,
    Delete,
    Get,
    Hidden,
    Path,
    Post,
    Put,
    Request,
    Route,
    Security,
    Tags,
} from "tsoa";
import { SettingConfig } from "../../../entities";
import dbService from "../../../services/db.service";
import { LdapAuthUtil } from "../../../utils/ldap-auth";
import {
    AddUpdateSettingConfigRequest,
    DeleteSettingConfigRequest,
    AddSettingConfigResponse,
    UpdateSettingConfigResponse,
    DeleteResponse,
    AetSettingConfigResponse,
} from "../settings.interface";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
const nodemailer = require("nodemailer");
import Container from "typedi";
import { DataSource } from "typeorm";

type queryParams = {
    where?: {
        clientId: unknown;
        type: unknown;
    };
};
@Route("")
@Tags("Settings")
export class SettingConfigController extends Controller {
    /**
     * Test Setting Config
     * @param request
     * @param response
     * @param next
     */
    @Security("bearerAuth")
    @Post("settings/config/test-email")
    @Hidden()
    async testSettingConfig(@Request() request: any): Promise<any> {
        try {
            const transporter = nodemailer.createTransport({
                host: request.body.config.host,
                port: request.body.config.port,
                auth: {
                    user: request.body.config.username,
                    pass: request.body.config.password,
                },
            });

            // Define email options
            const mailOptions = {
                from: request.body.config.username,
                to: request.body.config.emailId,
                subject: "Test Mail",
                text: "This is a test email sent using SMTP.",
            };

            const results = await transporter.sendMail(mailOptions);
            return CommonHelper.apiSwaggerSuccessResponse(results);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Add Setting Config
     * @param request
     * @param response
     * @param next
     */

    @Security("bearerAuth")
    @Post("settings/config")
    @Hidden()
    async addSettingConfig(
        @Body() requestBody: AddUpdateSettingConfigRequest,
        @Request() request: any
    ): Promise<AddSettingConfigResponse | unknown> {
        console.log('addSettingConfig called.');
        try {
          console.log('requestBody', requestBody);
            const payload: any = {};

            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;
            payload.type = requestBody.type;
            payload.config = JSON.stringify(requestBody.config);

            const results = await dbService._createQueryService(
                Container.get(DataSource).getRepository(SettingConfig),
                payload
            );
            console.log('results', results);
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
          console.log('error', error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update Setting Config
     * @param request
     * @param response
     * @param next
     */
    @Security("bearerAuth")
    @Put("settings/config/:id")
    async updateSettingConfig(
        @Body() requestBody: AddUpdateSettingConfigRequest,
        @Path() id: string
    ): Promise<UpdateSettingConfigResponse | unknown> {
        try {
            const payload: any = {};

            payload.type = requestBody.type;
            payload.config = JSON.stringify(requestBody.config);

            const settingConfig = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(SettingConfig),
                { id, ...payload }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                data: settingConfig,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Delete Setting Config
     * @param request
     * @param response
     * @param next
     */
    @Security("bearerAuth")
    @Delete("settings/config")
    async deleteSettingConfig(
        @Body() requestBody: DeleteSettingConfigRequest
    ): Promise<DeleteResponse | unknown> {
        try {
            const results = await dbService._deleteQueryService(
                Container.get(DataSource).getRepository(SettingConfig),
                { id: requestBody.id }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Get Setting Config By ID
     * @param request
     * @param response
     * @param next
     */
    @Security("bearerAuth")
    @Get("settings/config/:id")
    async getSettingConfigById(
        @Path() id: string
    ): Promise<AetSettingConfigResponse | unknown> {
        try {
            const results = await dbService._findOneQueryService(
                Container.get(DataSource).getRepository(SettingConfig),
                { id: id }
            );
            if (results) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: results,
                });
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: "No such setting config exists",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Get All Setting Configs
     * @param request
     * @param response
     * @param next
     */
    @Security("bearerAuth")
    @Get("settings/configs/:type")
    async getAllSettingConfigs(
        @Request() request: any,
        @Path() type: string
    ): Promise<AetSettingConfigResponse | unknown> {
        try {
            const clientId = request.userDetails.client_id;
            const whereCondition: any = {
                where: { clientId, type: type },
            };

            const settingConfigs = await dbService._findQueryService(
                Container.get(DataSource).getRepository(SettingConfig),
                { ...whereCondition }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                data: settingConfigs,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Test Setting Config
     * @param request
     * @param response
     * @param next
     */
    @Security("bearerAuth")
    @Post("settings/config/test-ldap")
    @Hidden()
    async testSettingConfigLdap(@Body() requestBody: any): Promise<any> {
        try {
            const results = await LdapAuthUtil.ldapCheckUser(
                requestBody.config.analystLdapURL,
                requestBody.config.analystLdapUser,
                requestBody.config.analystLdapPassword
            );
            return CommonHelper.apiSwaggerSuccessResponse(results);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
