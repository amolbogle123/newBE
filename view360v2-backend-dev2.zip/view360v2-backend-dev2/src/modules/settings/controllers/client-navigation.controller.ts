import { Body, Get, Route, Request, Security, Tags, Patch, Controller } from "tsoa";
import { ClientNavigation } from "../../../entities";
import { CommonHelper, ApiErrorResponse } from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import Container from 'typedi';
import { DataSource } from "typeorm";
import { UpdateClientNavigation } from '../doc/clientNavigation-interface';

import { NavigationMenu } from "../../../models/navigation-menu";
import {cacheResponseData} from "../../../utils/redis.middleware";
import {CommonUtil} from "../../../utils/common.util";

@Route('')
@Tags('Client Navigation')
export class ClientNavigationController extends Controller{

    /**
     * Get All Client Navigations
     * @param request
     * @param response
     * @param next
     */
    @Security('berarerAuth')
    @Get('navigation')
    async getAllClientNavigations(
        @Request() request: any,
    ): Promise<any> {
        try {
            const response = {data: null};
            const criteria: any = {
                clientId: request.userDetails.client_id,
                active: 1,
            };
            console.time("navigation");
            const results = await dbService._findOneQueryService(
                Container.get(DataSource).getRepository(ClientNavigation),
                { where: criteria, select: ["menu"] }
            );
            if (results) {
                response.data = {
                    menu: results.menu,
                };
            }
            
            await cacheResponseData(request.originalUrl, response);
            console.timeEnd("navigation");
            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update Client Navigation
     * @param request
     * @param response
     * @param next
     */
    @Security('berarerAuth')
    @Patch('navigation')
    async updateClientNavigation(
        @Body() requestBody: UpdateClientNavigation,
        @Request() request: any
    ): Promise<any> {
        try {
            const updateData: any = {
                menu: requestBody.menu,
                updatedBy: request.userDetails.id,
                active: 1,
            };
            let result = null;
            const whereClause = { clientId: request.userDetails.client_id };
            const hasNavData: boolean =
                (await dbService._countQueryService(Container.get(DataSource).getRepository(ClientNavigation), { where: whereClause })) > 0;
            if (hasNavData) {
                result = await Container.get(DataSource).getRepository(ClientNavigation).update(
                    { clientId: request.userDetails.client_id },
                    updateData
                );
            }
            return CommonHelper.apiSwaggerSuccessResponse({data: result});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * @param request
     * @param response
     * @param next
     * @returns
     * @memberof ClientNavigationController
     * @description Set Menu Settings to default
     * */
    @Security('berarerAuth')
    @Patch('navigation/reset-menu')
    async setMenuSettingsToDefault(
        @Request() request: any,
    ): Promise<any> {
        try {
            // Main Navigation Menu -- Start
            const navigationMenu: NavigationMenu[] = CommonUtil.setNavigationMenu();
            // Main Navigation Menu -- End
            const updateData: any = {
                menu: JSON.stringify([{
                    "name": "Analytics",
                    "type": "section",
                    "sectionTextColor": "#212529",
                    "sectionBgColor": "#fff",
                    "menuItems": navigationMenu
                }]),
                updatedBy: request.userDetails.id,
                active: 1,
            };
            let result = null;
            const whereClause = { clientId: request.userDetails.client_id };
            const hasNavData: boolean =
                (await dbService._countQueryService(Container.get(DataSource).getRepository(ClientNavigation), { where: whereClause })) > 0;
            if (hasNavData) {
                result = await Container.get(DataSource).getRepository(ClientNavigation).update(
                    { clientId: request.userDetails.client_id },
                    updateData
                );
            }
            return CommonHelper.apiSwaggerSuccessResponse({data: result});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}


