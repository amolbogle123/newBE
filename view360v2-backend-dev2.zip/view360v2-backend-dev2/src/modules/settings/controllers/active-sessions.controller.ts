import { ActiveSession } from "entities/active-session";
import lodash from "lodash";
import dbService from "services/db.service";
import { Body, Controller, Get, Patch, Post, Request, Route, Security, Tags } from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { CreateActiveSession, UpdateActiveSession } from "../doc/activeSession-interface";

@Route("")
@Tags("Active Session")
export class ActiveSessionController extends Controller {
    static async throwError(errorMessage: string): Promise<void> {
        throw Error(errorMessage);
    }

    /**
     * Add Active Session
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Post("active-session")
    async addActiveSession(
        @Body() requestBody: CreateActiveSession,
        @Request() request: any
    ): Promise<any> {
        try {
            const payload: any = requestBody;

            const activeSession = await dbService._createQueryService(
                Container.get(DataSource).getRepository(ActiveSession),
                payload
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: activeSession,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }


    /**
     * Get active session on ID = 1
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("active-session")
    async getActiveSession(): Promise<any> {
        try {
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ActiveSession),
                { where: { id: 1 } }
            );
            if (results) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: results,
                });
            }
            this.setStatus(204);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "No such active date exists",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
    * Update Client General
    * @param req
    * @param res
    * @param next
    */
    @Security('bearerAuth')
    @Patch('active-session')
    async updateActiveSession(
        @Body() requestBody: UpdateActiveSession,
        @Request() req: any,
    ): Promise<any> {
        try {
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ActiveSession),
                { where: { id: 1 } }
            );

            if (results.length && !lodash.isEmpty(results)) {
                await dbService._updateQueryService(Container.get(DataSource).getRepository(ActiveSession), {
                    id: 1,
                    updatedAt: new Date(),
                    isLogoutPerformed: 0,
                    ...requestBody,
                });
                return CommonHelper.apiSwaggerSuccessResponse({ data: { id: 1, ...requestBody } });
            }
            await ActiveSessionController.throwError(
                `No expiry date found.`
            );
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }

}