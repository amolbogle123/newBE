import { Body, Get, Route, Request, Security, Tags, Patch, Controller, Post, Delete, Path, Query } from "tsoa";
import { ClientLandingPage } from "../../../entities";
import { CommonHelper, ApiErrorResponse } from "../../../utils/helpers/common.helper";
import { LandingPageHelper } from "../utils/helpers/landing-page.helper";
import dbService from "../../../services/db.service";
import Container from 'typedi';
import { DataSource } from "typeorm";
import { DeleteMultiple, CreateLandingPage } from '../doc/clientLandingPage-interface';
import { CommonUtil } from "utils/common.util";
@Route('landing-page')
@Tags('Client Landing Page')
export class ClientLandingPageController extends Controller {

    // Helpers
    private landingPageHelper: LandingPageHelper = new LandingPageHelper();

    @Security("bearerAuth")
    @Post("/")
    async addConfig(
        @Body() requestBody: CreateLandingPage,
        @Request() request: any
    ): Promise<any> {
        try {
            const payload: any = requestBody;
            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;
            payload.updatedBy = request.userDetails.id;

            const landingResult = await dbService._createQueryService(
                Container.get(DataSource).getRepository(ClientLandingPage),
                payload
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: landingResult,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("berarerAuth")
    @Patch("/:id")
    async updateModule(
        @Path() id: string,
        @Body() requestBody: any
    ): Promise<any> {
        try {
            const landingResult = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(ClientLandingPage),
                { id: id, ...requestBody }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                data: landingResult,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('berarerAuth')
    @Get('/')
    async list(
        @Request() request: any,
        @Query('page') page: number = 1,
        @Query('pageSize') pageSize: number = 10,
        @Query('sortOrder') sortOrder?: number,
        @Query('sortField') sortField?: string,
        @Query('filters') filters?: string
    ): Promise<any> {
        try {

            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };

            let whereCondition = { clientId: request.userDetails.client_id };

            whereCondition = await CommonUtil.applyFilter(filters, whereCondition);


            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject['name'] = sortOrder;
            }


            const result = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ClientLandingPage),
                {
                    where: whereCondition,
                    // Use queryObj directly instead of spreading it
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );

            const totalRecordCount = await Container.get(DataSource)
                .getRepository(ClientLandingPage)
                .count();
            if (result) {
                apiResponse.data = result;
            }

            apiResponse.data = result;
            apiResponse.recordsTotal = totalRecordCount;
            apiResponse.recordsFiltered = pageSize;

            const totalPages = Math.ceil(totalRecordCount / pageSize);
            apiResponse.totalPages = totalPages;
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("/")
    async deleteMultiple(
        @Body() requestBody: DeleteMultiple
    ): Promise<any> {
        try {
            const { id: ids } = requestBody;

            const results = await dbService._deleteMultipleQueryService(
                Container.get(DataSource).getRepository(ClientLandingPage),
                { id: ids }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('berarerAuth')
    @Get('/default-url')
    async defaultRedirectUrl(
        @Request() request: any,
    ): Promise<any> {
        try {
            const response = { data: null };
            const whereClause = { clientId: request.userDetails.client_id, active: 1 };
            const result = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ClientLandingPage),
                { where: whereClause, select: ["config"] }
            );
            response.data = await this.landingPageHelper.getDefaultUrl(result, request.userDetails);

            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('berarerAuth')
    @Get('/all')
    async getAll(
        @Request() request: any,
    ): Promise<any> {
        try {
            const response = { data: null };
            const whereClause = { clientId: request.userDetails.client_id };
            const result = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ClientLandingPage),
                { where: whereClause, select: ["config"] }
            );
            response.data = result;

            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}


