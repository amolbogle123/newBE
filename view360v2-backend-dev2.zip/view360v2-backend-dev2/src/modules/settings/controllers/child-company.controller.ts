import {
    Body,
    Path,
    Post,
    Get,
    Route,
    Security,
    Tags,
    Request,
    Delete,
    Controller,
    Query,
} from "tsoa";

import { ChildCompany } from "../../../entities";
import {
    CommonHelper,
    ApiErrorResponse,
} from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import {
    CreateChildCompany,
    DeleteMultipleChildCompanies,
    DeleteResponse,
} from "../doc/childCompany-interface";
import Container from "typedi";
import { DataSource } from "typeorm";
import { CommonUtil } from "utils/common.util";

@Route("")
@Tags("Child Company")
export class ChildCompanyController extends Controller {
    /**
     * Add Child Company
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Post("child-company")
    async addChildCompany(
        @Body() requestBody: CreateChildCompany,
        @Request() request: any
    ): Promise<any> {
        try {
            const payload: any = requestBody;
            payload.clientId = request.userDetails.client_id;
            payload.locations = payload.locations
                ? payload.locations.join(",")
                : null;
            const childCompany = await dbService._createQueryService(
                Container.get(DataSource).getRepository(ChildCompany),
                payload
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: childCompany,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Delete Multiple Child Companies
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Delete("child-company")
    async deleteMultipleChildCompanies(
        @Body() requestBody: DeleteMultipleChildCompanies
    ): Promise<DeleteResponse | any> {
        try {
            const { id: ids } = requestBody;
            // Here if ids will be [1,2,3] then we can perform this operation
            const results = await dbService._deleteMultipleQueryService(
                Container.get(DataSource).getRepository(ChildCompany),
                { id: ids }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get All Child Companies
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("child-company")
    async getAllChildCompanies(
        @Request() request: any,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<any> {
        try {
            let whereCondition: any = {
                clientId: request.userDetails.client_id,
            };
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };

            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            console.log(whereCondition,'whereConditionwhereCondition')

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["createdOn"] = sortOrder;
            }

            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(ChildCompany),
                {
                    where: whereCondition,
                }
            );
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ChildCompany),
                {
                    where: whereCondition,
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );

            apiResponse.data = results;
            apiResponse.recordsTotal = totalRecordCount;
            apiResponse.recordsFiltered = pageSize;

            const totalPages = Math.ceil(totalRecordCount / pageSize);
            apiResponse.totalPages = totalPages;
            if (results) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }
            this.setStatus(204);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "No such child company exists",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get child comapnies By ID
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("child-company/:id")
    async getChildCompanyById(@Path() id: string): Promise<any> {
        try {
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ChildCompany),
                { where: { id: id } }
            );
            if (results) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: results,
                });
            }
            this.setStatus(204);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "No such child company exists",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
