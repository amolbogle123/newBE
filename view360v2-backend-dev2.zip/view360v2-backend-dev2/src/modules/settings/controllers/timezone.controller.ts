import { Request, Response, NextFunction } from "express";
import momentTz from "moment-timezone";

export class TimezoneController {
    /**
     * Add Module
     * @param req
     * @param res
     * @param next
     */
    async list(
        req: Request | any,
        res: Response,
        next: NextFunction
    ): Promise<any> {
        try {
            const response = { timezones: null, serverTimezone: null };

            response.timezones = momentTz.tz.names();
            response.serverTimezone = momentTz.tz.guess();

            res.status(200).json({ status: "success", data: response });
        } catch (error) {
            res.status(200).json(error);
        }
    }
}
