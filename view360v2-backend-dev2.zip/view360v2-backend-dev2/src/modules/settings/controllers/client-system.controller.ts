import {Body, Controller, Get, Path, Put, Route, Security, Tags} from "tsoa";
import { ClientSystem } from "../../../entities";
import dbService from "../../../services/db.service";
import Container from 'typedi';
import { DataSource } from "typeorm";
import {ApiErrorResponse, CommonHelper} from "../../../utils/helpers/common.helper";

@Route('')
@Tags('Settings')
export class ClientSystemController extends Controller{

    /**
     * Update Client System
     */
    @Security('bearerAuth')
    @Put('settings/client-system/:id')
    async updateClientSystem(
        @Body() requestBody: any,
        @Path() id: string
    ): Promise<any> {
        try {
            const clientSystem = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(ClientSystem),
                { id, ...requestBody }
            );
            return CommonHelper.apiSwaggerSuccessResponse(clientSystem);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Get All Client Systems
     */
    @Get('settings/client-systems')
    @Security('bearerAuth')
    async getAllClientSystems(
    ): Promise<any> {
        try {
            const clientSystems = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ClientSystem),
                {}
            );
            return CommonHelper.apiSwaggerSuccessResponse(clientSystems);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
