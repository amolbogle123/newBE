import {
    Body,
    Delete,
    Get,
    Path,
    Post,
    Request,
    Route,
    Security,
    Tags,
    Controller,
    Query,
} from "tsoa";
import { CompanyDepartment } from "../../../entities";
import dbService from "../../../services/db.service";
import Container from "typedi";
import { DataSource } from "typeorm";
import {
    AddDepartmentRequest,
    MultipleDeleteDepartmentRequest,
    GetDepartmentResponse,
    DeleteResponse,
    AddDepartmentResponse,
} from "../settings.interface";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import { CommonUtil } from "utils/common.util";

@Route("")
@Tags("Department")
export class CompanyDepartmentController extends Controller {
    /**
     * Add Company Department
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Post("department")
    async addCompanyDepartment(
        @Body() requestBody: AddDepartmentRequest,
        @Request() request: any
    ): Promise<AddDepartmentResponse | unknown> {
        try {
            const companyDepartment = await dbService._createQueryService(
                Container.get(DataSource).getRepository(CompanyDepartment),
                requestBody
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: companyDepartment,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Delete Multiple Company Departments
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Delete("department")
    async deleteMultipleCompanyDepartments(
        @Body() requestBody: MultipleDeleteDepartmentRequest
    ): Promise<DeleteResponse | unknown> {
        try {
            const { id: ids } = requestBody;
            const results = await dbService._deleteMultipleQueryService(
                Container.get(DataSource).getRepository(CompanyDepartment),
                { id: ids }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get All Company Departments
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("department")
    async getAllCompanyDepartments(
        @Request() request: any,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<GetDepartmentResponse | unknown> {
        try {
            let whereCondition: any = {};
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };

            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["createdOn"] = sortOrder;
            }

            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(CompanyDepartment),
                {
                    where: whereCondition,
                }
            );
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(CompanyDepartment),
                {
                    where: whereCondition,
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );

            apiResponse.data = results;
            apiResponse.recordsTotal = totalRecordCount;
            apiResponse.recordsFiltered = pageSize;

            const totalPages = Math.ceil(totalRecordCount / pageSize);
            apiResponse.totalPages = totalPages;
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get company department By ID
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("department/:id")
    async getCompanyDepartmentById(
        @Path() id: string
    ): Promise<GetDepartmentResponse | unknown> {
        try {
            const results = await dbService._findOneQueryService(
                Container.get(DataSource).getRepository(CompanyDepartment),
                { where: { id: id } }
            );
            if (results) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: results,
                });
            }
            this.setStatus(204);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "No such company department exists",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
