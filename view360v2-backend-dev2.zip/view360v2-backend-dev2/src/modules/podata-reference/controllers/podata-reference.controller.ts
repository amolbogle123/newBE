import { dataSource } from "core/data-source";
import { DataRelationBuilder } from "entities";
import dbService from "services/db.service";
import { Controller, Get, Path, Post, Request, Route, Tags } from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { MySQLExecutorUtil } from "../../connectors/executor-utils/mySQLExecutor.util";
import { ChartExecutionUtil } from "../../dynamic-dashboard/utils/chartExecution.util";
import { PODataReferenceService } from "../services/podata-reference.service";

@Route("podata-reference")
@Tags("POData Reference")
export class PODataReferenceController extends Controller {
    private podataReferenceService: PODataReferenceService;

    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    constructor() {
        super();
        this.podataReferenceService = new PODataReferenceService();
    }

    @Get(":referenceId")
    async getPODataReference(
        @Request() request: any,
        @Path() referenceId: string
    ): Promise<void> {
        try {
            const response = await this.podataReferenceService.getPODataReference(referenceId, '');

            if (response) {
                return CommonHelper.apiSwaggerSuccessResponse(response);
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({ data: null });
            }
        } catch (error) {
            console.log("Error in getPODataReference :: ", error)
            const apiErrorResponse: ApiErrorResponse = {
                error: error
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("")
    async createPODataReference(
        @Request() request: any
    ): Promise<void> {
        try {
            let message = '';
            const responseData = {
                updatedCount: 0,
                skippedCount: 0,
                insertUpdate: false
            }
            const publicTableName = request.body?.publicTableName || "";
            const referenceId = request.body.referenceId.split(",");
            const connectorId = request.body.connectorID;
            const selectedFilterName = request.body.selectedFilterName;
            const connectorDetails = {};
            connectorDetails['columnMapperList'] = request.body.columnMapperList;
            connectorDetails['connectorTableName'] = request.body.connectorTableName;
            connectorDetails['connectorTableQuery'] = request.body.connectorTableQuery;

            let getAllData;
            for (const id of referenceId) {
                const actionObject: any = request.body.actionObject;
                if(actionObject?.setValueType === 'Static') {
                    const checkExisting = await this.podataReferenceService.getPODataReference(id, publicTableName);
                    if (checkExisting) {
                            const value = await this.checkExceptionStatusAlreadyMark(checkExisting, actionObject)
                            if (value && actionObject.refColumn.key !== 'SUBMITTED_TO_PO') {
                                responseData.skippedCount += 1;
                            } else {
                               const updateResult = await this.podataReferenceService.executeUpdate(publicTableName,actionObject.refColumn.key,actionObject.staticValue,id,request.userDetails.id,'')
                                responseData.insertUpdate = updateResult
                                responseData.updatedCount += 1;
                            }
                    } else {
                        if(request.body.connectorID) {
                            getAllData = await this.getAllDataOfPOAndGRN(connectorId, id, connectorDetails['connectorTableQuery']);
                            const insertResult = await this.podataReferenceService.executeInsert(publicTableName,actionObject.refColumn.key, actionObject.staticValue.toLowerCase(), id,request.userDetails.id,getAllData.data[0] , selectedFilterName, '', connectorDetails);
                            responseData.insertUpdate = insertResult
                        }
                    }
                } else if (actionObject?.setValueType === 'Dynamic') {
                    const roleId = actionObject.roleId;
                    if(roleId) {
                        const query = `SELECT users.id, COUNT(${publicTableName}.${actionObject?.refColumn?.key || "IA_REVIEWER"}) AS entry_count FROM users LEFT OUTER JOIN ${publicTableName} ON users.id = ${publicTableName}.IA_REVIEWER WHERE users.ROLE_ID = '${roleId}' GROUP BY users.id ORDER BY entry_count ASC`;
                        const userList = await dataSource.manager.query(query);
                        if(userList && userList.length > 0) {
                            const checkExisting = await this.podataReferenceService.getPODataReference(id, publicTableName);
                            if (checkExisting) {
                                const updateResult = await this.podataReferenceService.executeUpdate(publicTableName,actionObject.refColumn.key,actionObject.staticValue,id,request.userDetails.id,userList[0].id)
                                responseData.insertUpdate = updateResult
                            } else {
                                getAllData = await this.getAllDataOfPOAndGRN(connectorId, id, connectorDetails['connectorTableQuery']);
                                const insertResult = await this.podataReferenceService.executeInsert(publicTableName,actionObject.refColumn.key, actionObject.staticValue, id,request.userDetails.id,getAllData.data[0] , selectedFilterName, userList[0].id, connectorDetails);
                                responseData.insertUpdate = insertResult
                            }
                        } else {
                            responseData.insertUpdate = false
                        }
                    } else {
                        responseData.insertUpdate = false
                    }
                } else {
                    responseData.insertUpdate = false
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse({ data: responseData, message: message });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    async checkExceptionStatusAlreadyMark(existingValues, actionObject) {
        const statusValue = existingValues.EXCEPTION_STATUS;
        const changingValue = await this.convertStringBooleanToBit(actionObject.staticValue);
        if(statusValue === changingValue) {
            return true;
        } else if(statusValue !== changingValue) {
            return false;
        } else {
            return null;
        }
    }
    async convertStringBooleanToBit(value: string) {
        if (value.toLowerCase() === 'true') {
            return 1;
        } else if (value.toLowerCase() === 'false') {
            return 0;
        } else {
            return null;
        }
    }

    async getAllDataOfPOAndGRN(connectorId, referenceId, connectorTableQuery) {
        try {
            let accountConfig;
            let dataRelationBuilder: any = await dbService._findQueryService(
                Container.get(DataSource).getRepository(DataRelationBuilder),
                {
                    where: { id: connectorId },
                    select: ["connectorId"],
                }
            );
            if(dataRelationBuilder && Array.isArray(dataRelationBuilder) && dataRelationBuilder.length > 0) {
                const reqData = {body: {widgetAccount: dataRelationBuilder[0].connectorId} }
                accountConfig = await ChartExecutionUtil.getAccountConfig(reqData);
                const query = await this.replacePlaceholders(connectorTableQuery, referenceId);
                if(accountConfig) {
                    return await MySQLExecutorUtil.executeMYSQLQuery(query, accountConfig.accountConfigDetails);
                }
            }
        } catch (e) {
            throw new Error(e);
        }
    }

   async replacePlaceholders(text: string, replacements: { [key: string]: string }) {
        return text.replace(/\[@(\w+)\]/g, (_, key) => {
            return `'${replacements}'` ;
        });
    }
}
