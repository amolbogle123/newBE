import { dataSource } from "core/data-source";
import {v4 as generateUuid} from "uuid";

export class PODataReferenceService {
    async getPODataReference(referenceId: string, publicTableName: string) {
        let query = `SELECT * FROM ${publicTableName} WHERE REFERENCE_ID = '${referenceId}'`;
        const poList = await dataSource.manager.query(query);
        if (poList?.length > 0) {
            return poList[0];
        }
        return null;
    }

    async createPODataReference(referenceId: string, referenceData: any, createdBy: string, getAllData: any ,userId: string, selectedFilterName: string) {
        if((referenceData.refColumn.key === 'SUBMITTED_TO_PO' || referenceData.refColumn.key === 'EXCEPTION_STATUS') && typeof referenceData.staticValue === 'string') {
            referenceData.staticValue = referenceData.staticValue.toLowerCase() === "true" ? true : referenceData.staticValue.toLowerCase() === "false" ? false : null
        }
        let data = {};
        if(referenceData.refColumn.key === 'SUBMITTED_TO_PO') {
            data = {
                refId: referenceId,
                submittedToPo: referenceData.refColumn.key === 'SUBMITTED_TO_PO' ? referenceData.staticValue : null,
                createdBy: createdBy
            }
        } else if(referenceData.refColumn.key === 'EXCEPTION_STATUS') {
            data = {
                refId: referenceId,
                exceptionStatus: referenceData.refColumn.key === 'EXCEPTION_STATUS' ? referenceData.staticValue : null,
                createdBy: createdBy,
            }
        } else if (referenceData.refColumn.key === 'IA_REVIEWER') {
            data = {
                refId: referenceId,
                iaReviewer: referenceData.refColumn.key === 'IA_REVIEWER' ? userId : null,
                createdBy: createdBy,
            }
        }
        const appendObject = await this.appendDataObject(data, getAllData, selectedFilterName);
        // return await Container.get(DataSource).getRepository(PODataReference).save(appendObject);
    }


    async updatePODataReference(publicTableName: string, referenceId: string, referenceData: any, updatedBy: string, userId: string) {
        let staticValue;
        if((referenceData.refColumn.key === 'SUBMITTED_TO_PO' || referenceData.refColumn.key === 'EXCEPTION_STATUS') && typeof referenceData.staticValue === 'string') {
            staticValue = referenceData.staticValue.toLowerCase() === "true" ? true : referenceData.staticValue.toLowerCase() === "false" ? false : null
        }
        let data = {};
        if(referenceData.refColumn.key === 'SUBMITTED_TO_PO') {
            data = {
                refId: referenceId,
                submittedToPo: referenceData.refColumn.key === 'SUBMITTED_TO_PO' ? staticValue : null,
                updatedBy: updatedBy,
                updatedOn: new Date()
            }
        } else if(referenceData.refColumn.key === 'EXCEPTION_STATUS') {
            data = {
                refId: referenceId,
                exceptionStatus: referenceData.refColumn.key === 'EXCEPTION_STATUS' ? staticValue : null,
                updatedBy: updatedBy,
                updatedOn: new Date()
            }
        } else if (referenceData.refColumn.key === 'IA_REVIEWER') {
            data = {
                refId: referenceId,
                iaReviewer: referenceData.refColumn.key === 'IA_REVIEWER' ? userId : null,
                updatedBy: updatedBy,
                updatedOn: new Date()
            }
        }
        // return await Container.get(DataSource).getRepository('PODataReference').update({ refId: referenceId }, data);
        let query = `UPDATE ${publicTableName} SET  WHERE REFERENCE_ID = '${referenceId}'`;
        await dataSource.manager.query(query);
        return true;
    }

    async appendDataObject(data, getAllData, selectedFilterName) {
        const insertData = {
            po_document_type: getAllData.data[0].document_type,
            po_document_no: getAllData.data[0].document_no,
            po_line_no: getAllData.data[0].line_no,
            po_poln: getAllData.data[0].poln,
            po_approvel_id: getAllData.data[0].approvel_id,
            po_approval_date: getAllData.data[0].approval_date,
            'po_buy-from_vendor_no': getAllData.data[0]['buy-from_vendor_no'],
            po_type: getAllData.data[0].type,
            po_no: getAllData.data[0].no,
            po_description: getAllData.data[0].description,
            po_description_2: getAllData.data[0].description_2,
            po_item: getAllData.data[0].item,
            po_unit_of_measure: getAllData.data[0].unit_of_measure,
            po_quantity: getAllData.data[0].quantity,
            po_outstanding_quantity: getAllData.data[0].outstanding_quantity,
            'po_qty._to_invoice': getAllData.data[0]['qty._to_invoice'],
            'po_qty._to_receive' : getAllData.data[0]['qty._to_receive'],
            po_amount: getAllData.data[0].amount,
            po_shortcut_dimension_1_code: getAllData.data[0].shortcut_dimension_1_code,
            po_rate_pu: getAllData.data[0].rate_pu,
            po_shortcut_dimension_2_code: getAllData.data[0].shortcut_dimension_2_code,
            po_job_no: getAllData.data[0].job_no,
            po_quantity_received: getAllData.data[0].quantity_received,
            po_quantity_invoiced: getAllData.data[0].quantity_invoiced,
            po_receipt_no: getAllData.data[0].receipt_no,
            po_order_no: getAllData.data[0].order_no,
            po_order_line_no: getAllData.data[0].order_line_no,
            'po_pay-to_vendor_no': getAllData.data[0]['pay-to_vendor_no'],
            'po_gen._bus._posting_group': getAllData.data[0]['gen._bus._posting_group'],
            'po_gen._prod._posting_group': getAllData.data[0]['gen._prod._posting_group'],
            po_transaction_type: getAllData.data[0].transaction_type,
            po_transport_method: getAllData.data[0].transport_method,
            po_blanket_order_no: getAllData.data[0].blanket_order_no,
            po_blanket_order_line_no: getAllData.data[0].blanket_order_line_no,
            po_dimension_set_id: getAllData.data[0].dimension_set_id,
            po_job_task_no: getAllData.data[0].job_task_no,
            po_unit_of_measure_code: getAllData.data[0].unit_of_measure_code,
            po_depreciation_book_code: getAllData.data[0].depreciation_book_code,
            po_responsibility_center: getAllData.data[0].responsibility_center,
            po_item_category_code: getAllData.data[0].item_category_code,
            po_purchasing_code: getAllData.data[0].purchasing_code,
            po_gst_group_code: getAllData.data[0].gst_group_code,
            'po_hsn/sac_code': getAllData.data[0]['hsn/sac_code'],
            po_state_code: getAllData.data[0].state_code,
            po_charge_group_code: getAllData.data[0].charge_group_code,
            po_nature_of_remittance: getAllData.data[0].nature_of_remittance,
            po_act_applicable: getAllData.data[0].act_applicable,
            po_shortcut_dimension_4_code: getAllData.data[0].shortcut_dimension_4_code,
            po_shortcut_dimension_6_code: getAllData.data[0].shortcut_dimension_6_code,
            po_job_master_code: getAllData.data[0].job_master_code,
            po_indent_no: getAllData.data[0].indent_no,
            po_indent_line_no: getAllData.data[0].indent_line_no,
            po_parallel_unit_of_measure_code: getAllData.data[0].parallel_unit_of_measure_code,
            po_job_code: getAllData.data[0].job_code,
            po_purchase_category: getAllData.data[0].purchase_category,
            po_ic_gst_group_code: getAllData.data[0].ic_gst_group_code,
            'po_ic_hsn/sac_code': getAllData.data[0]['ic_hsn/sac_code'],
            po_budget_name: getAllData.data[0].budget_name,
            po_created_on: getAllData.data[0].created_on,
            grn_document_type: getAllData.data[0].GRN_document_type,
            grn_document_no: getAllData.data[0].GRN_document_no,
            grn_line_no: getAllData.data[0].GRN_line_no,
            grn_purchase_order_no: getAllData.data[0].GRN_purchase_order_no,
            grn_po_qty: getAllData.data[0].GRN_po_qty,
            grn_received_quantity: getAllData.data[0].GRN_received_quantity,
            grn_vendor_measurment_qty: getAllData.data[0].GRN_vendor_measurment_qty,
            grn_portal_status: getAllData.data[0].GRN_portal_status,
            grn_sender_id: getAllData.data[0].GRN_sender_id,
            'grn_date-time_sent_for_approval': getAllData.data[0]['GRN_date-time_sent_for_approval'],
            grn_approver_id: getAllData.data[0].GRN_approver_id,
            'grn_approval-date-time': getAllData.data[0]['GRN_approval-date-time'],
            grn_approval_status: getAllData.data[0].GRN_approval_status,
            poItemSelected: selectedFilterName,
            grn_created_on: getAllData.data[0].GRN_created_on
        }
        return { ...data, ...insertData };
    }

    async executeInsert(tableName,insertColumn,insertValue, refID ,userID, dataObject, selectedFilterName, IA_ReviewerID, connectorDetails) {
        try {
            const id = await generateUuid();
            let columns = [];
            let values = [];
            connectorDetails.columnMapperList.forEach(item => {
                if(item.connectorTableColumn !== null) {
                    columns.push(`\`${item.publicTableColumn}\``);
                    if (item.connectorTableColumn) {
                        //const val = dataObject[item.connectorTableColumn];
                        values.push(`'${dataObject[item.connectorTableColumn]}'`); // Assume values are strings, adjust as necessary
                    }
                } else {
                    if(item.publicTableColumn.toLowerCase() === 'id' || item.publicTableColumn.toLowerCase() === 'uid') {
                        columns.push(`\`${item.publicTableColumn}\``);
                        values.push(`'${id}'`); // Assume values are strings, adjust as necessary
                    }
                    if(item.publicTableColumn === 'po_item_selected') {
                        columns.push(`\`${item.publicTableColumn}\``);
                        values.push(`'${selectedFilterName}'`); // Assume values are strings, adjust as necessary
                    }
                }
            });
            if (insertValue && insertValue.toLowerCase() === 'true') {
                insertValue = 1;
            } else if (insertValue && insertValue.toLowerCase() === 'false') {
                insertValue = 0;
            } else {
                insertValue = `'${IA_ReviewerID}'`
            }
            columns.push(`\`${insertColumn}\``);
            values.push( `${insertValue}` );
            const columnsString = columns.join(', ');
            const valuesString = values.join(', ');
            const insertQuery = `INSERT INTO ${tableName} (${columnsString}) VALUES (${valuesString});`;
            const insertResult = await dataSource.manager.query(insertQuery);
            return true
        } catch (e) {
            return false;
        }
    }

    async executeUpdate(tableName,insertColumn,insertValue, refID ,userID, IA_ReviewerID) {
        try {
            if (insertValue && insertValue.toLowerCase() === 'true') {
                insertValue = 1;
            } else if (insertValue && insertValue.toLowerCase() === 'false') {
                insertValue = 0;
            } else {
                insertValue = "'"+ IA_ReviewerID + "'";
            }
            const updateQuery = `UPDATE ${tableName} SET ${insertColumn} = ${insertValue} WHERE REFERENCE_ID= '${refID}' `
            const updateResult = await dataSource.manager.query(updateQuery);
            return true
        } catch (e) {
            return false;
        }
    }

}
