import dbService from "../../../services/db.service";
import Container from "typedi";
import { DataSource } from "typeorm";
import { SettingConfig } from "../../../entities";
import { ConnectorHelper } from "../../../utils/helpers/connector.helper";

export class SentimentalService {
    async getSentimentalConfig(requestBody): Promise<any> {
        return new Promise(async (resolve) => {
            const response = {
                config: null,
            };
            try {
                const results = await dbService._findQueryService(
                    Container.get(DataSource).getRepository(SettingConfig),
                    {
                        where: { type: "MAIL_ACCOUNT_KEY" },
                    }
                );
                if (results?.length) {
                    const config = results[0].config
                        ? JSON.parse(results[0].config)
                        : {};
                    if (config?.sentimentalAPI) {
                        const connectorParams = {
                            feedback: requestBody?.body || "",
                        };
                        const sentiApiResponse =
                            await ConnectorHelper.apiConnector(
                                config.sentimentalAPI,
                                connectorParams
                            );
                        if (
                            sentiApiResponse?.status === "success" &&
                            sentiApiResponse?.data
                        ) {
                            response.config = sentiApiResponse.data;
                        }
                    }
                }

                resolve(response);
            } catch (error) {
                resolve(response);
            }
        });
    }
}
