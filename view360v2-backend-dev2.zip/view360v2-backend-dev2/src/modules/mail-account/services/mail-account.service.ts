import gmailApi from "../../../utils/gmailApi.util";

export class MailAccountService {
    async getProfileDetails(email, tokenConfig): Promise<any> {
        return new Promise(async (resolve) => {
            const response = {
                data: null,
                error: null,
            };

            try {
                const tokenDetails: any = await gmailApi.getToken(tokenConfig);
                if (tokenDetails?.token) {
                    // const results = await gmailApi.getAllEmailByAdmin(
                    //     '../../public/gmail-access/gmail-admin-test.json'
                    // );
                    // const resultsEmail: any = await gmailApi.getEmailListByAdmin(
                    //     '../../public/gmail-access/gmail-admin-test.json',
                    //     "omi@epikso.com"
                    // );
                    // // console.log('resultsEmail', resultsEmail);
                    // const results = await gmailApi.getMailDetails(
                    //     "omi@epikso.com",
                    //     resultsEmail?.token?.access_token,
                    //     "18eeee760905726b"
                    // );
                    // console.log('results 18eeee760905726b', results);

                    // const results = await gmailApi.getAllEmailByAdmin(
                    //     '../../public/gmail-access/gmail-admin-test.json'
                    // );
                    // const resultsEmail: any = await gmailApi.getEmailListByAdmin(
                    //     '../../public/gmail-access/gmail-admin-test.json',
                    //     "omi@epikso.com"
                    // );
                    // console.log('resultsEmail', resultsEmail);
                    // const results = await gmailApi.getMailDetails(
                    //     "omi@epikso.com",
                    //     resultsEmail?.token?.access_token,
                    //     "18ee6befd5ac0699"
                    // );
                    // console.log('results 18ee6befd5ac0699', results);

                    const result = await gmailApi.getProfileDetails(
                        email,
                        tokenDetails.token
                    );
                    if (result) {
                        response.data = result;
                    }
                } else {
                    response.error = tokenDetails.error;
                }
                resolve(response);
            } catch (error) {
                resolve(response);
            }
        });
    }
    async getMailList(email, token, config): Promise<any> {
        return new Promise(async (resolve) => {
            const response = {
                data: null,
            };
            try {
                const result = await gmailApi.getMailList(email, token, config);
                if (result) {
                    response.data = result;
                }
                resolve(response);
            } catch (error) {
                resolve(response);
            }
        });
    }
    async getMaildetails(email, token, threadId): Promise<any> {
        return new Promise(async (resolve) => {
            const response = {
                data: null,
            };
            try {
                const result = await gmailApi.getMailDetails(
                    email,
                    token,
                    threadId
                );
                if (result) {
                    response.data = result;
                }
                resolve(response);
            } catch (error) {
                resolve(response);
            }
        });
    }

    setUpMailData(mailList, widgetConfig, token, base64url, allSentimentalConfig) {
        return new Promise(async (resolve) => {
            const apiResponse = {
                sentimentalAPI: null,
                data: []
            };

            try {
                for (const mail of mailList) {
                    let dataSet = mail;
                    dataSet["date"] = "";
                    dataSet["from"] = "";
                    dataSet["subject"] = "";
                    dataSet["htmlBody"] = "";
                    dataSet["bodyContainer"] = "";

                    if (apiResponse?.sentimentalAPI) {
                        dataSet["sentimentalConfig"] = null;
                        const findSentimentalConfig =
                        allSentimentalConfig.find(
                                (s) => s.mailId === mail.id
                            );
                        if (findSentimentalConfig?.config) {
                            dataSet["sentimentalConfig"] =
                                JSON.parse(
                                    findSentimentalConfig.config
                                );
                        }
                    }

                    dataSet = await this.setMailDataSet(dataSet, widgetConfig, token, mail, base64url);
                    apiResponse.data.push(dataSet);
                }

                resolve(apiResponse);
            } catch (error) {
                resolve(apiResponse);
            }
        });
    }

    async setMailDataSet(dataSet, widgetConfig, token, mail, base64url) {
        return new Promise(async (resolve) => {
            try {
                const details = await this.getMaildetails(widgetConfig.email, token, mail.id);
                if (
                    details?.data?.payload?.headers
                        ?.length
                ) {
                    const findSubject =
                        details.data.payload.headers.find(
                            (h) =>
                                h.name === "Subject"
                        );
                    if (findSubject?.value) {
                        dataSet["subject"] =
                            findSubject.value;
                    }
                    const findFrom =
                        details.data.payload.headers.find(
                            (h) => h.name === "From"
                        );
                    if (findFrom?.value) {
                        dataSet["from"] =
                            findFrom.value;
                    }
                    const findDate =
                        details.data.payload.headers.find(
                            (h) => h.name === "Date"
                        );
                    if (findDate?.value) {
                        dataSet["date"] =
                            findDate.value;
                    }
                }
                if (
                    details?.data?.payload?.body
                        ?.data
                ) {
                    let htmlBody = base64url.decode(
                        details.data.payload.body
                            .data
                    );
                    dataSet["htmlBody"] = htmlBody;
                    dataSet["bodyContainer"] =
                        htmlBody;

                    const parseHtml =
                        /<body.*?>([\s\S]*)<\/body>/.exec(
                            htmlBody
                        );
                    if (parseHtml?.length === 2) {
                        dataSet["bodyContainer"] =
                            parseHtml[1].replace(
                                /<[^>]+>/g,
                                ""
                            );
                    }
                }

                resolve(dataSet);
            } catch (error) {
                resolve(dataSet);
            }
        })
    }
}
