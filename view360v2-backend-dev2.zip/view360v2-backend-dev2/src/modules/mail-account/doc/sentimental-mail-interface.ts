export interface SentimentalMailResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface InsertSentimentalMailRequest {
    mailId?: string;
    email?: string;
    config?: any;
    body?: any;
    subject?: any;
}
