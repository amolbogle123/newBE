export interface MailAccountListResponse {
    status: boolean;
    data?: any;
    message?: string;
    recordsTotal?: number;
    recordsFiltered?: number;
}

export interface MailAccountDetailsResponse {
    status: boolean;
    data?: any;
    message?: string;
}
