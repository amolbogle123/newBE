import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import { SentimentalMailMapper } from "../../../entities";
import Container from "typedi";
import { DataSource } from "typeorm";
import { Controller, Post, Body, Request, Route, Security, Tags } from "tsoa";
import {
    InsertSentimentalMailRequest,
    SentimentalMailResponse,
} from "../doc/sentimental-mail-interface";
import { SentimentalService } from "../services/sentimental.service";

@Route("")
@Tags("Sentimental Mail")
export class SentimentalController extends Controller {
    private sentimentalService: SentimentalService = new SentimentalService();

    @Security("bearerAuth")
    @Post("sentimental-mail")
    async sentimentalMail(
        @Request() request: any,
        @Body() requestBody: InsertSentimentalMailRequest
    ): Promise<SentimentalMailResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            const sentimentalData = await this.sentimentalService.getSentimentalConfig(requestBody);

            const SentimentalMailModel = new SentimentalMailMapper();
            SentimentalMailModel.clientId = request.userDetails.client_id;
            SentimentalMailModel.mailId = requestBody.mailId;
            SentimentalMailModel.email = requestBody.email;
            SentimentalMailModel.createdBy = request.userDetails.id;

            if (requestBody?.subject) {
                SentimentalMailModel.mailSubject = requestBody.subject;
            }
            if (requestBody?.body) {
                SentimentalMailModel.mailBody = requestBody.body;
            }
            if (sentimentalData?.config) {
                SentimentalMailModel.config = JSON.stringify(sentimentalData.config);

                if (typeof sentimentalData.config.compound !== 'undefined') {
                    SentimentalMailModel.sentinelValue = sentimentalData.config.compound
                }
            }

            const result = await Container.get(DataSource).manager.save(
                SentimentalMailModel
            );
            if (result?.id) {
                apiResponse.data = {
                    insertedId: result.id,
                    config: requestBody.config,
                };
                this.setStatus(201);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
