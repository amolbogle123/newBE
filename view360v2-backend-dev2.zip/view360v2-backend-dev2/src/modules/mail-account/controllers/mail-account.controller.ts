import base64url from "base64url";

import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import {
    SettingConfig,
    WidgetAccount,
    SentimentalMailMapper,
} from "../../../entities";
import Container from "typedi";
import { DataSource } from "typeorm";
import { Controller, Get, Path, Query, Request, Route, Security, Tags } from "tsoa";
import {
    MailAccountListResponse,
    MailAccountDetailsResponse,
} from "../doc/mail-account-interface";
import gmailApi from "../../../utils/gmailApi.util";
import { MailAccountService } from "../services/mail-account.service";

@Route("")
@Tags("Mail Account")
export class MailAccountController extends Controller {
    private mailAccountService: MailAccountService = new MailAccountService();

    @Security("bearerAuth")
    @Get("mail-account")
    async mailAccountList(
        @Request() request: any,
        @Query("pageToken") pageToken: string = "",
        @Query("pageSize") pageSize: number = 10
    ): Promise<MailAccountListResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: [],
                sentimentalAPI: null,
                prevPageToken: null,
                nextPageToken: null,
            };

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(SettingConfig),
                {
                    where: { type: "MAIL_ACCOUNT_KEY" },
                }
            );
            if (!results?.length) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            const config = results[0].config
                ? JSON.parse(results[0].config)
                : {};
            if (!config?.accountId) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            const widgetAccount = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .findOne({ where: { id: config.accountId } });
            if (!widgetAccount?.config) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            const widgetConfig = widgetAccount.config
                ? JSON.parse(widgetAccount.config)
                : {};
            if (!widgetConfig?.token?.access_token) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            let token = null;
            const tokenDetails: any = await gmailApi.getToken(
                widgetConfig
            );
            if (!tokenDetails?.token) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            token = tokenDetails.token;
            apiResponse.prevPageToken = pageToken || null;

            const mailList =
                await this.mailAccountService.getMailList(
                    widgetConfig?.email,
                    token,
                    {
                        maxResults: pageSize,
                        pageToken: pageToken,
                    }
                );
            if (!mailList?.data?.messages) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            this.setStatus(200);
            apiResponse.data = [];
            apiResponse.nextPageToken = mailList?.data?.nextPageToken || null;

            let allSentimentalConfig = [];
            if (config?.sentimentalAPI) {
                apiResponse.sentimentalAPI = config.sentimentalAPI;

                const mailIds = mailList.data.messages.map(
                    (m) => m.id
                );
                let whereCondition = `WA.clientId = :id AND WA.mailId IN ('${mailIds.join(
                    "', '"
                )}')`;
                const sentiResults = await Container.get(DataSource)
                    .getRepository(SentimentalMailMapper)
                    .createQueryBuilder("WA")
                    .where(whereCondition, {
                        id: request.userDetails.client_id,
                    })
                    .getMany();
                if (sentiResults?.length) {
                    allSentimentalConfig = sentiResults;
                }
            }

            const mailDataResult: any = await this.mailAccountService.setUpMailData(mailList.data.messages, widgetConfig, token, base64url, allSentimentalConfig);
            if (mailDataResult) {
                apiResponse.sentimentalAPI = mailDataResult.sentimentalAPI;
                apiResponse.data = mailDataResult.data;
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("mail-account/profile")
    async getMailAccountDetails(
        @Request() request: any
    ): Promise<MailAccountDetailsResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: null,
                error: null
            };

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(SettingConfig),
                {
                    where: { type: "MAIL_ACCOUNT_KEY" },
                }
            );
            if (!results?.length) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            const config = results[0].config
                ? JSON.parse(results[0].config)
                : {};
            if (!config?.accountId) {
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }

            const widgetAccount = await Container.get(DataSource)
                .getRepository(WidgetAccount)
                .findOne({ where: { id: config.accountId } });
            if (widgetAccount?.config) {
                const widgetConfig = JSON.parse(widgetAccount.config);
                if (widgetConfig?.token?.access_token) {
                    const mailResult =
                        await this.mailAccountService.getProfileDetails(
                            widgetConfig.email,
                            widgetConfig
                        );
                    if (mailResult?.error) {
                        apiResponse.error = mailResult.error;
                    } else if (mailResult?.data) {
                        apiResponse.data = mailResult.data;
                        this.setStatus(200);
                    } 
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("mail-account/mail-list/:connectorId")
    async getMailList(
        @Request() request: any,
        @Path() connectorId: string
    ): Promise<MailAccountDetailsResponse | unknown> {
        try {
            const apiResponse = {
                data: null,
                error: null
            };

            const widgetAccount = await Container.get(DataSource)
                        .getRepository(WidgetAccount)
                        .findOne({ where: { id: connectorId } });
            if (widgetAccount?.config) {
                const widgetConfig = widgetAccount.config
                    ? JSON.parse(widgetAccount.config)
                    : {};
                if (widgetConfig?.accessCode) {
                    const results = await gmailApi.getAllEmailByAdmin(
                        widgetConfig.accessCode
                    );
                    if (results) {
                        apiResponse.data = results;
                        this.setStatus(200);
                    }
                }
            }

            // const results = await gmailApi.getAllEmailByAdmin(
            //     '../../public/gmail-access/gmail-admin-test.json'
            // );
            // if (results) {
            //     apiResponse.data = results;
            //     this.setStatus(200);
            // }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
