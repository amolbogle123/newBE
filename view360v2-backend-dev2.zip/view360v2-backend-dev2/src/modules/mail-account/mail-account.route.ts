import { AppRoutes } from "../../app.routes";
import { MailAccountController } from "./controllers/mail-account.controller";

export class MailAccountRoutes extends AppRoutes {
    private mailAccountController: MailAccountController;

    constructor() {
        super();
        this.mailAccountController = new MailAccountController();
    }
}
