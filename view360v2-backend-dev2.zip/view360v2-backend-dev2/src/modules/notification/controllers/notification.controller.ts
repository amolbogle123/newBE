import { ILike } from "typeorm";
import { CommonHelper, ApiErrorResponse } from "../../../utils/helpers/common.helper";
import { Notification } from "../../../entities/notification";
import { dataSource } from "../../../core/data-source";
import { Get, Post, Request, Route, Security, Tags, Controller } from "tsoa";
@Route("notifications")
@Tags("Notifications")
export class NotificationController extends Controller{

    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }
    @Security("bearerAuth")
    @Get("/")
    async list(
        @Request() request: Request | any,
    ): Promise<any> {
        try {
            const apiResponse: any = { status: true, data: null };
            const take = request.query.length ? request.query.length : 6;

            const initialConditions = {
                clientId: request.userDetails.client_id,
            };
            if(request.query.viewMessage){
                initialConditions["viewMessage"] = request.query.viewMessage;
            }

            let notiResult: any = await dataSource
                .getRepository(Notification)
                .find({
                    where: [
                        { ...initialConditions, roleType: request.userDetails.role_id },
                        { ...initialConditions, receiverId: request.userDetails.id },
                    ],
                    take: take,
                    order: { createdOn: "DESC" },
                });
            if (notiResult) {
                apiResponse.data = notiResult;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Get("/count")
    async totalCount(
        @Request() request: Request | any,
    ): Promise<any> {
        try {
            const apiResponse: any = { status: true, data: 0 };

            const initialConditions = {
                clientId: request.userDetails.client_id,
                viewMessage: 0,
            };

            let notifyResult: any = await dataSource
                .getRepository(Notification)
                .find({
                    where: [
                        { ...initialConditions, roleType: request.userDetails.role_id },
                        { ...initialConditions, receiverId: request.userDetails.id },
                    ]
                });
            if (notifyResult?.length) {
                apiResponse.data = notifyResult.length;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Post("/")
    async notificationlist(
        @Request() request: Request | any,
    ): Promise<any> {
        try {
            const apiResponse: any = {
                status: true,
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };

            const client_Id = request.userDetails.client_id;
            let whereCondition: any = [];
            const take = request.body.length ? request.body.length : 10;
            const skip = request.body.start ? request.body.start : 0;
            if (
                request.body.search &&
                request.body.search.value &&
                request.body.search.value !== ""
            ) {
                const searchFields = ["message", "extraMessage"];
                searchFields.forEach((i) =>
                    whereCondition.push({
                        [i]: ILike(request.body.search.value),
                        clientId: client_Id,
                        roleType: request.userDetails.role_id,
                    }, {
                        [i]: ILike(request.body.search.value),
                        clientId: client_Id,
                        receiverId: request.userDetails.id
                    })
                );
            } else {
                whereCondition = [{
                    clientId: client_Id,
                    roleType: request.userDetails.role_id,
                },
                {
                    clientId: client_Id,
                    receiverId: request.userDetails.id
                }];
            }

            const dataSetRows: any = await dataSource
                .getRepository(Notification)
                .findAndCount({
                    where: whereCondition,
                    take: take,
                    skip: skip,
                    order: { createdOn: "DESC" },
                });
            if (dataSetRows[0]?.length > 0) {
                apiResponse.data = dataSetRows[0];
                apiResponse.recordsTotal = dataSetRows[1];
                apiResponse.recordsFiltered = dataSetRows[1];
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("/mark-as-read")
    async markAsRead(
        @Request() request: Request | any,
    ): Promise<any> {
        try {
            const apiResponse: any = { status: true, data: null };
            const client_Id = request.userDetails.client_id;
            const receiverId = request.userDetails.id;

            const updateData = {
                viewMessage: 1,
            };
            const whereCondition = {
                clientId: client_Id,
                receiverId: receiverId,
                viewMessage: 0,
            };
            await dataSource
                .getRepository(Notification)
                .update(whereCondition, updateData);
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
