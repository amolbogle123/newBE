import { AppRoutes } from "../../app.routes";

export class NotificationRoutes extends AppRoutes {
    constructor() {
        super();
    }
}
