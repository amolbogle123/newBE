import Container from "typedi";
import { DataSource,Between } from "typeorm";
import { Notification } from "../../../entities";
export class NotificationService {
    async addNotification(notification: Notification): Promise<any> {
        const notificationRepository = Container.get(DataSource).getRepository(Notification);
        return notificationRepository.save(notification);
    }
    async checkNotificationEntryForTriggerValueExists(userId: string, triggerValue: string): Promise<boolean> {
        const notificationRepository = Container.get(DataSource).getRepository(Notification);
        const notificationCount = await notificationRepository.count({
            where: {
                receiverId: userId,
                extraData: triggerValue, 
                // ... other filter conditions ...
            },
        });
    
        return notificationCount > 0;
    }
    async checkNotificationEntryForTodayExists(userId: string, notificationType: string): Promise<boolean> {
        const notificationRepository = Container.get(DataSource).getRepository(Notification);
    
        const todayStart = new Date();
        todayStart.setHours(0, 0, 0, 0); // Set time to start of day
    
        const todayEnd = new Date();
        todayEnd.setHours(23, 59, 59, 999); // Set time to end of day
    
        const notificationCount = await notificationRepository.count({
            where: {
                receiverId: userId,
                createdOn: Between(todayStart, todayEnd),
                type: notificationType, 
                // ... other filter conditions ...
            },
        });
    
        return notificationCount > 0; // Return true if at least one notification exists, otherwise false
    }
    
}