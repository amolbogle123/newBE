// pdfWorker.ts

import { parentPort, workerData } from 'worker_threads';
import fs from 'fs';
import pdf from 'pdf-parse';

async function removeCommonWords(text: string, commonWords: string[]) {
  const words = text.split(" ");

  // Filter out common words
  const filteredWords = words.filter((word) => !commonWords.includes(word.toLowerCase()));

  // Join the filtered words back into a string
  return filteredWords.join(" ");
}

async function readPDF(filePath: string) {
     const dataBuffer = fs.readFileSync(filePath);
     return pdf(dataBuffer);
}

parentPort?.on('message', async (message: any) => {
  if (message === 'processPDF') {
    const { filePath, commonWords } = workerData;
    const pdfData = await readPDF(filePath);
    const textData = pdfData.text.split('/^Page \d+$/');
    const processedTextData: string[] = [];

    for (let i = 0; i < textData.length; i++) {
      const sanitizedText = await removeCommonWords(textData[i], commonWords);
      processedTextData.push(sanitizedText);
    }

    parentPort?.postMessage(processedTextData);
  }
});
