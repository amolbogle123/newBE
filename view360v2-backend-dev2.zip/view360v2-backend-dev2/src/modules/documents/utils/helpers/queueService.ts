// queueService.js
import Queue from 'bull';
import fs from 'fs';
import pdf from "pdf-parse";
import Container from "typedi";
import { DataSource } from "typeorm";
import { DMSFiles, DMSIndexedFiles } from "../../../../entities";


const pdfQueue = new Queue('pdfQueue');

// Define the PDF processing worker function
pdfQueue.process(async (job) => {
  const { filePath, commonWords } = job.data;
  const pdfData = await readPDF(filePath);
  const textData = pdfData.text.split('\n');
  const processedTextData = [];

  /**
   * for (let i = 0; i < textData.length; i++) {
    const sanitizedText = await removeCommonWords(textData[i], commonWords);
    processedTextData.push(sanitizedText);
  }
   */

  for (let text of textData) {
    const sanitizedText = await removeCommonWords(text, commonWords);
    processedTextData.push(sanitizedText);
  }

  // Save processed data to DMSIndexedFiles
  // const indexedFiles = processedTextData.map((data, index) => ({
  //           const indexedFile = new DMSIndexedFiles(),
  //           indexedFile.clientId = file.clientId,
  //           indexedFile.fileName = file.fileName,
  //           indexedFile.page = `${i + 1}`,
  //           indexedFile.data = sanitizedText,
  //           indexedFile.fileType = "PDF",
  //           indexedFile.actionDate = new Date(),
  //           indexedFile.createdOn = new Date(),
  //           indexedFile.updatedOn = new Date()
  // }));

  // await Promise.all(indexedFiles.map((indexedFile) => saveIndexedFile(indexedFile)));

  // Update DMSFiles isIndexed to 1
  // await updateDMSFile(file);

  return processedTextData;
});

async function saveIndexedFile(indexedFile: DMSIndexedFiles){
  console.log("saving")
  await Container.get(DataSource).manager.save(indexedFile);
}

async function updateDMSFile(file: DMSFiles){
  await Container.get(DataSource).manager.save(file);
}

async function removeCommonWords(text: string, commonWords: string[]) {
  // Split the text into words
  const words = text.split(" ");

  // Filter out common words
  const filteredWords = words.filter((word) => !commonWords.includes(word.toLowerCase()));

  // Join the filtered words back into a string
  return filteredWords.join(" ");
}
async function readPDF(filePath: string){
  const dataBuffer = fs.readFileSync(filePath);
  return pdf(dataBuffer);
}
export { pdfQueue };
