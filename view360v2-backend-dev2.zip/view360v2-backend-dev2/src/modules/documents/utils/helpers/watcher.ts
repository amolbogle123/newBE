import chokidar from 'chokidar';
import { DMSFiles, DMSFolders } from "../../../../entities";
import { DataSource } from "typeorm";
import Container from "typedi";
import fs from 'fs';
import * as fpath from 'path';
export function watchFolder(folderPath: string) {
  console.log("watchFolder ="+folderPath);
    const watcher = chokidar.watch(folderPath, {
        ignored: /(^|[/\\])\../, // Ignore dotfiles
        persistent: true,
    });
    
    // Initialize a set to keep track of added files and folders
    const changeSet = new Set<{ action: 'add' | 'delete'; type: 'file' | 'folder'; path: string }>();

    
    watcher
  .on('add', (filePath) => {
    // Handle newly added files
    changeSet.add({ action: 'add', type: 'file', path: filePath });
  })
  .on('addDir', (folderPathUrl) => {
    // Handle newly added folders
    changeSet.add({ action: 'add', type: 'folder', path: folderPathUrl });
  })
  .on('unlink', (filePath) => {
    // Handle deleted files
    changeSet.add({ action: 'delete', type: 'file', path: filePath });
  })
  .on('unlinkDir', (folderPathUrl) => {
    // Handle deleted folders
    changeSet.add({ action: 'delete', type: 'folder', path: folderPathUrl });
  })
  .on('ready', () => {
    // Called when the initial scan is completed
    console.log('Initial scan complete.');
  });
    
    // Function to save changes to the database
    function saveChangesToDatabase() {
        // Your logic to save the changes to your database using the `addedSet`
        changeSet.forEach(async (change) => {
            const { action, type, path } = change;
            console.log(`Action: ${action}, Type: ${type}, Path: ${path}`);
            // Implement your database operations here
            if (action === 'add') {
            if (type === 'file') {
                const fileName = fpath.parse(path).base;
                const fileExt = fpath.parse(path).ext;
                if(fileExt == '.pdf' || fileExt == '.mp3' || fileExt == '.mp4' || fileExt=='.wav'){
                const fileSize = fs.statSync(path).size;
                console.log(`Added File: Name=${fileName}, Size=${fileSize} bytes`);
                // Implement your database operations for added files here
                const dmsfiles = new DMSFiles();
                dmsfiles.fileName = fileName;
                dmsfiles.filePath = fpath.dirname(path);
                dmsfiles.fileSize = String(fileSize);
    
                // Check if a file with the same name already exists
                const existingFile = await Container.get(DataSource).manager.findOne(DMSFiles, {
                where: { fileName: dmsfiles.fileName },
                });
    
                if (existingFile) {
                console.log(`File ${dmsfiles.fileName} already exists. Skipping.`);
                } else {
                const result = await Container.get(DataSource).manager.save(dmsfiles);
                console.log(result);
                }
              }
              } else if (type === 'folder') {
                // Extract the folder name and concatenate with parent folders using underscores
                // const folderName = getFolderName(path);
                const folderName = path;

                console.log(`Added Folder: Name=${folderName}`);
                // Implement your database operations for added folders here
                const dmsfolders = new DMSFolders();
                dmsfolders.folderName = folderName;
                const existingFolder = await Container.get(DataSource).manager.findOne(DMSFolders, {
                where: { folderName: dmsfolders.folderName },
                });
            
                if (existingFolder) {
                console.log(`Folder ${dmsfolders.folderName} already exists. Skipping.`);
                } else {
                const result = await Container.get(DataSource).manager.save(dmsfolders);
                console.log(result);
                }
              }
            } else if (action === 'delete') {
                if(type==='file'){
                    const fileName = fpath.parse(path).base;
                    const fileDeleteResult = await Container.get(DataSource).manager.delete(DMSFiles,{filePath:fpath.dirname(path),fileName: fileName});
                    console.log("File Delete ="+fileDeleteResult);
                }
                if(type === 'folder'){
                    const folderName = getFolderName(path);
                    const result = await Container.get(DataSource).manager.delete(DMSFolders,{folderName:folderName});
                    console.log("Folder Delete ="+result);
                }
            }

          });
    
        // Clear the set after saving changes
        changeSet.clear();
    }
    
    // Periodically save changes to the database (adjust the interval as needed)
    setInterval(saveChangesToDatabase, 5000); // Adjust the interval (in milliseconds) as needed


    function getFolderName(path: string) {
        return path.replace(folderPath, '').split('/').filter(Boolean).join('_');
    }
}

