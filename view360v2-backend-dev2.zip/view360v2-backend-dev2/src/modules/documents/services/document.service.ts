import { DeleteResult, UpdateResult, DataSource } from "typeorm";
import { CustomForms, CustomFormsGroup } from "../../../entities";
import dbService from "../../../services/db.service";
import Container from 'typedi';
export class DocumentService {

    async isCustomFormGroupExist(condition: any): Promise<boolean> {
        return await dbService._countQueryService(Container.get(DataSource).getRepository(CustomFormsGroup), condition) > 0;
    }

    async getFormGroup(condition: any, fields: any[] = []): Promise<CustomFormsGroup | null> {
        return dbService._findOneQueryService(Container.get(DataSource).getRepository(CustomFormsGroup), { where: condition, select: fields });
    }

    async getFormGroups(condition: any, fields: any[] = []): Promise<CustomFormsGroup[]> {
        return dbService._findQueryService(Container.get(DataSource).getRepository(CustomFormsGroup), { where: condition, select: fields });
    }

    async saveFormGroup(payload: any): Promise<CustomFormsGroup | null> {
        return dbService._createQueryService(Container.get(DataSource).getRepository(CustomFormsGroup), payload);
    }

    async updateFormGroup(condition: any, payload: any): Promise<UpdateResult> {
        return dbService._updateQueryService(Container.get(DataSource).getRepository(CustomFormsGroup), { paramsObj: { ...condition }, ...payload });
    }

    async deleteFormGroup(condition: any): Promise<DeleteResult> {
        return dbService._deleteQueryService(Container.get(DataSource).getRepository(CustomFormsGroup), condition);
    }

    async getCustomForms(condition: any, fields: any[] = []): Promise<CustomForms[]> {
        return dbService._findQueryService(Container.get(DataSource).getRepository(CustomForms), { where: condition, select: fields });
    }

    async deleteCustomForms(condition: any): Promise<DeleteResult> {
        return dbService._deleteQueryService(Container.get(DataSource).getRepository(CustomForms), condition);
    }

    async getFormGroupWithRelations(condition: any, fields: any[] = [], relations: any = []): Promise<CustomFormsGroup[]> {
        return dbService._findQueryService(Container.get(DataSource).getRepository(CustomFormsGroup), {where: condition, select: fields, relations, order: {createdOn: 'DESC'}});
    }
}
