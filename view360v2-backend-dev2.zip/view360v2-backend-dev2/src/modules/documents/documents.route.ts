import { AppRoutes } from "../../app.routes";
import { DocumentController } from "./controllers/document.controller";

export class DocumentsRoutes extends AppRoutes {
    private documentController: DocumentController;

    constructor() {
        super();
        this.documentController = new DocumentController();

        this.initRoutes();
    }

    initRoutes() {
        /*
        // document controllers apis
         * this.router.post('/form-builder/add-document', (req, res, next) => this.documentController.insertDocument(req, res, next).catch(next));
         * this.router.post('/form-builder/update-document', (req, res, next) => this.documentController.updateDocument(req, res, next).catch(next));
         * this.router.post('/form-builder/delete-document', (req, res, next) => this.documentController.deleteDocument(req, res, next).catch(next));
         * this.router.post('/form-builder/update-document-user', (req, res, next) => this.documentController.updateDocumentUser(req, res, next).catch(next));
         * this.router.get('/form-builder/act-deact-form-folder/:id/:action', (req, res, next) => this.documentController.setFolderActivityStatus(req, res, next).catch(next));
         * this.router.get('/form-builder/document-details/:id', (req, res, next) => this.documentController.documentDetails(req, res, next).catch(next));
         * this.router.get('/form-builder/document-list', (req, res, next) => this.documentController.documentList(req, res, next).catch(next));
         * this.router.get('/form-builder/all-custom-forms', (req, res, next) => this.documentController.getDocumentWithFormList(req, res, next).catch(next));
         */
    }
}
