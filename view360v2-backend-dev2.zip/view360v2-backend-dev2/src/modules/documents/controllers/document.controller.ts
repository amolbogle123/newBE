import { DocumentService } from "../services/document.service";
import * as txt from "../utils/constants/api.constant";
import lodash from "lodash";
import { ILike, In, Not } from "typeorm";
import { CustomFormsGroup, CustomForms } from "../../../entities";
import {
    CommonHelper,
    ApiErrorResponse,
} from "../../../utils/helpers/common.helper";
import { FormBuilderService } from "../../form-builder/services/form-builder.service";
import {
    Body,
    Controller,
    Get,
    Post,
    Query,
    Request,
    Route,
    Security,
    Tags,
    Path,
    Delete,
    Patch,
    Middlewares,
} from "tsoa";
import {
    DeleteDocument,
    DocumentListResponse,
    InsertDocumentRequest,
    InsertDocumentResponse,
    UpdateDocumentRequest,
    UpdateDocumentResponse,
} from "../doc/document-interface";
import { cacheResponseData } from "../../../utils/redis.middleware";
import { commonMiddleware } from "../../../middlewares/common.middleware";

@Route("")
@Tags("Documents")
export class DocumentController extends Controller {
    // Services
    private documentService: DocumentService = new DocumentService();
    private formBuilderService: FormBuilderService = new FormBuilderService();

    @Security("bearerAuth")
    @Post("documents")
    async insertDocument(
        @Body() requestBody: InsertDocumentRequest,
        @Request() request: any
    ): Promise<InsertDocumentResponse | unknown> {
        const clientId = request.userDetails.client_id;
        try {
            const criteria: any = [
                { clientId: clientId, name: requestBody.projectName },
                { clientId: clientId, shortName: requestBody.projectshortName },
            ];
            const docResult = await this.documentService.getFormGroups(
                criteria,
                ["name", "shortName"]
            );
            if (!lodash.isEmpty(docResult)) {
                let errors: any = {};
                const findName = docResult.find(
                    (d) => d.name === requestBody.projectName
                );
                if (findName) {
                    errors.projectName = txt.FOLDER_ALREADY_EXIST;
                }
                const findShortName = docResult.find(
                    (d) => d.shortName === requestBody.projectshortName
                );
                if (findShortName) {
                    errors.projectshortName = txt.FOLDER_SHORT_ALREADY_EXIST;
                }
                this.setStatus(500);
                return CommonHelper.apiSwaggerErrorResponse({
                    message: txt.FOLDER_ALREADY_EXIST,
                    error: errors,
                });
            }
            const insertData = {
                clientId: request.userDetails.client_id,
                name: requestBody.projectName,
                shortName: requestBody.projectshortName,
                projectManager: requestBody.projectManager || "",
                description: requestBody.projectDiscription,
                mappedUser: JSON.stringify(requestBody.mapped_user),
                createdBy: request.userDetails.id,
                status: 2,
                username: request.userDetails.username,
            };

            const docSavedResponse = await this.documentService.saveFormGroup(
                insertData
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: docSavedResponse,
                message: txt.DOC_SAVED_SUCCESS,
            });
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
 
    @Security("bearerAuth")
    @Patch("documents/:id")
    async updateDocument(
        @Path() id: string,
        @Body() requestBody: UpdateDocumentRequest,
        @Request() request: any
    ): Promise<UpdateDocumentResponse | unknown> {
        this.setStatus(500);
        try {
            let updateData: any = {
                mappedUser: "[]",
            };
            const criteria: any = [];

            if (requestBody.projectName) {
                updateData.name = requestBody.projectName;
                criteria.push({
                    id: Not(id),
                    clientId: request.userDetails.client_id,
                    name: requestBody.projectName,
                });
            }
            if (requestBody.projectshortName) {
                updateData.shortName = requestBody.projectshortName;
                criteria.push({
                    id: Not(id),
                    clientId: request.userDetails.client_id,
                    shortName: requestBody.projectshortName,
                });
            }
            if (criteria?.length) {
                const docResult = await this.documentService.getFormGroups(
                    criteria,
                    ["name", "shortName"]
                );
                if (!lodash.isEmpty(docResult)) {
                    let errors: any = {};
                    const findName = docResult.find(
                        (d) => d.name === requestBody.projectName
                    );
                    if (findName) {
                        errors.projectName = txt.FOLDER_ALREADY_EXIST;
                    }
                    const findShortName = docResult.find(
                        (d) => d.shortName === requestBody.projectshortName
                    );
                    if (findShortName) {
                        errors.projectshortName =
                            txt.FOLDER_SHORT_ALREADY_EXIST;
                    }
                    return CommonHelper.apiSwaggerErrorResponse({
                        message: txt.FOLDER_ALREADY_EXIST,
                        error: errors,
                    });
                }
            }

            this.setStatus(204);
            const updateResult = await this.updateFormGroup(id, requestBody, updateData);
            
            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: updateResult,
                message: txt.DOC_UPDATED_SUCCESS,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("documents")
    async deleteDocument(
        @Body() requestBody: DeleteDocument,
        @Request() request: any
    ): Promise<string | unknown> {
        try {
            const listOfIds: any[] = requestBody.id;
            const clientId = request.userDetails.client_id;
            const formValues = [];

            if (listOfIds.length || !lodash.isEmpty(listOfIds)) {
                await this.formBuilderService.getCustomForms(
                    { clientId: clientId, docId: In(listOfIds) },
                    ["id", "referenceId"]
                );

                const customFormCriteria: any = {
                    docId: In(listOfIds),
                    clientId: request.userDetails.client_id,
                };

                await this.documentService.deleteFormGroup({
                    id: In(listOfIds),
                });
                await this.documentService.deleteCustomForms(
                    customFormCriteria
                );
            } else {
                this.setStatus(204);
            }
            return CommonHelper.apiSwaggerSuccessResponse({});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("documents")
    @Middlewares(commonMiddleware)
    async documentList(
        @Request() request: any,
        @Query() status: 1 | 2,
        @Query() rbav?: string,
        @Query() searchKey?: string
    ): Promise<DocumentListResponse[] | unknown> {
        try {
            const apiResponse: any = { data: [] };

            const whereCondition1: any = {
                clientId: request.userDetails.client_id,
            };
            let whereCondition2: any = {};
            const criteria: any = [];

            whereCondition1.status = status;

            if (!lodash.isEmpty(searchKey) && searchKey !== "") {
                whereCondition1.name = ILike("%" + searchKey + "%");
                whereCondition2.shortName = ILike("%" + searchKey + "%");

                criteria.push(whereCondition2);
            }
            criteria.push(whereCondition1);

            const docResult: CustomFormsGroup[] =
                await this.documentService.getFormGroupWithRelations(criteria);

            if (docResult.length || !lodash.isEmpty(docResult)) {
                let getFormDetails: any = await this.documentListUserPermission(request.userDetails, docResult);

                for (let i in getFormDetails) {
                    const customFormResult: CustomForms[] =
                        await this.documentService.getCustomForms(
                            {
                                docId: getFormDetails[i].id,
                                clientId: request.userDetails.client_id,
                            },
                            ["id", "formName"]
                        );
                    getFormDetails[i].totalForm = 0;
                    getFormDetails[i].allForms = [];

                    if (customFormResult?.length) {
                        getFormDetails[i].totalForm = customFormResult.length;
                        getFormDetails[i].allForms = customFormResult;
                    }
                }
                apiResponse.data = getFormDetails;
            }
            await cacheResponseData(request.originalUrl, { ...apiResponse });
            return CommonHelper.apiSwaggerSuccessResponse({ ...apiResponse });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("documents/:id")
    async documentDetails(
        @Path() id: string,
        @Request() request: any
    ): Promise<DocumentListResponse | unknown> {
        try {
            const customFormGroups: CustomFormsGroup =
                await this.documentService.getFormGroup({
                    clientId: request.userDetails.client_id,
                    id: id,
                });
            if (!customFormGroups?.id) {
                this.setStatus(204);
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: customFormGroups,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    updateFormGroup(id, requestBody, updateData) {
        return new Promise(async(resolve) => {
            const updateList = [
                {col: "projectManager", value: "projectManager"},
                {col: "projectDiscription", value: "description"},
                {col: "status", value: "status"},
            ];
            for (let u of updateList) {
                if (requestBody[u.col]) {
                    updateData[u.value] = requestBody[u.col];
                }
            }
            if (requestBody.mapped_user) {
                updateData.mappedUser = JSON.stringify(requestBody.mapped_user);
            }

            const updateResult = await this.documentService.updateFormGroup(
                { id: id },
                updateData
            );

            resolve(updateResult);
        });
    }

    documentListUserPermission(userDetails, docResult) {
        return new Promise(async(resolve) => {
            let getFormDetails = [];

            for (let doc of docResult) {
                let userPermission = [];
                let dataSet: any = doc;

                dataSet.mappedUser = dataSet.mappedUser
                    ? JSON.parse(dataSet.mappedUser)
                    : [];
                userPermission = dataSet.mappedUser;

                if (userDetails.is_superadmin === 1) {
                    dataSet.permission = {
                        viewDocument: true,
                        editDocument: true,
                        manageUserDocument: true,
                        deleteDocument: true,
                        createForms: true,
                        formList: true,
                    };
                } else {
                    const findPermission = userPermission.findIndex(
                        (u: any) => u.userID === userDetails.id
                    );
                    if (findPermission > -1) {
                        const allPermission = ["viewDocument", "editDocument", "manageUserDocument", "deleteDocument", "createForms", "formList"];

                        dataSet.permission = {};
                        allPermission.forEach((v, k) => {
                            dataSet.permission[v] = userPermission[findPermission]["permission"][k] === "1";
                        });
                    } else if (userPermission?.length === 0) {
                        dataSet.permission = null;
                    }
                }

                if (
                    !dataSet.permission ||
                    dataSet.permission.viewDocument
                ) {
                    getFormDetails.push(dataSet);
                }
            }

            resolve(getFormDetails);
        });
    }
}
