import fs from 'fs';
import * as path from 'path';
import pdf from "pdf-parse";
import {
  Body,
  Controller,
  Get,
  Post,
  Query,
  Request,
  Route,
  Security,
  Tags
} from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { Worker } from 'worker_threads';
import { DMSFiles, DMSFilesLogs, DMSFolders, DMSIndexedFiles, WidgetAccount } from "../../../entities";
import { watchFolder } from "../../../modules/documents/utils/helpers/watcher";
import {
  ApiErrorResponse,
  CommonHelper,
} from "../../../utils/helpers/common.helper";
process.env.UV_THREADPOOL_SIZE = '64';

@Route("dms")
@Tags("crawl index documents")
export class DMSController extends Controller {

  
  @Post("crawl-folders")
  async crawlFolders(
    @Request() request: any,
    @Body() requestBody:any
  ): Promise<any[] | unknown> {
    try {

      const connectorId = requestBody.id;
      const apiResponse: any = { data: [] };
      
      const connectorData  = await Container.get(DataSource).manager.find(WidgetAccount, {
        where: { widgetType: 'CRAWLER_INDEXER',id:connectorId }
      });
      for (const widgetData of connectorData) {

        console.log("widgetData",widgetData);

        const config = JSON.parse(widgetData.config);
        for (const item of config) {
           const DMS_PATH = item.folderPath;
           watchFolder(DMS_PATH);

        }
      }

      return CommonHelper.apiSwaggerSuccessResponse({ ...apiResponse });
    } catch (error) {
      const apiErrorResponse: ApiErrorResponse = {
        error: {
          error_description: (error as Error).message,
        },
      };
      this.setStatus(500);
      return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
    }
  }



@Get('get-indexing-status')
async getIndexingStatus(){
  try {
    
    const totalPendingFiles  = await Container.get(DataSource).manager.find(DMSFiles, {
      where: { isIndexed: 0 },
    });

     const totalPdfFiles  = await Container.get(DataSource).manager.find(DMSFiles, {
      
    });


    return CommonHelper.apiSwaggerSuccessResponse({data:{'pending':totalPendingFiles.length,'total':totalPdfFiles.length} });
  } catch (error) {
    const apiErrorResponse: ApiErrorResponse = {
      error: {
        error_description: error.message,
      },
    };
    // Handle the response or error status as needed
    this.setStatus(500);
    return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
  }
}


// optimized join
// Main Thread
@Get('index-pdf-files')
async indexPDFFiles(@Query() folderPath: string): Promise<string> {
  try {
    const batchSize = 100;
    const totalPdfFiles = await Container.get(DataSource).manager.find(DMSFiles, {
      where: { isIndexed: 0 },
    });

    console.log(totalPdfFiles.length);

    while (totalPdfFiles.length > 0) {
      const pdfFiles = totalPdfFiles.splice(0, batchSize);

      const promises = pdfFiles.map(async (file) => {
        const filePath = path.join(file.filePath , file.fileName);
        
        const commonWords = ['is', 'am', 'are'];

        const workerData = {
          filePath,
          commonWords,
        };
        // /usr/share/public/worker/workerThread.js
        // /usr/share/nginx/html/backend/public/worker/workerThread.js

        const workerFilePath = path.join(__dirname, '../public/worker/workerThread.js');   // server 

        return new Promise<void>((resolve) => {
          const worker = new Worker(workerFilePath, { workerData });

          worker.on('message', async (processedTextData: string[]) => {
            for (let i = 0; i < processedTextData.length; i++) {
              const indexedFile = new DMSIndexedFiles();
              indexedFile.clientId = file.clientId;
              indexedFile.fileName = file.fileName;
              indexedFile.page = `${i + 1}`;
              indexedFile.data = processedTextData[i];
              indexedFile.fileType = 'PDF';
              indexedFile.actionDate = new Date();
              indexedFile.createdOn = new Date();
              indexedFile.updatedOn = new Date();

              await this.saveIndexedFile(indexedFile);
            }

            file.isIndexed = 1;
            await this.updateDMSFile(file);

            worker.terminate();
            resolve();
          });

          worker.on('error', (error) => {
            console.error(error);
            worker.terminate();
            resolve();
          });

          worker.postMessage('processPDF');
        });
      });

      await Promise.all(promises);
    }

    return CommonHelper.apiSwaggerSuccessResponse({ message: 'PDF files indexed successfully.' });
  } catch (error) {
    // Handle errors

    const apiErrorResponse: ApiErrorResponse = {
      error: {
        error_description: error.message,
      },
    };
          this.setStatus(500);
      return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
  }
}

@Get('check-folder-existence')
async checkFolderExistence(@Query() folderPath: string): Promise<string> {
  try {
    const absolutePath = path.resolve(folderPath);
    const isFolderExist = fs.existsSync(absolutePath);
    if (isFolderExist) {
      try{
      // Check if the user has read and execute permissions
      fs.accessSync(absolutePath, fs.constants.R_OK | fs.constants.X_OK);
      return CommonHelper.apiSwaggerSuccessResponse({ message: 'Folder exists and has required permissions.' });
      }catch(err){
        return CommonHelper.apiSwaggerSuccessResponse({ message: 'Folder exists but does not have required permissions.' },false);
      }
      
      
    } else {
      return CommonHelper.apiSwaggerSuccessResponse({message: 'Folder does not exist.' },false);
    }
  } catch (error) {
    // Handle errors

    const apiErrorResponse: ApiErrorResponse = {
      error: {
        error_description: error.message,
      },
    };
          this.setStatus(500);
      return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
  }
}



  async saveIndexedFile(indexedFile: DMSIndexedFiles):Promise<void>{
    console.log("saving")
    await Container.get(DataSource).manager.save(indexedFile);
  }

  async updateDMSFile(file: DMSFiles): Promise<void> {
    await Container.get(DataSource).manager.save(file);
  }

/*
   function to retrieve isIndexed 0 files 
*/

  async getUnindexedPDFFiles(batchSize: number): Promise<DMSFiles[]> {
    return Container.get(DataSource).manager.find(DMSFiles, {
      where: { isIndexed: 0 },
      take: 1,
    });
  }



  private async removeCommonWords(text: string, commonWords: string[]): Promise<string> {
    // Split the text into words
    const words = text.split(" ");

    // Filter out common words
    const filteredWords = words.filter((word) => !commonWords.includes(word.toLowerCase()));

    // Join the filtered words back into a string
    return filteredWords.join(" ");
  }
  private async readPDF(filePath: string): Promise<any> {
    const dataBuffer = fs.readFileSync(filePath);
    return pdf(dataBuffer);
  }




  @Security("bearerAuth")
  @Get("dms-files-logs")
  async getDMSFilesLogs(
    @Request() request: any,
    @Query() fileName: string,
    @Query() filePath: string,
    ): Promise<any> {
    try {
      
      const dmsFilesLogs = await Container.get(DataSource).manager.find(DMSFilesLogs, {
        where:{
          CLIENT_ID:request.userDetails.client_id,
          FILE_NAME: fileName,
          FILE_PATH: filePath,          
        },
        order: {
          ACTION_DATE: "DESC",
          },
          });
      return CommonHelper.apiSwaggerSuccessResponse({ data: dmsFilesLogs });
    } catch (error) {
      const apiErrorResponse: ApiErrorResponse = {
        error: {
          error_description: (error as Error).message,
        },
      };
      this.setStatus(500);
      return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
    }
  }

  @Get("dms-folders")
  async getDMSFolders(
    @Request() request: any,
  ): Promise<any[] | unknown> {
    try {
      const apiResponse: any = { data: [] };
      const dmsFolders = await Container.get(DataSource).manager.find(DMSFolders, {
//        where: { clientId: request.userDetails.client_id },
        select: ["folderName"],
      });
      apiResponse.data = dmsFolders;
      return CommonHelper.apiSwaggerSuccessResponse({ ...apiResponse });
    } catch (error) {
      const apiErrorResponse: ApiErrorResponse = {
        error: {
          error_description: (error as Error).message,
        },
      };
      this.setStatus(500);
      return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
    }
  }




}
