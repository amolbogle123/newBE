import {NotificationTemplate} from "../../../entities";
import {StatusType, UserType} from "../../../models/enums";
import {CommonHelper,SetResponse} from "../../../utils/helpers/common.helper";
import Container from 'typedi';
import { DataSource } from "typeorm";


export class NavigationTemplateService {

    async isTemplateExist(condition: any): Promise<boolean> {
        return await Container.get(DataSource).getRepository(NotificationTemplate).count({where: condition}) > 0;
    }

    async createTemplate(payload: any): Promise<void> {
        await Container.get(DataSource).getRepository(NotificationTemplate).save(payload)
    }

    async updatedTemplate(condition: any, fields: any): Promise<void> {
        await Container.get(DataSource).getRepository(NotificationTemplate).update(condition, fields);
    }

    async listAllTemplates(condition: any, userType: string, fields: any[] = []): Promise<NotificationTemplate[]> {

        if (UserType.OWNER === userType) {
            condition.createdBy = userType;
        }
        return Container.get(DataSource).getRepository(NotificationTemplate).find({where: condition, select: fields});
    }

    async getSingleTemplate(condition: any, fields: any[] = []): Promise<NotificationTemplate | null> {
        return Container.get(DataSource).getRepository(NotificationTemplate).findOne({where: condition, select: fields});
    }

    async deleteTemplate(condition: any): Promise<SetResponse> {
        if (!await this.isTemplateExist(condition)) {
            return CommonHelper.setResponse(StatusType.ERROR)
        }
        await Container.get(DataSource).getRepository(NotificationTemplate).delete(condition);
        return CommonHelper.setResponse(StatusType.SUCCESS)
    }
}
