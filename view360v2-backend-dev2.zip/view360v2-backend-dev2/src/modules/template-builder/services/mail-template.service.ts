import {MailTemplate} from "../../../entities";
import {StatusType} from "../../../models/enums";
import {CommonHelper,SetResponse} from "../../../utils/helpers/common.helper";
import Container from 'typedi';
import { DataSource } from "typeorm";

export class MailTemplateService {


    async isTemplateExist(condition: any): Promise<boolean> {
        return await Container.get(DataSource).getRepository(MailTemplate).count({where: condition}) > 0;
    }

    async createTemplate(payload: any): Promise<void> {
        await Container.get(DataSource).getRepository(MailTemplate).save(payload)
    }

    async updatedTemplate(condition: any, fields: any): Promise<void> {
        await Container.get(DataSource).getRepository(MailTemplate).update(condition, fields);
    }

    // async listAllTemplates(condition: any, userType: string, fields: any[] = []): Promise<MailTemplate[]> {
    //
    //     if (UserType.OWNER === userType) {
    //         condition.createdBy = userType;
    //     }
    //     return await Container.get(DataSource).getRepository(MailTemplate).find({where: condition, select: fields});
    // }
    //
    // async getSingleTemplate(condition: any, fields: any[] = []): Promise<MailTemplate | null> {
    //     return await Container.get(DataSource).getRepository(MailTemplate).findOne({where: condition, select: fields});
    // }

    async deleteTemplate(condition: any): Promise<SetResponse> {
        if (!await this.isTemplateExist(condition)) {
            return CommonHelper.setResponse(StatusType.ERROR)
        }
        await Container.get(DataSource).getRepository(MailTemplate).delete(condition);
        return CommonHelper.setResponse(StatusType.SUCCESS)
    }
}
