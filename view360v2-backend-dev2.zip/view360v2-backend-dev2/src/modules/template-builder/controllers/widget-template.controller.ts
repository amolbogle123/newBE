import { WidgetTemplate } from "entities/widget-template";
import lodash from "lodash";
import { Body, Controller, Delete, Get, Hidden, Path, Post, Put, Query, Request, Route, Security, Tags } from "tsoa";
import Container from 'typedi';
import { DataSource } from "typeorm";
import { StatusType, UserType } from "../../../models/enums";
import dbService from "../../../services/db.service";
import { ApiErrorResponse, CommonHelper, SetResponse } from "../../../utils/helpers/common.helper";
import { DeleteTemplateRequest } from '../doc/notificationTemplate-interface';
import * as txt from "../utils/constants/api.constant";

@Route('widget-template')
@Tags('')
export class WidgetTemplateController extends Controller {
    // Services

    /**
     * Create Widget Template
     * @param request Request  from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Post('widget')
    async createTemplate(
        @Body() requestBody: any,
        @Request() request: any,
    ): Promise<any> {
        try {
            let payload: any = requestBody;

            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;
            payload.updatedBy = request.userDetails.id;
            payload = lodash.omit(payload, ["id"]);

            const widgetTemplateResponse = await dbService._createQueryService(
                Container.get(DataSource).getRepository(WidgetTemplate),
                {
                    ...payload,
                }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: { lastInsertId: widgetTemplateResponse.id || '' }, message: txt.WIDGET_TEMPLATE_SAVED, });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update Notification Template
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Put('widget/:id')
    async updateTemplate(
        @Body() requestBody: any,
        @Request() request: any,
        @Path() id: string,
    ): Promise<any> {
        try {
            let payload: any = {};

            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;

            payload.name = requestBody.name;
            payload.message = requestBody.message;

            const updatedMailTemplate = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(WidgetTemplate),
                {
                    id,
                    ...payload,
                }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: { updatedRows: updatedMailTemplate.affected || 0 }, message: txt.NOTIFICATION_TEMPLATE_UPDATED, });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * List all Notification Templates
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Get('widget')
    async listTemplate(
        @Request() request: any,
        @Query() rbav?: string,
    ): Promise<any> {
        try {
            const userType = rbav;
            const params: any = {
                clientId: request.userDetails.client_id,
            };
            if (userType === UserType.OWNER) {
                params.createdBy = userType;
            }
            const listTemplate: WidgetTemplate[] =
                await dbService._findQueryService(
                    Container.get(DataSource).getRepository(WidgetTemplate),
                    { where: { ...params } }
                );
            return CommonHelper.apiSwaggerSuccessResponse({ data: lodash.isEmpty(listTemplate) ? null : listTemplate, message: txt.SUCCESS_EXECUTED, });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get Single Notification Template
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Get('widget/:id')
    async getTemplate(@Path() id: string,): Promise<any> {
        try {
            const notificationTemplate: WidgetTemplate | null =
                await dbService._findOneQueryService(
                    Container.get(DataSource).getRepository(WidgetTemplate),
                    {
                        id,
                    }
                );
            if (lodash.isEmpty(notificationTemplate)) {
                return CommonHelper.apiSwaggerSuccessResponse({data: {}, message: txt.NOTIFICATION_TEMPLATE_NO_DATA});
            }
            return CommonHelper.apiSwaggerSuccessResponse({ data: notificationTemplate, message: txt.SUCCESS_EXECUTED, });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Delete Notification Template(s)
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Delete('widget')
    async deleteTemplate(
        @Body() requestBody: DeleteTemplateRequest,
    ): Promise<any> {
        try {
            const deleteTemplateResponse: SetResponse =
                await dbService._deleteQueryService(
                    Container.get(DataSource).getRepository(WidgetTemplate),
                    {
                        id: requestBody.id,
                    }
                );

            if (deleteTemplateResponse.status === StatusType.ERROR) {
                return CommonHelper.apiSwaggerSuccessResponse({data: {}, message: txt.NOTIFICATION_TEMPLATE_NO_DATA});
            }
            return CommonHelper.apiSwaggerSuccessResponse({data: { deletedRows: deleteTemplateResponse.affected || 0 }, message: txt.NOTIFICATION_TEMPLATE_DELETED,});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
