import lodash from "lodash";
import {Body, Path, Post, Route, Request, Security, Tags, Get, Query, Put, Delete, Controller, Hidden} from "tsoa";
import { ApiErrorResponse,SetResponse, CommonHelper } from "../../../utils/helpers/common.helper";
import Container from 'typedi';
import { DataSource } from "typeorm";
import * as txt from "../utils/constants/api.constant";
import { MailTemplate } from "../../../entities";
import { StatusType, UserType } from "../../../models/enums";
import { cacheResponseData } from "../../../utils/redis.middleware";
import dbService from "../../../services/db.service";


@Route('template-builder')
@Tags('')
export class MailTemplateController extends Controller{
    // Services

    /**
     * Create Mail Template
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Post('mail')
    async createTemplate(
        @Body() requestBody: any,
        @Request() request: any,
    ): Promise<any> {
        try {
            let payload: any = requestBody;

            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;
            payload.updatedBy = request.userDetails.id;
            payload.formMapKey = requestBody.formMapKey
                ? JSON.stringify(requestBody.formMapKey)
                : null;

            payload = lodash.omit(payload, ["id"]);
            const mailTemplateResponse = await dbService._createQueryService(
                Container.get(DataSource).getRepository(MailTemplate),
                payload
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: { lastInsertId: mailTemplateResponse.id || '' }, message: txt.MAIL_TEMPLATE_SAVED });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update Mail Template
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Put('mail/:id')
    async updateTemplate(
        @Body() requestBody: any,
        @Request() request: any,
        @Path() id: string,
    ): Promise<any> { 
        try {
            const payload: any = requestBody;

            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;
            payload.formMapKey = requestBody.formMapKey
                ? JSON.stringify(requestBody.formMapKey)
                : null;

            const updatedMailTemplate = await dbService._updateQueryService(Container.get(DataSource).getRepository(MailTemplate), {
                id: request.params.id,
                ...payload,
            });
            return CommonHelper.apiSwaggerSuccessResponse({ data: { updatedRows: updatedMailTemplate.affected || 0 }, message: txt.MAIL_TEMPLATE_UPDATED });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * List all Mail Templates
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Get('mails')
    async listTemplate(
        @Request() request: any,
        @Query() rbav?: string,
    ): Promise<any> {
        try {
            const userType = rbav;
            const params: any = {
                clientId: request.userDetails.client_id,
            };
            if (userType === UserType.OWNER) {
                params.createdBy = userType;
            }
            const listMailTemplate: MailTemplate[] =
                await dbService._findQueryService(Container.get(DataSource).getRepository(MailTemplate), {
                    where: { ...params },
                });
            return CommonHelper.apiSwaggerSuccessResponse({ data: listMailTemplate, message: txt.SUCCESS_EXECUTED, });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get Single Mail Template
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Get('mail/:id')
    async getTemplate(
        @Request() request: any,
        @Path() id: string,
    ): Promise<any> {
        try {
            const mailTemplate: MailTemplate | null =
                await dbService._findOneQueryService(Container.get(DataSource).getRepository(MailTemplate), {
                    id: request.params.id,
                });

            if (lodash.isEmpty(mailTemplate)) {
                return { status: "error", data: {}, message: txt.MAIL_TEMPLATE_NO_DATA, error: null }
            }
            mailTemplate.formMapKey = lodash.isEmpty(mailTemplate?.formMapKey)
                ? null
                : JSON.parse(mailTemplate?.formMapKey);
            await cacheResponseData(request.originalUrl, {
                message: txt.SUCCESS_EXECUTED,
                data: mailTemplate,
            });
            return CommonHelper.apiSwaggerSuccessResponse({
                message: txt.SUCCESS_EXECUTED,
                data: mailTemplate,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Delete Mail Template(s)
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Delete('mail')
    async deleteTemplate(
        @Body() requestBody: any
    ): Promise<any> {
        try {
            const deleteTemplateResponse: SetResponse =
                await dbService._deleteQueryService(Container.get(DataSource).getRepository(MailTemplate), {
                    id: requestBody.id,
                });

            if (deleteTemplateResponse.status === StatusType.ERROR) {
                return CommonHelper.apiSwaggerSuccessResponse({data: {},message: txt.MAIL_TEMPLATE_NO_DATA});
            }
            return CommonHelper.apiSwaggerSuccessResponse({data: { deletedRows: deleteTemplateResponse.affected || 0 }, message: txt.MAIL_TEMPLATE_DELETED,});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
