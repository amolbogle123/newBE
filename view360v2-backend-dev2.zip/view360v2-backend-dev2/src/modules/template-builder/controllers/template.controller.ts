import {Body, Controller, Delete, Get, Patch, Path, Post, Query, Request, Route, Security, Tags} from "tsoa";
import lodash from "lodash";
import dbService from "services/db.service";
import Container from "typedi";
import { DataSource } from "typeorm";
import { MailTemplate, NotificationTemplate } from "entities";
import { ApiErrorResponse, CommonHelper, SetResponse } from "utils/helpers/common.helper";
import * as txt from "../utils/constants/api.constant";
import { StatusType, UserType } from "../../../models/enums";
import { cacheResponseData } from "utils/redis.middleware";

@Route('template-builder')
@Tags('Template Builder')
export class TemplateController extends  Controller{
    @Security('bearerAuth')
    @Post('/:type') 
    async createTemplate(
        @Body() requestBody: any,
        @Request() request: any,
        @Path() type: string,
    ): Promise<any> {
        try {
            let payload: any = requestBody;
            switch (type) {
                case 'mail':
                    payload.clientId = request.userDetails.client_id;
                    payload.createdBy = request.userDetails.id;
                    payload.updatedBy = request.userDetails.id;
                    payload.formMapKey = requestBody.formMapKey
                        ? JSON.stringify(requestBody.formMapKey)
                        : null;

                    payload = lodash.omit(payload, ["id"]);

                    const mailTemplateResponse = await dbService._createQueryService(
                        Container.get(DataSource).getRepository(MailTemplate),
                        payload
                    );

                    return { status: true, data: { lastInsertId: mailTemplateResponse.id || '' }, message: txt.MAIL_TEMPLATE_SAVED, }

                case 'notification':
                    payload.clientId = request.userDetails.client_id;
                    payload.createdBy = request.userDetails.id;
                    payload.updatedBy = request.userDetails.id;
                    payload = lodash.omit(payload, ["id"]);

                    const notificationTemplateResponse = await dbService._createQueryService(
                        Container.get(DataSource).getRepository(NotificationTemplate),
                        {
                            ...payload,
                        }
                    );
                    return CommonHelper.apiSwaggerSuccessResponse({data: { lastInsertId: notificationTemplateResponse.id || '' }, message: txt.NOTIFICATION_TEMPLATE_SAVED,});
            }

        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Patch('/:type/:id')
    async updateTemplate(
        @Body() requestBody: any,
        @Request() request: any,
        @Path() type: string,
        @Path() id: string
    ): Promise<any> {
        try {
            const payload: any = requestBody;

            switch (type) {
                case 'mail':
                    payload.clientId = request.userDetails.client_id;
                    payload.createdBy = request.userDetails.id;
                    payload.formMapKey = requestBody.formMapKey
                        ? JSON.stringify(requestBody.formMapKey)
                        : null;

                    const updatedMailTemplate = await dbService._updateQueryService(Container.get(DataSource).getRepository(MailTemplate), {
                        id,
                        ...payload,
                    });

                    return { status: true, data: { updatedRows: updatedMailTemplate.affected || 0 }, message: txt.MAIL_TEMPLATE_UPDATED, }
                case 'notification':
                    payload.clientId = request.userDetails.client_id;
                    payload.createdBy = request.userDetails.id;

                    payload.name = requestBody.name;
                    payload.message = requestBody.message;

                    const updateNotificationTemplate = await dbService._updateQueryService(
                        Container.get(DataSource).getRepository(NotificationTemplate),
                        {
                            id,
                            ...payload,
                        }
                    );
                    return CommonHelper.apiSwaggerSuccessResponse({data: { updatedRows: updateNotificationTemplate.affected || 0 }, message: txt.NOTIFICATION_TEMPLATE_UPDATED,});
            }

        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('/:type')
    async listTemplate(
        @Request() request: any,
        @Path() type: string,
        @Query() rbav?: string,
    ): Promise<any> {
        try {
            const userType = rbav;
            const params: any = {
                clientId: request.userDetails.client_id,
            };
            switch (type) {
                case 'mails':
                    if (userType === UserType.OWNER) {
                        params.createdBy = userType;
                    }
                    const listMailTemplate: MailTemplate[] =
                        await dbService._findQueryService(Container.get(DataSource).getRepository(MailTemplate), {
                            where: { ...params },
                        });

                    return { status: true, data: listMailTemplate, message: txt.SUCCESS_EXECUTED, }
                case 'notifications':
                    if (userType === UserType.OWNER) {
                        params.createdBy = userType;
                    }
                    const listTemplate: NotificationTemplate[] =
                        await dbService._findQueryService(
                            Container.get(DataSource).getRepository(NotificationTemplate),
                            { where: { ...params } }
                        );
                    return CommonHelper.apiSwaggerSuccessResponse({data: lodash.isEmpty(listTemplate) ? null : listTemplate, message: txt.SUCCESS_EXECUTED,});
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('/:type/:id')
    async getTemplate(
        @Request() request: any,
        @Path() type: string,
        @Path() id: string,
    ): Promise<any> {
        try {
            switch (type) {
                case 'mail':
                    const mailTemplate: MailTemplate | null =
                        await dbService._findOneQueryService(Container.get(DataSource).getRepository(MailTemplate), {
                            id: request.params.id,
                        });

                    if (lodash.isEmpty(mailTemplate)) {
                        return { status: false, data: {}, message: txt.MAIL_TEMPLATE_NO_DATA, error: null }
                    }

                    mailTemplate.formMapKey = lodash.isEmpty(mailTemplate?.formMapKey)
                        ? null
                        : JSON.parse(mailTemplate?.formMapKey);

                    await cacheResponseData(request.originalUrl, {
                        message: txt.SUCCESS_EXECUTED,
                        data: mailTemplate,
                    });

                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: txt.SUCCESS_EXECUTED,
                        data: mailTemplate,
                    });
                case 'notification':
                    const notificationTemplate: NotificationTemplate | null =
                        await dbService._findOneQueryService(
                            Container.get(DataSource).getRepository(NotificationTemplate),
                            {
                                id,
                            }
                        );

                    if (lodash.isEmpty(notificationTemplate)) {
                        return CommonHelper.apiSwaggerSuccessResponse({data: {}, message: txt.NOTIFICATION_TEMPLATE_NO_DATA,})
                    }
                    return CommonHelper.apiSwaggerSuccessResponse({data: notificationTemplate, message: txt.SUCCESS_EXECUTED});
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Delete('/:type')
    async deleteTemplate(
        @Body() requestBody: any,
        @Path() type: string
    ): Promise<any> {
        try {
            switch (type) {
                case 'mail':
                    const deleteMailTemplateResponse: SetResponse =
                        await dbService._deleteQueryService(Container.get(DataSource).getRepository(MailTemplate), {
                            id: requestBody.id,
                        });

                    if (deleteMailTemplateResponse.status === StatusType.ERROR) {
                        return { status: false, data: {}, message: txt.MAIL_TEMPLATE_NO_DATA, error: null }
                    }

                    return { status: true, data: { deletedRows: deleteMailTemplateResponse.affected || 0 }, message: txt.MAIL_TEMPLATE_DELETED, }
                case 'notification':
                    const deleteNotificationTemplateResponse: SetResponse =
                        await dbService._deleteQueryService(
                            Container.get(DataSource).getRepository(NotificationTemplate),
                            {
                                id: requestBody.id,
                            }
                        );

                    if (deleteNotificationTemplateResponse.status === StatusType.ERROR) {
                        return CommonHelper.apiSwaggerSuccessResponse({message: txt.NOTIFICATION_TEMPLATE_NO_DATA});
                    }
                    return CommonHelper.apiSwaggerSuccessResponse({data: { deletedRows: deleteNotificationTemplateResponse.affected || 0 }, message: txt.NOTIFICATION_TEMPLATE_DELETED,});
            }

        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
