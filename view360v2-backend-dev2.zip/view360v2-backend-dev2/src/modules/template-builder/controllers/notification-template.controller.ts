import lodash from "lodash";
import {Body, Path, Post, Route, Request, Security, Tags, Get, Query, Put, Delete, Controller, Hidden} from "tsoa";
import { CommonHelper,ApiErrorResponse,SetResponse } from "../../../utils/helpers/common.helper";
import * as txt from "../utils/constants/api.constant";
import { NotificationTemplate } from "../../../entities";
import { StatusType, UserType } from "../../../models/enums";
import dbService from "../../../services/db.service";
import Container from 'typedi';
import { DataSource } from "typeorm";
import { DeleteTemplateRequest } from '../doc/notificationTemplate-interface';

@Route('template-builder')
@Tags('')
export class NotificationTemplateController extends Controller {
    // Services

    /**
     * Create Notification Template
     * @param request Request  from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Post('notification')
    async createTemplate(
        @Body() requestBody: any,
        @Request() request: any,
    ): Promise<any> {
        try {
            let payload: any = requestBody;

            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;
            payload.updatedBy = request.userDetails.id;
            payload = lodash.omit(payload, ["id"]);

            const notificationTemplateResponse = await dbService._createQueryService(
                Container.get(DataSource).getRepository(NotificationTemplate),
                {
                    ...payload,
                }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: { lastInsertId: notificationTemplateResponse.id || '' }, message: txt.NOTIFICATION_TEMPLATE_SAVED, });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update Notification Template
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Put('notification/:id')
    async updateTemplate(
        @Body() requestBody: any,
        @Request() request: any,
        @Path() id: string,
    ): Promise<any> {
        try {
            let payload: any = {};

            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;

            payload.name = requestBody.name;
            payload.message = requestBody.message;

            const updatedMailTemplate = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(NotificationTemplate),
                {
                    id,
                    ...payload,
                }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: { updatedRows: updatedMailTemplate.affected || 0 }, message: txt.NOTIFICATION_TEMPLATE_UPDATED, });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * List all Notification Templates
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Get('notifications')
    async listTemplate(
        @Request() request: any,
        @Query() rbav?: string,
    ): Promise<any> {
        try {
            const userType = rbav;
            const params: any = {
                clientId: request.userDetails.client_id,
            };
            if (userType === UserType.OWNER) {
                params.createdBy = userType;
            }
            const listTemplate: NotificationTemplate[] =
                await dbService._findQueryService(
                    Container.get(DataSource).getRepository(NotificationTemplate),
                    { where: { ...params } }
                );
            return CommonHelper.apiSwaggerSuccessResponse({ data: lodash.isEmpty(listTemplate) ? null : listTemplate, message: txt.SUCCESS_EXECUTED, });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get Single Notification Template
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Get('notification/:id')
    async getTemplate(@Path() id: string,): Promise<any> {
        try {
            const notificationTemplate: NotificationTemplate | null =
                await dbService._findOneQueryService(
                    Container.get(DataSource).getRepository(NotificationTemplate),
                    {
                        id,
                    }
                );
            if (lodash.isEmpty(notificationTemplate)) {
                return CommonHelper.apiSwaggerSuccessResponse({data: {}, message: txt.NOTIFICATION_TEMPLATE_NO_DATA});
            }
            return CommonHelper.apiSwaggerSuccessResponse({ data: notificationTemplate, message: txt.SUCCESS_EXECUTED, });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Delete Notification Template(s)
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    @Security('bearerAuth')
    @Hidden()
    @Delete('notification')
    async deleteTemplate(
        @Body() requestBody: DeleteTemplateRequest,
    ): Promise<any> {
        try {
            const deleteTemplateResponse: SetResponse =
                await dbService._deleteQueryService(
                    Container.get(DataSource).getRepository(NotificationTemplate),
                    {
                        id: requestBody.id,
                    }
                );

            if (deleteTemplateResponse.status === StatusType.ERROR) {
                return CommonHelper.apiSwaggerSuccessResponse({data: {}, message: txt.NOTIFICATION_TEMPLATE_NO_DATA});
            }
            return CommonHelper.apiSwaggerSuccessResponse({data: { deletedRows: deleteTemplateResponse.affected || 0 }, message: txt.NOTIFICATION_TEMPLATE_DELETED,});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
