export interface CreateTemplateRequest {
    name: string;
    message: string;
}

export interface UpdateTemplateRequest {
    name?: string;
    message?: string;
}

export interface DeleteTemplateRequest {
    id: string;
}
