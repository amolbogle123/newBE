export interface CreateTemplateRequest {
    formMapKey: string;
}

export interface UpdateTemplateRequest {
    formMapKey: string;
}

export interface DeleteTemplateRequest {
    id: string;
}
