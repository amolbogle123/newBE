import { AppRoutes } from "../../app.routes";

export class TemplateBuilderRoutes extends AppRoutes {

    constructor() {
        super();
        this.initRoutes();
    }

    initRoutes(): void {
        /*
        * this.router.post('/template-builder/mail', (req, res, next) => this.mailTemplateController.createTemplate(req, res, next).catch(next));
        * this.router.put('/template-builder/mail/:id', (req, res, next) => this.mailTemplateController.updateTemplate(req, res, next).catch(next));
        * this.router.get('/template-builder/mail', (req, res, next) => this.mailTemplateController.listTemplate(req, res, next).catch(next));
        * this.router.get('/template-builder/mail/:id', (req, res, next) => this.mailTemplateController.getTemplate(req, res, next).catch(next));
        * this.router.delete('/template-builder/mail', (req, res, next) => this.mailTemplateController.deleteTemplate(req, res, next).catch(next));

        * this.router.post('/template-builder/notification', (req, res, next) => this.notificationTemplateController.createTemplate(req, res, next).catch(next));
        * this.router.get('/template-builder/notification', (req, res, next) => this.notificationTemplateController.listTemplate(req, res, next).catch(next));
        * this.router.get('/template-builder/notification/:id', (req, res, next) => this.notificationTemplateController.getTemplate(req, res, next).catch(next));
        * this.router.put('/template-builder/notification/:id', (req, res, next) => this.notificationTemplateController.updateTemplate(req, res, next).catch(next));
        * this.router.delete('/template-builder/notification', (req, res, next) => this.notificationTemplateController.deleteTemplate(req, res, next).catch(next));
        */
    }
}
