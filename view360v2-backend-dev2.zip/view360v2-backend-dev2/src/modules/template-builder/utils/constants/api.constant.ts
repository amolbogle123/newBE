

export const ERROR_UNKNOWN: string = 'unknown error.';


export const SUCCESS_EXECUTED: string = 'Operation has been successfully executed.';
export const MAIL_TEMPLATE_SAVED: string = 'Mail template created successfully.';
export const NOTIFICATION_TEMPLATE_SAVED: string = 'Notification template created successfully.';
export const WIDGET_TEMPLATE_SAVED: string = 'Widget template created successfully.';

export const MAIL_TEMPLATE_UPDATED: string = 'Mail template updated successfully.';
export const NOTIFICATION_TEMPLATE_UPDATED: string = 'Notification template updated successfully.';
export const MAIL_TEMPLATE_DELETED: string = 'Mail template deleted successfully.';
export const NOTIFICATION_TEMPLATE_DELETED: string = 'Notification template deleted successfully.';
export const MAIL_TEMPLATE_NO_DATA: string = 'Couldn\'t processed, mail template data not available.';
export const NOTIFICATION_TEMPLATE_NO_DATA: string = 'Couldn\'t processed, notification template data not available.';
