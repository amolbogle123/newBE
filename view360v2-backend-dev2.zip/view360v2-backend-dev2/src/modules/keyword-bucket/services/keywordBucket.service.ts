import Container from "typedi";
import { DataSource } from "typeorm";

export class KeywordBucketService {
    async getKeywordBuckets(pageNumber: number, pageSize: number) {
        // Query database using TypeORM's query builder
        const [data, recordsTotal] = await Container.get(DataSource).getRepository('KeywordBucket').findAndCount({
            where: { isDeleted: 0 },
            order: { createdOn: 'DESC' },
            skip: (pageNumber - 1) * pageSize,
            take: pageSize,
            select: ['id', 'clientId', 'keywordBucketName', 'keywordBucketDescription', 'keywords', 'isActive', 'createdOn', 'createdBy', 'updatedOn']
        });

        const totalPages = Math.ceil(recordsTotal / pageSize);

        return { data, recordsTotal, recordsFiltered: data.length, totalPages };
    }

    async createKeywordBucket(keywordBucketName: string, keywordBucketDescription: string, keywords: string,  clientId: string, createdBy: string) {
        // Create a new bucket
        const data = {
            keywordBucketName: keywordBucketName,
            keywordBucketDescription: keywordBucketDescription,
            keywords: keywords,
            clientId: clientId,
            createdBy: createdBy,
            createdOn: new Date()
        }

        return Container.get(DataSource).getRepository('KeywordBucket').save(data);
    }

    async getKeywordBucketById(id: string) {
        return Container.get(DataSource).getRepository('KeywordBucket').findOne({ where: { id: id, isDeleted: 0 } });
    }

    async updateKeywordBucket(id: string, keywordBucketName: string, keywordBucketDescription: string, keywords: any, updatedBy: string, isDeleted?: number) {
        const data = {
            keywordBucketName: keywordBucketName,
            keywordBucketDescription: keywordBucketDescription,
            keywords: keywords,
            updatedBy: updatedBy,
            updatedOn: new Date(),
            isDeleted: isDeleted
        }

        return Container.get(DataSource).getRepository('KeywordBucket').update(id, data);
    }
}
