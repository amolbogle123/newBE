import { Body, Controller, Get, Patch, Post, Query, Request, Route, Tags } from "tsoa";
import { KeywordBucketService } from "../services/keywordBucket.service";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";

@Route("keyword-bucket")
@Tags("Keyword Bucket")
export class KeywordBucketController extends Controller {
    private keywordBucketService: KeywordBucketService

    constructor() {
        super();
        this.keywordBucketService = new KeywordBucketService();
    }

    @Get()
    async getKeywordBuckets(
        @Query() pageNumber: number,
        @Query() pageSize: number
    ): Promise<void> {
        try {
            const response = await this.keywordBucketService.getKeywordBuckets(pageNumber, pageSize);

            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            console.error("Error :: Get Assessment Template :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post()
    async createKeywordBucket(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response = await this.keywordBucketService.createKeywordBucket(requestBody.keywordBucketName, requestBody.keywordBucketDescription, requestBody.keywords, req.userDetails.client_id, req.userDetails.id);

            return CommonHelper.apiSwaggerSuccessResponse({
                data: response
            });
        } catch (error) {
            console.error("Error :: Create Assessment Template :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("{id}")
    async getKeywordBucketById(id: string): Promise<void> {
        try {
            const response = await this.keywordBucketService.getKeywordBucketById(id);

            return CommonHelper.apiSwaggerSuccessResponse({
                data: response
            });
        } catch (error) {
            console.error("Error :: Get Bucket By Id :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Patch("{id}")
    async updateKeywordBucketById(
        id: string,
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response = await this.keywordBucketService.updateKeywordBucket(id, requestBody.keywordBucketName, requestBody.keywordBucketDescription, requestBody.keywords, req.userDetails.id, requestBody.isDeleted);

            return CommonHelper.apiSwaggerSuccessResponse({
                data: response
            });
        } catch (error) {
            console.error("Error :: Update Bucket By Id :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
