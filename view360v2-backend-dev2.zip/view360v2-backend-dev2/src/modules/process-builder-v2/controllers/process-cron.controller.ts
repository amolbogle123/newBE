import * as lodash from 'lodash';
import { Controller, Hidden, Post, Request, Route } from "tsoa";
import { dataSource } from "../../../core/data-source";
import { BusinessProcessModeling, BusinessProcessModelingSql, Cron, CustomForms, WidgetAccount } from "../../../entities";
import { FormBuilder } from "../../../entities/create-form-builder";
import { StatusType } from "../../../models/enums";
import { ApiErrorResponse, CommonHelper, SetResponse } from "../../../utils/helpers/common.helper";
import { ConnectorHelper } from "../../../utils/helpers/connector.helper";
import { FormBuilderService } from "../../form-builder/services/form-builder.service";
import { ConnectorParam, PanelData, ProcessDataType, ProcessStatus } from "../models";
import { ProcessBuilderService } from "../services/process-builder.service";
import { ProcessCronService } from "../services/process-cron.service";
import * as msg from "../utils/constants/api.constant";
import { ProcessBuilderHelper } from "../utils/helpers/process-builder.helper";

@Route('v2')
export class ProcessCronV2Controller extends Controller {
  // Services
  private processBuilderService: ProcessBuilderService = new ProcessBuilderService();
  private processCronService: ProcessCronService = new ProcessCronService();
  private formBuilderService: FormBuilderService = new FormBuilderService();

  // Helpers
  private processBuilderHelper: ProcessBuilderHelper = new ProcessBuilderHelper();

  private async sqlConnector(connectorParams: ConnectorParam, bpmn: BusinessProcessModeling) {
    const accountConfig = await this.getAccountConfig(connectorParams);

    const serviceResponse = await dataSource.getRepository(BusinessProcessModelingSql)
      .createQueryBuilder('BS')
      .where('BS.BPMN_ID = :bpmnId', { bpmnId: bpmn.id })
      .getMany();

    if (lodash.toLower(accountConfig.dbType) === lodash.toLower("MYSQL")) {
      let queryStatement: string;
      queryStatement = this.getQueryStatement(connectorParams, queryStatement, serviceResponse);

      const queryResponse: any = await ConnectorHelper.connect(null, queryStatement, accountConfig);
      if (
        queryResponse.status === "success" &&
        queryResponse?.data?.length > 0
      ) {
        const executableEntries: any[] = [];
        for (const value of queryResponse.data) {
          const columnName = value[connectorParams.columnName];

          // Need to check this as we are not passing formid
          this.processBuilderHelper.execute(
            bpmn.clientId, null, columnName, '', { type: 'SQL_CONNECTOR', bpmnid: bpmn.id, queryData: value }, null, null
          );
          executableEntries.push(columnName);
        }
        return this.processBuilderService.saveOrUpdateBpmnSql({ bpmn: bpmn.id, executeData: executableEntries.join(',') });
      } else {
        return CommonHelper.setResponse(StatusType.ERROR, msg.EXECUTABLE_DATA_NOT_FOUND);
      }
    }
  }

  private getQueryStatement(connectorParams: ConnectorParam, queryStatement: string, serviceResponse: BusinessProcessModelingSql[]) {
    if (connectorParams.isManualQuery && connectorParams.manualQuery) {
      queryStatement = connectorParams.manualQuery;
      if (!connectorParams.manualQuery.toLowerCase().includes('where')) {
        queryStatement += ` WHERE 1 = 1`;
      }
    } else {
      queryStatement = 'SELECT * FROM `' + connectorParams.sqlTable + '` WHERE 1 = 1';
    }
    // TO_DO: set this query, currently maxEntry key not found.
    // queryStatement += ` AND [${connectorParams.columnName}] > '${connectorParams.maxEntry}'`;
    if (serviceResponse?.length) {
      let executedEntries = lodash.flatten(
        serviceResponse.map((i: any) => i.executeData.split(',').filter(f => (f)))
      );
      queryStatement += ' AND `' + connectorParams.columnName + '` NOT IN ("' + (lodash.uniq(executedEntries) as string[]).join('","') + '")';
    }
    return queryStatement;
  }

  private async getAccountConfig(connectorParams: ConnectorParam) {
    const WAccountResult = await dataSource.getRepository(WidgetAccount)
      .createQueryBuilder('WA')
      .where('WA.ID = :id', { id: connectorParams.sqlAccount })
      .getOne();

    if (WAccountResult?.config) {
      try {
        return JSON.parse(WAccountResult.config);
      } catch (error) {
        // Handle parsing error
      }
    }

    return null;
  }

  // @Security('bearerAuth')
  @Post('bpmn-cron')
  @Hidden()
  async bpmnCron(@Request() request: any): Promise<any> {

    try {
      const bpmnId: string = request.body.bpmnId;

      if (lodash.isEmpty(request.body.bpmnId)) {
        return CommonHelper.apiSwaggerErrorResponse({ message: msg.BPMN_ID_NOT_FOUND, error: null });
      }

      const bpmnData = await this.getBpmnData(bpmnId);

      if (lodash.isEmpty(bpmnData)) {
        this.setStatus(404);
        return CommonHelper.apiSwaggerErrorResponse({ message: msg.DATA_NOT_FOUND, error: null });
      }
      if (bpmnData.status === 0) {
        // TO_DO update to logger instead of console.log("Cron skipped due to the BPMN is inactive. bpmnId:" + bpmnId);
        this.setStatus(202);
        return CommonHelper.apiSwaggerErrorResponse({ message: msg.BPMN_STATUS_INACTIVE, error: null });
      }
      const panelData: PanelData = JSON.parse(bpmnData?.panelData);
      const bpmnFormId: string | null = panelData.form || null;
      let referenceId: string | null = '';

      if (bpmnFormId) {
        const results: CustomForms[] = await this.formBuilderService
          .getCustomForms({ clientId: request.userDetails.client_id, id: bpmnFormId }, ["referenceId"]);
        referenceId = results[0].referenceId
      }
      return await this.processBPMN(bpmnFormId, bpmnData, referenceId, panelData, request);

    } catch (error) {
      const apiErrorResponse: ApiErrorResponse = {
        error: {
          error_description: (error as Error).message
        }
      }
      this.setStatus(500);
      return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
    }
  }
  
  @Post('cron-list')
  @Hidden()
  async cronList(@Request() request: any): Promise<any> {
    try {
      console.log('111... cron-list called.');
      const whereCond = {};
      const cronResponse: Cron[] = await this.processCronService.getCronList(whereCond);
      const message = !lodash.isEmpty(cronResponse) ? null : msg.DATA_NOT_FOUND;
      return CommonHelper.setResponse(StatusType.SUCCESS, message, cronResponse);
    } catch (error) {
      const apiErrorResponse: ApiErrorResponse = {
        error: {
          error_description: (error as Error).message
        }
      }
      this.setStatus(500);
      return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
    }
  }

    private async getBpmnData(bpmnId: string) {
        return this.processBuilderService.getBpmnById(bpmnId, ['id', 'clientId', 'sqlConnector', 'panelData', 'createdBy', 'status']);
    }

  private async processBPMN(bpmnFormId: string, bpmnData: BusinessProcessModeling, referenceId: string | null, panelData: PanelData, request: any) {
    if (bpmnData?.sqlConnector) {

      const sqlConnectorResponse: SetResponse = await this.sqlConnector(panelData.connectorParams, bpmnData);
      if (sqlConnectorResponse.status === StatusType.ERROR) {
        return CommonHelper.apiSwaggerErrorResponse({ message: sqlConnectorResponse.message, error: null });
      }
      return CommonHelper.apiSwaggerSuccessResponse({ message: sqlConnectorResponse.message });

    } else if (bpmnFormId) {
      const apiResponse = { status: true, data: [], message: "cron bpmn found and executed." };
      let submittedData = await this.getSubmittedBPMNFormData(request, bpmnFormId, bpmnData, referenceId);

      this.processBuilderHelper.execute(bpmnData?.clientId, bpmnFormId, request.body.entryId, referenceId, submittedData, bpmnData?.id, { type: ProcessDataType.FROM_BPMN_CRON });
      return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
    } else if (panelData.starton === ProcessStatus.CAMPAIGN) {

      if (lodash.isEmpty(panelData.campaign)) {
        return CommonHelper.apiSwaggerErrorResponse({ message: msg.CAMPAIGN_NOT_SELECTED, error: null });
      }
      const fieldsToBeFetched: any[] = ['id', 'name', 'emailConfig']
      const campaignSqlResponse: SetResponse = await this.processBuilderService
        .getSingleCampaign({ id: panelData.campaign, clientId: bpmnData?.clientId, status: 1 }, fieldsToBeFetched);

      if (lodash.isEmpty(campaignSqlResponse.data)) {
        this.setStatus(404);
        return CommonHelper.apiSwaggerErrorResponse({ message: msg.CAMPAIGN_NOT_FOUND, error: null });
      }
      const campaignData = campaignSqlResponse.data;
      campaignData.type = ProcessStatus.CAMPAIGN.toLocaleUpperCase();
      campaignData.createdBy = bpmnData?.createdBy;

      if (request.body.activityId) {
        campaignData.startProcessFrom = request.body.activityId;
        campaignData.executedActivities = request.body.executedActivities;
        await this.processCronService.deleteCron(request.body.refId);
      }
      await this.processBuilderHelper.execute(bpmnData?.clientId, null, null, referenceId, campaignData, bpmnData?.id, null);
      return CommonHelper.apiSwaggerSuccessResponse({ message: msg.CAMPAIGN_FOUND, data: campaignData });
    } else {

      await this.processBuilderHelper
        .execute(bpmnData?.clientId, null, null, referenceId, { type: 'BPMN_CRON', bpmnId: bpmnData?.id }, bpmnData?.id, null);
      return CommonHelper.apiSwaggerSuccessResponse({ message: msg.CRON_BPMN_FOUND_EXECUTED });
    }
  }

  private async getSubmittedBPMNFormData(request: any, bpmnFormId: string, bpmnData: BusinessProcessModeling, referenceId: string) {
    let submittedData = {
      executedActivities: request.body.executedActivities || [],
      submittedData: {}
    };

    const whereClause: any = { id: request.body.entryId, formId: bpmnFormId };
    const formBuilderRes: FormBuilder = await this.formBuilderService
      .getFormBuilder(bpmnData.clientId, referenceId, whereClause, ['submittedData']);
    if (formBuilderRes && !lodash.isEmpty(formBuilderRes) && formBuilderRes.submittedData) {
      submittedData.submittedData = formBuilderRes.submittedData;
    }
    return submittedData;
  }
}
