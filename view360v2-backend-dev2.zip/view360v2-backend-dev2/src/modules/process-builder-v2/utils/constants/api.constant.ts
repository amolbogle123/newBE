

export const ERROR_UNKNOWN: string = 'unknown error.';


export const SUCCESS_EXECUTED: string = 'Operation has been successfully executed.';
export const PROCESS_DELETE_SUCCESS: string = 'Process has been deleted successfully.';
export const DATA_NOT_FOUND: string = 'Couldn\'t process; data not found !';
export const CAMPAIGN_NOT_SELECTED: string = 'Couldn\'t process; campaign not selected !';
export const CAMPAIGN_NOT_FOUND: string = 'Couldn\'t process; campaign data not found !';
export const CAMPAIGN_FOUND: string = 'Successfully executed; campaign has been found !';
export const REFERENCE_ID_NOT_FOUND: string = 'Couldn\'t process; reference id not found !';
export const STATUS_UPDATE_SUCCESS: string = 'Status has been updated successfully.';
export const STATUS_UPDATE_SKIPPED: string = 'Status update not required.';
export const BPMN_SAVED: string = 'BPMN saved successfully.';
export const BPMN_STATUS_INACTIVE: string = 'BPMN is not active.';
export const FAILED_BPMN_SAVED: string = 'Failed to save the bpmn data.';
export const BPMN_ID_NOT_FOUND: string = 'Couldn\'t process; bpmn id not found !';
export const CRON_BPMN_FOUND_EXECUTED: string = 'Cron bpmn found and successfully executed !';
export const EXECUTABLE_DATA_NOT_FOUND: string = 'Couldn\'t process; executable data not found !';
export const ALREADY_EXECUTED: string = 'This is already executed !';
export const USER_INPUT_DONE: string = 'User input is done !';
export const SMS_FAILED: string = 'Couldn\'t sent message !';
