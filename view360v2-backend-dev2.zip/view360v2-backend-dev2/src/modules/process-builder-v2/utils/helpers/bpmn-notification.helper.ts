import {PanelDataTask, ProcessAssignee} from "../../models";
import {Notification, NotificationTemplate} from "../../../../entities";
import Container from 'typedi';
import {DataSource} from 'typeorm';

export class BpmnNotificationHelper {

    async execute(formId: string, insertId: string, params: any, type: PanelDataTask | any, clientId: number, createdBy: string, payload?: any): Promise<any> {
        const notificationMapping = {
            [PanelDataTask.ASSIGN]: {
                roleType: ProcessAssignee.ROLE,
                message: "Process : Assignment Task for You.1",
                url: "/forms-builder/custom-form-view/",
                userParam: "assignee",
            },
            [PanelDataTask.SEND_FOR_REVIEW]: {
                roleType: ProcessAssignee.USER,
                message: "Process : Task to review",
                url: "/forms-builder/custom-form-view/",
                userParam: "assignee",
            },
            [PanelDataTask.APPROVAL]: {
                roleType: ProcessAssignee.USER,
                message: "Process : Approval Task for You",
                url: "/forms-builder/custom-form-view/",
                userParam: "assignee",
            },
            [PanelDataTask.DRAFT_INITIATION]: {
                roleType: 0,
                message: "Process : Draft Task for You",
                url: "/forms-builder/custom-form-view/",
                userParam: "assignee",
            },
            [PanelDataTask.START_INITIATION]: {
                roleType: 0,
                message: "Process : You can start the Process Now",
                url: "/forms-builder/custom-form-view/",
                userParam: "assignee",
            },
            [PanelDataTask.RECEIVE_TASK_NOTIFY]: {
                roleType: 0,
                message: "Trigger: Trigger threshold hit",
                url: "/dynamic-dashboard",
                userParam: "assignee",
            },
        };
    
        const mapping = notificationMapping[type];
    
        if (!mapping) {
            return;
        }
    
        let role: string | null = null;
        let user: any | null = null;
        let url: string = '';
        let msg: string = '';
    
        if (params && params.notificationTemplate) {
            const notifyTemplateArr = await Container.get(DataSource).getRepository(NotificationTemplate)
                .find({ where: { id: params.notificationTemplate }, select: ['message'] });
    
            if (notifyTemplateArr && notifyTemplateArr.length > 0) {
                msg = notifyTemplateArr[0].message;
            }
        }
    
        if (params.assignto === ProcessAssignee.ROLE) {
            role = params[mapping.userParam][0];
        } else if (params.assignto === ProcessAssignee.USER || params.assignto === ProcessAssignee.FORM_FIELD) {
            user = params[mapping.userParam][0];
        }
    
        if (formId && insertId) {
          url = mapping.url + formId + "/" + insertId + "/view";
        } else {
          url = mapping.url;
        }
        msg = msg || mapping.message;
    
        const insertData = {
            clientId,
            type,
            senderId: createdBy || '',
            receiverId: user || 0,
            roleType: role || 0,
            message: msg,
            redirectUrl: url,
            createdBy: createdBy || '',
        } as unknown as Notification;
        if (params.notificationExtraData) {
            const extraDataValue = this.getValueFromPayload(payload, params.notificationExtraData);
            if (typeof extraDataValue !== 'undefined') {
              insertData.extraData = JSON.stringify(extraDataValue);
            }
        }
        // if (payload?.apiResult?.data?.notificationTriggerValue) {
        //   insertData.extraData = JSON.stringify(payload.apiResult.data.notificationTriggerValue);
        // }
    
        await Container.get(DataSource).getRepository(Notification).save(insertData);
    }
    getValueFromPayload(object, path) {
      // Split the path into an array of keys
      const keys = path.split('.');
    
      // Traverse the object using a loop
      let current = object;
      for (const key of keys) {
        // Check if the current property exists
        if (current && typeof current === 'object') {
          current = current[key];
        } else {
          // Key not found or invalid path
          return undefined;
        }
      }
    
      // Return the final value
      return current;
    }
}
