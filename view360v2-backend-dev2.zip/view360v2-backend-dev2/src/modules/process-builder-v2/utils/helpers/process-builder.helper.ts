import { Engine } from 'bpmn-engine';
import EventEmitter from "events";
import lodash from "lodash";
import Container from 'typedi';
import { DataSource } from 'typeorm';
import { BusinessProcessModeling } from "../../../../entities";
import { FormBuilder } from "../../../../entities/create-form-builder";
import { FormBuilderHelper } from "../../../form-builder/utils/helpers/form-builder.helper";
import { MailAccountService } from "../../../mail-account/services/mail-account.service";
import { Conditions, PanelData, PanelDataTask, ProcessDataType, ProcessStatus } from "../../models";
import { ProcessBuilderService } from "../../services/process-builder.service";
import { ReceiveTask } from "../../tasks/receive-task";
import { ServiceTask } from "../../tasks/service-task";
import { GamilService } from "../../tasks/service-task/add-ons/gmail.service";
import { TimerTask } from "../../tasks/timer-task";
import { UserTask } from "../../tasks/user-task";



export class ProcessBuilderHelper {
  private scope: any;

  // Services
  private processBuilderService: ProcessBuilderService = new ProcessBuilderService();
  private gmailService: GamilService = new GamilService();
  private mailAccountService: MailAccountService = new MailAccountService();

  // Other Helpers
  private userTask: UserTask = new UserTask();
  private receiveTask: ReceiveTask = new ReceiveTask();
  private timerTask: TimerTask = new TimerTask();
  private serviceTask: ServiceTask = new ServiceTask();



  private async checkAndGetNext(workFlow: any[], formId: string | null, insertId: any = null): Promise<any> {
    const criteria = { formId, followAfter: workFlow[0].id, entryId: insertId, taskName: PanelDataTask.APPROVED_INITIATION, status: 1 };
    const bpmnExecResponse = await this.processBuilderService.getBpmnExecute(criteria, ['id']);

    if (bpmnExecResponse.length > 0 || !lodash.isEmpty(bpmnExecResponse)) {
      const workFlow1 = await this.processBuilderService.getMultipleBpmn({ formId, followAfter: workFlow[0].id });

      if (workFlow1 && workFlow1.length > 0) {
        return this.checkAndGetNext(workFlow1, formId);
      }
    } else {
      return workFlow;
    }

  }

  private static valueCompare(value1: any, conditionOf: any, value2: any): { result: boolean, matchedKeywords?: Array<string> } {
    if (typeof value1 === 'string') {
      value1 = value1.toLowerCase();
    } else if (typeof value1 === "boolean") {
      value1 = value1.toString();
    } else if (!isNaN(value1)) {
      value1 = parseFloat(value1);
    }

    if (typeof value2 === 'string') {
      value2 = value2.toLowerCase();
    } else if (typeof value2 === "boolean") {
      value2 = value2.toString();
    } else if (!isNaN(value2)) {
      value2 = parseFloat(value2);
    }

    switch (conditionOf) {
      case 'equals':
        return { result: (value1 == value2) };
      case 'notequals':
        return { result: (value1 != value2) };
      case 'greaterthan':
        return { result: (value1 > value2) };
      case 'smallerthen':
        return { result: (value1 < value2) };
      case 'greaterequals':
        return { result: (value1 >= value2) };
      case 'smallerequals':
        return { result: (value1 <= value2) };
      case 'contains':
        if (Array.isArray(value1) && value1?.length > 0) {
          let matchedWords = [];
          value1.forEach(obj => {
            if (value2.includes(obj)) {
              matchedWords.push(obj);
            }
          })
          return { result: matchedWords.length ? true : false, matchedKeywords: matchedWords };
        }
        return { result: value1.includes(value2) };
      case 'startswith':
        return { result: value1.startsWith(value2) };
      case 'endswith':
        return { result: value1.endsWith(value2) };
      default:
        return { result: false };
    }
  }

  private checkCondition(checkId: any, panelData: PanelData | any, data: any, insertId: string | null, payload: any, keywordBuckets: any) {
    console.log("Inside Check Condition");
    const condition = panelData.conditionsarr.find((x: Conditions) => x.id === checkId);

    if (condition && condition.conditionon && condition.conditionType && condition.params?.sqlFields) {
      const sourceData = this.getSourceData(condition.conditionon, panelData, data, insertId, payload);

      if (sourceData || condition.conditionon == 'TASK_RESPONSE') {
        const checkedCount = this.countMatches(condition.conditionon, sourceData, condition.params.sqlFields, panelData, payload, keywordBuckets, checkId);
        console.log('checkedCount', checkedCount);
        console.log('condition.conditionType', condition.conditionType);

        if ((condition.conditionType === 'AND' && checkedCount === condition.params.sqlFields.length) || (condition.conditionType === 'OR' && checkedCount > 0)) {
          return true;
        } else {
          return false;
        }
      }
    }

    return false;
  }

  private getSourceData(conditionon: string, panelData: PanelData | any, data: any, insertId: string | null, payload: any) {
    if (conditionon === 'CONNECTOR' && panelData.connectorParams?.columnName) {
      return data?.queryData && data.queryData[panelData.connectorParams.columnName] === insertId
        ? data.queryData
        : null;
    } else if (conditionon === 'FORM' && data?.submittedData) {
      try {
        return JSON.parse(data.submittedData);
      } catch {
        return null;
      }
    } else if (conditionon === 'EMAIL_BUCKET') {
      return payload;
    } else if (conditionon === 'PAYLOAD') {
      return payload;
    }
    return null;
  }

  private countMatches(conditionon: string, sourceData: any, sqlFields: any[], panelData: PanelData | any, payload: any, keywordBuckets: any, checkId: string) {
    let checkedCount = 0;
    console.log('conditionon', conditionon);
    if (conditionon === 'EMAIL_BUCKET') {
      payload.bucketInfo = { condition: "EMAIL_BUCKET", matchedBucket: [] }
    }

    for (const field of sqlFields) {
      let sourceValue = sourceData?.[field.columnName] ?? '';
      let matchValue = '';
      if (conditionon === 'FORM') {
        matchValue = field.otherValue;
      } else if (sourceData?.[field.formField]) {
        matchValue = sourceData[field.formField];
      } else if (conditionon === 'TASK_RESPONSE') {
        matchValue = field.otherValue;
      }

      if (conditionon === 'TASK_RESPONSE' && field.columnName) {
        const taskData = panelData.taskarr.find((x: any) => x.id === field.columnName);
        if (taskData?.params && typeof taskData.params[`${field.taskOutput}`] !== 'undefined') {
          sourceValue = taskData.params[`${field.taskOutput}`];
        }
      }
      
      if (conditionon === 'EMAIL_BUCKET' && field.matchCase && keywordBuckets?.length && payload?.mailData?.body) {
        // let keywordBucket = await Container.get(DataSource).getRepository('KeywordBucket').findOne({ where: { id: field.columnName }});
        let selectedKeywordBucket = keywordBuckets.find(obj => obj.id == field.columnName);
        sourceValue = selectedKeywordBucket.keywords.split(',');
        matchValue = payload.mailData.subject + payload.mailData.body;
        // console.log('sourceValue', sourceValue);
        // console.log('field.matchCase', field.matchCase);
        // console.log('matchValue', matchValue);
        // console.log("Inside Email Bucket Condition :: Payload :: ", JSON.stringify(payload))
        // const keywords = selectedKeywordBucket.keywords.split(',');
        // for (const keyword of keywords) {
        //   if (ProcessBuilderHelper.valueCompare(sourceData.mailInfo.body, field.matchCase, keyword)) {
        //     // console.log("Matched Keyword :: ", keyword)
        //     const bucketInfo = { bucketName: selectedKeywordBucket.keywordBucketName, matchedKeyword: keyword, recipientsEmail: selectedKeywordBucket.recipients };
        //     // console.log("Bucket Info before addOrUpdate :: ", bucketInfo)
        //     this.addOrUpdate(payload, bucketInfo);
        //     checkedCount += 1;
        //   }
        // }

        // if (field.conditionType === 'OR') {
        //   break;
        // }
      } else if (conditionon === 'PAYLOAD' && field.matchCase && sourceData) {
        sourceValue = this.getValueFromObject(sourceData, field.columnName);
        matchValue = field.otherValue;
      }
      // console.log('sourceValue', sourceValue);
      // console.log('matchValue', matchValue);
      const valueCompareResult = ProcessBuilderHelper.valueCompare(sourceValue, field.matchCase, matchValue);
      if (valueCompareResult.matchedKeywords?.length && payload?.mailData?.body) {
        payload.mailData.passActivityId = field.columnName;
        if (!payload.mailData.matchedBuckets) {
          payload.mailData.matchedBuckets = [];
        }
        const matchedBucket = keywordBuckets.find(obj => obj.id == field.columnName);
        payload.mailData.matchedBuckets.push({
          bucketId: field.columnName,
          bucketName: matchedBucket.keywordBucketName,
          matchedKeywords: valueCompareResult.matchedKeywords.join(',')
        })
        payload.mailData.bucketName = matchedBucket.keywordBucketName;
      }
      if (sourceValue !== '' && field.matchCase && matchValue !== '' && valueCompareResult.result) {
        checkedCount += 1;

        if (field.conditionType === 'OR') {
          break;
        }
      }
    }

    return checkedCount;
  }


  // private async executeWorkFlow({ bpmnId, panel_data, data, bpmnData, insertId, tempId, client_id, formTableName, payload, mailAccount, keywordBucket, bpmnCreatedOn }) {
  //   const panelData: any = JSON.parse(panel_data);
  //   panelData.executedActivities = [];
  //   // console.log('executeWorkFlow called.', payload);
  //   // return;

  //   if (Array.isArray(data.executedActivities) && data.executedActivities.length) {
  //     panelData.executedActivities = data.executedActivities;
  //   }

  //   let engine = Engine({ name: 'exclusive gateway example', source: bpmnData, });
  //   const listener = new EventEmitter();

  //   listener.on('wait', async (elemntApi, instance) => {
  //     // Nothing to work here as of now...
  //   });

  //   listener.on('wait', (api) => {
  //     console.log(api.name, 'is waiting');
  //     // api.signal();
  //   });

  //   listener.on('activity.start', async (api) => {
  //     if (api.type && api.type.includes('UserTask')) {
  //       const taskVars = { panelData, api, data, formId: tempId, entryId: insertId, client_id, bpmnId, formTableName };
  //       await this.userTask.executeTask(taskVars, engine);
  //     }
  //     if (api.type && api.type.includes('IntermediateCatchEvent')) {
  //       const taskVars = { panelData, api, data, clientId: client_id, bpmnId, entryId: insertId };
  //       await this.timerTask.executeTask(taskVars, engine);
  //     }

  //     if (api.type && api.type.includes('ReceiveTask')) {
  //       const taskVars = { panelData, api, data, formId: tempId, entryId: insertId, clientId: client_id };
  //       await this.receiveTask.executeTask(taskVars);
  //     }

  //     if (api.type && api.type.includes('EndEvent')) {
  //         //This is left intentionally blank. Nothing is gonna be happen here....
  //         console.log('EndEvent called. --->');
  //     }

  //   });

  //   /**
  //    * listener.on('flow.take', (flow) => {
  //       //This is left intentionally blank. Nothing to work here as of now...
  //   });

  //   listener.on('flow.discard', (flow) => {
  //       //This is left intentionally blank. Nothing to work here as of now...
  //   });
  //    */

  //   const result = await this.executeFlow(engine, listener, client_id, bpmnId, tempId, panelData, data, insertId, formTableName, payload, mailAccount, keywordBucket, bpmnCreatedOn);
  //   console.log("Result in executeWorkFlow :: 279 :: ", result);
  //   /**
  //    * let subProcess = await this.processBuilderService.getNextSubProcess(panelData.bpmnId,"PENDING",this.scope.id,"GMAIL");
  //   if (subProcess) {
  //     const connectorResult: WidgetAccount = await Container.get(DataSource).getRepository(WidgetAccount).findOne({ where: { id: panelDataObj.params.connectorApi } });
  //     this.gmailService.checkAndGoNextSubProcess(this.processBuilderService, this.mailAccountService, panelData, this.scope, payload, mailAccount, "", subProcess,)
  //   }
  //    */
  // }

  private async executeWorkFlow({ bpmnId, panel_data, data, bpmnData, insertId, tempId, client_id, formTableName, payload, mailAccount, keywordBucket, bpmnCreatedOn }) {
    const panelData: any = JSON.parse(panel_data);
    panelData.executedActivities = [];

    if (Array.isArray(data.executedActivities) && data.executedActivities.length) {
      panelData.executedActivities = data.executedActivities;
    }

    let engine = Engine({ name: 'exclusive gateway example', source: bpmnData });
    const listener = new EventEmitter();

    // Listeners to handle various engine events
    listener.on('wait', async (elementApi, instance) => {
      // Placeholder for handling 'wait' event asynchronously
    });

    listener.on('wait', (api) => {
      console.log(api.name, 'is waiting');
      // api.signal();
    });

    listener.on('activity.start', async (api) => {
      // Handling UserTask
      if (api.type && api.type.includes('UserTask')) {
        const taskVars = { panelData, api, data, formId: tempId, entryId: insertId, client_id, bpmnId, formTableName };
        await this.userTask.executeTask(taskVars, engine);
      }

      // Handling IntermediateCatchEvent
      if (api.type && api.type.includes('IntermediateCatchEvent')) {
        const taskVars = { panelData, api, data, clientId: client_id, bpmnId, entryId: insertId };
        await this.timerTask.executeTask(taskVars, engine);
      }

      // Handling ReceiveTask
      if (api.type && api.type.includes('ReceiveTask')) {
        const taskVars = { panelData, api, data, formId: tempId, entryId: insertId, clientId: client_id };
        await this.receiveTask.executeTask(taskVars);
      }

      // Handling EndEvent
      if (api.type && api.type.includes('EndEvent')) {
        console.log('EndEvent called. --->');
      }
    });

    // Execute the flow using the listener and engine
    const result = await this.executeFlow(engine, listener, client_id, bpmnId, tempId, panelData, data, insertId, formTableName, payload, mailAccount, keywordBucket, bpmnCreatedOn);
    return result;

    // Additional async handling for subProcess (if applicable)
    /**
     * let subProcess = await this.processBuilderService.getNextSubProcess(panelData.bpmnId, "PENDING", this.scope.id, "GMAIL");
     * if (subProcess) {
     *     const connectorResult: WidgetAccount = await Container.get(DataSource).getRepository(WidgetAccount).findOne({ where: { id: panelDataObj.params.connectorApi } });
     *     await this.gmailService.checkAndGoNextSubProcess(this.processBuilderService, this.mailAccountService, panelData, this.scope, payload, mailAccount, "", subProcess);
     * }
     */
  }


  // private executeFlow(engine, listener: EventEmitter, client_id: any, bpmnId: any, tempId: any, panelData: any, data: any, insertId: any, formTableName: any, payload: any, mailAccount: any, keywordBucket: any, bpmnCreatedOn: any) {
  //   engine.execute({
  //     listener,
  //     services: {
  //       getRequest: async (scope: any, callback: (arg0: null, arg1: unknown) => any) => {
  //         this.scope = scope;
  //         try {
  //           const taskVarPanelVars = { client_id, bpmnId, formId: tempId, bpmnCreatedOn };
  //           const result: any = await this.serviceTask.executeTask(Object.assign(taskVarPanelVars, panelData), data, scope, insertId, formTableName, payload, mailAccount);
  //           console.log('getRequest--->result', result);
  //           if (result?.stopEngine) {
  //             engine.stop();
  //           }
  //           return callback(null, result);
  //         } catch (err) {
  //           console.error('err', err);
  //           return callback(null, err);
  //         }
  //       },
  //       check: (checkId: any) => {
  //         console.log("Condition Check :: ", checkId);
  //         return this.checkCondition(checkId, panelData, data, insertId, payload, keywordBucket);
  //       }
  //     }
  //   });
  // }

  private async executeFlow(
    engine,
    listener: EventEmitter,
    client_id: any,
    bpmnId: any,
    tempId: any,
    panelData: any,
    data: any,
    insertId: any,
    formTableName: any,
    payload: any,
    mailAccount: any,
    keywordBucket: any,
    bpmnCreatedOn: any
  ): Promise<any> {
    try {
      // Wrap engine.execute in a Promise to control its execution flow and capture the result
      const result = await new Promise<any>((resolve, reject) => {
        engine.execute(
          {
            listener,
            services: {
              getRequest: async (scope: any, callback: (arg0: null, arg1: unknown) => any) => {
                this.scope = scope;
                let taskResult;
                try {
                  const taskVarPanelVars = { client_id, bpmnId, formId: tempId, bpmnCreatedOn };
                  // Await task execution
                  taskResult = await this.serviceTask.executeTask(
                    Object.assign(taskVarPanelVars, panelData),
                    data,
                    scope,
                    insertId,
                    formTableName,
                    payload,
                    mailAccount
                  );
  
                  // Log result before invoking the callback
                  console.log('getRequest--->result', taskResult);
  
                  // Stop the engine if required
                  if (taskResult?.stopEngine) {
                    await engine.stop();
                  }
  
                  // Resolve the Promise with the result
                  resolve(taskResult);
                  callback(null, taskResult);
                } catch (err) {
                  console.error('Error during task execution:', err);
                  // Reject the Promise and pass error to callback
                  reject(err);
                  callback(null, err);
                }
              },
              check: async (checkId: any) => {
                console.log('Condition Check :: ', checkId);
                return this.checkCondition(checkId, panelData, data, insertId, payload, keywordBucket);
              },
            },
          },
          (err: Error | null) => {
            // If an error occurs outside of getRequest, reject the Promise
            if (err) {
              console.error('Error executing engine:', err);
              reject(err);
            }
          }
        );
      });
  
      // Return the captured result
      return result;
    } catch (error) {
      console.error('Error executing flow:', error);
      throw error;
    }
  }  

  // async execute(clientId: number, formId: string | null, entryId: string | null, referenceId: string, data: any = null, bpmnId: string | null = null, extra: any = {}): Promise<any> {
  //   console.log("Inside Execute")
  //   console.log("Data :: ", data);
  //   console.log('-----execute clientId', clientId);
  //   console.log('-----execute formId', formId);
  //   console.log('-----execute entryId', entryId);
  //   console.log('-----execute bpmnId', bpmnId);
  //   console.log('-----execute extra', extra);

  //   /* STARTING POINT of BPMN */
  //   // const customFormTable = await FormBuilderHelper.getTableName(clientId, formBuilderEntity);
  //   const customFormTable = `form_builder_${clientId}_${referenceId}`;

  //   if (lodash.isEmpty(data) && formId && entryId) {
  //     // const queryResponse: FormBuilder[] = await ( await FormBuilderHelper.formBuilderRepo(clientId) ).findBy({formId, id: entryId});
  //     const queryResponse: FormBuilder[] = await (await FormBuilderHelper.formBuilderRepo(clientId, referenceId)).findBy({ formId, id: entryId });

  //     if (queryResponse.length > 0) {
  //       data = queryResponse[0];
  //     }
  //   }
  //   if (data.submittedData && typeof data.submittedData === 'string') {
  //     data.submittedData = JSON.parse(data.submittedData);
  //   }

  //   if (bpmnId) {
  //     data.bpmnid = bpmnId;
  //   }
  //   if (clientId && !data.client_id) {
  //     data.client_id = clientId;
  //   }
  //   // console.log('-----execute data', data);

  //   const directBpmnType: ProcessDataType[] = [
  //     ProcessDataType.SQL_CONNECTOR,
  //     ProcessDataType.FROM_ANOTHER_PROCESS,
  //     ProcessDataType.PULSE_THRESHOLD,
  //     ProcessDataType.CAMPAIGN,
  //     ProcessDataType.MANUAL_TRIGGER,
  //     ProcessDataType.BPMN_CRON,
  //     ProcessDataType.CUSTOM_EVENT
  //   ];
  //   let workflow: string | any[] = await this.getWorkflow(data, formId, directBpmnType);

  //   if (workflow.length > 0) {
  //     let newWorkFlow: BusinessProcessModeling[] = await this.checkAndGetNext(workflow, formId, entryId);

  //     if (newWorkFlow.length > 0) {
  //       for (let i = newWorkFlow.length - 1; i >= 0; i--) {

  //         if (
  //           newWorkFlow[i].type === ProcessStatus.TIMER_BASED &&
  //           extra && extra.type === ProcessStatus.FORM_SUBMIT
  //         ) {
  //           continue;
  //         }
  //         let { id, panelData, bpmnData, createdOn } = newWorkFlow[i];

  //         let executeWorkFlowInput = {
  //           bpmnId: id,
  //           panel_data: panelData,
  //           // panel_data: await this.configurePayload(panelData, data),
  //           data: data,
  //           bpmnData: bpmnData,
  //           insertId: entryId,
  //           tempId: formId,
  //           client_id: clientId,
  //           formTableName: customFormTable,
  //           payload: Object.assign({}, await this.configurePayload(panelData, data)),
  //           mailAccount: '',
  //           bpmnCreatedOn: createdOn,
  //           keywordBucket: []
  //         }
  //         // await this.executeWorkFlow(executeWorkFlowInput);

  //         let emailCount = 0;
  //         let emailList: any;
  //         const panelData1: any = JSON.parse(panelData);
  //         for(const task of panelData1.taskarr) {
  //           if(task.serviceType === 'GMAIL') {
  //              if(task.params.selectedEmails.length > 0) {
  //                emailCount = task.params.selectedEmails.length;
  //                emailList =  task.params.selectedEmails;
  //              }
  //           }
  //         }
  //         if (data?.type === 'BPMN_SUBPROCESS_ACTIVITY') {
  //           let keywordBucket = await Container.get(DataSource).getRepository('KeywordBucket').find();
  //           executeWorkFlowInput.keywordBucket = keywordBucket;
  //           emailCount = 0;
  //         }
  //         console.log('emailCount', emailCount);
  //         if(emailCount > 0) {
  //           let keywordBucket = await Container.get(DataSource).getRepository('KeywordBucket').find();
  //           executeWorkFlowInput.keywordBucket = keywordBucket;
  //           //await this.createSubProcessAndExecuteWorkFlow(emailList,executeWorkFlowInput);
  //           for (const mail of emailList) {
  //             executeWorkFlowInput.mailAccount = mail;
  //             console.log("Mail List loop :: Mail :: ", mail)
  //             await this.executeWorkFlow(executeWorkFlowInput);
  //           }
  //         } else if (panelData1.enableMultipleStart && panelData1.multipleValueField && lodash.isArray(data?.submittedData?.[panelData1.multipleValueField])) {
  //           for (const multiValueData of data?.submittedData?.[panelData1.multipleValueField]) {
  //             data.submittedData.row = multiValueData;
  //             const executeInput = {
  //               bpmnId: id,
  //               panel_data: panelData,
  //               data: data,
  //               bpmnData: bpmnData,
  //               insertId: entryId,
  //               tempId: formId,
  //               client_id: clientId,
  //               formTableName: customFormTable,
  //               payload: await this.configurePayload(panelData, data),
  //               mailAccount: '',
  //               bpmnCreatedOn: createdOn,
  //               keywordBucket: []
  //             }
  //             // console.log("DataGrid loop :: GridData :: ", executeInput.payload);
  //             await this.executeWorkFlow(executeInput);
  //           }
  //           // data?.submittedData?.[panelData1.multipleValueField].forEach(async (multiValueData) => {
  //           //   const executeInput = { ...executeWorkFlowInput };
  //           //   executeInput.data.submittedData.row = multiValueData;
  //           //   executeInput.payload.submittedData.row = multiValueData;
  //           //   await this.executeWorkFlow(executeInput);
  //           // });
  //         } else {
  //            await this.executeWorkFlow(executeWorkFlowInput);
  //            return { "data": "My data after executeWorkFlow"}
  //         }
  //       }
  //     }

  //   }
  // }

  async execute(clientId: number, formId: string | null, entryId: string | null, referenceId: string, data: any = null, bpmnId: string | null = null, extra: any = {}): Promise<any> {
    console.log("Inside Execute");
    console.log("Data :: ", data);
    console.log('-----execute clientId', clientId);
    console.log('-----execute formId', formId);
    console.log('-----execute entryId', entryId);
    console.log('-----execute bpmnId', bpmnId);
    console.log('-----execute extra', extra);

    // STARTING POINT of BPMN
    const customFormTable = `form_builder_${clientId}_${referenceId}`;

    if (lodash.isEmpty(data) && formId && entryId) {
        const queryResponse: FormBuilder[] = await (await FormBuilderHelper.formBuilderRepo(clientId, referenceId)).findBy({ formId, id: entryId });

        if (queryResponse.length > 0) {
            data = queryResponse[0];
        }
    }

    if (data?.submittedData && typeof data.submittedData === 'string') {
        data.submittedData = JSON.parse(data.submittedData);
    }

    if (bpmnId) {
        data.bpmnid = bpmnId;
    }

    if (extra?.type === 'customevent') {
      data.type = 'CUSTOM_EVENT';
    }

    if (clientId && !data.client_id) {
        data.client_id = clientId;
    }

    const directBpmnType: ProcessDataType[] = [
        ProcessDataType.SQL_CONNECTOR,
        ProcessDataType.FROM_ANOTHER_PROCESS,
        ProcessDataType.PULSE_THRESHOLD,
        ProcessDataType.CAMPAIGN,
        ProcessDataType.MANUAL_TRIGGER,
        ProcessDataType.BPMN_CRON,
        ProcessDataType.CUSTOM_EVENT
    ];

    let workflow: string | any[] = await this.getWorkflow(data, formId, directBpmnType);

    if (workflow.length > 0) {
        let newWorkFlow: BusinessProcessModeling[] = await this.checkAndGetNext(workflow, formId, entryId);

        if (newWorkFlow.length > 0) {
            for (let i = newWorkFlow.length - 1; i >= 0; i--) {
                if (
                    newWorkFlow[i].type === ProcessStatus.TIMER_BASED &&
                    extra && extra.type === ProcessStatus.FORM_SUBMIT
                ) {
                    continue;
                }

                let { id, panelData, bpmnData, createdOn } = newWorkFlow[i];
                let executeWorkFlowInput = {
                    bpmnId: id,
                    panel_data: panelData,
                    data: data,
                    bpmnData: bpmnData,
                    insertId: entryId,
                    tempId: formId,
                    client_id: clientId,
                    formTableName: customFormTable,
                    payload: Object.assign({}, await this.configurePayload(panelData, data)),
                    mailAccount: '',
                    bpmnCreatedOn: createdOn,
                    keywordBucket: []
                };

                let emailCount = 0;
                let emailList: any;
                const panelData1: any = JSON.parse(panelData);
                for (const task of panelData1.taskarr) {
                    if (task.serviceType === 'GMAIL') {
                        if (task.params.selectedEmails.length > 0) {
                            emailCount = task.params.selectedEmails.length;
                            emailList = task.params.selectedEmails;
                        }
                    }
                }

                if (data?.type === 'BPMN_SUBPROCESS_ACTIVITY') {
                    let keywordBucket = await Container.get(DataSource).getRepository('KeywordBucket').find();
                    executeWorkFlowInput.keywordBucket = keywordBucket;
                    emailCount = 0;
                }

                console.log('emailCount', emailCount);

                if (emailCount > 0) {
                    let keywordBucket = await Container.get(DataSource).getRepository('KeywordBucket').find();
                    executeWorkFlowInput.keywordBucket = keywordBucket;

                    for (const mail of emailList) {
                        executeWorkFlowInput.mailAccount = mail;
                        console.log("Mail List loop :: Mail :: ", mail);
                        await this.executeWorkFlow(executeWorkFlowInput);
                    }
                } else if (panelData1.enableMultipleStart && panelData1.multipleValueField && lodash.isArray(data?.submittedData?.[panelData1.multipleValueField])) {
                    for (const multiValueData of data?.submittedData?.[panelData1.multipleValueField]) {
                        data.submittedData.row = multiValueData;
                        const executeInput = {
                            bpmnId: id,
                            panel_data: panelData,
                            data: data,
                            bpmnData: bpmnData,
                            insertId: entryId,
                            tempId: formId,
                            client_id: clientId,
                            formTableName: customFormTable,
                            payload: await this.configurePayload(panelData, data),
                            mailAccount: '',
                            bpmnCreatedOn: createdOn,
                            keywordBucket: []
                        };
                        await this.executeWorkFlow(executeInput);
                    }
                } else {
                    const executionResult = await this.executeWorkFlow(executeWorkFlowInput);
                    console.log("Execution Result :: ", executionResult);
                    return executionResult
                }
            }
        }
    }
}

  // private async createSubProcessAndExecuteWorkFlow(data:any,executeWorkFlowInput: any) {
  //   try{
  //   let subProcessData = [];
  //   data.forEach(element => {
  //       let subprocess = new BusinessProcessModelingSubProcess();
  //       subprocess.bpmn= executeWorkFlowInput.bpmnId;
  //       subprocess.processData= element;
  //       subprocess.status= "PENDING";
  //       subprocess.isDeleted= 0;
  //       subProcessData.push(subprocess);
  //   });
   
  //   await this.processBuilderService.createSubProcess(subProcessData);
  //   let subprocesses = await this.processBuilderService.getAllSubProcess(executeWorkFlowInput.bpmnId,"PENDING");
  //     for(let subprocess of subprocesses) {
  //       executeWorkFlowInput.mailAccount = subprocess.processData;
  //       await this.executeWorkFlow(executeWorkFlowInput);
  //       await this.processBuilderService.updateSubProcessStatus(subprocess.id,"COMPLETED");
  //     };
  //   } catch (error) {
  //     console.log("ProcessBuilderHelper -> createSubProcessAndExecuteWorkFlow -> error", error)
  //   }
  // }

  private async getWorkflow(data: any, formId: string, directBpmnType: ProcessDataType[]) {
    console.log("Inside getWorkflow :: directBpmnType :: ", directBpmnType);
    let workflow: string | any[] = [];

    let bpmnOptions = {};
    if (data.bpmnid && !formId && directBpmnType.includes(data.type)) {
      bpmnOptions = { id: data.bpmnid, followAfter: 0 };
    }
    else if (data.bpmnid && formId) {
      bpmnOptions = { id: data.bpmnid, followAfter: 0, status: 1 };
    } else {
      bpmnOptions = { formId: formId, followAfter: 0, status: 1 };
    }
    const bpmnResult: BusinessProcessModeling[] = await this.processBuilderService.getMultipleBpmn(bpmnOptions);
    if (bpmnResult.length > 0) {
      workflow = bpmnResult;
    }
    return workflow;
  }

  async configurePayload(panel_data: any, data: any) {
    try {
      panel_data = JSON.parse(panel_data);
      // console.log('data.submittedData', data.submittedData);
      if (panel_data.apiInput.length) {
        panel_data.payload.apiInput = panel_data.apiInput;  
      }
      
      if (data.submittedData) {
        // data.submittedData = JSON.parse(data.submittedData);
        // const submittedData = JSON.parse(data.submittedData);
        // Iterate over the keys in obj2.submittedData
        for (const key in data.submittedData) {
          // Check if the key exists in obj1's submittedData
          if (panel_data.payload.submittedData.hasOwnProperty(key)) {
            // Assign value from obj2 to obj1
            panel_data.payload.submittedData[key] = data.submittedData[key];
          } else if (data.submittedData.hasOwnProperty('row')) {
            panel_data.payload.submittedData['row'] = data.submittedData.row;
          }
        }
      } else if (data) {
        panel_data.payload.data = data;
      } 
      // console.log("Panel Data :: Payload :: ", panel_data.payload)
      
      return panel_data.payload;
    } catch (error) {
      console.log("ProcessBuilderHelper -> configurePayload -> error", error)
    }
  }

  getValueFromObject(obj, path) {
    // Split the path into an array of keys
    const keys = path.split('.');
  
    // Traverse the object using a loop
    let current = obj;
    for (const key of keys) {
      // Check if the current property exists
      if (current && typeof current === 'object') {
        current = current[key];
      } else {
        // Key not found or invalid path
        return undefined;
      }
    }
  
    // Return the final value
    return current;
  }

  private addOrUpdate(payload, record) {
    // Check if the record already exists
    // console.log("Payload Before AddOrUpdate :: ", JSON.stringify(payload));
    const existingRecordIndex = payload.bucketInfo.matchedBucket.findIndex(item => item.bucketName === record.bucketName);
    // console.log("Existing Record Index :: ", existingRecordIndex)
    if (existingRecordIndex !== -1) {
      // If the record exists, update the matchedKeyword
      payload.bucketInfo.matchedBucket[existingRecordIndex].matchedKeyword += `, ${record.matchedKeyword}`;
    } else {
      // If the record doesn't exist, push it to the array
      payload.bucketInfo.matchedBucket.push(record);
    }
  }
}
