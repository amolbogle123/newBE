import { WidgetAccount } from "../../../../entities";
import { DatabaseType, QueryType } from "../../../../models/enums";
import { ProcessDataType } from "../../models";
import lodash from "lodash";

export class ConfigUtils {
    async setSourceConnector(panelData: any, sourceConnector: any) {
        if (panelData.connectorParams &&
            panelData.connectorParams.sqlAccount &&
            panelData.connectorParams.columnName) {
            if (panelData.connectorParams.sqlTable ||
                panelData.connectorParams.manualQuery) {
                sourceConnector = panelData.connectorParams;
            }
        }
        return sourceConnector;
    }

    async getSourceAndDestinationConfigs(connectors: WidgetAccount[], panelDataObj: any, destinationConfig: any, sourceConnector: any, sourceConfig: any) {
        if (connectors && connectors.length > 0) {
            const destinationAccount = connectors.find(
                (obj) => obj.id === panelDataObj.params.sqlAccount
            );
            destinationConfig =
                destinationAccount && destinationAccount.config
                    ? JSON.parse(destinationAccount.config)
                    : {};
            if (sourceConnector && sourceConnector.sqlAccount) {
                const sourceAccount = connectors.find(
                    (obj) => obj.id === sourceConnector.sqlAccount
                );
                sourceConfig =
                    sourceAccount && sourceAccount.config
                        ? JSON.parse(sourceAccount.config)
                        : {};
            }
        }
        return { destinationConfig, sourceConfig };
    }

    async getSourceData(sourceConfig: any, data: any, sourceConnector: any) {
        let sourceData: any = {};
        if (sourceConfig &&
            sourceConfig.dbType === DatabaseType.MYSQL) {
            if (data &&
                data.type &&
                data.type === ProcessDataType.SQL_CONNECTOR) {
                if (data.queryData &&
                    data.queryData[sourceConnector.columnName]) {
                    sourceData = data.queryData;
                }
            }
        }
        return sourceData;
    }

    async getSourceQuery(sourceConnector: any, insertId: string) {
        let sourceQry: string = "";
        if (sourceConnector.isManualQuery &&
            sourceConnector.manualQuery) {
            sourceQry = sourceConnector.manualQuery;
        } else {
            sourceQry = `SELECT * FROM ${sourceConnector.sqlTable} WHERE ${sourceConnector.columnName} = '${insertId}' LIMIT 1`;
        }
        return sourceQry;
    }

    async updateSQLDataSet(panel_data: any, panelDataObj: any, sourceData: any, data: any, sqlDataSet: any, payload: any) {
        if (Array.isArray(panelDataObj.params.sqlFields) &&
            panelDataObj.params.sqlFields.length > 0) {
            for (const fieldValue of panelDataObj.params.sqlFields) {
                let formValue = "";
                if (fieldValue.formField === "V_OTHER_DATA" &&
                    fieldValue.otherValue) {
                    formValue = fieldValue.otherValue;
                } else if (sourceData &&
                    sourceData[fieldValue.formField]) {
                    formValue = sourceData[fieldValue.formField];
                } else if (data && data[fieldValue.formField]) {
                    formValue = data[fieldValue.formField];
                } else if (fieldValue.formField === "V_PAYLOAD_DATA" &&
                    fieldValue.payloadKey) {
                    const payloadKey = fieldValue.payloadKey.split(".");
                    if (payloadKey.length > 1) {
                        if (payloadKey[0] === "submittedData") {
                            formValue = payload['submittedData'][payloadKey[1]];
                        }
                    } else {
                        formValue = payload[fieldValue.payloadKey];
                    }
                } else if (data && data.submittedData) {
                    const submittedData = data.submittedData;
                    if (submittedData[fieldValue.formField]) {
                        formValue = submittedData[fieldValue.formField];
                    }
                }
                sqlDataSet[fieldValue.columnName] = formValue;
            }
        }
    }

    async getWhereCond(panelDataObj: any, whereCond: string, sourceData: any, data: any, destinationConfig: any, mssqlWhere: any[]) {
        if (Array.isArray(panelDataObj.params.whereFields) &&
            panelDataObj.params.whereFields.length > 0) {
            whereCond = "1";
            for (const whereValue of panelDataObj.params.whereFields) {
                let formValue = this.getFormValueForWhereCond(whereValue, sourceData, data);
                if (formValue) {
                    if (destinationConfig.dbType === DatabaseType.MSSQL) {
                        mssqlWhere.push(
                            `[${whereValue.columnName}] = '${formValue}'`
                        );
                    }
                    if (lodash.toLower(destinationConfig.dbType) === lodash.toLower(DatabaseType.MYSQL)) {
                        whereCond +=
                            " AND `" +
                            whereValue.columnName +
                            "` = '" +
                            formValue +
                            "'";
                    }
                }
            }
        }
        return whereCond;
    }

    private getFormValueForWhereCond(whereValue: any, sourceData: any, data: any) {
        let formValue = "";
        if (whereValue.formField === "V_OTHER_DATA" &&
            whereValue.otherValue) {
            formValue = whereValue.otherValue;
        } else if (sourceData &&
            sourceData[whereValue.formField]) {
            formValue = sourceData[whereValue.formField];
        } else if (data && data[whereValue.formField]) {
            formValue = data[whereValue.formField];
        }
        return formValue;
    }

    async getDestinationQuery(panelDataObj: any, destinationConfig: any, sqlDataSet: any, mssqlWhere: any[], whereCond: string) {
        let destinationQuery = "";
        const tableName: string = panelDataObj.params.sqlTable;

        if (destinationConfig.dbType === DatabaseType.MSSQL) {
            if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.INSERT &&
                Object.keys(sqlDataSet).length > 0) {
                const fieldNames = Object.keys(sqlDataSet).join(",");
                const fieldValues = Object.values(sqlDataSet).join(",");
                destinationQuery = `${QueryType.INSERT} INTO [${tableName}] (${fieldNames}) VALUES (${fieldValues})`;
            } else if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.UPDATE &&
                sqlDataSet.length > 0 &&
                mssqlWhere.length > 0) {
                destinationQuery = `${QueryType.UPDATE} [${tableName}] SET ${sqlDataSet.join(
                    ","
                )} WHERE ${mssqlWhere.join(" AND ")}`;
            } else if (panelDataObj.params.dbQuery === QueryType.DELETE) {
                destinationQuery = `${QueryType.DELETE} FROM [${tableName}] WHERE ${mssqlWhere.join(
                    " AND "
                )}`;
            }
        } else if (lodash.toLower(destinationConfig.dbType) === lodash.toLower(DatabaseType.MYSQL)) {
            const setQueryBuild = Object.keys(sqlDataSet).map(
                (key) => `${key} = '${sqlDataSet[key]}'`
            );

            if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.INSERT) {
                destinationQuery = `${QueryType.INSERT} ${tableName} SET ${setQueryBuild}`;
                if (panelDataObj.params.payloadConfiguration && panelDataObj.params.payloadConfiguration.type === 'LAST_INSERT_OBJECT') {
                    destinationQuery += `; SELECT * FROM ${tableName} WHERE Id=(SELECT LAST_INSERT_ID());`;
                }
            } else if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.UPDATE &&
                whereCond) {
                destinationQuery =
                    `${QueryType.UPDATE} ${tableName} SET ${setQueryBuild} WHERE ` +
                    whereCond;
            } else if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.DELETE &&
                whereCond) {
                destinationQuery =
                    `${QueryType.DELETE} FROM ${tableName} WHERE ` +
                    whereCond;
            }
        }
        return destinationQuery;
    }
    replaceObjectValues(str, obj) {
      const regex = /@(\w+(\.\w+)*)*/g;
      return str.replace(regex, (match, group) => {
        const path = group.split('.');
        let value = obj;
        path.forEach(key => {
          value = value[key];
        });
        return value;
      });
    }
    getValueFromObject(obj, path) {
      // Split the path into an array of keys
      const keys = path.split('.');
    
      // Traverse the object using a loop
      let current = obj;
      for (const key of keys) {
        // Check if the current property exists
        if (current && typeof current === 'object') {
          current = current[key];
        } else {
          // Key not found or invalid path
          return undefined;
        }
      }
    
      // Return the final value
      return current;
    }
    calculateUsingString(inputString) {
      // Extract the operation and operands
      const match = inputString.match(/^([A-Z]+)\(([0-9]+)\s*([+-])\s*([0-9]+)\)$/);
      if (!match) {
        throw new Error('Invalid expression format');
      }
    
      const [, operation, num1, operator, num2] = match;
    
      // Perform the calculation
      switch (operation) {
        case 'SUBT':
          return Number(num1) - Number(num2);
        case 'SUM':
          return Number(num1) + Number(num2);
        default:
          throw new Error('Unsupported operation');
      }
    }
}