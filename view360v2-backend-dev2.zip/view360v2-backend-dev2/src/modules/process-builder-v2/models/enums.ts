export enum ApiMethod {
    POST = "POST",
    PUT = "PUT",
    GET = "GET",
    DELETE = "DELETE"
}

export enum TaskServiceType {
    FORM = 'FORM',
    EXECUTE_SQL = 'EXECUTE_SQL',
    API_CONNECT = 'API_CONNECT',
    CONNECTOR = 'CONNECTOR',
    MYSQL = 'MYSQL',
    ANOTHER_PROCESS = 'ANOTHER_PROCESS',
    GMAIL = 'GMAIL',
    EMAIL_NOTIFICATION = 'EMAIL_NOTIFICATION',
    OPEN_AI = 'OPEN_AI',
}

export enum ProcessDataType {
    SQL_CONNECTOR = 'SQL_CONNECTOR',
    FROM_ANOTHER_PROCESS = 'FROM_ANOTHER_PROCESS',
    PULSE_THRESHOLD = 'PULSE_THRESHOLD',
    CAMPAIGN = 'CAMPAIGN',
    MANUAL_TRIGGER = 'MANUAL_TRIGGER',
    BPMN_CRON = 'BPMN_CRON',
    FROM_BPMN_CRON = 'FROM_BPMN_CRON',
    CUSTOM_EVENT = 'CUSTOM_EVENT',
}

export enum ProcessCheckOn {
    TEXT_VALUE = 'textvalue',
    CUSTOM_FIELD = 'customField',
    SELECTED_USER = 'selectedUser',
    SELECTED_ROLE = 'selectedRole',
    CAMPAIGN_USERS = 'campaignUsers',
    FORM_FIELD = 'formfield',
    ASSIGNED_USER = 'assignedUser',
    SELECTED_TEAM_ROLE = 'selectedTeamRole',
}

export enum ProcessAssignee {
    ASSIGNED_USER = 'assigneduser',
    USER = 'user',
    ROLE = 'role',
    USER_MANAGER = 'userManager',
    FORM_FIELD = 'formField',
}

export enum OnRejectStatus {
    SEND_TO_ACTION = 'sendtoaction',
    MARK_REJECTED = 'markasreject'
}

export enum ProcessStatus {
    REJECT = 'reject',
    MARK_COMPLETE = 'markcomplete',
    PROCESS_COMPLETE = 'processcomplete',
    TIMER_BASED = 'timerbased',
    FORM_SUBMIT = 'formsubmit',
    MANUAL_TRIGGER = 'manualtrigger',
    CUSTOM_EVENT = 'customevent',
    CAMPAIGN = 'campaign',
    USER_ASSIGNED = 'userAssigned',
    APPROVE = 'approve'
}

export enum PanelDataTask {
    COMPLETE__INITIATION = 'completeinitiation',
    APPROVED_INITIATION = 'approvedinitiation',
    ASSIGN = 'assign',
    DRAFT_INITIATION = 'draftinitiation',
    START_INITIATION = 'startinitiation',
    APPROVAL = 'approval',
    RECEIVE_TASK_NOTIFY = 'receive-task-notify',
    SEND_FOR_REVIEW = 'sendForReview',
}
