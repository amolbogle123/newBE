import {ProcessStatus} from "./enums";

export class StatusProcess {

    public submittedBy: string;
    public tempId: string;
    public entryId: string;
    public bpmnId: string;
    public id: string;
    public status: ProcessStatus;
    public reject: any;

    constructor(submittedBy: string, tempId: string, entryId: string, bpmnId: string, id: string, status: ProcessStatus, reject: any) {
        this.submittedBy = submittedBy;
        this.tempId = tempId;
        this.entryId = entryId;
        this.bpmnId = bpmnId;
        this.id = id;
        this.status = status;
        this.reject = reject;
    }
}

export interface IStatusProcess extends StatusProcess {
}
