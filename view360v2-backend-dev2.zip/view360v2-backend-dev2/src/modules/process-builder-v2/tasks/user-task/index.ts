import { ProcessBuilderService } from "../../services/process-builder.service";
import * as txt from '../../utils/constants/api.constant';
import lodash from "lodash";
import { PanelDataTask, ProcessAssignee } from "../../models";
import { BusinessProcessModelingExecute, CustomForms, MailTemplate, Users } from "../../../../entities";
import { In, DataSource } from "typeorm";
import { CommunicationHelper } from "../../../../utils/helpers/communication.helper";
import { BpmnNotificationHelper } from "../../utils/helpers/bpmn-notification.helper";
import { ProcessBuilderHelper } from "../../utils/helpers/process-builder.helper";
import { FormBuilderService } from "../../../form-builder/services/form-builder.service";
import Container from 'typedi';
import { FormBuilder } from "../../../../entities/create-form-builder";

export class UserTask {


  // Services
  private processBuilderService: ProcessBuilderService = new ProcessBuilderService();
  private formBuilderService: FormBuilderService = new FormBuilderService();

  // Helpers
  private executeProcessBuilder = (): Function => new ProcessBuilderHelper().execute;
  private communicationHelper: CommunicationHelper = new CommunicationHelper();
  private bpmnNotificationHelper: BpmnNotificationHelper = new BpmnNotificationHelper();

  async executeTask(task: any, engine) {
    // console.log("task---->>>>task", task);
    if (task.panelData.executedActivities.includes(task.api.id)) {
      task.api.signal(txt.ALREADY_EXECUTED);
      return;
    }
    const criteria: any = { activityId: task.api.id, entryId: task.entryId, formId: task.formId }
    const bpmnExecResult: any[] = await this.processBuilderService.getBpmnExecute(criteria);

    const results: CustomForms[] = await this.formBuilderService
      .getCustomForms({ clientId: task.client_id, id: task.formId }, ["referenceId"]);

    if (!lodash.isEmpty(bpmnExecResult) && bpmnExecResult.length > 0 && task.panelData.sendToActivity != task.api.id) {
      await this.processBPMNExecResult(bpmnExecResult, task, results);
    } else {

      let panelData: any = await this.saveOrUpdateBpmnExecute(task);
      if ([PanelDataTask.ASSIGN, PanelDataTask.DRAFT_INITIATION, PanelDataTask.START_INITIATION, PanelDataTask.SEND_FOR_REVIEW, PanelDataTask.APPROVAL].indexOf(panelData.task) > -1) {
        await this.bpmnNotificationHelper.execute(task.formId, task.entryId, panelData.params, panelData.task, task.client_id, task?.data?.createdBy);
      } else {
        // Nothing will be execute here... (code commented in old source code)
      }

      const assigneeList: ProcessAssignee[] = [
        ProcessAssignee.USER,
        ProcessAssignee.ASSIGNED_USER,
        ProcessAssignee.USER_MANAGER,
        ProcessAssignee.FORM_FIELD
      ];
      let users: Users[] = await this.getUsersAsPerProcessAssignee(panelData, assigneeList);

      if (panelData.params.mailtemplate) {
        let [mailTemplate] = await Container.get(DataSource).getRepository(MailTemplate)
          .find({ where: { id: panelData.params.mailtemplate }, select: ['subject', 'body'] });

        if (!mailTemplate || lodash.isEmpty(mailTemplate)) {
          console.error("No Mail Template Found on BPMN Receive Task.");
          return;
        }

        await this.sendEmailToUsers(users, mailTemplate, task, panelData);
      }

      await this.sendSMSToUsers(panelData, users);

      await this.proceedTowardTaskCompletion(panelData, task, engine);
    }
  }

  private async proceedTowardTaskCompletion(panelData: any, task: any, engine: any) {
    // console.log('proceedTowardTaskCompletion', panelData.task);
    if (panelData.task == PanelDataTask.APPROVED_INITIATION) {
      setTimeout(() => {
        this.executeProcessBuilder()(task.formId, task.entryId, null);
      }, 1000);
    }

    if (panelData.task === PanelDataTask.APPROVAL ||
      panelData.task == PanelDataTask.ASSIGN ||
      panelData.task === PanelDataTask.SEND_FOR_REVIEW) {
      engine.stop();
    }
    task.api.signal(`User Task completed.`);
  }

  private async saveOrUpdateBpmnExecute(task: any) {
    let panelData: any = task.panelData.taskarr.find((x: any) => {
      return x.id == task.api.id;
    });
    task.panelData.executedActivities.push(task.api.id);

    let status = 0;
    status = await this.processAsPerPanelDataTask(panelData, status, task);
    // console.log('panelData.params.assignee', panelData.params.assignee);

    let assignedUserId = 0;
    if (panelData.params.assignee) {
      assignedUserId = panelData.params.assignee[0];
    }
    let assignedRoleId = 0;
    if (panelData.params.assigneerole) {
      assignedRoleId = panelData.params.assigneerole[0];
    }

    const executeInsertData = {
      stage: task.panelData.process.name,
      bpmn: { id: task.bpmnId },
      entryId: task.entryId,
      formId: task.formId,
      activityId: task.api.id,
      status,
      panelData: JSON.stringify(panelData),
      taskName: panelData.task,
      assignedUserId,
      assignedRoleId,
      // submittedBy: task.data.createdBy
    } as unknown as BusinessProcessModelingExecute;

    let newEntry = await this.processBuilderService.saveOrUpdateBpmnExecute(executeInsertData);
    console.log('--------newEntry-------------------newEntry', newEntry);
    // notify by mail,notification and sms-------------------------------
    console.log('->>>>>>>>>>>>>>panelData', JSON.stringify(panelData, null, 2));
    return panelData;
  }

  private async processAsPerPanelDataTask(panelData: any, status: number, task: any) {
    if ([PanelDataTask.APPROVED_INITIATION, PanelDataTask.COMPLETE__INITIATION].includes(panelData.task)) {
      status = 1;
    }

    // check if is assigned and change panelData user accordingly---
    // -------------------------------------------------------------
    if (panelData.task == PanelDataTask.ASSIGN && panelData.params.assignto == ProcessAssignee.ASSIGNED_USER) {
      await this.runCustomizedQuery(task, panelData);
    }
    if (panelData.task === PanelDataTask.ASSIGN && panelData.params.assignto === ProcessAssignee.USER_MANAGER) {
      await this.getMultipleUser_userManager(task, panelData);
    }
    if (panelData.task === PanelDataTask.ASSIGN && panelData.params.assignto === ProcessAssignee.FORM_FIELD) {
      await this.getMultipleUser_formField(task, panelData);
    }
    if (panelData.task === PanelDataTask.APPROVAL && panelData.params.assignto === ProcessAssignee.FORM_FIELD) {
      await this.getMultipleUser_formField(task, panelData);
    }
    if (panelData.task === PanelDataTask.SEND_FOR_REVIEW && panelData.params.assignto === ProcessAssignee.FORM_FIELD) {
      await this.sendForReview_FormField(task, panelData);
    }
    if (panelData.task === PanelDataTask.SEND_FOR_REVIEW && panelData.params.assignto === ProcessAssignee.USER_MANAGER) {
      await this.sendForReview_userManager(task, panelData);
    }
    return status;
  }

  private async processBPMNExecResult(bpmnExecResult: any[], task: any, results: CustomForms[]) {
    const pastdetails = bpmnExecResult[0];

    if (pastdetails.status == 1) {
      let pdata = task.panelData.taskarr.find(x => { return x.id == task.api.id; });
      console.log("User Input is done ! Status is 1");
      if (Array.isArray(pdata.params.updateFormFields) && pdata.params.updateFormFields.length > 0) {
        await this.getAndUpdateFormBuilderSubmittedData(task, results, pdata);
      }
      task.api.signal('User Input is done ! Status is 1');
    } else if (pastdetails.isRejected == 1) {
      console.log("User Input is done ! Status is REJECTED");
      task.api.signal('User Input is done ! Status is REJECTED');
    } else {
      console.log("Waiting for user input...");
      task.api.signal(`Waiting for user input`);
    }
  }

  private async getAndUpdateFormBuilderSubmittedData(task: any, results: CustomForms[], pdata: any) {
    const whereClause: any = { id: task.entryId };

    const formBuilderRes: FormBuilder = await this.formBuilderService
      .getFormBuilder(task.client_id, results[0].referenceId, whereClause, ['submittedData']);
    if (!lodash.isEmpty(formBuilderRes)) {
      let submittedData = {};
      if (formBuilderRes.submittedData) {
        submittedData = JSON.parse(formBuilderRes.submittedData);
      }

      for (const fieldValue of pdata.params.updateFormFields) {
        if (fieldValue.formField === 'STATUS') {
          submittedData['STATUS'] = fieldValue.updateValue;
        } else if (fieldValue.formField) {
          submittedData[fieldValue.formField] = fieldValue.updateValue;
        }
      }

      const dataPayload = {
        submittedData: JSON.stringify(submittedData),
      };
      await this.formBuilderService.updateFormBuilder(task.client_id, results[0].referenceId, whereClause, dataPayload);
    }
  }

  private async getUsersAsPerProcessAssignee(panelData: any, assigneeList: ProcessAssignee[]) {
    let conditionsForGetMultipleUser: any = {};
    console.log('panelData.params.assignto', panelData.params.assignto, assigneeList.includes(panelData.params.assignto));
    console.log('panelData.params.assignee', panelData.params.assignee);
    if (panelData.params.assignto == ProcessAssignee.ROLE) {
      conditionsForGetMultipleUser.roleId = In(panelData.params.assigneerole[0]);
    } else if (assigneeList.includes(panelData.params.assignto)) {
      conditionsForGetMultipleUser.id = panelData.params.assignee[0].id ? panelData.params.assignee[0].id : panelData.params.assignee[0];
    }
    console.log('conditionsForGetMultipleUser', conditionsForGetMultipleUser);
    return this.processBuilderService.getMultipleUser(conditionsForGetMultipleUser, ['email', 'username', 'mobile']);
  }

  private async sendSMSToUsers(panelData: any, users: Users[]) {
    if (panelData.params.enablesms &&
      [ProcessAssignee.USER, ProcessAssignee.ASSIGNED_USER].includes(panelData.params.assignto)) {
      if (users && !lodash.isEmpty(users)) {
        for (let user of users) {
          let params = {
            message: `Hi ${user.username}, You have a New Job to Review !`,
            from: null,
            to: user.mobile
          };
          await this.communicationHelper.sendSms(params);
        }
      }
    }
  }

  private async sendEmailToUsers(users: Users[], mailTemplate: MailTemplate, task: any, panelData: any) {
    if (users && !lodash.isEmpty(users)) {
      for (let user of users) {
        let mailParams = {
          subject: mailTemplate.subject,
          body: mailTemplate.body,
          to: user.email,
          name: user.username,
          tempId: task.formId,
          insertId: task.entryId,
          panelDataParam: panelData.params,
          task: panelData.task,
          client_id: task.client_id
        };
        await this.communicationHelper.sendEmail(mailParams);
      }
    }
  }

  private async sendForReview_userManager(task: any, panelData: any) {
    if (task?.data?.createdBy) {
      const userDetail = await Container.get(DataSource).getRepository(Users).find({ where: { id: task.data.createdBy }, select: ['userManager'] });
      if (userDetail?.length) {
        panelData.params['assignee'] = [userDetail[0].userManager];
      }
    }
  }

  private async sendForReview_FormField(task: any, panelData: any) {
    if (task.data && task.data.submittedData) {
      const entryData = JSON.parse(task.data.submittedData);
      let id = entryData[panelData.params.assignee] || null;
      if (panelData.params.assignee === 'CREATEDBY') {
        id = task.data.createdBy || null;
      }
      if (id) {
        const userDetail = await Container.get(DataSource).getRepository(Users).find({ where: { id }, select: ['id'] });
        if (userDetail?.length) {
          panelData.params['assignee'] = [userDetail[0].id];
        }
      }
    }
  }

  private async getMultipleUser_formField(task: any, panelData: any) {
    if (task.data && task.data.submittedData) {
      const entryData = task.data.submittedData;
      if (!lodash.isEmpty(entryData[panelData.params.assignee])) {
        let criteriaForGetMultipleUser: any = { id: entryData[panelData.params.assignee] };
        if (entryData[panelData.params.assignee].includes('@')) {
          criteriaForGetMultipleUser = { email: entryData[panelData.params.assignee] };
        }
        const fields = ['id', 'roleId', 'firstName', 'lastName', 'email', 'username', 'isSuperAdmin', 'clientId'];
        let userDetail = await this.processBuilderService.getMultipleUser(criteriaForGetMultipleUser, fields);

        if (userDetail && userDetail.length > 0) {
          panelData.params['assignee'] = [userDetail[0].id];
        }
      } else if (!lodash.isEmpty(entryData[panelData.params.assigneeField])) {
        let criteriaForGetMultipleUser: any = { id: entryData[panelData.params.assigneeField] };
        if (entryData[panelData.params.assigneeField].includes('@')) {
          criteriaForGetMultipleUser = { email: entryData[panelData.params.assigneeField] };
        }
        const fields = ['id', 'roleId', 'firstName', 'lastName', 'email', 'username', 'isSuperAdmin', 'clientId'];
        let userDetail = await this.processBuilderService.getMultipleUser(criteriaForGetMultipleUser, fields);

        if (userDetail && userDetail.length > 0) {
          panelData.params['assignee'] = [userDetail[0].id];
        }
      }
    }
  }

  private async getMultipleUser_userManager(task: any, panelData: any) {
    let userData = await this.processBuilderService.getMultipleUser({ id: task.data.CREATEDBY });
    if (userData && userData.length > 0) {
      panelData.params['assignee'] = [userData[0].userManager];
    }
  }

  private async runCustomizedQuery(task: any, panelData: any) {
    const customizedQuery: string = `SELECT ASSIGN_TO FROM ${task.formTableName} where ID = ?`;
    let isAssigned: any[] = await this.processBuilderService.runCustomizedQuery(customizedQuery, [task.entryId]);
    if (isAssigned && isAssigned.length > 0) {
      panelData.params['assignee'] = [isAssigned[0].ASSIGN_TO];
    }
  }
}