import { dataSource } from "core/data-source";
import {PublicTables, WidgetAccount} from "../../../../../entities";
import { ConfigUtils } from "../../../utils/helpers/config-utils";
import {DataSource, In} from "typeorm";
import { SetResponse } from "../../../../../utils/helpers/common.helper";
import { ConnectorHelper } from "../../../../../utils/helpers/connector.helper";
import lodash from "lodash";
import { StatusType } from "../../../../../models/enums";
import Container from "typedi";
import * as uuid from 'uuid';

export class MySQLService {
    constructor() {
    }
    async mysqlServiceTaskExecute(panelData, panelDataObj, data, insertId, payload) {
        const mySqlServiceTaskData = this.getMYSQLServiceData(panelData);
        if(mySqlServiceTaskData.isNewTable === 'Yes') {
            const tablePrefix = 'BP_';
            const tableName = tablePrefix + mySqlServiceTaskData.mySqlData.params.tableName;
            const columnsMapping:any = mySqlServiceTaskData.mySqlData.params.addNewsqlFields;
            const columnList = columnsMapping.map(item => item.columnName);
            const columnNameAndDataType = columnsMapping.map(({ columnName, dataType }) => ({ columnName, dataType }));
            const result: any = await this.createNewTable(tableName, dataSource, columnList, columnNameAndDataType);
            const emailData: any = await this.prepareData(columnsMapping,payload,panelData.client_id,panelData.bpmnId );
            if(result.status || result.errno === 1050) {
              if (Array.isArray(payload?.mailData?.matchedBuckets) && payload?.mailData?.matchedBuckets?.length && data?.type === 'BPMN_SUBPROCESS_ACTIVITY') {
                for (const matchedBucketInfo of payload.mailData.matchedBuckets) {
                  if (!emailData?.length) {
                    break;
                  }
                  emailData[0].matchedKeyword = matchedBucketInfo.matchedKeywords;
                  emailData[0].bucketId = matchedBucketInfo.bucketId;
                  emailData[0].bucketName = matchedBucketInfo.bucketName;
                  emailData[0].ID = uuid.v4();
                  await this.insertDataToTable(tableName,dataSource,columnList, emailData);
                }
              } else {
                await this.insertDataToTable(tableName,dataSource,columnList,emailData);
              }
            }
            if(result.status) {
                await this.insertTableEntryInPublicTables(tableName,dataSource,panelData.client_id);
            }
        } else if(mySqlServiceTaskData.isNewTable === 'No') {
            const tableName = mySqlServiceTaskData.mySqlData.params.sqlTable;
            const columnsMapping:any = mySqlServiceTaskData.mySqlData.params.sqlFields;
            const columnList = columnsMapping.map(item => item.columnName);
            const emailData = await this.prepareData(columnsMapping,payload,panelData.client_id,panelData.bpmnId );
            await this.insertDataToTable(tableName,dataSource,columnList,emailData);
        } else {
            let sourceConnector: any = {};
            if (panelData.manualSQLConnector) {
                sourceConnector = new ConfigUtils().setSourceConnector(panelData, sourceConnector);
            }
            if (panelDataObj.params &&
                panelDataObj.params.sqlAccount &&
                panelDataObj.params.sqlTable &&
                panelDataObj.params.dbQuery) {
                const listOfIds: any[] = [panelDataObj.params.sqlAccount];
                if (sourceConnector && sourceConnector.sqlAccount) {
                    listOfIds.push(sourceConnector.sqlAccount);
                }
                const connectors = await dataSource
                    .getRepository(WidgetAccount)
                    .find({
                        where: { id: In(listOfIds) },
                        select: ["id", "config"],
                    });

                let destinationConfig = null;
                let sourceConfig = null;
                ({ destinationConfig, sourceConfig } = await new ConfigUtils().getSourceAndDestinationConfigs(connectors, panelDataObj, destinationConfig, sourceConnector, sourceConfig));

                let sourceData: any = new ConfigUtils().getSourceData(sourceConfig, data, sourceConnector);

                let sourceQry: string = await new ConfigUtils().getSourceQuery(sourceConnector, insertId);

                const connectorHelperResponse: SetResponse = await ConnectorHelper.connect(
                    null,
                    sourceQry,
                    destinationConfig
                );

                if (connectorHelperResponse.status === StatusType.SUCCESS &&
                    !lodash.isEmpty(connectorHelperResponse.data)) {
                    sourceData = connectorHelperResponse.data[0];
                }
                let sqlDataSet: any = {};

                await new ConfigUtils().updateSQLDataSet(panelData, panelDataObj, sourceData, data, sqlDataSet, payload);
                let whereCond = "";
                let mssqlWhere = [];

                whereCond = await new ConfigUtils().getWhereCond(panelDataObj, whereCond, sourceData, data, destinationConfig, mssqlWhere);
                let destinationQuery = await new ConfigUtils().getDestinationQuery(panelDataObj, destinationConfig, sqlDataSet, mssqlWhere, whereCond);
                if (!lodash.isEmpty(destinationQuery)) {
                    const dataResponse = await ConnectorHelper.connect(
                        null,
                        destinationQuery,
                        destinationConfig
                    );
                    if (panelDataObj.params.payloadConfiguration) {
                        if (panelDataObj.params.payloadConfiguration.type === 'LAST_INSERT_OBJECT') {
                            payload[panelDataObj.params.payloadConfiguration.variableName] = JSON.stringify(dataResponse.data[1][0]);
                        }
                        if (panelDataObj.params.payloadConfiguration.type === 'LAST_INSERT_ID') {
                            payload[panelDataObj.params.payloadConfiguration.variableName] = dataResponse.data.insertId;
                        }
                    }
                }
            }
        }

    }

    public getMYSQLServiceData(panelData) {
        const mySqlData = panelData.taskarr.find(item => item.serviceType === 'MYSQL');
        const isNewTable = mySqlData.params.isNewTable;
        const dbQuery = mySqlData.params.dbQuery;
        // let tableName;
        // if(mySqlData.params.isNewTable === 'Yes') {
        //     tableName = 'BPMNPT_' + mySqlData.params.tableName;
        // } else {
        //     tableName = mySqlData.params.publicTableName;
        // }
        return {isNewTable, dbQuery, mySqlData}
    }

    public getEmailsData(panelData) {
        const mySqlData = panelData.taskarr.find(item => item.serviceType === 'GMAIL');
        return mySqlData.params.emailList;
    }

    async prepareData(columnMapperList,payload,client_id,bpmnId) {
        const emailDataList = [];
        if(Array.isArray(payload)) {
            for (let emailData of payload) {
                emailDataList.push({CLIENT_ID: client_id,BPMN_ID: bpmnId,BUCKET_ID: '123' ,values:emailData})
            }
        } else {
            let data = {};
            columnMapperList.map(mapping => {
                const keys = mapping.payloadKey.split('.');
                const dataType = mapping.dataType;
                let value = payload;
                for (const key of keys) {
                    value = value[key];
                }
                if(dataType === 'timestamp') {
                   value = this.convertToTimestamp(value);
                   data[mapping.columnName] = value;
                } else if(dataType === 'number') {
                    value = this.convertToNumber(value);
                    data[mapping.columnName] = value;
                } else {
                    data[mapping.columnName] = value;
                }
            });
            data['ID'] = await this.GetUUID();
            emailDataList.push(data);
        }

        return emailDataList;
    }

    convertToTimestamp(value) {
        if (!value) {
          return null;
        }
        const dateString = value;
        const dateObject = new Date(dateString);
        return dateObject.toISOString().slice(0, 19).replace('T', ' ');
    }

    convertToNumber(value) {
        // Use parseFloat for floating-point numbers
        const floatValue = parseFloat(value);
        // Use parseInt for integers
        const intValue = parseInt(value, 10); // The second argument specifies the radix (base), which is 10 for decimal numbers

        // Check if the parsed values are not NaN (Not a Number)
        if (!isNaN(floatValue) && !isNaN(intValue)) {
            // Return the parsed value based on the presence of a decimal point
            return Number.isInteger(floatValue) ? intValue : floatValue;
        } else {
            // Return NaN if the input string cannot be parsed as a number
            return NaN;
        }
    }

    async createNewTable(tableName, AppDataSource, columnList, columnNameAndDataType) {
        const response = {status: false, message: '', errno: ''};
        return new Promise(async (resolve, reject) => {
            // Get the existing connection
            const connection = AppDataSource.manager.connection;

            // Create a new query runner
            const queryRunner = connection.createQueryRunner();
            try {
                // Connect to the database
                await queryRunner.connect();

                // Start a new transaction
                await queryRunner.startTransaction();

                /*
                 *let columnsString = columnList.map(column => `\`${column}\` text`).join(', ');
                 */
                const preparedColumnData = columnNameAndDataType.map(({ columnName, dataType }) => {
                  if (dataType === 'timestamp') {
                    dataType = `TIMESTAMP NULL DEFAULT NULL`
                  }
                  return `\`${columnName}\` ${dataType}`
                }).join(', ');
                /**
                 * let createTableQuery = `CREATE TABLE \`${tableName}\` (\`id\` INT AUTO_INCREMENT NOT NULL,\`CREATED_ON\` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),${preparedColumnData},PRIMARY KEY (\`id\`))`;
                 */
                let createTableQuery = `CREATE TABLE IF NOT EXISTS \`${tableName}\` (\`ID\` CHAR(36) NOT NULL,\`CREATED_ON\` TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),${preparedColumnData},PRIMARY KEY (\`ID\`))`;
                // console.log('createTableQuery', createTableQuery);
                // Run the SQL query to create a new table
                await queryRunner.query(createTableQuery);

                // Commit the transaction
                await queryRunner.commitTransaction();

                response.status = true;
                response.message = 'Table created successfully';
                resolve(response); // Resolve the promise
            } catch (error) {
                // console.log('create table error', error);
                // If there's an error, roll back the transaction
                await queryRunner.rollbackTransaction();
                response.status = false;
                response.message = error.message;
                response.errno = error.errno;
                resolve(response); // Resolve the promise
                //reject(error); // Reject the promise with the error
            } finally {
                // Release the query runner
                await queryRunner.release();
            }
        });
    }

    async insertDataToTable(tableName: string,AppDataSource:DataSource,columnList: any[],dataList: any[]) {
        // Get the existing connection
        const connection = AppDataSource.manager.connection;

        // Create a new query runner
        const queryRunner = connection.createQueryRunner();

        // Connect to the database
        await queryRunner.connect();

        // Start a new transaction
        await queryRunner.startTransaction();

        try {
            if (columnList.indexOf('ID') === -1) {
              columnList.push('ID');
            }
            let columnsString = columnList.map(column => `\`${column}\``).join(', ');
            let insertQueries = dataList.map(row => {
                let valuesString;
                if (Array.isArray(row)) {
                    valuesString = row.map(value => {
                        // Escape single quotes by replacing them with two single quotes
                        let escapedValue = value.replace(/'/g, "''");
                        return `'${escapedValue}'`;
                    }).join(', '); // Wrap values in single quotes for SQL
                } else {
                    valuesString = Object.values(row).map((value:any) => {
                        // Escape single quotes by replacing them with two single quotes
                        //let escapedValue = value.replace(/'/g, "''");
                        if(typeof value === 'object') {
                            const jsonValueStringify = JSON.stringify(value);
                            value = jsonValueStringify.replace(/'/g, '"');
                        }
                        return `'${value?.replace(/'/g, '"')}'`;
                    }).join(', '); // Wrap values in single quotes for SQL
                }
                return `INSERT INTO \`${tableName}\` (${columnsString}) VALUES (${valuesString})`;
            });

            // let insertDataQuery = `
            //     INSERT INTO ${tableName} (${columnsString})
            //     VALUES ${valuesString}
            // `;
            // Run the SQL query to create a new table
            //await queryRunner.query(insertDataQuery);
            for (let query of insertQueries) {
                // Execute each INSERT query
                // console.log('insert query', query);
                await queryRunner.query(query);
            }

            // Commit the transaction
            await queryRunner.commitTransaction();
        } catch (error) {
            // console.log('insert data error', error);
            // If there's an error, roll back the transaction
            await queryRunner.rollbackTransaction();
            throw error;
        } finally {
            // console.log("Data inserted successfully");
            // Release the query runner
            await queryRunner.release();
        }
    }
    private async GetUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0,
                v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    async insertTableEntryInPublicTables(tableName: string,AppDataSource:DataSource,clientId: number) {
        try{
            const public_table = new PublicTables();
            public_table.name = tableName;
            public_table.client_id = clientId;
            public_table.migration_id =  'EmailData';
            await Container.get(DataSource).manager.save(
                public_table
            );
        }
        catch (error) {
            console.log('insert table entry error', error);
        }
    }

}
