import fetch from "node-fetch";

export class OpenAIService {
  payloadList = [];
  async openAIServiceTask(panelData: any, panelDataObj: any, data: any, scope: any, payload: any): Promise<{ status: boolean, stopEngine: boolean }> {
    const response = { status: true, stopEngine: false };
    if (!panelDataObj?.params?.customPrompt) {
      response.stopEngine = true;
      return response;
    }
    
    const replaceCustomPrompt = this.replaceObjectValues(panelDataObj.params.customPrompt, payload);
    const apiPostData = {
      // documentId: userDetails.documentId,
      // modelname: "orca-mini",
      question: replaceCustomPrompt,
      // sessionId: requestBody.sessionId,
      // userId: userDetails.id,
    };
    try {
      const apiFetchResult = await fetch(
        process.env.CHATBOT_API_URL + "ollama/question",
        {
          method: "POST",
          body: JSON.stringify(apiPostData),
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const result = await apiFetchResult.json();
      if (result?.answer && panelDataObj.params.payloadConfiguration) {
        payload[panelDataObj.params.payloadConfiguration.variableName] = result.answer;
        this.payloadList.push(payload[panelDataObj.params.payloadConfiguration.variableName]);
      }
    } catch (err) {
      console.error('err', err);
    }
    return response;
  }
  replaceObjectValues(str, obj) {
    // Regular expression to match placeholders with object keys
    const regex = /@\(?([\w.]+)\)?/g;

    return str.replace(regex, (match, key) => {
      // Access nested object values using key paths
      let value = obj;
      const keyParts = key.split('.');
      for (const part of keyParts) {
        value = value[part];
        if (value === undefined) {
          return match; // Return original match if key not found
        }
      }
      return value;
    });
  }
}
