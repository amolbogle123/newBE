import {ConnectorHelper} from "utils/helpers/connector.helper";


export class ApiServiceTaskExecuteService {
    constructor() {
    }

    // public async  executeAPIServiceTask(panelDataObj, data, payload) {
    //     let connectorParams = {};
    //     if (panelDataObj.params.apiParams.length > 0) {
    //         for (const apiValue of panelDataObj.params.apiParams) {
    //             let apiParamValue = apiValue.payloadKey;
    //             let key;
    //             if(apiParamValue.includes('.')) {
    //                 key = apiParamValue.split('.')[1];
    //             } else {
    //                 key = apiParamValue;
    //             }

    //             let insertedData;
    //             if(typeof data.submittedData === 'object') {
    //                 insertedData = data.submittedData;

    //             } else if(typeof data.submittedData === 'string') {
    //                 insertedData = data.submittedData ? JSON.parse(data.submittedData) : {};
    //             }

    //             if (insertedData && insertedData[key]) {
    //                 apiParamValue = insertedData[key];
    //             } else if (payload) {
    //                 // console.log("HERE -------", apiParamValue);
    //                 apiParamValue = this.getValueFromObject(payload, apiParamValue);
    //             }
    //             connectorParams[`${apiValue.paramKey}`] = apiParamValue;
    //         }
    //     }
    //     // console.log('data', data);
    //     // console.log('payload', JSON.stringify(payload, null, 4));
    //     // console.log('connectorParams', connectorParams);
    //     const apiResponse = await ConnectorHelper.apiConnector(
    //         panelDataObj.params.connectorApi,
    //         connectorParams,
    //         panelDataObj.params.apiHeaders
    //     );
    //     console.log('apiResponse :: API RESPONSE :: 45 :: ', apiResponse);
    //     // if (apiResponse.data && panelDataObj.params.saveResultApi && panelDataObj.params.saveResultApi) {
    //     //     let responseToSave = apiResponse.data;
    //     //     // if (panelDataObj.params.apiResponseKey && apiResponse.data[panelDataObj.params.apiResponseKey]) {
    //     //     if (panelDataObj.params.apiResponseKey) {
    //     //         responseToSave = apiResponse.data[panelDataObj.params.apiResponseKey];
    //     //     }
    //     //     //await this.getAndUpdateFormBuilderSubmittedData(panelData.client_id, insertId, panelDataObj.params.apiResultSaveField, responseToSave);
    //     // }
    //     // if (apiResponse.data && panelDataObj.params.saveResultApi) {
    //     //     if (panelDataObj.params.apiResponseKey) {
    //     //         panelDataObj.params.apiResponseKey = {data: apiResponse.data};
    //     //     }
    //     // }
    //     if (apiResponse.data && panelDataObj.params.payloadConfiguration?.variableName) {
    //       payload[panelDataObj.params.payloadConfiguration.variableName] = apiResponse.data;
    //     }
    //     return {"data": "returning from executeAPIServiceTask"};
    //     // console.log('payload', JSON.stringify(payload, null, 4));
    // }

    public async executeAPIServiceTask(panelDataObj, data, payload) {
        let connectorParams = {};
        if (panelDataObj.params.apiParams.length > 0) {
            for (const apiValue of panelDataObj.params.apiParams) {
                let apiParamValue = apiValue.payloadKey;
                let key;
                if (apiParamValue.includes('.')) {
                    key = apiParamValue.split('.')[1];
                } else {
                    key = apiParamValue;
                }
    
                let insertedData;
                if (typeof data.submittedData === 'object') {
                    insertedData = data.submittedData;
                } else if (typeof data.submittedData === 'string') {
                    insertedData = data.submittedData ? JSON.parse(data.submittedData) : {};
                }
    
                if (insertedData && insertedData[key]) {
                    apiParamValue = insertedData[key];
                } else if (payload) {
                    apiParamValue = this.getValueFromObject(payload, apiParamValue);
                }
                connectorParams[`${apiValue.paramKey}`] = apiParamValue;
            }
        }

        if (payload.apiInput.length) {
            payload.apiInput = JSON.parse(payload.apiInput);
            if (payload.apiInput) {
                if (payload.apiInput.payload) {
                    // Parse the stringified JSON in the request object, if needed
                    for (let key in payload.apiInput.payload) {
                        if (data.requestData[key]) {
                            try {
                                // console.log('data.requestData[key] :: ', data.requestData[key]);
                                // data.requestData = JSON.parse(data.requestData[key]);
                                // apiInput.payload[key] = JSON.parse(data.requestData[key]);
                                payload.apiInput.payload[key] = this.parseString(data.requestData[key]);
                            } catch (e) {
                                payload.apiInput.payload[key] = data.requestData[key];
                            }
                        }
                    }
                    connectorParams['requestBody'] = payload.apiInput.payload
                }
                if(payload.apiInput.queryString) {
                    for (let key in payload.apiInput.queryString) {
                        if (data.requestData[key]) {
                            try {
                                connectorParams[key] = this.parseString(data.requestData[key]);
                            } catch (e) {
                                connectorParams[key] = data.requestData[key];
                            }
                        }

                    }
                }

                // if (payload.apiInput.queryString) {
                //     connectorParams['queryString'] = payload.apiInput.queryString;
                // }
            }
        }
    
        // Await the asynchronous call to ensure execution waits for the response
        const apiResponse = await ConnectorHelper.apiConnector(
            panelDataObj.params.connectorApi,
            connectorParams,
            panelDataObj.params.apiHeaders
        );
    
        // console.log('apiResponse :: API RESPONSE :: 45 :: ', apiResponse);
    
        // Handle the response based on the configuration provided in the panelDataObj
        if (apiResponse.data && panelDataObj.params.payloadConfiguration?.variableName) {
            payload[panelDataObj.params.payloadConfiguration.variableName] = apiResponse.data;
        }
    
        // Ensure the function waits until this point before returning
        return payload;
    }    

    // Function to replace single quotes with double quotes and parse JSON
    parseString(string) {
        try {
            // Replace single quotes with double quotes for valid JSON parsing
            const jsonString = string.replace(/'/g, '"');
            return JSON.parse(jsonString);
        } catch (error) {
            console.error("Failed to parse location string:", error);
            return string; // Fallback if parsing fails
        }
    }
    
    getValueFromObject(obj, path) {
      // Split the path into an array of keys
      const keys = path.split('.');
    
      // Traverse the object using a loop
      let current = obj;
      for (const key of keys) {
        // Check if the current property exists
        if (current && typeof current === 'object') {
          current = current[key];
        } else {
          // Key not found or invalid path
          return undefined;
        }
      }
    
      // Return the final value
      return current;
    }
}
