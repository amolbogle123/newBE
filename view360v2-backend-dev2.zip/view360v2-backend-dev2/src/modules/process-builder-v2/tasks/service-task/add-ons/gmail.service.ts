import base64url from "base64url";
import { BusinessProcessModelingExecute, BusinessProcessModelingSubProcess, WidgetAccount } from "entities";
import { MailAccountService } from "../../../../mail-account/services/mail-account.service";
import { ProcessBuilderService } from "../../../services/process-builder.service";
import Container from "typedi";
import { DataSource } from "typeorm";
import GmailApi from "utils/gmailApi.util";
import { ProcessBuilderHelper } from "../../../utils/helpers/process-builder.helper";
import moment from 'moment';

export class GamilService {
    // Services
    private mailAccountService: MailAccountService = new MailAccountService();
    private processBuilderService: ProcessBuilderService = new ProcessBuilderService();
    payloadList = [];
    async executeGmailServiceTask(panelData: any, panelDataObj: any, data: any, scope: any, payload: any, mailAccount: any): Promise<{ status: boolean, stopEngine: boolean }> {
        console.log('executeGmailServiceTask called.');
        const response = { status: true, stopEngine: false };
        console.log('data.type', data?.type, data);
        if (data?.type == 'BPMN_SUBPROCESS_ACTIVITY' && (!data?.activityStartFrom)) {
          response.stopEngine = true;
          return response;
        }
        console.log("Inside Gmail Service Task Execute");
        const connectorResult: WidgetAccount = await Container.get(DataSource).getRepository(WidgetAccount).findOne({ where: { id: panelDataObj.params.connectorApi } });
        if(connectorResult.widgetType === 'GMAIL_GSUITE_ACCOUNT') {
            if (!panelDataObj.params?.connectorApi) {
                return response;
            }
            const filePath = JSON.parse(connectorResult.config)
            if (data?.type === 'BPMN_SUBPROCESS_ACTIVITY' && data?.activityStartFrom === scope.id) {
              /* SINGLE EMAIL DATA READ AND LET OTHER MOVE */
              const messageId = data.mailId;
              const mailExecuteWhere = { bpmn: { id: panelData.bpmnId }, activityId: scope.id, executedData: `${messageId}` };
              const mailExecutedData: BusinessProcessModelingExecute[] = await this.processBuilderService.getBpmnExecute(mailExecuteWhere);
              if (mailExecutedData.length > 0) {
                  console.log(`Process already executed for this email.`, messageId);
                  return response;
              }
              const tokenData: any = await GmailApi.getEmailToken(filePath.accessCode, data.processData?.mailAccount);
              const details: any = await GmailApi.getMailDetails(data.processData?.mailAccount, tokenData.token?.access_token, data.processData?.threadId);
              let dataSet = {
                  date: '',
                  formattedDate: '',
                  from: '',
                  subject: '',
                  htmlBody: '',
                  to: '',
                  mailAccount: data.processData?.mailAccount,
                  messageId: messageId,
                  threadId: data.processData?.threadId,
                  subProcessId: data.subProcessId,
                  matchedKeyword: '',
                  bucketId: '',
                  bucketName: ''
              };
              const mailPayload = details.payload;
              if (!mailPayload) {
                response.stopEngine = true;
                return response;
              }
              if (details.payload.headers?.length) {
                  const findSubject = details.payload.headers.find((h) => h.name === "Subject");
                  if (findSubject?.value) {
                      dataSet["subject"] = findSubject.value;
                  }
                  const findFrom = details.payload.headers.find((h) => h.name === "From");
                  if (findFrom?.value) {
                      dataSet["from"] = findFrom.value;
                  }
                  const findDate = details.payload.headers.find((h) => h.name === "Date");
                  if (findDate?.value) {
                      dataSet["date"] = findDate.value;
                      dataSet['formattedDate'] = moment(findDate.value, 'ddd, D MMM YYYY HH:mm:ss Z').format(`MM-DD-YYYY HH:mm:ss`);
                  }
                  const findMessageId = details.payload.headers.find((h) => h.name.toLowerCase() === 'message-id');
                  if (findMessageId?.value) {
                    dataSet["Rfc822msgid"] = findMessageId.value;
                  }
                  const findTo = details.payload.headers.find((h) => h.name === "To");
                  if (findTo?.value) {
                      dataSet["to"] = findTo.value;
                  }
              }
              let htmlContent = ``;
              if (mailPayload.parts?.length) {
                  for (const partBody of mailPayload.parts) {
                      if (partBody.body.data && partBody.mimeType === 'text/html') {
                          htmlContent += `${base64url.decode(partBody.body.data)}`;
                      } 
                      if (partBody.parts?.length) {
                        for (const subPartBody of partBody.parts) {
                          if (subPartBody.body.data && subPartBody.mimeType === 'text/html') {
                            htmlContent += `${base64url.decode(subPartBody.body.data)}`;
                          }
                        }
                      }
                  }
              } else if (details.payload.body?.data) {
                  htmlContent += `${base64url.decode(details.payload.body.data)}`;
              }
              let htmlBody = ``;
              if (htmlContent) {
                  htmlBody = htmlContent;
                  htmlContent = htmlContent.toString();
                  const styleTagRegex = /<style[^>]*>([\s\S]*?)<\/style>/g;
                  const inlineStyleRegex = /\s+style="([^"]+)"/g;
                  htmlContent = htmlContent.replace(styleTagRegex, '');
                  htmlContent = htmlContent.replace(inlineStyleRegex, '');
                  htmlContent = htmlContent.replace(/(<([^>]+)>)/ig, '');
              }
              dataSet['body'] = htmlContent;
              dataSet['htmlBody'] = htmlBody;
              let outputObj = dataSet;
              if (typeof panelDataObj.params.outputResponse !== 'undefined' && dataSet[panelDataObj.params.outputResponse]) {
                  outputObj = dataSet[panelDataObj.params.outputResponse];
              }
              if (panelDataObj.params.output) {
                  panelDataObj.params[`${panelDataObj.params.output}`] = outputObj;
                  panelDataObj.params[`mailDetails`] = { data: dataSet };
              }
              if (panelDataObj.params.payloadConfiguration) {
                  if (panelDataObj.params.payloadConfiguration.type === 'MAIL_OBJECT') {
                      payload[panelDataObj.params.payloadConfiguration.variableName] = dataSet
                      this.payloadList.push(payload[panelDataObj.params.payloadConfiguration.variableName]);
                  }
              }

              // console.log("Payload Final :: ", JSON.stringify(payload))
              const parsedDate = moment(dataSet['date'], 'ddd, D MMM YYYY HH:mm:ss Z');
              const executeInsertData = {
                  stage: panelData.process.name,
                  bpmn: { id: panelData.bpmnId },
                  entryId: messageId,
                  formId: null,
                  activityId: scope.id,
                  status: 1,
                  panelData: JSON.stringify(panelData),
                  taskName: panelData.task,
                  assignedUserId: null,
                  assignedRoleId: null,
                  executedData: JSON.stringify({
                    messageId,
                    date: parsedDate ? parsedDate.valueOf() : null,
                    historyId: details.historyId
                  })
                  // submittedBy: task.data.createdBy
              } as unknown as BusinessProcessModelingExecute;
              await this.processBuilderService.saveOrUpdateBpmnExecute(executeInsertData);
              // console.log('dataSet.subject', dataSet.subject);
              // console.log('dataSet.Rfc822msgid', dataSet['Rfc822msgid']);
              // let subProcessData = [];
              // let subprocess = new BusinessProcessModelingSubProcess();
              // subprocess.bpmn= panelData.bpmnId;
              // subprocess.activityId= scope.id;
              // subprocess.serviceType= "GMAIL";
              // subprocess.processData= JSON.parse(JSON.stringify({
              //     "MailId": message.id,
              // }));
              // subprocess.status= "PENDING";
              // subprocess.isDeleted= 0;
              // subprocess.createdBy= "SYSTEM";
              // subprocess.updatedBy= "SYSTEM";
              // subprocess.updatedOn= new Date();
              // subProcessData.push(subprocess);
              // const subProcessRes = await this.processBuilderService.createSubProcess(subProcessData);
              // console.log('subProcessRes', subProcessRes);
              // panelDataObj.params.emailList = [];
              // panelDataObj.params.emailList = this.payloadList;
              this.checkAndGoNextSubProcess(this.processBuilderService,this.mailAccountService,panelData,scope, payload, mailAccount, connectorResult.config, panelDataObj, null);
              return response;
            }
            if (mailAccount) {
                /* DEFAULT ALL MAILS ADD TO SUBPROCESS */
                // 1 hit: 
                // 2 hit: 
                const lastSubProcess = await this.processBuilderService.getLastSubProcessForMailAccount({
                  bpmn: panelData.bpmnId,
                  activityId: scope.id,
                  serviceType: 'GMAIL',
                  mailAccount
                });
                console.log('lastSubProcess', lastSubProcess);
                let lastPageToken = null;
                if (lastSubProcess.data?.id) {
                  lastPageToken = lastSubProcess.data.processData.nextPageToken;
                }
                const settingConfig = await this.processBuilderService.getSettingConfig({ type: "MAIL_ACCOUNT_KEY" });
                let emailStartDate = `${moment(panelData.bpmnCreatedOn).format('YYYY-MM-DD')}`;
                const settingConfigData = settingConfig?.config ? JSON.parse(settingConfig.config) : {};
                console.log('settingConfigData.startDate', settingConfigData.startDate);
                if (settingConfigData.startDate) {
                  emailStartDate = `${moment(settingConfigData.startDate).format('YYYY-MM-DD')}`;
                }
                console.log('emailStartDate', emailStartDate);
                let startDate = moment(`${emailStartDate} 00:00:00`,'YYYY-MM-DD HH:mm:ss').valueOf() / 1000;
                console.log('startDate', startDate);
                const mailList: any = await GmailApi.getEmailListByAdmin(filePath.accessCode, mailAccount, 20, startDate, lastPageToken);
                if (!mailList?.data) {
                    return;
                }
                let i = 0;
                for (const message of mailList.data.messages) {
                    i++;
                    const mailExecuteWhere = { bpmn: { id: panelData.bpmnId }, activityId: scope.id, entryId: `${message.id}` };
                    const mailExecutedData: BusinessProcessModelingExecute[] = await this.processBuilderService.getBpmnExecute(mailExecuteWhere);
                    // console.log('mailExecutedData.length', mailExecutedData.length);
                    // const details: any = await GmailApi.getMailDetails(mailAccount, mailList.token.access_token, message.threadId);
                    let subProcessData = [];
                    let subprocess = new BusinessProcessModelingSubProcess();
                    subprocess.bpmn= panelData.bpmnId;
                    subprocess.activityId= scope.id;
                    subprocess.serviceType= "GMAIL";
                    let nextPageToken = null;
                    if (!lastPageToken) {
                      nextPageToken = null;
                    } else if (mailList.data.nextPageToken) {
                      nextPageToken = mailList.data.nextPageToken;
                    }
                    subprocess.processData= JSON.parse(JSON.stringify({
                        "MailId": message.id,
                        mailAccount,
                        threadId: message.threadId,
                        nextPageToken
                    }));
                    subprocess.status= "PENDING";
                    subprocess.isDeleted= 0;
                    subprocess.createdBy= "SYSTEM";
                    subprocess.updatedBy= "SYSTEM";
                    subprocess.updatedOn= new Date();
                    subProcessData.push(subprocess);
                    if (mailExecutedData.length > 0) {
                        console.log(`Process already executed for this email.`, message.id);
                        break;
                    } else {
                        await this.processBuilderService.createSubProcess(subProcessData);
                        panelDataObj.params.emailList = [];
                        panelDataObj.params.emailList = this.payloadList;
                        response.stopEngine = true;
                        // const details: any = await GmailApi.getMailDetails(mailAccount, mailList.token.access_token, message.threadId);
                        // let dataSet = {
                        //     date: '',
                        //     from: '',
                        //     subject: '',
                        //     htmlBody: ''
                        // };
                        // const mailPayload = details.payload;
                        
                        // console.log('mailPayload', JSON.stringify(mailPayload, null, 4));
                        // if (!mailPayload) {
                        //   // return response;
                        //   continue;
                        // }
                        // if (mailPayload.headers?.length) {
                        //     const findSubject = details.payload.headers.find((h) => h.name === "Subject");
                        //     if (findSubject?.value) {
                        //         dataSet["subject"] = findSubject.value;
                        //     }
                        //     const findFrom = details.payload.headers.find((h) => h.name === "From");
                        //     if (findFrom?.value) {
                        //         dataSet["from"] = findFrom.value;
                        //     }
                        //     const findDate = details.payload.headers.find((h) => h.name === "Date");
                        //     if (findDate?.value) {
                        //         dataSet["date"] = findDate.value;
                        //     }
                        //     const findMessageId = details.payload.headers.find((h) => h.name === 'Message-ID');
                        //     if (findMessageId?.value) {
                        //       dataSet["Rfc822msgid"] = findMessageId.value;
                        //   }
                        // }
                        // let htmlContent = ``;
                        // // console.log('mailPayload.parts', mailPayload.parts);
                        // // console.log('mailPayload.parts', JSON.stringify(mailPayload.parts, null, 4));
                        // // console.log('mailPayload', JSON.stringify(mailPayload, null, 4));
                        // // console.log('dataSet["Rfc822msgid"]', dataSet["Rfc822msgid"]);
                        // if (mailPayload.parts?.length) {
                        //     for (const partBody of mailPayload.parts) {
                        //         if (partBody.body.data && partBody.mimeType === 'text/html') {
                        //             htmlContent += `${base64url.decode(partBody.body.data)}`;
                        //         }
                        //     }
                        // } else if (details.payload.body?.data) {
                        //     htmlContent += `${base64url.decode(details.payload.body.data)}`;
                        // }
                        // let htmlBody = ``;
                        // if (htmlContent) {
                        //     htmlBody = htmlContent;
                        //     htmlContent = htmlContent.toString();
                        //     htmlContent = htmlContent.replace(/(<([^>]+)>)/ig, '');
                        //     // htmlContentNew = htmlContent.replace(/\\<.*?\\>/g, "");
                        // }
                        // dataSet['body'] = htmlContent;
                        // dataSet['bodyContainer'] = htmlBody;
                        // let outputObj = dataSet;
                        // if (typeof panelDataObj.params.outputResponse !== 'undefined' && dataSet[panelDataObj.params.outputResponse]) {
                        //     outputObj = dataSet[panelDataObj.params.outputResponse];
                        // }
                        // if (panelDataObj.params.output) {
                        //     panelDataObj.params[`${panelDataObj.params.output}`] = outputObj;
                        //     panelDataObj.params[`mailDetails`] = { data: dataSet };
                        // }
                        // if (panelDataObj.params.payloadConfiguration) {
                        //     if (panelDataObj.params.payloadConfiguration.type === 'MAIL_OBJECT') {
                        //         payload[panelDataObj.params.payloadConfiguration.variableName] = dataSet
                        //         this.payloadList.push(payload[panelDataObj.params.payloadConfiguration.variableName]);
                        //     }
                        // }

                        // // console.log("Payload Final :: ", JSON.stringify(payload))
                        // const executeInsertData = {
                        //     stage: panelData.process.name,
                        //     bpmn: { id: panelData.bpmnId },
                        //     entryId: dataSet["Rfc822msgid"],
                        //     formId: null,
                        //     activityId: scope.id,
                        //     status: 1,
                        //     panelData: JSON.stringify(panelData),
                        //     taskName: panelData.task,
                        //     assignedUserId: null,
                        //     assignedRoleId: null,
                        //     executedData: `${message.id}`
                        //     // submittedBy: task.data.createdBy
                        // } as unknown as BusinessProcessModelingExecute;
                        // let newEntry = await this.processBuilderService.saveOrUpdateBpmnExecute(executeInsertData);
                        
                    }
                }
                this.checkAndGoNextSubProcess(this.processBuilderService,this.mailAccountService,panelData,scope, payload, mailAccount, connectorResult.config, panelDataObj, null);
                return response;
                // let dataSet = {
                //     date: '',
                //     from: '',
                //     subject: '',
                //     htmlBody: ''
                // };
                // const mail = mailList.data.messages[0];
                // const mailExecuteWhere = { bpmn: { id: panelData.bpmnId }, activityId: scope.id, executedData: `${mail.id}` };
                // // console.log('mailExecuteWhere', mailExecuteWhere);
                // const mailExecutedData: BusinessProcessModelingExecute[] = await this.processBuilderService.getBpmnExecute(mailExecuteWhere);
                // // console.log('mailExecutedData', mailExecutedData.length);
                // if (mailExecutedData.length > 0) {
                //     console.log(`Process already executed for this email.`, mail.id);
                //     return;
                // }
                //
                // //const details = await this.mailAccountService.getMaildetails(connectorConfig.email, token, mail.id);
                // const details: any = await GmailApi.getMailDetails(mailAccount, mailList.token.access_token, mailList.data.messages[0].threadId)
                // // console.log('details', JSON.stringify(details, null, 4));
                // if (!details) {
                //     return;
                // }
                // if (!details.payload) {
                //     return;
                // }
                // const mailPayload = details.payload;
                // if (mailPayload.headers?.length) {
                //     const findSubject = details.payload.headers.find((h) => h.name === "Subject");
                //     if (findSubject?.value) {
                //         dataSet["subject"] = findSubject.value;
                //     }
                //     const findFrom = details.payload.headers.find((h) => h.name === "From");
                //     if (findFrom?.value) {
                //         dataSet["from"] = findFrom.value;
                //     }
                //     const findDate = details.payload.headers.find((h) => h.name === "Date");
                //     if (findDate?.value) {
                //         dataSet["date"] = findDate.value;
                //     }
                // }
                // let htmlContent = ``;
                // // console.log('mailPayload.parts', mailPayload.parts);
                // if (mailPayload.parts?.length) {
                //     for (const partBody of mailPayload.parts) {
                //         if (partBody.body.data && partBody.mimeType === 'text/html') {
                //             htmlContent += `${base64url.decode(partBody.body.data)}`;
                //         }
                //     }
                // } else if (details.payload.body?.data) {
                //     htmlContent += `${base64url.decode(details.payload.body.data)}`;
                // }
                // let htmlBody = ``;
                // if (htmlContent) {
                //     htmlBody = htmlContent;
                //     htmlContent = htmlContent.toString();
                //     htmlContent = htmlContent.replace(/(<([^>]+)>)/ig, '');
                //     // htmlContentNew = htmlContent.replace(/\\<.*?\\>/g, "");
                // }
                // dataSet['body'] = htmlContent;
                // dataSet['bodyContainer'] = htmlBody;
                // let outputObj = dataSet;
                // if (typeof panelDataObj.params.outputResponse !== 'undefined' && dataSet[panelDataObj.params.outputResponse]) {
                //     outputObj = dataSet[panelDataObj.params.outputResponse];
                // }
                // if (panelDataObj.params.output) {
                //     panelDataObj.params[`${panelDataObj.params.output}`] = outputObj;
                //     panelDataObj.params[`mailDetails`] = { data: dataSet };
                // }
                // if (panelDataObj.params.payloadConfiguration) {
                //     if (panelDataObj.params.payloadConfiguration.type === 'MAIL_OBJECT') {
                //         payload[panelDataObj.params.payloadConfiguration.variableName] = dataSet
                //     }
                // }
                //
                // // console.log("Payload Final :: ", JSON.stringify(payload))
                // const executeInsertData = {
                //     stage: panelData.process.name,
                //     bpmn: { id: panelData.bpmnId },
                //     entryId: mail.id,
                //     formId: null,
                //     activityId: scope.id,
                //     status: 1,
                //     panelData: JSON.stringify(panelData),
                //     taskName: panelData.task,
                //     assignedUserId: null,
                //     assignedRoleId: null,
                //     executedData: `${mail.id}`
                //     // submittedBy: task.data.createdBy
                // } as unknown as BusinessProcessModelingExecute;
                //
                // let newEntry = await this.processBuilderService.saveOrUpdateBpmnExecute(executeInsertData);
            }
        } else if (connectorResult.widgetType === 'GOOGLE_GMAIL') {
            /***
             * console.log('connectorResult', connectorResult);
            if (connectorResult?.widgetType != 'GOOGLE_GMAIL') {
                return;
            }
             */
            const connectorConfig = connectorResult.config ? JSON.parse(connectorResult.config) : {};
            if (connectorConfig?.token?.access_token) {
                const tokenDetails: any = await GmailApi.getToken(connectorConfig);
                if (tokenDetails?.token) {
                    const token = tokenDetails.token;
                    const mailList = await this.mailAccountService.getMailList(connectorConfig?.email, token, { maxResults: 5, pageToken: null, q: 'in:inbox' });
                    if (!mailList?.data?.messages) {
                        return;
                    }
                    //start 
                    let subProcessData = [];
                    mailList.data.messages.forEach(element => {
                        let subprocess = new BusinessProcessModelingSubProcess();
                        subprocess.bpmn= panelData.bpmnId;
                        subprocess.activityId= scope.id;
                        subprocess.serviceType= "GMAIL";
                        subprocess.processData= JSON.parse(JSON.stringify({
                            "MailId": element.id,
                        }));
                        subprocess.status= "PENDING";
                        subprocess.isDeleted= 0;
                        subprocess.createdBy= "SYSTEM";
                        subprocess.updatedBy= "SYSTEM";
                        subprocess.updatedOn= new Date();
                        subProcessData.push(subprocess);
                    });
                    await this.processBuilderService.createSubProcess(subProcessData);
                    
                    await this.checkAndGoNextSubProcess(this.processBuilderService,this.mailAccountService,panelData,scope, payload, mailAccount, connectorConfig, panelDataObj, token);

                    //end




                    
                }
            }
        }
        return response;

        // const gmailAccessToken = GmailApi.getEmailListByAdmin('', )
        // Below code is commented for backup
        // const connectorResult: WidgetAccount = await Container.get(DataSource).getRepository(WidgetAccount).findOne({ where: { id: panelDataObj.params.connectorApi } });
        // // console.log('connectorResult', connectorResult);
        // if (connectorResult?.widgetType != 'GOOGLE_GMAIL') {
        //     return;
        // }
        // const connectorConfig = connectorResult.config ? JSON.parse(connectorResult.config) : {};
        // if (connectorConfig?.token?.access_token) {
        //     const tokenDetails: any = await GmailApi.getToken(connectorConfig);
        //     if (tokenDetails?.token) {
        //         const token = tokenDetails.token;
        //
        //
        //         const mailList = await this.mailAccountService.getMailList(connectorConfig?.email, token, { maxResults: 1, pageToken: null, q: 'in:inbox' });
        //         console.log('mailList', mailList.data.messages);
        //         // console.log('mailList', JSON.stringify(mailList, null, 4));
        //         if (!mailList?.data?.messages) {
        //             return;
        //         }
        //         let dataSet = {
        //             date: '',
        //             from: '',
        //             subject: '',
        //             htmlBody: ''
        //         };
        //         const mail = mailList.data.messages[0];
        //         const mailExecuteWhere = { bpmn: { id: panelData.bpmnId }, activityId: scope.id, executedData: `${mail.id}` };
        //         // console.log('mailExecuteWhere', mailExecuteWhere);
        //         const mailExecutedData: BusinessProcessModelingExecute[] = await this.processBuilderService.getBpmnExecute(mailExecuteWhere);
        //         // console.log('mailExecutedData', mailExecutedData.length);
        //         if (mailExecutedData.length > 0) {
        //             console.log(`Process already executed for this email.`, mail.id);
        //             return;
        //         }
        //         // console.log('\n\n\n\n\n\n------------------HERE---------------\n\n\n\n\n\n\----');
        //
        //
        //         const details = await this.mailAccountService.getMaildetails(connectorConfig.email, token, mail.id);
        //         // console.log('details', JSON.stringify(details, null, 4));
        //         if (!details?.data) {
        //             return;
        //         }
        //         if (!details.data.payload) {
        //             return;
        //         }
        //         const mailPayload = details.data.payload;
        //         if (mailPayload.headers?.length) {
        //             const findSubject = details.data.payload.headers.find((h) => h.name === "Subject");
        //             if (findSubject?.value) {
        //                 dataSet["subject"] = findSubject.value;
        //             }
        //             const findFrom = details.data.payload.headers.find((h) => h.name === "From");
        //             if (findFrom?.value) {
        //                 dataSet["from"] = findFrom.value;
        //             }
        //             const findDate = details.data.payload.headers.find((h) => h.name === "Date");
        //             if (findDate?.value) {
        //                 dataSet["date"] = findDate.value;
        //             }
        //         }
        //         let htmlContent = ``;
        //         // console.log('mailPayload.parts', mailPayload.parts);
        //         if (mailPayload.parts?.length) {
        //             for (const partBody of mailPayload.parts) {
        //                 if (partBody.body.data && partBody.mimeType === 'text/html') {
        //                     htmlContent += `${base64url.decode(partBody.body.data)}`;
        //                 }
        //             }
        //         } else if (details.data.payload.body?.data) {
        //             htmlContent += `${base64url.decode(details.data.payload.body.data)}`;
        //         }
        //         // console.log('htmlContent', htmlContent);
        //         // let htmlnew = '';
        //         let htmlBody = ``;
        //         if (htmlContent) {
        //             htmlBody = htmlContent;
        //             htmlContent = htmlContent.toString();
        //             htmlContent = htmlContent.replace(/(<([^>]+)>)/ig, '');
        //             // htmlContentNew = htmlContent.replace(/\\<.*?\\>/g, "");
        //         }
        //         // console.log('htmlnew', htmlnew);
        //         // console.log('------\n\n\n\n------');
        //         dataSet['body'] = htmlContent;
        //         dataSet['bodyContainer'] = htmlBody;
        //         // console.log('dataSet', JSON.stringify(dataSet, null, 4));
        //         // console.log('panelDataObj.params.output', panelDataObj.params.output);
        //         let outputObj = dataSet;
        //         if (typeof panelDataObj.params.outputResponse !== 'undefined' && dataSet[panelDataObj.params.outputResponse]) {
        //             outputObj = dataSet[panelDataObj.params.outputResponse];
        //         }
        //         if (panelDataObj.params.output) {
        //             panelDataObj.params[`${panelDataObj.params.output}`] = outputObj;
        //             panelDataObj.params[`mailDetails`] = { data: dataSet };
        //         }
        //         // console.log("Panel Object Params :: Gmail Service :: Payload Configuration :: ", panelDataObj.params.payloadConfiguration);
        //         // console.log("Data Set :: Gmail Service :: Payload Configuration :: ", dataSet);
        //         if (panelDataObj.params.payloadConfiguration) {
        //             if (panelDataObj.params.payloadConfiguration.type === 'MAIL_OBJECT') {
        //                 payload[panelDataObj.params.payloadConfiguration.variableName] = dataSet
        //             }
        //         }
        //
        //
        //         console.log("Payload Final :: ", JSON.stringify(payload))
        //         const executeInsertData = {
        //             stage: panelData.process.name,
        //             bpmn: { id: panelData.bpmnId },
        //             entryId: mail.id,
        //             formId: null,
        //             activityId: scope.id,
        //             status: 1,
        //             panelData: JSON.stringify(panelData),
        //             taskName: panelData.task,
        //             assignedUserId: null,
        //             assignedRoleId: null,
        //             executedData: `${mail.id}`
        //             // submittedBy: task.data.createdBy
        //         } as unknown as BusinessProcessModelingExecute;
        //
        //
        //         let newEntry = await this.processBuilderService.saveOrUpdateBpmnExecute(executeInsertData);
        //         // console.log('newEntry', newEntry);
        //     }
        // }

    }

    async checkAndGoNextSubProcess(processBuilderService,mailAccountService,panelData,scope, payload, mailAccount, connectorConfig, panelDataObj, token) {
      console.log('checkAndGoNextSubProcess called.');
        let subProcess=await processBuilderService.getNextSubProcess(panelData.bpmnId,"PENDING",scope.id,"GMAIL");
        console.log('subProcess', subProcess);
        if(subProcess){
            const processBuilderHelper = new ProcessBuilderHelper();
            const processData = { 
              type: 'BPMN_SUBPROCESS_ACTIVITY', 
              bpmnId: subProcess.bpmn, 
              activityStartFrom: subProcess.activityId, 
              mailId: subProcess.processData?.MailId,
              subProcessId: subProcess.id,
              processData: subProcess.processData
            }
            processBuilderHelper.execute(1, null, null, null, processData, subProcess.bpmn, null);
            await processBuilderService.updateSubProcessStatus(subProcess.id,"INPROGRESS");

            //Keep this
            // let dataSet = {
            //     date: '',
            //     from: '',
            //     subject: '',
            //     htmlBody: ''
            // };
            // const mail = {
            //     id: subProcess.processData.MailId
            // };
            // const mailExecuteWhere = { bpmn: { id: panelData.bpmnId }, activityId: scope.id, executedData: `${mail.id}` };
            // // console.log('mailExecuteWhere', mailExecuteWhere);
            // const mailExecutedData: BusinessProcessModelingExecute[] = await processBuilderService.getBpmnExecute(mailExecuteWhere);
            // // console.log('mailExecutedData', mailExecutedData.length);
            // if (mailExecutedData.length > 0) {
            //     console.log(`Process already executed for this email.`, mail.id);
            //     return;
            // }
            // console.log('\n\n\n\n\n\n------------------HERE---------------\n\n\n\n\n\n\----');


            // const details = await mailAccountService.getMaildetails(connectorConfig.email, token, mail.id);
            // console.log('details', JSON.stringify(details, null, 4));
            // if (!details?.data) {
            //     return;
            // }
            // if (!details.data.payload) {
            //     return;
            // }
            // const mailPayload = details.data.payload;
            // if (mailPayload.headers?.length) {
            //     const findSubject = details.data.payload.headers.find((h) => h.name === "Subject");
            //     if (findSubject?.value) {
            //         dataSet["subject"] = findSubject.value;
            //     }
            //     const findFrom = details.data.payload.headers.find((h) => h.name === "From");
            //     if (findFrom?.value) {
            //         dataSet["from"] = findFrom.value;
            //     }
            //     const findDate = details.data.payload.headers.find((h) => h.name === "Date");
            //     if (findDate?.value) {
            //         dataSet["date"] = findDate.value;
            //     }
            // }
            // let htmlContent = ``;
            // console.log('mailPayload.parts', mailPayload.parts);
            // if (mailPayload.parts?.length) {
            //     for (const partBody of mailPayload.parts) {
            //         if (partBody.body.data && partBody.mimeType === 'text/html') {
            //             htmlContent += `${base64url.decode(partBody.body.data)}`;
            //         }
            //     }
            // } else if (details.data.payload.body?.data) {
            //     htmlContent += `${base64url.decode(details.data.payload.body.data)}`;
            // }
            // console.log('htmlContent', htmlContent);
            // let htmlnew = '';
            // let htmlBody = ``;
            // if (htmlContent) {
            //     htmlBody = htmlContent;
            //     htmlContent = htmlContent.toString();
            //     htmlContent = htmlContent.replace(/(<([^>]+)>)/ig, '');
            //     // htmlContentNew = htmlContent.replace(/\\<.*?\\>/g, "");
            // }
            // console.log('htmlnew', htmlnew);
            // console.log('------\n\n\n\n------');
            // dataSet['body'] = htmlContent;
            // dataSet['bodyContainer'] = htmlBody;
            // console.log('dataSet', JSON.stringify(dataSet, null, 4));
            // console.log('panelDataObj.params.output', panelDataObj.params.output);
            // let outputObj = dataSet;
            // if (typeof panelDataObj.params.outputResponse !== 'undefined' && dataSet[panelDataObj.params.outputResponse]) {
            //     outputObj = dataSet[panelDataObj.params.outputResponse];
            // }
            // if (panelDataObj.params.output) {
            //     panelDataObj.params[`${panelDataObj.params.output}`] = outputObj;
            //     panelDataObj.params[`mailDetails`] = { data: dataSet };
            // }
            // console.log("Panel Object Params :: Gmail Service :: Payload Configuration :: ", panelDataObj.params.payloadConfiguration);
            // console.log("Data Set :: Gmail Service :: Payload Configuration :: ", dataSet);
            // if (panelDataObj.params.payloadConfiguration) {
            //     if (panelDataObj.params.payloadConfiguration.type === 'MAIL_OBJECT') {
            //         payload[panelDataObj.params.payloadConfiguration.variableName] = dataSet
            //     }
            // }


            // console.log("Payload Final :: ", JSON.stringify(payload))
            // const executeInsertData = {
            //     stage: panelData.process.name,
            //     bpmn: { id: panelData.bpmnId },
            //     entryId: mail.id,
            //     formId: null,
            //     activityId: scope.id,
            //     status: 1,
            //     panelData: JSON.stringify(panelData),
            //     taskName: panelData.task,
            //     assignedUserId: null,
            //     assignedRoleId: null,
            //     executedData: `${mail.id}`
            //     // submittedBy: task.data.createdBy
            // } as unknown as BusinessProcessModelingExecute;


            // let newEntry = await processBuilderService.saveOrUpdateBpmnExecute(executeInsertData);
            // console.log('newEntry', newEntry);
            // await processBuilderService.updateSubProcessStatus(subProcess.id,"COMPLETED");
            //await checkAndGoNextSubProcess(processBuilderService,mailAccountService,panelData,scope);
        }
    }
}
