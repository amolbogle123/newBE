import Container from "typedi";
import { DataSource, In } from "typeorm";
import { Users, WidgetAccount } from "../../../../../entities";
import GmailApi from "../../../../../utils/gmailApi.util";
import { CommunicationHelper } from "../../../../../utils/helpers/communication.helper";
import { PanelDataTask, ProcessAssignee, ProcessCheckOn } from "../../../models";
import { BpmnNotificationHelper } from "../../../utils/helpers/bpmn-notification.helper";

export class EmailNotificationService {
    private communicationHelperService: CommunicationHelper = new CommunicationHelper();

    private bpmnNotificationHelper: BpmnNotificationHelper = new BpmnNotificationHelper();

    sendEmailNotification(panelData, panelDataObj, data, scope, insertId, payload): Promise<any> {
      console.log("sendEmailNotification called. ");
        return new Promise(async (resolve) => {
            try {
                if (panelDataObj?.params?.mailAction === 'CREATE') {
                  await this.createNotificationFlow(panelData, panelDataObj, data, scope, insertId, payload);
                } else if (panelDataObj?.params?.mailAction === 'FORWARD') {
                  await this.forwardNotificationFlow(panelData, panelDataObj, data, scope, insertId);
                }
                resolve(true);
            } catch (error) {
                resolve(true);
            }
        });
    }

     createNotificationFlow(panelData, panelDataObj, data, scope, insertId, payload) {
      return new Promise(async (resolve) => {
        try {
          let emailList = [];
          if (panelDataObj?.checkon && (panelDataObj?.params?.mailtemplate || panelDataObj?.params?.notificationTemplate)) {
            let selectFields: any = ['username', 'roleId', 'email', 'id'];

            switch (panelDataObj.checkon) {
              case ProcessCheckOn.FORM_FIELD:
                if (data?.submittedData) {
                  const submittedData = JSON.parse(data.submittedData);
                  if (submittedData && panelDataObj.params.recipientMail && submittedData[panelDataObj.params.recipientMail]) {
                    emailList = submittedData[panelDataObj.params.recipientMail].split(',').filter(item => item.trim() !== '').map(item => { 
                      return {
                        username: item.trim(),
                        email: item.trim()
                      };
                    });

                    const condition = {
                      email: In(emailList.map(item => item.email))
                    };
                    const usersList = await Container.get(DataSource).getRepository(Users).find({where: condition, select: selectFields});
                    if (usersList?.length) {
                      for (let user of usersList) {
                        const findIndex = emailList.findIndex(item => item.email === user.email);
                        if (findIndex > -1 && user.id) {
                          emailList[findIndex].id = user.id;
                        }
                      }
                    }
                  }
                }
                break;
              case ProcessCheckOn.TEXT_VALUE:
                if (panelDataObj.params?.recipientMail) {
                  emailList = panelDataObj.params.recipientMail.split(',').filter(item => item.trim() !== '').map(item => {
                    return {
                      username: item.trim(),
                      email: item.trim()
                    };
                  });

                  const condition = {
                    email: In(emailList.map(item => item.email))
                  };
                  const usersList = await Container.get(DataSource).getRepository(Users).find({where: condition, select: selectFields});
                  if (usersList?.length) {
                    for (let user of usersList) {
                      const findIndex = emailList.findIndex(item => item.email === user.email);
                      if (findIndex > -1 && user.id) {
                        emailList[findIndex].id = user.id;
                      }
                    }
                  }
                }
                break;
              case ProcessCheckOn.ASSIGNED_USER:
                if (data?.createdBy) {
                  const condition = {
                    userManager: data.createdBy
                  };
                  const usersList = await Container.get(DataSource).getRepository(Users).find({where: condition, select: selectFields});
                  if (usersList?.length) {
                    emailList = usersList;
                  }
                }
                break;
              case ProcessCheckOn.SELECTED_USER:
                if (panelDataObj.params?.recipientMail?.length) {
                  const condition = {
                    id: In(panelDataObj.params.recipientMail)
                  };
                  const usersList = await Container.get(DataSource).getRepository(Users).find({where: condition, select: selectFields});
                  if (usersList?.length) {
                    emailList = usersList;
                  }
                }
                break;
              case ProcessCheckOn.SELECTED_ROLE:
                if (panelDataObj.params?.recipientMail?.length) {
                  const condition = {
                    roleId: In(panelDataObj.params.recipientMail)
                  };
                  const usersList = await Container.get(DataSource).getRepository(Users).find({where: condition, select: selectFields});
                  if (usersList?.length) {
                    emailList = usersList;
                  }
                }
                break;
            }
            
            if (emailList?.length) {
              if (panelDataObj?.params?.mailtemplate) {
                let mailData = {
                  subject: 'View360',
                  html: "",
                  clientId: panelData.client_id,
                  to: "",
                  importantMail: true
                };

                for (let email of emailList) {
                  mailData.to = email.email;

                  const replaceData = Object.assign({}, payload);
                  const userDetails = { username: email.username };
                  const replace = await this.communicationHelperService.htmlReplace(panelDataObj.params.mailtemplate, 'id', userDetails, replaceData);
                  if (replace?.status) {
                    mailData.subject = replace.subject;
                    /**
                     * mailData.html = replace.htmlString;
                     */
                    mailData.html = '<!DOCTYPE html>'+
                    '<html><head><title>'+replace.subject+'</title>'+
                    '</head><body>'+ replace.htmlString +'</body></html>';
                  }
                  await this.communicationHelperService.nodeMailerService(mailData);
                }
              }

              if (panelDataObj?.params?.notificationTemplate) {
                let notificationParams = {
                  notificationTemplate: panelDataObj.params.notificationTemplate,
                  assignto: ProcessAssignee.USER,
                  notificationExtraData: panelDataObj.params.notificationExtraData
                };
                for (let email of emailList) {
                  if (email?.id) {
                    notificationParams['assignee'] = [email.id]; 
                    
                    await this.bpmnNotificationHelper.execute(data.formId, insertId, notificationParams, PanelDataTask.ASSIGN, panelData.client_id, data.createdBy, payload);
                  }
                }
              }
            }
          }
          resolve(true);
        } catch (error) {
          resolve(true);
        }
      });
    }

     forwardNotificationFlow(panelData, panelDataObj, data, scope, insertId) {
      return new Promise(async (resolve) => {
        if (panelDataObj.params.mailForwardTask && panelDataObj.params.recipientMail) {
          const taskData = panelData.taskarr.find(obj => obj.id == panelDataObj.params.mailForwardTask);
          if (!taskData?.params?.connectorApi) {
            return;
          }
          if (!taskData?.params?.mailDetails?.data) {
            return;
          }
          const mailDetails = taskData.params.mailDetails.data;
          const connectorResult: WidgetAccount = await Container.get(DataSource).getRepository(WidgetAccount).findOne({ where: {id: taskData.params.connectorApi} });
          if (!connectorResult) {
            return;
          }
          if (connectorResult?.widgetType != 'GOOGLE_GMAIL') {
            return;
          }
          const connectorConfig = connectorResult.config ? JSON.parse(connectorResult.config) : {};
          if (!connectorConfig.token?.access_token) {
            return;
          }
          const tokenDetails: any = await GmailApi.getToken(connectorConfig);
          if (!tokenDetails?.token) {
            return;
          }
          const token = tokenDetails.token;
          /**
           * console.log('token', token);
          console.log('mailDetails', mailDetails);
          console.log('mailDetails.payload.headers', JSON.stringify(mailDetails.payload.headers, null, 4));
          const toDataIndex = mailDetails.payload.headers.findIndex(obj => obj.name === 'To');
          console.log('mailDetails.payload.headers[toDataIndex]', mailDetails.payload.headers[toDataIndex]);
          mailDetails.payload.headers[toDataIndex].value = panelDataObj.params.recipientMail;
          console.log('1.mailDetails.payload.headers[toDataIndex]', mailDetails.payload.headers[toDataIndex]);
           */
          await GmailApi.forwardMail(connectorConfig.email, token, mailDetails, panelDataObj.params.recipientMail);
        }
        resolve(true);
      });
    }
}