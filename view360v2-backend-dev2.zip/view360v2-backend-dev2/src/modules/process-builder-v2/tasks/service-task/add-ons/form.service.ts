import lodash from "lodash";
import { FormBuilder } from "../../../../../entities/create-form-builder";
import { FormBuilderService } from "../../../../form-builder/services/form-builder.service";
import { ConfigUtils } from "../../../../process-builder-v2/utils/helpers/config-utils";

export class FormService {
  payloadList = [];
  private formBuilderService: FormBuilderService = new FormBuilderService();
  private processConfigService = new ConfigUtils();

  formServiceTask(panelData, insertId, panelDataObj, data, payload): Promise<any> {
    console.log('formServiceTask called.');
    console.log('payload', payload);
    return new Promise(async (resolve) => {
      try {
        console.log('panelDataObj', panelDataObj);
        if (panelDataObj.params?.operationType === 'select' && panelDataObj.params.formId) {
          const whereClause: any = this.getWhereFields(panelDataObj, payload);
          // const formResults: CustomForms[] = await this.formBuilderService.getCustomForms({ clientId: panelData.client_id, id: panelDataObj.params.formId }, ["referenceId"]);
          // console.log('formResults', formResults);
          const entryResults: FormBuilder = await this.formBuilderService.getFormBuilder(panelData.client_id, null, whereClause);
          console.log('entryResults', entryResults);
          if (entryResults?.id) {
            entryResults.submittedData = JSON.parse(entryResults.submittedData);
          }
          if (panelDataObj.params.payloadConfiguration?.variableName) {
            payload[panelDataObj.params.payloadConfiguration.variableName] = entryResults;
          }
        }
        else if (panelDataObj.params?.operationType === 'update' && panelDataObj.params.formId) {
          // SUBT = SUBTRACTION
          // SUM = SUMMATION
          const whereClause: any = this.getWhereFields(panelDataObj, payload);
          console.log('1.whereClause', whereClause);
          console.log('panelDataObj.params.updateFormFields', panelDataObj.params.updateFormFields);
          const updateResults: FormBuilder[] = await this.formBuilderService.getFormBuilderList(panelData.client_id, null, whereClause, ['id','submittedData']);
          console.log('updateResults', updateResults);
          if (!lodash.isEmpty(updateResults)) {
            updateResults.forEach(async (formResult) => {
              const submittedData = formResult.submittedData ? JSON.parse(formResult.submittedData) : {};
              for (const fieldValue of panelDataObj.params.updateFormFields) {
                const updateFieldKey = fieldValue.formField;
                let updateValue = fieldValue.updateValue;
                if (fieldValue.valueType === 'PAYLOAD') {
                  const payloadValue = this.processConfigService.replaceObjectValues(fieldValue.updateValue, payload);
                  console.log('payloadValue', payloadValue);
                  if (payloadValue && (payloadValue.includes('SUBT(') || payloadValue.includes('SUM('))) {
                    updateValue = this.processConfigService.calculateUsingString(payloadValue);
                  }
                  submittedData[updateFieldKey] = updateValue;
                  continue;
                }
                submittedData[fieldValue.formField] = fieldValue.updateValue;
              }
              console.log('submittedData', submittedData);
              const dataPayload = {
                submittedData: JSON.stringify(submittedData),
              };
              await this.formBuilderService.updateFormBuilder(panelData.client_id, null, { id: formResult.id }, dataPayload);
            });
          }
        }
        // if (panelDataObj?.params?.formId && insertId && panelDataObj.params?.updateFormFields && Array.isArray(panelDataObj.params.updateFormFields) && panelDataObj.params.updateFormFields?.length > 0) {
        //   const whereClause: any = { id: data.id };
        //   const results: CustomForms[] = await this.formBuilderService.getCustomForms({ clientId: panelData.client_id, id: panelDataObj.params.formId }, ["referenceId"]);
        //   const formResults: FormBuilder = await this.formBuilderService.getFormBuilder(panelData.client_id, results[0].referenceId, whereClause, ['submittedData']);
        //   if (!lodash.isEmpty(formResults)) {
        //     const submittedData = formResults.submittedData ? JSON.parse(formResults.submittedData) : {};
        //     for (const fieldValue of panelDataObj.params.updateFormFields) {
        //       if (fieldValue.valueType === 'PAYLOAD') {
        //         const payloadValue = this.getValueByDotNotation(payload, fieldValue.updateValue);
        //         if (typeof payloadValue !== 'undefined') {
        //           submittedData[fieldValue.formField] = payloadValue;
        //         }
        //         continue;
        //       }
        //       submittedData[fieldValue.formField] = fieldValue.updateValue;
        //     }
        //     const dataPayload = {
        //       submittedData: JSON.stringify(submittedData),
        //     };
        //     await this.formBuilderService.updateFormBuilder(panelData.client_id, results[0].referenceId, whereClause, dataPayload);
        //   }
        // }
        resolve(true);
      } catch (error) {
        console.error('error', error);
        resolve(true);
      }
    });
  }
  getWhereFields(panelDataObj, payload) {
    console.log('panelDataObj.params.whereFields', panelDataObj.params.whereFields);
    const whereClause: any = {};
    if (Array.isArray(panelDataObj.params.whereFields) && panelDataObj.params.whereFields.length > 0) {
      for (const whereValue of panelDataObj.params.whereFields) {
        let formField = whereValue.formField;
        if (formField == 'entryId') {
          formField = 'id';
        }
        if (whereValue.valueType === 'PAYLOAD') {
          const payloadValue = this.processConfigService.getValueFromObject(payload, whereValue.updateValue);
          if (typeof payloadValue !== 'undefined') {
            whereClause[formField] = payloadValue;
          }
          continue;
        }
        whereClause[formField] = whereValue.updateValue;
      }
    }
    return whereClause;
  }
  getValueByDotNotation(obj, key) {
    const propertyNames = key.split(".");
    let currentObject = obj;
    for (const propertyName of propertyNames) {
      currentObject = currentObject?.[propertyName];
    }
    return currentObject;
  }
}