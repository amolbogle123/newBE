import lodash from "lodash";
import { DataSource, In } from "typeorm";
import { dataSource } from "../../../../core/data-source";
import { BusinessProcessModelingExecute, WidgetAccount } from "../../../../entities";
import { DatabaseType, QueryType, StatusType } from "../../../../models/enums";
import { ConnectorsUtil } from "../../../../utils/connectors.util";
import { SetResponse } from "../../../../utils/helpers/common.helper";
import { ConnectorHelper } from "../../../../utils/helpers/connector.helper";
import { FormBuilderService } from "../../../form-builder/services/form-builder.service";
import { ProcessDataType, ProcessTask, TaskServiceType } from "../../models";
import { ProcessBuilderService } from "../../services/process-builder.service";
import { ProcessBuilderHelper } from "../../utils/helpers/process-builder.helper";

import base64url from "base64url";
import Container from 'typedi';
import { FormBuilder } from "../../../../entities/create-form-builder";
import { MailAccountService } from "../../../../modules/mail-account/services/mail-account.service";
import GmailApi from "../../../../utils/gmailApi.util";
import { CommunicationHelper } from "../../../../utils/helpers/communication.helper";
import { BpmnNotificationHelper } from "../../utils/helpers/bpmn-notification.helper";
import { ApiServiceTaskExecuteService } from "./add-ons/api.serviceTask-execute.service";
import { EmailNotificationService } from "./add-ons/email-notification.service";
import { FormService } from "./add-ons/form.service";
import { GamilService } from "./add-ons/gmail.service";
import { MySQLService } from "./add-ons/mysql.service";
import { OpenAIService } from "./add-ons/open-ai.service";

export class ServiceTask {
    // Services
    private formService: FormService = new FormService();
    private emailNotificationService: EmailNotificationService = new EmailNotificationService();
    private formBuilderService: FormBuilderService = new FormBuilderService();
    private processBuilderService: ProcessBuilderService = new ProcessBuilderService();
    private mailAccountService: MailAccountService = new MailAccountService();
    private communicationHelper: CommunicationHelper = new CommunicationHelper();
    private bpmnNotificationHelper: BpmnNotificationHelper = new BpmnNotificationHelper();
    private apiServiceTaskExecuteService: ApiServiceTaskExecuteService = new ApiServiceTaskExecuteService();
    private mysqlService: MySQLService = new MySQLService();
    private gmailService: GamilService = new GamilService();
    private openAIService: OpenAIService = new OpenAIService();

    private replaceSource = (
        stringToReplace: string,
        variableToReplace: any = null
    ) => {
        return this.replace(/\{source.([^}]+)}/g,stringToReplace, variableToReplace);
    };

    private replaceInserted = (
        stringToReplace: string,
        variableToReplace: any = null
    ) => {
        return this.replace(/\{inserted.([^}]+)}/g,stringToReplace, variableToReplace);
    };

    private executeProcessBuilder = (): Function =>
        new ProcessBuilderHelper().execute;

    private replace(searchValueRegExp:any,stringToReplace: string, variableToReplace: any) {
        let string = stringToReplace;
        if (variableToReplace) {
            string = stringToReplace.replace(
                searchValueRegExp,
                (_, prop) => {
                    if (typeof variableToReplace[prop] === "undefined") {
                        return "";
                    } else {
                        return variableToReplace[prop];
                    }
                }
            );
        }
        return string;
    }

    private static async runQuery(
        queryStatement: string,
        quantifier: any[] = []
    ): Promise<any> {
        return Container.get(DataSource).manager.query(queryStatement, quantifier);
    }

    // async executeTask(
    //     panelData: any,
    //     data: any,
    //     scope: any,
    //     insertId: string | null,
    //     formTableName: string,
    //     payload: any,
    //     mailAccount: any
    // ) { 
    //     console.log('1..11....serviceTask called.');
    //     const response = { status: true, stopEngine: false };
    //     const panelDataObj: ProcessTask | any = panelData.taskarr.find(
    //         (x: any) => {
    //             return x.id == scope.id;
    //         }
    //     );
    //     console.log('panelDataObj.name', panelDataObj.name);
    //     // return;
    //     if (panelData.executedActivities.includes(scope.id)) {
    //         return { status: true, stopEngine: false };
    //     }
    //     panelData.executedActivities.push(scope.id);

    //     if (
    //         panelDataObj &&
    //         panelDataObj.nextbpmn &&
    //         panelDataObj.serviceType === TaskServiceType.ANOTHER_PROCESS
    //     ) {
    //         await this.processTaskService_AnotherProcess(panelDataObj, insertId);
    //     } else if (
    //         panelDataObj &&
    //         panelDataObj.serviceType === TaskServiceType.MYSQL
    //     ) {
    //         // console.log('TaskServiceType.CONNECTOR->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>++++++++++++++++++++', TaskServiceType.CONNECTOR);
    //         // console.log('------------------>panelData', JSON.stringify(panelData, null, 2));
    //         // console.log('------------------>panelDataObj', JSON.stringify(panelDataObj, null, 2));
    //         // await this.processTaskService_Connector(panelData, panelDataObj, data, insertId);
    //         await this.mysqlService.mysqlServiceTaskExecute(panelData, panelDataObj, data, insertId, payload);
    //     } else if (
    //         panelDataObj &&
    //         panelDataObj.serviceType === TaskServiceType.FORM
    //     ) {
    //         const formServiceResponse = await this.formService.formServiceTask(panelData, insertId, panelDataObj, data, payload);
    //         console.log('formServiceResponse', formServiceResponse);
    //     } else if (
    //         panelDataObj &&
    //         panelDataObj.serviceType === TaskServiceType.EXECUTE_SQL
    //     ) {
    //         await this.processTaskService_ExecuteSQL(panelData, panelDataObj, data);
    //     } else if (panelDataObj && panelDataObj.serviceType === TaskServiceType.API_CONNECT && panelDataObj.params && panelDataObj.params.connectorApi) {
    //        const result = await this.apiServiceTaskExecuteService.executeAPIServiceTask(panelDataObj, data, payload);
    //        console.log("result in index :: 134 :: ", result);
    //        return result;
    //     } else if (panelDataObj.serviceType === TaskServiceType.GMAIL) {
    //         // console.log("Payload :: in Gmail :: ", JSON.stringify(payload));
    //     //   await this.processTaskService_ExecuteGmail(panelData, panelDataObj, data, scope);
    //         const gmailServiceResponse = await this.gmailService.executeGmailServiceTask(panelData, panelDataObj, data, scope, payload, mailAccount);
    //         response.stopEngine = gmailServiceResponse?.stopEngine;
    //         return response;
    //     } else if (panelDataObj.serviceType === TaskServiceType.EMAIL_NOTIFICATION) { 
    //         // console.log("Send email notificaiton :: Payload :: ", payload)
    //         this.emailNotificationService.sendEmailNotification(panelData, panelDataObj, data, scope, insertId, payload);
    //     } else if (panelDataObj.serviceType === TaskServiceType.OPEN_AI) {
    //       const openAIResponse = await this.openAIService.openAIServiceTask(panelData, panelDataObj, data, scope, payload);
    //       console.log('openAIResponse', openAIResponse);
    //       return response;
    //   }
    //     return response;
    // }

    async executeTask(
        panelData: any,
        data: any,
        scope: any,
        insertId: string | null,
        formTableName: string,
        payload: any,
        mailAccount: any
    ) {
        const response = { status: true, stopEngine: false };
        const panelDataObj: ProcessTask | any = panelData.taskarr.find((x: any) => {
            return x.id == scope.id;
        });
    
    
        if (panelData.executedActivities.includes(scope.id)) {
            return { status: true, stopEngine: false };
        }
    
        panelData.executedActivities.push(scope.id);
    
        if (
            panelDataObj &&
            panelDataObj.nextbpmn &&
            panelDataObj.serviceType === TaskServiceType.ANOTHER_PROCESS
        ) {
            await this.processTaskService_AnotherProcess(panelDataObj, insertId);
        } else if (panelDataObj && panelDataObj.serviceType === TaskServiceType.MYSQL) {
            await this.mysqlService.mysqlServiceTaskExecute(panelData, panelDataObj, data, insertId, payload);
        } else if (panelDataObj && panelDataObj.serviceType === TaskServiceType.FORM) {
            const formServiceResponse = await this.formService.formServiceTask(panelData, insertId, panelDataObj, data, payload);
            console.log('formServiceResponse', formServiceResponse);
        } else if (panelDataObj && panelDataObj.serviceType === TaskServiceType.EXECUTE_SQL) {
            await this.processTaskService_ExecuteSQL(panelData, panelDataObj, data);
        } else if (panelDataObj && panelDataObj.serviceType === TaskServiceType.API_CONNECT && panelDataObj.params && panelDataObj.params.connectorApi) {
            const result = await this.apiServiceTaskExecuteService.executeAPIServiceTask(panelDataObj, data, payload);
            return result;
        } else if (panelDataObj.serviceType === TaskServiceType.GMAIL) {
            const gmailServiceResponse = await this.gmailService.executeGmailServiceTask(panelData, panelDataObj, data, scope, payload, mailAccount);
            response.stopEngine = gmailServiceResponse?.stopEngine;
            return response;
        } else if (panelDataObj.serviceType === TaskServiceType.EMAIL_NOTIFICATION) {
            this.emailNotificationService.sendEmailNotification(panelData, panelDataObj, data, scope, insertId, payload);
        } else if (panelDataObj.serviceType === TaskServiceType.OPEN_AI) {
            const openAIResponse = await this.openAIService.openAIServiceTask(panelData, panelDataObj, data, scope, payload);
            return response;
        }
    
        return response;
    }
    

    private async getAndUpdateFormBuilderSubmittedData(client_id, entryId: any, formFieldToUpdate: string, updateFieldValue: any) {
      const whereClause: any = { id: entryId };

      const formBuilderRes: FormBuilder = await this.formBuilderService.getFormBuilder(client_id, '', whereClause, ['submittedData']);
      if (!lodash.isEmpty(formBuilderRes)) {
          let submittedData = {};
          if (formBuilderRes.submittedData) {
              submittedData = JSON.parse(formBuilderRes.submittedData);
          }
          submittedData[formFieldToUpdate] = updateFieldValue;

          const dataPayload = {
              submittedData: JSON.stringify(submittedData),
          };
          await this.formBuilderService.updateFormBuilder(client_id, '', whereClause, dataPayload);
      }
  }

    private async processTaskService_ExecuteSQL(panelData: any, panelDataObj: any, data: any) {
        let sourceConnector: any = {};
        if (panelData.manualSQLConnector) {
            sourceConnector = this.setSourceConnector(panelData, sourceConnector);
        }
        if (panelDataObj.params &&
            panelDataObj.params.sqlAccount &&
            panelDataObj.params.sqlStatement) {
            let destinationConfig = await this.getDestinationConfig(panelDataObj, sourceConnector);
            let sourceData: any = {};
            if (data &&
                data.type &&
                data.type === ProcessDataType.SQL_CONNECTOR) {
                if (data.queryData &&
                    data.queryData[sourceConnector.columnName]) {
                    sourceData = data.queryData;
                }
            }

            let destinationQuery: any = panelDataObj.params.sqlStatement;
            if (destinationConfig &&
                destinationConfig.dbType.toLowerCase() === DatabaseType.MYSQL) {
                destinationQuery = this.replaceSource(
                    panelDataObj.params.sqlStatement,
                    sourceData
                );

                await ConnectorsUtil.connect(null, destinationQuery, destinationConfig);

                // const qryResult = await ServiceTaskHelper.runQuery(
                //     destinationQuery
                // );
                // const insertResult = qryResult.data;
                // TO_DO: need code for custom rule
                // if (insertResult.insertId && insertResult.affectedRows) {
                //     if (
                //         panelDataObj.params.isAfterExecution &&
                //         panelDataObj.params.ruleTable &&
                //         panelDataObj.params.ruleUniqueField
                //     ) {
                //         let selRuleFields = "*";
                //         if (
                //             panelDataObj.params.ruleGroupBy &&
                //             panelDataObj.params.ruleExtraField
                //         ) {
                //             selRuleFields +=
                //                 "," + panelDataObj.params.ruleExtraField;
                //         }
                //         let selInsQry = `SELECT ${selRuleFields} FROM ${panelDataObj.params.ruleTable} WHERE 1`;
                //         selInsQry += ` AND ${panelDataObj.params.ruleUniqueField} >= '${insertResult.insertId}'`;
                //         selInsQry += ` AND ${
                //             panelDataObj.params.ruleUniqueField
                //         } < '${
                //             insertResult.insertId +
                //             insertResult.affectedRows
                //         }'`;
                //         if (panelDataObj.params.ruleGroupBy) {
                //             selInsQry +=
                //                 " GROUP BY " +
                //                 panelDataObj.params.ruleGroupBy;
                //         }
                //         const insertedData =
                //             await ServiceTaskHelper.runQuery(selInsQry);
                //         if (
                //             Array.isArray(insertedData) &&
                //             insertedData.length &&
                //             panelDataObj.params.afterRules.length &&
                //             Array.isArray(panelDataObj.params.afterRules)
                //         ) {
                //             let insertedValues = insertedData
                //                 .map(
                //                     (obj) =>
                //                         obj[
                //                             panelDataObj.params
                //                                 .ruleUniqueField
                //                         ]
                //                 )
                //                 .join(",");
                //             if (
                //                 panelDataObj.params.ruleGroupBy &&
                //                 panelDataObj.params.deleteExtraInserted
                //             ) {
                //                 let deleteInsertedQry = `DELETE FROM ${panelDataObj.params.ruleTable} WHERE 1`;
                //                 deleteInsertedQry += ` AND ${panelDataObj.params.ruleUniqueField} >= '${insertResult.insertId}'`;
                //                 deleteInsertedQry += ` AND ${
                //                     panelDataObj.params.ruleUniqueField
                //                 } < '${
                //                     insertResult.insertId +
                //                     insertResult.affectedRows
                //                 }'`;
                //                 deleteInsertedQry += ` AND ${panelDataObj.params.ruleUniqueField} NOT IN (${insertedValues})`;
                //                 await ServiceTaskHelper.runQuery(
                //                     deleteInsertedQry
                //                 );
                //             }
                //             for (const insertedValue of insertedData) {
                //                 let _updateQueryService = "";
                //                 for (const ruleValue of panelDataObj.params
                //                     .afterRules) {
                //                     if (
                //                         !ruleValue.fieldName ||
                //                         !ruleValue.matchValue ||
                //                         !ruleValue.ruleAction
                //                     ) {
                //                         continue;
                //                     }
                //                     if (
                //                         insertedValue[
                //                             ruleValue.fieldName
                //                         ] &&
                //                         insertedValue[
                //                             ruleValue.fieldName
                //                         ] === ruleValue.matchValue
                //                     ) {
                //                         const updateStmt = `UPDATE ${
                //                             panelDataObj.params.ruleTable
                //                         } SET ${
                //                             ruleValue.ruleAction
                //                         } WHERE ${
                //                             panelDataObj.params
                //                                 .ruleUniqueField
                //                         } = '${
                //                             insertedValue[
                //                                 panelDataObj.params
                //                                     .ruleUniqueField
                //                             ]
                //                         }';`;
                //                         _updateQueryService +=
                //                             this.replaceInserted(
                //                                 updateStmt,
                //                                 insertedValue
                //                             );
                //                     }
                //                 }
                //                 if (_updateQueryService) {
                //                     await ServiceTaskHelper.runQuery(
                //                         _updateQueryService
                //                     );
                //                 }
                //             }
                //         }
                //     }
                // }
            }

            // TO_DO: add MS Sql or postgress connection code
        }
    }

    private async getDestinationConfig(panelDataObj: any, sourceConnector: any) {
        const listOfIds: any[] = [panelDataObj.params.sqlAccount];
        if (sourceConnector && sourceConnector.sqlAccount) {
            listOfIds.push(sourceConnector.sqlAccount);
        }
        const connectors = await dataSource
            .getRepository(WidgetAccount)
            .find({
                where: { id: In(listOfIds) },
                select: ["id", "config"],
            });

        let destinationConfig = null;
        if (connectors && connectors.length > 0) {
            const destinationAccount = connectors.find(
                (obj) => obj.id === panelDataObj.params.sqlAccount
            );
            destinationConfig =
                destinationAccount && destinationAccount.config
                    ? JSON.parse(destinationAccount.config)
                    : {};
            if (sourceConnector && sourceConnector.sqlAccount) {
                // Nothing will be happen here (code commented in old source code)
            }
        }
        return destinationConfig;
    }

    private setSourceConnector(panelData: any, sourceConnector: any) {
        if (panelData.connectorParams &&
            panelData.connectorParams.sqlAccount &&
            panelData.connectorParams.columnName) {
            if (panelData.connectorParams.sqlTable ||
                panelData.connectorParams.manualQuery) {
                sourceConnector = panelData.connectorParams;
            }
        }
        return sourceConnector;
    }

    private async processTaskService_Connector(panelData: any, panelDataObj: any, data: any, insertId: string) {
        let sourceConnector: any = {};
        if (panelData.manualSQLConnector) {
            sourceConnector = this.setSourceConnector(panelData, sourceConnector);
        }
        if (panelDataObj.params &&
            panelDataObj.params.sqlAccount &&
            panelDataObj.params.sqlTable &&
            panelDataObj.params.dbQuery) {
            const listOfIds: any[] = [panelDataObj.params.sqlAccount];
            if (sourceConnector && sourceConnector.sqlAccount) {
                listOfIds.push(sourceConnector.sqlAccount);
            }
            const connectors = await dataSource
                .getRepository(WidgetAccount)
                .find({
                    where: { id: In(listOfIds) },
                    select: ["id", "config"],
                });

            let destinationConfig = null;
            let sourceConfig = null;
            ({ destinationConfig, sourceConfig } = this.getSourceAndDestinationConfigs(connectors, panelDataObj, destinationConfig, sourceConnector, sourceConfig));

            let sourceData: any = this.getSourceData(sourceConfig, data, sourceConnector);

            let sourceQry: string = this.getSourceQuery(sourceConnector, insertId);

            const connectorHelperResponse: SetResponse = await ConnectorHelper.connect(
                null,
                sourceQry,
                destinationConfig
            );

            if (connectorHelperResponse.status === StatusType.SUCCESS &&
                !lodash.isEmpty(connectorHelperResponse.data)) {
                sourceData = connectorHelperResponse.data[0];
            }
            let sqlDataSet: any = {};

            this.updateSQLDataSet(panelData, panelDataObj, sourceData, data, sqlDataSet);

            let whereCond = "";
            let mssqlWhere = [];

            whereCond = this.getWhereCond(panelDataObj, whereCond, sourceData, data, destinationConfig, mssqlWhere);
            let destinationQuery = this.getDestinationQuery(panelDataObj, destinationConfig, sqlDataSet, mssqlWhere, whereCond);
            console.log('destinationQuery', destinationQuery);
            if (!lodash.isEmpty(destinationQuery)) {
                const dataResponse = await ConnectorHelper.connect(
                    null,
                    destinationQuery,
                    destinationConfig
                );
                if (panelDataObj.params.payloadConfiguration) {
                    if (panelDataObj.params.payloadConfiguration.type === 'LAST_INSERT_OBJECT') {
                        panelData.payload[panelDataObj.params.payloadConfiguration.variableName] = JSON.stringify(dataResponse.data[1][0]);
                    }
                    if (panelDataObj.params.payloadConfiguration.type === 'LAST_INSERT_ID') {
                        panelData.payload[panelDataObj.params.payloadConfiguration.variableName] = dataResponse.data.insertId;
                    }
                }
            }
        }
    }

    private getSourceAndDestinationConfigs(connectors: WidgetAccount[], panelDataObj: any, destinationConfig: any, sourceConnector: any, sourceConfig: any) {
        if (connectors && connectors.length > 0) {
            const destinationAccount = connectors.find(
                (obj) => obj.id === panelDataObj.params.sqlAccount
            );
            destinationConfig =
                destinationAccount && destinationAccount.config
                    ? JSON.parse(destinationAccount.config)
                    : {};
            if (sourceConnector && sourceConnector.sqlAccount) {
                const sourceAccount = connectors.find(
                    (obj) => obj.id === sourceConnector.sqlAccount
                );
                sourceConfig =
                    sourceAccount && sourceAccount.config
                        ? JSON.parse(sourceAccount.config)
                        : {};
            }
        }
        return { destinationConfig, sourceConfig };
    }

    private getDestinationQuery(panelDataObj: any, destinationConfig: any, sqlDataSet: any, mssqlWhere: any[], whereCond: string) {
        let destinationQuery = "";
        const tableName: string = panelDataObj.params.sqlTable;

        if (destinationConfig.dbType === DatabaseType.MSSQL) {
            if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.INSERT &&
                Object.keys(sqlDataSet).length > 0) {
                const fieldNames = Object.keys(sqlDataSet).join(",");
                const fieldValues = Object.values(sqlDataSet).join(",");
                destinationQuery = `${QueryType.INSERT} INTO [${tableName}] (${fieldNames}) VALUES (${fieldValues})`;
            } else if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.UPDATE &&
                sqlDataSet.length > 0 &&
                mssqlWhere.length > 0) {
                destinationQuery = `${QueryType.UPDATE} [${tableName}] SET ${sqlDataSet.join(
                    ","
                )} WHERE ${mssqlWhere.join(" AND ")}`;
            } else if (panelDataObj.params.dbQuery === QueryType.DELETE) {
                destinationQuery = `${QueryType.DELETE} FROM [${tableName}] WHERE ${mssqlWhere.join(
                    " AND "
                )}`;
            }
        } else if (lodash.toLower(destinationConfig.dbType) === lodash.toLower(DatabaseType.MYSQL)) {
            const setQueryBuild = Object.keys(sqlDataSet).map(
                (key) => `${key} = '${sqlDataSet[key]}'`
            );

            if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.INSERT) {
                destinationQuery = `${QueryType.INSERT} ${tableName} SET ${setQueryBuild}`;
                if (panelDataObj.params.payloadConfiguration && panelDataObj.params.payloadConfiguration.type === 'LAST_INSERT_OBJECT') {
                    destinationQuery += `; SELECT * FROM ${tableName} WHERE Id=(SELECT LAST_INSERT_ID());`;
                }
            } else if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.UPDATE &&
                whereCond) {
                destinationQuery =
                    `${QueryType.UPDATE} ${tableName} SET ${setQueryBuild} WHERE ` +
                    whereCond;
            } else if (panelDataObj.params.dbQuery.toUpperCase() ===
                QueryType.DELETE &&
                whereCond) {
                destinationQuery =
                    `${QueryType.DELETE} FROM ${tableName} WHERE ` +
                    whereCond;
            }
        }
        return destinationQuery;
    }

    private getWhereCond(panelDataObj: any, whereCond: string, sourceData: any, data: any, destinationConfig: any, mssqlWhere: any[]) {
        if (Array.isArray(panelDataObj.params.whereFields) &&
            panelDataObj.params.whereFields.length > 0) {
            whereCond = "1";
            for (const whereValue of panelDataObj.params.whereFields) {
                let formValue = this.getFormValueForWhereCond(whereValue, sourceData, data);
                if (formValue) {
                    if (destinationConfig.dbType === DatabaseType.MSSQL) {
                        mssqlWhere.push(
                            `[${whereValue.columnName}] = '${formValue}'`
                        );
                    }
                    if (lodash.toLower(destinationConfig.dbType) === lodash.toLower(DatabaseType.MYSQL)) {
                        whereCond +=
                            " AND `" +
                            whereValue.columnName +
                            "` = '" +
                            formValue +
                            "'";
                    }
                }
            }
        }
        return whereCond;
    }

    private getFormValueForWhereCond(whereValue: any, sourceData: any, data: any) {
        let formValue = "";
        if (whereValue.formField === "V_OTHER_DATA" &&
            whereValue.otherValue) {
            formValue = whereValue.otherValue;
        } else if (sourceData &&
            sourceData[whereValue.formField]) {
            formValue = sourceData[whereValue.formField];
        } else if (data && data[whereValue.formField]) {
            formValue = data[whereValue.formField];
        }
        return formValue;
    }

    private updateSQLDataSet(panel_data: any, panelDataObj: any, sourceData: any, data: any, sqlDataSet: any) {
        if (Array.isArray(panelDataObj.params.sqlFields) &&
            panelDataObj.params.sqlFields.length > 0) {
            for (const fieldValue of panelDataObj.params.sqlFields) {
                let formValue = "";
                if (fieldValue.formField === "V_OTHER_DATA" &&
                    fieldValue.otherValue) {
                    formValue = fieldValue.otherValue;
                } else if (sourceData &&
                    sourceData[fieldValue.formField]) {
                    formValue = sourceData[fieldValue.formField];
                } else if (data && data[fieldValue.formField]) {
                    formValue = data[fieldValue.formField];
                } else if (fieldValue.formField === "V_PAYLOAD_DATA" &&
                    fieldValue.payloadKey) {
                    const payloadKey = fieldValue.payloadKey.split(".");
                    if (payloadKey.length > 1) {
                        if (payloadKey[0] === "submittedData") {
                            formValue = panel_data.payload[payloadKey[1]];
                        }
                    } else {
                        formValue = panel_data.payload[fieldValue.payloadKey];
                    }
                } else if (data && data.submittedData) {
                    const submittedData = data.submittedData;
                    if (submittedData[fieldValue.formField]) {
                        formValue = submittedData[fieldValue.formField];
                    }
                }
                sqlDataSet[fieldValue.columnName] = formValue;
            }
        }
    }

    private getSourceQuery(sourceConnector: any, insertId: string) {
        let sourceQry: string = "";
        if (sourceConnector.isManualQuery &&
            sourceConnector.manualQuery) {
            sourceQry = sourceConnector.manualQuery;
        } else {
            sourceQry = `SELECT * FROM ${sourceConnector.sqlTable} WHERE ${sourceConnector.columnName} = '${insertId}' LIMIT 1`;
        }
        return sourceQry;
    }

    private getSourceData(sourceConfig: any, data: any, sourceConnector: any) {
        let sourceData: any = {};
        if (sourceConfig &&
            sourceConfig.dbType === DatabaseType.MYSQL) {
            if (data &&
                data.type &&
                data.type === ProcessDataType.SQL_CONNECTOR) {
                if (data.queryData &&
                    data.queryData[sourceConnector.columnName]) {
                    sourceData = data.queryData;
                }
            }
        }
        return sourceData;
    }

    private async processTaskService_AnotherProcess(panelDataObj: any, insertId: string) {
        const bpmnResult = await this.processBuilderService.getMultipleBpmn(
            { id: panelDataObj.nextbpmn },
            ["id", "clientId"]
        );

        // added blank reference id
        if (bpmnResult && bpmnResult.length > 0) {
            new ProcessBuilderHelper().execute(
                bpmnResult[0].clientId,
                null,
                insertId, '',
                {
                    type: ProcessDataType.FROM_ANOTHER_PROCESS,
                    bpmnid: bpmnResult[0].id,
                },
                null, null
            );
        }
    }

    private async processTaskService_ExecuteGmail(panelData: any, panelDataObj: any, data: any, scope: any) {
      if (!panelDataObj.params?.connectorApi) {
        return;
      }
      const connectorResult: WidgetAccount = await Container.get(DataSource).getRepository(WidgetAccount).findOne({ where: {id: panelDataObj.params.connectorApi} });
      if (connectorResult?.widgetType != 'GOOGLE_GMAIL') {
        return;
      }
      const connectorConfig = connectorResult.config ? JSON.parse(connectorResult.config) : {};
      if (connectorConfig?.token?.access_token) {
        const tokenDetails: any = await GmailApi.getToken(connectorConfig);
        if (tokenDetails?.token) {
          const token = tokenDetails.token;

          const mailList = await this.mailAccountService.getMailList(connectorConfig?.email, token, { maxResults: 1, pageToken: null, q: 'in:inbox' });
          if (!mailList?.data?.messages) {
            return;
          }
          let dataSet = {
            date: '',
            from: '',
            subject: '',
            htmlBody: ''
          };
          const mail = mailList.data.messages[0];
          const mailExecuteWhere = { bpmn: { id: panelData.bpmnId }, activityId: scope.id, executedData: `${mail.id}` };
          const mailExecutedData: BusinessProcessModelingExecute[] = await this.processBuilderService.getBpmnExecute(mailExecuteWhere);
          if (mailExecutedData.length > 0) {
            console.log(`Process already executed for this email.`, mail.id);
            return;
          }

          const details = await this.mailAccountService.getMaildetails(connectorConfig.email, token, mail.id);
          if (!details?.data) {
            return;
          }
          if (!details.data.payload) {
            return;
          }
          const mailPayload = details.data.payload;
          if (mailPayload.headers?.length) {
            const findSubject = details.data.payload.headers.find((h) => h.name === "Subject");
            if (findSubject?.value) {
              dataSet["subject"] = findSubject.value;
            }
            const findFrom = details.data.payload.headers.find((h) => h.name === "From");
            if (findFrom?.value) {
              dataSet["from"] = findFrom.value;
            }
            const findDate = details.data.payload.headers.find((h) => h.name === "Date");
            if (findDate?.value) {
              dataSet["date"] = findDate.value;
            }
          }
          let htmlContent = ``;
          if (mailPayload.parts?.length) {
            for (const partBody of mailPayload.parts) {
              if (partBody.body.data && partBody.mimeType === 'text/html') {
                htmlContent += `${base64url.decode(partBody.body.data)}`;
              }
            }
          } else if (details.data.payload.body?.data) {
            htmlContent += `${base64url.decode(details.data.payload.body.data)}`;
          }
          
          let htmlBody = ``;
          if (htmlContent) {
            htmlBody = htmlContent;
            htmlContent = htmlContent.toString();
            htmlContent = htmlContent.replace(/(<([^>]+)>)/ig, '');
          }
          
          dataSet['body'] = htmlContent;
          dataSet['bodyContainer'] = htmlBody;
          
          let outputObj = dataSet;
          if (typeof panelDataObj.params.outputResponse !== 'undefined' && dataSet[panelDataObj.params.outputResponse]) {
            outputObj = dataSet[panelDataObj.params.outputResponse];
          }
          if (panelDataObj.params.output) {
            panelDataObj.params[`${panelDataObj.params.output}`] = outputObj;
            panelDataObj.params[`mailDetails`] = { data: dataSet };
          }
          const executeInsertData = {
            stage: panelData.process.name,
            bpmn: { id: panelData.bpmnId },
            entryId: mail.id,
            formId: null,
            activityId: scope.id,
            status: 1,
            panelData: JSON.stringify(panelData),
            taskName: panelData.task,
            assignedUserId: null,
            assignedRoleId: null,
            executedData: `${mail.id}`
            // submittedBy: task.data.createdBy
          } as unknown as BusinessProcessModelingExecute;

          await this.processBuilderService.saveOrUpdateBpmnExecute(executeInsertData);
        }
      }
    }

    // private async processTaskService_ExecuteEmailNotification(panelData: any, panelDataObj: any, data: any, scope: any, insertId: string) {
    //   // console.log('panelDataObj', panelDataObj);
    //   if (panelDataObj.params?.mailAction && panelDataObj.params.mailForwardTask && panelDataObj.params.recipientMail && panelDataObj.params.mailAction === 'FORWARD') {
    //     const taskData = panelData.taskarr.find(obj => obj.id == panelDataObj.params.mailForwardTask);
    //     // console.log('taskData', taskData);
    //     if (!taskData?.params?.connectorApi) {
    //       return;
    //     }
    //     if (!taskData?.params?.mailDetails?.data) {
    //       return;
    //     }
    //     const mailDetails = taskData.params.mailDetails.data;
    //     const connectorResult: WidgetAccount = await Container.get(DataSource).getRepository(WidgetAccount).findOne({ where: {id: taskData.params.connectorApi} });
    //     // console.log('connectorResult', connectorResult);
    //     if (!connectorResult) {
    //       return;
    //     }
    //     if (connectorResult?.widgetType != 'GOOGLE_GMAIL') {
    //       return;
    //     }
    //     const connectorConfig = connectorResult.config ? JSON.parse(connectorResult.config) : {};
    //     if (!connectorConfig.token?.access_token) {
    //       return;
    //     }
    //     const tokenDetails: any = await GmailApi.getToken(connectorConfig);
    //     if (!tokenDetails?.token) {
    //       return;
    //     }
    //     const token = tokenDetails.token;
    //     // console.log('token', token);
    //     // console.log('mailDetails', mailDetails);
    //     // console.log('mailDetails.payload.headers', JSON.stringify(mailDetails.payload.headers, null, 4));
    //     // const toDataIndex = mailDetails.payload.headers.findIndex(obj => obj.name === 'To');
    //     // console.log('mailDetails.payload.headers[toDataIndex]', mailDetails.payload.headers[toDataIndex]);
    //     // mailDetails.payload.headers[toDataIndex].value = panelDataObj.params.recipientMail;
    //     // console.log('1.mailDetails.payload.headers[toDataIndex]', mailDetails.payload.headers[toDataIndex]);
    //     const forwardEmailData = await GmailApi.forwardMail(connectorConfig.email, token, mailDetails, panelDataObj.params.recipientMail);
    //     console.log('forwardEmailData', JSON.stringify(forwardEmailData, null, 4));
    //   }
    //   let message: string = '';

    // }
}
