import moment from "moment-timezone";
import { v4 as generateUuid } from "uuid";
import { BpmnEngine } from "bpmn-engine";
import { CronHelper } from "../../../../utils/helpers/cron.helper";
import { ProcessCronService } from "../../services/process-cron.service";
import { ApiMethod } from "../../models";



export class TimerTask {

  // Services
  private processCronService: ProcessCronService = new ProcessCronService();

  async executeTask(task: any, bpmnEngine: BpmnEngine) {
    let panelData = task.panelData.taskarr.find((x: any) => { return x.id == task.api.id });
    let isExecutedAlready = false;
    if (task.panelData.executedActivities.indexOf(task.api.id) > -1) {
      isExecutedAlready = true;
    }
    task.panelData.executedActivities.push(task.api.id);
    if (panelData.catchDuration && panelData.durationTime && !isExecutedAlready) {
      console.log('1.panelData', panelData);
      task.panelData.timerparams.cronDate = null;
      if (!task.panelData.timerparams.timezone) {
        task.panelData.timerparams.timezone = moment.tz.guess();
      }
      if (task.panelData.timerparams.time) {
        switch (panelData.catchDuration) {
          case 'minute':
            task.panelData.timerparams.time = moment(task.panelData.timerparams.time, 'HH:mm').tz(task.panelData.timerparams.timezone).add(panelData.durationTime, 'minute').format('HH:mm');
            task.panelData.timerparams.cronDate = task.panelData.timerparams.exactDate;
            break;
          case 'hour':
            task.panelData.timerparams.time = moment(task.panelData.timerparams.time, 'HH:mm').tz(task.panelData.timerparams.timezone).add(panelData.durationTime, 'hour').format('HH:mm');
            task.panelData.timerparams.cronDate = task.panelData.timerparams.exactDate;
            break;
          case 'day':
            task.panelData.timerparams.cronDate = moment(task.panelData.timerparams.exactDate).tz(task.panelData.timerparams.timezone).add(panelData.durationTime, 'day').toISOString();
            break;
          case 'month':
            task.panelData.timerparams.cronDate = moment(task.panelData.timerparams.exactDate).tz(task.panelData.timerparams.timezone).add(panelData.durationTime, 'month').toISOString();
            break;
          default:
            break;
        }
      } else {
        task.panelData.timerparams.time = moment().tz(task.panelData.timerparams.timezone).add('1', 'minute').format('HH:mm');
        task.panelData.timerparams.cronDate = moment().tz(task.panelData.timerparams.timezone).toISOString();
      }

      if (task.panelData.timerparams) {
        task.panelData.timerparams.frequency = 'exactDate';
        const uniqueRefId = generateUuid();
        let addCronData = {
          client_id: task.clientId,
          hitApi: 'bpmn-cron',
          hitMethod: ApiMethod.POST,
          cronType: 'BPMN_ACTIVITY',
          refId: uniqueRefId,
          createdBy: task.data.createdBy,
          config: {
            apiBody: {
              refId: uniqueRefId,
              bpmnId: task.bpmnId,
              activityId: task.api.id,
              entryId: task.entryId,
              executedActivities: task.panelData.executedActivities,
              entryData: task.data,
            },
            scheduleOn: CronHelper.generateTime(task.panelData.timerparams),
          },
          timezone: task.panelData.timerparams.timezone,
        }
        await this.processCronService.addCron(addCronData);
      }
      bpmnEngine.stop();
    }
  }
}
