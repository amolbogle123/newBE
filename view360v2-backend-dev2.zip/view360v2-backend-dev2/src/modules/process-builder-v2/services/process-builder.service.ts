import {DeleteResult, In, UpdateResult, DataSource} from "typeorm";
import lodash from 'lodash';
import {CommonHelper,ApiErrorResponse,SetResponse} from "../../../utils/helpers/common.helper";
import {StatusType, UserType} from "../../../models/enums";
import * as txt from "../utils/constants/api.constant";
import {
    BusinessProcessModelingExecute,
    BusinessProcessModeling,
    Campaign,
    BusinessProcessModelingSql, Users, MdbClient, BusinessProcessModelingSubProcess, SettingConfig
} from "../../../entities";
import Container from 'typedi';

export class ProcessBuilderService {

    async isBpmnExist(condition: any): Promise<boolean> {
        return await Container.get(DataSource).getRepository(BusinessProcessModeling).count({where: condition}) > 0;
    }

    async getBpmnById(id: string, fields: any[]): Promise<BusinessProcessModeling | null> {
        return Container.get(DataSource).getRepository(BusinessProcessModeling).findOne({select: fields, where: {id}})
    }

    async runCustomizedQuery(queryStatement: string, values: any[] = []): Promise<any> {
        return Container.get(DataSource).manager.query(queryStatement, values);
    }

    async getProcessListDetails(condition: any, userType: string, fields: any[] = [],take,skip,sortObject): Promise<SetResponse> {

        const whereClause: any = {clientId: condition.clientId};

        if (userType === UserType.OWNER) {
            whereClause.createdBy = condition.userId
        }
        const sqlResponse: BusinessProcessModeling[] =
            await Container.get(DataSource).getRepository(BusinessProcessModeling).find({where: whereClause, select: fields ,take: take,
                skip: skip,
                order: sortObject})
        const data = [];
        sqlResponse.forEach((item) => {
            data.push({
                CREATED_BY: item.createdBy,
                ID: item.id,
                PROCESSDATA: JSON.stringify(JSON.parse(item.panelData).process),
                CREATEDON: item.createdOn,
                FORMNAME: JSON.stringify(JSON.parse(item.panelData).formname) === "null" ? '' : JSON.stringify(JSON.parse(item.panelData).formname),
                STATUS: item.status,
                TYPE: item.type,
            })
        });
        const message = !lodash.isEmpty(data) ? null : txt.DATA_NOT_FOUND;

        return CommonHelper.setResponse(StatusType.SUCCESS, message, data);
    }

    async getAllProcess(clientId: number, fields: any[] = [],take,skip,sortObject): Promise<SetResponse> {

        const sqlResponse: BusinessProcessModeling[] = await Container.get(DataSource).getRepository(BusinessProcessModeling).find({
            where: {clientId}, select: fields,take: take,
            skip: skip,
            order: sortObject
        });

        const message = !lodash.isEmpty(sqlResponse) ? null : txt.DATA_NOT_FOUND;
        return CommonHelper.setResponse(StatusType.SUCCESS, message, sqlResponse);
    }

    async getSingleProcessDetail(condition: any): Promise<SetResponse> {
        const sqlResponse: BusinessProcessModeling | null = await Container.get(DataSource).getRepository(BusinessProcessModeling).findOne({where: condition});

        const message = !lodash.isEmpty(sqlResponse) ? null : txt.DATA_NOT_FOUND;
        return CommonHelper.setResponse(StatusType.SUCCESS, message, sqlResponse);
    }

    async getMultipleBpmn(condition: any, fields: any[] = []): Promise<BusinessProcessModeling[]> {
        return Container.get(DataSource).getRepository(BusinessProcessModeling).find({where: condition, select: fields});
    }

    async deleteProcess(condition: any): Promise<SetResponse> {
        const isBpmnExist: boolean = await this.isBpmnExist(condition);

        if (!isBpmnExist) {
            return CommonHelper.setResponse(StatusType.ERROR, txt.DATA_NOT_FOUND)
        }
        const sqlResponse: DeleteResult = await Container.get(DataSource).getRepository(BusinessProcessModeling).delete(condition);
        return CommonHelper.setResponse(StatusType.SUCCESS, txt.PROCESS_DELETE_SUCCESS, sqlResponse);
    }

    async deleteMultipleProcess(listOfIds: string[]): Promise<SetResponse> {
        // const isBpmnExist: boolean = await this.isBpmnExist(In(listOfIds));

        // if (!isBpmnExist) {
        //     return CommonHelper.setResponse(StatusType.ERROR, txt.DATA_NOT_FOUND)
        // }
        const sqlResponse: DeleteResult = await Container.get(DataSource).getRepository(BusinessProcessModeling).delete({id: In(listOfIds)});
        return CommonHelper.setResponse(StatusType.SUCCESS, txt.PROCESS_DELETE_SUCCESS, sqlResponse);
    }

    async getBpmnExecute(condition: any, fields: any[] = []): Promise<BusinessProcessModelingExecute[]> {
        return Container.get(DataSource).getRepository(BusinessProcessModelingExecute).find({where: condition, select: fields, order: {id: 'DESC'}});
    }

    async getBpmnSql(condition: any, fields: any = []): Promise<SetResponse> {

        const sqlResponse: BusinessProcessModelingSql[] = await Container.get(DataSource).getRepository(BusinessProcessModelingSql).find({
            where: condition, select: fields
        });
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async saveOrUpdateBpmn(updateFields: any): Promise<SetResponse> {
        try{
            const sqlResponse: BusinessProcessModeling[] = await Container.get(DataSource).getRepository(BusinessProcessModeling).save(updateFields);
            return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.setResponse(StatusType.ERROR, null, apiErrorResponse);
        }

    }

    async updateBpmn(condition: any, updateFields: any): Promise<SetResponse> {

        const sqlResponse: UpdateResult = await Container.get(DataSource).getRepository(BusinessProcessModeling).update(condition, updateFields);
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async saveOrUpdateBpmnExecute(updateFields: any): Promise<SetResponse> {

        const sqlResponse: BusinessProcessModelingExecute[] = await Container.get(DataSource).getRepository(BusinessProcessModelingExecute).save(updateFields);
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async updateBpmnExecute(condition: any, updateFields: any): Promise<SetResponse> {

        const sqlResponse: UpdateResult = await Container.get(DataSource).getRepository(BusinessProcessModelingExecute).update(condition, updateFields);
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async getSingleCampaign(condition: any, fields: any[]): Promise<any> {

        const sqlResponse: Campaign | null = await Container.get(DataSource).getRepository(Campaign)
            .findOne({where: condition, select: fields});

        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async saveOrUpdateBpmnSql(updateFields: any): Promise<SetResponse> {

        const sqlResponse: BusinessProcessModelingSql[] = await Container.get(DataSource).getRepository(BusinessProcessModelingSql).save(updateFields);
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async getMultipleUser(condition: any, fields: any[] = []): Promise<Users[]> {
        return Container.get(DataSource).getRepository(Users).find({where: condition, select: fields});
    }

    async getMdbClient(condition: any, fields: any[] = []): Promise<MdbClient[]> {
        return Container.get(DataSource).getRepository(MdbClient).find({where: condition, select: fields});
    }
    async getSettingConfig(condition: any, fields: any[] = []): Promise<SettingConfig> {
      return Container.get(DataSource).getRepository(SettingConfig).findOne({where: condition, select: fields});
    }

    async createSubProcess(subProcessData: any): Promise<SetResponse> {
        try {
            for (const [index, subprocess] of subProcessData.entries()) {
            const existingRecord = await Container.get(DataSource).getRepository(BusinessProcessModelingSubProcess)
            .createQueryBuilder('subprocesss') // Optional alias for clarity
            .where('subprocesss.bpmn = :bpmn', { bpmn: subprocess.bpmn })
            .andWhere('subprocesss.activityId = :activityId', { activityId: subprocess.activityId })
            .andWhere('subprocesss.serviceType = :serviceType', { serviceType: subprocess.serviceType })
            .andWhere('JSON_EXTRACT(subprocesss.processData, "$.MailId") = :mailId', { mailId: subprocess.processData.MailId })
            .getOne();
    
            if (!existingRecord){
                // Insert new record
                await Container.get(DataSource).getRepository(BusinessProcessModelingSubProcess).save(subprocess);
            }
            if(index === subProcessData.length - 1){
                return CommonHelper.setResponse(StatusType.SUCCESS, null, null);
            }}
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.setResponse(StatusType.ERROR, null, apiErrorResponse);
        }
    }
    async getLastSubProcessForMailAccount(subProcessData: any): Promise<{ status: boolean; data: any }> {
      try {
          const existingRecord = await Container.get(DataSource).getRepository(BusinessProcessModelingSubProcess)
          .createQueryBuilder('subprocesss') // Optional alias for clarity
          .where('subprocesss.bpmn = :bpmn', { bpmn: subProcessData.bpmn })
          .andWhere('subprocesss.activityId = :activityId', { activityId: subProcessData.activityId })
          .andWhere('subprocesss.serviceType = :serviceType', { serviceType: subProcessData.serviceType })
          // .andWhere('JSON_EXTRACT(subprocesss.processData, "$.MailId") = :mailId', { mailId: subProcessData.MailId })
          .andWhere('JSON_EXTRACT(subprocesss.processData, "$.mailAccount") = :mailAccount', { mailAccount: subProcessData.mailAccount })
          .orderBy('CREATED_ON','DESC')
          .getOne();
          return { status: true, data: existingRecord };
      } catch (error) {
          /**
           * const apiErrorResponse: ApiErrorResponse = {
              error: {
                  error_description: (error as Error).message
              }
          }
           */
          return { status: false, data: {} };
      }
  }
    
    async getNextSubProcess(bpmnId:string,status:string,activityId:string,serviceType:string):Promise<BusinessProcessModelingSubProcess>{
        try {
            return Container.get(DataSource).getRepository(BusinessProcessModelingSubProcess).findOne({where:{bpmn:bpmnId.toString(),status:status.toString(),activityId:activityId.toString(),serviceType:serviceType.toString()},order:{createdOn:'ASC'}});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
           throw apiErrorResponse;
        }
        
    }
    
    async updateSubProcessStatus(subProcessId:string,status:string):Promise<UpdateResult>{
        return Container.get(DataSource)
    .getRepository(BusinessProcessModelingSubProcess)
    .update({ id: subProcessId }, { status });
    }

}
