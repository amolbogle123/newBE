import { Body, Controller, Get, Path, Post, Request, Route, Tags } from "tsoa";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { ActivationData } from "../interfaces/activation.interface";
import { ActivationService } from "../services/activation.service";
import { checkValidity, createActivationKey, validateActivationKey } from "utils/activation.utils";

@Route("activation")
@Tags("Activation")
export class ActivationController extends Controller { 
    private activationService: ActivationService;
    constructor() {
        super();
        this.activationService = new ActivationService();
    }

    @Post()
    async generateActivationKey(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const validation = this.validateActivationRequest(requestBody);
            if (validation.error) {
                this.setStatus(400);
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description: validation.message,
                    },
                    message: validation.message,
                });
            }

            const response: ActivationData = await createActivationKey(requestBody);

            if (response) {
                return CommonHelper.apiSwaggerSuccessResponse({ data: response });
            }

            return CommonHelper.apiSwaggerErrorResponse({
                error: {
                    error_description: "Error in generating activation key",
                },
            });
        } catch (error) {
            console.error("Error :: Get Activation Key :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("/validate")
    async validateActivationKey(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response: ActivationData = await validateActivationKey(requestBody);

            if (response) {
                return CommonHelper.apiSwaggerSuccessResponse({ data: response });
            }

            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse({
                error: {
                    error_description: "Invalid or Incorrect Activation Key",
                },
            });
        } catch (error) {
            console.error("Error :: Validate Activation Key :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("/activate")
    async activateApplication(
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response: any = await this.activationService.activateApplication(requestBody);

            if (response) {
                switch (response) {
                    case "KEYERROR":
                        this.setStatus(400);
                        return CommonHelper.apiSwaggerErrorResponse({
                            error: {
                                error_description: "Invalid / Incorrect Bundle Id or Activation Key",
                            },
                            message: "Invalid / Incorrect Bundle Id or Activation Key",
                        });

                    case "ALREADYACTIVATED":
                        this.setStatus(400);
                        return CommonHelper.apiSwaggerErrorResponse({
                            error: {
                                error_description: "Activation Key is already used",
                            },
                            message: "Activation Key is already used",
                        });

                    case "INVALIDAPPLICATION":
                        this.setStatus(400);
                        return CommonHelper.apiSwaggerErrorResponse({
                            error: {
                                error_description: "Your Bundle Id / Activation Key is not valid for this application",
                            },
                            message: "Your Bundle Id / Activation Key is not valid for this application",
                        });

                    case "ALREADYEXPIRED":
                        this.setStatus(400);
                        return CommonHelper.apiSwaggerErrorResponse({
                            error: {
                                error_description: "You have entered an expired Activation Key / Bundle Id.",
                            },
                            message: "You have entered an expired Activation Key / Bundle Id.",
                        });

                    default:
                        return CommonHelper.apiSwaggerSuccessResponse({ data: response });
                }
            }

            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse({
                error: {
                    error_description: "Invalid or Incorrect Activation Key",
                },
                message: "Invalid or Incorrect Activation Key",
            });
        } catch (error) {
            console.error("Error :: Activate Application :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
                message: "Error in activating application",
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("/app-validation")
    async validateApplication(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const responseData = {
                appEnqStatus: process.env.APP_ENQ ? process.env.APP_ENQ.toLowerCase() === 'true' : true,
                validationStatus: true,
                message: "Application is valid."
            } as any;

            if (process.env.APP_ENQ === undefined || process.env.APP_ENQ.toLowerCase() != "false") {
                const validation = this.validateAppValidationRequest(requestBody);
                if (validation.error) {
                    this.setStatus(400);
                    return CommonHelper.apiSwaggerErrorResponse({
                        error: {
                            error_description: validation.message,
                        },
                        message: validation.message,
                    });
                }

                const response: any = await checkValidity(requestBody.clientId);

                if (response) {
                    switch (response) {
                        case "NLKF":
                            responseData.validationStatus = false;
                            responseData.message = "No License Key Found. Please contact administrator for more information.";
                            return CommonHelper.apiSwaggerSuccessResponse({ data: responseData });
                        case "LKE":
                            responseData.validationStatus = false;
                            responseData.message = "License Key Expired. Please contact administrator for more information.";
                            return CommonHelper.apiSwaggerSuccessResponse({ data: responseData });
                        case "SYSTIMEERR":
                            responseData.validationStatus = false;
                            responseData.message = "System Time Error. Please contact administrator for more information.";
                            return CommonHelper.apiSwaggerSuccessResponse({ data: responseData });
                        case "USAGEEXCEED":
                            responseData.validationStatus = false;
                            responseData.message = "You have exhausted your provided limit. Please contact administrator for more information.";
                            return CommonHelper.apiSwaggerSuccessResponse({ data: responseData });
                        default:
                            responseData.validationStatus = true;
                            responseData.message = "Application is valid.";
                            return CommonHelper.apiSwaggerSuccessResponse({ data: responseData });
                    }
                }

                this.setStatus(400);
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        validationStatus: false,
                        error_description: "Error while validating application",
                    },
                    message: "Error while validating application",
                });
            }

            return CommonHelper.apiSwaggerSuccessResponse({ data: responseData });
        } catch (error) {
            console.error("Error :: Validate Application :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("/purchase-history/:clientId")
    async getPurchaseHistory(
        @Path() clientId: string
    ): Promise<void> {
        try {
            const response: any = await this.activationService.getPurchaseHistory(clientId);

            if (response) {
                return CommonHelper.apiSwaggerSuccessResponse({ data: response });
            }

            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse({
                error: {
                    error_description: "Error in fetching purchase history",
                },
            });
        } catch (error) {
            console.error("Error :: Get Purchase History :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    private validateActivationRequest(requestBody: any): any {
        let errorMessage = null;

        switch (true) {
            case !requestBody.applicationName:
                errorMessage = "Application Name is required";
                break;
            case !requestBody.licenseType:
                errorMessage = "License Type is required";
                break;
            case requestBody.licenseType !== 1024 && requestBody.licenseType !== 2048:
                errorMessage = "Invalid License Type";
                break;
            case requestBody.licenseType === 2048 && !requestBody.bundleInformation:
                errorMessage = "Bundle Information is required for Bundle License.";
                break;
            case requestBody.licenseType === 2048 && !requestBody.bundleInformation.module:
                errorMessage = "Module is required for Bundle License.";
                break;
            case requestBody.licenseType === 2048 && !requestBody.bundleInformation.usage:
                errorMessage = "Usage is required for Bundle License.";
                break;
            case !requestBody.validityType:
                errorMessage = "Validity Type is required";
                break;
            case requestBody.validityType !== "days" && requestBody.validityType !== "time":
                errorMessage = "Invalid Validity Type";
                break;
            case !requestBody.validity:
                errorMessage = "Validity is required";
                break;
            case requestBody.validityType === "days" && typeof requestBody.validity !== "number":
                errorMessage = "Validity should be a number";
                break;
            case requestBody.validityType === "days" && requestBody.validity < 1:
                errorMessage = "Validity should be greater than 0";
                break;
            case requestBody.validityType === "time" && !this.validateDateAndTime(requestBody.validity):
                errorMessage = "Validity should be in 'YYYY-MM-DD HH:MM:SS' format";
                break;
            default:
                return {}; // No errors
        }

        return {
            error: true,
            message: errorMessage,
        };
    }

    private validateAppValidationRequest(requestBody: any): any {
        if (!requestBody.clientId) {
            return {
                error: true,
                message: "Client Id is required",
            };
        }
        return {}; // No errors
    }

    private validateDateAndTime(dateTimeString: string): boolean {
        // Ensure the input is a string
        if (typeof dateTimeString !== 'string') {
            return false;
        }

        // Regular expression to match "YYYY-MM-DD HH:MM:SS" format
        const regex = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/;

        const match = dateTimeString.match(regex);

        if (!match) {
            return false; // Format is incorrect
        }

        return true;
    }
}