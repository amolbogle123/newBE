export interface ActivationData {
    bundleId: string;
    activationKey: string;
}

export interface ActivationDetails {
    applicationName: string;
    licenseType: number;
    accessType: number;
    validity: number;
    validFrom: number;
    validTill: number;
}