-- Create the activation_counter table if it doesn't exist
CREATE TABLE IF NOT EXISTS activation_counter (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ACTIVATION_DATA_ID INT,
    ACTIVATION_DATA_BUNDLE_ID VARCHAR(255),
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(255)
);


DELIMITER //

CREATE PROCEDURE InsertActivationCounter(IN activationDataId INT, IN activationDataBundleId VARCHAR(255), IN createdBy VARCHAR(255))
BEGIN
    DECLARE currentDate DATE;

    -- Get the current date
    SET currentDate = CURDATE();

    -- Insert a new entry into activation_counter
    INSERT INTO activation_counter (ACTIVATION_DATA_ID, ACTIVATION_DATA_BUNDLE_ID, CREATED_AT, CREATED_BY)
    VALUES (activationDataId, activationDataBundleId, currentDate, createdBy);
END //

DELIMITER ;


DELIMITER //

CREATE TRIGGER after_activation_data_insert
AFTER INSERT ON activation_data
FOR EACH ROW
BEGIN
    IF NEW.IS_ACTIVE = 1 THEN
        CALL InsertActivationCounter(NEW.id, NEW.BUNDLE_ID, 'SYSTEM');
    END IF;
END //

DELIMITER ;


-- Enable event scheduler if not already enabled
SET GLOBAL event_scheduler = ON;

-- Drop the existing event if it exists
DROP EVENT IF EXISTS InsertActivationCounterEvent;

-- Create the event to run the stored procedure every 24 hours with created_by as 'system'
CREATE EVENT IF NOT EXISTS InsertActivationCounterEvent
ON SCHEDULE EVERY 1 DAY
DO
    CALL InsertActivationCounter(
        (SELECT id FROM activation_data WHERE status = 1 ORDER BY created_at DESC LIMIT 1), (SELECT BUNDLE_ID FROM activation_data WHERE status = 1 ORDER BY created_at DESC LIMIT 1),
        'system'
    );
