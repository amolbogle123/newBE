import Container from "typedi";
import { DataSource } from "typeorm";
import { validateActivationKey } from "../../../utils/activation.utils";

export class ActivationService {
    async activateApplication(activationData): Promise<any> {
        const activationInformation = await validateActivationKey(activationData);
        if (!activationInformation) {
            return "KEYERROR";
        }

        if (activationInformation.validTill < new Date().getTime()) {
            return "ALREADYEXPIRED";
        }

        if (activationInformation && activationInformation.applicationName !== process.env.APPLICATION_NAME) {
            return "INVALIDAPPLICATION";
        }

        const existingActivationData = await Container.get(DataSource).getRepository('ActivationData').findOne({
            where: { clientId: activationData.clientId, isActive: 1 }
        })

        if (existingActivationData) {
            if (existingActivationData.bundleId !== activationData.bundleId) {
                await Container.get(DataSource).getRepository('ActivationData').update(existingActivationData.id, {
                    isActive: 0,
                    updatedBy: "SYSTEM",
                    updatedAt: new Date()
                });
            } else {
                return "ALREADYACTIVATED";
            }
        }

        const data = {
            clientId: activationData.clientId,
            bundleId: activationData.bundleId,
            activationKey: activationData.activationKey,
            isActive: 1,
            createdBy: activationData.createdBy || 'SYSTEM',
            createdOn: new Date()
        }

        return Container.get(DataSource).getRepository('ActivationData').save(data);
    }

    async getPurchaseHistory(clientId): Promise<any> {
        const response = await Container.get(DataSource).getRepository('ActivationData').find({
            where: { clientId: clientId }, order: { createdOn: 'DESC' }
        });

        if (response.length) {
            return response.map((item) => {
                return {
                    bundleId: item.bundleId,
                    activationInformation: validateActivationKey(item),
                    activatedOn: item.createdOn
                }
            });
        }

        return [];
    }
}