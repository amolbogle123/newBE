import {
    Body,
    Controller,
    Get,
    Patch,
    Post,
    Request,
    Route,
    Security,
    Tags,
} from "tsoa";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";

import fs from "fs";
import { dataSource } from "../../../core/data-source";
import { ClientNavigation, Themes, Users } from "../../../entities";
import { ThemeBuilderHelper } from "../utils/helpers/theme-builder.helper";

@Route("")
@Tags("Theme Builder")
export class CustomComponentEnhancerController extends Controller {
    private themeBuilderHelper: ThemeBuilderHelper = new ThemeBuilderHelper();

    /**
     * Create Custom Enhancer
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Post("enhancer")
    async save(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };

                const payload = {
                    theme: JSON.stringify(requestBody.theme),
                    userid: request.userDetails.id,
                    client_id: request.userDetails.client_id
                };
                const saveResult = await dataSource
                    .getRepository(Themes)
                    .save(payload);
                apiResponse.data = saveResult;

                // let cssDetails = await this.themeBuilderHelper.createCssFile(
                //     requestBody.theme.data,
                //     saveResult.id
                // );
                // if (cssDetails?.status && cssDetails?.filePath) {
                //     apiResponse.data["filePath"] = cssDetails.filePath;
                // }
                await dataSource.getRepository(Users).update({
                    id: request.userDetails.id,
                }, {
                    selectedThemeId: saveResult.id,
                    selectedColorTheme: requestBody.theme.selectedColorTheme
                });

                //update navigation as per theme
                let navigationResult: any = await dataSource
                    .getRepository(ClientNavigation)
                    .findOne({
                        where: {
                            clientId: request.userDetails.client_id
                        },
                    });
                if (navigationResult) {
                    let navigationMenu=JSON.parse(navigationResult.menu);
                                                let themeSideBar =requestBody.theme.data[0].siteTheme.sidebar;
                                                navigationMenu.forEach((nav: any) => {
                                                    nav.sectionActiveBgColor = themeSideBar.activeBgColor;
                                                    nav.sectionActiveTextColor = themeSideBar.activeColor;
                                                    nav.sectionBgColor = themeSideBar.backgroundColor;
                                                    nav.sectionHoverBgColor = themeSideBar.hoverBgColor;
                                                    nav.sectionHoverTextColor =themeSideBar.hoverColor;
                                                    nav.sectionTextColor = themeSideBar.color;
                                                });
                                                await dataSource
                                                .getRepository(ClientNavigation)
                                                .update({ clientId: request.userDetails.client_id }, {menu: JSON.stringify(navigationMenu)});
                }
                this.setStatus(201);
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: apiResponse.data,
                });
            
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update Custom Enhancer
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Patch("enhancer")
    async update(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };
            //update user selected theme
            await dataSource.getRepository(Users).update({
                id: request.userDetails.id,
            }, {
                selectedThemeId: requestBody.themeId,
                selectedColorTheme: requestBody.selectedColorTheme
            });

            let themeResult: any = await dataSource
                .getRepository(Themes)
                .findOne({
                    where: {
                        id: requestBody.themeId
                    },
                });
            if (themeResult) {
                let theme = JSON.parse(themeResult.theme);
                theme.data.forEach(colorTheme => {
                    if(colorTheme.color==requestBody.theme.color){
                        colorTheme.siteTheme=requestBody.theme.siteTheme;
                        colorTheme.primaryColors = requestBody.theme.primaryColors;
                    }
                });

            const payload = {
                theme: JSON.stringify(theme),
            };
                const updateResult = await dataSource
                    .getRepository(Themes)
                    .update(
                        { id: requestBody.themeId },
                        payload
                    );
                apiResponse.data = updateResult;

                //update navigation as per theme
                let navigationResult: any = await dataSource
                    .getRepository(ClientNavigation)
                    .findOne({
                        where: {
                            clientId: request.userDetails.client_id
                        },
                    });
                if (navigationResult) {
                    let navigationMenu=JSON.parse(navigationResult.menu);
                                                let themeSideBar =requestBody.theme.siteTheme.sidebar;
                                                navigationMenu.forEach((nav: any) => {
                                                    nav.sectionActiveBgColor = themeSideBar.activeBgColor;
                                                    nav.sectionActiveTextColor = themeSideBar.activeColor;
                                                    nav.sectionBgColor = themeSideBar.backgroundColor;
                                                    nav.sectionHoverBgColor = themeSideBar.hoverBgColor;
                                                    nav.sectionHoverTextColor =themeSideBar.hoverColor;
                                                    nav.sectionTextColor = themeSideBar.color;
                                                });
                                                await dataSource
                                                .getRepository(ClientNavigation)
                                                .update({ clientId: request.userDetails.client_id }, {menu: JSON.stringify(navigationMenu)});
                }

                // let cssDetails = await this.themeBuilderHelper.createCssFile(
                //     requestBody.theme,
                //     requestBody.themeId
                // );
                // if (cssDetails?.status && cssDetails?.filePath) {
                //     apiResponse.data["filePath"] = cssDetails.filePath;
                // }
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: apiResponse.data,
                });
            } else {
                const apiErrorResponse: ApiErrorResponse = {
                    error: {
                        error_description: "Theme not found",
                    },
                };
                this.setStatus(500);
                return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
             this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Get Custom Enhancer
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("enhancer")
    async get( @Request() request: any): Promise<any> {
        try {
            const apiResponse = {
                data: {
                    themeId: null,
                    theme: null,
                },
            };

            //get user selected theme

            let userThemeResult: any = await dataSource.getRepository(Users).findOne({
                where: {
                    id: request.userDetails.id,
                },
            });
            if(userThemeResult && userThemeResult.selectedThemeId){
                let themeResult: any = await dataSource
                .getRepository(Themes)
                .findOne({
                    where: {
                        id: userThemeResult.selectedThemeId
                    },
                    select: ["theme", "id"]
                });
                if (themeResult) {
                    apiResponse.data.theme = JSON.parse(themeResult.theme);
                    apiResponse.data.theme.selectedColorTheme = userThemeResult.selectedColorTheme;
                    apiResponse.data.themeId = themeResult.id;
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

       /**
     * Update Custom Enhancer Css
     * @param req
     * @param res
     * @param next
     */
       @Security("bearerAuth")
       @Patch("enhancer/css")
    async updateCss(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
                message: "CSS file updated successfully",
            };
            //get user selected themeid
            let userResult: any = await dataSource.getRepository(Users).findOne({
                where: {
                    id: request.userDetails.id,
                },
                select: ["selectedThemeId"]
            });

            let cssFilePath =
                "./public/theme-builder/" +
                userResult.selectedThemeId +
                "-theme.css";
            fs.writeFile(cssFilePath, requestBody.cssData, (err) => {
                if (err) {
                    const apiErrorResponse: ApiErrorResponse = {
                        error: {
                            error_description: (err as Error).message,
                        },
                    };
                 
                    this.setStatus(500);
                    return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
                } else {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        data: apiResponse.data,
                    });
                 
                }
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
