import { Body, Controller, Get, Patch, Path, Route, Security, Tags } from "tsoa";
import { ClientTheme } from "../../../entities";
import dbService from "../../../services/db.service";
import Container from 'typedi';
import { DataSource } from "typeorm";
import {ApiErrorResponse, CommonHelper} from "../../../utils/helpers/common.helper";

@Route('')
@Tags('Theme Builder')
export class ClientThemeController extends Controller{

    /**
     * Update Client Theme
     */
    @Security('bearerAuth')
    @Patch('client-theme/:id')
    async updateClientTheme(
        @Body() requestBody: any,
        @Path() id: string
    ): Promise<any> {
        try {
            const clientTheme = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(ClientTheme),
                { id, ...requestBody }
            );
            return CommonHelper.apiSwaggerSuccessResponse(clientTheme);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    /**
     * Get All Client Themes
     */
    @Get('client-theme')
    @Security('bearerAuth')
    async getAllClientThemes(
    ): Promise<any> {
        try {
            const clientThemes = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ClientTheme),
                {}
            );
            return CommonHelper.apiSwaggerSuccessResponse(clientThemes);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
