
import {
    Body,
    Controller,
    Delete,
    Get,
    Patch,
    Request,
    Route,
    Security,
    Tags,
} from "tsoa";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";

import {
    BTN_THEME_LIST,
} from "../../../modules/theme/utils/constants/theme-builder.constant";
import { ThemeBuilderHelper } from "../../../modules/theme/utils/helpers/theme-builder.helper";

import Container from "typedi";
import { DataSource } from "typeorm";
import { dataSource } from "../../../core/data-source";
import { ClientNavigation, CustomFooter, CustomHeader, ThemeBuilder, Themes } from "../../../entities";
import { CustomBody } from "../../../entities/custom-body";
import { Users } from "../../../entities/users";
@Route("")
@Tags("Theme Builder")
export class ThemeBuilderController extends Controller {
    // Services
    private themeBuilderHelper: ThemeBuilderHelper = new ThemeBuilderHelper();

    /**
     * Get theme
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("theme")
    async getDetails(@Request() request: any): Promise<any> {
        try {
            const apiResponse = {
                data: {
                    config: {},
                    themeId: null,
                },
            };

            let userResult: any = await dataSource.getRepository(Users).findOne({
                where:{
                    clientId: request.userDetails.client_id,
                    isSuperAdmin: 1
                },
                select: ["selectedThemeId","selectedColorTheme"]
            });

            let themeResult: any = await dataSource
                .getRepository(Themes)
                .findOne({
                    where: {
                        id: userResult.selectedThemeId
                    },
                });
            if (themeResult) {
                //get selected color theme
                let themedata=JSON.parse(themeResult.theme);
                themedata.selectedColorTheme=userResult.selectedColorTheme;
                let selectedColorThemeConfig = themedata.data.filter((d)=>d.colorTheme==themedata.selectedColorTheme)[0];
                apiResponse.data.config = selectedColorThemeConfig;
                apiResponse.data.themeId = themeResult.id;
            } else {
                //to be removed
                let themeConfig =
                    await this.themeBuilderHelper.setupThemeSettings(
                        request.userDetails.client_id
                    );
                if (themeConfig?.status && themeConfig?.data) {
                    apiResponse.data.config = JSON.parse(themeConfig.data.config);
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Update theme
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Patch("theme")
    async updateDeatils(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };
            //get user selected theme
            let userResult: any = await dataSource.getRepository(Users).findOne({
                where: {
                    id: request.userDetails.id,
                },
                select: ["selectedThemeId","selectedColorTheme"]
            });

            let themeResult: any = await dataSource.getRepository(Themes).findOne({
                where: {
                    id: userResult.selectedThemeId
                },
            });
            let theme = JSON.parse(themeResult.theme);
            theme.data = theme.data.map(existingTheme => {
                if (existingTheme.colorTheme === requestBody.theme.colorTheme) {
                  return requestBody.theme;
                }
                return existingTheme;
              });
            const payload = {
                theme: JSON.stringify(theme),
            };

            const updateResult = await dataSource
                .getRepository(Themes)
                .update({ client_id: request.userDetails.client_id,id:themeResult.id }, payload);
            apiResponse.data = updateResult;

            // let cssDetails = await this.themeBuilderHelper.createCssFile(
            //     requestBody.theme,
            //     themeResult.id
            // );
            // if (cssDetails?.status && cssDetails?.filePath) {
            //     apiResponse.data["filePath"] = cssDetails.filePath;
            // }

            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     *  Get All theme
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Get("theme/all-theme")
    async getAllThemes(@Request() request: any): Promise<any> {
        try {
            const apiResponse = {
                data: {
                    themes_list: [], // THEMES_LIST,
                    btnthemes_list: BTN_THEME_LIST,
                },
            };
            let themeResult: any = await dataSource
                .getRepository(Themes)
                .find({
                    where: [
                        {userid: '',client_id: request.userDetails.client_id},
                        {client_id: request.userDetails.client_id,userid: request.userDetails.id},
                        
                    ]
                });
            if (themeResult.length > 0) {
                apiResponse.data.themes_list=[];
                themeResult.forEach(element => {
                    element.theme = JSON.parse(element.theme);
                    apiResponse.data.themes_list.push(
                        element
                    );
                });
                
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     *  Delete a theme
     * @param req
     * @param res
     * @param next
     */
    @Security("bearerAuth")
    @Delete("theme")
    async deleteSetting(@Request() request: any,@Body() requestBody: any): Promise<any> {
        try {
            const apiResponse = {
                data: {},
            };
            //check if theme is currently selected by user
            let userResult: any = await dataSource.getRepository(Users).findOne({
                where: {
                    id: request.userDetails.id,
                },
                select: ["selectedThemeId"]
            });
            if(userResult.selectedThemeId == requestBody.id){
                //get default theme
                const defaultThemeResult = await dataSource.getRepository(Themes).findOne({
                    where: {
                        client_id: requestBody.clientId,
                        isDefault: true
                    },
                });
                if(defaultThemeResult){
                    //update user theme
                    await dataSource
                    .getRepository(Users)
                    .update({ id:requestBody.userId}, {selectedThemeId: defaultThemeResult.id});
                }
            }

            const results = await dataSource
                .getRepository(Themes)
                .delete([requestBody.id]);
            apiResponse.data = results;
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }


     /**
     * Get app setting
     * @param req
     * @param res
     * @param next
     */
     @Security("bearerAuth")
     @Get("app-setting")
     async getAppSetting(@Request() request: any): Promise<any> {
         try {
             const apiResponse = {
                 data: {
                     config: {},
                 },
             };
             let themeResult: any = await dataSource
                 .getRepository(ThemeBuilder)
                 .findOne({
                     where: {
                        client_id: request.userDetails.client_id,
                     },
                 });
             if (themeResult) {
                 apiResponse.data.config = JSON.parse(themeResult.config);
             } 
 
             return CommonHelper.apiSwaggerSuccessResponse({
                 data: apiResponse.data,
             });
         } catch (error) {
             const apiErrorResponse: ApiErrorResponse = {
                 error: {
                     error_description: (error as Error).message,
                 },
             };
             this.setStatus(500);
             return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
         }
     }
 
     /**
      * Update app setting
      * @param req
      * @param res
      * @param next
      */
     @Security("bearerAuth")
     @Patch("app-setting")
     async updateAppSetting(
         @Body() requestBody: any,
         @Request() request: any
     ): Promise<any> {
         try {
             const apiResponse = {
                 data: {},
             };
             
             const payload = {
                 config: JSON.stringify(requestBody.config),
             };
 
             const updateResult = await dataSource
                 .getRepository(ThemeBuilder)
                 .update({ client_id: request.userDetails.client_id }, payload);
             apiResponse.data = updateResult;
 
             return CommonHelper.apiSwaggerSuccessResponse({
                 data: apiResponse.data,
             });
         } catch (error) {
             const apiErrorResponse: ApiErrorResponse = {
                 error: {
                     error_description: (error as Error).message,
                 },
             };
             this.setStatus(500);
             return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
         }
     }

     @Security("bearerAuth")
     @Delete("custom-skinning")
        async deleteCustomSkinning(@Request() request: any): Promise<any> {
            try {
                //Reset custom body
                let customBodyResult = await Container.get(DataSource)
                    .getRepository(CustomBody)
                    .delete({clientId: request.userDetails.client_id });
                
                if (!customBodyResult) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "Custom body not found",
                    });
                }

                //reset custom header
                const customHeaderResult = await Container.get(DataSource)
                    .getRepository(CustomHeader)
                    .delete({clientId: request.userDetails.client_id });
                if(!customHeaderResult) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "Custom header not found",
                    });
                }

                //reset custom footer
                const customFooterResult = await Container.get(DataSource)
                    .getRepository(CustomFooter)
                    .delete({clientId: request.userDetails.client_id });
                if(!customFooterResult) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "Custom footer not found",
                    });
                }

                //reset typography & sidebar
                //get currently selected theme
                const userResult = await Container.get(DataSource).getRepository(Users).findOne({
                    where:{id: request.userDetails.id},
                    select: ["selectedThemeId"]
                });
                if(!userResult?.selectedThemeId) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "Selected theme not found",
                    });
                }

                //get default theme
                const defaultThemeResult = await Container.get(DataSource).getRepository(Themes).findOne({
                    where: {
                        client_id: request.userDetails.client_id,
                        isDefault: true
                    },
                });
                //get selected theme
                const selectedThemeResult = await Container.get(DataSource).getRepository(Themes).findOne({
                    where: {
                        id: userResult.selectedThemeId
                    },
                });
                if(!defaultThemeResult) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "Default theme not found",
                    });
                }

                let theme = JSON.parse(defaultThemeResult.theme);
                if(defaultThemeResult.id == selectedThemeResult.id){
                    theme.data.fontInfo = theme.data.defaultFontInfo;
                }
                
                //update user theme
                const userThemeUpdateResult = await Container.get(DataSource)
                    .getRepository(Users)
                    .update({ id:request.userDetails.id}, {selectedThemeId: defaultThemeResult.id});

                //update theme 
                await Container.get(DataSource)
                    .getRepository(Themes)
                    .update({ id: defaultThemeResult.id }, {theme: JSON.stringify(theme)});

                if(!userThemeUpdateResult) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "User theme not update",
                    });
                }

                //reset sidebar
                //get navigation menu theme
                const navigationResult = await Container.get(DataSource).getRepository(ClientNavigation).findOne({
                    where: {
                        clientId: request.userDetails.client_id
                    },
                });
                
                if(!navigationResult) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "Navigation not found",
                    });
                }

                let navigationMenu=JSON.parse(navigationResult.menu);
                let themeSideBar =theme.data.siteTheme.sidebar;
                navigationMenu.forEach((nav: any) => {
                    nav.sectionActiveBgColor = themeSideBar.activeBgColor;
                    nav.sectionActiveTextColor = themeSideBar.activeColor;
                    nav.sectionBgColor = themeSideBar.backgroundColor;
                    nav.sectionHoverBgColor = themeSideBar.hoverBgColor;
                    nav.sectionHoverTextColor =themeSideBar.hoverColor;
                    nav.sectionTextColor = themeSideBar.color;
                });
                const navigationUpdateResult = await Container.get(DataSource)
                    .getRepository(ClientNavigation)
                    .update({ clientId: request.userDetails.client_id }, {menu: JSON.stringify(navigationMenu)});

                if(!navigationUpdateResult) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        message: "Navigation not update",
                    });
                }

                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Custom Skinning reset successfully",
                });
            } catch (error) {
                const apiErrorResponse: ApiErrorResponse = {
                    error: {
                        error_description: (error as Error).message,
                    },
                };
                this.setStatus(500);
                return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
            }
        }
}
