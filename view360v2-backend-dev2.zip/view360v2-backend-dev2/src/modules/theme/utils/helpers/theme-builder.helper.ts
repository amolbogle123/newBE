import fs from "fs";

import { CSS_CONFIG, CSS_FILE_PATH } from "../constants/theme-builder.constant";
import { ThemeBuilder } from "../../../../entities";
import { dataSource } from "../../../../core/data-source";

const CSS_PREFIX = ".v-";

export class ThemeBuilderHelper {

    async setupThemeSettings(clientid): Promise<any> {
        const apiResponse = { status: false, data: {} };

        const themeBuilderModal = new ThemeBuilder();
        themeBuilderModal.client_id = clientid;
        themeBuilderModal.config = JSON.stringify(CSS_CONFIG);
        const result = await dataSource.manager.save(themeBuilderModal);
        if (result?.id) {
            apiResponse.status = true;
            themeBuilderModal.id = result.id;
            apiResponse.data = themeBuilderModal;

            await this.createCssFile(CSS_CONFIG, clientid);
        }

        return apiResponse;
    }

    async createCssFile(dataSet: any, themeId): Promise<any> {
        return new Promise(async(resolve) => {
            let cssStyle = "",
                filePath = CSS_FILE_PATH.replace("[THEME_ID]", themeId),
                fontFilePath = "";

            const mapperUploadDir = "./public/theme-builder/";
            if (!fs.existsSync(mapperUploadDir)) {
                fs.mkdirSync(mapperUploadDir);
            }
            const keys = Object.keys(dataSet.siteTheme);
            for (const [i, c] of keys.entries()) {
                switch (c) {
                    case "header":
                        cssStyle += await this.generateHeaderCss(dataSet, c);
                        break;
                    case "footer":
                        cssStyle +=
                            "div.footer {background-color:" +
                            dataSet.siteTheme[c].backgroundColor +
                            " !important; color:" +
                            dataSet.siteTheme[c].textColor +
                            " !important;}";
                        break;
                    case "btnThemes":
                        cssStyle += await this.generateBtnThemesCss(dataSet, c);
                        break;
                    case "otherTheme":
                        cssStyle +=
                            CSS_PREFIX +
                            "border-radius {border-radius: " +
                            dataSet[c].borderRadius +
                            "px !important;}";

                        if (dataSet[c].typography) {
                            fontFilePath =
                                `@import "https://fonts.googleapis.com/css2?family=` +
                                dataSet[c].typography.replace(/ /g, "+") +
                                `"; `;
                        }
                        if (dataSet[c].typography) {
                            cssStyle +=
                                CSS_PREFIX +
                                `body {font-family: ` +
                                dataSet[c].typography +
                                ` !important; font-size: ` +
                                dataSet[c].fontSize +
                                `px !important;}`;
                        }
                        break;
                    case "componentTheme":
                        cssStyle += await this.generateComponentThemeCss(dataSet, c);
                        break;
                    case "datatableTheme":
                        cssStyle += await this.generateDataTableThemeCss(dataSet, c);
                        break;
                    case "inputTheme":
                        cssStyle += await this.generateInputThemeCss(dataSet, c);
                        break;
                    case "sidebar":
                        cssStyle += await this.generateSectionThemeCss(dataSet, c);
                        break;
                    case "tableTheme":
                        cssStyle += await this.generateTableThemeCss(dataSet, c);
                        break;
                    case "editors":
                        cssStyle += await this.generateEditorsCss(dataSet, c);
                        break;
                    case "tabs":
                        cssStyle += await this.generateTabCss(dataSet, c);
                        break;
                    case "modal":
                        cssStyle += await this.generateModalCss(dataSet, c);
                        break;
                }
                
                if (i == Object.keys(dataSet.siteTheme).length - 1) {
                    fs.writeFileSync("./" + filePath, fontFilePath + cssStyle);
                }
                resolve({ status: true, filePath });
            }
        });
    }
    generateHeaderCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";
            cssStyle +=
                "header {background-color:" +
                dataSet.siteTheme[c].backgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].textColor +
                " !important;}";
            /**
             * cssStyle +=
                CSS_PREFIX +
                "header .navbar-nav .nav-link {color:" +
                dataSet.siteTheme[c].textColor +
                " !important;}";
            cssStyle +=
                CSS_PREFIX +
                "header .navbar-nav .active .nav-link {background-color:" +
                dataSet.siteTheme[c].activeBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].activeTextColor +
                " !important;}";
            cssStyle +=
                CSS_PREFIX +
                "header .navbar-nav .nav-link:hover {background-color:" +
                dataSet.siteTheme[c].hoverBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].hoverTextColor +
                " !important;}";
            cssStyle +=
                CSS_PREFIX +
                "header .navbar-nav .active .nav-link:hover {background-color:" +
                dataSet.siteTheme[c].hoverActiveBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].hoverActiveTextColor +
                " !important;}";
             */
            resolve(cssStyle);
        });
    }
    generateBtnThemesCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";
            Object.keys(dataSet.siteTheme[c]).forEach((s) => {
                if (!s.includes("EXTRA_CSS_")) {
                    let className = `${s === "default" ? "theme" : s}`;
                    let extraCss = "";
                    let borderRadiusCss = "";
                    if (dataSet.siteTheme[c][`EXTRA_CSS_${s}`]) {
                        extraCss = dataSet.siteTheme[c][`EXTRA_CSS_${s}`];
                    }
                    if(dataSet.siteTheme.btnStyle == 'Rounded'){
                        borderRadiusCss = "border-radius: "+dataSet.siteTheme.btnBorderRadius+" !important;";
                    }

                    cssStyle +=
                        ".btn-" +
                        className +
                        "{background-color:" +
                        dataSet.siteTheme[c][s].backgroundColor +
                        " !important;color:" +
                        dataSet.siteTheme[c][s].textColor +
                        " !important;border-color:" +
                        dataSet.siteTheme[c][s].borderColor +
                        " !important;" +
                        borderRadiusCss +
                        extraCss + "}";

                    cssStyle += ".btn-" +
                        className +
                        ":hover{background-color:" +
                        dataSet.siteTheme[c][s].hoverBackgroundColor +
                        " !important;color:" +
                        dataSet.siteTheme[c][s].hoverTextColor +
                        " !important;border-color:" +
                        dataSet.siteTheme[c][s].hoverBorderColor +
                        " !important;}";

                    cssStyle +=
                        ".btn-outline-" +
                        className +
                        "{color:" +
                        dataSet.siteTheme[c]['light'].textColor +
                        " !important;background-color:" +
                        dataSet.siteTheme[c]['light'].backgroundColor +
                        " !important;border-color:" +
                        dataSet.siteTheme[c]['light'].borderColor +
                        " !important;" +
                        extraCss + "}";

                    cssStyle +=
                        " .swal2-container .swal2-confirm.swal2-styled {background-color:" +
                        dataSet.siteTheme[c]['primary']?.backgroundColor +
                        " !important;color:" +
                        dataSet.siteTheme[c]['primary']?.textColor +
                        " !important;border-color:" +
                        dataSet.siteTheme[c]['primary']?.borderColor +
                        " !important;" +
                        extraCss + "}";

                    cssStyle +=
                        ".swal2-container .swal2-cancel.swal2-styled {color:" +
                        dataSet.siteTheme[c]['light'].textColor +
                        " !important;background-color:" +
                        dataSet.siteTheme[c]['light'].backgroundColor +
                        " !important;border-color:" +
                        dataSet.siteTheme[c]['light'].backgroundColor +
                        " !important;" +
                        extraCss + "}";
                }
            });

            resolve(cssStyle);
        });
    }
    generateComponentThemeCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";
            cssStyle +=
                CSS_PREFIX +
                "modal .modal-header {background-color:" +
                dataSet[c].headerBackgroundColor +
                " !important; color:" +
                dataSet[c].headerColor +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "modal .modal-body {background-color:" +
                dataSet[c].backgroundColor +
                " !important; color:" +
                dataSet[c].color +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "modal .modal-footer {background-color:" +
                dataSet[c].footerBackgroundColor +
                " !important; color:" +
                dataSet[c].footerColor +
                " !important;}";

            resolve(cssStyle);
        });
    }
    generateDataTableThemeCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";
            cssStyle +=
                CSS_PREFIX +
                "datatable-header, " +
                CSS_PREFIX +
                "datatable .dataTable thead tr {background-color:" +
                dataSet[c].headerBackgroundColor +
                " !important; color:" +
                dataSet[c].headerColor +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "datatable-tbody, " +
                CSS_PREFIX +
                "datatable .dataTable tbody tr {background-color:" +
                dataSet[c].backgroundColor +
                " !important; color:" +
                dataSet[c].color +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "datatable-primary {background-color:" +
                dataSet[c].tableRowPrimary.backgroundColor +
                " !important; color:" +
                dataSet[c].tableRowPrimary.color +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "datatable-success {background-color:" +
                dataSet[c].tableRowSuccess.backgroundColor +
                " !important; color:" +
                dataSet[c].tableRowSuccess.color +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "datatable-danger {background-color:" +
                dataSet[c].tableRowDanger.backgroundColor +
                " !important; color:" +
                dataSet[c].tableRowDanger.color +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "datatable-secondary {background-color:" +
                dataSet[c].tableRowSecondary.backgroundColor +
                " !important; color:" +
                dataSet[c].tableRowSecondary.color +
                " !important;}";

            resolve(cssStyle);
        });
    }
    generateInputThemeCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";
            Object.keys(dataSet[c]).forEach((s) => {
                switch (s) {
                    case "textbox":
                        cssStyle +=
                            CSS_PREFIX +
                            s +
                            ", " +
                            CSS_PREFIX +
                            s +
                            ":focus {border-color:" +
                            dataSet[c][s].borderColor +
                            " !important; color:" +
                            dataSet[c][s].color +
                            " !important;}";
                        break;
                    case "dropdown":
                        cssStyle +=
                            CSS_PREFIX +
                            s +
                            " .ng-select-container {border-color:" +
                            dataSet[c][s].borderColor +
                            " !important; color:" +
                            dataSet[c][s].color +
                            " !important;}";
                        cssStyle +=
                            CSS_PREFIX +
                            s +
                            " .ng-dropdown-panel {border-color:" +
                            dataSet[c][s].borderColor +
                            " !important;}";
                        cssStyle +=
                            CSS_PREFIX +
                            s +
                            " .ng-option-label {color:" +
                            dataSet[c][s].color +
                            " !important;}";
                        break;
                    case "datepicker":
                        cssStyle +=
                            CSS_PREFIX +
                            s +
                            ` .bs-datepicker-container .bs-datepicker-head {background-color:` +
                            dataSet[c][s].backgroundColor +
                            " !important; color:" +
                            dataSet[c][s].color +
                            ` !important;}`;
                        cssStyle +=
                            CSS_PREFIX +
                            s +
                            ` .bs-datepicker-body table td {color:` +
                            dataSet[c][s].color +
                            ` !important;}`;
                        cssStyle +=
                            CSS_PREFIX +
                            s +
                            ` .bs-datepicker-body table td span.selected {background-color:` +
                            dataSet[c][s].backgroundColor +
                            " !important; color:" +
                            dataSet[c][s].color +
                            " !important;}";
                        break;
                }
            });

            resolve(cssStyle);
        });
    }
    generateSectionThemeCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";
            
            /**
             * cssStyle +=
                CSS_PREFIX +
                "header {background-color:" +
                dataSet[c]["header"].backgroundColor +
                " !important;}";
            cssStyle +=
                CSS_PREFIX +
                "header .navbar-nav .nav-link { color:" +
                dataSet[c]["header"].color +
                " !important;} ";

            cssStyle +=
                CSS_PREFIX +
                "header .navbar-nav .active .nav-link {background-color:" +
                dataSet[c]["header"].activeBgColor +
                " !important; color:" +
                dataSet[c]["header"].activeColor +
                " !important;} ";

            cssStyle +=
                CSS_PREFIX +
                "header .navbar-nav .nav-link:hover {background-color:" +
                dataSet[c]["header"].hoverBgColor +
                " !important; color:" +
                dataSet[c]["header"].hoverColor +
                " !important;} ";

            cssStyle +=
                CSS_PREFIX +
                "header .navbar-nav .active .nav-link:hover {background-color:" +
                dataSet[c]["header"].hoverActiveBgColor +
                " !important; color:" +
                dataSet[c]["header"].hoverActiveColor +
                " !important;} ";

            cssStyle +=
                CSS_PREFIX +
                "footer {background-color:" +
                dataSet[c]["footer"].backgroundColor +
                " !important; color:" +
                dataSet[c]["footer"].color +
                " !important;}";
             */

            cssStyle +=
                " div.p-2.section-wrapper.collapse.show {background:" +
                dataSet.siteTheme[c].backgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].color +
                " !important;"+
                "--section-active-bgcolor:" +dataSet.siteTheme[c].activeBgColor+
                " !important;--section-active-color:" +dataSet.siteTheme[c].activeColor+
                " !important;--section-hover-bgcolor:" +dataSet.siteTheme[c].hoverBgColor+
                " !important;--section-hover-color:" +dataSet.siteTheme[c].hoverColor+
                " !important;}";

            /**
             * cssStyle +=
                CSS_PREFIX +
                "sidebar .list-group-item-action, " +
                CSS_PREFIX +
                "sidebar .top-sidebar-link {color:" +
                dataSet[c]["sidebar"].color +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "sidebar .active, " +
                CSS_PREFIX +
                "sidebar .list-group-item-action.active {background-color:" +
                dataSet[c]["sidebar"].activeBgColor +
                " !important; color:" +
                dataSet[c]["sidebar"].activeColor +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "sidebar a:hover, " +
                CSS_PREFIX +
                "sidebar .list-group-item-action:hover {background-color:" +
                dataSet[c]["sidebar"].hoverBgColor +
                " !important; color:" +
                dataSet[c]["sidebar"].hoverColor +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "sidebar .active:hover, " +
                CSS_PREFIX +
                "sidebar .list-group-item-action.active:hover {background-color:" +
                dataSet[c]["sidebar"].hoverActiveBgColor +
                " !important; color:" +
                dataSet[c]["sidebar"].hoverActiveColor +
                " !important;}";

            cssStyle +=
                CSS_PREFIX +
                "container {background-color:" +
                dataSet[c]["container"].backgroundColor +
                " !important; color:" +
                dataSet[c]["container"].color +
                " !important;}";
             */

            resolve(cssStyle);
        });
    }
    generateTableThemeCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";

            cssStyle +=
                ".p-datatable .p-datatable-tbody > tr, .p-datatable .p-paginator-bottom {background-color:" +
                dataSet.siteTheme[c].backgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].textColor +
                " !important; border-color:" +
                dataSet.siteTheme[c].borderColor +
                " !important;";
            cssStyle += "}";

            cssStyle += ".p-datatable .p-datatable-wrapper .p-datatable-thead > tr > th, .p-datatable .p-datatable-wrapper .p-datatable-tbody > tr > td, .app-table {border-color:"+
                dataSet.siteTheme[c].borderColor +
                " !important;";
            cssStyle += "}";

            cssStyle += ".p-datatable-thead > tr > th { background-color:"+dataSet.siteTheme[c].headerBgColor+" !important; color:"+dataSet.siteTheme[c].headerTextColor+" !important;font-weight:"+dataSet.siteTheme[c].headerTextWeight+" !important;}";


            if (dataSet.siteTheme[c][`EXTRA_CSS_table`]) {
                cssStyle += dataSet.siteTheme[c][`EXTRA_CSS_table`];
            }
            cssStyle += "}";

            cssStyle +=
                "table thead.bg-gray,table thead.bg-gray tr th, .app-table .p-datatable .p-datatable-thead > tr > th, .app-table .p-datatable .p-datatable-header-{font-weight:" +
                dataSet.siteTheme[c].headerTextWeight +
                " !important; color:" +
                dataSet.siteTheme[c].headerTextColor +
                " !important; background-color:" +
                dataSet.siteTheme[c].headerBgColor +
                " !important;";

            if (dataSet.siteTheme[c][`EXTRA_CSS_table th`]) {
                cssStyle += dataSet.siteTheme[c][`EXTRA_CSS_table th`];
            }
            cssStyle += "}";

            resolve(cssStyle);
        });
    }
    generateEditorsCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";

            cssStyle +=
                ".form-control:not(.is-invalid, .is-valid), .ng-select .ng-select-container,.input-group-text{background-color:" +
                dataSet.siteTheme[c]["textBox"].backgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c]["textBox"].textColor +
                " !important; border-color:" +
                dataSet.siteTheme[c]["textBox"].borderColor +
                " !important;";

            if (dataSet.siteTheme[c]["textBox"][`EXTRA_CSS_inputText`]) {
                cssStyle += dataSet.siteTheme[c]["textBox"][`EXTRA_CSS_inputText`];
            }
            cssStyle += "}";

            cssStyle +=
                ".form-select, .ng-dropdown-panel .ng-dropdown-panel-items .ng-option:not(.ng-option-selected, .ng-option-marked) {background-color:" +
                dataSet.siteTheme[c]["selectList"].backgroundColor +
                " !important;" +
                "color:" +
                dataSet.siteTheme[c]["selectList"].textColor +
                " !important; border-color:" +
                dataSet.siteTheme[c]["selectList"].borderColor +
                " !important;";

            if (dataSet.siteTheme[c]["selectList"][`EXTRA_CSS_select`]) {
                cssStyle += dataSet.siteTheme[c]["selectList"][`EXTRA_CSS_select`];
            }
            cssStyle += "}";
            resolve(cssStyle);
        });
    }
    generateTabCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";
            cssStyle +=
            ".vertical-tab .list-group-item {background-color:" +
            dataSet.siteTheme[c].backgroundColor +
            " !important; color:" +
            dataSet.siteTheme[c].textColor +
            " !important;}";
            
            cssStyle +=
                "ul.custom-tabs li a.active  {background-color:" +
                dataSet.siteTheme[c].activeBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].activeTextColor +
                " !important;  border-color:" +
                dataSet.siteTheme[c].activeBorderColor +
                " !important;}";
            cssStyle +=
                ".vertical-tab  .list-group-item.active  {background-color:" +
                dataSet.siteTheme[c].activeBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].activeTextColor +
                " !important;";

            cssStyle += "}";
            cssStyle += "ul.custom-tabs li:hover {background-color:" +
                dataSet.siteTheme[c].hoverBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].hoverTextColor +
                " !important;}";
            cssStyle += ".vertical-tab .list-group-item:not(.active):hover {background-color:" +
                dataSet.siteTheme[c].hoverBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].hoverTextColor +
                " !important;}";

            if (dataSet.siteTheme[c]['backgroundColor'] && dataSet.siteTheme[c]['textColor'] && dataSet.siteTheme[c]['borderColor']) {
                cssStyle +=
                    "ul.custom-tabs li a {background-color:" +
                    dataSet.siteTheme[c].backgroundColor + " !important;" +
                    "color : " + dataSet.siteTheme[c].textColor + "!important;}"
            }

            if (dataSet.siteTheme[c][`EXTRA_CSS_tabs`]) {
                cssStyle += dataSet.siteTheme[c][`EXTRA_CSS_tabs`];
            }
            resolve(cssStyle);
        });
    }
    generateModalCss(dataSet, c) {
        return new Promise((resolve) => {
            let cssStyle = "";

            cssStyle +=
                ".modal-header {background-color:" +
                dataSet.siteTheme[c].headerBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].headerTextColor +
                " !important;";

            if (dataSet.siteTheme[c][`EXTRA_CSS_modalHeader`]) {
                cssStyle += dataSet.siteTheme[c][`EXTRA_CSS_modalHeader`];
            }
            cssStyle += "}";

            cssStyle +=
                ".modal-body {background-color:" +
                dataSet.siteTheme[c].bodyBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].bodyTextColor +
                " !important;";

            if (dataSet.siteTheme[c][`EXTRA_CSS_modalBody`]) {
                cssStyle += dataSet.siteTheme[c][`EXTRA_CSS_modalBody`];
            }
            cssStyle += "}";
            cssStyle +=
                ".modal-footer {background-color:" +
                dataSet.siteTheme[c].footerBackgroundColor +
                " !important; color:" +
                dataSet.siteTheme[c].footerTextColor +
                " !important;";
            if (dataSet.siteTheme[c][`EXTRA_CSS_modalFooter`]) {
                cssStyle += dataSet.siteTheme[c][`EXTRA_CSS_modalFooter`];
            }
            cssStyle += "}";
            resolve(cssStyle);
        });
    }
}
