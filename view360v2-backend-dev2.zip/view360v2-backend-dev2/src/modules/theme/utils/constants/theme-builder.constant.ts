export const CSS_FILE_PATH: string =
  "public/theme-builder/[THEME_ID]-theme.css";

export const CSS_CONFIG: any = {
  "id": "default",
  "name": "default",
  "img": "#0b7ac6",
  "data": {
    "sidebarLayout": "flat",
    "siteInfo": {
      "logo": "assets/img/logo.png",
      "logoSmall": "assets/img/logo-small.png"
    },
    "fontInfo": {
      "fontFamily": "Poppins",
      "customFont": "",
      "customFontName": "",
      "fontSize": "14px",
      "lineHeight": "default",
      "letterSpacing": "default"
    },
    "siteTheme": {
      "themeName": "default",
      "btnThemeName": "default",
      "colorTheme": "light",
      "header": {
        "backgroundColor": "#fff",
        "color": "#3F4254",
        "hoverBgColor": "#000",
        "hoverColor": "#000",
        "activeBgColor": "#00000000",
        "activeColor": "#1580c2"
      },
      "sidebar": {
        "backgroundColor": "#fff",
        "color": "#3F4254",
        "hoverBgColor": "#000",
        "hoverColor": "#000",
        "activeBgColor": "#00000000",
        "activeColor": "#1580c2"
      },
      "btnThemes": {
        "default": {
          "textColor": "#ffffff",
          "borderColor": "#0b7ac6",
          "backgroundColor": "#0b7ac6"
        },
        "primary": {
          "textColor": "#ffffff",
          "borderColor": "#007bff",
          "backgroundColor": "#007bff"
        },
        "secondary": {
          "textColor": "#ffffff",
          "borderColor": "#6c757d",
          "backgroundColor": "#6c757d"
        },
        "dark": {
          "textColor": "#ffffff",
          "borderColor": "#343a40",
          "backgroundColor": "#343a40"
        },
        "danger": {
          "textColor": "#ffffff",
          "borderColor": "#dc3545",
          "backgroundColor": "#dc3545"
        },
        "light": {
          "textColor": "#212529",
          "borderColor": "#f8f9fa",
          "backgroundColor": "#f8f9fa"
        },
        "warning": {
          "textColor": "#212529",
          "borderColor": "#ffc107",
          "backgroundColor": "#ffc107"
        },
        "success": {
          "textColor": "#ffffff",
          "borderColor": "#28a745",
          "backgroundColor": "#28a745"
        },
        "info": {
          "textColor": "#ffffff",
          "borderColor": "#17a2b8",
          "backgroundColor": "#17a2b8"
        }
      },
      "tableTheme": {
        "textColor": "#212529",
        "backgroundColor": "#ffffff",
        "borderColor": "#dee2e6",
        "headerBgColor": "#eaf1fb",
        "headerTextColor": "#212529",
        "headerTextWeight": "500"
      },
      "editors": {
        "textBox": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#ced4da",
          "placeholderColor": "#a9acaf",
          "borderFocusColor": "#80bdff"
        },
        "selectList": {
          "backgroundColor": "#ffffff"
        },
        "calendar": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#ced4da"
        }
      },
      "tabs": {
        "textColor": "#212529",
        "backgroundColor": "#ffffff",
        "borderColor": "#c2cfdd",
        "activeTextColor": "#212529",
        "activeBackgroundColor": "#eaf1fb",
        "activeBorderColor": "#0b7ac6"
      },
      "modal": {
        "headerTextColor": "#212529",
        "headerBackgroundColor": "#ffffff",
        "headerBorderColor": "#dedede",
        "bodyTextColor": "#212529",
        "bodyBackgroundColor": "#ffffff",
        "bodyBorderColor": "#dedede"
      }
    }
  }
};

export const THEMES_LIST: any = [
  {
    "id": "default",
    "name": "default",
    "img": "#0b7ac6",
    "data": {
      "sidebarLayout": "flat",
      "siteInfo": {
        "logo": "assets/img/logo.png",
        "logoSmall": "assets/img/logo-small.png"
      },
      "fontInfo": {
        "fontFamily": "Poppins",
        "customFont": "",
        "customFontName": "",
        "fontSize": "14px",
        "lineHeight": "default",
        "letterSpacing": "default"
      },
      "siteTheme": {
        "themeName": "default",
        "btnThemeName": "default",
        "colorTheme": "light",
        "header": {
          "backgroundColor": "#fff",
          "color": "#3F4254",
          "hoverBgColor": "#000",
          "hoverColor": "#000",
          "activeBgColor": "#00000000",
          "activeColor": "#1580c2"
        },
        "sidebar": {
          "backgroundColor": "#fff",
          "color": "#3F4254",
          "hoverBgColor": "#000",
          "hoverColor": "#000",
          "activeBgColor": "#00000000",
          "activeColor": "#1580c2"
        },
        "btnThemes": {
          "default": {
            "textColor": "#ffffff",
            "borderColor": "#0b7ac6",
            "backgroundColor": "#0b7ac6"
          },
          "primary": {
            "textColor": "#ffffff",
            "borderColor": "#007bff",
            "backgroundColor": "#007bff"
          },
          "secondary": {
            "textColor": "#ffffff",
            "borderColor": "#6c757d",
            "backgroundColor": "#6c757d"
          },
          "dark": {
            "textColor": "#ffffff",
            "borderColor": "#343a40",
            "backgroundColor": "#343a40"
          },
          "danger": {
            "textColor": "#ffffff",
            "borderColor": "#dc3545",
            "backgroundColor": "#dc3545"
          },
          "light": {
            "textColor": "#212529",
            "borderColor": "#f8f9fa",
            "backgroundColor": "#f8f9fa"
          },
          "warning": {
            "textColor": "#212529",
            "borderColor": "#ffc107",
            "backgroundColor": "#ffc107"
          },
          "success": {
            "textColor": "#ffffff",
            "borderColor": "#28a745",
            "backgroundColor": "#28a745"
          },
          "info": {
            "textColor": "#ffffff",
            "borderColor": "#17a2b8",
            "backgroundColor": "#17a2b8"
          }
        },
        "tableTheme": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#dee2e6",
          "headerBgColor": "#eaf1fb",
          "headerTextColor": "#212529",
          "headerTextWeight": "500"
        },
        "editors": {
          "textBox": {
            "textColor": "#212529",
            "backgroundColor": "#ffffff",
            "borderColor": "#ced4da",
            "placeholderColor": "#a9acaf",
            "borderFocusColor": "#80bdff"
          },
          "selectList": {
            "backgroundColor": "#ffffff"
          },
          "calendar": {
            "textColor": "#212529",
            "backgroundColor": "#ffffff",
            "borderColor": "#ced4da"
          }
        },
        "tabs": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#c2cfdd",
          "activeTextColor": "#212529",
          "activeBackgroundColor": "#eaf1fb",
          "activeBorderColor": "#0b7ac6"
        },
        "modal": {
          "headerTextColor": "#212529",
          "headerBackgroundColor": "#ffffff",
          "headerBorderColor": "#dedede",
          "bodyTextColor": "#212529",
          "bodyBackgroundColor": "#ffffff",
          "bodyBorderColor": "#dedede"
        }
      }
    }
  },
  {
    "id": "light",
    "name": "light",
    "img": "#eef0ff",
    "data": {
      "sidebarLayout": "flat",
      "siteInfo": {
        "logo": "assets/img/logo.png",
        "logoSmall": "assets/img/logo-small.png"
      },
      "fontInfo": {
        "fontFamily": "Poppins",
        "customFont": "",
        "customFontName": "",
        "fontSize": "14px",
        "lineHeight": "default",
        "letterSpacing": "default"
      },
      "siteTheme": {
        "themeName": "light",
        "btnThemeName": "default",
        "colorTheme": "light",
        "header": {
          "backgroundColor": "#fff",
          "color": "#3F4254",
          "hoverBgColor": "#00000000",
          "hoverColor": "#000000",
          "activeBgColor": "#00000000",
          "activeColor": "#000000"
        },
        "sidebar": {
          "backgroundColor": "#fff",
          "color": "#3F4254",
          "hoverBgColor": "#00000000",
          "hoverColor": "#000000",
          "activeBgColor": "#00000000",
          "activeColor": "#000000"
        },
        "btnThemes": {
          "default": {
            "textColor": "#3699FF",
            "borderColor": "#eef0ff",
            "backgroundColor": "#eef0ff"
          },
          "primary": {
            "textColor": "#3699FF",
            "borderColor": "#E1F0FF",
            "backgroundColor": "#E1F0FF"
          },
          "secondary": {
            "textColor": "#3F4254",
            "borderColor": "#E4E6EF",
            "backgroundColor": "#E4E6EF"
          },
          "dark": {
            "textColor": "#181C32",
            "borderColor": "#D1D3E",
            "backgroundColor": "#D1D3E"
          },
          "danger": {
            "textColor": "#F64E60",
            "borderColor": "#FFE2E5",
            "backgroundColor": "#FFE2E5"
          },
          "light": {
            "textColor": "#7a7a7a",
            "borderColor": "#F3F6F9",
            "backgroundColor": "#F3F6F9"
          },
          "warning": {
            "textColor": "#FFA800",
            "borderColor": "#FFF4DE",
            "backgroundColor": "#FFF4DE"
          },
          "success": {
            "textColor": "#1BC5BD",
            "borderColor": "#C9F7F5",
            "backgroundColor": "#C9F7F5"
          },
          "info": {
            "textColor": "#8950FC",
            "borderColor": "#EEE5FF",
            "backgroundColor": "#EEE5FF"
          }
        },
        "tableTheme": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#dee2e6",
          "headerBgColor": "#eef0ff",
          "headerTextColor": "#212529",
          "headerTextWeight": "500"
        },
        "editors": {
          "textBox": {
            "textColor": "#212529",
            "backgroundColor": "#ffffff",
            "borderColor": "#ced4da",
            "placeholderColor": "#a9acaf",
            "borderFocusColor": "#80bdff"
          },
          "selectList": {
            "backgroundColor": "#ffffff"
          },
          "calendar": {
            "textColor": "#212529",
            "backgroundColor": "#ffffff",
            "borderColor": "#ced4da"
          }
        },
        "tabs": {
          "textColor": "#3F4254",
          "backgroundColor": "#ffffff",
          "borderColor": "#dbe6f1",
          "activeTextColor": "#3b99ff",
          "activeBackgroundColor": "#eef0ff",
          "activeBorderColor": "#dbe6f1"
        },
        "modal": {
          "headerTextColor": "#212529",
          "headerBackgroundColor": "#ffffff",
          "headerBorderColor": "#dedede",
          "bodyTextColor": "#212529",
          "bodyBackgroundColor": "#ffffff",
          "bodyBorderColor": "#dedede"
        }
      }
    }
  },
  {
    "id": "blue",
    "name": "blue",
    "img": "#3699FF",
    "data": {
      "sidebarLayout": "flat",
      "siteInfo": {
        "logo": "assets/img/logo.png",
        "logoSmall": "assets/img/logo-small.png"
      },
      "siteTheme": {
        "themeName": "blue",
        "btnThemeName": "default",
        "colorTheme": "light",
        "header": {
          "backgroundColor": "#fff",
          "color": "#3F4254",
          "hoverBgColor": "#000000",
          "hoverColor": "#ffffff",
          "activeBgColor": "#000000",
          "activeColor": "#ffffff"
        },
        "sidebar": {
          "backgroundColor": "#fff",
          "color": "#3F4254",
          "hoverBgColor": "#000000",
          "hoverColor": "#ffffff",
          "activeBgColor": "#00000000",
          "activeColor": "#ffffff"
        },
        "btnThemes": {
          "default": {
            "textColor": "#ffffff",
            "borderColor": "#7b68ee",
            "backgroundColor": "#7b68ee"
          },
          "primary": {
            "textColor": "#ffffff",
            "borderColor": "#3699FF",
            "backgroundColor": "#3699FF"
          },
          "secondary": {
            "textColor": "#3F4254",
            "borderColor": "#E4E6EF",
            "backgroundColor": "#E4E6EF"
          },
          "dark": {
            "textColor": "#ffffff",
            "borderColor": "#181C32",
            "backgroundColor": "#181C32"
          },
          "danger": {
            "textColor": "#ffffff",
            "borderColor": "#F64E60",
            "backgroundColor": "#F64E60"
          },
          "light": {
            "textColor": "#7E8299",
            "borderColor": "#F3F6F9",
            "backgroundColor": "#F3F6F9"
          },
          "warning": {
            "textColor": "#fff",
            "borderColor": "#FFA800",
            "backgroundColor": "#FFA800"
          },
          "success": {
            "textColor": "#ffffff",
            "borderColor": "#1BC5BD",
            "backgroundColor": "#1BC5BD"
          },
          "info": {
            "textColor": "#ffffff",
            "borderColor": "#9184e3",
            "backgroundColor": "#9184e3"
          }
        },
        "tableTheme": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#dee2e6",
          "headerBgColor": "#7b68ee",
          "headerTextColor": "#212529",
          "headerTextWeight": "500"
        },
        "editors": {
          "textBox": {
            "textColor": "#212529",
            "backgroundColor": "#ffffff",
            "borderColor": "#ced4da",
            "placeholderColor": "#a9acaf",
            "borderFocusColor": "#80bdff"
          },
          "selectList": {
            "backgroundColor": "#ffffff"
          },
          "calendar": {
            "textColor": "#212529",
            "backgroundColor": "#ffffff",
            "borderColor": "#ced4da"
          }
        },
        "tabs": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#c2cfdd",
          "activeTextColor": "#212529",
          "activeBackgroundColor": "#eeebfd",
          "activeBorderColor": "#7b68ee"
        },
        "modal": {
          "headerTextColor": "#212529",
          "headerBackgroundColor": "#ffffff",
          "headerBorderColor": "#dedede",
          "bodyTextColor": "#212529",
          "bodyBackgroundColor": "#ffffff",
          "bodyBorderColor": "#dedede"
        }
      }
    }
  },
  {
    "id": "dark",
    "name": "dark",
    "img": "#212529",
    "data": {
      "sidebarLayout": "flat",
      "siteInfo": {
        "logo": "assets/img/logo.png",
        "logoSmall": "assets/img/logo-small.png"
      },
      "fontInfo": {
        "fontFamily": "Poppins",
        "customFont": "",
        "customFontName": "",
        "fontSize": "14px",
        "lineHeight": "default",
        "letterSpacing": "default"
      },
      "siteTheme": {
        "themeName": "dark",
        "btnThemeName": "default",
        "colorTheme": "dark",
        "header": {
          "backgroundColor": "#212529",
          "color": "#adb5bd",
          "hoverBgColor": "#000",
          "hoverColor": "#000",
          "activeBgColor": "#00000000",
          "activeColor": "#1580c2"
        },
        "sidebar": {
          "backgroundColor": "#212529",
          "color": "#adb5bd",
          "hoverBgColor": "#000000",
          "hoverColor": "#000000",
          "activeBgColor": "#ffffff",
          "activeColor": "#ffffff"
        },
        "btnThemes": {
          "default": {
            "textColor": "#3699FF",
            "borderColor": "#eef0ff",
            "backgroundColor": "#eef0ff"
          },
          "primary": {
            "textColor": "#3699FF",
            "borderColor": "#E1F0FF",
            "backgroundColor": "#E1F0FF"
          },
          "secondary": {
            "textColor": "#3F4254",
            "borderColor": "#E4E6EF",
            "backgroundColor": "#E4E6EF"
          },
          "dark": {
            "textColor": "#181C32",
            "borderColor": "#D1D3E",
            "backgroundColor": "#D1D3E"
          },
          "danger": {
            "textColor": "#F64E60",
            "borderColor": "#FFE2E5",
            "backgroundColor": "#FFE2E5"
          },
          "light": {
            "textColor": "#7a7a7a",
            "borderColor": "#F3F6F9",
            "backgroundColor": "#F3F6F9"
          },
          "warning": {
            "textColor": "#FFA800",
            "borderColor": "#FFF4DE",
            "backgroundColor": "#FFF4DE"
          },
          "success": {
            "textColor": "#1BC5BD",
            "borderColor": "#C9F7F5",
            "backgroundColor": "#C9F7F5"
          },
          "info": {
            "textColor": "#8950FC",
            "borderColor": "#EEE5FF",
            "backgroundColor": "#EEE5FF"
          }
        },
        "tableTheme": {
          "textColor": "#adb5bd",
          "backgroundColor": "#212529",
          "borderColor": "#495057",
          "headerBgColor": "#2b3035",
          "headerTextColor": "#adb5bd",
          "headerTextWeight": "500"
        },
        "editors": {
          "textBox": {
            "textColor": "#adb5bd",
            "backgroundColor": "#212529",
            "borderColor": "#495057",
            "placeholderColor": "#a9acaf",
            "borderFocusColor": "#80bdff"
          },
          "selectList": {
            "backgroundColor": "#ffffff"
          },
          "calendar": {
            "textColor": "#adb5bd",
            "backgroundColor": "#212529",
            "borderColor": "#495057"
          }
        },
        "tabs": {
          "textColor": "#adb5bd",
          "backgroundColor": "#212529",
          "borderColor": "#495057",
          "activeTextColor": "#ffffff",
          "activeBackgroundColor": "#2b3035",
          "activeBorderColor": "#6AABD2"
        },
        "modal": {
          "headerTextColor": "#adb5bd",
          "headerBackgroundColor": "#212529",
          "headerBorderColor": "#495057",
          "bodyTextColor": "#adb5bd",
          "bodyBackgroundColor": "#212529",
          "bodyBorderColor": "#495057"
        }
      }
    }
  },
  {
    "id": "custom",
    "name": "custom",
    "img": "#ffa12f",
    "data": {
      "sidebarLayout": "flat",
      "siteInfo": {
        "logo": "assets/img/logo.png",
        "logoSmall": "assets/img/logo-small.png"
      },
      "fontInfo": {
        "fontFamily": "Poppins",
        "customFont": "",
        "customFontName": "",
        "fontSize": "14px",
        "lineHeight": "default",
        "letterSpacing": "default"
      },
      "siteTheme": {
        "themeName": "custom",
        "btnThemeName": "custom",
        "colorTheme": "light",
        "header": {
          "backgroundColor": "#fff",
          "color": "#3F4254",
          "hoverBgColor": "#000",
          "hoverColor": "#000",
          "activeBgColor": "#00000000",
          "activeColor": "#1580c2"
        },
        "sidebar": {
          "backgroundColor": "#fff",
          "color": "#3F4254",
          "hoverBgColor": "#000",
          "hoverColor": "#000",
          "activeBgColor": "#00000000",
          "activeColor": "#1580c2"
        },
        "btnThemes": {
          "default": {
            "textColor": "#ffffff",
            "borderColor": "#ffa12f",
            "backgroundColor": "#ffa12f"
          },
          "primary": {
            "textColor": "#ffffff",
            "borderColor": "#007bff",
            "backgroundColor": "#007bff"
          },
          "secondary": {
            "textColor": "#ffffff",
            "borderColor": "#6c757d",
            "backgroundColor": "#6c757d"
          },
          "dark": {
            "textColor": "#ffffff",
            "borderColor": "#343a40",
            "backgroundColor": "#343a40"
          },
          "danger": {
            "textColor": "#ffffff",
            "borderColor": "#dc3545",
            "backgroundColor": "#dc3545"
          },
          "light": {
            "textColor": "#212529",
            "borderColor": "#f8f9fa",
            "backgroundColor": "#f8f9fa"
          },
          "warning": {
            "textColor": "#212529",
            "borderColor": "#ffc107",
            "backgroundColor": "#ffc107"
          },
          "success": {
            "textColor": "#ffffff",
            "borderColor": "#28a745",
            "backgroundColor": "#28a745"
          },
          "info": {
            "textColor": "#ffffff",
            "borderColor": "#17a2b8",
            "backgroundColor": "#17a2b8"
          }
        },
        "tableTheme": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#dee2e6",
          "headerBgColor": "#ffcc8f",
          "headerTextColor": "#212529",
          "headerTextWeight": "500"
        },
        "editors": {
          "textBox": {
            "textColor": "#212529",
            "backgroundColor": "#ffffff",
            "borderColor": "#ced4da",
            "placeholderColor": "#a9acaf",
            "borderFocusColor": "#80bdff"
          },
          "selectList": {
            "backgroundColor": "#ffffff"
          },
          "calendar": {
            "textColor": "#212529",
            "backgroundColor": "#ffffff",
            "borderColor": "#ced4da"
          }
        },
        "tabs": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#c2cfdd",
          "activeTextColor": "#fff",
          "activeBackgroundColor": "#ffa12f",
          "activeBorderColor": "#ffa12f"
        },
        "modal": {
          "headerTextColor": "#212529",
          "headerBackgroundColor": "#ffffff",
          "headerBorderColor": "#dedede",
          "bodyTextColor": "#212529",
          "bodyBackgroundColor": "#ffffff",
          "bodyBorderColor": "#dedede"
        }
      }
    }
  }
]
export const BTN_THEME_LIST: any = [
  {
    id: "default",
    name: "Default",
    img: "assets/img/theme-builder/buttons/default.jpg",
    data: {
      default: {
        backgroundColor: "#8598ad",
      },
      primary: {
        backgroundColor: "#8598ad",
      },
      secondary: {
        backgroundColor: "#6c757d",
      },
      dark: {
        backgroundColor: "#343a40",
      },
      danger: {
        backgroundColor: "#dc3545",
      },
      light: {
        backgroundColor: "#f8f9fa",
      },
      warning: {
        backgroundColor: "#ffc107",
      },
      success: {
        backgroundColor: "#28a745",
      },
      info: {
        backgroundColor: "#17a2b8",
      },
    },
  },
  {
    id: "bootstrap",
    name: "Bootstrap",
    img: "assets/img/theme-builder/buttons/bootstrap.jpg",
    data: {
      default: {
        backgroundColor: "#007bff",
      },
      primary: {
        backgroundColor: "#007bff",
      },
      secondary: {
        backgroundColor: "#6c757d",
      },
      dark: {
        backgroundColor: "#343a40",
      },
      danger: {
        backgroundColor: "#dc3545",
      },
      light: {
        backgroundColor: "#f8f9fa",
      },
      warning: {
        backgroundColor: "#ffc107",
      },
      success: {
        backgroundColor: "#28a745",
      },
      info: {
        backgroundColor: "#17a2b8",
      },
    },
  },
  {
    id: "journal",
    name: "Journal",
    img: "assets/img/theme-builder/buttons/journal.jpg",
    data: {
      default: {
        backgroundColor: "#eb6864",
      },
      primary: {
        backgroundColor: "#eb6864",
      },
      secondary: {
        backgroundColor: "#aaa",
      },
      dark: {
        backgroundColor: "#222",
      },
      danger: {
        backgroundColor: "#f57a00",
      },
      light: {
        backgroundColor: "#f9f9f9",
      },
      warning: {
        backgroundColor: "#f5e625",
      },
      success: {
        backgroundColor: "#22b24c",
      },
      info: {
        backgroundColor: "#369",
      },
    },
  },
  {
    id: "flatly",
    name: "Flatly",
    img: "assets/img/theme-builder/buttons/flatly.jpg",
    data: {
      default: {
        backgroundColor: "#2c3e50",
      },
      primary: {
        backgroundColor: "#2c3e50",
      },
      secondary: {
        backgroundColor: "#95a5a6",
      },
      dark: {
        backgroundColor: "#7b8a8b",
      },
      danger: {
        backgroundColor: "#e74c3c",
      },
      light: {
        backgroundColor: "#ecf0f1",
      },
      warning: {
        backgroundColor: "#f39c12",
      },
      success: {
        backgroundColor: "#18bc9c",
      },
      info: {
        backgroundColor: "#3498db",
      },
    },
  },
  {
    id: "lumen",
    name: "Lumen",
    img: "assets/img/theme-builder/buttons/lumen.jpg",
    data: {
      default: {
        backgroundColor: "#158cba",
      },
      primary: {
        backgroundColor: "#158cba",
      },
      secondary: {
        backgroundColor: "#f0f0f0",
      },
      dark: {
        backgroundColor: "#555",
      },
      danger: {
        backgroundColor: "#ff4136",
      },
      light: {
        backgroundColor: "#f6f6f6",
      },
      warning: {
        backgroundColor: "#ff851b",
      },
      success: {
        backgroundColor: "#28b62c",
      },
      info: {
        backgroundColor: "#75caeb",
      },
    },
  },
];
