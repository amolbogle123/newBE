import { AppRoutes } from "../../app.routes";

export class ThemeRoutes extends AppRoutes {
    constructor() {
        super();
    }
}
