import * as bcrypt from "bcryptjs";
import checkDiskSpace from 'check-disk-space';
import { execSync, spawnSync } from 'child_process';
import { dataSource, reloadSetDataSource, setDataSource } from "core/data-source";
import dotenv from "dotenv";
import { ClientDashboard, ClientGeneral, ClientNavigation, MdbClient, PublicTables, Themes, UserBkp, UserRoles, Users, WidgetAccount } from "entities";
import fs from "fs";
import lodash from "lodash";
import * as os from 'os';
import dbService from 'services/db.service';
import { Body, Controller, Get, Hidden, Path, Post, Request, Route, Tags } from 'tsoa';
import Container from 'typedi';
import { DataSource, Repository } from "typeorm";
import { CommonUtil } from "utils/common.util";
import { ConnectorsUtil } from "utils/connectors.util";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { NewNavigationMenu } from "../../../models/navigation-menu";
import { FormBuilderHelper } from "../../form-builder/utils/helpers/form-builder.helper";
import { APIResponse, DataBaseRequest, DbSettingsRequest, SetupWizardRequest } from '../doc/config.interface';
import { getCpuConfig, getMemoryConfig, StorageConfig } from "../utils/config-helper";
import * as constants from "../utils/constants";

@Route('config')
@Tags('Initial Setup')
export class ConfigurationController extends Controller {
    private static mdbClientRepo: Repository<MdbClient> = dataSource.getRepository(MdbClient);
    private static userRoleRepo: Repository<UserRoles> = dataSource.getRepository(UserRoles);
    private static userRepo: Repository<Users> = dataSource.getRepository(Users);
    private static generalRepo: Repository<ClientGeneral> = dataSource.getRepository(ClientGeneral);
    private static userBkpRepo: Repository<UserBkp> = dataSource.getRepository(UserBkp);
    private static clientNavigationRepo: Repository<ClientNavigation> = dataSource.getRepository(ClientNavigation);
    private static defaultTheme: Repository<Themes> = dataSource.getRepository(Themes);
    private static widgetAccount: Repository<WidgetAccount> = dataSource.getRepository(WidgetAccount);
    private static publicTables: Repository<PublicTables> = dataSource.getRepository(PublicTables);

    static getUpdatedDataSourceAndRepository(): void {
        ConfigurationController.mdbClientRepo = Container.get(DataSource).getRepository(MdbClient);
        ConfigurationController.generalRepo=Container.get(DataSource).getRepository(ClientGeneral);
        ConfigurationController.userRoleRepo=Container.get(DataSource).getRepository(UserRoles);
        ConfigurationController.userRepo=Container.get(DataSource).getRepository(Users);
        ConfigurationController.userBkpRepo=Container.get(DataSource).getRepository(UserBkp);
        ConfigurationController.clientNavigationRepo=Container.get(DataSource).getRepository(ClientNavigation);
        ConfigurationController.defaultTheme=Container.get(DataSource).getRepository(Themes);
        ConfigurationController.widgetAccount=Container.get(DataSource).getRepository(WidgetAccount);
        ConfigurationController.publicTables=Container.get(DataSource).getRepository(PublicTables);
    }
    
    @Get('get-config-status')
    @Hidden()
    async getSetupFlag(
        @Request() request: any
    ): Promise<APIResponse | unknown> {
        try {
            return CommonHelper.apiSwaggerSuccessResponse({
                data: process.env.INITIAL_SETUP !== 'false',
            });
        } catch (e) {
            return CommonHelper.apiSwaggerErrorResponse({
                error: { error_description: e.message },
            });
        }
    }

    @Get('get-client-details/:clientId')
    @Hidden()
    async getClientDetails(
        @Request() request: any,
        @Path() clientId: string
    ): Promise<APIResponse | unknown> {
        try {
            const response = {
                data: {
                    totalDashboard: 0,
                    totalUser: 0,
                    totalActiveUser: 0,
                    totalInactiveUser: 0,
                    totalRoles: 0
                }
            };
            let id = parseInt(clientId);
            const activeUsersDetails = await dataSource.getRepository(Users).find({where: { clientId: id ,isActive: 1 }});
            if (activeUsersDetails?.length) {
                response.data.totalActiveUser = activeUsersDetails.length;
            }

            const inactiveUsersDetails = await dataSource.getRepository(Users).find({where: { clientId: id ,isActive: 0 }});
            if (inactiveUsersDetails?.length) {
                response.data.totalInactiveUser = inactiveUsersDetails.length;
            }

            const roles = await dataSource.getRepository(UserRoles).find({where: { clientId: id }});
            if (roles?.length) {
                response.data.totalRoles = roles.length;
            }

            const dashboardDetails = await dataSource.getRepository(ClientDashboard).find({where: { clientId: id }});
            if (dashboardDetails?.length) {
                response.data.totalDashboard = dashboardDetails.length;
            }

            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (e) {
            return CommonHelper.apiSwaggerErrorResponse({
                error: { error_description: e.message },
            });
        }
    }
    
    @Get('get-system-config')
    @Hidden()
    async getSystemConfiguration(
        @Request() request: any
    ): Promise<APIResponse | unknown> {
        try {
            const totalMemory = os.totalmem(); // kilobyte
            const [cpuCapability] = os.cpus();
            const npmVerShell = spawnSync('npm', ['-v'], {shell: true});
            const storageShell = spawnSync('df', [ '-h', '--total | grep total'], {shell: true});

            const systemMemory = getMemoryConfig(totalMemory);
            const cpu = getCpuConfig(cpuCapability);
            const nodeVersion = parseFloat(process.version.substring(1));
            const npmVersion = parseFloat(npmVerShell.stdout.toString());
            const storage = new StorageConfig(storageShell.stdout.toString());

            return CommonHelper.apiSwaggerSuccessResponse({
                data: {
                    nodeVersion,
                    cpu,
                    npmVersion,
                    systemMemory,
                    storage,
                },
            });
        } catch (e) {
            return CommonHelper.apiSwaggerErrorResponse({
                error: { error_description: e.message },
            });
        }
    }

    @Get('get-hardware-info')
    @Hidden()
    async getHardwareInformation(): Promise<APIResponse | any> {
        try {
            const [nodeInformation, cpuInformation, memoryInformation, storageInformation] = await Promise.all([
                this.getNodeInformation(),
                this.getCpuInformation(),
                this.getMemoryInformation(),
                this.getStorageInformation()
            ]);

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "Success!",
                data: {
                    nodeInformation,
                    cpuInformation,
                    memoryInformation,
                    storageInformation
                }
            }, true);
        } catch (err) {
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse({ message: err, error: true }, false);
        }
    }

    @Post('get-db-status')
    @Hidden()
    async getDataBaseStatus(
        @Body() requestBody: DataBaseRequest,
        @Request() request: any
    ): Promise<APIResponse | unknown> {
        try {
            let apiResponse: any = { status: false, data: [], message: {}};
            const { config } = requestBody;
            if(config && config.dbType) {
                const accountConfig = {
                    multipleStatements: true,
                    host: config.dbHost || "",
                    port: config.dbPort || "",
                    user: config.dbUser || "",
                    password: config.dbPass || "",
                    database: config.dbName || "",
                    dbType: config.dbType || "",
                };
                apiResponse = await ConnectorsUtil.testDBConnection('SELECT NOW();', accountConfig);
            }
            return CommonHelper.apiSwaggerSuccessResponse({data: apiResponse.data, message: apiResponse.message});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post('setup-wizard')
    @Hidden()
    async setupWizard(
        @Body() requestBody: SetupWizardRequest,
        @Request() request: any
    ): Promise<APIResponse | unknown> {
        try {
            ConfigurationController.getUpdatedDataSourceAndRepository();
            let apiResponse: any = { status: false, data: null, message: {}};
            let clientData: any = await this.createClient(requestBody);
            let clientInsertResultID = clientData.clientInsertResultID;

            if (clientData.clientData.length) {
                apiResponse.status = false;
                apiResponse.message = "The client already exist";
                return CommonHelper.apiSwaggerSuccessResponse({data: apiResponse});
            }

            const roleResult = await dbService._findQueryService(ConfigurationController.userRoleRepo, { where: { clientId: clientInsertResultID, name: 'Super Admin' } });
            await FormBuilderHelper.generateFormBuilderEntity(clientInsertResultID);
            if(roleResult?.length > 0) {
                apiResponse.status = false;
                apiResponse.message = "The role already exist";
                return CommonHelper.apiSwaggerSuccessResponse({data: apiResponse});
            }
            const insertConnector = {
                clientId: clientInsertResultID,
                widgetType: 'VIEW360_TABLE',
                accountName: "View360 Table",
                createdBy: 'Default',
                config: '{}'
            };
            await dbService._createQueryService(ConfigurationController.widgetAccount, { ...insertConnector });
            const insertPublicTable = {
                client_id: clientInsertResultID,
                name: "ocr_reader",
                createdBy: 'Default',
                isClientCheck: 1
            };
            await dbService._createQueryService(ConfigurationController.publicTables, { ...insertPublicTable });
            const insertRole = {
                clientId: clientInsertResultID,
                name: 'Super Admin',
                permission: constants.ALL_PERMISSION,
                isDefaultRole: 1,
                createdBy: 'Default',
                appId: ''
            };
            const roleInsertResult = await dbService._createQueryService(ConfigurationController.userRoleRepo, { ...insertRole });
            if (!roleInsertResult) {
                apiResponse.status = false;
                apiResponse.message = "The client role already exist";
                return CommonHelper.apiSwaggerSuccessResponse({data: apiResponse});
            }

            const checkUser = await dbService._findQueryService(ConfigurationController.userRepo, {
                where: {email: requestBody.email, clientId: clientInsertResultID},
                select: ['id', 'email']
            });

            if(checkUser && Array.isArray(checkUser) && checkUser.length > 0) {
                apiResponse.status = false;
                apiResponse.message = "User already registered!";
                return CommonHelper.apiSwaggerSuccessResponse({data: apiResponse});
            }

            //Create Theme
            const defaultTheme = {
                client_id: clientInsertResultID,
                theme: '{"id":"light theme","name":"light theme","selectedColorTheme":"lighttheme1","data":[{"colorTheme":"lighttheme1","color":"#e1f0ff","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#e1f0ff","color":"#3b99ff","borderColor":"#3b99ff"},"siteTheme":{"themeName":"light1","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#e1f0ff","activeColor":"#3b99ff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#e1f0ff","activeColor":"#3b99ff"},"btnThemes":{"primary":{"textColor":"#3699FF","borderColor":"#E1F0FF","backgroundColor":"#E1F0FF","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#F64E60","borderColor":"#FFE2E5","backgroundColor":"#FFE2E5","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#e1f0ff","headerTextColor":"#212529","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#3b99ff","activeBackgroundColor":"#e1f0ff","activeBorderColor":"#3b99ff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme2","color":"#D4F1F4","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#D4F1F4","color":"#05445E","borderColor":"#05445E"},"siteTheme":{"themeName":"light2","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#D4F1F4","activeColor":"#05445E"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#D4F1F4","activeColor":"#05445E"},"btnThemes":{"primary":{"textColor":"#05445E","borderColor":"#D4F1F4","backgroundColor":"#D4F1F4","hoverBackgroundColor":"#D4F1F4","hoverBorderColor":"#D4F1F4","hoverTextColor":"#05445E"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#F64E60","borderColor":"#FFE2E5","backgroundColor":"#FFE2E5","hoverBackgroundColor":"#e8bbbf","hoverBorderColor":"#e8bbbf","hoverTextColor":"#F64E60"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#D4F1F4","headerTextColor":"#05445E","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#05445E","activeBackgroundColor":"#D4F1F4","activeBorderColor":"#05445E","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme3","color":"#c2d0ea","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#c2d0ea","color":"#46649f","borderColor":"#46649f"},"siteTheme":{"themeName":"light3","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#c2d0ea","activeColor":"#46649f"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#c2d0ea","activeColor":"#46649f"},"btnThemes":{"primary":{"textColor":"#46649f","borderColor":"#c2d0ea","backgroundColor":"#c2d0ea","hoverBackgroundColor":"#c2d0ea","hoverBorderColor":"#c2d0ea","hoverTextColor":"#46649f"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#F64E60","borderColor":"#FFE2E5","backgroundColor":"#FFE2E5","hoverBackgroundColor":"#e8bbbf","hoverBorderColor":"#e8bbbf","hoverTextColor":"#F64E60"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#c2d0ea","headerTextColor":"#46649f","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#46649f","activeBackgroundColor":"#c2d0ea","activeBorderColor":"#46649f","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme4","color":"#fff5e4","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#fff5e4","color":"#F88379","borderColor":"#F88379"},"siteTheme":{"themeName":"light4","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#fff5e4","activeColor":"#F88379"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#fff5e4","activeColor":"#F88379"},"btnThemes":{"primary":{"textColor":"#F88379","borderColor":"#fff5e4","backgroundColor":"#fff5e4","hoverBackgroundColor":"#fff5e4","hoverBorderColor":"#fff5e4","hoverTextColor":"#F88379"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#F64E60","borderColor":"#FFE2E5","backgroundColor":"#FFE2E5","hoverBackgroundColor":"#e8bbbf","hoverBorderColor":"#e8bbbf","hoverTextColor":"#F64E60"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#fff5e4","headerTextColor":"#F88379","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#F88379","activeBackgroundColor":"#fff5e4","activeBorderColor":"#F88379","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme5","color":"#ffe3ea","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#ffe3ea","color":"#FB5490","borderColor":"#FB5490"},"siteTheme":{"themeName":"light5","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#ffe3ea","activeColor":"#FB5490"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#ffe3ea","activeColor":"#FB5490"},"btnThemes":{"primary":{"textColor":"#FB5490","borderColor":"#ffe3ea","backgroundColor":"#ffe3ea","hoverBackgroundColor":"#ffe3ea","hoverBorderColor":"#ffe3ea","hoverTextColor":"#FB5490"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#F64E60","borderColor":"#FFE2E5","backgroundColor":"#FFE2E5","hoverBackgroundColor":"#e8bbbf","hoverBorderColor":"#e8bbbf","hoverTextColor":"#F64E60"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#ffe3ea","headerTextColor":"#FB5490","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#FB5490","activeBackgroundColor":"#ffe3ea","activeBorderColor":"#FB5490","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme6","color":"#d0ecdc","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#d0ecdc","color":"#18A558","borderColor":"#18A558"},"siteTheme":{"themeName":"light6","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#d0ecdc","activeColor":"#18A558"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#d0ecdc","activeColor":"#18A558"},"btnThemes":{"primary":{"textColor":"#18A558","borderColor":"#d0ecdc","backgroundColor":"#d0ecdc","hoverBackgroundColor":"#d0ecdc","hoverBorderColor":"#d0ecdc","hoverTextColor":"#18A558"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#F64E60","borderColor":"#FFE2E5","backgroundColor":"#FFE2E5","hoverBackgroundColor":"#e8bbbf","hoverBorderColor":"#e8bbbf","hoverTextColor":"#F64E60"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#d0ecdc","headerTextColor":"#18A558","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#18A558","activeBackgroundColor":"#d0ecdc","activeBorderColor":"#18A558","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme7","color":"#7f77f1","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#7f77f1","color":"#343a40","borderColor":"#7f77f1"},"siteTheme":{"themeName":"light7","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#7f77f1","activeColor":"#fff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#7f77f1","activeColor":"#fff"},"btnThemes":{"primary":{"textColor":"#fff","borderColor":"#7f77f1","backgroundColor":"#7f77f1","hoverBackgroundColor":"#7f77f1","hoverBorderColor":"#7f77f1","hoverTextColor":"#fff"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#fff","borderColor":"#F64E60","backgroundColor":"#F64E60","hoverBackgroundColor":"#F64E60","hoverBorderColor":"#F64E60","hoverTextColor":"#fff"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#7f77f1","headerTextColor":"#fff","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#fff","activeBackgroundColor":"#7f77f1","activeBorderColor":"#fff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme8","color":"#6985ff","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#6985ff","color":"#343a40","borderColor":"#6985ff"},"siteTheme":{"themeName":"light8","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#6985ff","activeColor":"#fff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#6985ff","activeColor":"#fff"},"btnThemes":{"primary":{"textColor":"#fff","borderColor":"#6985ff","backgroundColor":"#6985ff","hoverBackgroundColor":"#6985ff","hoverBorderColor":"#6985ff","hoverTextColor":"#fff"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#fff","borderColor":"#F64E60","backgroundColor":"#F64E60","hoverBackgroundColor":"#F64E60","hoverBorderColor":"#F64E60","hoverTextColor":"#fff"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#6985ff","headerTextColor":"#fff","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#fff","activeBackgroundColor":"#6985ff","activeBorderColor":"#fff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme9","color":"#1090e0","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#1090e0","color":"#343a40","borderColor":"#1090e0"},"siteTheme":{"themeName":"light9","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#1090e0","activeColor":"#fff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#1090e0","activeColor":"#fff"},"btnThemes":{"primary":{"textColor":"#fff","borderColor":"#1090e0","backgroundColor":"#1090e0","hoverBackgroundColor":"#1090e0","hoverBorderColor":"#1090e0","hoverTextColor":"#fff"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#fff","borderColor":"#F64E60","backgroundColor":"#F64E60","hoverBackgroundColor":"#F64E60","hoverBorderColor":"#F64E60","hoverTextColor":"#fff"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#1090e0","headerTextColor":"#fff","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#fff","activeBackgroundColor":"#1090e0","activeBorderColor":"#fff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme10","color":"#0f9d9f","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#0f9d9f","color":"#343a40","borderColor":"#0f9d9f"},"siteTheme":{"themeName":"light10","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#0f9d9f","activeColor":"#fff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#0f9d9f","activeColor":"#fff"},"btnThemes":{"primary":{"textColor":"#fff","borderColor":"#0f9d9f","backgroundColor":"#0f9d9f","hoverBackgroundColor":"#0f9d9f","hoverBorderColor":"#0f9d9f","hoverTextColor":"#fff"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#fff","borderColor":"#F64E60","backgroundColor":"#F64E60","hoverBackgroundColor":"#F64E60","hoverBorderColor":"#F64E60","hoverTextColor":"#fff"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#0f9d9f","headerTextColor":"#fff","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#fff","activeBackgroundColor":"#0f9d9f","activeBorderColor":"#fff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme11","color":"#3db88b","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#3db88b","color":"#343a40","borderColor":"#3db88b"},"siteTheme":{"themeName":"light11","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#3db88b","activeColor":"#fff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#3db88b","activeColor":"#fff"},"btnThemes":{"primary":{"textColor":"#fff","borderColor":"#3db88b","backgroundColor":"#3db88b","hoverBackgroundColor":"#3db88b","hoverBorderColor":"#3db88b","hoverTextColor":"#fff"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#fff","borderColor":"#F64E60","backgroundColor":"#F64E60","hoverBackgroundColor":"#F64E60","hoverBorderColor":"#F64E60","hoverTextColor":"#fff"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#3db88b","headerTextColor":"#fff","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#fff","activeBackgroundColor":"#3db88b","activeBorderColor":"#fff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme12","color":"#e16b16","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#e16b16","color":"#343a40","borderColor":"#e16b16"},"siteTheme":{"themeName":"light12","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#e16b16","activeColor":"#fff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#e16b16","activeColor":"#fff"},"btnThemes":{"primary":{"textColor":"#fff","borderColor":"#e16b16","backgroundColor":"#e16b16","hoverBackgroundColor":"#e16b16","hoverBorderColor":"#e16b16","hoverTextColor":"#fff"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#fff","borderColor":"#F64E60","backgroundColor":"#F64E60","hoverBackgroundColor":"#F64E60","hoverBorderColor":"#F64E60","hoverTextColor":"#fff"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#e16b16","headerTextColor":"#fff","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#fff","activeBackgroundColor":"#e16b16","activeBorderColor":"#fff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme13","color":"#ee5e99","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#ee5e99","color":"#343a40","borderColor":"#ee5e99"},"siteTheme":{"themeName":"light13","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#ee5e99","activeColor":"#fff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#ee5e99","activeColor":"#fff"},"btnThemes":{"primary":{"textColor":"#fff","borderColor":"#ee5e99","backgroundColor":"#ee5e99","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#fff","borderColor":"#F64E60","backgroundColor":"#F64E60","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#ee5e99","headerTextColor":"#fff","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#fff","activeBackgroundColor":"#ee5e99","activeBorderColor":"#fff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme14","color":"#b660e0","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#b660e0","color":"#343a40","borderColor":"#b660e0"},"siteTheme":{"themeName":"light14","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#b660e0","activeColor":"#fff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#b660e0","activeColor":"#fff"},"btnThemes":{"primary":{"textColor":"#fff","borderColor":"#b660e0","backgroundColor":"#b660e0","hoverBackgroundColor":"#b660e0","hoverBorderColor":"#b660e0","hoverTextColor":"#fff"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#fff","borderColor":"#F64E60","backgroundColor":"#F64E60","hoverBackgroundColor":"#F64E60","hoverBorderColor":"#F64E60","hoverTextColor":"#fff"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#b660e0","headerTextColor":"#fff","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#fff","activeBackgroundColor":"#b660e0","activeBorderColor":"#fff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"lighttheme15","color":"#595d66","fontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#595d66","color":"#fff","borderColor":"#595d66"},"siteTheme":{"themeName":"light15","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#595d66","activeColor":"#fff"},"sidebar":{"backgroundColor":"","color":"#3F4254","hoverBgColor":"#f9f9f9","hoverColor":"#3F4254","activeBgColor":"#595d66","activeColor":"#fff"},"btnThemes":{"primary":{"textColor":"#fff","borderColor":"#595d66","backgroundColor":"#595d66","hoverBackgroundColor":"#595d66","hoverBorderColor":"#595d66","hoverTextColor":"#fff"},"secondary":{"textColor":"#3F4254","borderColor":"#E4E6EF","backgroundColor":"#E4E6EF","hoverBackgroundColor":"#d7daea","hoverBorderColor":"#d7daea","hoverTextColor":"#3F4254"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E","backgroundColor":"#D1D3E","hoverBackgroundColor":"#D1D3E","hoverBorderColor":"#D1D3E","hoverTextColor":"#181C32"},"danger":{"textColor":"#F64E60","borderColor":"#FFE2E5","backgroundColor":"#FFE2E5","hoverBackgroundColor":"#e8bbbf","hoverBorderColor":"#e8bbbf","hoverTextColor":"#F64E60"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9","hoverBackgroundColor":"#d7dee4","hoverBorderColor":"#d7dee4","hoverTextColor":"#7a7a7a"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5","hoverTextColor":"#1BC5BD","hoverBackgroundColor":"#abe7e4","hoverBorderColor":"#abe7e4"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#595d66","headerTextColor":"#fff","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#3F4254","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#fff","activeBackgroundColor":"#595d66","activeBorderColor":"#fff","hoverTextColor":"#3F4254","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#212529","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}},{"colorTheme":"l&ttheme-light","color":"#07518c","fontInfo":{"fontFamily":"Noto+Sans","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"defaultFontInfo":{"fontFamily":"Poppins","customFont":"","customFontName":"","fontSize":"13px","lineHeight":"default","letterSpacing":"default"},"primaryColors":{"background":"#07518c","color":"#ffc71b","borderColor":"#07518c"},"siteTheme":{"themeName":"l&tlight","colorTheme":"light","themeCategory":"light","header":{"backgroundColor":"#fff","color":"#07518c","hoverBgColor":"#f9f9f9","hoverColor":"#ffc71b","activeBgColor":"#07518c","activeColor":"#ffc71b"},"sidebar":{"backgroundColor":"","color":"#07518c","hoverBgColor":"#07518c","hoverColor":"#ffc71b","activeBgColor":"#07518c","activeColor":"#ffc71b"},"btnThemes":{"primary":{"textColor":"#ffc71b","borderColor":"#07518c","backgroundColor":"#07518c"},"secondary":{"textColor":"#fff","borderColor":"#ffc71b","backgroundColor":"#ffc71b"},"dark":{"textColor":"#181C32","borderColor":"#D1D3E1","backgroundColor":"#D1D3E1","hoverBackgroundColor":"#D1D3E1","hoverBorderColor":"#D1D3E1","hoverTextColor":"#181C32"},"danger":{"textColor":"#fff","borderColor":"#F64E60","backgroundColor":"#F64E60"},"light":{"textColor":"#7a7a7a","borderColor":"#F3F6F9","backgroundColor":"#F3F6F9"},"warning":{"textColor":"#FFA800","borderColor":"#FFF4DE","backgroundColor":"#FFF4DE","hoverBackgroundColor":"#FFF4DE","hoverBorderColor":"#FFF4DE","hoverTextColor":"#FFA800"},"success":{"textColor":"#1BC5BD","borderColor":"#C9F7F5","backgroundColor":"#C9F7F5"},"info":{"textColor":"#8950FC","borderColor":"#EEE5FF","backgroundColor":"#EEE5FF","hoverTextColor":"#8950FC","hoverBackgroundColor":"#EEE5FF","hoverBorderColor":"#EEE5FF"}},"tableTheme":{"textColor":"#07518c","backgroundColor":"#ffffff","borderColor":"#dee2e6","headerBgColor":"#07518c","headerTextColor":"#ffc71b","headerTextWeight":"500"},"editors":{"textBox":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"},"selectList":{"textColor":"#212529","backgroundColor":"#ffffff","borderColor":"#ced4da","placeholderColor":"#a9acaf"}},"tabs":{"textColor":"#07518c","backgroundColor":"#ffffff","borderColor":"#dbe6f1","activeTextColor":"#ffc71b","activeBackgroundColor":"#07518c","activeBorderColor":"#ffc71b","hoverTextColor":"#07518c","hoverBackgroundColor":"#f9f9f9"},"modal":{"headerTextColor":"#212529","headerBackgroundColor":"#ffffff","headerBorderColor":"#dedede","bodyTextColor":"#212529","bodyBackgroundColor":"#ffffff","bodyBorderColor":"#dedede","footerTextColor":"#212529","footerBackgroundColor":"#ffffff"},"btnStyle":"Regular","btnBorderRadius":"4px","footer":{"backgroundColor":"#fcfcfc","textColor":"#5d5959"}},"body":{"bgColor":"#fff","type":false,"color":"#07518c","imgPath":null,"opacity":50,"enableBodyBGImg":false},"navigation":{"navPosition":"left","menuPosition":"horizontal","bgColor":"#fff"}}]}',
                userid: '',
                isDefault: true,
                isSystem: true,
                updatedAt: new Date(),
                createdOn: new Date()
            }
            const themeData = await dbService._createQueryService(ConfigurationController.defaultTheme, { ...defaultTheme });
            if(!themeData) {
                apiResponse.status = false;
                apiResponse.message = "Problem in creating default theme.";
                return CommonHelper.apiSwaggerSuccessResponse({data: apiResponse});
            }
            const salt = bcrypt.genSaltSync();
            requestBody.password = bcrypt.hashSync(requestBody.password, salt);
            const insertUserData = {
                clientId: clientInsertResultID,
                roleId: roleInsertResult.id,
                firstName: requestBody.first_name,
                lastName: requestBody.last_name,
                email: requestBody.email,
                username: requestBody.username,
                password: requestBody.password,
                isSuperAdmin: 1,
                address: '',
                country: '',
                department: '',
                jobTitle: '',
                mobile: '',
                skype: '',
                userManager: '',
                isActive: 1,
                changePasswordToken: '',
                changePasswordTokens: '',
                aiApp: '',
                logoUrl: '',
                isView360Login: 1,
                selectedThemeId: themeData.id,
                selectedColorTheme: 'lighttheme1'
            };
            const insertUserResult = await dbService._createQueryService(ConfigurationController.userRepo, { ...insertUserData });
            
            // Main Navigation Menu -- Start
            const navigationMenu: NewNavigationMenu[] = CommonUtil.setNavigationMenu(roleInsertResult.id);
            // Main Navigation Menu -- End

            const insertClientNavigation = {
                menu: JSON.stringify(navigationMenu),
                clientId: clientInsertResultID,
                active: 1,
                updatedBy: ''
            };
            if (insertUserResult && !lodash.isEmpty(insertUserResult)) {
                let insertUserBkpData = {...insertUserResult, isDeleted: 0};
                await dbService._createQueryService(ConfigurationController.userBkpRepo, { ...insertUserBkpData });
                await dbService._createQueryService(ConfigurationController.clientNavigationRepo, { ...insertClientNavigation });

                apiResponse.data = lodash.omit(insertUserResult, ['password']);
                apiResponse.status = true;
                apiResponse.message = 'User successfully created';
            }

            return CommonHelper.apiSwaggerSuccessResponse({data: apiResponse});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    async createClient (requestBody) {
        const clientName = requestBody.first_name + requestBody.last_name;
        let clientData: any = await dbService._findQueryService(ConfigurationController.mdbClientRepo, { where: { name: clientName }, select: ['name'] });
        if(clientData.length === 0) {
            const insertClient = {
                name: clientName,
                firstName: requestBody.first_name,
                lastName: requestBody.last_name,
                email: requestBody.email,
                primaryContact: '',
                secondaryContact: '',
                companyName: '',
                employees: '',
                websiteUrl: requestBody.website_url,
                storeName: '',
                vertical: '',
                accessibleUntil: '',
                maxUserLimit: 1000,
                logoUrl: '',
                orgId: '',
                userId: '',
                secondEmail: '',
                thirdEmail: '',
                fourthEmail: '',
            };
            const clientInsertResult = await dbService._createQueryService(ConfigurationController.mdbClientRepo, { ...insertClient });
            if(clientInsertResult) {
                const insertClientGeneral = {
                    client_id: clientInsertResult.id,
                    company_name: '',
                    legal_name: '',
                    contact_person: '',
                    comp_address: '',
                    zip: '',
                    city: '',
                    state: '',
                    country: '',
                    comp_phone: '',
                    comp_phone2: '',
                    company_email: '',
                    mobile: '',
                    fax: '',
                    website: '',
                    comp_registration:'',
                    tax_no: ''
                }
                await dbService._createQueryService(ConfigurationController.generalRepo, { ...insertClientGeneral });
                return {clientData: clientData, clientInsertResultID: clientInsertResult.id};
            }
        }
        return {clientData: clientData};
    }

    @Post('set-db-settings')
    @Hidden()
    async saveDBSettings(
        @Body() requestBody: DbSettingsRequest,
        @Request() request: any
    ): Promise<APIResponse | unknown> {
        try {
            const reloadEnv = () => {
                const envConfig_ = dotenv.parse(fs.readFileSync('.env'))

                for (const key in envConfig_) {
                    process.env[key] = envConfig_[key]
                }
            }
            const config = requestBody.config;

            dotenv.config({override:true,path: '.env' });

            process.env.INITIAL_SETUP = String(true);
            process.env.DB_TYPE = config.dbType;
            process.env.DB_HOST = config.dbHost;
            process.env.DB_PORT = config.dbPort;
            process.env.DB_USERNAME = config.dbUser;
            process.env.DB_PASSWORD = config.dbPass;
            process.env.DB_NAME = config.dbName;
            process.env.DB_SYNCHRONIZE = String(true); // this shouldn't be turned on in production
            process.env.DB_LOGGING = String(false);

            // Convert the environment variables to a string
            const envConfig = dotenv.parse(fs.readFileSync('.env'));

            // Update the environment variables with your changes
            Object.keys(envConfig).forEach((key) => {
                envConfig[key] = process.env[key];
            });

            // Convert the environment variables back to a string
            const envConfigString = Object.keys(envConfig).map((key) => `${key}="${envConfig[key]}"`).join('\n');

            // Write the updated environment variables to the .env file
            //fs.writeFileSync('.env', envConfigString);

            fs.writeFile('.env', envConfigString, async(err) => {
                // Checking for errors
                if (err) throw err;

                delete process.env.INITIAL_SETUP;
                delete process.env.DB_TYPE;
                delete process.env.DB_HOST;
                delete process.env.DB_PORT;
                delete process.env.DB_USERNAME;
                delete process.env.DB_PASSWORD;
                delete process.env.DB_NAME;
                delete process.env.DB_SYNCHRONIZE;
                delete process.env.DB_LOGGING;
                delete process.env.ENABLE_APPLICATION_INSIGHTS;
                dotenv.config({override:true})
                reloadEnv();
                //await dataSource.destroy();
                //const dataSource2: DataSource = new DatabaseConnection().initialize();

                await setDataSource(await reloadSetDataSource());
                 //await dataSource.initialize();
                 setTimeout(() => {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        data: {setup: true},
                        message: 'File updated successfully.',
                    });
                 }, 1000);
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    private async getNodeInformation() {
        const nodeVersion = execSync('node -v').toString().trim();
        const npmVersion = execSync('npm -v').toString().trim();

        return {
            nodeVersion: nodeVersion ? nodeVersion.substring(1) : 'Unable to fetch this information.',
            npmVersion: npmVersion ? npmVersion : 'Unable to fetch this information.'
        }
    }

    private async getCpuInformation() {
        const cpuInformation = os.cpus();

        return {
            processorName: cpuInformation ? cpuInformation[0].model : 'Unable to fetch this information.',
            clockSpeedInGhz: cpuInformation ? `${(cpuInformation[0].speed / 1000).toFixed(2)} Ghz` : 'Unable to fetch this information.',
            totalCores: cpuInformation ? cpuInformation.length : 'Unable to fetch this information.'
        }
    }

    private async getMemoryInformation() {
        const totalMemory = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(2);
        const freeMemory = (os.freemem() / (1024 * 1024 * 1024)).toFixed(2);

        return {
            installedMemoryInGb: totalMemory ? `${totalMemory} GB` : 'Unable to fetch this information.',
            availableMemoryInGb: freeMemory ? `${freeMemory} GB` : 'Unable to fetch this information.'
        }
    }

    private async getStorageInformation() {
        let diskInformation = await checkDiskSpace(process.cwd());

        return {
            diskPath: diskInformation ? diskInformation.diskPath : 'Unable to fetch this information.',
            diskSizeInGb: diskInformation ? `${(diskInformation.size / (1024 * 1024 * 1024)).toFixed(2)} GB` : 'Unable to fetch this information.',
            freeSizeInGb: diskInformation ? `${(diskInformation.free / (1024 * 1024 * 1024)).toFixed(2)} GB` : 'Unable to fetch this information.'
        }
    }
}
