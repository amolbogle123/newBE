export interface APIResponse {
    status: string;
    data?: any;
    message?: string;
}

export interface DataBaseRequest {
    config?: any;
}

export interface SetupWizardRequest {
    first_name: string;
    last_name: string;
    email: string;
    password: string;
    username: string;
    website_url: string;
}

export interface DbSettingsRequest {
    config: any;
}
