import { CpuInfo } from "os";



export enum Hertz {
    GIGA_HERTZ = 'GHz',
    MEGA_HERTZ = 'MHz'
}

export class CpuConfig {

    constructor(public processorName: string, public gigahertzValue: number, public megahertzValue: number) {
    }
}

export class MemoryConfig {

    constructor(public inGB: number, public inMB: number) {
    }
}

export class StorageConfig {

    public totalStorage: number = 0;
    public usedStorage: number = 0;
    public availableStorage: number = 0;

    constructor(storageValue: string) {

        const _st = this.parseStorageValue(storageValue);

        this.totalStorage = _st.totalStorage ? parseInt(_st.totalStorage) : 200;
        this.usedStorage = _st.usedStorage ? parseInt(_st.usedStorage) : 200;
        this.availableStorage = _st.availableStorage ? parseInt(_st.availableStorage) : 200;
    }

    parseStorageValue(storageValue) {
        const filterParams: string[] = ['total', '', '-\n', '-'];
        let storageArray: string[] = storageValue.split(' ').filter(i => !filterParams.includes(i));

        const [totalStorage, usedStorage, availableStorage] = storageArray;
        return { totalStorage, usedStorage, availableStorage };
    }
}


export const multiReplace = (str: string, array: (RegExp | string)[], replaceWith: string[] | string = '') => {

    array.forEach((replaceValue, index) =>
        str.replace(replaceValue, Array.isArray(replaceWith) ? replaceWith[index] : replaceWith)
    );
    return str;
}

export const getMemoryConfig = (totalMemoryValue: number) => {


    try {
        const valueInGb = parseFloat(
            (totalMemoryValue / Math.pow(1024, 3)).toFixed(2)
        );
        const valueInMb = parseFloat(
            (totalMemoryValue / Math.pow(1024, 2)).toFixed(2)
        )

        return new MemoryConfig(valueInGb, valueInMb);

    } catch (e) {
        return new MemoryConfig(0, 0);
    }
}

export const getCpuConfig = (cpuInfo: CpuInfo, type: Hertz = Hertz.GIGA_HERTZ) => {

    let gigahertzValue: number;
    let megahertzValue: number;

    try {
        if (cpuInfo.model.includes('@')) {
            const [processorName, hertzValue] = cpuInfo.model.split('@');

            if (hertzValue.includes(Hertz.GIGA_HERTZ)) {
                gigahertzValue = parseFloat(hertzValue.replace(Hertz.GIGA_HERTZ, ''));
                megahertzValue = gigahertzValue * 1000;
            }
            if (hertzValue.includes(Hertz.MEGA_HERTZ)) {
                megahertzValue = parseFloat(hertzValue.replace(Hertz.MEGA_HERTZ, ''));
            }
            return new CpuConfig(processorName.trim(), gigahertzValue, megahertzValue);
        }
        return new CpuConfig(cpuInfo.model, cpuInfo.speed / 1000, cpuInfo.speed);
    } catch (e) {
        return new CpuConfig(null, NaN, NaN);
    }
}


