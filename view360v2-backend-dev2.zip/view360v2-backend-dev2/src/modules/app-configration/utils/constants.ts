import { NavigationMenu } from "../../../models/navigation-menu";

export const ALL_PERMISSION: string = '{"dashboard":{"widget":{"view":true,"add":true,"configure":true,"permission":true,"clone":true,"move":true,"refresh":true,"delete":true},"dashboard":{"view":true,"add":true,"edit":true,"delete":true},"select":true},"documents":{"document":{"view":true,"add":true,"edit":true,"manageUser":true,"delete":true,"filters":true,"viewall":true},"form":{"view":true,"add":true,"edit":true,"delete":true,"formEmbed":true,"formShare":true,"viewall":true},"formEntry":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"users":{"user":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"roles":{"role":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"setting":{"general":{"view":true,"edit":true},"navigation":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"defaultlandingpage":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"modules":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"childCompanies":{"view":true,"add":true,"delete":true},"department":{"view":true,"add":true,"delete":true},"location":{"view":true,"add":true,"delete":true},"smtp":{"view":true,"edit":true},"sms":{"view":true,"edit":true},"maintenance":{"view":true,"edit":true},"signupConfiguration":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"analystad":{"view":true,"edit":true},"crawlerindexer":{"view":true,"edit":true},"select":true},"customskinning":{"appsetting":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"custombody":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"typography":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"componentstheming":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"customheader":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"customNavigation":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"customFooter":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"Formmapper":{"pdf":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"excel":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"automation":{"mailTemplate":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"notificationTemplate":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"processBuilder":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"datamigrators":{"datamigrator":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"pagebuilder":{"pagebuilder":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"genAI":{"chat":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"models":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"fireDetections":{"firemodule":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true},"select":true},"relationBuilder":{"relationBuilder":{"view":true,"add":true,"edit":true,"delete":true,"viewall":true}}}'

// New Navigation Menu
export const dashboard: NavigationMenu = {
    name: 'Dashboard',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Dashboard-1624444146283283',
    faClass: 'briefcase',
    components: [],
    parantTmpId: null,
    routerLink: 'dynamic-dashboard/dashboard'
}

export const manageUsers: NavigationMenu = {
    name: 'Manage Users',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'User Information-1624446506890890',
    faClass: 'user-check',
    components: [],
    parantTmpId: null,
    routerLink: 'users'
}

export const manageRoles: NavigationMenu = {
    name: 'Manage Roles',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Roles-1624446523338338',
    faClass: 'users',
    components: [],
    parantTmpId: null,
    routerLink: 'roles'
}

export const settings: NavigationMenu = {
    name: 'Settings',
    order: 0,
    roles: '2',
    active: 1,
    tempId: 'Setting-1624446480915915',
    faClass: 'settings',
    components: [],
    parantTmpId: null,
    routerLink: 'setting/view/general'
}

export const workflowManagement: NavigationMenu = {
    name: 'Workflow Management',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Process Builder-1624446295506506',
    faClass: 'cpu',
    components: [],
    parantTmpId: null,
    routerLink: 'list-processes'
}

export const documents: NavigationMenu = {
    name: 'Documents',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Documents-1624445918458458',
    faClass: 'folder',
    components: [],
    parantTmpId: null,
    routerLink: 'forms-builder/projects'
}

export const formBuilder: NavigationMenu = {
    name: 'Form Builder',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Form Builder-1624446037355355',
    faClass: 'file',
    components: [],
    parantTmpId: null,
    routerLink: 'forms-builder/add-form-builder/-1/-1'
}

export const templateBuilder: NavigationMenu = {
    name: 'Template Builder',
    order: 0,
    roles: '2c8be754-3318-4616-826c-11f2c209feaa',
    active: 1,
    tempId: 'Template Builder-1624446110985985',
    faClass: 'file-plus',
    components: [],
    parantTmpId: null,
    routerLink: 'templates'
}

export const analyticsSubmenu: NavigationMenu = {
    name: 'Analytics',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Analytics-1682599649957957',
    faClass: 'message-square',
    components: [],
    parantTmpId: null,
    routerLink: ''
}

export const administrationSubmenu: NavigationMenu = {
    name: 'Administration',
    order: 0,
    roles: '',
    active: 1,
    tempId: 'Admin-1682599603732732',
    faClass: 'user',
    components: [],
    parantTmpId: null,
    routerLink: ''
}
