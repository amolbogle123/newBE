import {AppRoutes} from "../../app.routes";

export class ConfigurationRoutes extends AppRoutes {
    constructor() {
        super();
        this.initRoutes();
    }

    initRoutes() {
        /**
         * this.router.get('/config/get-config-status', ConfigurationController.getSetupFlag);
         * this.router.get('/config/get-system-config', ConfigurationController.getSystemConfiguration);
         * this.router.post('/config/get-db-status', ConfigurationController.getDataBaseStatus);
         * this.router.post('/config/setup-wizard', ConfigurationController.applicationSetupWizard);
         * this.router.post('/config/set-db-settings', ConfigurationController.saveDBSettings);
         */
    }
}
