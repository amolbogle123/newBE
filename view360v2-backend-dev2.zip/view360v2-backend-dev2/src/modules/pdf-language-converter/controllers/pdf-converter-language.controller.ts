import {Body, Controller, Delete, Get, Post, Query, Request, Route, Tags} from "tsoa";
import {ApiErrorResponse, CommonHelper} from "utils/helpers/common.helper";
const fs = require('fs');
const path = require('path');
import {Response} from "express";
import {PdfLanguageConverter} from "entities";
import Container from "typedi";
import {DataSource, UpdateResult} from "typeorm";
import {CommonUtil} from "utils/common.util";
import dbService from "services/db.service";
const fetch = require('node-fetch');


@Route("pdf-converter-language")
@Tags("PDF Converter Language")
export class PdfConverterLanguageController extends Controller {

    constructor() {
        super();
    }

    @Post("")
    async LanguageConverter(
        @Request() request: any
    ): Promise<void> {
        try {
            const response = { status: false, data: {} };
            // const filePath = path.join('./public/pdf-converter-files', 'french_withimage.pdf'); //req.file.path;
            // const fileData = fs.readFileSync(filePath);
            //
            // // Extract text from PDF
            // const data = await pdfParse(fileData);
            // const text = data.text;
            //
            // // Translate text from French to English
            // await new Promise(resolve => setTimeout(resolve, 1000));
            // const translated = await translate(text, { from: 'fr', to: 'en' });
            // const translatedText = translated.text;
            //
            // // Create a new PDF with translated text
            // const translatedPdfPath = path.join('./public/pdf-converter-files', 'translated.pdf');
            // const doc = new PDFDocument();
            // doc.pipe(fs.createWriteStream(translatedPdfPath));
            // doc.text(translatedText);
            // doc.end();


            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("file-status")
    async updateFileStatus(
        @Request() request: any
    ): Promise<void> {
        try {
            console.log('request.body', request.body);
            const response = { status: false, data: null };
            if (!request.body.fileId) {
              const apiErrorResponse: ApiErrorResponse = {
                error: { error_description: 'File Id is required', },
              };
              return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
            }
            if (!request.body.translatedFileName) {
              const apiTransErrorResponse: ApiErrorResponse = {
                error: { error_description: 'Translated File Name is required' },
              };
              return CommonHelper.apiSwaggerErrorResponse(apiTransErrorResponse);
            }
            const condition = { id: request.body.fileId };
            const updateFields  = {
              translatedFileName: request.body.translatedFileName,
            }
            const sqlResponse: UpdateResult = await Container.get(DataSource).getRepository(PdfLanguageConverter).update(condition, updateFields);
            if (sqlResponse.affected) {
              response.status = true;
              response.data = sqlResponse;
              return CommonHelper.apiSwaggerSuccessResponse(response);
            }
            const apiUpdateErrorResponse: ApiErrorResponse = {
              error: { error_description: 'Error in updating the file status' },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiUpdateErrorResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }


    async pdfUpload(
      request: Request | any,
      response: Response,
      next: any
    ): Promise<any> {
      try {
        const apiResponse: any = { data: null, error: null, fileInformation: {}, fileDetailsSaved: false };

        if (request.file) {
          const uploadedFilePath = request.file.destination + request.file.filename;
          const languageFrom = await this.getLanguageCode(request.body.language);
          const languageTo = await this.getLanguageCode(request.body.languageTo);
          if (fs.existsSync(uploadedFilePath)) {
            const fileInfo = {
              fileServerName: request.file.filename,
              filePath: request.file.destination,
              fileOriginalName: request.file.originalname,
              translatedFileName: null,
              fileSize: request.file.size,
              fileUploadedLanguage: request.body.language
            };
            apiResponse.data = [];
            apiResponse.fileInformation = fileInfo;
            const saveResult: any = await this.saveFileDetails(fileInfo, request);
            console.log('saveResult', saveResult);
            if (saveResult?.id) {
              this.translateFile(uploadedFilePath, request.file.filename,languageFrom, languageTo, saveResult.id);
              apiResponse.fileDetailsSaved = true;
            }
            // const translatedFile = await this.translateTheFile(uploadedFilePath, request.file.filename);
            // if(translatedFile) {
            //     const fileInfo = {
            //         fileServerName: request.file.filename,
            //         filePath: request.file.destination,
            //         fileOriginalName: request.file.originalname,
            //         translatedFileName: translatedFile.output_file,
            //         fileSize: request.file.size,
            //         fileUploadedLanguage: request.body.language };
            //     apiResponse.data = [];
            //     apiResponse.fileInformation = fileInfo;
            //     const saveResult = await this.saveFileDetails(fileInfo, request);
            //     if(saveResult) {
            //         apiResponse.fileDetailsSaved = true;
            //     }
            // } else {
            //     apiResponse.error = "Please try again";
            // }
          } else {
            apiResponse.error = "Please upload file";
          }
        }

        return CommonHelper.apiSuccessResponse(response, apiResponse);
      } catch (err) {
        const apiErrorResponse: ApiErrorResponse = {
          error: {
            error_description: (err as Error).message,
          },
        };
        return CommonHelper.apiErrorResponse(response, apiErrorResponse);
      }
    }

   async getLanguageCode(language) {
        switch (language) {
            case 'English':
                return 'en';
            case 'French':
                return 'fr';
            case 'Russian':
                return 'ru';
            default:
                return 'fr';
        }
    }

    async translateFile(uploadedFilePath, fileName, languageFrom ,languageTo, fileId) {
        if (!fileId) {
          return false;
        }
        const url = process.env.PDF_CONVERTER_API;
        const data = {
            pdf_path: `${process.env.BASE_URL}/${process.env.PDF_CONVERTER_UPLOAD_FILE_PATH}/${fileName}`,
            languageFrom: languageFrom,
            languageTo: languageTo,
            fileId,
            statusAPI: `${process.env.BASE_URL}/pdf-converter-language/file-status`
        };

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            if (!response.ok) {
                console.log('File Uploaded response :: ', response.status )
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            return result;
        } catch (error) {
            return false;
        }
    }

    async prefixWithT(str) {
        if (typeof str !== 'string') {
            throw new TypeError('The argument must be a string');
        }
        return 'T_' + str;
    }

    async saveFileDetails(fileInfo, req) {
        try {
            const fileDetails = fileInfo;
            const objPdfLanguageConverter = new PdfLanguageConverter();
            objPdfLanguageConverter.fileOriginalName = fileDetails.fileOriginalName;
            objPdfLanguageConverter.fileServerName = fileDetails.fileServerName;
            objPdfLanguageConverter.translatedFileName = fileDetails.translatedFileName;
            objPdfLanguageConverter.filePath = fileDetails.filePath;
            objPdfLanguageConverter.fileSize = fileDetails.fileSize;
            objPdfLanguageConverter.fileUploadedLanguage = fileDetails.fileUploadedLanguage;
            objPdfLanguageConverter.createdBy = req?.userDetails?.id ? req?.userDetails?.id : 'SuperAdmin';
            const insertResult = await Container.get(DataSource).getRepository(PdfLanguageConverter).save(objPdfLanguageConverter);
            if(insertResult) {
                return insertResult
            } else  {
                return 'Error in saving data'
            }
        } catch (e) {
            return 'Error in saving data';
        }
    }


    @Get("")
    async getAllTranslatedFiles(
        @Request() request: any,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<any | unknown> {
        try {
            let whereCondition: any = {};
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };

            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["createdOn"] = 'DESC';
            }

            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(PdfLanguageConverter),
                {
                    where: whereCondition,
                }
            );
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(PdfLanguageConverter),
                {
                    where: whereCondition,
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );

            apiResponse.data = results;
            apiResponse.recordsTotal = totalRecordCount;
            apiResponse.recordsFiltered = pageSize;

            const totalPages = Math.ceil(totalRecordCount / pageSize);
            apiResponse.totalPages = totalPages;
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }


    @Delete("")
    async deleteRecord(
        @Body() requestBody): Promise<any> {
        try {
            const ids = requestBody.ids;
            const results = await  Container.get(DataSource).
                getRepository(PdfLanguageConverter)
                .delete({ id: ids });
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
