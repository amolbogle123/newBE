export interface UserRoleRequest {
    id?: string;
    name: string;
    permission: any;
}

export interface UserRoleResponse {
    status: string | boolean;
    data?: any;
    message?: string;
    recordsTotal?: number;
    recordsFiltered?: number;
}

export interface GetRolesRequest {
    draw: number;
    columns: Columns[];
    order: Order[];
    start: number;
    length: number;
    search: Search;
    customFilters: CustomFilters;
}
export interface DeleteRoles {
    id: string;
}

interface Permission {
    dashboard: Dashboard;
    documents: Documents;
    pdf: Pdf;
    automation: Automation;
    setting: Setting;
    users: Users;
    roles: Roles;
    reports: Reports;
    gridReports: GridReports;
}

interface Dashboard {
    widget: Widget;
    dashboard: DashboardSubMenu;
}

interface Widget {
    view: boolean;
    add: boolean;
    configure: boolean;
    permission: boolean;
    clone: boolean;
    move: boolean;
    refresh: boolean;
    delete: boolean;
}

interface DashboardSubMenu {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
}

interface Documents {
    document: DocumentSubMenu;
    form: Form;
    formEntry: FormEntry;
}

interface DocumentSubMenu {
    view: boolean;
    add: boolean;
    edit: boolean;
    manageUser: boolean;
    delete: boolean;
    filters: boolean;
    viewall: boolean;
}

interface Form {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    formEmbed: boolean;
    formShare: boolean;
    viewall: boolean;
}

interface FormEntry {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    viewall: boolean;
}

interface Pdf {
    pdfForm: PdfForm;
    pdfFormEntry: PdfFormEntry;
}

interface PdfForm {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    viewall: boolean;
}

interface PdfFormEntry {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    viewall: boolean;
}

interface Automation {
    mailTemplate: MailTemplate;
    notificationTemplate: NotificationTemplate;
    processBuilder: ProcessBuilder;
}

interface MailTemplate {
    view: boolean;
    add: boolean
    edit: boolean
    delete: boolean
    viewall: boolean
}

interface NotificationTemplate {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    viewall: boolean;
}

interface ProcessBuilder {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean
    viewall: boolean;
}

interface Setting {
    general: General;
    childCompanies: ChildCompany;
    department: Department;
    location: Location;
    connectors: Connectors;
}

interface General {
    view: boolean;
    edit: boolean;
}

interface ChildCompany {
    view: boolean;
    add: boolean;
    delete: boolean;
}

interface Department {
    view: boolean;
    add: boolean;
    delete: boolean;
}

interface Location {
    view: boolean;
    add: boolean;
    delete: boolean;
}

interface Connectors {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    viewall: boolean;
}

interface Users {
    user: User;
}

interface User {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    viewall: boolean;
}

interface Roles {
    role: Role;
}

interface Role {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    viewall: boolean;
}

interface Reports {
    report: Report
}

interface Report {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    viewall: boolean;
}

interface GridReports {
    report: Report;
}

interface Report {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    viewall: boolean;
}

interface Data {
    clientId: number;
    name: string;
    permission: Permission;
    isDefaultRole: number;
    createdBy: string;
}

interface Columns {
    data: string;
    name: string;
    searchable: boolean;
    orderable: boolean;
    search: Search
}

interface Search {
    value: string;
    regex: boolean
}

interface Order {
    column: number;
    dir: string
}

interface CustomFilters {
    role: DynamicFields[]
}

interface DynamicFields {
    [key: string]: any
}