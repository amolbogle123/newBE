export interface DashboardCrudAddRequest {
    id?: string,
    title: string,
    clientId?: number,
    createdBy?: string,
    rolePermissionConfig?: string,
    mappedUser?: any,
    userPermissionConfig?: string,
    filterConfig: string,
    defaultId?:string
}


export interface DashboardCrudAddReponse {
    status?: string | boolean;
    data?: any;
    message?: string;
}


export interface DashboardDeleteRequest {
    id: string
}



export interface WidgetAccountListResponse {
    records: string,
    recordsTotal: number,
    recordsFiltered: number,
}


export interface AddWidgetToDashboard {
    dashboard: string,
    type: string,
    mappedUser:string,
    title:string
}

export interface GetWidgetToAccountList{
    type:string
}
export interface AddWidgetAccount{
    widgetType:string
    accountName:string
    config:string
    appId:string,
    accountConfig:string
    id:string
}



export interface PermissionWidgetAdd{
    title:string
    widgetAccount:string
    widgetConfig:string
    isConfigured:1,
    WidgetType:string
}
