export interface InviteRequestBody {
    role: string;
    email: string;
    emailTemplate: string;
    newEmail:string;
}
export interface InviteResponse {
    status: string;
    data: Invite[];
    message: string;
}
export interface InviteDataTableListResponse {
    status: string;
    data: {
        recordsTotal: number;
        recordsFiltered: number;
        records: Invite[];
    };
    message: string;
}
export interface Invite {
    id: string;
    clientId: number;
    role: {
        name: string;
    };
    roleId: string;
    email: string;
    emailTemplateId: string;
    status: string;
    code: string;
    updatedOn: string;
    createdOn:string;
}
export interface InviteRegisterRequestBody {
    email: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
    password: string;
    clientId: number;
    roleId: string;
    emailVerificationCode: string;
}
