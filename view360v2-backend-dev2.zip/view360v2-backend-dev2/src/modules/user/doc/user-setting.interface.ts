export interface UserSettingResponse {
    status: string;
    data: UserSetting;
    message: string;
}
export interface UserSetting{
    settingName: string;
    settingValue: string;
}
export interface UserSettingBody{
    userId: string;
    settingName: string;
    settingValue: string;
}