export interface LoginRequest {
    email: string;
    password: string;
    token: string;
    Skip2FA: boolean;
    appType?: string;
}

export interface LoginResponse {
    status: string;
    data?: Data;
    message?: string;
}

export interface SsoStatusResponse {
    message: string;
    data: {
        ssoActive: boolean;
    };
}
export interface LdapResponse {
    message: string;
    data: {
        ldapActive: boolean;
    };
}

export interface ReCaptchaResponse {
    message: string;
    data: {
        recaptchaActive: boolean;
        data?: Data;
    };
}

interface Data {
    user: User;
    token: string;
}

export interface User {
    id: string;
    clientid: number;
    roleid: string;
    issuperadmin: number;
    isadmin: number;
    teamid: any;
    usermanager: string;
    firstname: string;
    lastname: string;
    email: string;
    phone: any;
    username: string;
    password: string;
    state: any;
    city: any;
    zipcode: any;
    hashcode: any;
    passresetdate: any;
    hiredate: any;
    address: string;
    country: string;
    department: string;
    hourlyrate: string;
    jobtitle: string;
    localeen: any;
    mobile: string;
    skype: string;
    tag: any;
    twitter: any;
    website: any;
    childcompany: any;
    location: any;
    workingyear: number;
    isactive: number;
    applytheme: string;
    disabledstate: number;
    profileimage: number;
    profileurl: any;
    lanid: any;
    menulist: any;
    emailverified: number;
    changepasswordtoken: any;
    lastlogindate: string;
    currentlogindate: string;
    updateddate: string;
    updatedat: string;
    createdon: string;
    changepasswordtokens: string;
    aiapp: any;
    isdeleted: number;
    escalationcontact1: number;
    escalationcontact2: number;
    isview360login: number;
    countrycode: string;
    logourl: string;
    mdbclient: MdbClient;
}

interface MdbClient {
    id: number;
    name: string;
    firstName: string;
    lastName: string;
    email: string;
    primaryContact: string;
    secondaryContact: string;
    companyName: string;
    employees: string;
    websiteUrl: string;
    storeName: string;
    vertical: string;
    isTrial: number;
    createdOn: string;
    modifiedOn: any;
    maxUserLimit: number;
    pwaUrl: any;
    usingAccess: number;
    valueMultiplier: number;
    accessibleUntil: string;
    clientAddress: any;
    chatbotAgent: any;
    logoUrl: string;
    orgId: string;
    state: any;
    zipCode: any;
    territoryFilePath: any;
    meters: any;
    userId: string;
    secondEmail: string;
    thirdEmail: string;
    fourthEmail: string;
}
