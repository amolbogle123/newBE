export interface UserRequest {
    id?: string;
    first_name: string;
    last_name: string;
    username: string;
    job_title?: any;
    email: string;
    phone?: any;
    mobile?: any;
    password: string;
    address: string;
    state: string;
    country: string;
    city: string;
    zip: string;
    role_id: string;
    parent_user?: any;
    website?: any;
    twitter?: any;
    hourly_rate?: any;
    child_company?: any;
    location?: any;
    department?: any;
    locale_en?: any;
    skype?: any;
    tag?: any;
}
