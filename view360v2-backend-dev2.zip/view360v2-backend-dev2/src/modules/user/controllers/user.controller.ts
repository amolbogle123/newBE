import { ILike, In, DataSource } from "typeorm";
import lodash from "lodash";
import * as bcrypt from "bcryptjs";
import { Themes } from "../../../entities/themes";

import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import Container from "typedi";
import {
    ChildCompany,
    MdbClient,
    UserRoles,
    Users,
    UserBkp,
    SettingConfig,
    UserSetting,
} from "../../../entities";
import dbService from "../../../services/db.service";
import { cacheResponseData } from "../../../utils/redis.middleware";
import {
    Body,
    Get,
    Path,
    Post,
    Put,
    Delete,
    Query,
    Request,
    Route,
    Security,
    Tags,
    Controller,
    Hidden,
    Middlewares,
} from "tsoa";
import { UserRequest } from "../doc/user.interface";
import { CommonUtil } from "../../../utils/common.util";
import { LdapAuthUtil } from "utils/ldap-auth";
import { Crypto } from "utils/crypto";
import { validateEntryCount } from "../../../middlewares/common.middleware";

@Route("")
@Tags("Users")
export class UserController extends Controller {
    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    @Security("bearerAuth")
    @Get("user/:id")
    async getUserDetail(
        @Path() id: string,
        @Request() request: any
    ): Promise<unknown> {
        try {
            let client_id = request.userDetails.client_id;

            const results: Users[] = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: { id: id, clientId: client_id },
                }
            );

            if (results && Array.isArray(results) && results.length > 0) {
                const userData: Users | any = results[0];
                userData.password = null;

                const roleResult: UserRoles[] =
                    await dbService._findQueryService(
                        Container.get(DataSource).getRepository(UserRoles),
                        {
                            where: {
                                id: results[0].roleId,
                                clientId: client_id,
                            },
                        }
                    );

                if (
                    roleResult &&
                    Array.isArray(roleResult) &&
                    roleResult.length > 0
                ) {
                    userData.roleList = roleResult[0];
                }
                if (userData.childCompany) {
                    const companyResult: ChildCompany =
                        await dbService._findOneQueryService(
                            Container.get(DataSource).getRepository(
                                ChildCompany
                            ),
                            {
                                where: {
                                    id: userData.childCompany,
                                    clientId: client_id,
                                },
                                select: ["name"],
                            }
                        );

                    if (companyResult && !lodash.isEmpty(companyResult)) {
                        userData.child_company_name = companyResult.name;
                    }
                }
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: userData,
                    message: "User successfully created",
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: {},
                    message: "User successfully created",
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("user")
    @Middlewares(validateEntryCount)
    async createUser(
        @Body() requestBody: UserRequest,
        @Request() request: any
    ): Promise<unknown> {
        try {
            let client_id = request.userDetails.client_id;

            let clientData: any = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MdbClient),
                {
                    where: { id: client_id },
                    select: ["maxUserLimit"],
                }
            );

            if (!(clientData && Array.isArray(clientData) && clientData.length > 0)) {
                return CommonHelper.apiSwaggerErrorResponse({
                    error: "Client not found!",
                });
            }
            const userCountResult = await dbService._countQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: { clientId: client_id },
                }
            );

            if (userCountResult === 0) {
                return CommonHelper.apiSwaggerErrorResponse({
                    error: "User count not found!",
                });
            }
            
            const checkUser = await dbService._findOneQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: { email: requestBody.email},
                    select: ["id", "email"],
                }
            );

            if (checkUser && CommonUtil.isNotNull(checkUser.email)) {
                return CommonHelper.apiSwaggerErrorResponse({
                    error: "alreadyRegistered",
                    message: "User already registered!",
                });
            }
            const salt = bcrypt.genSaltSync();
            request.body.password = bcrypt.hashSync(
                request.body.password,
                salt
            );

            //get system default theme
            let defaultTheme: any = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Themes),
                {
                    where: { isDefault: 1,client_id: client_id},
                    select: ["id", "theme"],
                }
            );
            const insertData = {
                clientId: client_id,
                roleId: requestBody.role_id,
                firstName: requestBody.first_name,
                lastName: requestBody.last_name,
                email: requestBody.email,
                phone: requestBody.phone,
                username: requestBody.username,
                password: requestBody.password,
                state: requestBody.state,
                city: requestBody.city,
                zipCode: requestBody.zip,
                address: requestBody.address,
                country: requestBody.country,
                department: requestBody.department,
                jobTitle: requestBody.job_title,
                mobile: requestBody.mobile,
                tag: requestBody.tag,
                childCompany: requestBody.child_company,
                userManager: requestBody.parent_user,
                location: requestBody.location,
                isActive: request.body.is_active,
                isSuperAdmin: 0,
                selectedThemeId:
                    defaultTheme.length > 0 ? defaultTheme[0].id : "",
                selectedColorTheme:
                    defaultTheme.length > 0
                        ? JSON.parse(defaultTheme[0].theme)
                                .selectedColorTheme
                        : "",
            } as unknown as Users;

            const insertResult = await dbService._createQueryService(
                Container.get(DataSource).getRepository(Users),
                insertData
            );

            let response = {
                data: null,
                message: "User successfully created",
            };
            if (insertResult && !lodash.isEmpty(insertResult)) {
                let insertUserBkpData = { ...insertData, isDeleted: 0 };
                await dbService._createQueryService(
                    Container.get(DataSource).getRepository(UserBkp),
                    insertUserBkpData
                );

                response.data = lodash.omit(insertData, ["password"]);
            }

            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Put("user/:id")
    async editUser(
        @Path() id: string,
        @Body() requestBody: UserRequest,
        @Request() request: any
    ): Promise<string | unknown> {
        try {
            let client_id = request.userDetails.client_id;

            const criteria: any = {
                email: requestBody.email,
                id: id,
                clientId: client_id,
            };
            const emailCheck: number = await dbService._countQueryService(
                Container.get(DataSource).getRepository(Users),
                { where: criteria }
            );

            if (!emailCheck || emailCheck === 0) {
                return CommonHelper.apiSwaggerErrorResponse({
                    error: "alreadyRegistered",
                    message: "User already registered!",
                });
            } else {
                const updateData = {
                    roleId: request.body.role_id,
                    firstName: request.body.first_name,
                    lastName: request.body.last_name,
                    email: request.body.email,
                    phone: request.body.phone,
                    username: request.body.username,
                    state: request.body.state,
                    city: request.body.city,
                    zipCode: request.body.zip,
                    address: request.body.address,
                    country: request.body.country,
                    department: request.body.department,
                    jobTitle: request.body.job_title,
                    mobile: request.body.mobile,
                    tag: request.body.tag,
                    childCompany: request.body.child_company,
                    userManager: request.body.parent_user,
                    location: request.body.location,
                } as unknown as Users;
                if (request.body.password) {
                    const salt = bcrypt.genSaltSync(10);
                    updateData.password = await bcrypt.hash(
                        request.body.password,
                        salt
                    );
                }
                await dbService._updateQueryService(
                    Container.get(DataSource).getRepository(Users),
                    {
                        paramsObj: { id, clientId: client_id },
                        ...updateData,
                    }
                );
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "User updated successfully",
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("users")
    @Hidden()
    async getAllUserList(@Request() request: any): Promise<unknown> {
        try {
            let client_id = request.userDetails.client_id;
            let limit = request.body.length ? request.body.length : 10;
            let start = request.body.start ? request.body.start : 0;
            let role = request.body.customFilters?.role;
            let whereCondition: any = [];

            if (
                request.body.search &&
                request.body.search.value &&
                request.body.search.value !== ""
            ) {
                const searchFields = ["username", "email", "phone", "city"];
                const roleCondition = !role ? {} : { roleId: role };

                searchFields.forEach((i) =>
                    whereCondition.push({
                        [i]: ILike(request.body.search.value),
                        clientId: client_id,
                        ...roleCondition,
                    })
                );
            } else {
                const roleCondition = !role ? {} : { roleId: role };
                whereCondition = { clientId: client_id, ...roleCondition };
            }

            let apiResponse = {
                data: {
                    recordsTotal: 0,
                    recordsFiltered: 0,
                    records: [],
                },
            };

            const userCount: number = await dbService._countQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: { clientId: client_id },
                }
            );
            let users = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: whereCondition,
                    take: limit,
                    skip: start,
                }
            );

            if (users.length > 0 && !lodash.isEmpty(users)) {
                apiResponse.data.records = users.map((r) => {
                    delete r.password;
                    return r;
                });
                apiResponse.data.recordsTotal = userCount;
                apiResponse.data.recordsFiltered = userCount;
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("users")
    async deleteUser(
        @Body() requestBody: { id: string[] },
        @Request() request: any
    ): Promise<string | unknown> {
        try {
            let client_id = request.userDetails.client_id;
            let id = requestBody.id;

            if (!Array.isArray(requestBody.id)) {
                id = [requestBody.id];
            }
            const userSettingResult =await Container.get(DataSource).getRepository(UserSetting).find({
                where: { userId: In(id) },
            });
            if(userSettingResult && userSettingResult.length > 0){
                await dbService._deleteMultipleQueryService(
                    Container.get(DataSource).getRepository(UserSetting),
                    {
                        id: In(userSettingResult.map((r) => r.id)),
                    }
                );
            }
            const deleteResult = await dbService._deleteMultipleQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    id: In(id),
                    clientId: client_id,
                }
            );

            if (deleteResult) {
                await dbService._updateQueryService(
                    Container.get(DataSource).getRepository(UserBkp),
                    {
                        paramsObj: { clientId: client_id },
                        isDeleted: 1,
                    }
                );

                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "User deleted successfully",
                    data: {},
                });
            } else {
                return CommonHelper.apiSwaggerErrorResponse(deleteResult);
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("users")
    async allUser(
        @Request() request: any,
        @Query() roleId?: string,
        @Query("pagination") pagination: boolean = true,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<unknown> {
        try {
            let whereCondition: any = {
                clientId: request.userDetails.client_id,
            };
            if (roleId && !lodash.isEmpty(roleId)) {
                whereCondition.roleId = roleId;
            }
            const selectedFields: any = [
                "id",
                "clientId",
                "roleId",
                "isSuperAdmin",
                "userManager",
                "firstName",
                "lastName",
                "username",
                "email",
                "profileUrl",
                "createdOn",
                "secretKey",
            ];

            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };

            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["createdOn"] = sortOrder;
            }
            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: whereCondition,
                }
            );

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: whereCondition,
                    select: selectedFields,
                    take: pagination ? pageSize : totalRecordCount,
                    skip: pagination ? (page - 1) * pageSize : 0,
                    order: sortObject,
                }
            );

            apiResponse.data = results;
            apiResponse.recordsTotal = totalRecordCount;
            apiResponse.recordsFiltered = totalRecordCount;

            const totalPages = Math.ceil(totalRecordCount / pageSize);
            apiResponse.totalPages = totalPages;

            if (!lodash.isEmpty(results) && results.length > 0) {
                await cacheResponseData(request.originalUrl, apiResponse);
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: [],
                message: "Successfully executed.",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("users-list")
    async allTokenUser(
        @Request() request: any,
        @Query() roleId?: string,
    ): Promise<unknown> {
        try {
            let origin: any = await CommonUtil.getOriginUrl(request.headers.origin);
            const clientDetails = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MdbClient),
                {
                    where: [
                        { websiteUrl: origin },
                        { pwaUrl: origin },
                    ]
                }
            );
            if (!clientDetails?.length || !clientDetails[0]?.id) {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: 'Bad Request: Client is Required!!' } });
            }

            let whereCondition: any = {
                clientId: clientDetails[0].id,
            };
            if (roleId && !lodash.isEmpty(roleId)) {
                whereCondition.roleId = roleId;
            }
            const selectedFields: any = [
                "id",
                "clientId",
                "roleId",
                "isSuperAdmin",
                "userManager",
                "firstName",
                "lastName",
                "username",
                "email",
                "profileUrl",
                "createdOn",
                "secretKey",
            ];

            const apiResponse = {
                data: [],
            };

            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: whereCondition,
                }
            );

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: whereCondition,
                    select: selectedFields,
                }
            );

            apiResponse.data = results;

            if (!lodash.isEmpty(results) && results.length > 0) {
                await cacheResponseData(request.originalUrl, apiResponse);
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: [],
                message: "Successfully executed.",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Put("user/profile-image/:id")
    async updateUserImage(
        @Path() id: string,
        @Body() requestBody: { url: string | null },
        @Request() request: any
    ): Promise<unknown> {
        try {
            const updateData = { profileUrl: requestBody.url };
            const whereCondition: any = {
                id: id,
                clientId: request.userDetails.client_id,
            };

            const updateResponse = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    paramsObj: whereCondition,
                    ...updateData,
                }
            );

            if (updateResponse && updateResponse.affected) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: [],
                    message: "Profile image updated successfully",
                });
            }
            return CommonHelper.apiSwaggerErrorResponse({
                error: "profileImageError",
                message: "Something went wrong !",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    // @Security("bearerAuth")
    @Get("users/by-role/:role")
    @Hidden()
    async getUserByRole(
        @Path() role: string,
        @Request() request: any
    ): Promise<string | unknown> {
        try {
            let whereCondition: any = {
                // clientId: request.userDetails.client_id,
            };
            if (role && !lodash.isEmpty(role)) {
                whereCondition.roleId = role;
            }

            const selectedFields: any = [
                "id",
                "clientId",
                "roleId",
                "isSuperAdmin",
                "userManager",
                "firstName",
                "lastName",
                "username",
                "email",
                "profileUrl",
                "createdOn",
                "isActive",
                "address",
                "zipCode",
                "city",
                "state",
                "country",
                "mobile",
            ];
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: whereCondition,
                    select: selectedFields,
                }
            );

            if (!lodash.isEmpty(results) && results.length > 0) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: results,
                    message: "Successfully executed.",
                });
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: [],
                message: "User not found",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("users/ldap-user/:name")
    async searchADUser(
        @Path() name: string,
        @Request() request: any
    ): Promise<any> {
        try {
            const response = { status: true, data: [] };
            const clientId = request.userDetails.client_id;
            const whereCondition: any = {
                where: { clientId, type: "ANALYST_LDAP" },
            };

            const ldapSettings = await dbService._findQueryService(
                Container.get(DataSource).getRepository(SettingConfig),
                { ...whereCondition }
            );

            if (ldapSettings && ldapSettings.length) {
                let configData = JSON.parse(ldapSettings[0].config) || {};
                const serverURL = configData.analystLdapURL;
                const username = configData.analystLdapUser;
                const password = configData.analystLdapPassword;
                const searchData = await LdapAuthUtil.ldapSearchUser(
                    serverURL,
                    username,
                    password,
                    name
                );
                response.data = [searchData];
            }

            return CommonHelper.apiSwaggerSuccessResponse({
                data: response,
                message: "Successfully executed.",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Hidden()
    @Put("user-secret-key/:id")
    async updateUserSecretKey(
        @Path() id: string,
        @Body() requestBody,
        @Request() request: any
    ): Promise<string | unknown> {
        try {
            const updateData = {
                secretKey: Crypto.encr("", request.body.secretKey),
            } as unknown as Users;

            await dbService._updateQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    paramsObj: { id },
                    ...updateData,
                }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "User updated successfully",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Hidden()
    @Security("bearerAuth")
    @Put("resetMFA/:id")
    async resetMFA(
        @Path() id: string,
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<string | unknown> {
        try {
            const updateData = { secretKey: "" } as unknown as Users;
            await dbService._updateQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    paramsObj: { id },
                    ...updateData,
                }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "User updated successfully",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
