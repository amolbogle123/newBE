import {
    Body,
    Controller,
    Delete,
    Get,
    Patch,
    Path,
    Post,
    Request,
    Route,
    Security,
    Tags
} from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { UserSetting } from "../../../entities";
import dbService from "../../../services/db.service";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import {
    UserSettingBody,
    UserSettingResponse
} from "../doc/user-setting.interface";
@Route("")
@Tags("User Setting")
export class UserSettingController extends Controller {

    @Security("bearerAuth")
    @Get("UserSetting/:Setting_Name")
    async getUserSetting(
        @Request() req: Request | any,
    ): Promise<UserSettingResponse> {
        try {
            let user_id = req.userDetails.id;
            let whereCondition = {
                userId: user_id,
                settingName: req.params.Setting_Name,
                isDeleted: 0
            };
            const userSetting = await dbService._findOneQueryService(
                Container.get(DataSource).getRepository(UserSetting),
                {
                    where: whereCondition,
                    select: ["settingName", "settingValue"],
                },
            );

            let response: UserSettingResponse = {
                status: "success",
                data: userSetting,
                message: "User Setting fetched successfully",
            };
            this.setStatus(200);
            return response;

        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("UserSetting")
    async createUserSetting(
        @Request() req: Request | any,
        @Body() body: UserSettingBody
    ): Promise<UserSettingResponse> {
        try {
            //check if exists
            let whereCondition = {
                userId: body.userId,
                settingName: body.settingName,
                isDeleted: 0
            };
            const userSettingExists = await dbService._findOneQueryService(
                Container.get(DataSource).getRepository(UserSetting),
                {
                    where: whereCondition,
                },
            );
            if (userSettingExists) {
                let userResponse: UserSettingResponse = {
                    status: "error",
                    data: userSettingExists,
                    message: "User Setting already exists",
                };
                this.setStatus(409);
                return userResponse;
            }
            let userSetting = await this.addUserSetting(body, req);
            let response: UserSettingResponse = {
                status: "success",
                data: userSetting,
                message: "User Setting created successfully",
            };
            this.setStatus(201);
            return response;
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    private async addUserSetting(body: UserSettingBody, req: any) {
        let userSetting = new UserSetting();
        userSetting.userId = body.userId;
        userSetting.settingName = body.settingName;
        userSetting.settingValue = body.settingValue;
        userSetting.createdBy = req.userDetails.id ? req.userDetails.id : "";
        userSetting.updatedBy = req.userDetails.id ? req.userDetails.id : "";
        userSetting.isDeleted = 0;
        await dbService._createQueryService(
            Container.get(DataSource).getRepository(UserSetting),
            userSetting
        );
        return userSetting;
    }

    @Security("bearerAuth")
    @Patch("UserSetting/:Setting_Name")
    async updateUserSetting(
        @Request() req: Request | any,
        @Body() body: UserSettingBody,
        @Path() Setting_Name: string
    ): Promise<UserSettingResponse> {
        try {
            let user_id = req.userDetails.id ? req.userDetails.id:"";
            let whereCondition = {
                userId: body.userId,
                settingName: Setting_Name,
                isDeleted: 0
            };
            let userSetting = await dbService._findOneQueryService(
                Container.get(DataSource).getRepository(UserSetting),
                {
                    where: whereCondition,
                },
            );
            if (userSetting) {
                userSetting.settingValue = body.settingValue;
                userSetting.updatedBy = user_id;
                await dbService._updateQueryService(
                    Container.get(DataSource).getRepository(UserSetting),
                    userSetting
                );
                let response: UserSettingResponse = {
                    status: "success",
                    data: userSetting,
                    message: "User Setting updated successfully",
                };
                this.setStatus(200);
                return response;
            } else {
                let userSettings = await this.addUserSetting(body, req);
                let response: UserSettingResponse = {
                    status: "success",
                    data: userSettings,
                    message: "User Setting created successfully",
                };
                this.setStatus(201);
                return response;
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("UserSetting/:Setting_Name")
    async deleteUserSetting(
        @Request() req: Request | any,
        @Path() Setting_Name: string
    ): Promise<UserSettingResponse> {
        try {
            let user_id = req.userDetails.id;
            let whereCondition = {
                userId: user_id,
                settingName: Setting_Name,
                isDeleted: 0
            };
            let userSetting = await dbService._findOneQueryService(
                Container.get(DataSource).getRepository(UserSetting),
                {
                    where: whereCondition,
                },
            );
            if (userSetting) {
                userSetting.isDeleted = 1;
                userSetting.updatedBy = user_id;
                await dbService._updateQueryService(
                    Container.get(DataSource).getRepository(UserSetting),
                    userSetting
                );
                let response: UserSettingResponse = {
                    status: "success",
                    data: userSetting,
                    message: "User Setting deleted successfully",
                };
                this.setStatus(200);
                return response;
            } else {
                let response: UserSettingResponse = {
                    status: "error",
                    data: userSetting,
                    message: "User Setting not found",
                };
                this.setStatus(404);
                return response;
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
