import { DataSource } from "typeorm";
import { toLower } from "lodash";
import dbService from "../../../services/db.service";
import { AccessLogger } from "../../../core/config/pino-loggers";
import {
    Users,
    UserBkp,
    ClientNavigation,
    MenuModule,
    MdbClient,
    SettingConfig,
    UserRoles,
} from "../../../entities";
import { ClientSubscriptionUtil } from "../../../utils/clientSubscription.util";
import { JwtEncryptUtil } from "../../../utils/jwt-encrypt.util";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import moment from "moment";
import * as siteConfig from "../../../utils/constants/config.constant";
import { CommonUtil } from "../../../utils/common.util";
import {
    Body,
    Controller,
    Get,
    Post,
    Request,
    Route,
    Security,
    Tags,
} from "tsoa";
import {
    LoginRequest,
    LoginResponse,
    SsoStatusResponse,
    LdapResponse,
    ReCaptchaResponse,
} from "../doc/auth.interface";
import Container from "typedi";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { LdapAuthUtil } from "utils/ldap-auth";
const nodemailer = require("nodemailer");
import { TwoFactorService } from "../services/two.factor.service";
import { Crypto } from "utils/crypto";
import { checkValidity } from "utils/activation.utils";
import fetch from "node-fetch";
@Route("auth")
@Tags("Authentication")
export class AuthController extends Controller {
    private readonly TOKEN_EXPIRY_TIME: string = "7d";
    private readonly DEFAULT_ORIGIN: string = siteConfig.DEFAULT_ORIGIN;
    private twoFactorService: TwoFactorService;
    constructor() {
        super();
        this.twoFactorService = new TwoFactorService();
    }
    @Post("login")
    async login(
        @Body() requestBody: LoginRequest,
        @Request() request: any
    ): Promise<LoginResponse | unknown> {
        this.setStatus(500);
        try {
            let requestStart = Date.now();
            const apiResponse: any = {
                status: false,
                data: {},
            };
            const userDetails = await dbService._userLoginService(
                Container.get(DataSource).getRepository(Users),
                { email: toLower(request.body.email) }
            );
            if (userDetails?.length !== 1 || !userDetails[0].mdbClient) {
                apiResponse.message = "User not found!!";
                this.setStatus(401);
                return CommonHelper.apiSwaggerErrorResponse(apiResponse);
            }

            let isValidUser = false;
            let userLoginDetails = {};
            const clientId = userDetails[0].mdbClient.id;
            isValidUser = true;

            // if (!request.headers.origin.includes("localhost:")) {
            //     const checkClientResult = await fetch(`${process.env.MASTER_SITE_URL}mdb-client/isactive/${clientId}`);
            //     const checkClientStatus = await checkClientResult.json();
            //     if (!checkClientStatus?.status) {
            //         apiResponse.message = "Your application is not active. Please contact your administrator for assistance.";
            //         this.setStatus(401);
            //         return CommonHelper.apiSwaggerErrorResponse(apiResponse);
            //     }
            // }

            let ldapActive = false;
            let ldapStatus: any = await Container.get(DataSource)
                .getRepository(MenuModule)
                .findOne({
                    where: {
                        moduleName: "ANALYST_LDAP",
                        clientId: clientId,
                    },
                });
            if (ldapStatus?.isActive) {
                ldapActive = true;
            }

            let loginRedirectUrl = "/dashboard-wrapper/dashboard";
            let menuResult: any = await Container.get(DataSource)
                .getRepository(ClientNavigation)
                .findOne({
                    where: {
                        clientId: clientId,
                    },
                });
            if (menuResult?.loginRedirectUrl) {
                loginRedirectUrl = menuResult.loginRedirectUrl;
            }
            if (ldapActive && userDetails[0].isSuperAdmin !== 1) {
                const whereCondition: any = {
                    where: { clientId, type: "ANALYST_LDAP" },
                };
                const ldapSettings = await dbService._findQueryService(
                    Container.get(DataSource).getRepository(SettingConfig),
                    { ...whereCondition }
                );
                if (ldapSettings?.length) {
                    let configData = JSON.parse(ldapSettings[0].config) || {};
                    if (!configData.analystLdapURL) {
                        apiResponse.message = `Server URL is null or Empty.`;
                        return CommonHelper.apiSwaggerErrorResponse(
                            apiResponse
                        );
                    }
                    const ldapCheck = await LdapAuthUtil.ldapCheckUser(
                        configData.analystLdapURL,
                        request.body.email.toLowerCase(),
                        requestBody.password
                    );
                    if (!ldapCheck.status) {
                        apiResponse.message = ldapCheck.message;
                        return CommonHelper.apiSwaggerErrorResponse(
                            apiResponse
                        );
                    }

                    const jwtDataSet = {
                        id: userDetails[0].id,
                        role_id: userDetails[0].roleId,
                        username: userDetails[0].username,
                        useremail: userDetails[0].email, // added user email so that we can log it
                        client_id: clientId,
                        is_superadmin: userDetails[0].isSuperAdmin,
                        loginDate: new Date(),
                    };
                    let token = JwtEncryptUtil.encryptedCode(jwtDataSet, "1d");
                    this.setStatus(200);
                    this.setHeader(
                        "Set-Cookie",
                        `auth=${token}; SameSite=None; Secure; HttpOnly; Max-Age=${
                            process.env.COOKIE_TIMEOUT_SECONDS || 24 * 60 * 60
                        }; path=/`
                    );
                    userLoginDetails = userDetails[0];
                    userLoginDetails["roleid"] = userLoginDetails["roleId"];
                    return CommonHelper.apiSwaggerSuccessResponse({
                        data: {
                            user: userLoginDetails,
                            loginRedirectUrl: loginRedirectUrl,
                        },
                    });
                }
            } else {
                if (
                    (userDetails[0].isView360Login === 1 &&
                        isValidUser &&
                        !requestBody.appType) ||
                    requestBody?.appType === "pwa"
                ) {
                    const failAttemptUpdate = {
                        failpwdAttempt: userDetails[0].failpwdAttempt + 1,
                    };
                    if (!requestBody.password || !userDetails[0].password) {
                        await dbService._updateQueryService(
                            Container.get(DataSource).getRepository(Users),
                            {
                                paramsObj: {
                                    id: userDetails[0].id,
                                    clientId: clientId,
                                },
                                ...failAttemptUpdate,
                            }
                        );
                        apiResponse.message =
                            "You have entered Invalid email or password. Please try again with correct credentials";
                        return CommonHelper.apiSwaggerErrorResponse(
                            apiResponse
                        );
                    }
                    let isPasswordValid: any =
                        await ClientSubscriptionUtil.verifyPassword(
                            requestBody.password,
                            userDetails[0].password,
                            userDetails[0],
                            userLoginDetails
                        );
                    if (!isPasswordValid.status) {
                        await dbService._updateQueryService(
                            Container.get(DataSource).getRepository(Users),
                            {
                                paramsObj: {
                                    id: userDetails[0].id,
                                    clientId: clientId,
                                },
                                ...failAttemptUpdate,
                            }
                        );
                        apiResponse.message =
                            "You have entered Invalid email or password. Please try again with correct credentials";
                        return CommonHelper.apiSwaggerErrorResponse(
                            apiResponse
                        );
                    }

                    if (
                        process.env.APP_ENQ === undefined ||
                        process.env.APP_ENQ.toLowerCase() != "false"
                    ) {
                        const lke = await checkValidity(
                            userDetails[0].mdbClient.id
                        );
                        switch (lke) {
                            case "NLKF":
                                this.setStatus(400);
                                return CommonHelper.apiSwaggerErrorResponse({
                                    error: {
                                        error_description:
                                            "No License Key found. Please contact administrator for more information.",
                                        error_code: "NLKF",
                                        userDetails: {
                                            fullName:
                                                userDetails[0].firstName +
                                                " " +
                                                userDetails[0].lastName,
                                            clientId:
                                                userDetails[0].mdbClient.id,
                                        },
                                    },
                                    message:
                                        "No License Key found. Please contact administrator for more information.",
                                });
                            case "LKE":
                                this.setStatus(400);
                                return CommonHelper.apiSwaggerErrorResponse({
                                    error: {
                                        error_description:
                                            "License Key Expired. Please contact administrator for more information.",
                                        error_code: "LKE",
                                        userDetails: {
                                            fullName:
                                                userDetails[0].firstName +
                                                " " +
                                                userDetails[0].lastName,
                                            clientId:
                                                userDetails[0].mdbClient.id,
                                        },
                                    },
                                    message:
                                        "License Key Expired. Please contact administrator for more information.",
                                });
                            case "SYSTIMEERR":
                                this.setStatus(400);
                                return CommonHelper.apiSwaggerErrorResponse({
                                    error: {
                                        error_description:
                                            "Invalid or Expired License Key. Please contact administrator for more information.",
                                        error_code: "SYSTIMEERR",
                                        userDetails: {
                                            fullName:
                                                userDetails[0].firstName +
                                                " " +
                                                userDetails[0].lastName,
                                            clientId:
                                                userDetails[0].mdbClient.id,
                                        },
                                    },
                                    message:
                                        "Invalid or Expired License Key. Please contact administrator for more information.",
                                });
                            case "USAGEEXCEED":
                                this.setStatus(400);
                                return CommonHelper.apiSwaggerErrorResponse({
                                    error: {
                                        error_description:
                                            "You have exhausted the provided limit. Please contact administrator for more information.",
                                        error_code: "USAGEEXCEED",
                                        userDetails: {
                                            fullName:
                                                userDetails[0].firstName +
                                                " " +
                                                userDetails[0].lastName,
                                            clientId:
                                                userDetails[0].mdbClient.id,
                                        },
                                    },
                                    message:
                                        "You have exhausted the provided limit. Please contact administrator for more information.",
                                });
                        }
                    }

                    const userRoles = await dbService._findQueryService(
                        Container.get(DataSource).getRepository(UserRoles),
                        {
                            where: { id: userDetails[0].roleId },
                        }
                    );
                    if (
                        process.env.TWO_FACTOR === "true" &&
                        userRoles[0].mfa === 1 &&
                        !request.body.Skip2FA
                    ) {
                        const SecretKey = userDetails[0].secretKey;
                        if (
                            CommonUtil.isNullOrEmpty(requestBody.token) &&
                            !CommonUtil.isNullOrEmpty(SecretKey)
                        ) {
                            this.setStatus(200);
                            return CommonHelper.apiSwaggerSuccessResponse({
                                data: { verifyToken: true },
                            });
                        } else {
                            const SecretKey = userDetails[0].secretKey;
                            if (CommonUtil.isNullOrEmpty(SecretKey)) {
                                // Generate Secret Key
                                const secretKey =
                                    await this.twoFactorService.generateSecret();
                                const secretKeyDecrypted = await Crypto.decr(
                                    "",
                                    secretKey
                                );
                                const qrCode =
                                    await this.twoFactorService.generateQRCode(
                                        userDetails[0].email,
                                        secretKey
                                    );
                                this.setStatus(200);
                                return CommonHelper.apiSwaggerSuccessResponse({
                                    data: {
                                        user: userDetails[0],
                                        scanQrcode: true,
                                        QRCode: qrCode,
                                        secretKey: secretKeyDecrypted,
                                    },
                                });
                            }
                            if (
                                await this.twoFactorService.verify(
                                    SecretKey,
                                    requestBody.token
                                )
                            ) {
                                const userData = userDetails[0];
                            } else {
                                this.setStatus(401);
                                apiResponse.message =
                                    "Invalid token. Please try again with correct token.";
                                return CommonHelper.apiSwaggerErrorResponse(
                                    apiResponse
                                );
                            }
                        }
                    }

                    const jwtDataSet = {
                        id: userDetails[0].id,
                        role_id: userDetails[0].roleId,
                        username: userDetails[0].username,
                        useremail: userDetails[0].email, // added user email so that we can log it
                        client_id: clientId,
                        is_superadmin: userDetails[0].isSuperAdmin,
                        loginDate: new Date(),
                    };

                    const loginUpdate = {
                        lastLoginDate: userDetails[0].currentLoginDate,
                        currentLoginDate: new Date(),
                    };
                    await dbService._updateQueryService(
                        Container.get(DataSource).getRepository(Users),
                        {
                            paramsObj: {
                                id: userDetails[0].id,
                                clientId: clientId,
                            },
                            failpwdAttempt: 0,
                        }
                    );
                    await dbService._updateQueryService(
                        Container.get(DataSource).getRepository(Users),
                        {
                            paramsObj: {
                                id: userDetails[0].id,
                                clientId: clientId,
                            },
                            ...loginUpdate,
                        }
                    );

                    await dbService._updateQueryService(
                        Container.get(DataSource).getRepository(UserBkp),
                        {
                            paramsObj: {
                                email: userDetails[0].email,
                                clientId: clientId,
                            },
                            ...loginUpdate,
                        }
                    );
                    let token = JwtEncryptUtil.encryptedCode(jwtDataSet, "1d");
                    AccessLogger.info({
                        userid: jwtDataSet.id,
                        username: jwtDataSet.username,
                        useremail: jwtDataSet.useremail,
                        timestamp: requestStart,
                        accessdatetime: moment(requestStart).format(
                            "MM-DD-YYYY HH:mm:ss"
                        ),
                        processingTime: Date.now() - requestStart,
                        errorMessage: "",
                        reqURL: request.url,
                        ip: request.ip,
                    });

                    this.setStatus(200);
                    this.setHeader(
                        "Set-Cookie",
                        `auth=${token}; SameSite=None; Secure; HttpOnly; Max-Age=${
                            process.env.COOKIE_TIMEOUT_SECONDS || 24 * 60 * 60
                        }; path=/`
                    );
                    return CommonHelper.apiSwaggerSuccessResponse({
                        data: {
                            user: userLoginDetails,
                            loginRedirectUrl: loginRedirectUrl,
                        },
                    });
                } else {
                    apiResponse.message = "Access Denied for this Application.";
                    this.setStatus(403);
                    return CommonHelper.apiSwaggerErrorResponse(apiResponse);
                }
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    // @Post("login")
    // async login(
    //     @Body() requestBody: LoginRequest,
    //     @Request() request: any
    // ): Promise<LoginResponse | unknown> {
    //     this.setStatus(500);
    //     const requestStart = Date.now();
    //     const apiResponse: any = { status: false, data: {} };

    //     try {
    //         const userDetails = await this.getUserDetails(request.body.email);
    //         if (!userDetails) {
    //             return this.userNotFoundResponse(apiResponse);
    //         }

    //         const clientId = userDetails.mdbClient.id;
    //         if (!(await this.isClientActive(request, clientId))) {
    //             return this.clientInactiveResponse(apiResponse);
    //         }

    //         console.log(userDetails, "userDetails");
    //         if (
    //             (await this.isLdapActive(clientId)) &&
    //             userDetails.isSuperAdmin !== 1
    //         ) {
    //             return this.handleLdapLogin(
    //                 requestBody,
    //                 userDetails,
    //                 clientId,
    //                 apiResponse
    //             );
    //         }

    //         return await this.handlePasswordLogin(
    //             requestBody,
    //             userDetails,
    //             request,
    //             clientId,
    //             apiResponse,
    //             requestStart
    //         );
    //     } catch (error) {
    //         return this.handleError(apiResponse, error);
    //     }
    // }

    // private async getUserDetails(email: string) {
    //     const userDetails = await dbService._userLoginService(
    //         Container.get(DataSource).getRepository(Users),
    //         { email: toLower(email) }
    //     );
    //     return userDetails?.length === 1 && userDetails[0].mdbClient
    //         ? userDetails[0]
    //         : null;
    // }

    // private userNotFoundResponse(apiResponse: any) {
    //     apiResponse.message = "User not found!!";
    //     this.setStatus(401);
    //     return CommonHelper.apiSwaggerErrorResponse(apiResponse);
    // }

    // private async isClientActive(request: any, clientId: number) {
    //     if (!request.headers.origin.includes("localhost:")) {
    //         const response = await fetch(
    //             `${process.env.MASTER_SITE_URL}mdb-client/isactive/${clientId}`
    //         );
    //         const status = await response.json();
    //         return status?.status;
    //     }
    //     return true;
    // }

    // private clientInactiveResponse(apiResponse: any) {
    //     apiResponse.message =
    //         "Your application is not active. Please contact your administrator.";
    //     this.setStatus(401);
    //     return CommonHelper.apiSwaggerErrorResponse(apiResponse);
    // }

    // private async isLdapActive(clientId: number) {
    //     const ldapStatus = await Container.get(DataSource)
    //         .getRepository(MenuModule)
    //         .findOne({ where: { moduleName: "ANALYST_LDAP", clientId } });
    //     return ldapStatus?.isActive || false;
    // }

    // private async handleLdapLogin(
    //     requestBody: LoginRequest,
    //     userDetails: any,
    //     clientId: number,
    //     apiResponse: any
    // ) {
    //     const ldapSettings = await dbService._findQueryService(
    //         Container.get(DataSource).getRepository(SettingConfig),
    //         { where: { clientId, type: "ANALYST_LDAP" } }
    //     );

    //     if (
    //         !ldapSettings?.length ||
    //         !this.validateLdap(requestBody, ldapSettings[0].config)
    //     ) {
    //         apiResponse.message = `Server URL is null or Empty.`;
    //         return CommonHelper.apiSwaggerErrorResponse(apiResponse);
    //     }

    //     const jwtDataSet = this.generateJwtDataSet(userDetails, clientId);
    //     const token = JwtEncryptUtil.encryptedCode(jwtDataSet, "1d");
    //     this.setStatus(200);
    //     this.setCookie(token);

    //     return CommonHelper.apiSwaggerSuccessResponse({
    //         data: {
    //             user: userDetails,
    //             loginRedirectUrl: await this.getLoginRedirectUrl(clientId),
    //         },
    //     });
    // }

    // private validateLdap(requestBody: LoginRequest, config: string) {
    //     const configData = JSON.parse(config) || {};
    //     if (!configData.analystLdapURL) return false;

    //     const ldapCheck = LdapAuthUtil.ldapCheckUser(
    //         configData.analystLdapURL,
    //         requestBody.email.toLowerCase(),
    //         requestBody.password
    //     );
    //     return ldapCheck.status;
    // }

    // private generateJwtDataSet(userDetails: any, clientId: number) {
    //     return {
    //         id: userDetails.id,
    //         role_id: userDetails.roleId,
    //         username: userDetails.username,
    //         useremail: userDetails.email,
    //         client_id: clientId,
    //         is_superadmin: userDetails.isSuperAdmin,
    //         loginDate: new Date(),
    //     };
    // }

    // private setCookie(token: string) {
    //     this.setHeader(
    //         "Set-Cookie",
    //         `auth=${token}; SameSite=None; Secure; HttpOnly; Max-Age=${
    //             process.env.COOKIE_TIMEOUT_SECONDS || 24 * 60 * 60
    //         }; path=/`
    //     );
    // }

    // private async getLoginRedirectUrl(clientId: number) {
    //     const menuResult = await Container.get(DataSource)
    //         .getRepository(ClientNavigation)
    //         .findOne({ where: { clientId } });
    //     return menuResult?.loginRedirectUrl || "/dashboard-wrapper/dashboard";
    // }

    // private async handlePasswordLogin(
    //     requestBody: LoginRequest,
    //     userDetails: any,
    //     request: any,
    //     clientId: number,
    //     apiResponse: any,
    //     requestStart: number
    // ) {
    //     if (!this.isPasswordValid(requestBody, userDetails, apiResponse)) {
    //         return CommonHelper.apiSwaggerErrorResponse(apiResponse);
    //     }

    //     if (
    //         !(await this.checkLicenseValidity(
    //             userDetails.mdbClient.id,
    //             requestStart,
    //             request
    //         ))
    //     ) {
    //         return CommonHelper.apiSwaggerErrorResponse(apiResponse);
    //     }

    //     return this.processLoginSuccess(
    //         request,
    //         userDetails,
    //         clientId,
    //         requestStart
    //     );
    // }

    // private async isPasswordValid(
    //     requestBody: LoginRequest,
    //     userDetails: any,
    //     apiResponse: any
    // ) {
    //     if (!requestBody.password || !userDetails.password) {
    //         apiResponse.message = "You have entered Invalid email or password.";
    //         return false;
    //     }

    //     const isPasswordValid: any =
    //         await ClientSubscriptionUtil.verifyPassword(
    //             requestBody.password,
    //             userDetails.password,
    //             userDetails,
    //             userDetails
    //         );
    //     if (!isPasswordValid.status) {
    //         apiResponse.message = "You have entered Invalid email or password.";
    //         return false;
    //     }

    //     return true;
    // }

    // private async checkLicenseValidity(
    //     clientId: any,
    //     requestStart: number,
    //     request: any
    // ) {
    //     if (
    //         process.env.APP_ENQ === undefined ||
    //         process.env.APP_ENQ.toLowerCase() !== "false"
    //     ) {
    //         const lke = await checkValidity(clientId);
    //         if (lke !== "VALID") {
    //             this.setStatus(400);
    //             return false;
    //         }
    //     }
    //     return true;
    // }

    // private async processLoginSuccess(
    //     request: any,
    //     userDetails: any,
    //     clientId: number,
    //     requestStart: number
    // ) {
    //     const jwtDataSet = this.generateJwtDataSet(userDetails, clientId);
    //     const token = JwtEncryptUtil.encryptedCode(jwtDataSet, "1d");
    //     this.setStatus(200);
    //     this.setCookie(token);

    //     await this.updateLoginDetails(userDetails, clientId);
    //     await this.logAccess(request, jwtDataSet, requestStart);

    //     return CommonHelper.apiSwaggerSuccessResponse({
    //         data: {
    //             user: userDetails,
    //             loginRedirectUrl: await this.getLoginRedirectUrl(clientId),
    //         },
    //     });
    // }

    // private async updateLoginDetails(userDetails: any, clientId: number) {
    //     const loginUpdate = {
    //         lastLoginDate: userDetails.currentLoginDate,
    //         currentLoginDate: new Date(),
    //     };

    //     await dbService._updateQueryService(
    //         Container.get(DataSource).getRepository(Users),
    //         {
    //             paramsObj: { id: userDetails.id, clientId },
    //             ...loginUpdate,
    //             failpwdAttempt: 0,
    //         }
    //     );

    //     await dbService._updateQueryService(
    //         Container.get(DataSource).getRepository(UserBkp),
    //         {
    //             paramsObj: { email: userDetails.email, clientId },
    //             ...loginUpdate,
    //         }
    //     );
    // }

    // private async logAccess(
    //     request: any,
    //     jwtDataSet: any,
    //     requestStart: number
    // ) {
    //     AccessLogger.info({
    //         userid: jwtDataSet.id,
    //         username: jwtDataSet.username,
    //         useremail: jwtDataSet.useremail,
    //         timestamp: requestStart,
    //         accessdatetime: moment(requestStart).format("MM-DD-YYYY HH:mm:ss"),
    //         processingTime: Date.now() - requestStart,
    //         errorMessage: "",
    //         reqURL: request.url,
    //         ip: request.ip,
    //     });
    // }

    // private handleError(apiResponse: any, error: Error) {
    //     const apiErrorResponse: ApiErrorResponse = {
    //         error: { error_description: error.message },
    //     };
    //     this.setStatus(500);
    //     return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
    // }

    @Security("bearerAuth")
    @Post("logout")
    async logout(@Request() request: any): Promise<unknown> {
        const apiResponse: any = {
            message: "Logout successfully!!",
            data: null,
        };
        this.setHeader("Set-Cookie", `auth=; HttpOnly; Max-Age=0; path=/`);
        return CommonHelper.apiSwaggerSuccessResponse({ ...apiResponse });
    }

    @Get("sso-status")
    async ssoStatus(@Request() request: any): Promise<SsoStatusResponse> {
        const apiResponse: any = {
            message: "SSO Status!!",
            data: {
                ssoActive: false,
            },
        };

        let origin: any = await CommonUtil.getOriginUrl(request.headers.origin);
        // if (origin === "localhost") {
        //     origin = "v2dev.epikdev.org";
        // }
        let result: any = await Container.get(DataSource)
            .getRepository(MdbClient)
            .findOne({
                where: {
                    websiteUrl: origin,
                },
            });
        if (result) {
            let menuResult: any = await Container.get(DataSource)
                .getRepository(MenuModule)
                .findOne({
                    where: {
                        moduleName: "SSO_ADFS_SAML",
                        clientId: result.id,
                    },
                });
            if (menuResult?.isActive) {
                apiResponse.data.ssoActive = true;
            }
        }

        return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
    }

    @Post("forgot-password")
    async forgotPassword(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<unknown> {
        const apiResponse = { status: false, data: null };
        let origin: any = await CommonUtil.getOriginUrl(request.headers.origin);
        let result: any = await Container.get(DataSource)
            .getRepository(MdbClient)
            .findOne({
                where: {
                    websiteUrl: origin,
                },
            });
        if (result) {
            let whereCondition: any = {
                clientId: result.id,
                email: toLower(requestBody.email),
            };
            const selectedFields: any = ["id", "username"];

            const userResults = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: whereCondition,
                    select: selectedFields,
                }
            );

            if (userResults?.length > 0) {
                let expireTimeInSecond = parseInt(
                    process.env.FORGOT_EXPIRE_TIME.slice(0, -1)
                );
                let jwtData = {
                    id: userResults[0].id,
                    client_id: result.id,
                };
                let jwtExp = {
                    expiresIn: process.env.FORGOT_EXPIRE_TIME,
                };
                let pwaExtraMsg = "";

                if (requestBody.type === "pwa") {
                    jwtData["otpKey"] = Math.floor(
                        100000 + Math.random() * 900000
                    ).toString();
                    jwtExp.expiresIn = process.env.forgotPasswordPwaExpireTime;
                    expireTimeInSecond = parseInt(
                        process.env.forgotPasswordPwaExpireTime.slice(0, -1)
                    );

                    pwaExtraMsg = `<tr><td>Or for Pwa OTP is: <span style="font-size: 20px;font-weight: bold;color: brown;">${jwtData["otpKey"]}</span></td></tr>`;
                }

                let token = jwt.sign(jwtData, process.env.SECRET_KEY, jwtExp);
                if (token) {
                    const updateData = { changePasswordToken: token };
                    const whereConditionForUpdateUsers: any = {
                        id: userResults[0].id,
                        clientId: result.id,
                    };
                    const updateResponse = await dbService._updateQueryService(
                        Container.get(DataSource).getRepository(Users),
                        {
                            paramsObj: whereConditionForUpdateUsers,
                            ...updateData,
                        }
                    );
                    if (updateResponse?.affected) {
                        const transporter = nodemailer.createTransport({
                            host: siteConfig.MAIL_HOST,
                            port: siteConfig.MAIL_PORT,
                            secureConnection: true,
                            auth: {
                                user: siteConfig.MAIL_AUTH_USER,
                                pass: siteConfig.MAIL_AUTH_PASS,
                            },
                        });

                        let forgotURL = "https://" + origin + "/auth/" + token;
                        let expireTime = expireTimeInSecond / (60 * 60);

                        let mailbody = `<table cellpadding='10' style='margin:0 auto; max-width:640px; border:1px solid #ddd'> <tr><td><strong>Hi ${userResults[0].username}</strong></td></tr> <tr> <td>You recently requested to reset your password for ${origin} account. Click the button below to reset it.</td> </tr>${pwaExtraMsg}<tr> <td style='text-align:center;'><a href='${forgotURL}' target='_blank' style='text-decoration:none; background: #085291; border-radius: 2px;color: #ffffff; padding: 10px 25px; height: 45px; font-size: 13px; font-weight: 600; width: 130px;'>Reset Your Password</a></td> </tr> <tr> <td>If you did not request a password reset, please ignore this email or reply to let us know. This password reset is only vaild for the ${expireTime} hours</td> </tr> <tr> <td>Thanks, <br> ${origin}</td> </tr> <tr> <td><hr></td> </tr> <tr> <td>If you're having trouble clicking the password reset button, copy and paste the URL below into your web browser</td> </tr> <tr> <td><a href='${forgotURL}'>${forgotURL}</a></td> </tr> </table>`;

                        const mailOptions = {
                            from: siteConfig.MAIL_AUTH_USER,
                            to: requestBody.email,
                            subject: "Reset password",
                            html: mailbody,
                            importantMail: true,
                        };
                        await transporter.sendMail(mailOptions);
                        apiResponse.status = true;
                    }
                    return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
                }
            } else {
                return CommonHelper.apiSwaggerErrorResponse({
                    error: "notValidEmail",
                    message: "Something went wrong !",
                });
            }
        } else {
            return CommonHelper.apiSwaggerErrorResponse({
                error: "notValidEmail",
                message: "Something went wrong !",
            });
        }
    }

    @Post("check-password")
    async checkPassword(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<unknown> {
        const apiResponse = { status: false, data: null };
        let decodedToken = null;
        try {
            decodedToken = jwt.verify(
                requestBody.token,
                process.env.SECRET_KEY
            );
        } catch (error) {}

        if (
            (decodedToken && decodedToken.id) ||
            (request.type && request.type === "pwa")
        ) {
            let whereCondition: any = {
                changePasswordToken: requestBody.token,
            };
            const selectedFields: any = ["id", "clientId"];

            const userResults: any = await dbService._findQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    where: whereCondition,
                    select: selectedFields,
                }
            );
            if (userResults && userResults.length > 0) {
                apiResponse.status = true;
                apiResponse.data = userResults[0];
            } else {
                return CommonHelper.apiSwaggerErrorResponse({
                    error: "invalidToken",
                    message: "Something went wrong !",
                });
            }
        }
        return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
    }

    @Post("change-password")
    async changePassword(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<unknown> {
        let decodedToken = null;
        const apiResponse = { status: false, data: null };
        try {
            decodedToken = jwt.verify(
                requestBody.token,
                process.env.SECRET_KEY
            );
        } catch (error) {}

        if (
            (decodedToken && decodedToken.id) ||
            (requestBody.body.type &&
                requestBody.body.type === "pwa" &&
                requestBody.body.id &&
                requestBody.body.id !== "" &&
                requestBody.body.client_id &&
                requestBody.body.client_id !== "")
        ) {
            const salt = bcrypt.genSaltSync(10);
            let hashpassword = await bcrypt.hash(requestBody.password, salt);
            const updateData = {
                password: hashpassword,
                changePasswordToken: null,
            };
            let whereCondition = {};
            if (decodedToken && decodedToken.id) {
                whereCondition = {
                    id: decodedToken.id,
                    clientId: decodedToken.client_id,
                };
            } else {
                whereCondition = {
                    id: requestBody.id,
                    clientId: requestBody.client_id,
                };
            }
            const updateResponse = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    paramsObj: whereCondition,
                    ...updateData,
                }
            );
            if (updateResponse && updateResponse.affected) {
                apiResponse.status = true;
                apiResponse.data = updateResponse.affected;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } else {
            return CommonHelper.apiSwaggerErrorResponse({
                error: "tokenExpire",
                message: "Sorry, your token expired",
            });
        }
    }

    @Get("analyst-ldap-status")
    async analystLdapStatus(@Request() request: any): Promise<LdapResponse> {
        const apiResponse: any = {
            message: "Analyst Ldap Status!!",
            data: {
                ldapActive: false,
            },
        };

        let origin: any = await CommonUtil.getOriginUrl(request.headers.origin);
        let result: any = await Container.get(DataSource)
            .getRepository(MdbClient)
            .findOne({
                where: {
                    websiteUrl: origin,
                },
            });
        if (result) {
            let menuResult: any = await Container.get(DataSource)
                .getRepository(MenuModule)
                .findOne({
                    where: {
                        moduleName: "ANALYST_LDAP",
                        clientId: result.id,
                    },
                });
            if (menuResult?.isActive) {
                apiResponse.data.ldapActive = true;
            }
        }

        return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
    }

    @Get("reCaptcha-config")
    async googleRecaptcha(@Request() request: any): Promise<ReCaptchaResponse> {
        const apiResponse: any = {
            message: "recaptcha Status!!",
            data: {
                recaptchaActive: false,
                data: [],
            },
        };

        let origin: any = await CommonUtil.getOriginUrl(request.headers.origin);
        if (origin === "localhost") {
            origin = "v2dev.epikdev.org";
        }
        let result: any = await Container.get(DataSource)
            .getRepository(MdbClient)
            .findOne({
                where: {
                    websiteUrl: origin,
                },
            });

        if (result) {
            let captchaResult: any = await Container.get(DataSource)
                .getRepository(MenuModule)
                .findOne({
                    where: {
                        moduleName: "GOOGLE_CAPTCHA",
                        clientId: result.id,
                    },
                });
            if (captchaResult?.isActive) {
                const whereCondition: any = {
                    where: { clientId: result.id, type: "GOOGLE_CAPTCHA" },
                };

                const settingConfigs = await dbService._findQueryService(
                    Container.get(DataSource).getRepository(SettingConfig),
                    { ...whereCondition }
                );
                apiResponse.data.recaptchaActive = true;
                apiResponse.data.data = settingConfigs;
            }
        }

        return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
    }

    @Post("verify-reCaptcha")
    async verifyRecaptcha(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<any> {
        const apiResponse: any = {
            message: "recaptcha Status!!",
            data: {
                recaptchaActive: false,
                message: "reCAPTCHA verification failed",
            },
        };
        const response = await fetch(
            `https://www.google.com/recaptcha/api/siteverify?secret=${requestBody.secretKey}&response=${requestBody.captchaResponse}`,
            {
                method: "POST",
            }
        );
        const data = await response.json();

        if (data.success) {
            apiResponse.data.recaptchaActive = true;
            apiResponse.data.message = "reCAPTCHA verification Successfully";
        } else {
            this.setStatus(400);
        }
        return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
    }
}
