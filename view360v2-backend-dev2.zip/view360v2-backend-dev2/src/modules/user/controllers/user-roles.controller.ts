import { DataSource, Not } from "typeorm";
import { MdbClient, UserRoles } from "../../../entities";
import dbService from "../../../services/db.service";
import {
    Body,
    Get,
    Path,
    Post,
    Request,
    Route,
    Security,
    Tags,
    Delete,
    Controller,
    Patch,
    Query,
    Middlewares,
} from "tsoa";
import { UserRoleResponse, DeleteRoles } from "../doc/user-roles.interface";
import Container from "typedi";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import { USER_ROLES } from "../../../utils/constants/user-roles";
import { CommonUtil } from "utils/common.util";
import { validateEntryCount } from "../../../middlewares/common.middleware";

@Route("")
@Tags("User Role")
export class UserRolesController extends Controller {
    @Security("bearerAuth")
    @Middlewares(validateEntryCount)
    @Post("role")
    async addRole(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<UserRoleResponse> {
        try {
            const payload: any = {
                name: requestBody.name,
                description: requestBody.description,
                mfa: requestBody.mfa ? requestBody.mfa : 0,
                permission: JSON.stringify(requestBody.permission),
                isDefaultRole: 0,
            };
            payload.clientId = request.userDetails.client_id;
            payload.createdBy = request.userDetails.id;

            const results = await dbService._createQueryService(
                Container.get(DataSource).getRepository(UserRoles),
                payload
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Patch("role/:id")
    async editRole(
        @Path() id: string,
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<UserRoleResponse> {
        try {
            const payload = {
                clientId: request.userDetails.client_id,
                name: requestBody.name,
                description: requestBody.description,
                mfa: requestBody.mfa ? requestBody.mfa : 0,
                permission: JSON.stringify(requestBody.permission),
                isDefaultRole: 0,
                createdBy: request.userDetails.id,
            };
            const results = await dbService._updateQueryService(
                Container.get(DataSource).getRepository(UserRoles),
                { id: id, ...payload }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: results });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("role")
    async getAllRoles(
        @Request() request: any,
        @Query("pagination") pagination: boolean = true,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<UserRoleResponse> {
        try {
            const { isSuperAdmin, rbav } = request.query;
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };

            let whereCondition: any = {};
            whereCondition.clientId = request.userDetails.client_id;

            if (rbav === "owner") {
                whereCondition.createdBy = request.userDetails.id;
            }

            if (!isSuperAdmin) {
                whereCondition.isDefaultRole = Not(1);
            }

            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["createdOn"] = sortOrder;
            }

            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(UserRoles),
                {
                    where: whereCondition,
                }
            );
            const userRoles = await dbService._findQueryService(
                Container.get(DataSource).getRepository(UserRoles),
                {
                    select: {
                        id: true,
                        name: true,
                        mfa: true,
                        createdBy: true,
                        createdOn: true,
                        isDefaultRole: true,
                    },
                    where: whereCondition, // Use queryObj directly instead of spreading it
                    take: pagination ? pageSize : totalRecordCount,
                    skip: pagination ? (page - 1) * pageSize : 0,
                    order: sortObject,
                }
            );
            apiResponse.data = userRoles;
            apiResponse.recordsTotal = totalRecordCount;
            apiResponse.recordsFiltered = pageSize;

            const totalPages = Math.ceil(totalRecordCount / pageSize);
            apiResponse.totalPages = totalPages;

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("role-list")
    async getAllTokenRoles(
        @Request() request: any
    ): Promise<UserRoleResponse> {
        try {
            let origin: any = await CommonUtil.getOriginUrl(request.headers.origin);
            const clientDetails = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MdbClient),
                {
                    where: [
                        { websiteUrl: origin },
                        { pwaUrl: origin },
                    ]
                }
            );
            if (!clientDetails?.length || !clientDetails[0]?.id) {
                return CommonHelper.apiSwaggerErrorResponse({ error: { error_description: 'Bad Request: Client is Required!!' } });
            }

            const { isSuperAdmin, rbav } = request.query;
            const apiResponse = {
                data: [],
            };

            let whereCondition: any = {};
            whereCondition.clientId = clientDetails[0].id

            if (!isSuperAdmin) {
                whereCondition.isDefaultRole = Not(1);
            }

            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(UserRoles),
                {
                    where: whereCondition,
                }
            );
            const userRoles = await dbService._findQueryService(
                Container.get(DataSource).getRepository(UserRoles),
                {
                    select: {
                        id: true,
                        name: true,
                        mfa: true,
                        createdBy: true,
                        createdOn: true,
                        isDefaultRole: true,
                    },
                    where: whereCondition, // Use queryObj directly instead of spreading it
                }
            );
            apiResponse.data = userRoles;

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("role/:id")
    async getRoleDetails(
        @Path() id: string,
        @Request() request: any
    ): Promise<UserRoleResponse> {
        try {
            if (id === "default") {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: USER_ROLES,
                });
            }
            const { perPage = 10, current = 1, clientId } = request.query;

            const startPoint =
                (parseInt(current.toString(), 10) - 1) *
                parseInt(perPage.toString(), 10);
            const queryObj = {};
            if (clientId) {
                queryObj["client_id"] = clientId;
            }
            if (id) {
                queryObj["id"] = id;
            }
            const userRoles = await dbService._findQueryService(
                Container.get(DataSource).getRepository(UserRoles),
                {
                    where: { ...queryObj },
                    take: +perPage,
                    skip: startPoint,
                }
            );
            if (userRoles && userRoles.length) {
                let responsedata = {
                    data: null,
                    status: true,
                };
                let permission = {};
                //check if role is Super Admin
                if (userRoles[0].name == "Super Admin") {
                    permission = USER_ROLES;
                } else {
                    permission = JSON.parse(userRoles[0].permission);
                }

                responsedata.data = userRoles[0];
                responsedata.data.permission = permission;

                return responsedata;
            }
            return CommonHelper.apiSwaggerSuccessResponse({ data: userRoles });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Delete Role
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */

    @Security("bearerAuth")
    @Delete("role")
    async deleteRoles(
        @Body() requestBody: DeleteRoles
    ): Promise<UserRoleResponse> {
        try {
            const roleDelete = await dbService._deleteQueryService(
                Container.get(DataSource).getRepository(UserRoles),
                { id: requestBody.id }
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: roleDelete });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(400);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
