import {
    Body,
    Get,
    Path,
    Post,
    Request,
    Route,
    Security,
    Tags,
    Controller,
    Query,
} from "tsoa";
import dbService from "../../../services/db.service";
import {
    CommonHelper,
    ApiErrorResponse,
} from "../../../utils/helpers/common.helper";
import Container from "typedi";
import { DataSource, ILike, Like, Not } from "typeorm";
import { RoleInvites, Users } from "../../../entities";
import { CommunicationHelper } from "../../../utils/helpers/communication.helper";
import { UserService } from "../../user/services/user.service";
import * as bcrypt from "bcryptjs";
import * as crypto from "crypto";
import {
    InviteResponse,
    InviteRequestBody,
    InviteRegisterRequestBody,
    InviteDataTableListResponse,
} from "../doc/invites.interface";
import { CommonUtil } from "utils/common.util";
@Route("")
@Tags("Invites")
export class RoleInvitesController extends Controller {
    private communicationHelperService: CommunicationHelper =
        new CommunicationHelper();
    private userService: UserService = new UserService();

    async isValidJSON(str) {
        try {
            JSON.parse(str);
            return true;
        } catch (e) {
            return false;
        }
    }

    async applyFilterCondition(columnName, filter) {
        let whereCondition = {};

        if (filter && filter[0].value) {
            const value = filter[0].value;
            const matchMode = filter[0].matchMode;

            if (matchMode === "contains") {
                whereCondition[columnName] = Like(`%${value}%`);
            } else if (matchMode === "equals") {
                whereCondition[columnName] = value;
            } else if (matchMode === "startsWith") {
                whereCondition[columnName] = Like(`${value}%`);
            } else if (matchMode === "endsWith") {
                whereCondition[columnName] = Like(`%${value}`);
            } else if (matchMode === "notContains") {
                whereCondition[columnName] = Not(Like(`%${value}%`));
            } else if (matchMode === "notEquals") {
                whereCondition[columnName] = Not(value);
            }
        }

        return {
            sqlCondition: Object.keys(whereCondition)
                .map(
                    (field) =>
                        `${field} ${whereCondition[field]._type} :${field}`
                )
                .join(" AND "),
            parameters: Object.keys(whereCondition).reduce((params, field) => {
                params[field] = whereCondition[field]._value;
                return params;
            }, {}),
        };
    }

    @Security("bearerAuth")
    @Get("invites")
    async getRoleInvites(
        @Request() req: Request | any,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<InviteResponse> {
        try {
            let whereCondition: any = {};
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };

            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["createdOn"] = sortOrder;
            }

            const totalRecordCount = await dbService._countQueryService(
                Container.get(DataSource).getRepository(RoleInvites),
                {
                    where: whereCondition,
                }
            );
            const invites = await dbService._findQueryService(
                Container.get(DataSource).getRepository(RoleInvites),
                {
                    where: whereCondition, // Use queryObj directly instead of spreading it
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );
            apiResponse.data = invites;
            apiResponse.recordsTotal = totalRecordCount;
            apiResponse.recordsFiltered = pageSize;

            const totalPages = Math.ceil(totalRecordCount / pageSize);
            apiResponse.totalPages = totalPages;

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    async processEmail(email, emails, client_id, req, reqBody) {
        let isResend = false;
        let isCurrentEmailIsActiveAmongAllEmails = false;

        const users = await dbService._findQueryService(
            Container.get(DataSource).getRepository(Users),
            {
                where: { clientId: client_id, email: email },
            }
        );

        if (users.length > 0) {
            if (emails.length == 1) {
                throw new Error("User already exist");
            } else {
                isCurrentEmailIsActiveAmongAllEmails = true;
            }
        }

        const inviteData = await dbService._findQueryService(
            Container.get(DataSource).getRepository(RoleInvites),
            {
                where: { clientId: client_id, email: email },
            }
        );

        if (inviteData.length > 0) {
            if (inviteData[0].status !== "active") {
                isResend = true;
            }
        }

        let results;
        if (!isCurrentEmailIsActiveAmongAllEmails) {
            let emailVerificationCode = await this.generateVerificationCode(
                12,
                1
            );
            let roleInvites = {
                email: email,
                roleId: reqBody.role,
                status: "sent",
                emailTemplateId: reqBody.emailTemplate,
                clientId: client_id,
                code: emailVerificationCode,
            };

            if (!isResend) {
                results = await dbService._createQueryService(
                    Container.get(DataSource).getRepository(RoleInvites),
                    roleInvites
                );
            } else {
                const roleInviteUpdate = {
                    status: "resent",
                    code: emailVerificationCode,
                };
                results = await dbService._updateQueryService(
                    Container.get(DataSource).getRepository(RoleInvites),
                    {
                        paramsObj: {
                            email: email,
                        },
                        ...roleInviteUpdate,
                    }
                );
            }

            let emailVerificationLink =
                process.env.VIEW360v2FE_URL +
                "/verify-email/" +
                emailVerificationCode;

            let key = reqBody.emailTemplate;
            let configData = {
                Email: email,
                VerificationLink: emailVerificationLink,
            };
            const mailTemplate =
                await this.communicationHelperService.htmlReplace(
                    key,
                    "id",
                    req.userDetails,
                    configData
                );

            const mailParams = {
                subject: mailTemplate.subject ?? "View360 User Invite",
                html:
                    "<div style='width:100%'><img style='float:right;' src='https://v2dev.epiksolution.org/assets/img/logo.png' height='100px' width='200px'>" +
                    mailTemplate.htmlString,
                clientId: req.userDetails.client_id,
                to: email,
                importantMail: true,
            };

            await this.communicationHelperService.nodeMailerService(mailParams);
        }

        return results;
    }
    @Security("bearerAuth")
    @Post("invites")
    async createRoleInvite(
        @Request() req: Request | any,
        @Body() reqBody: InviteRequestBody
    ): Promise<InviteResponse | any> {
        try {
            let client_id = req.userDetails.client_id;
            let emails = reqBody.email.split(",");
            let resultsArray = [];

            for (let i = 0; i < emails.length; i++) {
                let email = emails[i];
                const results = await this.processEmail(
                    email,
                    emails,
                    client_id,
                    req,
                    reqBody
                );
                resultsArray.push(results);

                if (i === emails.length - 1) {
                    this.setStatus(201); // set return status 201
                    return CommonHelper.apiSwaggerSuccessResponse({
                        data: resultsArray,
                    });
                }
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("invites/list")
    async getRoleInvitesList(
        @Request() req: Request | any
    ): Promise<InviteDataTableListResponse> {
        try {
            let limit = req.body.length ? req.body.length : 10;
            let start = req.body.start ? req.body.start : 0;
            let whereCondition: any = [];
            let client_id = req.userDetails.client_id;
            if (
                req.body.search &&
                req.body.search.value &&
                req.body.search.value !== ""
            ) {
                const searchFields = ["email", "status"];
                searchFields.forEach((i) =>
                    whereCondition.push({
                        [i]: ILike(req.body.search.value),
                        clientId: client_id,
                    })
                );
            }
            const results = await Container.get(DataSource)
                .getRepository(RoleInvites)
                .createQueryBuilder("roleInvites")
                .leftJoinAndSelect("roleInvites.role", "role")
                .where(whereCondition)
                .take(+limit)
                .skip(start)
                .select([
                    "roleInvites.id",
                    "roleInvites.email",
                    "roleInvites.status",
                    "roleInvites.code",
                    "roleInvites.roleId",
                    "roleInvites.emailTemplateId",
                    "roleInvites.clientId",
                    "role.name",
                    "roleInvites.createdOn",
                    "roleInvites.updatedOn",
                ])
                .getMany();

            const totalInvites = await Container.get(DataSource)
                .getRepository(RoleInvites)
                .createQueryBuilder("roleInvites")
                .leftJoinAndSelect("roleInvites.role", "role")
                .where("roleInvites.clientId = :clientId", {
                    clientId: client_id,
                })
                .getCount();
            let apiResponse = {
                data: {
                    recordsTotal: 0,
                    recordsFiltered: 0,
                    records: [],
                },
            };
            if (results.length > 0) {
                apiResponse.data.records = results;
                apiResponse.data.recordsTotal = totalInvites;
                apiResponse.data.recordsFiltered = results.length;
                return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
            } else {
                this.setStatus(204);
                return CommonHelper.apiSwaggerSuccessResponse({ data: [] });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    async generateVerificationCode(length, expireInDays) {
        const charset =
            "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        let code = "";
        let randomNum: any = crypto.randomBytes(1);
        for (let i = 0; i < length; i++) {
            let randomIndex = Math.floor(randomNum * charset.length);
            code += charset[randomIndex];
        }

        // Get the current timestamp in milliseconds
        const currentTimestamp = Date.now();
        // Calculate one day's worth of milliseconds (1 day = 24 hours * 60 minutes * 60 seconds * 1000 milliseconds)
        const dayMilliseconds = expireInDays * 24 * 60 * 60 * 1000;
        // Add one day to the current timestamp
        const timestampPlusDays = currentTimestamp + dayMilliseconds;

        return code + "-" + timestampPlusDays;
    }

    @Get("invites/verify/:code")
    async verifyEmail(@Path() code: string | any): Promise<InviteResponse> {
        try {
            let emailVerificationCode = code;
            let expiryTime = code.split("-")[1];

            // Get the current timestamp in milliseconds
            const currentTimestamp = Date.now();
            if (currentTimestamp > expiryTime) {
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description: "This invitation link is expired.",
                    },
                });
            }
            const results = await Container.get(DataSource)
                .getRepository(RoleInvites)
                .createQueryBuilder("roleInvites")
                .leftJoinAndSelect("roleInvites.role", "role")
                .where("roleInvites.code = :code", {
                    code: emailVerificationCode,
                })
                .select([
                    "roleInvites.id",
                    "roleInvites.email",
                    "roleInvites.status",
                    "roleInvites.code",
                    "roleInvites.roleId",
                    "roleInvites.emailTemplateId",
                    "roleInvites.clientId",
                    "role.name",
                    "roleInvites.createdOn",
                    "roleInvites.updatedOn",
                ])
                .getOne();
            if (results) {
                if (results.status == "active") {
                    return CommonHelper.apiSwaggerErrorResponse({
                        error: {
                            error_description:
                                "User already registered.Kindly login to continue.",
                        },
                    });
                }

                const statusUpdate = {
                    status: "verified",
                };
                await dbService._updateQueryService(
                    Container.get(DataSource).getRepository(RoleInvites),
                    {
                        paramsObj: {
                            code: emailVerificationCode,
                        },
                        ...statusUpdate,
                    }
                );
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: results,
                });
            } else {
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description: "This invitation link is expired.",
                    },
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("invites/register")
    async register(
        @Body() requestBody: InviteRegisterRequestBody
    ): Promise<InviteResponse> {
        try {
            //check user email verified or not
            const results = await Container.get(DataSource)
                .getRepository(RoleInvites)
                .createQueryBuilder("roleInvites")
                .leftJoinAndSelect("roleInvites.role", "role")
                .where("roleInvites.code = :code", {
                    code: requestBody.emailVerificationCode,
                })
                .select([
                    "roleInvites.id",
                    "roleInvites.email",
                    "roleInvites.status",
                    "roleInvites.code",
                    "roleInvites.roleId",
                    "roleInvites.emailTemplateId",
                    "roleInvites.clientId",
                    "role.name",
                    "roleInvites.createdOn",
                    "roleInvites.updatedOn",
                ])
                .getOne();
            if (results) {
                if (results.status != "verified") {
                    return CommonHelper.apiSwaggerErrorResponse({
                        error: {
                            error_description: "User email not verified.",
                        },
                    });
                } else {
                    //check user email exists or not
                    let isUserExist = await this.userService.checkUserExist(
                        requestBody.email,
                        requestBody.clientId
                    );
                    if (isUserExist) {
                        //user email exists
                        const apiErrorResponse: ApiErrorResponse = {
                            error: {
                                error_description:
                                    "User already registered.Kindly login to continue.",
                            },
                        };
                        return CommonHelper.apiSwaggerErrorResponse(
                            apiErrorResponse
                        );
                    } else {
                        const salt = bcrypt.genSaltSync();
                        requestBody.password = bcrypt.hashSync(
                            requestBody.password,
                            salt
                        );
                        const insertData = {
                            clientId: requestBody.clientId,
                            roleId: requestBody.roleId || null,
                            firstName: requestBody.firstName,
                            lastName: requestBody.lastName,
                            email: requestBody.email,
                            phone: requestBody.phoneNumber || null,
                            username: requestBody.email,
                            password: requestBody.password,
                            isActive: 1,
                            isSuperAdmin: 0,
                        } as unknown as Users;
                        const users: Users = await this.userService.createUser(
                            insertData
                        );
                        if (!users) {
                            return CommonHelper.apiSwaggerErrorResponse({
                                error: {
                                    error_description: "Something went wrong.",
                                },
                            });
                        }
                        const statusUpdate = {
                            status: "active",
                        };
                        await dbService._updateQueryService(
                            Container.get(DataSource).getRepository(
                                RoleInvites
                            ),
                            {
                                paramsObj: {
                                    code: requestBody.emailVerificationCode,
                                },
                                ...statusUpdate,
                            }
                        );
                        this.setStatus(201); // set return status 201
                        return CommonHelper.apiSwaggerSuccessResponse({
                            data: users,
                        });
                    }
                }
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    private sortByColumnAscending(arr: any[], column: string): any[] {
        return arr.sort((a, b) => {
            if (a[column] < b[column]) {
                return -1;
            }
            if (a[column] > b[column]) {
                return 1;
            }
            return 0;
        });
    }

    private sortByColumnDescending(arr: any[], column: string): any[] {
        return arr.sort((a, b) => {
            if (a[column] < b[column]) {
                return 1;
            }
            if (a[column] > b[column]) {
                return -1;
            }
            return 0;
        });
    }
}
