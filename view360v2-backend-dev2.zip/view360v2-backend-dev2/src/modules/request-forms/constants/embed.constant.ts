export const embedData = {
    embedJsData: `$(function () {
  let metaDataSet = {};
  let metaContent = document.getElementsByTagName("meta");
  // Handle form submit request
  function handleSubmit(event) {
    if (metaDataSet && metaDataSet["id"] && metaDataSet["id"] !== "") {
      let formDataSet = {};

      $.each(event.target, (k, v) => {
        let name = $(v).attr("name");
        let type = $(v).attr("type");

        if (type && type === "radio") {
          let isChecked = $(v).is(":checked");

          if (!formDataSet[name]) {
            formDataSet[name] = null;
          }
          if (!formDataSet[name] && isChecked) {
            formDataSet[name] = $(v).val();
          }
        } else if (type !== "submit") {
          formDataSet[name] = name && name !== "" ? $(v).val() : null;
        }
      });
      $.ajax({
        type: "POST",
        url: metaDataSet["url"] + "request-form/embed-form/" + metaDataSet["id"],
        dataType: "json",
        success: function (msg) {
          console.log(msg);
        },
        data: formDataSet,
      });
    }
  }

  //fetch meta data from script request and set

  $.each(metaContent, (k, v) => {
    let name = $(v).attr("name");

    if (name && name !== "") {
      let content = $(v).attr("content");
      let url = $(v).attr("url");
      let nameArr = name.split("_");

      if (
        nameArr &&
        nameArr.length &&
        nameArr.length === 2 &&
        nameArr[0] === "v2audit-form-builder"
      ) {
        metaDataSet = {
          id: nameArr[1],
          content: content,
          url: url,
        };
      }
    }
  });

  //submit form handle
  $.each(document.forms, (k, form) => {
    let formId = $(form).attr("id");
    if (formId === metaDataSet.content) {
      form.addEventListener("submit", handleSubmit);
    }
  });
});`,
};
