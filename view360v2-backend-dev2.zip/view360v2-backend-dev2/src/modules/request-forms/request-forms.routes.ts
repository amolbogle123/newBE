import fs from "fs";
import { AppRoutes } from "../../app.routes";
import { RequestFormsController } from "./controllers/request-forms.controller";
import { embedData } from "./constants/embed.constant";

export class RequestFormsRoutes extends AppRoutes {
    private requestFormsController: RequestFormsController;
    
    constructor() {
        super();
        this.requestFormsController = new RequestFormsController();

        this.initRoutes();
    }

    initRoutes() {
        const baseChatbotDir = "./public/embed-form/";
        if (!fs.existsSync(baseChatbotDir)) {
            fs.mkdirSync(baseChatbotDir);
        }

        this.createSuportFiles();
        /*
         * this.router.get('/request-form/:urlPath', (req, res, next) => this.requestFormsController.details(req, res, next).catch(next));
         * this.router.get('/request-form/:id', (req, res, next) => this.requestFormsController.getCustomForm(req, res, next).catch(next));
         * this.router.post('/request-form', (req, res, next) => this.requestFormsController.submitCustomForm(req, res, next).catch(next));
         */
    }
    createSuportFiles() {
        if (!fs.existsSync("./public/embed-form/form-builder.js")) {
            fs.writeFileSync("./public/embed-form/form-builder.js", embedData.embedJsData);
        }
       
    }
}
