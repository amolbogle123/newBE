import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import { CustomForms, RequestForm, Themes, Users } from "../../../entities";
import Container from "typedi";
import { DataSource } from "typeorm";
import { FormBuilderService } from "../../form-builder/services/form-builder.service";
import lodash from "lodash";
import { FormBuilder } from "../../../entities/create-form-builder";
import {
    Body,
    Controller,
    Get,
    Hidden,
    Path,
    Post,
    Request,
    Route,
    Tags,
} from "tsoa";
import { dataSource } from "../../../core/data-source";
import { ThemeBuilderHelper } from "../../../modules/theme/utils/helpers/theme-builder.helper";

@Route("request-form")
@Tags("Request Forms")
export class RequestFormsController extends Controller {
    private formBuilderService: FormBuilderService = new FormBuilderService();
    private themeBuilderHelper: ThemeBuilderHelper = new ThemeBuilderHelper();

    static throwError(errorMessage: string | null): void {
        throw Error(errorMessage);
    }

    @Get("{urlPath}")
    @Hidden()
    async details(@Path() urlPath: string): Promise<any> {
        try {
            const apiResponse = {
                data: null,
            };

            const whereCondition: any = { urlPath: urlPath };
            const results: RequestForm[] = await Container.get(DataSource)
                .getRepository(RequestForm)
                .find({ where: whereCondition });

            if (results.length) {
                apiResponse.data = results[0];
                apiResponse.data.requestConfig = JSON.parse(
                    apiResponse.data.requestConfig
                );

                const userThemeInfo = await this.getUserThemeInformation(results[0]);
                apiResponse.data.userThemeInfo = userThemeInfo;

                const themeConfig = await this.getThemeInformation(userThemeInfo.selectedThemeId, userThemeInfo.selectedColorTheme, results[0].clientId);
                apiResponse.data.themeConfig = themeConfig;
            }

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("form/{id}")
    @Hidden()
    async getCustomForm(@Path() id: string): Promise<any> {
        try {
            const apiResponse = {
                data: null,
            };

            const whereCondition: any = { id: id };

            const results: CustomForms[] =
                await this.formBuilderService.getCustomForms(whereCondition);

            if (results.length) {
                apiResponse.data = results[0];
                apiResponse.data.formDataConfig = JSON.parse(
                    apiResponse.data.formDataConfig
                );
                apiResponse.data.approvalData = JSON.parse(
                    apiResponse.data.approvalData
                );
            }

            this.setStatus(200);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse.data,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("")
    @Hidden()
    async submitCustomForm(@Request() request: any): Promise<any> {
        const apiResponse: any = {
            data: {},
        };
        try {
            const insertFormEntry = {
                formId: request.body.formId,
                submittedData: JSON.stringify(request.body.data),
                createdBy: "Guest",
                beingFilledBy: "Guest",
            };

            const results: CustomForms[] =
                await this.formBuilderService.getCustomForms(
                    {
                        clientId: request.body.client_id,
                        id: request.body.formId,
                    },
                    ["referenceId"]
                );

            const fbEntryResponse: FormBuilder =
                await this.formBuilderService.fbInsertEntry(
                    request.body.client_id,
                    insertFormEntry,
                    results[0].referenceId
                );

            if (lodash.isEmpty(fbEntryResponse)) {
                RequestFormsController.throwError(
                    "Unable to save entry in form"
                );
            }

            const whereCondition = { urlPath: request.body.urlPath };
            const updateSet = {
                entryId: fbEntryResponse.id,
                submittedOn: new Date(),
                userId: request.body.userid,
            };

            await Container.get(DataSource)
                .getRepository(RequestForm)
                .update(whereCondition, updateSet);
            apiResponse.data = fbEntryResponse;
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Post("embed-form/:id")
    async embedForm(
        @Path() id: string,
        @Body() requestBody: any
    ): Promise<any> {
        const apiResponse: any = {
            data: {},
        };
        try {
            const formEntries: any[] = [];
            const formHistoryEntries: any[] = [];

            const whereCond: any = { id: id };
            const resultCust: CustomForms[] =
                await this.formBuilderService.getCustomForms(whereCond);

            if (resultCust.length) {
                let formConfig = [];
                let formData = {
                    extraparams: {},
                };
                formConfig = JSON.parse(resultCust[0]["formDataConfig"]);
                for (let form of formConfig) {
                    if (form.key) {
                        formData[form.key] =
                            requestBody &&
                            typeof requestBody[form.key] === "string"
                                ? requestBody[form.key]
                                : "";
                    }
                }

                formEntries.push({
                    formId: id,
                    submittedData: JSON.stringify(formData),
                    beingFilledBy: resultCust[0].createdBy,
                    createdBy: resultCust[0].createdBy,
                });
                formHistoryEntries.push({
                    formId: id,
                    entryId: "",
                    submittedData: JSON.stringify(formData),
                    beingFilledBy: resultCust[0].createdBy,
                    username: "Guest",
                    createdBy: resultCust[0].createdBy,
                });
            }
            const [savedEntries, savedHistoryEntries] = await Promise.all([
                this.formBuilderService.fbInsertEntry(
                    resultCust[0].clientId,
                    formEntries,
                    resultCust[0].referenceId
                ),
                this.formBuilderService.fbHistoryInsertEntry(
                    resultCust[0].clientId,
                    formHistoryEntries,
                    resultCust[0].referenceId
                ),
            ]);

            // Update formHistoryEntries with the newly created IDs
            for (let i = 0; i < savedEntries.length; i++) {
                savedHistoryEntries[i].entryId = savedEntries[i].id;
            }

            // Now save the updated formHistoryEntries to the database
            this.formBuilderService.fbUpdateHistoryEntries(
                resultCust[0].clientId,
                savedHistoryEntries,
                resultCust[0].referenceId
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: apiResponse,
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    private async getUserThemeInformation(userDetails: any): Promise<any> {
        return await dataSource.getRepository(Users).findOne({
            where:{
                clientId: userDetails.clientId,
                isSuperAdmin: 1
            },
            select: ["selectedThemeId","selectedColorTheme"]
        });
    }

    private async getThemeInformation(selectedThemeId: string, selectedColorTheme: string, clientId: number): Promise<any> {
        let themeConfig: any = {};

        let themeResult: any = await dataSource
            .getRepository(Themes)
            .findOne({
                where: {
                    id: selectedThemeId
                },
            });
        if (themeResult) {
            //get selected color theme
            let themedata = JSON.parse(themeResult.theme);
            themedata.selectedColorTheme = selectedColorTheme;
            let selectedColorThemeConfig = themedata.data.filter((d) => d.colorTheme == themedata.selectedColorTheme)[0];
            themeConfig.config = selectedColorThemeConfig;
            themeConfig.themeId = themeResult.id;
        } else {
            //to be removed
            let themeConfig =
                await this.themeBuilderHelper.setupThemeSettings(
                    clientId
                );
            if (themeConfig?.status && themeConfig?.data) {
                themeConfig.config = JSON.parse(themeConfig.data.config);
            }
        }

        return themeConfig;
    }
}
