import { AppRoutes } from "../../app.routes";
import { ContractFormController } from "./controllers/contract-form.controller";



export class ContractFormRoutes extends AppRoutes {
    private contractFormController: ContractFormController;

    constructor() {
        super();
        this.contractFormController = new ContractFormController();
    }
}
