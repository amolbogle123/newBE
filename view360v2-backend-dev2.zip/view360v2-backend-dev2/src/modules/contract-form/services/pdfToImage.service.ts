import fetch from "node-fetch";

const apiUrl = "https://ocr.epiksolution.org";

export class PdfToImageService {
    async readFile(filePath): Promise<any> {
        return new Promise(async (resolve) => {
            try {
                let fileListResponse = [];
                filePath = `${process.env.BASE_URL}/${filePath}`;

                if (process.env.BASE_URL.includes("localhost")) {
                    filePath = "https://v2dev.epiksolution.org:8080/file-sample.pdf";
                }

                const url = `${apiUrl}/pdf-to-img?file=${filePath}`;
                const apiFetchResult = await fetch(url);
                const jsonData = await apiFetchResult.json();

                if (jsonData?.status && jsonData?.data?.list?.length) {
                    fileListResponse = jsonData.data.list.map((file) => `${apiUrl}/${file.url}`);
                }

                resolve(fileListResponse);
            } catch (error) {
                resolve(null);
            }
        });
    }
}
