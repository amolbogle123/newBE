export interface InsertRequest {
    name?: string;
    config?: any;
    isViewed?: number;
    isSigned?: number;
    status?: string;
}

export interface UpdateContractFormRequest {
    name?: string;
    config?: any;
    isViewed?: number;
    isSigned?: number;
    status?: string;
    executeProcess?: string;
}

export interface SaveResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface ContractFormResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface GetDetailsResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DeleteContractForm {
    id: string[];
}

export interface ParseFileRequest {
    filePath: string;
}

export interface ParseFileResponse {
    status: boolean;
    data?: any;
    message?: string;
}