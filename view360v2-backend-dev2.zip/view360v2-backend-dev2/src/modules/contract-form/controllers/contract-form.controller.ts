import {
    Body,
    Controller,
    Delete,
    Get,
    Patch,
    Path,
    Post,
    Query,
    Request,
    Route,
    Security,
    Tags
} from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { CommonUtil } from "utils/common.util";
import { dataSource } from "../../../core/data-source";
import { ContractForm } from "../../../entities";
import dbService from "../../../services/db.service";
import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import { ProcessBuilderHelper } from "../../process-builder/utils/helpers/process-builder.helper";
import {
    ContractFormResponse,
    DeleteContractForm,
    GetDetailsResponse,
    InsertRequest,
    ParseFileRequest,
    ParseFileResponse,
    SaveResponse,
    UpdateContractFormRequest,
} from "../doc/contract-form-interface";
import { PdfToImageService } from "../services/pdfToImage.service";

@Route("")
@Tags("Contract Form")
export class ContractFormController extends Controller {
    private pdfToImageService: PdfToImageService = new PdfToImageService();
    private processBuilderHelper: ProcessBuilderHelper = new ProcessBuilderHelper();

    @Security("bearerAuth")
    @Post("contract-form/parse-file")
    async parseFile(
        @Body() requestBody: ParseFileRequest,
        @Request() request: any
    ): Promise<ParseFileResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            const results = await this.pdfToImageService.readFile(
                requestBody.filePath
            );
            if (results?.length) {
                apiResponse.data = results;
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("contract-form")
    async contractFormList(
        @Request() request: any,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<ContractFormResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };
            const selectedFields: any = [
                "id",
                "clientId",
                "name",
                "config",
                "isViewed",
                "isSigned",
                "status",
                "createdOn",
            ];

            let whereCondition = { clientId: request.userDetails.client_id };
            const totalRecordCount = await Container.get(DataSource)
                .getRepository(ContractForm)
                .count({ where: whereCondition });
            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["id"] = sortOrder;
            }

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ContractForm),
                {
                    where: whereCondition,
                    select: selectedFields,
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );

            if (results?.length > 0) {
                apiResponse.data = results;
                apiResponse.recordsTotal = totalRecordCount;
                apiResponse.recordsFiltered = totalRecordCount;

                const totalPages = Math.ceil(totalRecordCount / pageSize);
                apiResponse.totalPages = totalPages;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Patch("contract-form/:id")
    async updateContractForm(
        @Path() id: string,
        @Body() requestBody: UpdateContractFormRequest,
        @Request() request: any
    ): Promise<ContractFormResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            let isDataFound = false;
            let payload: any = {};

            if (requestBody?.name) {
                payload.name = requestBody.name;
                isDataFound = true;
            }
            if (requestBody?.config) {
                payload.config = JSON.stringify(requestBody.config);
                isDataFound = true;
            }
            if (typeof requestBody?.isViewed === "number") {
                payload.isViewed = requestBody.isViewed;
                isDataFound = true;
            }
            if (typeof requestBody?.isSigned === "number") {
                payload.isSigned = requestBody.isSigned;
                isDataFound = true;
            }
            if (requestBody?.status) {
                payload.status = requestBody.status;
                isDataFound = true;
            }

            let updateResult = null;
            if (isDataFound) {
                updateResult = await dataSource
                    .getRepository(ContractForm)
                    .update({ id: request.params.id }, payload);
                apiResponse.data = updateResult;
            }
            if (!updateResult?.affected) {
                this.setStatus(204);
            } else {
                console.log('-->requestBody?.executeProcess', requestBody?.executeProcess);
                if (requestBody?.executeProcess && requestBody?.config?.emailId) {
                    await this.processBuilderHelper.execute(request.userDetails.client_id, null, null, null, {
                        email: requestBody.config.emailId,
                        contractLink: `${process.env.VIEW360v2FE_URL}/contract-form/${request.params.id}/true`,
                        type: "MANUAL_TRIGGER"
                    }, requestBody.executeProcess, {type: "MANUAL_TRIGGER"});
                }
                this.setStatus(200);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("contract-form/:id")
    async getContractForm(
        @Path() id: string,
        @Request() request: any
    ): Promise<GetDetailsResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };

            let whereCondition = {
                clientId: request.userDetails.client_id,
                id: id,
            };
            let results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(ContractForm),
                {
                    where: whereCondition,
                }
            );

            if (results?.length) {
                if (results[0]?.config) {
                    results[0].config = JSON.parse(results[0].config);
                }
                apiResponse.data = results[0];
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("contract-form")
    async saveContractForm(
        @Body() requestBody: InsertRequest,
        @Request() request: any
    ): Promise<SaveResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            const contractFormModel = new ContractForm();
            contractFormModel.clientId = request.userDetails.client_id;
            contractFormModel.name = requestBody.name;
            contractFormModel.config = JSON.stringify(requestBody.config);
            contractFormModel.createdBy = request.userDetails.id;

            const result = await Container.get(DataSource).manager.save(
                contractFormModel
            );
            if (result?.id) {
                apiResponse.data = { insertedId: result.id };
                this.setStatus(201);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("contract-form")
    async deleteContractForm(
        @Body() requestBody: DeleteContractForm
    ): Promise<ContractFormResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            const widgetResult = await dataSource
                .getRepository(ContractForm)
                .delete(requestBody.id);
            apiResponse.data = widgetResult;

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
