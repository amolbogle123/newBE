export interface AddUpdateCustomBodyRequestBody {
    clientId:number;
    createdBy:string;
    active:number;
    themeSetting:string;
}
export interface DeleteCustomBodyRequestBody {
    id:string;
}
export interface GetCustomBodyResponse {
    status:boolean;
    message:string;
    data:CustomBody[];
}
export interface AddCustomBodyResponse {
    status:boolean;
    message:string;
    data:CustomBody;
}
export interface CustomBody {
    id:string;
    clientId:string;
    themeSetting:string,
    active:number;
    createdBy:string;
    createdOn:string;
}
export interface CustomBodyMessageResponse {
    message:string;
}
export interface CustomBodyApiErrorResponse {
    status:boolean;
    message:string;
    error:{
        error_description:string;
    };
}