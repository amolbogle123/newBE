import { CommonHelper, ApiErrorResponse } from "../../../utils/helpers/common.helper";
import { DataSource } from "typeorm";
import Container from "typedi";
import { CustomBody } from "../../../entities/custom-body";
import { Body, Delete, Get, Post, Request, Route, Security, Tags, Controller, Patch } from "tsoa";
import { AddUpdateCustomBodyRequestBody, AddCustomBodyResponse, GetCustomBodyResponse, CustomBodyMessageResponse, CustomBodyApiErrorResponse, DeleteCustomBodyRequestBody } from "../doc/custom-body.interface";
@Route("custom-body")
@Tags("Custom Body")
export class CustomBodyController extends Controller {
    
     /**
     * get CustomBody Objects
     */
    @Security("bearerAuth")
    @Get("/")
    async get(
        @Request() req: any,
    ): Promise<GetCustomBodyResponse|CustomBodyApiErrorResponse> {
        try {
            let Objects;
            const custom_body_id = req.userDetails.client_id;
            Objects = await Container.get(DataSource)
                .getRepository(CustomBody)
                .findOneBy({
                    clientId: custom_body_id,
                });
            if (Objects != null) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: Objects,
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "No records has been found!.",
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

     /**
     * Update CustomBody Objects
     */
    @Security("bearerAuth")
    @Patch("/")
    async update(
        @Body() body: AddUpdateCustomBodyRequestBody
    ): Promise<CustomBodyMessageResponse|CustomBodyApiErrorResponse> {
        try {
            let result;
            let id = body.clientId;
            result = await Container.get(DataSource)
                .getRepository(CustomBody)
                .update({ clientId: id }, body);

            if (result.affected > 0) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Custom Body updated successfully",
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Custom Body Not Found",
                });
            }
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Add CustomBody Objects
     */
    @Security("bearerAuth")
    @Post("/")
    async add(
        @Request() req: any,
        @Body() body: AddUpdateCustomBodyRequestBody
    ): Promise<AddCustomBodyResponse| CustomBodyApiErrorResponse> {
        try {
            const customBodyObj = new CustomBody();
            customBodyObj.clientId = body.clientId;
            customBodyObj.createdBy = body.createdBy;
            customBodyObj.active = body.active;
            customBodyObj.themeSetting = body.themeSetting;

            const result = await Container.get(DataSource).manager.save(
                customBodyObj
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({ data: result });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Delete("/")
    async delete(
        @Request() request: any,
        @Body() body: DeleteCustomBodyRequestBody,
    ): Promise<CustomBodyMessageResponse | CustomBodyApiErrorResponse> {
        try {
            let result;
            result = await Container.get(DataSource)
                .getRepository(CustomBody)
                .delete({id:body.id, clientId: request.userDetails.client_id });
            if (result){
            if(result.affected > 0) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Record deleted successfully",
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "No Record Found",
                });
            }}else{
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "No Record Found",
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
