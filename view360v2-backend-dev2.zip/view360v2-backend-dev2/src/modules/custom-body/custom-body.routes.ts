import {AppRoutes} from "../../app.routes";
import { CustomBodyController } from "./controllers/custom-body.controller";

export class CustomBodyRoutes extends AppRoutes {
    customBodyService: CustomBodyController;

    constructor() {
        super();
        this.customBodyService = new CustomBodyController();
    }
}
