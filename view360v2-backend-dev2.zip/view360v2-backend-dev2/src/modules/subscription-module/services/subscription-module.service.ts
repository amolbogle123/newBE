import axios from "axios";
import { ModuleSubscription } from "entities";
import { writeFileSync } from "fs";
import { EncryptionSerice } from "services/encryption.service";
import Container from "typedi";
import { DataSource } from "typeorm";

export class SubscriptionModuleService {
    private encryptionService: EncryptionSerice;

    constructor() {
        this.encryptionService = new EncryptionSerice();
    }

    async generateSubscriptionKey(clientId: number, moduleId: string, subscriptionDay: number): Promise<string> {
        const data = {
            clientId: clientId,
            moduleId: moduleId,
            validUntil: new Date(new Date().getTime() + (subscriptionDay * 24 * 60 * 60 * 1000)).setHours(23, 59, 59, 999)
            // validUntil: new Date().setHours(12, 25, 59, 999)
        }

        const subscriptionKey = this.encryptionService.encryptValue(JSON.stringify(data));

        const existingSubscription = await Container.get(DataSource).getRepository(ModuleSubscription).findOne({
            where: { moduleId: moduleId, clientId: clientId, isActive: 1 }
        });

        if (existingSubscription) {
            await Container.get(DataSource).getRepository(ModuleSubscription).update({ clientId: clientId, moduleId: moduleId, isActive: 1 }, { isActive: 0 });
        }

        await Container.get(DataSource).getRepository(ModuleSubscription).save({
            clientId: clientId,
            moduleId: moduleId,
            accessKey: subscriptionKey,
            isActive: 1
        });

        return subscriptionKey;
    }

    async getSubscriptionKey(clientId: number, moduleId: string): Promise<ModuleSubscription> {
        return Container.get(DataSource).getRepository(ModuleSubscription).findOne({
            where: { clientId: clientId, moduleId: moduleId, isActive: 1 }, select: ['accessKey']
        });
    }

    async getKeyInformation(accessKey: string): Promise<string> {
        return this.encryptionService.decryptValue(accessKey);
    }

    async syncModuleList(): Promise<void> {
        try {
            console.log("Syncing module list")
            let moduleList = {}
            const result = await axios.get(process.env.MODULE_SYNC_LIST_API).then(response => response.data);
            result.data.forEach(module => {
                if (module.module_type !== 'free') {
                    moduleList[module.url] = module.id;
                }
            });

            // Path to the JSON file
            // const filePath = path.join(__dirname, '../../../../moduleList.json');
            const filePath = './public/moduleList.json'
            // Convert the data object to a JSON string
            const jsonData = JSON.stringify(moduleList, null, 2);
            // Write the JSON string to the file
            writeFileSync(filePath, jsonData)
            return Promise.resolve();
        } catch (error) {
            console.log("Error in syncModuleList :: ", error);
            throw error;
        }
    }
}
