export interface SubscriptionModuleRequest {
    moduleId: string;
    clientId: number;
    subscriptionDay: number;
}