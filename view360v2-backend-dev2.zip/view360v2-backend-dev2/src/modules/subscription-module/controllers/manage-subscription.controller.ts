import { dataSource } from "core/data-source";
import { ModuleSubscription } from "entities";
import { EncryptionSerice } from "services/encryption.service";
import { Body, Get, Path, Post, Put, Request, Route, Security, Tags } from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { SubscriptionModuleService } from "../services/subscription-module.service";

@Route('manage-subscription')
@Tags('Manage Subscription')
export class ManageSubscriptionController {
    constructor(private encryptionService = new EncryptionSerice(),
    private subscriptionModuleService = new SubscriptionModuleService()) {

    }

    @Post('subscriptionKey')
    async addSubscriptionKey(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response = { status: false, data: {} };
            const objModuleSubscription = new ModuleSubscription();
            objModuleSubscription.clientId = req.userDetails.client_id;
            objModuleSubscription.moduleId = requestBody.moduleId;
            objModuleSubscription.accessKey = requestBody.accessKey;
            objModuleSubscription.isActive = 1;
            const result = await Container.get(DataSource).getRepository(ModuleSubscription).save(objModuleSubscription);
            if(result){
                response.status = true;
                response.data = result;
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: response,
            });
        } catch (error) {
            console.error('Error in getSubscriptionDetails:', error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get('subscriptionKey/:moduleId')
    async getSubscriptionKey(
        @Request() req: any,
        @Path() moduleId: string
    ): Promise<void> {
        try {
            const response = { status: false, data: {} };
            const result = await dataSource
                .getRepository(ModuleSubscription)
                .findOneBy({ moduleId: req.params.moduleId });
            if(result){
                response.status = true;
                response.data = result;
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: response,
            });
        } catch (error) {
            console.error('Error in getSubscriptionDetails:', error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Put('subscriptionKey/:moduleId')
    async editSubscriptionKey(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response = { status: false, data: {} };
           let payload = { accessKey: requestBody.accessKey }
            const result = await dataSource
                .getRepository(ModuleSubscription)
                .update({ moduleId: req.params.moduleId }, payload);
            if(result){
                response.status = true;
                response.data = result;
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: response,
            });
        } catch (error) {
            console.error('Error in getSubscriptionDetails:', error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get('getActiveSubscription')
    async getActiveSubscription(): Promise<void> {
        try {
            const response = { status: false, data: {} };
            const result = await dataSource
                .getRepository(ModuleSubscription)
                .find({ where: { isActive: 1 } });
                // make this if statement synchronous
            if (result) {
                // Using Promise.all to wait for all decryption operations to complete
                await Promise.all(result.map(async (element: any) => {
                    try {
                        const decryptedKey = JSON.parse(await this.encryptionService.decryptValue(element.accessKey));
                        console.log('decryptedKey:', decryptedKey);
                        element.validUntil = decryptedKey.validUntil;
                    } catch (error) {
                        console.error('Error decrypting access key:', error);
                    }
                }));


                console.log("Result :: ", result);
                response.status = true;
                response.data = result;
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: response,
            });
        } catch (error) {
            console.error('Error in getSubscriptionDetails:', error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get('syncModules')
    @Security("bearerAuth")
    async syncModules(): Promise<void> {
        await this.subscriptionModuleService.syncModuleList();
        return CommonHelper.apiSwaggerSuccessResponse({}, true);
    }
}
