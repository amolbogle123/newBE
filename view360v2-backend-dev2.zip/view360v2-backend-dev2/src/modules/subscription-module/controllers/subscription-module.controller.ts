import { Body, Controller, Get, Post, Request, Route, Tags } from "tsoa";
import { SubscriptionModuleService } from "../services/subscription-module.service";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { SubscriptionModuleRequest } from "../interfaces/subscription-module.interface";

@Route('subscription-module')
@Tags('Subscription Module')
export class SubscriptionModuleController extends Controller {
    private subscriptionService: SubscriptionModuleService;

    constructor() {
        super();
        this.subscriptionService = new SubscriptionModuleService();
    }

    @Post('generateSubscriptionKey')
    async generateSubscriptionKey(
        @Request() req: any,
        @Body() requestBody: SubscriptionModuleRequest
    ): Promise<void> {
        try {
            const subscriptionKey = await this.subscriptionService.generateSubscriptionKey(requestBody.clientId, requestBody.moduleId, requestBody.subscriptionDay);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: {
                    subscriptionKey: subscriptionKey,
                },
            });
        } catch (error) {
            console.error('Error in getSubscriptionDetails:', error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get('getSubscriptionKey')
    async getSubscriptionKey(
        @Request() req: any
    ) {
        try {
            const subscriptionKey = await this.subscriptionService.getSubscriptionKey(req.userDetails.clientId, req.query.moduleId);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: {
                    subscriptionKey: subscriptionKey.accessKey,
                },
            });
        } catch (error) {
            console.error('Error in getSubscriptionKey:', error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get('getKeyInformation')
    async getKeyInformation(
        @Request() req: any
    ){
        try {
            const keyInformation = await this.subscriptionService.getKeyInformation(req.query.accessKey);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: JSON.parse(keyInformation)
            });
        } catch (error) {
            console.error('Error in getKeyInformation:', error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}