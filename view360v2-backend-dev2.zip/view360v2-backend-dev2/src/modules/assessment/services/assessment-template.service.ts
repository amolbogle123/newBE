import Container from "typedi";
import { DataSource } from "typeorm";

export class AssessmentTemplateService {
    async saveAssessmentTemplate(templateName: string, templateDescription: string, templateQuestions: string[], clientId: number, createdBy: string) {
        const data = {
            templateName: templateName,
            templateDescription: templateDescription,
            templateQuestions: JSON.stringify(templateQuestions),
            clientId: clientId,
            createdBy: createdBy,
            createdOn: new Date()
        }

        return Container.get(DataSource).getRepository('AssessmentTemplate').save(data);
    }

    async getAssessmentTemplate(pageNumber: number, pageSize: number) {
        // Query database using TypeORM's query builder
        const [data, recordsTotal] = await Container.get(DataSource).getRepository('AssessmentTemplate').findAndCount({
            where: { isDeleted: 0 },
            order: { createdOn: 'DESC' },
            skip: (pageNumber - 1) * pageSize,
            take: pageSize,
            select: ['id', 'templateName', 'templateDescription', 'templateQuestions', 'createdOn', 'createdBy', 'updatedOn']
        });

        const totalPages = Math.ceil(recordsTotal / pageSize);

        return { data, recordsTotal, recordsFiltered: data.length, totalPages };
    }

    async getAssessmentTemplateById(id: string) {
        const response = await Container.get(DataSource).getRepository('AssessmentTemplate').findOne({ where: { id: id, isDeleted: 0 }, select: ['id', 'templateName', 'templateDescription', 'templateQuestions'] });
        if (response) {
            response.templateQuestions = JSON.parse(response.templateQuestions);
        }

        return response;
    }

    async updateAssessmentTemplate(id: string, templateName: string, templateDescription: string, templateQuestions: string[], updatedBy: string, isDeleted?: number) {
        const data = {
            templateName: templateName,
            templateDescription: templateDescription,
            templateQuestions: JSON.stringify(templateQuestions),
            updatedBy: updatedBy,
            updatedOn: new Date(),
            isDeleted: isDeleted
        }

        return Container.get(DataSource).getRepository('AssessmentTemplate').update({ id: id }, data);
    }

    async getAllAssessmentTemplates() {
        return Container.get(DataSource).getRepository('AssessmentTemplate').find({ where: { isDeleted: 0 }, select: ['id', 'templateName'] });
    }
}