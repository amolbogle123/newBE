import axios from "axios";
import Container from "typedi";
import { DataSource } from "typeorm";

export class AssessmentService {

    async saveAssessment(assessmentName, assessmentDescription, documentId, templateId, assessments, userId, clientId) {
        console.log("Request Body :: Create Assessment :: Service ", assessmentName, assessmentDescription, documentId, templateId, assessments, userId, clientId);
        // Query database using TypeORM's query builder
        const data = {
            clientId: clientId,
            userId: userId,
            assessmentName: assessmentName,
            assessmentDescription: assessmentDescription,
            documentId: documentId,
            assessmentTemplateId: templateId,
            assessments: JSON.stringify(assessments),
            createdBy: userId,
            createdOn: new Date()
        }

        return Container.get(DataSource).getRepository('Assessment').save(data);
    }

    async getAssessments(pageNumber: number, pageSize: number) {
        // Query database using TypeORM's query builder
        const [data, recordsTotal] = await Container.get(DataSource).getRepository('Assessment').findAndCount({
            where: { isDeleted: 0 },
            order: { createdOn: 'DESC' },
            skip: (pageNumber - 1) * pageSize,
            take: pageSize,
            select: ['id', 'clientId', 'userId', 'assessmentName', 'status', 'isActive', 'createdOn', 'createdBy', 'updatedOn']
        });

        const totalPages = Math.ceil(recordsTotal / pageSize);

        return { data, recordsTotal, recordsFiltered: data.length, totalPages };
    }

    async getAssessmentById(id: string) {
        // Query database using TypeORM's query builder
        const result = await Container.get(DataSource).getRepository('Assessment')
            .findOne({
                where: { id: id }, select: [
                    'id', 'clientId', 'userId', 'assessmentName', 'assessmentDescription', 'documentId', 'assessmentTemplateId', 'assessments', 'status', 'isActive', 'createdOn', 'createdBy', 'updatedOn', 'updatedBy'
                ]
            });

        if (result) {
            result.assessments = JSON.parse(result.assessments);
        }

        return result;
    }

    async updateAssessment(id: string, assessmentTemplateId: string, assessmentQuestions: string, updatedBy: string, isDeleted?: number) {
        const data = {
            assessmentTemplateId: assessmentTemplateId,
            assessmentQuestions: JSON.stringify(assessmentQuestions),
            updatedBy: updatedBy,
            updatedOn: new Date(),
            status: 'in-progress',
            isDeleted: isDeleted
        }

        if (isDeleted && isDeleted === 1) {
            delete data.status;
        }

        return Container.get(DataSource).getRepository('Assessment').update({ id: id }, data);
    }

    async startAssessment(id: string, userId: string) {
        const assessmentInfo = await Container.get(DataSource).getRepository('Assessment').findOne({ where: { id: id } });
        if (assessmentInfo) {
            const assessmentQuestions = JSON.parse(assessmentInfo.assessments);
            for (const assessment of assessmentQuestions) {
                const assessmentAnswers: any = await this.getAssessmentAnswers(assessment, assessmentInfo.documentId, userId);
                assessment.answer = assessmentAnswers.data.answer ? assessmentAnswers.data.answer : ' ';
            }
            assessmentInfo.assessments = JSON.stringify(assessmentQuestions);
            assessmentInfo.status = 'done';
            await Container.get(DataSource).getRepository('Assessment').update({ id: id }, assessmentInfo);
        }
    }

    private async getAssessmentAnswers(assessment: any, documentId: string, userId: string) {
        return new Promise((resolve) => {
            const searchData = {
                question: assessment.question,
                sessionId: assessment.questionId,
                modalName: 'orca-mini',
                documentId: documentId,
                userId: userId,
            }

            axios.post(`${process.env.CHATBOT_API_URL}ollama/query`, searchData).then(
                (response) => {
                    resolve(response);
                }).catch((error) => {
                    console.error("Error :: Get Assessment Answers :: ", error);
                    resolve({ answer: '', source_documents: [] });
                });
        });
    }
}
