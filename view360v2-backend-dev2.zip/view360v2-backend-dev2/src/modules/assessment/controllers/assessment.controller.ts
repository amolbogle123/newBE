import { Body, Controller, Get, Patch, Post, Query, Request, Route, Tags } from "tsoa";
import { AssessmentService } from "../services/assessment.service";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";

@Route("assessment")
@Tags("Assessment")
export class AssessmentController extends Controller {
    private assessmentService: AssessmentService;

    constructor() {
        super();
        this.assessmentService = new AssessmentService();
    }

    @Post()
    async createAssessment(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response = await this.assessmentService.saveAssessment(requestBody.assessmentName, requestBody.assessmentDescription, requestBody.documentId, requestBody.templateId, requestBody.assessments, req.userDetails.id, req.userDetails.client_id);
            return CommonHelper.apiSwaggerSuccessResponse({ data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get()
    async getAssessments(
        @Query() pageNumber: number,
        @Query() pageSize: number
    ): Promise<void> {
        try {
            const response = await this.assessmentService.getAssessments(pageNumber, pageSize);

            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            console.error("Error :: Get Assessment Template :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("{id}")
    async getAssessmentById(
        id: string
    ): Promise<void> {
        try {
            const response = await this.assessmentService.getAssessmentById(id);

            return CommonHelper.apiSwaggerSuccessResponse({ data: response });
        } catch (error) {
            console.error("Error :: Get Assessment Template :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Patch("{id}")
    async updateAssessment(
        id: string,
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response = await this.assessmentService.updateAssessment(id, requestBody.assessmentTemplateId, requestBody.assessmentQuestions, req.userDetails.id, requestBody.isDeleted);
            this.startAssessment(id, req.userDetails.id);
            return CommonHelper.apiSwaggerSuccessResponse({
                data: response
            });
        } catch (error) {
            console.error("Error :: Update Assessment Template :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    private startAssessment(assessmentId: string, userId: string) {
        // Start Assessment
        console.log("Going to start assessment")
        this.assessmentService.startAssessment(assessmentId, userId);
    }
}