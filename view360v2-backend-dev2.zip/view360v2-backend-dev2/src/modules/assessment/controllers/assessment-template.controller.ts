import { Body, Controller, Get, Patch, Post, Query, Request, Route, Tags } from "tsoa";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { AssessmentTemplateService } from "../services/assessment-template.service";

@Route("assessment-template")
@Tags("Assessment Template")
export class AssessmentTemplateController extends Controller {
    private assessmentTemplateService: AssessmentTemplateService;

    constructor() {
        super();
        this.assessmentTemplateService = new AssessmentTemplateService();
    }

    @Post()
    async createAssessmentTemplate(
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response = await this.assessmentTemplateService.saveAssessmentTemplate(requestBody.templateName, requestBody.templateDescription, requestBody.templateQuestions, req.userDetails.client_id, req.userDetails.id);

            return CommonHelper.apiSwaggerSuccessResponse({
                data: response
            });
        } catch (error) {
            console.error("Error :: Create Assessment Template :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get()
    async getAssessmentTemplate(
        @Query() pageNumber: number,
        @Query() pageSize: number
    ): Promise<void> {
        try {
            const response = await this.assessmentTemplateService.getAssessmentTemplate(pageNumber, pageSize);

            return CommonHelper.apiSwaggerSuccessResponse(response);
        } catch (error) {
            console.error("Error :: Get Assessment Template :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("all")
    async getAllAssessmentTemplates(): Promise<void> {
        try {
            const response = await this.assessmentTemplateService.getAllAssessmentTemplates();
            return CommonHelper.apiSwaggerSuccessResponse({ data: response });
        } catch (error) {
            console.error("Error :: Get All Assessment Templates :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("{id}")
    async getAssessmentTemplateById(id: string): Promise<void> {
        try {
            const response = await this.assessmentTemplateService.getAssessmentTemplateById(id);

            return CommonHelper.apiSwaggerSuccessResponse({
                data: response
            });
        } catch (error) {
            console.error("Error :: Get Assessment Template By Id :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Patch("{id}")
    async updateAssessmentTemplate(
        id: string,
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            const response = await this.assessmentTemplateService.updateAssessmentTemplate(id, requestBody.templateName, requestBody.templateDescription, requestBody.templateQuestions, req.userDetails.id, requestBody.isDeleted);

            return CommonHelper.apiSwaggerSuccessResponse({
                data: response
            });
        } catch (error) {
            console.error("Error :: Update Assessment Template :: ", error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}