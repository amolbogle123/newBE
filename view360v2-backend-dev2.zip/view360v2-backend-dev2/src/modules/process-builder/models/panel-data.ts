import {OnRejectStatus, PanelDataTask, ProcessAssignee, ProcessStatus} from "./enums";
import {CronData} from "../../../utils/helpers/cron.helper";

interface FormField {
}

interface NotificationParam {
    mailtemplate?: string;
    notificationTemplate?: string;
    enablesms?: boolean;
}

interface AssignParam {
    assignto?: ProcessAssignee,
    assignee?: string[] | null,
    assigneerole?: string[] | null;
    onreject?: OnRejectStatus;
    sendbackto?: string;
}

export interface ConnectorParam {
    sqlAccount: string;
    sqlTable: string;
    columnName: string;
    maxEntry: null | number;
    isManualQuery?: boolean;
    manualQuery?: string | null;
}

interface TimerParam extends CronData {
    starton: ProcessStatus
}

interface Process {
    name: string;
    desc: string;
    approval: 'Yes' | 'No' | 'yes' | 'no';
}

interface ProcessTaskParam extends AssignParam, NotificationParam {
}

export interface ProcessTask {
    id: string;
    task: string | null;
    params: ProcessTaskParam;
    name: string;
    catchDuration?: string;
    nextbpmn?: any;
    serviceType?: any;
    sqlFields?: any | any[];
}

interface ConditionsParam {
}

export interface Conditions {
    id: string;
    checkon: string;
    value1: string | null;
    check: string | null;
    value2: string | null;
    params: ConditionsParam;
    conditionon: string;
    conditionType: string;
}

interface Item {
    id: string;
    type: string;
}


export interface PanelData {
    processtype: string,
    type: string,
    form: string,
    formname: string,
    formFields: FormField[],
    processafter: string,
    manualSQLConnector: boolean;
    connectorParams: ConnectorParam;
    timerparams: TimerParam;
    starton: ProcessStatus;
    process: Process;
    campaign: null | string,
    apiInput: null | string,
    task: PanelDataTask | null | string,
    taskarr: ProcessTask[] | any;
    usertaskarr: any[];
    conditionsarr: Conditions[] | any;
    items: Item[];
    tasksarr: any[];
    end: null | any;
    executedActivities?: any
}
