import axios from 'axios';
import { Cron } from 'entities';
import Container from 'typedi';
import { DataSource } from 'typeorm';
import { StatusType } from "../../../models/enums";
import { CommonHelper, SetResponse } from "../../../utils/helpers/common.helper";
import * as txt from "../utils/constants/api.constant";


export class ProcessCronService {

    private CRON_HTTP_HOST: string = `${process.env.view360Cron_url}`;
    //private BE_HTTP_HOST: string = 'http://localhost:8080';

    async addCron(data: any) {

        const apiUrl: string = this.CRON_HTTP_HOST + '/' + 'add-cron';

        try {

            if (data && data.hitApi && data.hitMethod && data.cronType && data.refId) {
                await Container.get(DataSource).getRepository(Cron).delete({refId: data.refId});
                const insertFields = {
                  type: data.cronType,
                  config: JSON.stringify(data.config),
                  bpmn: null,
                  hitApi: `${process.env.BASE_URL}/${data.hitApi}`,
                  hitMethod: data.hitMethod,
                  refId: data.refId,
                  timezone: data.timezone,
                  createdBy: data.createdBy
                };
                const sqlResponse = await Container.get(DataSource).getRepository(Cron).save(insertFields);
                console.log('sqlResponse', sqlResponse);

                const requestPayload = {
                    ...data,
                    hitApi: insertFields.hitApi,
                    type: data.cronType
                }
                
                await axios.post(apiUrl, requestPayload);
                return CommonHelper.setResponse(StatusType.SUCCESS)
            } else {
                return CommonHelper.setResponse(StatusType.ERROR, txt.DATA_NOT_FOUND)
            }
        } catch (e) {
            return CommonHelper.setResponse(StatusType.ERROR, txt.DATA_NOT_FOUND, {data: e})
        }

    }

    async deleteCron(referenceId: string): Promise<SetResponse> {

        const apiUrl: string = this.CRON_HTTP_HOST + '/' + 'delete-cron'

        try {
            const requestPayload = {
                refId: referenceId
            }

            if (referenceId) {
                
                await axios.post(apiUrl, requestPayload);
                return CommonHelper.setResponse(StatusType.SUCCESS);
            } else {
                return CommonHelper.setResponse(StatusType.ERROR, txt.REFERENCE_ID_NOT_FOUND)
            }
        } catch (e) {
            return CommonHelper.setResponse(StatusType.ERROR, txt.REFERENCE_ID_NOT_FOUND, {data: e})
        }

    }

    async getCronList(whereCondition: any, fields: any[] = []): Promise<Cron[]> {

      return Container.get(DataSource).getRepository(Cron).find({
          where: whereCondition,
      });
  }
}
