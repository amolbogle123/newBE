import {DeleteResult, In, UpdateResult, DataSource} from "typeorm";
import lodash from 'lodash';
import {CommonHelper,ApiErrorResponse,SetResponse} from "../../../utils/helpers/common.helper";
import {StatusType, UserType} from "../../../models/enums";
import * as txt from "../utils/constants/api.constant";
import {
    BusinessProcessModelingExecute,
    BusinessProcessModeling,
    Campaign,
    BusinessProcessModelingSql, Users, MdbClient
} from "../../../entities";
import Container from 'typedi';

export class ProcessBuilderService {

    async isBpmnExist(condition: any): Promise<boolean> {
        return await Container.get(DataSource).getRepository(BusinessProcessModeling).count({where: condition}) > 0;
    }

    async getBpmnById(id: string, fields: any[]): Promise<BusinessProcessModeling | null> {
        return Container.get(DataSource).getRepository(BusinessProcessModeling).findOne({select: fields, where: {id}})
    }

    async runCustomizedQuery(queryStatement: string, values: any[] = []): Promise<any> {
        return Container.get(DataSource).manager.query(queryStatement, values);
    }

    async getProcessListDetails(condition: any, userType: string, fields: any[] = [],take,skip,sortObject): Promise<SetResponse> {

        const whereClause: any = {clientId: condition.clientId};

        if (userType === UserType.OWNER) {
            whereClause.createdBy = condition.userId
        }
        const sqlResponse: BusinessProcessModeling[] =
            await Container.get(DataSource).getRepository(BusinessProcessModeling).find({where: whereClause, select: fields ,take: take,
                skip: skip,
                order: sortObject})
        const data = [];
        sqlResponse.forEach((item) => {
            data.push({
                CREATED_BY: item.createdBy,
                ID: item.id,
                PROCESSDATA: JSON.stringify(JSON.parse(item.panelData).process),
                CREATEDON: item.createdOn,
                FORMNAME: JSON.stringify(JSON.parse(item.panelData).formname) === "null" ? '' : JSON.stringify(JSON.parse(item.panelData).formname),
                STATUS: item.status,
                TYPE: item.type,
            })
        });
        const message = !lodash.isEmpty(data) ? null : txt.DATA_NOT_FOUND;

        return CommonHelper.setResponse(StatusType.SUCCESS, message, data);
    }

    async getAllProcess(clientId: number, fields: any[] = [],take,skip,sortObject): Promise<SetResponse> {

        const sqlResponse: BusinessProcessModeling[] = await Container.get(DataSource).getRepository(BusinessProcessModeling).find({
            where: {clientId}, select: fields,take: take,
            skip: skip,
            order: sortObject
        });

        const message = !lodash.isEmpty(sqlResponse) ? null : txt.DATA_NOT_FOUND;
        return CommonHelper.setResponse(StatusType.SUCCESS, message, sqlResponse);
    }

    async getSingleProcessDetail(condition: any): Promise<SetResponse> {
        const sqlResponse: BusinessProcessModeling | null = await Container.get(DataSource).getRepository(BusinessProcessModeling).findOne({where: condition});

        const message = !lodash.isEmpty(sqlResponse) ? null : txt.DATA_NOT_FOUND;
        return CommonHelper.setResponse(StatusType.SUCCESS, message, sqlResponse);
    }

    async getMultipleBpmn(condition: any, fields: any[] = []): Promise<BusinessProcessModeling[]> {
        return Container.get(DataSource).getRepository(BusinessProcessModeling).find({where: condition, select: fields});
    }

    async deleteProcess(condition: any): Promise<SetResponse> {
        const isBpmnExist: boolean = await this.isBpmnExist(condition);

        if (!isBpmnExist) {
            return CommonHelper.setResponse(StatusType.ERROR, txt.DATA_NOT_FOUND)
        }
        const sqlResponse: DeleteResult = await Container.get(DataSource).getRepository(BusinessProcessModeling).delete(condition);
        return CommonHelper.setResponse(StatusType.SUCCESS, txt.PROCESS_DELETE_SUCCESS, sqlResponse);
    }

    async deleteMultipleProcess(listOfIds: string[]): Promise<SetResponse> {
        const sqlResponse: DeleteResult = await Container.get(DataSource).getRepository(BusinessProcessModeling).delete({id: In(listOfIds)});
        return CommonHelper.setResponse(StatusType.SUCCESS, txt.PROCESS_DELETE_SUCCESS, sqlResponse);
    }

    async getBpmnExecute(condition: any, fields: any[] = []): Promise<BusinessProcessModelingExecute[]> {
        return Container.get(DataSource).getRepository(BusinessProcessModelingExecute).find({where: condition, select: fields, order: {id: 'DESC'}});
    }

    async getBpmnSql(condition: any, fields: any = []): Promise<SetResponse> {

        const sqlResponse: BusinessProcessModelingSql[] = await Container.get(DataSource).getRepository(BusinessProcessModelingSql).find({
            where: condition, select: fields
        });
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async saveOrUpdateBpmn(updateFields: any): Promise<SetResponse> {
        try{
            const sqlResponse: BusinessProcessModeling[] = await Container.get(DataSource).getRepository(BusinessProcessModeling).save(updateFields);
            return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.setResponse(StatusType.ERROR, null, apiErrorResponse);
        }

    }

    async updateBpmn(condition: any, updateFields: any): Promise<SetResponse> {

        const sqlResponse: UpdateResult = await Container.get(DataSource).getRepository(BusinessProcessModeling).update(condition, updateFields);
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async saveOrUpdateBpmnExecute(updateFields: any): Promise<SetResponse> {

        const sqlResponse: BusinessProcessModelingExecute[] = await Container.get(DataSource).getRepository(BusinessProcessModelingExecute).save(updateFields);
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async updateBpmnExecute(condition: any, updateFields: any): Promise<SetResponse> {

        const sqlResponse: UpdateResult = await Container.get(DataSource).getRepository(BusinessProcessModelingExecute).update(condition, updateFields);
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async getSingleCampaign(condition: any, fields: any[]): Promise<any> {

        const sqlResponse: Campaign | null = await Container.get(DataSource).getRepository(Campaign)
            .findOne({where: condition, select: fields});

        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async saveOrUpdateBpmnSql(updateFields: any): Promise<SetResponse> {

        const sqlResponse: BusinessProcessModelingSql[] = await Container.get(DataSource).getRepository(BusinessProcessModelingSql).save(updateFields);
        return CommonHelper.setResponse(StatusType.SUCCESS, null, sqlResponse);
    }

    async getMultipleUser(condition: any, fields: any[] = []): Promise<Users[]> {
        return Container.get(DataSource).getRepository(Users).find({where: condition, select: fields});
    }

    async getMdbClient(condition: any, fields: any[] = []): Promise<MdbClient[]> {
        return Container.get(DataSource).getRepository(MdbClient).find({where: condition, select: fields});
    }

}
