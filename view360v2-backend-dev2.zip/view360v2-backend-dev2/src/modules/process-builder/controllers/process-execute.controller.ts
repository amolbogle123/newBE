import {ProcessStatus} from "../models";
import {ApiErrorResponse, CommonHelper} from "utils/helpers/common.helper";
import {NextFunction, Request, Response} from "express";
import {ProcessBuilderHelper} from "../utils/helpers/process-builder.helper";


export class ProcessExecuteController {

    // Helpers
    private processBuilderHelper: ProcessBuilderHelper = new ProcessBuilderHelper();

    async custom_event(request: Request | any, response: Response, next: NextFunction): Promise<any> {
        let extra = {type: ProcessStatus.CUSTOM_EVENT};
        return this.execute_bpmn(request, response, next, extra);
    }

    /**
     * Execute the Business Process Modeling using itd ID
     * @param request Request from the front-end
     * @param response Response that will send to the front-end
     * @param next It will be use for passing to next method
     */
    async execute_bpmn(request: Request | any, response: Response, next: NextFunction, extra: any = {}): Promise<any> {
        const result = { status: false, data: null };
        try {
            const clientId = request.userDetails.client_id;
            const bpmnId = request.query.id;

            // ***** BPMN EXECUTION *****
            await this.processBuilderHelper.execute(
                clientId, null, null,'', null, bpmnId, {type: ProcessStatus.MANUAL_TRIGGER}
            );
            result.status = true;
            return CommonHelper.apiSuccessResponse(response, result);
        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiErrorResponse(response, apiErrorResponse)
        }
    }
}
