import lodash from "lodash";
import { DataSource, UpdateResult } from "typeorm";
import { BusinessProcessModeling, CustomForms } from "../../../entities";
import { StatusType } from "../../../models/enums";
import { ApiErrorResponse, CommonHelper, SetResponse } from "../../../utils/helpers/common.helper";
import { FormBuilderService } from "../../form-builder/services/form-builder.service";
import { ProcessBuilderService } from "../services/process-builder.service";
import { ProcessCronService } from "../services/process-cron.service";
import * as msg from "../utils/constants/api.constant";

import axios from 'axios';
import momentTz from 'moment-timezone';
import { Controller, Delete, Get, Hidden, Middlewares, Patch, Post, Query, Request, Route, Security, Tags } from "tsoa";
import Container from "typedi";
import { CommonUtil } from "utils/common.util";
import { FormBuilder } from "../../../entities/create-form-builder";
import { commonMiddleware } from "../../../middlewares/common.middleware";
import { ConnectorHelper } from "../../../utils/helpers/connector.helper";
import { CronHelper } from "../../../utils/helpers/cron.helper";
import {
    ApiMethod,
    ConnectorParam,
    IStatusProcess,
    OnRejectStatus,
    PanelData,
    ProcessStatus,
    StatusProcess
} from "../models";
import { ProcessBuilderHelper } from "../utils/helpers/process-builder.helper";


@Route('')
@Tags('Process Builder')
export class ProcessBuilderController extends Controller {

    // Services
    private processBuilderService: ProcessBuilderService = new ProcessBuilderService();
    private processCronService: ProcessCronService = new ProcessCronService();
    private formBuilderService: FormBuilderService = new FormBuilderService();

    // Helpers
    private processBuilderHelper: ProcessBuilderHelper = new ProcessBuilderHelper();

    private CRON_HTTP_HOST: string = `${process.env.VIEW360CRON_URL}`;

    private async onProcessStatusReject(condition: any, payload: any): Promise<any> {
        try {

            const bpmnExecResponse: any[] = await this.processBuilderService.getBpmnExecute(condition, ['id', 'activityId']);

            if (!lodash.isEmpty(bpmnExecResponse)) {

                for (const item of bpmnExecResponse) {

                    const fieldToBeUpdated: any = { id: item.id, isRejected: 1, submittedBy: payload.submittedBy };
                    await this.processBuilderService.saveOrUpdateBpmnExecute(fieldToBeUpdated);

                    if (item.activityId === payload.reject.rejactivity) {
                        break;
                    }
                }
                return { status: StatusType.SUCCESS, message: msg.SUCCESS_EXECUTED, data: null } as SetResponse;
            }

        } catch (e) {
            throw new Error((e as Error).message);
        }
    }

    private async onMarkCompleted(payload: any, clientId: number, tempId: string, entryId: string): Promise<any> {
        try {
            const fieldToBeUpdated: any = { id: payload.id, status: 1, submittedBy: payload.submittedBy };
            const sqlResponse: SetResponse = await this.processBuilderService.saveOrUpdateBpmnExecute(fieldToBeUpdated);

            const results: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: clientId, id: tempId }, ["referenceId"]);

            await this.processBuilderHelper.execute(clientId, tempId, entryId, results[0].referenceId, null, null, null);

            sqlResponse.message = msg.SUCCESS_EXECUTED;
            return sqlResponse;

        } catch (e) {
            throw new Error((e as Error).message);
        }
    }

    private async onMarkAssignedUser(payload: any, params: any, userDetails: any, formId: string, entryId: string): Promise<any> {
        try {
            let apiResponse = { status: false, data: null };

            const results: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: userDetails.client_id, id: formId }, ["referenceId"]);
            let submittedData = await this.getFormBuilderSubmittedData(entryId, formId, userDetails.client_id, results);

            if (payload.status === ProcessStatus.USER_ASSIGNED) {
                // TO_DO: to be fix
                // formBuilderRes.submittedData = Object.assign(formBuilderRes.submittedData, { assignedUser: req.body.selectedUser });
            } else if (
                payload.status === ProcessStatus.APPROVE &&
                params?.saveResultApproval &&
                params?.saveResultOn
            ) {
                submittedData[params.saveResultOn] = true;
            }

            const dataPayload = {
                submittedData: JSON.stringify(submittedData),
            };
            const whereClauseForUpdateFormBuilder: any = { id: entryId }
            const updateResponse: UpdateResult = await this.formBuilderService.updateFormBuilder(userDetails.client_id, results[0].referenceId, whereClauseForUpdateFormBuilder, dataPayload);
            if (updateResponse?.affected) {

                const updateData = { status: 1, submittedBy: userDetails.id };
                const uBpmnEResponse: any = await this.processBuilderService.updateBpmnExecute({ id: payload.id }, updateData);
                if (uBpmnEResponse?.data?.affected) {
                    apiResponse.status = true;
                    apiResponse.data = uBpmnEResponse;

                    const bpmnExtraFields = { actionedBy: userDetails.id };
                    if (payload?.status === ProcessStatus.USER_ASSIGNED) {
                        bpmnExtraFields['ignoreTimer'] = true;
                    }
                    this.processBuilderHelper.execute(userDetails.client_id, formId, entryId, results[0].referenceId, null, null, bpmnExtraFields);
                }
            }


            return apiResponse;
        } catch (e) {
            throw new Error((e as Error).message);
        }
    }

    private static async manualSQlConnectorOperation(panelData: PanelData): Promise<PanelData> {
        const connectorParams: ConnectorParam = panelData.connectorParams || null;

        if (connectorParams && connectorParams.sqlAccount && connectorParams.sqlTable && connectorParams.columnName) {

            const customQuery = `SELECT MAX([${connectorParams.columnName}]) as 'MAX_ENTRY' FROM [${connectorParams.sqlTable}]`;
            const connectorResult: SetResponse = await ConnectorHelper.connect(connectorParams.sqlAccount, customQuery);

            if (connectorResult.status === StatusType.SUCCESS && !lodash.isEmpty(connectorResult.data)) {
                panelData.connectorParams.maxEntry = connectorResult.data[0]['MAX_ENTRY']
            }
            return panelData;
        }
        return panelData;
    }

    private async saveOrUpdateBpmnRecord(bpmPayload: any, panelData: PanelData, type: 'save' | 'update') {
        const response = { status: false, data: null };
        let sqlPayload = {
            clientId: bpmPayload.userDetails.clientId,
            formId: bpmPayload.formId || null,
            followAfter: bpmPayload.followAfter || 0,
            type: panelData.starton,
            sqlConnector: !panelData.manualSQLConnector ? 0 : 1,
            bpmnData: bpmPayload.data,
            panelData: JSON.stringify(panelData),
        } as BusinessProcessModeling;

        if (type === 'update') {
            sqlPayload.updatedBy = bpmPayload.userDetails.clientId;
            sqlPayload.id = bpmPayload.id;
        } else {
            sqlPayload.createdBy = bpmPayload.userDetails.clientId
        }

        const sqlResponse: SetResponse = await this.processBuilderService.saveOrUpdateBpmn(sqlPayload);


        if (sqlResponse.status === StatusType.SUCCESS) {
            response.status = true;
            if (type === 'update') {
                response.data = { updatedRows: 1 }
            } else {
                response.data = { lastInsertId: sqlResponse.data.id }
            }
            console.log('panelData.starton', panelData.starton, ProcessStatus.TIMER_BASED, (panelData.starton === ProcessStatus.TIMER_BASED));
            if (panelData.starton === ProcessStatus.TIMER_BASED) {
                const processCronRes = await this.addProcessCron(panelData, sqlResponse.data, bpmPayload.userDetails);
                console.log('processCronRes', processCronRes);
            }
            return CommonHelper.apiSwaggerSuccessResponse({ ...response });
        }
        const errResponse = { message: msg.FAILED_BPMN_SAVED, error: { error_description: msg.ERROR_UNKNOWN } }
        return CommonHelper.apiSwaggerErrorResponse(errResponse);
    }

    private async addProcessCron(panelData: PanelData, savedBpmnResponse: BusinessProcessModeling, userDetails: any): Promise<SetResponse> {
        panelData.timerparams.frequency = panelData.timerparams.starton;

        return this.processCronService.addCron({
            hitApi: 'bpmn-cron',
            hitMethod: ApiMethod.POST,
            cronType: 'BPMN_TIMER',
            refId: savedBpmnResponse.id,
            createdBy: userDetails.id,
            client_id: userDetails.clientId,
            config: {
                apiBody: {
                    bpmnId: savedBpmnResponse.id,
                },
                scheduleOn: CronHelper.generateTime(panelData.timerparams),
            },
            timezone: panelData.timerparams && panelData.timerparams.timezone || momentTz.tz.guess(),
        });
    }


    @Security('bearerAuth')
    @Get('customworkflow')
    @Hidden()
    @Middlewares(commonMiddleware)
    async getProcessList(
        @Query() rbav: string,
        @Request() request: any,
        @Query('page') page: number = 1,
        @Query('pageSize') pageSize: number = 10,
        @Query('sortOrder') sortOrder?: number,
        @Query('sortField') sortField?: string,
        @Query('filters') filters?: string
    ): Promise<any> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
                status: false
            };
            let whereCondition = {};
            await CommonUtil.applyFilter(filters, whereCondition);


            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject['email'] = sortOrder;
            }
            const totalRecordCount = await Container.get(DataSource)
                .getRepository(BusinessProcessModeling)
                .count();
            const fieldsToBeFetched: string[] = ['id', 'createdOn', 'createdBy', 'status', 'panelData', 'type'];
            let take = pageSize;
            let skip = (page - 1) * pageSize;
            let order = sortObject;
            if (rbav === 'all') {


                const { client_id: clientId, id: userId } = request.userDetails;
              
                const sqlResponse: SetResponse = await this.processBuilderService
                    .getProcessListDetails({ clientId, userId }, rbav, fieldsToBeFetched, take, skip, order);
                if (sqlResponse.status) {
                    apiResponse.data = sqlResponse.data;
                    apiResponse.recordsTotal = totalRecordCount;
                    apiResponse.recordsFiltered = pageSize;

                    const totalPages = Math.ceil(totalRecordCount / pageSize);
                    apiResponse.totalPages = totalPages;
                }
                if (sqlResponse.data !== null) {
                    return CommonHelper.apiSwaggerSuccessResponse({ ...apiResponse });
                } else {
                    this.setStatus(204);
                    return CommonHelper.apiSwaggerSuccessResponse({ ...apiResponse });
                }

            } else {
                request.userDetails = { client_id: 1 }
                const { client_id: clientId } = request.userDetails;
                const fieldToBeFetched: any[] = ['id', 'status', 'panelData'];

                const sqlResponse: SetResponse = await this.processBuilderService.getAllProcess(clientId, fieldToBeFetched,take,skip,sortObject);

                if (sqlResponse.data !== null && sqlResponse.data.length) {
                    sqlResponse.data.map((item: BusinessProcessModeling) => {
                        item.panelData = (JSON.parse(JSON.stringify(item.panelData)) as PanelData);
                        return item;
                    })
                }
                if (sqlResponse.status) {
                    apiResponse.data = sqlResponse.data;
                    apiResponse.recordsTotal = totalRecordCount;
                    apiResponse.recordsFiltered = pageSize;

                    const totalPages = Math.ceil(totalRecordCount / pageSize);
                    apiResponse.totalPages = totalPages;
                }
                if (sqlResponse.data !== null && sqlResponse.data.length) {
                    return CommonHelper.apiSwaggerSuccessResponse({ ...apiResponse });
                } else {
                    this.setStatus(204);
                    return CommonHelper.apiSwaggerSuccessResponse({ ...apiResponse });
                }

            }

        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('customworkflow-id')
    @Hidden()
    async getSingleProcess(@Request() request: any): Promise<any> {
        try {
            const clientId = request.userDetails.client_id;
            const id = request.body.id;
            const response = { status: false, data: null };
            const sqlResponse: SetResponse = await this.processBuilderService.getSingleProcessDetail({ clientId, id });

            if (!lodash.isEmpty(sqlResponse.data)) {
                response.status = true;
                const data = [];
                data.push({
                    APP_ID: sqlResponse.data.appIdd,
                    BPMN_DATA: sqlResponse.data.bpmnData,
                    CLIENT_ID: sqlResponse.data.clientId,
                    CREATEDON: sqlResponse.data.createdOn,
                    CREATED_BY: sqlResponse.data.createdBy,
                    FOLLOW_AFTER: sqlResponse.data.followAfter,
                    FORM_ID: sqlResponse.data.formId,
                    ID: sqlResponse.data.id,
                    PANEL_DATA: sqlResponse.data.panelData,
                    SQL_CONNECTOR: sqlResponse.data.sqlConnector,
                    STATUS: sqlResponse.data.status,
                    TYPE: sqlResponse.data.type,
                    UPDATED_BY: sqlResponse.data.updatedBy
                });
                response.data = data;
                // sqlResponse.data.panelData = (JSON.parse(sqlResponse.data.panelData) as PanelData)
            }

            return CommonHelper.apiSwaggerSuccessResponse({ ...response });

        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('customworkflow')
    @Hidden()
    async saveProcess(@Request() request: any): Promise<any> {

        try {
            let formId: string = request.body.formId;
            let panelData: PanelData = JSON.parse(request.body.panel);

            let followAfter = null;

            if (panelData.starton === ProcessStatus.PROCESS_COMPLETE) {
                followAfter = panelData.processafter;
                let bpmnObject: BusinessProcessModeling | null = await this.processBuilderService.getBpmnById(followAfter, ['formId']);

                if (!lodash.isEmpty(bpmnObject)) {
                    formId = bpmnObject?.formId;
                }
            }

            if (panelData.manualSQLConnector) {
                panelData = await ProcessBuilderController.manualSQlConnectorOperation(panelData);
            }
            const userDetails = {
                clientId: request.userDetails.client_id,
                id: request.userDetails.id
            }
            const saveBpmnPayload = { ...request.body, formId, userDetails, followAfter: followAfter || 0 };
            return await this.saveOrUpdateBpmnRecord(saveBpmnPayload, panelData, 'save');

        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Patch('customworkflow')
    @Hidden()
    async updateProcess(@Request() request: any): Promise<any> {

        try {
            let formId: string = request.body.formid;
            let panelData: PanelData = JSON.parse(request.body.panel);

            let followAfter = null;

            if (panelData.starton === ProcessStatus.PROCESS_COMPLETE) {
                followAfter = panelData.processafter;
                let bpmnObject: BusinessProcessModeling | null = await this.processBuilderService.getBpmnById(followAfter, ['formId']);

                if (!lodash.isEmpty(bpmnObject)) {
                    formId = bpmnObject?.formId;
                }
            }

            if (panelData.manualSQLConnector) {
                panelData = await ProcessBuilderController.manualSQlConnectorOperation(panelData);
            }

            const userDetails = {
                clientId: request.userDetails.client_id,
                id: request.userDetails.id
            }
            const updateBpmnPayload = { ...request.body, formId, userDetails, followAfter: followAfter || 0 };
            return await this.saveOrUpdateBpmnRecord(updateBpmnPayload, panelData, 'update');

        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Delete('customworkflow')
    @Hidden()
    async deleteMultipleProcess(@Request() request: any): Promise<any> {
        try {
            const response = { status: false, data: null };
            const lisOdIds: string[] = request.body.id;
            const sqlResponse: SetResponse = await this.processBuilderService.deleteMultipleProcess(lisOdIds);

            if (sqlResponse.status === StatusType.ERROR) {
                return CommonHelper.apiSwaggerErrorResponse({ message: sqlResponse.message, error: { error_description: sqlResponse.data } });
            }

            for (const id of lisOdIds) {
                await this.processCronService.deleteCron(id);
            }

            if (sqlResponse.status === StatusType.SUCCESS) {
                response.status = true;
                response.data = sqlResponse.data.affected
            }
            return CommonHelper.apiSwaggerSuccessResponse({ ...response });

        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }

    @Security('bearerAuth')
    @Patch('customworkflow/update-status')
    @Hidden()
    async updateStatus(@Request() request: any): Promise<any> {
        try {

            const { id, status }: any = request.body;

            if (lodash.isEmpty(id)) {
                return CommonHelper.apiSwaggerErrorResponse({ message: msg.BPMN_ID_NOT_FOUND, error: null });
            }

            const bpmnData: BusinessProcessModeling | null =
                await this.processBuilderService.getBpmnById(id, ['id', 'clientId', 'sqlConnector', 'panelData', 'createdBy', 'status']);

            if (lodash.isEmpty(bpmnData)) {
                this.setStatus(404);
                return CommonHelper.apiSwaggerErrorResponse({ message: msg.DATA_NOT_FOUND, error: null });
            }

            if (bpmnData.status === status) {
                return CommonHelper.apiSwaggerSuccessResponse({ message: msg.STATUS_UPDATE_SKIPPED });
            }

            const sqlResponse: SetResponse = await this.processBuilderService.updateBpmn({ id }, { status });

            if (sqlResponse.status === StatusType.SUCCESS) {
                await this.updateCron({ id, status })

                return CommonHelper.apiSwaggerSuccessResponse({ message: msg.STATUS_UPDATE_SUCCESS });
            }

            return CommonHelper.apiSwaggerErrorResponse({ error: null });

        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }

    async updateCron(data) {
        try {
            if (data && data.id) {
                const apiUrl: string = this.CRON_HTTP_HOST + '/' + 'cron';

                const requestPayload = {
                    refId: data.id,
                    run: (data.status !== 0)
                }

                await axios.put(apiUrl, requestPayload);
                return true;
            }
        } catch (e) {
            //TO_DO update to logger from console.log("Error: " + (e as Error).message);
            return { msg: e }
        }
        return false
    }

    @Security('bearerAuth')
    @Post('customworkflow/next')
    @Hidden()
    async nextProcess(@Request() request: any): Promise<any> {
        try {
            const { bpmnId: id, tempId, entryId } = request.body;

            const sqlResponse: SetResponse = await this.processBuilderService.updateBpmnExecute({ id }, { status: 1 });

            const results: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: request.userDetails.client_id, id: tempId }, ["referenceId"]);

            if (sqlResponse.status === StatusType.SUCCESS) {
                await this.processBuilderHelper.execute(request.userDetails.client_id, tempId, entryId, results[0].referenceId, null, null, null);
                return CommonHelper.apiSwaggerSuccessResponse({ message: msg.STATUS_UPDATE_SUCCESS });
            }
            return CommonHelper.apiSwaggerErrorResponse({ error: null });

        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }

    @Security('bearerAuth')
    @Post('customworkflow/status')
    @Hidden()
    async statusProcess(@Request() request: any): Promise<any> {
        try {

            const { tempId, entryid, bpmnId, id, status, reject, params } = request.body;
            let serviceResponse: {};

            const payload: IStatusProcess = new StatusProcess(
                request.userDetails.id, tempId, entryid, bpmnId, id, status, reject
            );

            const results: CustomForms[] = await this.formBuilderService
                .getCustomForms({ clientId: request.userDetails.client_id, id: tempId }, ["referenceId"]);

            if (payload.status === ProcessStatus.REJECT) {

                if (
                    params?.saveResultApproval &&
                    params?.saveResultOn
                ) {
                    let submittedData = await this.getFormBuilderSubmittedData(entryid, tempId, request.userDetails.client_id, results);

                    submittedData[params.saveResultOn] = true;

                    const dataPayload = {
                        submittedData: JSON.stringify(submittedData),
                    };
                    const whereClauseForUpdateFormBuilder: any = { id: entryid };
                    await this.formBuilderService.updateFormBuilder(request.userDetails.client_id, results[0].referenceId, whereClauseForUpdateFormBuilder, dataPayload);

                }

                serviceResponse = await this.onProcessStatusReject({ entryId: entryid, bpmn: { id: bpmnId } }, payload);

                if (payload.reject.onreject === OnRejectStatus.SEND_TO_ACTION) {
                    await this.processBuilderHelper.execute(request.userDetails.client_id, tempId, entryid, results[0].referenceId, null, null, null);
                }

            } else if (
                [ProcessStatus.USER_ASSIGNED, ProcessStatus.APPROVE].indexOf(payload.status) > -1
            ) {
                serviceResponse = await this.onMarkAssignedUser(payload, params, request.userDetails, tempId, entryid);
            } else {
                serviceResponse = await this.onMarkCompleted(payload, request.userDetails.client_id, tempId, entryid);
            }
            return CommonHelper.apiSwaggerSuccessResponse(serviceResponse);

        } catch (error) {

            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse)
        }
    }



    private async getFormBuilderSubmittedData(entryid: any, tempId: any, client_id: any, results: CustomForms[]) {
        const whereClauseForGetFormBuilder: any = { id: entryid, formId: tempId };
        const formBuilderRes: FormBuilder = await this.formBuilderService
            .getFormBuilder(client_id, results[0].referenceId, whereClauseForGetFormBuilder, ['id', 'submittedData']);
        let submittedData = {};
        if (!lodash.isEmpty(formBuilderRes)) {

            if (formBuilderRes.submittedData) {
                submittedData = JSON.parse(JSON.stringify(formBuilderRes.submittedData));
            }
        }
        return submittedData;
    }
}
