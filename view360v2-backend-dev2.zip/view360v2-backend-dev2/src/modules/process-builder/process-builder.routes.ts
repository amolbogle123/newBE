import {AppRoutes} from "../../app.routes";
import {ProcessBuilderController} from "./controllers/process-builder.controller";
import {ProcessCronController} from "./controllers/process-cron.controller";
import {ProcessExecuteController} from "./controllers/process-execute.controller";

export class ProcessBuilderRoutes extends AppRoutes {

    private processBuilderController: ProcessBuilderController;
    private processCronController: ProcessCronController;
    private processExecuteController: ProcessExecuteController;
    public route_prefix = '/customworkflow';

    constructor() {
        super();
        this.processBuilderController = new ProcessBuilderController();
        this.processCronController = new ProcessCronController();
        this.processExecuteController = new ProcessExecuteController();
        this.initRoutes();
    }

    initRoutes(): void {
        this.router.get('/customworkflow/execute-bpmn', (req, res, next) => this.processExecuteController.execute_bpmn(req, res, next).catch(next));

        this.router.post('/customworkflow/custom-event', (req, res, next) => this.processExecuteController.custom_event(req, res, next).catch(next));

        /*
        * this.router.post(this.route_prefix + '/savebpmn',  (req, res, next) => this.processBuilderController.saveProcess(req, res, next).catch(next));
        * this.router.post('/bpmnCron',  (req, res, next) => this.processCronController.bpmnCron(req, res, next).catch(next));
        * this.router.get(this.route_prefix + '/getWorkflows', (req, res, next) => this.processBuilderController.getProcessList(req, res, next).catch(next));
        * this.router.post(this.route_prefix + '/getworkflowsbyid', (req, res, next) => this.processBuilderController.getSingleProcess(req, res, next).catch(next));
        * this.router.get(this.route_prefix + '/getall', (req, res, next) => this.processBuilderController.getAllProcess(req, res, next).catch(next));

        * this.router.post(this.route_prefix + '/deletebpmn', (req, res, next) => this.processBuilderController.deleteProcess(req, res, next).catch(next));
        * this.router.post(this.route_prefix + '/delete-multiple-bpmn', (req, res, next) => this.processBuilderController.deleteMultipleProcess(req, res, next).catch(next));
       

        * this.router.post(this.route_prefix + '/updatebpmn', (req, res, next) => this.processBuilderController.updateProcess(req, res, next).catch(next));
        * this.router.post(this.route_prefix + '/status', (req, res, next) => this.processBuilderController.statusProcess(req, res, next).catch(next));
        * this.router.post(this.route_prefix + '/update-status', (req, res, next) => this.processBuilderController.updateStatus(req, res, next).catch(next));
        * this.router.post(this.route_prefix + '/next', (req, res, next) => this.processBuilderController.nextProcess(req, res, next).catch(next));
        */
    }
}
