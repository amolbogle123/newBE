import {Engine} from 'bpmn-engine';
import EventEmitter from "events";
import {ProcessBuilderService} from "../../services/process-builder.service";
import lodash from "lodash";
import {BusinessProcessModeling} from "../../../../entities";
import {Conditions, PanelData, PanelDataTask, ProcessDataType, ProcessStatus} from "../../models";
import {UserTaskHelper} from "./user-task.helper";
import {ReceiveTaskHelper} from "./receive-task.helper";
import {TimerTaskHelper} from "./timer-task.helper";
import {ServiceTaskHelper} from "./service-task.helper";
import {FormBuilderHelper} from "../../../form-builder/utils/helpers/form-builder.helper";
import {FormBuilder} from "../../../../entities/create-form-builder";


export class ProcessBuilderHelper {


    // Services
    private processBuilderService: ProcessBuilderService = new ProcessBuilderService();

    // Other Helpers
    private userTaskHelper: UserTaskHelper = new UserTaskHelper();
    private receiverTaskHelper: ReceiveTaskHelper = new ReceiveTaskHelper();
    private timerTaskHelper: TimerTaskHelper = new TimerTaskHelper();
    private serviceTaskHelper: ServiceTaskHelper = new ServiceTaskHelper();



    private async checkAndGetNext(workFlow: any[], formId: string | null, insertId: any = null): Promise<any> {
        const criteria = {formId, followAfter: workFlow[0].id, entryId: insertId, taskName: PanelDataTask.APPROVED_INITIATION, status: 1};
        const bpmnExecResponse = await this.processBuilderService.getBpmnExecute(criteria, ['id']);

        if (bpmnExecResponse.length > 0 || !lodash.isEmpty(bpmnExecResponse)) {
            const workFlow1 = await this.processBuilderService.getMultipleBpmn({formId, followAfter: workFlow[0].id});

            if (workFlow1 && workFlow1.length > 0) {
                return this.checkAndGetNext(workFlow1, formId);
            }
        } else {
            return workFlow;
        }

    }

    private static valueCompare(value1: any, conditionOf: any, value2: any) {
        if (typeof value1 === 'string') {
            value1 = value1.toLowerCase();
        } else if (typeof value1 === "boolean") {
            value1 = value1.toString();
        } else if (!isNaN(value1)) {
            value1 = parseFloat(value1);
        }

        if (typeof value2 === 'string') {
            value2 = value2.toLowerCase();
        } else if (typeof value2 === "boolean") {
            value2 = value2.toString();
        } else if (!isNaN(value2)) {
            value2 = parseFloat(value2);
        }
        
        switch (conditionOf) {
            case 'equals':
                return (value1 == value2);
            case 'notequals':
                return (value1 != value2);
            case 'greaterthan':
                return (value1 > value2);
            case 'smallerthen':
                return (value1 < value2);
            case 'greaterequals':
                return (value1 >= value2);
            case 'smallerequals':
                return (value1 <= value2);
            case 'contains':
                return value1.includes(value2);
            case 'startswith':
                return value1.startsWith(value2);
            case 'endswith':
                return value1.endsWith(value2);
            default:
                return false;
        }
    }

    private checkCondition(checkId: any, panelData: PanelData | any, data: any, insertId: string | null) {
        const condition = panelData.conditionsarr.find((x: Conditions) => x.id === checkId);
      
        if (condition && condition.conditionon && condition.conditionType && condition.params?.sqlFields) {
          const sourceData = this.getSourceData(condition.conditionon, panelData, data, insertId);
      
          if (sourceData || condition.conditionon == 'TASK_RESPONSE') {
            const checkedCount = this.countMatches(condition.conditionon, sourceData, condition.params.sqlFields, panelData);
            
            if ((condition.conditionType === 'AND' && checkedCount === condition.params.sqlFields.length) || (condition.conditionType === 'OR' && checkedCount > 0)) {
              return true;
            } else {
              return false;
            }
          }
        }
      
        return false;
      }
      
      private getSourceData(conditionon: string, panelData: PanelData | any, data: any, insertId: string | null) {
        if (conditionon === 'CONNECTOR' && panelData.connectorParams?.columnName) {
          return data?.queryData && data.queryData[panelData.connectorParams.columnName] === insertId
            ? data.queryData
            : null;
        } else if (conditionon === 'FORM' && data?.submittedData) {
          try {
            return JSON.parse(data.submittedData);
          } catch {
            return null;
          }
        }
        return null;
      }
      
      private countMatches(conditionon: string, sourceData: any, sqlFields: any[], panelData: PanelData | any) {
        let checkedCount = 0;
      
        for (const field of sqlFields) {
          let sourceValue = sourceData?.[field.columnName] ?? '';
          let matchValue = '';
          if (conditionon === 'FORM') {
            matchValue = field.otherValue;
          } else if (sourceData?.[field.formField]) {
            matchValue = sourceData[field.formField];
          } else if (conditionon === 'TASK_RESPONSE') {
            matchValue = field.otherValue;
          }

          if (conditionon === 'TASK_RESPONSE' && field.columnName) {
            const taskData = panelData.taskarr.find((x: any) => x.id === field.columnName);
            if (taskData?.params && typeof taskData.params[`${field.taskOutput}`] !== 'undefined') {
              sourceValue = taskData.params[`${field.taskOutput}`];
            }
          }
      
          if (sourceValue !== '' && field.matchCase && matchValue !== '' && ProcessBuilderHelper.valueCompare(sourceValue, field.matchCase, matchValue)) {
            checkedCount += 1;
      
            if (field.conditionType === 'OR') {
              break;
            }
          }
        }
      
        return checkedCount;
      }
      

    private async executeWorkFlow(
        {bpmnId, panel_data, data, bpmnData, insertId, tempId, client_id, formTableName}
    ) {
        const panelData: any = JSON.parse(panel_data);
        panelData.executedActivities = [];

        if (Array.isArray(data.executedActivities) && data.executedActivities.length) {
            panelData.executedActivities = data.executedActivities;
        }

        let engine = Engine({ name: 'exclusive gateway example', source: bpmnData, });
        const listener = new EventEmitter();

        listener.on('wait', async (elemntApi, instance) => {
            // Nothing to work here as of now...
        });

        listener.on('wait', (api) => {
            console.log(api.name, 'is waiting');
            api.signal();
        });

        listener.on('activity.start', async (api) => {
            if (api.type && api.type.includes('UserTask')) {
                const taskVars = { panelData, api, data, formId: tempId, entryId: insertId, client_id, bpmnId, formTableName };
                await this.userTaskHelper.executeTask(taskVars, engine);
            }
            if (api.type && api.type.includes('IntermediateCatchEvent')) {
                const taskVars = { panelData, api, data, clientId: client_id, bpmnId, entryId: insertId };
                await this.timerTaskHelper.executeTask(taskVars, engine);
            }

            if (api.type && api.type.includes('ReceiveTask')) {
                const taskVars = { panelData, api, data, formId: tempId, entryId: insertId, clientId: client_id };
                await this.receiverTaskHelper.executeTask(taskVars);
            }
        });

        /**
         * listener.on('flow.take', (flow) => {
            //This is left intentionally blank. Nothing to work here as of now...
        });

        listener.on('flow.discard', (flow) => {
            //This is left intentionally blank. Nothing to work here as of now...
        });
         */

        engine.execute({
            listener,
            services: {
                getRequest: async (scope: any, callback: (arg0: null, arg1: unknown) => any) => {
                    try {
                        const taskVarPanelVars = { client_id, bpmnId, formId: tempId };
                        const result = await this.serviceTaskHelper.executeTask(Object.assign(taskVarPanelVars, panelData), data, scope, insertId, formTableName);
                        return callback(null, result);
                    } catch (err) {
                        console.error('err', err);
                        return callback(null, err);
                    }
                },
                check: (checkId: any) => {
                    return this.checkCondition(checkId, panelData, data, insertId);
                }
            }
        });

    }

    async execute(clientId: number, formId: string | null, entryId: string | null,referenceId: string, data: any = null, bpmnId: string | null = null, extra: any = {}): Promise<any> {
        /* STARTING POINT of BPMN */
        // const customFormTable = await FormBuilderHelper.getTableName(clientId, formBuilderEntity);
        const customFormTable = `form_builder_${clientId}_${referenceId}`;

        if (lodash.isEmpty(data)) {
            // const queryResponse: FormBuilder[] = await ( await FormBuilderHelper.formBuilderRepo(clientId) ).findBy({formId, id: entryId});
            const queryResponse: FormBuilder[] = await ( await FormBuilderHelper.formBuilderRepo(clientId, referenceId) ).findBy({formId, id: entryId});

            if (queryResponse.length > 0) {
                data = queryResponse[0];
            }
        }

        if (bpmnId) {
            data.bpmnid = bpmnId;
        }

        const directBpmnType: ProcessDataType[] = [
            ProcessDataType.SQL_CONNECTOR,
            ProcessDataType.FROM_ANOTHER_PROCESS,
            ProcessDataType.PULSE_THRESHOLD,
            ProcessDataType.CAMPAIGN,
            ProcessDataType.MANUAL_TRIGGER,
            ProcessDataType.BPMN_CRON
        ];
        let workflow: string | any[] = await this.getWorkflow(data, formId, directBpmnType);
          

        if (workflow.length > 0) {
            let newWorkFlow: BusinessProcessModeling[] = await this.checkAndGetNext(workflow, formId, entryId);

            if (newWorkFlow.length > 0) {
                for (let i = newWorkFlow.length - 1; i >= 0; i--) {

                    if (
                        newWorkFlow[i].type === ProcessStatus.TIMER_BASED &&
                        extra && extra.type === ProcessStatus.FORM_SUBMIT
                    ) {
                        continue;
                    }
                    let {id, panelData, bpmnData} = newWorkFlow[i];
                    let executeWorkFlowInput={
                        bpmnId:id,
                        panel_data:panelData,
                        data:data,
                        bpmnData:bpmnData,
                        insertId:entryId,
                        tempId:formId,
                        client_id:clientId,
                        formTableName:customFormTable
                    }
                    await this.executeWorkFlow(executeWorkFlowInput);
                }
            }

        }
}

    private async getWorkflow(data: any, formId: string, directBpmnType: ProcessDataType[]) {
        let workflow: string | any[] = [];

        let bpmnOptions = {};
        if (data.bpmnid && !formId && directBpmnType.includes(data.type)) {
            bpmnOptions = { id: data.bpmnid, followAfter: 0 };
        }
        else if (data.bpmnid && formId) {
            bpmnOptions = { id: data.bpmnid, followAfter: 0, status: 1 };
        } else {
            bpmnOptions = { formId: formId, followAfter: 0, status: 1 };
        }
        const bpmnResult: BusinessProcessModeling[] = await this.processBuilderService.getMultipleBpmn(bpmnOptions);
        if (bpmnResult.length > 0) {
            workflow = bpmnResult;
        }
        return workflow;
    }
}
