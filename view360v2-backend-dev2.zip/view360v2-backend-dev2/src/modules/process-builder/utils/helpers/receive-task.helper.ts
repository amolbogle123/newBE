import {ProcessBuilderService} from "../../services/process-builder.service";
import lodash from "lodash";
import {PanelData, PanelDataTask, ProcessCheckOn} from "../../models";
import {CommunicationHelper} from "../../../../utils/helpers/communication.helper";
import {MailTemplate, NotificationTemplate, Users} from "../../../../entities";
import {In, DataSource} from "typeorm";
import {BpmnNotificationHelper} from "./bpmn-notification.helper";
import Container from 'typedi';

export class ReceiveTaskHelper {


    // Services
    private processBuilderService: ProcessBuilderService = new ProcessBuilderService();

    // Helpers
    private bpmnNotificationHelper: BpmnNotificationHelper = new BpmnNotificationHelper();
    private communicationHelper: CommunicationHelper = new CommunicationHelper();

    private async notifyMasterClient(data: any) {
        const result: any[] = await this.processBuilderService
            .getMdbClient({id: data.id}, ['id', 'name', 'websiteUrl'])

        if (result && result.length) {
            // TO_DO: firebase functionality will be execute here...
            // firebaseFun.pushFirebase(`clientAlert`, data.firebaseValue);
        }
    }


    async executeTask(task: any) {

        let panelData: PanelData | any = task.panelData.taskarr.find( (x: any) => { return x.id === task.api.id });
        let isExecutedAlready = false;
        if (task.panelData.executedActivities.indexOf(task.api.id) > -1) {
            return;
        }
        task.panelData.executedActivities.push(task.api.id);

        if (panelData && panelData.params && panelData.checkon && !isExecutedAlready) {
            let message: string = '';
            if (panelData.params.mailtemplate) {

                let mailTemplateArr: MailTemplate[] = await Container.get(DataSource).getRepository(MailTemplate)
                    .find({where: {id: panelData.params.mailtemplate}, select: ['subject', 'body']});

                if (lodash.isEmpty(mailTemplateArr)) {
                    console.error("No Mail Template Found on BPMN Receive Task.");
                    return;
                }
                let [mailTemplate] = mailTemplateArr;
                message = mailTemplate.body;

                let { mailParams, entryData }: { mailParams: any; entryData: any; } = this.getMailParamsAndEntryData(mailTemplate, task, panelData);
                mailParams.name = entryData.userName;
                mailParams.entryData = entryData.entryData;

                await this.sendEmailAsPerProcessCheckOn(panelData, entryData, mailParams, task);
            }
            if (panelData.params.notificationTemplate) {
                panelData.params.checkon = panelData.checkon;

                message = await this.getNotificationMessageIfTaskTypeIsPulseThreshold(task, panelData, message);

                await this.sendBPMNNotificationAsPerProcessCheckOn(panelData, task);
            }

            await this.notifyMasterClientFor_PULSE_THRESHOLD(task, message);
        }
    }

    private async getNotificationMessageIfTaskTypeIsPulseThreshold(task: any, panelData: any, message: string) {
        if (task.data.type && task.data.type === 'PULSE_THRESHOLD') {
            const notifyTemplatesArr = await Container.get(DataSource).getRepository(NotificationTemplate)
                .find({ where: { id: panelData.params.notificationTemplate }, select: ['message'] });

            if (notifyTemplatesArr && notifyTemplatesArr.length > 0) {
                message = notifyTemplatesArr[0].message;
            }
            panelData.params.alertMasterClient = true;
        }
        return message;
    }

    private getMailParamsAndEntryData(mailTemplate: MailTemplate, task: any, panelData: any) {
        let mailParams: any = {
            subject: mailTemplate.subject,
            body: mailTemplate.body,
            tempId: task.formId,
            insertId: task.entryId,
            clientId: task.clientId,
            templateId: panelData.params.mailtemplate
        };
        let entryData: any = {};
        if (task.data && task.data.submittedData) {
            entryData = JSON.parse(task.data.submittedData);
        }
        return { mailParams, entryData };
    }

    private async notifyMasterClientFor_PULSE_THRESHOLD(task: any, message: string) {
        if (task.data.type && task.data.type === 'PULSE_THRESHOLD') {

            const payload = {
                id: task.clientId,
                firebaseValue: {
                    clientId: task.clientId,
                    message: message || 'Trigger threshold hit',
                    pulseId: task.data.pulseId,
                    pulseTitle: task.data.pulseTitle,
                    runTime: task.data.runTime,
                    pulseValue: task.data.otherData && task.data.otherData.fieldValue || null,
                    thresholdValue: task.data.otherData && task.data.otherData.operationValue || null,
                    workflow: task.data.bpmnid,
                }
            };

            await this.notifyMasterClient(payload);
        }
    }

    private async sendBPMNNotificationAsPerProcessCheckOn(panelData: any, task: any) {
        if (panelData.checkon === ProcessCheckOn.FORM_FIELD) {
            await this.sendBPMNNotification_ForProcessCheckOn_FormField(task, panelData);
        } else if (panelData.checkon === ProcessCheckOn.ASSIGNED_USER) {
            await this.sendBPMNNotification_ForProcessCheckOn_AssignedUser(task, panelData);
        } else if (panelData.checkon === ProcessCheckOn.SELECTED_USER) {
            await this.sendBPMNNotification_ForProcessCheckOn_SelectedUser(panelData, task);
        } else if (panelData.checkon === ProcessCheckOn.SELECTED_ROLE) {
            await this.sendBPMNNotification_ForProcessCheckOn_SelectedRole(panelData, task);
        }
    }

    private async sendBPMNNotification_ForProcessCheckOn_FormField(task: any, panelData: any) {
        if (task.data && task.data.submittedData) {
            let entryData = JSON.parse(task.data.submittedData);
            panelData.params.assignee = entryData[panelData.params.recipientMail];
            await this.bpmnNotificationHelper
                .execute(task.formId, task.entryId, panelData.params, PanelDataTask.RECEIVE_TASK_NOTIFY, task.clientId, task?.data?.createdBy);
        }
    }

    private async sendBPMNNotification_ForProcessCheckOn_AssignedUser(task: any, panelData: any) {
        if (task.data && task.data.assignUser) {
            panelData.params.assignee = task.data.assignUser;
            await this.bpmnNotificationHelper
                .execute(task.formId, task.entryId, panelData.params, PanelDataTask.RECEIVE_TASK_NOTIFY, task.clientId, task?.data?.createdBy);
        }
    }

    private async sendBPMNNotification_ForProcessCheckOn_SelectedUser(panelData: any, task: any) {
        if (Array.isArray(panelData.params.recipientMail) && panelData.params.recipientMail.length > 0) {
            for (const selectedUser of panelData.params.recipientMail) {
                panelData.params.assignee = selectedUser;
                await this.bpmnNotificationHelper
                    .execute(task.formId, task.entryId, panelData.params, PanelDataTask.RECEIVE_TASK_NOTIFY, task.clientId, task?.data?.createdBy);
            }
        }
    }

    private async sendBPMNNotification_ForProcessCheckOn_SelectedRole(panelData: any, task: any) {
        if (Array.isArray(panelData.params.recipientMail) && panelData.params.recipientMail.length > 0) {

            let roleUsers: Users[] = await this.processBuilderService
                .getMultipleUser({ roleId: In(panelData.params.recipientMail) }, ['id']);

            if (roleUsers && roleUsers.length > 0) {
                for (const userValue of roleUsers) {
                    panelData.params.assignee = userValue.id;
                    await this.bpmnNotificationHelper
                        .execute(task.formId, task.entryId, panelData.params, PanelDataTask.RECEIVE_TASK_NOTIFY, task.clientId, task?.data?.createdBy);
                }
            }
        }
    }

    private async sendEmailAsPerProcessCheckOn(panelData: any, entryData: any, mailParams: any, task: any) {
        if (panelData.checkon === ProcessCheckOn.FORM_FIELD) {
            await this.sendEmail_ForProcessCheckOn_FormField(entryData, panelData, mailParams);
        } else if (panelData.checkon === ProcessCheckOn.TEXT_VALUE) {
            if (panelData.params.recipientMail) {
                mailParams.to = panelData.params.recipientMail;
                await this.communicationHelper.sendEmail(mailParams);
            }
        } else if (panelData.checkon === ProcessCheckOn.CUSTOM_FIELD) {
            await this.sendEmail_ForProcessCheckOn_CustomField(panelData, task, mailParams);
        } else if (panelData.checkon === ProcessCheckOn.ASSIGNED_USER) {
            await this.sendEmail_ForProcessCheckOn_AssignedUser(task, mailParams);
        } else if (panelData.checkon === ProcessCheckOn.SELECTED_USER ||
            panelData.checkon === ProcessCheckOn.SELECTED_ROLE) {
            await this.sendEmail_ForProcessCheckOn_SelectedUser(panelData, mailParams);
        } else if (panelData.checkon === ProcessCheckOn.CAMPAIGN_USERS) {
            await this.sendEmail_ForProcessCheckOn_CampaignUsers(task, mailParams);
        } else if (panelData.checkon === ProcessCheckOn.SELECTED_TEAM_ROLE) {
            await this.sendEmail_ForProcessCheckOn_SelectedTeamRole(panelData, mailParams);
        } else if (panelData.checkon === ProcessCheckOn.CUSTOM_DATA) {
          await this.sendEmail_ForProcessCheckOn_SelectedDataField(entryData, panelData, mailParams, task);
        }
    }

    private async sendEmail_ForProcessCheckOn_FormField(entryData: any, panelData: any, mailParams: any) {
        if (Array.isArray(entryData[panelData.params.recipientMail]) &&
            entryData[panelData.params.recipientMail].length) {
            for (const recipientMail of entryData[panelData.params.recipientMail]) {
                mailParams.to = recipientMail;
                await this.communicationHelper.sendEmail(mailParams);
            }
        } else {
            mailParams.to = entryData[panelData.params.recipientMail];
            await this.communicationHelper.sendEmail(mailParams);
        }
    }

    private async sendEmail_ForProcessCheckOn_CampaignUsers(task: any, mailParams: any) {
        let userEmails: any[];

        try {
            userEmails = task.data.EMAIL_CONFIG ? task.data.EMAIL_CONFIG.split(',') : [];
        } catch (e) {
            userEmails = [];
        }
        if (!lodash.isEmpty(userEmails.length)) {
            for (const userEmail of userEmails) {
                mailParams.to = userEmail;
                await this.communicationHelper.sendEmail(mailParams);
            }
        }
    }

    private async sendEmail_ForProcessCheckOn_SelectedTeamRole(panelData: any, mailParams: any) {
        if (panelData.params.recipientMail &&
            panelData.params.recipientMail.teamIds &&
            panelData.params.recipientMail.RoleType_ID) {
            const criteria = {
                roleId: In(panelData.params.recipientMail.RoleType_ID),
                teamId: In(panelData.params.recipientMail.teamIds),
            };
            const teamRoleUsers = await this.processBuilderService.getMultipleUser(criteria, ['username', 'email']);

            if (Array.isArray(teamRoleUsers) && teamRoleUsers.length > 0) {
                for (const teamUser of teamRoleUsers) {
                    if (teamUser.email) {
                        mailParams.to = teamUser.email;
                        await this.communicationHelper.sendEmail(mailParams);
                    }
                }
            }
        }
    }
    private async sendEmail_ForProcessCheckOn_SelectedDataField(entryData: any, panelData: any, mailParams: any, task: any) {
        if (panelData.params.recipientMail && task?.data && task?.data[panelData.params.recipientMail]) {
          mailParams.to = task.data[panelData.params.recipientMail];
          mailParams.entryData = {
            contractLink: task.data?.contractLink ?? ''
          };
          await this.communicationHelper.sendEmail(mailParams);
        }
    }

    private async sendEmail_ForProcessCheckOn_CustomField(panelData: any, task: any, mailParams: any) {
        if (panelData.params.recipientMail && task.data[panelData.params.recipientMail]) {
            mailParams.to = task.data[panelData.params.recipientMail];
            await this.communicationHelper.sendEmail(mailParams);
        }
    }

    private async sendEmail_ForProcessCheckOn_AssignedUser(task: any, mailParams: any) {
        if (task.data && task.data.assignUser) {
            let assignedUserArr: Users[] = await this.processBuilderService.getMultipleUser({ id: task.data.assignUser }, ['email']);

            if (assignedUserArr && !lodash.isEmpty(assignedUserArr)) {
                mailParams.to = assignedUserArr[0].email;
                await this.communicationHelper.sendEmail(mailParams);
            }
        }
    }

    private async sendEmail_ForProcessCheckOn_SelectedUser(panelData: any, mailParams: any) {
        if (Array.isArray(panelData.params.recipientMail) && panelData.params.recipientMail.length > 0) {

            const condition: any = panelData.checkon === ProcessCheckOn.SELECTED_USER ?
                { id: In(panelData.params.recipientMail) } : { roleId: In([3, 4, 5]) };
            const assignedUserArr: Users[] = await this.processBuilderService.getMultipleUser(condition, ['email']);

            if (assignedUserArr.length || !lodash.isEmpty(assignedUserArr)) {
                for (const selectedUser of assignedUserArr) {
                    if (!lodash.isEmpty(selectedUser.email)) {
                        mailParams.to = selectedUser.email;
                        await this.communicationHelper.sendEmail(mailParams);
                    }
                }
            }

        }
    }
}
