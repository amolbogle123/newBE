import { Controller, Get, Route } from "tsoa";
import * as os from 'os';
import { exec } from "child_process";
import { CommonHelper } from "utils/helpers/common.helper";
import moment from "moment";

const serviceKeywords = [
    { displayName: 'MySQL', windowsServiceName: 'mysqld.exe', linuxServiceName: 'mysql' },
    { displayName: 'Redis', windowsServiceName: 'redis-server.exe', linuxServiceName: 'redis' },
    { displayName: 'Nginx', windowsServiceName: 'nginx.exe', linuxServiceName: 'nginx' },
    // { displayName: 'PHP', windowsServiceName: 'php-cgi.exe', linuxServiceName: 'php' },
    { displayName: 'NodeJS', windowsServiceName: 'node.exe', linuxServiceName: 'node' },
    { displayName: 'Docker', windowsServiceName: 'docker.exe', linuxServiceName: 'docker' },
    { displayName: 'Google Chrome', windowsServiceName: 'chrome.exe', linuxServiceName: 'chrome' }
];

@Route('service-status')
export class ServiceStatusController extends Controller {
    @Get('check-status')
    async getServiceStatus(): Promise<any> {
        try {
            if (os.platform() === 'win32') {
                const result = await this.getAllServiceInfoWindows(serviceKeywords);
                return CommonHelper.apiSwaggerSuccessResponse({ data: { serviceInfo: result, osInfo: await this.getOsInformation() } });
            } else {
                const result = await this.getAllServiceInfoLinux(serviceKeywords);
                return CommonHelper.apiSwaggerSuccessResponse({ data: { serviceInfo: result, osInfo: await this.getOsInformation() } });
            }
        } catch (error) {
            console.log("Error while getting service status :: ", error);
            return CommonHelper.apiSwaggerErrorResponse({ error: error.message });
        }
    }

    private async getAllServiceInfoWindows(serviceKeyword) {
        const infoPromises = serviceKeyword.map(servicesKeyword => this.getServiceInfoWindows(servicesKeyword));
        return Promise.all(infoPromises);
    }

    private async getServiceInfoWindows(serviceKeyword) {
        const command = `wmic process where "name='${serviceKeyword.windowsServiceName}'" get ProcessId,CreationDate /format:list`;
        return new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    resolve({
                        serviceName: serviceKeyword.displayName,
                        pid: null,
                        uptime: error.message
                    });
                    return;
                }
                if (stderr) {
                    resolve({
                        serviceName: serviceKeyword.displayName,
                        pid: null,
                        uptime: stderr.trim()
                    })
                    return;
                }

                const lines = stdout.split(os.EOL).filter(line => line.trim() !== '');
                if (lines.length === 1) {
                    resolve({
                        serviceName: serviceKeyword.displayName,
                        pid: null,
                        uptime: 'Service not found'
                    });
                    return;
                }

                const pidLine = lines[1].trim();
                const pid = pidLine.split('=')[1];
                const creationDateLine = lines[0].trim();
                const creationDateString = creationDateLine.split('=')[1].trim();
                const year = Number(creationDateString.substring(0, 4));
                const month = Number(creationDateString.substring(4, 6)) - 1;
                const day = Number(creationDateString.substring(6, 8));
                const hours = Number(creationDateString.substring(8, 10));
                const minutes = Number(creationDateString.substring(10, 12));
                const seconds = Number(creationDateString.substring(12, 14));

                const creationDate = new Date(year, month, day, hours, minutes, seconds);

                const uptimeSeconds = (Date.now() - creationDate.getTime()) / 1000;

                resolve({
                    serviceName: serviceKeyword.displayName,
                    pid: pid,
                    uptime: this.formatUptime(uptimeSeconds)
                });
            });
        });
    }

    private async getAllServiceInfoLinux(serviceKeyword) {
        const infoPromises = serviceKeyword.map(servicesKeywords => this.getServiceInfoLinux(servicesKeywords));
        return Promise.all(infoPromises);
    }

    private async getServiceInfoLinux(serviceKeyword) {
        const command = `ps -eo pid,lstart,cmd | grep "${serviceKeyword.linuxServiceName}"`;
        return new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    resolve({
                        serviceName: serviceKeyword.displayName,
                        pid: null,
                        uptime: error.message.trim()
                    })
                    return;
                }
                if (stderr) {
                    resolve({
                        serviceName: serviceKeyword.displayName,
                        pid: null,
                        uptime: stderr.trim()
                    })
                    return;
                }

                const lines = stdout.split(os.EOL).filter(line => line.trim() !== '');
                
                if (lines.length < 3) {
                    resolve({
                        serviceName: serviceKeyword.displayName,
                        pid: null,
                        uptime: 'Service not found'
                    });
                    return;
                }

                const fields = lines[0].split(/\s+/);
                const pid = fields[1];

                const startTimeString = fields.slice(2, 7).join(' ');
                const startTime = moment(startTimeString, 'ddd MMM D HH:mm:ss YYYY').toDate();
                const uptimeSeconds = (Date.now() - startTime.getTime()) / 1000;

                resolve({
                    serviceName: serviceKeyword.displayName,
                    pid: pid,
                    uptime: this.formatUptime(uptimeSeconds)
                });
            });
        });
    }

    private formatUptime(uptimeSeconds) {
        const days = Math.floor(uptimeSeconds / (3600 * 24));
        const hours = Math.floor((uptimeSeconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        const seconds = Math.floor(uptimeSeconds % 60);

        return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    }

    private async getOsInformation() {
        return {
            platform: os.platform(),
            release: os.release(),
            type: os.type(),
            arch: os.arch(),
            totalMemory: (os.totalmem() / 1024 / 1024 / 1024).toFixed(2) + ' GB',
            freeMemory: (os.freemem() / 1024 / 1024 / 1024).toFixed(2) + ' GB',
            uptime: this.formatUptime(os.uptime())
        };
    }
}
