import { dataSource } from "core/data-source";
import { Themes } from "entities";
import { Body, Controller, Delete, Get, Patch, Post, Request, Route, Security, Tags } from "tsoa";
import Container from "typedi";
import { DataSource } from "typeorm";
import { CustomFooter } from "../../../entities/custom-footer";
import { ApiErrorResponse, CommonHelper } from "../../../utils/helpers/common.helper";
import { AddCustomFooterResponse, AddUpdateCustomFooterRequestBody, CustomFooterApiErrorResponse, CustomFooterMessageResponse, DeleteCustomFooterRequestBody, GetCustomFooterResponse } from "../doc/custom-footer.interface";
@Route("custom-footer")
@Tags("Custom Footer")
export class CustomFooterController extends Controller {
    
     /**
     * get CustomFooter Objects
     */
    @Security("bearerAuth")
    @Get("/")
    async get(
        @Request() req: any,
    ): Promise<GetCustomFooterResponse|CustomFooterApiErrorResponse> {
        try {
            let Objects;
            const custom_footer_id = req.userDetails.client_id;
            Objects = await Container.get(DataSource)
                .getRepository(CustomFooter)
                .findOneBy({
                    clientId: custom_footer_id,
                });
            if (Objects != null) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: Objects,
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "No records has been found!.",
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

     /**
     * Update CustomFooter Objects
     */
    @Security("bearerAuth")
    @Patch("/")
    async update(
        @Body() body: AddUpdateCustomFooterRequestBody
    ): Promise<CustomFooterMessageResponse|CustomFooterApiErrorResponse> {
        try {
            let result;
            let id = body.clientId;
            result = await Container.get(DataSource)
                .getRepository(CustomFooter)
                .update({ clientId: id }, body);

            if (result.affected > 0) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Custom Footer updated successfully",
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Custom Footer Not Found",
                });
            }
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    /**
     * Add CustomFooter Objects
     */
    @Security("bearerAuth")
    @Post("/")
    async add(
        @Request() req: any,
        @Body() body: AddUpdateCustomFooterRequestBody
    ): Promise<AddCustomFooterResponse| CustomFooterApiErrorResponse> {
        try {
            const customFooterObj = new CustomFooter();
            customFooterObj.data = body.data;
            customFooterObj.clientId = body.clientId;
            customFooterObj.createdBy = body.createdBy;
            customFooterObj.active = body.active;
            customFooterObj.stickyFooter = body.stickyFooter;
            customFooterObj.themeSetting = body.themeSetting;

            const result = await Container.get(DataSource).manager.save(
                customFooterObj
            );
            this.setStatus(201);
            return CommonHelper.apiSwaggerSuccessResponse({ data: result });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    @Security("bearerAuth")
    @Delete("/")
    async delete(
        @Request() request: any,
        @Body() body: DeleteCustomFooterRequestBody,
    ): Promise<CustomFooterMessageResponse | CustomFooterApiErrorResponse> {
        try {
            let result;
            result = await Container.get(DataSource)
                .getRepository(CustomFooter)
                .delete({id:body.id, clientId: request.userDetails.client_id });
            if (result){
            if(result.affected > 0) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "Record deleted successfully",
                });
            } else {
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "No Record Found",
                });
            }}else{
                return CommonHelper.apiSwaggerSuccessResponse({
                    message: "No Record Found",
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Patch("/default-setting")
    async resetToDefault(
        @Request() request: any
    ): Promise<unknown|CustomFooterApiErrorResponse> {
        try {
            let themeResult: any = await dataSource
                .getRepository(Themes)
                .findOne({
                    where: {
                        client_id: request.userDetails.client_id,
                        userid: request.userDetails.user_id,
                        isDefault: true
                    },
                });
            const theme = JSON.parse(themeResult.theme)
            const defaultFooter = theme?.data?.siteTheme?.footer;

            if (defaultFooter) {
                const footerData = {
                    data: "",
                    themeSetting: JSON.stringify(defaultFooter),
                    active: 0,
                    stickyFooter: 0
                }
                const result = await Container.get(DataSource)
                    .getRepository(CustomFooter)
                    .update({ clientId: request.userDetails.client_id }, footerData);
                if (result) {
                    return CommonHelper.apiSwaggerSuccessResponse({
                        data: footerData
                    })
                }                     
            }

            return CommonHelper.apiSwaggerErrorResponse({
                error: {
                    message: "Failed to update to default."
                }
            })
        } catch (err) {
            console.log("Error :: ", err)
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
