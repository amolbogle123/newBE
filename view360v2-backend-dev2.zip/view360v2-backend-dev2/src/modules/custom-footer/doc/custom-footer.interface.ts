export interface AddUpdateCustomFooterRequestBody {
    clientId:number;
    createdBy:string;
    data:string;
    active:number;
    stickyFooter: number;
    themeSetting:string;
}
export interface DeleteCustomFooterRequestBody {
    id:string;
}
export interface GetCustomFooterResponse {
    status:boolean;
    message:string;
    data:CustomFooter[];
}
export interface AddCustomFooterResponse {
    status:boolean;
    message:string;
    data:CustomFooter;
}
export interface CustomFooter {
    id:string;
    clientId:string;
    data:string,
    themeSetting:string,
    active:number;
    createdBy:string;
    createdOn:string;
}
export interface CustomFooterMessageResponse {
    message:string;
}
export interface CustomFooterApiErrorResponse {
    status:boolean;
    message:string;
    error:{
        error_description:string;
    };
}