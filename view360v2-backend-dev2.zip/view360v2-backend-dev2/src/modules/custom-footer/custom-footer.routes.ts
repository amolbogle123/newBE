import {AppRoutes} from "../../app.routes";
import { CustomFooterController } from "./controllers/custom-footer.controller";

export class CustomFootersRoutes extends AppRoutes {
    customFooterService: CustomFooterController;

    constructor() {
        super();
        this.customFooterService = new CustomFooterController();
        this.initRoutes();
    }

    initRoutes() {
        /*
         * this.router.get('/custom-footer',  (req, res, next) => this.customFooterService.getDetails(req,res,next).catch(next));
         * this.router.post('/custom-footer',  (req, res, next) => this.customFooterService.addCustomFooter(req,res,next).catch(next));
         * this.router.put('/custom-footer',  (req, res, next) => this.customFooterService.updateCustomFooter(req,res,next).catch(next));
         * this.router.delete('/custom-footer',  (req, res, next) => this.customFooterService.deleteRouter(req,res,next).catch(next));
        */
    }
}
