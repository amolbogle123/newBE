import { AppRoutes } from "../../app.routes";
import {AiDrivenController} from "./controllers/ai-driven.controller";

export class AiDrivenRoutes extends AppRoutes {

    private aiDrivenController: AiDrivenController;


    constructor() {
        super();
        this.aiDrivenController = new AiDrivenController();
        this.initRoutes();
    }

    initRoutes() {

        this.router.get('/aidriven/app-list', (req: any, res: any, next: any) =>
            this.aiDrivenController.getAppList(req, res, next).catch(next)
        );
    }
}

