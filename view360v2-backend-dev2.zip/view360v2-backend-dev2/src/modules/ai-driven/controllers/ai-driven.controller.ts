import {NextFunction, Request, Response} from "express";
import {Repository,DataSource} from "typeorm";
import {AiDrivenApp} from "entities/ai-driven-app";
import {CommonHelper,ApiErrorResponse} from "utils/helpers/common.helper";
import Container from 'typedi';

export class AiDrivenController {
    private aiDrivenAppRepo: Repository<AiDrivenApp> = Container.get(DataSource).getRepository(AiDrivenApp);

    /**
     * Get App List
     * @param request
     * @param response
     * @param next
     */
    async getAppList(request: Request | any, response: Response, next: NextFunction) {
        try {
            const result = await this.aiDrivenAppRepo
                .find({where: {clientId: request.userDetails.client_id}, order: {createdOn: 'DESC'}});

            return CommonHelper.apiSuccessResponse(response, {data: result});

        } catch (e) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (e as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(response, apiErrorResponse);
        }
    }
}
