
import Container from "typedi";
import { DataSource } from "typeorm";

export class VendorService {
    saveVendorData(fileData) {
        return new Promise(async(resolve) => {
            const response = {TableData: []};

            try {
                for (let sheet of fileData) {
                    if (sheet.xlsxJson?.length) {
                        for (let row of sheet.xlsxJson) {
                            if (row) {
                                const result = await Container.get(DataSource).manager.save('');
                                response.TableData.push(result);
                            }
                        }
                    }
                }

                resolve(response);
            } catch (error) {
                resolve(response);
            }
        });
    }
}
