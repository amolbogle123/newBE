import PDFParser from "pdf2json";

export class FileUploaderHelper {

    static async parsePdf(filePath: string, fileObj): Promise<any> {
        return new Promise((resolve) => {
            const response = { status: false, data: null, error: "" };
            let pdfParser = new PDFParser();

            pdfParser.on("pdfParser_dataError", (errData) => {
                console.error(errData.parserError);
                response["error"] = errData.parserError;
                resolve(response);
            });
            pdfParser.on("pdfParser_dataReady", (pdfData) => {
                response.status = true;
                response.data = {
                    pdfData,
                    allField: pdfParser.getAllFieldsTypes(),
                    originalname: fileObj.originalname
                };
                resolve(response);
            });
            pdfParser.loadPDF(filePath);
        });
    }
}
