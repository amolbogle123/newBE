import { AppRoutes } from "../../app.routes";
import fs from "fs";
import multer from "multer";
import path from "path";

import { VendorController } from "./controllers/vendor.controller";
import { MapperController } from "./controllers/mapper.controller";
import { PublicFileController } from "./controllers/public-file.controller";
import { UploadFileController } from "./controllers/upload-file.controller";
import { ThemeBuilderController } from "./controllers/theme-builder.controller";
import {PdfConverterLanguageController} from "../pdf-language-converter/controllers/pdf-converter-language.controller";
import {BulkUploadController} from "../form-builder/controllers/bulk-upload.controller";

export class UploadFilesRoutes extends AppRoutes {
    private mapperController: MapperController;
    private vendorController: VendorController;
    private publicFileController: PublicFileController;
    private uploadFileController: UploadFileController;
    private themeBuilderController: ThemeBuilderController;
    private pdfFileLanguageConverter: PdfConverterLanguageController;
    private bulkUploadController: BulkUploadController;

    public route_prefix = "/xlsx-parser";

    constructor() {
        super();
        this.vendorController = new VendorController();
        this.mapperController = new MapperController();
        this.publicFileController = new PublicFileController();
        this.uploadFileController = new UploadFileController();
        this.themeBuilderController = new ThemeBuilderController();
        this.pdfFileLanguageConverter = new PdfConverterLanguageController();
        this.bulkUploadController = new BulkUploadController();

        this.initRoutes();
    }

    initRoutes() {
        // Read public file
        this.router.get('/public/:folderName/:filename', (req, res, next) => this.publicFileController.downloadFile(req, res, next).catch(next));

        // Theme Builder
        const base64UploadDir = "./public/upload64-files/";
        if (!fs.existsSync(base64UploadDir)) {
            fs.mkdirSync(base64UploadDir);
        }
        this.router.post('/upload-file/b64-img', (req, res, next) => this.uploadFileController.base64Img(req, res, next).catch(next));

        // xlsx mapper
        const mapperUploadDir = "./public/xlsx-mapper/";
        if (!fs.existsSync(mapperUploadDir)) {
            fs.mkdirSync(mapperUploadDir);
        }
        const mapperStorage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, mapperUploadDir);
            },
            filename: getFileName(),
            }
        )
        const mapperFileFilter = (req, file, cb) => {
            cb(null, true);
        };
        const mapperUpload = multer({
            storage: mapperStorage,
            limits: {
                fileSize: 1024 * 1024 * 10,
            },
            fileFilter: mapperFileFilter,
        });
        this.router.post(
            "/upload-file/xlsx-parser",
            mapperUpload.single("file"),
            (req, res, next) =>
                this.mapperController.xlsxMapper(req, res, next).catch(next)
        );

        // xlsx file parser
        const xlsxParserUploadDir = "./public/xlsx-import/";
        if (!fs.existsSync(xlsxParserUploadDir)) {
            fs.mkdirSync(xlsxParserUploadDir);
        }
        const xlsxParserStorage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, xlsxParserUploadDir);
            },
            filename: getFileName(),
        });
        const xlsxParserFileFilter = (req, file, cb) => {
            cb(null, true);
        };
        const xlsxParserUpload = multer({
            storage: xlsxParserStorage,
            limits: {
                fileSize: 1024 * 1024 * 10,
            },
            fileFilter: xlsxParserFileFilter,
        });
        this.router.post(
            "/upload-file/xlsx-data-parser",
            xlsxParserUpload.single("file"),
            (req, res, next) =>
                this.mapperController.xlsxBulkFile(req, res, next).catch(next)
        );

        // PDF Mapper
        const pdfMapperUploadDir = "./public/pdf-mapper/";
        if (!fs.existsSync(pdfMapperUploadDir)) {
            fs.mkdirSync(pdfMapperUploadDir);
        }
        const pdfMapperStorage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, pdfMapperUploadDir);
            },
            filename: getFileName(),
        });
        const pdfMapperFileFilter = (req, file, cb) => {
            cb(null, true);
        };
        const pdfMapperUpload = multer({
            storage: pdfMapperStorage,
            limits: {
                fileSize: 1024 * 1024 * 10,
            },
            fileFilter: pdfMapperFileFilter,
        });
        this.router.post(
            "/upload-file/pdf-parser",
            pdfMapperUpload.single("file"),
            (req, res, next) =>
                this.mapperController.pdfMapper(req, res, next).catch(next)
        );

        // Theme Builder
        const themeBuilderUploadDir = "./public/theme-builder/";
        if (!fs.existsSync(themeBuilderUploadDir)) {
            fs.mkdirSync(themeBuilderUploadDir);
        }
        const themeBuilderStorage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, themeBuilderUploadDir);
            },
            filename: getFileName(),
        });
        const themeBuilderFileFilter = (req, file, cb) => {
            cb(null, true);
        };
        const themeBuilderUpload = multer({
            storage: themeBuilderStorage,
            limits: {
                fileSize: 1024 * 1024 * 10,
            },
            fileFilter: themeBuilderFileFilter,
        });
        this.router.post(
            "/upload-file/theme-builder-file",
            themeBuilderUpload.single("file"),
            (req, res, next) =>
                this.themeBuilderController.themeBuilder(req, res, next).catch(next)
        );

        // Theme Builder
        const mediaAssetsUploadDir = "./public/media-assets/";
        if (!fs.existsSync(mediaAssetsUploadDir)) {
            fs.mkdirSync(mediaAssetsUploadDir);
        }
        const mediaAssetsStorage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, mediaAssetsUploadDir);
            },
            filename: getFileName(),
        });
        const mediaAssetsFileFilter = (req, file, cb) => {
            cb(null, true);
        };
        const mediaAssetsUpload = multer({
            storage: mediaAssetsStorage,
            limits: {
                fileSize: 1024 * 1024 * 50,
            },
            fileFilter: mediaAssetsFileFilter,
        });
        this.router.post(
            "/upload-file/media-assets",
            mediaAssetsUpload.single("file"),
            (req, res, next) =>
                this.uploadFileController.mediaAssets(req, res, next).catch(next)
        );
        this.router.post(
            "/open-api/upload-file/media-assets",
            mediaAssetsUpload.single("file"),
            (req, res, next) =>
                this.uploadFileController.mediaAssets(req, res, next).catch(next)
        );
        this.router.post("/upload-file/delete-media-assets", (req, res, next) =>
            this.uploadFileController.deleteMediaAssets(req, res, next).catch(next)
        );

        function getFileName() {
            return function (req, file, cb) {
                const fileName = new Date().getTime();
                const fileExt = path.extname(file.originalname);
                cb(null, fileName + fileExt);
            };
        }

        // xlsx vendor file parser
        const xlsxVendorUploadDir = "./public/xlsx-vendor-import/";
        if (!fs.existsSync(xlsxVendorUploadDir)) {
            fs.mkdirSync(xlsxVendorUploadDir);
        }
        const xlsxVendorStorage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, xlsxVendorUploadDir);
            },
            filename: getFileName(),
        });
        const xlsxVendorFileFilter = (req, file, cb) => {
            cb(null, true);
        };
        const xlsxVendorUpload = multer({
            storage: xlsxVendorStorage,
            limits: {
                fileSize: 1024 * 1024 * 10,
            },
            fileFilter: xlsxVendorFileFilter,
        });
        this.router.post(
            "/upload-file/xlsx-vendor-data",
            xlsxVendorUpload.single("file"),
            (req, res, next) =>
                this.vendorController.xlsxBulkFile(req, res, next).catch(next)
        );
        this.router.post(
            "/upload-file/xlsx-vendor-column",
            xlsxVendorUpload.single("file"),
            (req, res, next) =>
                this.vendorController.xlsxColumn(req, res, next).catch(next)
        );


        // PDF language converter
        const pdfConverterDir = "./public/pdf-converter-files/";
        if (!fs.existsSync(pdfConverterDir)) {
            fs.mkdirSync(pdfConverterDir);
        }
        const pdfConverterStorage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, pdfConverterDir);
            },
            filename: getFileName(),
        });
        const pdfConverterFilter = (req, file, cb) => {
            cb(null, true);
        };
        const pdfConverterUpload = multer({
            storage: pdfConverterStorage,
            limits: {
                fileSize: 1024 * 1024 * 40,
            },
            fileFilter: pdfConverterFilter,
        });
        this.router.post(
            "/upload-file/pdf-converter-files",
            pdfConverterUpload.single("file"),
            (req, res, next) =>
                this.pdfFileLanguageConverter.pdfUpload(req, res, next).catch(next)
        );


        // Bulk Upload xlsx file
        const bulkUploadDir = "./public/bulk-upload-files/";
        if (!fs.existsSync(bulkUploadDir)) {
            fs.mkdirSync(bulkUploadDir);
        }
        const bulkUploadStorage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, bulkUploadDir);
            },
            filename: getFileName(),
        });
        const bulkUploadDirFilter = (req, file, cb) => {
            cb(null, true);
        };
        const bulkUploadUpload = multer({
            storage: bulkUploadStorage,
            limits: {
                fileSize: 1024 * 1024 * 40,
            },
            fileFilter: bulkUploadDirFilter,
        });
        this.router.post(
            "/upload-file/bulk-upload-file",
            bulkUploadUpload.single("file"),
            (req, res, next) => {
                if (req.body.tableName) {
                    this.bulkUploadController.dynamicTableBulkImport(req, res, next).catch(next)
                } else {
                    this.bulkUploadController.bulkUpload(req, res, next).catch(next)
                }
            }
        );

    }
}
