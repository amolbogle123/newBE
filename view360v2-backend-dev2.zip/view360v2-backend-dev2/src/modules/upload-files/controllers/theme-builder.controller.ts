import { Request, Response } from "express";
import fs from "fs";
import { CommonHelper, ApiErrorResponse } from "../../../utils/helpers/common.helper";

export class ThemeBuilderController {

    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    async themeBuilder(
        request: Request | any,
        response: Response,
        next: any
    ): Promise<any> {
        try {
            const apiResponse: any = {
                data: null,
                error: null,
            };

            if (request.file) {
                const uploadedFilePath =
                    request.file.destination + request.file.filename;

                if (fs.existsSync(uploadedFilePath)) {
                    apiResponse.data = {
                        filePath: request.file.path,
                        name: request.file.originalname,
                    };
                } else {
                    apiResponse.error = "Please try again";
                }
            } else {
                apiResponse.error = "Please upload file";
            }

            return CommonHelper.apiSuccessResponse(response, apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(response, apiErrorResponse);
        }
    }
}
