import { NextFunction, Request, Response } from "express";

export class PublicFileController {

    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    async downloadFile(
        request: Request | any,
        response: Response,
        next: NextFunction
    ) {
        const filename = request.params.filename;
        const folderName = request.params.folderName;

        const filePath = `./public/${folderName}/${filename}`;
        response.download(filePath);
    }
}
