import { NextFunction, Request, Response } from "express";
import fs from "fs";
import Container from "typedi";
import { DataSource } from "typeorm";

import { MediaAssets } from "../../../entities";
import { CommonHelper } from "../../../utils/helpers/common.helper";

export class UploadFileController {
    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    async base64Img(
        request: Request | any,
        response: Response,
        next: NextFunction
    ) {
        const apiResponse: any = {
            data: null,
            error: null,
        };

        if (!request.body.base64Data) {
            apiResponse.error = "Required field is missing";
            return CommonHelper.apiSuccessResponse(response, apiResponse);
        }

        let base64Data = request.body.base64Data.split(",");
        const type = request.body.base64Data.split(";")[0].split("/")[1];
        if (base64Data[1]) {
            apiResponse.data = {
                filePath: `./public/upload64-files/${new Date().getTime()}.${type}`,
            };
            const buffer = Buffer.from(base64Data[1], "base64");
            fs.writeFileSync(apiResponse.data.filePath, buffer);
        } else {
            apiResponse.error = "Required field is missing";
        }

        return CommonHelper.apiSuccessResponse(response, apiResponse);
    }

    async mediaAssets(
        request: Request | any,
        response: Response,
        next: NextFunction
    ) {
        const apiResponse: any = {
            data: null,
            error: null,
        };

        if (!request.file) {

            apiResponse.error = "Required field is missing";
            return CommonHelper.apiSuccessResponse(response, apiResponse);
        }
        
        const uploadedFilePath =
            request.file.destination + request.file.filename;

        if (fs.existsSync(uploadedFilePath)) {
            apiResponse.data = {
                filePath: request.file.path,
                name: request.file.originalname,
            };

            const mediaAssets = new MediaAssets();
            mediaAssets.fileName = request.file.originalname;
            mediaAssets.filePath = request.file.path;

            const result = await Container.get(DataSource).manager.save(mediaAssets);
            if (result) {
                apiResponse.data = result;
            }
        } else {
            apiResponse.error = "Please try again";
        }


        return CommonHelper.apiSuccessResponse(response, apiResponse);
    }
    async deleteMediaAssets(
        request: Request | any,
        response: Response,
        next: NextFunction
    ) {
        const apiResponse: any = {
            data: null,
            error: null,
        };

        if (!request.body.filePath) {
            apiResponse.error = "Required field is missing";
            return CommonHelper.apiSuccessResponse(response, apiResponse);
        }

        if (fs.existsSync(request.body.filePath)) {
            fs.unlinkSync(request.body.filePath);
            const mediaAssets = await Container.get(DataSource).manager.findOne(MediaAssets, {
                where: {
                    filePath: request.body.filePath,
                },
            });
            if (mediaAssets) {
                const result = await Container.get(DataSource).manager.delete(MediaAssets, mediaAssets);
                if (result) {
                    apiResponse.data = "Deleted successfully";
                }
            }
        } else {
            apiResponse.error = "Please try again";
        }

        return CommonHelper.apiSuccessResponse(response, apiResponse);
    }
}
