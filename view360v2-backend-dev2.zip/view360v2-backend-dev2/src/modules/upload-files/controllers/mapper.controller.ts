import { Request, Response } from "express";
import fs from "fs";
import XLSX from "xlsx";
import { CommonHelper, ApiErrorResponse } from "../../../utils/helpers/common.helper";
import { FileUploaderHelper } from "../utils/helpers/file-uploader.helper";

export class MapperController {

    static throwError(errorMessage: string): void {
        throw Error(errorMessage);
    }

    async xlsxMapper(
        request: Request | any,
        response: Response,
        next: any
    ): Promise<any> {
        try {
            const apiResponse: any = {
                data: null,
                error: null,
            };

            if (!request?.file) {
                apiResponse.error = "Please upload file";
                return CommonHelper.apiSuccessResponse(response, apiResponse);
            }
            const uploadedFilePath =
                request.file.destination + request.file.filename;

            if (!fs.existsSync(uploadedFilePath)) {
                apiResponse.error = "Please try again";
                return CommonHelper.apiSuccessResponse(response, apiResponse);
            }

            let fileData = [];
            const workSheetsFromFile = XLSX.readFile(
                `${request.file.destination}${request.file.filename}`,
                {
                    type: "binary",
                    cellDates: true,
                    cellNF: false,
                    cellText: false,
                }
            );
            const sheetnames = Object.keys(workSheetsFromFile.Sheets);

            for (let sheetname of sheetnames) {
                const fileDataInput = {
                    name: sheetname,
                    xlsxJson: [],
                };
                const xlsxJson = XLSX.utils.sheet_to_json(
                    workSheetsFromFile.Sheets[sheetname],
                    {
                        header: 1,
                    }
                );
                if (request.body.dataStartColumn) {
                    if (
                        xlsxJson.length &&
                        xlsxJson[request.body.dataStartColumn - 1] &&
                        Array.isArray(
                            xlsxJson[request.body.dataStartColumn - 1]
                        ) &&
                        xlsxJson[request.body.dataStartColumn - 1][0]
                    ) {
                        let xlsx: any =
                            xlsxJson[request.body.dataStartColumn - 1];
                            fileDataInput.xlsxJson = xlsx;
                    }
                }
                fileData.push(fileDataInput);
            } 
            apiResponse.data = {
                fileConfig: {
                    filePath: request.file.path,
                    name: request.file.originalname
                },
                xlsxData: fileData
            };

            return CommonHelper.apiSuccessResponse(response, apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(response, apiErrorResponse);
        }
    }

    async xlsxBulkFile(
        request: Request | any,
        response: Response,
        next: any
    ): Promise<any> {
        try {
            const apiResponse: any = {
                data: null,
                error: null,
            };

            if (request.file) {
                const uploadedFilePath =
                    request.file.destination + request.file.filename;

                if (fs.existsSync(uploadedFilePath)) {
                    let fileData = [];
                    const workSheetsFromFile = XLSX.readFile(
                        `${request.file.destination}${request.file.filename}`,
                        {
                            type: "binary",
                            cellDates: true,
                            cellNF: false,
                            cellText: false,
                        }
                    );
                    const sheetnames = Object.keys(workSheetsFromFile.Sheets);

                    for (let sheetname of sheetnames) {
                        var range = XLSX.utils.decode_range(
                            workSheetsFromFile.Sheets[sheetname]["!ref"]
                        );
                        if (request.body.columnHeader) {
                            range.s.r = request.body.columnHeader - 1;
                        }

                        var new_range = XLSX.utils.encode_range(range);
                        const xlsxJson = XLSX.utils
                            .sheet_to_json(
                                workSheetsFromFile.Sheets[sheetname],
                                {
                                    range: new_range,
                                    blankrows: false,
                                    raw: false,
                                    dateNF: 'm"/"d"/"yyyy',
                                }
                            )
                            .map((row) =>
                                Object.keys(row).reduce((obj, key) => {
                                    obj[key.trim()] = row[key];
                                    return obj;
                                }, {})
                            );
                        fileData.push({
                            name: sheetname,
                            xlsxJson,
                        });
                    }

                    apiResponse.data = fileData;
                } else {
                    apiResponse.error = "Please try again";
                }
            } else {
                apiResponse.error = "Please upload file";
            }

            return CommonHelper.apiSuccessResponse(response, apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(response, apiErrorResponse);
        }
    }

    async pdfMapper(
        request: Request | any,
        response: Response,
        next: any
    ): Promise<any> {
        try {
            const apiResponse: any = {
                data: null,
                error: null,
            };
            
            if (request.file) {
                const uploadedFilePath =
                    request.file.destination + request.file.filename;

                if (fs.existsSync(uploadedFilePath)) {
                    apiResponse.data = [];
                    let result = await FileUploaderHelper.parsePdf(uploadedFilePath, request.file);
                    if (result?.status && result?.data) {
                        apiResponse.data = result.data;
                        apiResponse.data['fileConfig'] = {
                            filePath: request.file.path,
                            name: request.file.originalname
                        };
                    }
                } else {
                    apiResponse.error = "Please try again";
                }
            } else {
                apiResponse.error = "Please upload file";
            }

            return CommonHelper.apiSuccessResponse(response, apiResponse);
        } catch (err) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (err as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(response, apiErrorResponse);
        }
    }
}
