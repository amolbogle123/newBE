import fs from 'fs';
import { Body, Controller, Get, Hidden, Path, Post, Request, Route, Security, Tags } from "tsoa";
import Container from 'typedi';
import { DataSource } from 'typeorm';
import { dataSource } from "../../../core/data-source";
import { MigratorData, MigratorDataHistory, WidgetAccount } from "../../../entities";
import { ConnectorsUtil } from "../../../utils/connectors.util";
import { ApiErrorResponse, CommonHelper } from "../../../utils/helpers/common.helper";
import { DatabaseListResponse, ExecuteMigratorRequest, ExecuteMigratorResponse, ReadFileResponse } from "../doc/migrator-interface";
import { ExecuteMigrator } from "../utils/executeMigrator.util";

@Route('')
@Tags('Data Migration/Configurer')
export class MigratorConfigController extends Controller {

    @Security('bearerAuth')
    @Get('migrator-config/database/:accountId')
    @Hidden()
    async getDatabase(
        @Request() req: any,
        @Path() accountId: string
    ) : Promise<DatabaseListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };

            let connectors;
            connectors = await dataSource.getRepository(WidgetAccount).findOneBy({
                id: accountId
            });
            if (connectors) { 
                let widgetConfig: any = connectors.config ? JSON.parse(connectors.config) : {};
                if (widgetConfig?.dbType === 'MYSQL') {
                    const query = "SHOW DATABASES;";
                    const mysqlData: any = await ConnectorsUtil.connect(null, query, widgetConfig);
                    if (mysqlData.status) {
                        apiResponse.data = mysqlData.data;
                    }
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('migrator-config/tables/:accountId/:databaseName')
    @Hidden()
    async getDatabaseTables(
        @Request() req: any,
        @Path() accountId: string,
        @Path() databaseName: string
    ) : Promise<DatabaseListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };

            let connectors;
            connectors = await dataSource.getRepository(WidgetAccount).findOneBy({
                id: accountId
            });
            if (connectors) { 
                let widgetConfig: any = connectors.config ? JSON.parse(connectors.config) : {};
                if (widgetConfig?.dbType === 'MYSQL') {
                    const query = `SELECT table_name as 'TABLE_NAME' FROM information_schema.tables WHERE table_schema = '${databaseName}'`;
                    const mysqlData: any = await ConnectorsUtil.connect(null, query, widgetConfig);
                    if (mysqlData.status) {
                        apiResponse.data = mysqlData.data;
                    }
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('migrator-config/table-details/:accountId/:databaseName/:tableName')
    @Hidden()
    async getTableDetails(
        @Request() req: any,
        @Path() accountId: string,
        @Path() databaseName: string,
        @Path() tableName: string
    ) : Promise<DatabaseListResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            let connectors;
            connectors = await dataSource.getRepository(WidgetAccount).findOneBy({
                id: accountId
            });
            if (connectors) { 
                let widgetConfig: any = connectors.config ? JSON.parse(connectors.config) : {};
                if (widgetConfig?.dbType === 'MYSQL') {
                    const query = `SELECT CONCAT(column_name, ' (', data_type, ')') as 'COLUMN_NAME', column_name, data_type FROM information_schema.columns WHERE table_schema = '${databaseName}' AND table_name = '${tableName}'`;
                    const mysqlData: any = await ConnectorsUtil.connect(null, query, widgetConfig);
                    if (mysqlData.status) {
                        apiResponse.data['allColumns'] = mysqlData.data;
                    }

                    // const countQuery = `SELECT COUNT(id) FROM '${tableName}'`;
                    // const mysqlCountData: any = await ConnectorsUtil.connect(null, countQuery, widgetConfig);
                    // console.log('mysqlCountData', mysqlCountData);
                    // if (mysqlCountData.status) {
                    //     apiResponse.data['totalRows'] = mysqlCountData.data;
                    // }
                }
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('migrator-config/check-table-name/:accountId/:databaseName/:tableName')
    @Hidden()
    async checkTableName(@Request() req: any,
    @Path() accountId: string,
    @Path() databaseName: string,
    @Path() tableName: string
) : Promise<DatabaseListResponse | unknown> {
    try {
        const apiResponse = {
            data: {},
        };
        if(accountId == 'View360'){
            if(await this.checkTableExists(tableName)){
                apiResponse.data = [{
                    TABLE_NAME: tableName
                }];
            }
        }
        
        let connectors = await dataSource.getRepository(WidgetAccount).findOneBy({
            id: accountId
        });
        if (!connectors) { 
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        }

        let widgetConfig: any = connectors.config ? JSON.parse(connectors.config) : {};
        if (widgetConfig?.dbType === 'MYSQL') {
            const query = `SELECT table_name as 'TABLE_NAME' FROM information_schema.tables WHERE table_schema = '${databaseName}' AND table_name = '${tableName}'`;
            const mysqlData: any = await ConnectorsUtil.connect(null, query, widgetConfig);
            if (mysqlData.status) {
                apiResponse.data = mysqlData.data;
            }
        } else if(widgetConfig.dbType === 'MSSQL') {
            const query = `SELECT table_name as 'TABLE_NAME' FROM information_schema.tables WHERE table_schema = '${databaseName}' AND table_name = '${tableName}'`;
            const mysqlData: any = await ConnectorsUtil.connect(null, query, widgetConfig);
            if (mysqlData.status) {
                apiResponse.data = mysqlData.data;
            }
        }

        return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
    } catch (error) {
        const apiErrorResponse: ApiErrorResponse = {
            error: {
                error_description: (error as Error).message,
            },
        };
        this.setStatus(500);
        return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
    }
}

async  checkTableExists(tableName: string): Promise<boolean> {
    const connection = dataSource.manager.connection;
    let database=dataSource.manager.connection.options.database;
    const queryRunner = connection.createQueryRunner();
    
    const tableExistsQuery = `SELECT table_name as 'TABLE_NAME' FROM information_schema.tables WHERE table_schema = '${database}' AND table_name = '${tableName}'`;
    const result = await queryRunner.query(tableExistsQuery);
    await queryRunner.release();
    return result.length > 0 ? true : false;
}

    @Security('bearerAuth')
    @Post('migrator-config/execute/:id')
    @Hidden()
    async saveMigrator(
        @Path() id: string,
        @Body() requestBody: ExecuteMigratorRequest,
        @Request() request: any
    ) : Promise<ExecuteMigratorResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            const result: any = await dataSource
                .getRepository(MigratorData)
                .findOne({
                    where: {
                        id: id,
                        clientId: request.userDetails.client_id,
                    },
                });
            if (result?.config) {
                const migratorDataModel = new MigratorDataHistory();
                migratorDataModel.clientId = request.userDetails.client_id;
                migratorDataModel.migrationId = id;
                migratorDataModel.config = result.config;
                migratorDataModel.executionConfig = JSON.stringify(requestBody.executionConfig);
                migratorDataModel.name = requestBody.name;
                migratorDataModel.status = 'initiateProcess';
                migratorDataModel.createdBy = request.userDetails.id;

                const historyResult = await Container.get(DataSource).manager.save(
                    migratorDataModel
                );
                if (historyResult?.id) {
                    apiResponse.data = { insertedId: historyResult.id };
                    
                    // TO_DO: start to schedule
                    executeMigrator(historyResult.id, result.config, requestBody, request.userDetails.client_id);

                    this.setStatus(201);
                }
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('migrator-config/read-xlsx-file/:fileName')
    @Hidden()
    async readXlsxFile(
        @Request() req: any,
        @Path() fileName: string
    ) : Promise<ReadFileResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
            };

            const fileData = fs.readFileSync(`./public/json-data-migration/${fileName}`, {encoding: 'utf-8'});
            if (fileData) { console.log('fileData', fileData);
                apiResponse.data = JSON.parse(fileData);
            }
            
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) { console.log('error', error);
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}

function executeMigrator(id, configResult, requestBody, client_id) {
    return new Promise(async (resolve) => {
        let payload: any = { status: 'failedProcess' };
        try {
            const config = JSON.parse(configResult);
            const executeMigratorResult = await ExecuteMigrator.execute(config, requestBody.executionConfig, client_id);
            if (executeMigratorResult) {
                payload.status = 'completedProcess';
               await dataSource.getRepository(MigratorDataHistory).update({ id: id }, payload);
            }
            resolve(true);
        } catch (error) {
            await dataSource.getRepository(MigratorDataHistory).update({ id: id }, payload);
            resolve(null);
        }
    });
}