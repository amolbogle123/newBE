import { Body, Controller, Delete, Get, Path, Post, Put, Query, Request, Route, Security, Tags } from "tsoa";
import Container from 'typedi';
import { DataSource } from 'typeorm';
import { CommonUtil } from "utils/common.util";
import { dataSource } from "../../../core/data-source";
import { MigratorData, MigratorDataHistory } from "../../../entities";
import dbService from "../../../services/db.service";
import { ApiErrorResponse, CommonHelper } from "../../../utils/helpers/common.helper";
import { DatabaseListResponse, DeleteMigrator, DeleteMigratorResponse, InsertMigratorRequest, MigratorDetailsResponse, SaveMigratorResponse, UpdateMigratorRequest, UpdateMigratorResponse } from "../doc/migrator-interface";

@Route('')
@Tags('Data Migration/CRUD')
export class MigratorCrudController extends Controller {

    @Security('bearerAuth')
    @Get('data-migrator')
    async getMigratorList(
        @Request() request: any,
        @Query('page') page: number = 1,
        @Query('pageSize') pageSize: number = 10,
        @Query('sortOrder') sortOrder?: number,
        @Query('sortField') sortField?: string,
        @Query('filters') filters?: string
    ): Promise<DatabaseListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };
            let whereCondition = { clientId: request.userDetails.client_id };

            whereCondition = await CommonUtil.applyFilter(filters, whereCondition);

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject['email'] = sortOrder;
            }


            const totalRecordCount = await Container.get(DataSource)
                .getRepository(MigratorData)
                .createQueryBuilder("m")
                .where("m.clientId = :clientId", { clientId: request.userDetails.client_id })
                .getCount();

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MigratorData),
                {
                    where: whereCondition,  // Use queryObj directly instead of spreading it
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                },
            );

            if (results?.length > 0) {
                apiResponse.data = [];
                
                for (let r of results) {
                    r['isMigrationProcess'] = false;
                    let result: any = await dataSource.getRepository(MigratorDataHistory).find({
                        where: {
                            migrationId: r.id,
                            clientId: request.userDetails.client_id,
                        },
                    });
                    if (result?.length) {
                        const findProcess = result.find((p) => ['completedProcess','failedProcess'].indexOf(p.status) === -1);
                        if (findProcess) {
                            r['isMigrationProcess'] = true;
                        }
                    }
                    apiResponse.data.push(r);
                }

                apiResponse.recordsTotal = totalRecordCount;
                apiResponse.recordsFiltered = totalRecordCount;
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('data-migrator/history/:id')
    async getMigratorHistoryList(
        @Request() request: any,
        @Path() id: string,
        @Query('page') page: number = 1,
        @Query('pageSize') pageSize: number = 10,
        @Query('sortOrder') sortOrder?: number,
        @Query('sortField') sortField?: string,
        @Query('filters') filters?: string
    ): Promise<DatabaseListResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
            };
            let whereCondition = { clientId: request.userDetails.client_id, migrationId: id };

            whereCondition = await CommonUtil.applyFilter(filters, whereCondition);

            // Apply sorting if sortOrder and sortField are provided
            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject['createdOn'] = sortOrder;
            }

            const totalRecordCount = await Container.get(DataSource).getRepository(MigratorDataHistory)
                .createQueryBuilder("m")
                .where("m.clientId = :clientId AND m.migrationId = :migrationId", { clientId: request.userDetails.client_id, migrationId: id })
                .getCount();
                
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(MigratorDataHistory),
                {
                    where: whereCondition,  // Use queryObj directly instead of spreading it
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                },
            );

            if (results?.length > 0) {
                apiResponse.data = results;

                apiResponse.recordsTotal = totalRecordCount;
                apiResponse.recordsFiltered = totalRecordCount;
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Post('data-migrator')
    async saveMigrator(
        @Body() requestBody: InsertMigratorRequest,
        @Request() request: any
    ): Promise<SaveMigratorResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            const migratorDataModel = new MigratorData();
            migratorDataModel.clientId = request.userDetails.client_id;
            migratorDataModel.config = JSON.stringify(requestBody.config);
            migratorDataModel.name = requestBody.name;
            migratorDataModel.createdBy = request.userDetails.id;

            const result = await Container.get(DataSource).manager.save(
                migratorDataModel
            );
            if (result?.id) {
                apiResponse.data = { insertedId: result.id };
                this.setStatus(201);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Get('data-migrator/:id')
    async getMigrator(
        @Path() id: string,
        @Request() request: any
    ): Promise<MigratorDetailsResponse | unknown> {
        try {
            const apiResponse = {
                data: null,
            };
            let result: any = await dataSource
                .getRepository(MigratorData)
                .findOne({
                    where: {
                        id: id,
                        clientId: request.userDetails.client_id,
                    },
                });
            apiResponse.data = result;

            if (apiResponse.data) {
                if (apiResponse.data["config"]) {
                    apiResponse.data["config"] = JSON.parse(
                        apiResponse.data["config"]
                    );
                } else {
                    apiResponse.data["config"] = {};
                }
            } else {
                this.setStatus(204);
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Put('data-migrator/:id')
    async updateMigrator(
        @Path() id: string,
        @Body() requestBody: UpdateMigratorRequest,
        @Request() request: any
    ): Promise<UpdateMigratorResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            const payload = {
                name: request.body.name,
                config: JSON.stringify(request.body.config)
            };

            const updateResult = await dataSource
                .getRepository(MigratorData)
                .update({ id: request.params.id }, payload);
            apiResponse.data = updateResult;

            if (!updateResult?.affected) {
                this.setStatus(204);
            } else {
                this.setStatus(200);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security('bearerAuth')
    @Delete('data-migrator')
    async deleteMigrator(
        @Body() requestBody: DeleteMigrator,
        @Request() request: any
    ): Promise<DeleteMigratorResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            const widgetResult = await dataSource
                .getRepository(MigratorData)
                .delete(requestBody.id);
            apiResponse.data = widgetResult;

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
