export interface ReadFileResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DatabaseListResponse {
    status: boolean;
    data?: any;
    message?: string;
    recordsTotal?: number;
    recordsFiltered?: number;
}

export interface InsertMigratorRequest {
    name: string;
    config: any;
}

export interface UpdateMigratorRequest {
    name: string;
    config: any;
}

export interface UpdateMigratorResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DeleteMigrator {
    id: string[];
}

export interface SaveMigratorResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface MigratorDetailsResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface DeleteMigratorResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface ExecuteMigratorRequest {
    name: string;
    executionConfig: any;
}

export interface ExecuteMigratorResponse {
    status: boolean;
    data?: any;
    message?: string;
}