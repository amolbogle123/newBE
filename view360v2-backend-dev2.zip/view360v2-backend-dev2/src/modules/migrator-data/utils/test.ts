let a=[
    {
      title: "12345.json",
      isConfigured: true,
      dataType: null,
      dataSets: null,
      dataSetDetails: {
        totalColumns: [
          {
            id: "tab0-0",
            name: "sheet 1",
            headers: [
              {
                isSelected: true,
                COLUMN_NAME: "1",
              },
              {
                isSelected: true,
                COLUMN_NAME: "2",
              },
              {
                isSelected: true,
                COLUMN_NAME: "3",
              },
              {
                isSelected: true,
                COLUMN_NAME: "4",
              },
            ],
            rows: [
              [
                "data of 1",
                "data of 2",
                "data of 3",
                "data of 4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
            ],
          },
          {
            id: "tab0-1",
            name: "sheet 2",
            headers: [
              {
                isSelected: true,
                COLUMN_NAME: "1",
              },
              {
                isSelected: true,
                COLUMN_NAME: "2",
              },
              {
                isSelected: true,
                COLUMN_NAME: "3",
              },
              {
                isSelected: true,
                COLUMN_NAME: "4",
              },
            ],
            rows: [
              [
                "data of 1",
                "data of 2",
                "data of 3",
                "data of 4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
            ],
          },
        ],
      },
      destinationDetails: {
        isCreatedNew: "yes",
        tableName: null,
        database: "View360",
        sheets: [
          {
            id: "tab0-0",
            name: "sheet 1",
            tableName: "table1",
          },
          {
            id: "tab0-1",
            name: "sheet 2",
            tableName: "table2",
          },
        ],
      },
      filter: [
      ],
    },
    {
      title: "12345.json",
      isConfigured: true,
      dataType: null,
      dataSets: null,
      dataSetDetails: {
        totalColumns: [
          {
            id: "tab1-0",
            name: "sheet 1",
            headers: [
              {
                isSelected: true,
                COLUMN_NAME: "1",
              },
              {
                isSelected: true,
                COLUMN_NAME: "2",
              },
              {
                isSelected: true,
                COLUMN_NAME: "3",
              },
              {
                isSelected: true,
                COLUMN_NAME: "4",
              },
            ],
            rows: [
              [
                "data of 1",
                "data of 2",
                "data of 3",
                "data of 4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
            ],
          },
          {
            id: "tab1-1",
            name: "sheet 2",
            headers: [
              {
                isSelected: true,
                COLUMN_NAME: "1",
              },
              {
                isSelected: true,
                COLUMN_NAME: "2",
              },
              {
                isSelected: true,
                COLUMN_NAME: "3",
              },
              {
                isSelected: true,
                COLUMN_NAME: "4",
              },
            ],
            rows: [
              [
                "data of 1",
                "data of 2",
                "data of 3",
                "data of 4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
              [
                "1",
                "2",
                "3",
                "4",
              ],
            ],
          },
        ],
      },
      destinationDetails: {
        isCreatedNew: "yes",
        tableName: null,
        database: "View360",
        sheets: [
          {
            id: "tab1-0",
            name: "sheet 1",
            tableName: "table3",
          },
          {
            id: "tab1-1",
            name: "sheet 2",
            tableName: "table4",
          },
        ],
      },
      filter: [
      ],
    },
  ]
  