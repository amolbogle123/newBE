import { dataSource } from "../../../core/data-source";
import { PublicTables, WidgetAccount } from "../../../entities";
import { ConnectorsUtil } from "../../../utils/connectors.util";

import fs from "fs";
import Container from "typedi";
import { DataSource } from "typeorm";
import { OpenSearchExecutor } from "../../connectors/executor-utils/openSearchExecutor.util";
import { SplunkExecutor } from "../../connectors/executor-utils/splunkExecutor.util";

export class ExecuteMigrator {
    static migration_id: string;
    static async execute(config, executionConfig, client_id?: number) {
        try {
            this.migration_id = await this.GetUUID();
            let i = 0;
            for (let source of config.sourceList) {
                let skipConnectorFile = null;
                let sheetExecutionConfig = null;
                console.log(
                    "executionConfig",
                    JSON.stringify(executionConfig, null, 2)
                );
                if (
                    executionConfig?.fileList?.length &&
                    executionConfig.fileList[i]?.sheets?.length
                ) {
                    sheetExecutionConfig = executionConfig.fileList[i].sheets;

                    if (executionConfig.fileList[i]?.fileUrl) {
                        skipConnectorFile =
                            executionConfig.fileList[i]?.fileUrl;
                    }
                }
                console.log(
                    "sheetExecutionConfig",
                    skipConnectorFile,
                    JSON.stringify(sheetExecutionConfig, null, 2)
                );
                if (
                    source?.isConfigured &&
                    //source?.dataType &&
                    //source?.dataSets &&
                    (source?.destinationDetails?.database ||
                        config.sourceConnectorType === "XLSX") && // TO_DO: un-comment in mysql
                    //source?.destinationDetails?.tableName &&
                    source?.dataSetDetails?.totalColumns?.length
                ) {
                    if (config.sourceConnectorType === "XLSX") {
                        for (let [
                            index,
                            sheet,
                        ] of source.dataSetDetails.totalColumns.entries()) {
                            let extraConfig = null;
                            if (
                                sheetExecutionConfig?.length &&
                                sheetExecutionConfig[index]
                            ) {
                                extraConfig = sheetExecutionConfig[index];
                            }
                            const columnList = sheet.headers
                                .filter((c) => c?.isSelected && c?.COLUMN_NAME)
                                .map((c) => {
                                    return {
                                        columnName: c?.COLUMN_NAME,
                                        mappedColumn:
                                            source.destinationDetails
                                                .isCreatedNew == "yes"
                                                ? c?.COLUMN_NAME
                                                : c?.mappedColumn || null,
                                    };
                                });
                            const sourceDetails = {
                                fileIndex: i,
                                sheetIndex: index,
                                connectorId: config.sourceConnector,
                                connectorType: config.sourceConnectorType,
                                database: source?.dataType,
                                table: sheet.sheetName,
                                filter: null,
                            };
                            const destiDetails = {
                                connectorId: config.destiConnector,
                                connectorType: config.destiConnectorType,
                                database: source?.destinationDetails?.database,
                                table: source.destinationDetails.sheets[index]
                                    .tableName,
                            };
                            await this.insertData(
                                source?.destinationDetails?.isCreatedNew ===
                                    "yes",
                                sourceDetails,
                                destiDetails,
                                columnList,
                                client_id,
                                extraConfig,
                                skipConnectorFile
                            );
                        }
                    } else {
                        const columnList = source.dataSetDetails.totalColumns
                            .filter((c) => c?.isSelected && c?.COLUMN_NAME)
                            .map((c) => {
                                return {
                                    columnName: c?.COLUMN_NAME,
                                    mappedColumn:
                                        source.destinationDetails
                                            .isCreatedNew == "yes"
                                            ? c?.COLUMN_NAME
                                            : c?.mappedColumn || null,
                                };
                            });

                        const sourceDetails = {
                            connectorId: config.sourceConnector,
                            connectorType: config.sourceConnectorType,
                            database: source?.dataType,
                            table: source?.dataSets,
                            filter: source?.filter,
                        };
                        const destiDetails = {
                            connectorId: config.destiConnector,
                            connectorType: config.destiConnectorType,
                            database: source?.destinationDetails?.database,
                            table: source?.destinationDetails?.tableName,
                        };
                        await this.insertData(
                            source?.destinationDetails?.isCreatedNew === "yes",
                            sourceDetails,
                            destiDetails,
                            columnList,
                            null,
                            null,
                            skipConnectorFile
                        );
                    }
                }
                i += 1;
            }
            return true;
        } catch (error) {
            console.error(error);
            throw error;
        }
    }

    private static async insertData(
        isNewEntry,
        sourceDetails,
        destiDetails,
        columnList,
        client_id?: number,
        extraConfig: any = null,
        skipConnectorFile = null
    ) {
        const dataList = await this.getSourceData(
            sourceDetails,
            columnList,
            skipConnectorFile
        );
        if (isNewEntry) {
            await this.insertDestinationData(
                sourceDetails,
                destiDetails,
                columnList,
                dataList,
                client_id,
                extraConfig
            );
        } else {
            await this.updateDestinationData(
                sourceDetails,
                destiDetails,
                columnList,
                dataList,
                extraConfig
            );
        }
    }

    private static async getSourceData(
        sourceDetails,
        columnList,
        skipConnectorFile = null
    ) {
        let response = [];
        if (sourceDetails?.connectorType === "SPLUNK") {
            let splunkResponse = null;
            switch (sourceDetails.database) {
                case "app":
                    splunkResponse = await SplunkExecutor.getAppList(
                        sourceDetails.connectorId
                    );
                    break;
                case "dashboards":
                    splunkResponse = await SplunkExecutor.getAppList(
                        sourceDetails.connectorId
                    );
                    break;
                case "datasets":
                    splunkResponse = await SplunkExecutor.getDatasetList(
                        sourceDetails.connectorId
                    );
                    break;
                case "indexes":
                    splunkResponse = await SplunkExecutor.searchIndexData(
                        sourceDetails.connectorId,
                        sourceDetails.table,
                        sourceDetails.filter,
                        {}
                    );
                    break;
            }
            if (splunkResponse?.status) {
                response = splunkResponse.data;
            }
        } else if (sourceDetails?.connectorType === "OPEN_SEARCH") {
            let openSearchResponse: any =
                await OpenSearchExecutor.searchIndexData(
                    sourceDetails.connectorId,
                    sourceDetails.table,
                    sourceDetails.filter,
                    {}
                );
            if (
                openSearchResponse?.status &&
                openSearchResponse?.data?.list?.length
            ) {
                response = openSearchResponse.data.list;
            }
        } else if (["MYSQL"].indexOf(sourceDetails?.connectorType) > -1) {
            let connectors: any = await dataSource
                .getRepository(WidgetAccount)
                .findOneBy({ id: sourceDetails.connectorId });
            if (connectors) {
                let widgetConfig: any = connectors.config
                    ? JSON.parse(connectors.config)
                    : {};
                if (sourceDetails?.connectorType === "MYSQL") {
                    widgetConfig.dbName = sourceDetails.database;

                    const query = `SELECT ${columnList
                        .map((c) => `\`${c?.columnName}\``)
                        .join(",")} FROM \`${sourceDetails.table}\``;
                    const mysqlData: any = await ConnectorsUtil.connect(
                        null,
                        query,
                        widgetConfig
                    );
                    if (mysqlData.status) {
                        response = mysqlData.data;
                    }
                }
            }
        } else if (["XLSX"].indexOf(sourceDetails?.connectorType) > -1) {
            let fileUrl = skipConnectorFile;
            if (!skipConnectorFile) {
                let connectors: any = await dataSource
                    .getRepository(WidgetAccount)
                    .findOneBy({ id: sourceDetails.connectorId });
                if (connectors) {
                    let widgetConfig: any = connectors.config
                        ? JSON.parse(connectors.config)
                        : {};
                    if (widgetConfig?.files?.length && widgetConfig.files[sourceDetails?.fileIndex]?.jsonFile) {
                        fileUrl = widgetConfig.files[sourceDetails.fileIndex].jsonFile;
                    }
                }
            }

            if (fileUrl) {
                let fileData: any = fs.readFileSync(`public/json-data-migration/${fileUrl}`, {encoding: 'utf-8'});
                fileData = fileData ? JSON.parse(fileData) : [];
                if (fileData && fileData[sourceDetails?.sheetIndex]?.rows?.length) {
                    response = fileData[sourceDetails.sheetIndex].rows.map((str) => JSON.parse(str));
                }
            }
        }

        return response;
    }

    private static async formatDataList(dataList, columnList, defaultValue) {
        let response = [];
        if (dataList?.length) {
            response = dataList.map((d) => {
                let formatData = Object.assign({}, defaultValue);
                for (let c of columnList) {
                    if (c?.mappedColumn) {
                        formatData[c?.mappedColumn] = d[c.columnName];
                    } else if (c?.columnName) {
                        formatData[c?.columnName] = d[c.columnName];
                    }
                }
                return formatData;
            });
        }
        return response;
    }

    private static async getSelectedRows(selectRows) {
        let ids = [];
        if (selectRows) {
            const idsSplit = selectRows?.split(",").map((id) => id.trim());
            for (let id of idsSplit) {
                if (id.includes(":")) {
                    const idRange = id.split(":").map((i) => i.trim());
                    for (
                        let i = parseInt(idRange[0]);
                        i <= parseInt(idRange[1]);
                        i++
                    ) {
                        ids.push(i);
                    }
                } else {
                    ids.push(parseInt(id));
                }
            }
        }
        return ids;
    }

    private static async insertDestinationData(
        sourceDetails,
        destiDetails,
        columnList,
        dataList,
        client_id?: number,
        extraConfig: any = null
    ) {
        if (dataList?.length) {
            if (extraConfig?.selectRows) {
                const selectedRows = await this.getSelectedRows(
                    extraConfig.selectRows
                );
                if (selectedRows?.length) {
                    dataList = dataList.filter((d, k) =>
                        selectedRows.includes(k + 1)
                    );
                }
            }
            console.log("destiDetails", destiDetails);
            if (destiDetails?.connectorType === "OPEN_SEARCH") {
                const craeteIndex: any = await OpenSearchExecutor.createIndex(
                    destiDetails.connectorId,
                    destiDetails.table
                );
                if (craeteIndex?.status) {
                    const formatedDataList = await this.formatDataList(
                        dataList,
                        columnList,
                        {}
                    );
                    await OpenSearchExecutor.createBulkIndex(
                        destiDetails.connectorId,
                        destiDetails.table,
                        formatedDataList
                    );
                }
            } else if (["SPLUNK"].indexOf(destiDetails?.connectorType) > -1) {
                const craeteIndex: any = { status: true }; // await SplunkExecutor.createIndex(destiDetails.connectorId, destiDetails.table);
                if (craeteIndex?.status) {
                    const formatedDataList = await this.formatDataList(
                        dataList,
                        columnList,
                        {}
                    );
                    await SplunkExecutor.createBulkIndex(
                        destiDetails.connectorId,
                        destiDetails.table,
                        formatedDataList
                    );
                }
            } else if (["MYSQL"].indexOf(destiDetails?.connectorType) > -1) {
                let connectors: any = await dataSource
                    .getRepository(WidgetAccount)
                    .findOneBy({ id: destiDetails.connectorId });
                if (connectors) {
                    let widgetConfig: any = connectors.config
                        ? JSON.parse(connectors.config)
                        : {};

                    if (destiDetails?.connectorType === "MYSQL") {
                        widgetConfig.dbName = destiDetails.database;

                        for (const [dindex, d] of dataList.entries()) {
                            let formatDataList = [];
                            for (const [cindex, c] of columnList.entries()) {
                                let formatData = {
                                    columnName: c?.mappedColumn,
                                    columnValue: null,
                                };
                                if (sourceDetails?.connectorType === "XLSX") {
                                    formatData.columnValue = d[cindex];
                                } else {
                                    if (c?.columnName && d[c?.columnName]) {
                                        formatData.columnValue =
                                            d[c.columnName];
                                    }
                                }
                                formatDataList.push(formatData);
                            }
                            if (dindex === 0) {
                                //create table
                                let columnsString = columnList
                                    .map(
                                        (column) =>
                                            `\`${column.mappedColumn}\` text`
                                    )
                                    .join(", ");
                                let createTableQuery = `CREATE TABLE \`${destiDetails.table}\` (\`id\` INT AUTO_INCREMENT NOT NULL, ${columnsString}, PRIMARY KEY (\`id\`))`;
                                let res: any = await ConnectorsUtil.connect(
                                    null,
                                    createTableQuery,
                                    widgetConfig
                                );
                                if (!res.status) {
                                    throw new Error(res.message);
                                }
                            }
                            const query =
                                "INSERT INTO `" +
                                destiDetails.table +
                                "` (`" +
                                formatDataList
                                    .map((c) => c.columnName)
                                    .join("`,`") +
                                "`) VALUES ('" +
                                formatDataList
                                    .map((c) => c.columnValue)
                                    .join("','") +
                                "');";
                            console.log("query insert", query);
                            let connectRes: any = await ConnectorsUtil.connect(
                                null,
                                query,
                                widgetConfig
                            );
                            if (!connectRes.status) {
                                throw new Error(connectRes.message);
                            }
                        }
                    }
                }
            } else if (["View360"].indexOf(destiDetails?.connectorType) > -1) {
                await this.createNewTable(
                    destiDetails.table,
                    dataSource,
                    columnList
                );
                await this.insertDataToTable(
                    destiDetails.table,
                    dataSource,
                    columnList,
                    dataList
                );
                await this.insertTableEntryInPublicTables(
                    destiDetails.table,
                    dataSource,
                    client_id
                );
            }
        }
    }

    private static async updateDestinationData(
        sourceDetails,
        destiDetails,
        columnList,
        dataList,
        extraConfig
    ) {
        if (dataList?.length) {
            if (extraConfig?.selectRows) {
                const selectedRows = await this.getSelectedRows(
                    extraConfig.selectRows
                );
                if (selectedRows?.length) {
                    dataList = dataList.filter((d, k) =>
                        selectedRows.includes(k + 1)
                    );
                }
            }

            if (destiDetails?.connectorType === "OPEN_SEARCH") {
                let allColumn = {};
                const allColumnResult: any =
                    await OpenSearchExecutor.getIndexColumn(
                        destiDetails.connectorId,
                        destiDetails.table
                    );
                if (allColumnResult?.status && allColumnResult?.data) {
                    Object.keys(allColumnResult.data).forEach((v) => {
                        allColumn[v] = "";
                    });
                }
                const formatedDataList = await this.formatDataList(
                    dataList,
                    columnList,
                    allColumn
                );
                await OpenSearchExecutor.createBulkIndex(
                    destiDetails.connectorId,
                    destiDetails.table,
                    formatedDataList
                );
            } else if (destiDetails?.connectorType === "MYSQL") {
                let connectors: any = await dataSource
                    .getRepository(WidgetAccount)
                    .findOneBy({ id: destiDetails.connectorId });
                if (connectors) {
                    let widgetConfig: any = connectors.config
                        ? JSON.parse(connectors.config)
                        : {};

                    if (destiDetails?.connectorType === "MYSQL") {
                        widgetConfig.dbName = destiDetails.database;

                        for (const [dindex, d] of dataList.entries()) {
                            let formatDataList = [];
                            for (const [cindex, c] of columnList.entries()) {
                                let formatData = {
                                    columnName: c?.mappedColumn,
                                    columnValue: null,
                                };
                                if (sourceDetails?.connectorType === "XLSX") {
                                    formatData.columnValue = d[cindex];
                                } else {
                                    if (c?.columnName && d[c?.columnName]) {
                                        formatData.columnValue =
                                            d[c.columnName];
                                    }
                                }
                                formatDataList.push(formatData);
                            }

                            if (
                                extraConfig?.operationType === "update" &&
                                extraConfig?.whereColumn
                            ) {
                                let findWhereValue = formatDataList.find(
                                    (c) =>
                                        c.columnName === extraConfig.whereColumn
                                );
                                if (findWhereValue) {
                                    let columnValue =
                                        findWhereValue?.columnValue || "";
                                    const query =
                                        "UPDATE `" +
                                        destiDetails.table +
                                        "` SET " +
                                        formatDataList
                                            .map(
                                                (c) =>
                                                    `\`${c.columnName}\` = '${c.columnValue}'`
                                            )
                                            .join(", ") +
                                        " WHERE `" +
                                        extraConfig.whereColumn +
                                        "` = '" +
                                        columnValue +
                                        "';";
                                    console.log("query", query);
                                    let res: any = await ConnectorsUtil.connect(
                                        null,
                                        query,
                                        widgetConfig
                                    );
                                    if (!res.status) {
                                        throw new Error(res.message);
                                    }
                                }
                            } else {
                                const query =
                                    "INSERT INTO `" +
                                    destiDetails.table +
                                    "` (`" +
                                    formatDataList
                                        .map((c) => c.columnName)
                                        .join("`,`") +
                                    "`) VALUES ('" +
                                    formatDataList
                                        .map((c) => c.columnValue)
                                        .join("','") +
                                    "');";
                                console.log("query", query);
                                let res: any = await ConnectorsUtil.connect(
                                    null,
                                    query,
                                    widgetConfig
                                );
                                if (!res.status) {
                                    throw new Error(res.message);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    private static async createNewTable(
        tableName: string,
        AppDataSource: DataSource,
        columnList: any[]
    ) {
        // Get the existing connection
        const connection = AppDataSource.manager.connection;

        // Create a new query runner
        const queryRunner = connection.createQueryRunner();

        // Connect to the database
        await queryRunner.connect();

        // Start a new transaction
        await queryRunner.startTransaction();

        try {
            let columnsString = columnList
                .map((column) => `\`${column.mappedColumn}\` text`)
                .join(", ");

            let createTableQuery = `
    CREATE TABLE \`${tableName}\` (
        \`id\` INT AUTO_INCREMENT NOT NULL,
        ${columnsString},
        PRIMARY KEY (\`id\`)
    )
`;

            console.log("createTableQuery", createTableQuery);
            // Run the SQL query to create a new table
            await queryRunner.query(createTableQuery);

            // Commit the transaction
            await queryRunner.commitTransaction();
        } catch (error) {
            console.log("create table error", error);
            // If there's an error, roll back the transaction
            await queryRunner.rollbackTransaction();
            throw error;
        } finally {
            console.log("Table created successfully");
            // Release the query runner
            await queryRunner.release();
        }
    }
    private static async insertDataToTable(
        tableName: string,
        AppDataSource: DataSource,
        columnList: any[],
        dataList: any[]
    ) {
        // Get the existing connection
        const connection = AppDataSource.manager.connection;

        // Create a new query runner
        const queryRunner = connection.createQueryRunner();

        // Connect to the database
        await queryRunner.connect();

        // Start a new transaction
        await queryRunner.startTransaction();

        try {
            let columnsString = columnList
                .map((column) => `\`${column.mappedColumn}\``)
                .join(", ");
            let insertQueries = dataList.map((row) => {
                let valuesString;
                if (Array.isArray(row)) {
                    valuesString = row
                        .map((value) => {
                            // Escape single quotes by replacing them with two single quotes
                            let escapedValue = value.replace(/'/g, "''");
                            return `'${escapedValue}'`;
                        })
                        .join(", "); // Wrap values in single quotes for SQL
                } else {
                    valuesString = Object.values(row)
                        .map((value: any) => {
                            // Escape single quotes by replacing them with two single quotes
                            let escapedValue = value.replace(/'/g, "''");
                            return `'${escapedValue}'`;
                        })
                        .join(", "); // Wrap values in single quotes for SQL
                }
                return `INSERT INTO \`${tableName}\` (${columnsString}) VALUES (${valuesString})`;
            });

            // let insertDataQuery = `
            //     INSERT INTO ${tableName} (${columnsString})
            //     VALUES ${valuesString}
            // `;
            // Run the SQL query to create a new table
            //await queryRunner.query(insertDataQuery);
            for (let query of insertQueries) {
                // Execute each INSERT query
                console.log("insert query", query);
                await queryRunner.query(query);
            }

            // Commit the transaction
            await queryRunner.commitTransaction();
        } catch (error) {
            console.log("insert data error", error);
            // If there's an error, roll back the transaction
            await queryRunner.rollbackTransaction();
            throw error;
        } finally {
            console.log("Data inserted successfully");
            // Release the query runner
            await queryRunner.release();
        }
    }
    private static async GetUUID() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
            /[xy]/g,
            function (c) {
                var r = (Math.random() * 16) | 0,
                    v = c == "x" ? r : (r & 0x3) | 0x8;
                return v.toString(16);
            }
        );
    }
    private static async insertTableEntryInPublicTables(
        tableName: string,
        AppDataSource: DataSource,
        clientId: number
    ) {
        try {
            const public_table = new PublicTables();
            public_table.name = tableName;
            public_table.client_id = clientId;
            public_table.migration_id = this.migration_id;
            await Container.get(DataSource).manager.save(
                public_table
            );
        } catch (error) {
            console.log("insert table entry error", error);
        }
    }
}
