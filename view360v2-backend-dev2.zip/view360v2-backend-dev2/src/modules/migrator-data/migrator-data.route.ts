import { AppRoutes } from "../../app.routes";
import { MigratorConfigController } from "./controllers/migrator-config.controller";
import { MigratorCrudController } from "./controllers/migrator-crud.controller";

export class MigratorDataRoutes extends AppRoutes {
    private migratorConfigController: MigratorConfigController;
    private migratorCrudController: MigratorCrudController;

    constructor() {
        super();
        this.migratorConfigController = new MigratorConfigController();
        this.migratorCrudController = new MigratorCrudController();
    }
}
