export interface SaveResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface PwaResponse {
    status: boolean;
    data?: any;
    message?: string;
}

export interface GetDetailsResponse {
    status: boolean;
    data?: any;
    message?: string;
}