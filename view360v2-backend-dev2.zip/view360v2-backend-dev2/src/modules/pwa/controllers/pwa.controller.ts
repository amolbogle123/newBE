import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import { PwaPages } from "../../../entities";
import { dataSource } from "../../../core/data-source";
import Container from "typedi";
import { DataSource } from "typeorm";
import {
    Body,
    Controller,
    Get,
    Post,
    Query,
    Request,
    Route,
    Security,
    Tags,
    Path,
    Delete,
    Patch,
} from "tsoa";
import {
    GetDetailsResponse,
    PwaResponse,
    SaveResponse,
} from "../doc/pwa-interface";
import { CommonUtil } from "utils/common.util";

@Route("")
@Tags("Pwa")
export class PwaController extends Controller {
    @Security("bearerAuth")
    @Get("pwa")
    async pwaList(
        @Request() request: any,
        @Query("page") page: number = 1,
        @Query("pageSize") pageSize: number = 10,
        @Query("sortOrder") sortOrder?: number,
        @Query("sortField") sortField?: string,
        @Query("filters") filters?: string
    ): Promise<PwaResponse | unknown> {
        try {
            const apiResponse = {
                data: [],
                recordsTotal: 0,
                recordsFiltered: 0,
                totalPages: 0,
            };
            const selectedFields: any = ["id", "name", "pageUrl", "createdOn"];

            let whereCondition = {};
            const totalRecordCount = await Container.get(DataSource)
                .getRepository(PwaPages)
                .count({ where: whereCondition });
            whereCondition = await CommonUtil.applyFilter(
                filters,
                whereCondition
            );

            const sortObject: any = {};
            if (sortOrder !== undefined && sortField !== undefined) {
                sortObject[sortField] = sortOrder;
            } else {
                // If sortField is undefined, provide a default field to sort by
                sortObject["id"] = sortOrder;
            }

            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(PwaPages),
                {
                    where: whereCondition,
                    select: selectedFields,
                    take: pageSize,
                    skip: (page - 1) * pageSize,
                    order: sortObject,
                }
            );

            if (results?.length > 0) {
                apiResponse.data = results;
                apiResponse.recordsTotal = totalRecordCount;
                apiResponse.recordsFiltered = totalRecordCount;

                const totalPages = Math.ceil(totalRecordCount / pageSize);
                apiResponse.totalPages = totalPages;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Get("pwa/all")
    async getAllPwa(
        @Request() request: any
    ): Promise<GetDetailsResponse | unknown> {
        try {
            const apiResponse = {
                data: null,
            };

            let whereCondition = {};
            const results = await dbService._findQueryService(
                Container.get(DataSource).getRepository(PwaPages),
                {
                    where: whereCondition,
                }
            );

            if (results?.length) {
                apiResponse.data = results;
            }
            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Patch("pwa/:id")
    async updatePwa(
        @Path() id: string,
        @Body()
        requestBody: {
            name: string;
            pageUrl: string;
        },
        @Request() request: any
    ): Promise<PwaResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            let isDataFound = false;
            let payload: any = {};

            if (requestBody?.name) {
                payload.name = requestBody.name;
                isDataFound = true;
            }
            if (requestBody?.pageUrl) {
                payload.pageUrl = requestBody.pageUrl;
                isDataFound = true;
            }

            let updateResult: any = null;
            if (isDataFound) {
                updateResult = await dataSource
                    .getRepository(PwaPages)
                    .update({ id: id }, payload);
                apiResponse.data = updateResult;
            }
            if (!updateResult?.affected) {
                this.setStatus(204);
            } else {
                this.setStatus(200);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Post("pwa")
    async savePwa(
        @Body()
        requestBody: {
            name: string;
            pageUrl: string;
        },
        @Request() request: any
    ): Promise<SaveResponse | unknown> {
        this.setStatus(500);
        try {
            const apiResponse = {
                data: {},
            };

            const pwaModel = new PwaPages();
            pwaModel.name = requestBody.name;
            pwaModel.pageUrl = requestBody.pageUrl;
            pwaModel.createdBy = request.userDetails.id;
            const result = await Container.get(DataSource).manager.save(
                pwaModel
            );
            if (result?.id) {
                apiResponse.data = { insertedId: result.id };
                this.setStatus(201);
            }

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Security("bearerAuth")
    @Delete("pwa")
    async deletePwa(
        @Body() requestBody: { id: string[] }
    ): Promise<SaveResponse | unknown> {
        try {
            const apiResponse = {
                data: {},
            };

            const widgetResult = await dataSource
                .getRepository(PwaPages)
                .delete(requestBody.id);
            apiResponse.data = widgetResult;

            return CommonHelper.apiSwaggerSuccessResponse(apiResponse);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
