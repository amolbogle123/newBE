import {
    ApiErrorResponse,
    CommonHelper,
} from "../../../utils/helpers/common.helper";
import dbService from "../../../services/db.service";
import { Users } from "../../../entities";
import Container from "typedi";
import { DataSource } from "typeorm";
import {
    Body,
    Controller,
    Request,
    Route,
    Security,
    Tags,
    Path,
    Patch,
} from "tsoa";
import { PwaResponse } from "../doc/pwa-interface";

@Route("")
@Tags("Pwa")
export class PwaUserController extends Controller {
    @Security("bearerAuth")
    @Patch("pwa/user/:id")
    async pwaUser(
        @Request() request: any,
        @Path() id: string,
        @Body()
        requestBody: {
            first_name: string;
            last_name?: string | null;
            phone: string;
        }
    ): Promise<PwaResponse | unknown> {
        try {
            const updateData = {
                firstName: requestBody.first_name,
                lastName: requestBody.last_name,
                phone: requestBody.phone,
            } as unknown as Users;
            await dbService._updateQueryService(
                Container.get(DataSource).getRepository(Users),
                {
                    paramsObj: { id: id },
                    ...updateData,
                }
            );
            return CommonHelper.apiSwaggerSuccessResponse({
                message: "User updated successfully",
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
