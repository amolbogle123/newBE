import { AppRoutes } from "../../app.routes";
import { PwaController } from "./controllers/pwa.controller";

export class ChatbotRoutes extends AppRoutes {
    private pwaController: PwaController;

    constructor() {
        super();
        this.pwaController = new PwaController();
    }
}
