/**
 * import xmlParser from "xml2json";
 */
import { ApplicationLogger } from "core/config/pino-loggers";
import { dataSource } from "core/data-source";
import { AdfsAd } from "entities";
import { DataSource } from "typeorm";
import Container from 'typedi';

export class AdfsXmlHelper {
    async processAdfsData(adfsXMLString): Promise<any> {
        /**
         * let adfsData = JSON.parse(xmlParser.toJson(adfsXMLString));
        let adfsVersion = 0;
        if (adfsData["md:EntityDescriptor"]) {
            adfsData = adfsData["md:EntityDescriptor"];
            adfsVersion = 1;
        } else {
            adfsVersion = 2;
            adfsData = adfsData["EntityDescriptor"];
        }
        // console.log("adfsData", JSON.stringify(adfsData));
        const entityID = adfsData["entityID"].split("/")[2];
        let cert = null;
        
        if (adfsVersion == 1) {
            // cert =
            //     adfsData["md:IDPSSODescriptor"]["md:KeyDescriptor"][0][
            //         "ds:KeyInfo"
            //     ]["ds:X509Data"]["ds:X509Certificate"];
            cert =
                adfsData["md:IDPSSODescriptor"]["md:KeyDescriptor"][
                    "ds:KeyInfo"
                ]["ds:X509Data"]["ds:X509Certificate"];
        } else if (adfsVersion == 2) {
            // cert =
            //     adfsData["IDPSSODescriptor"]["KeyDescriptor"][0]["KeyInfo"][
            //         "X509Data"
            //     ]["X509Certificate"];
            cert =
                adfsData["IDPSSODescriptor"]["KeyDescriptor"]["KeyInfo"][
                    "X509Data"
                ]["X509Certificate"];
        }
        
        return {
            microsoft_id: `https://${entityID}/`,
            cert: cert,
        };
         */
    }

    async createAdfsAd(adfsData): Promise<any> {
        try {
            let responseData = null;

            let adfsAd = new AdfsAd();
            adfsAd.clientId = adfsData.client_id;
            adfsAd.microsoftId = adfsData.microsoft_id;
            adfsAd.cert = adfsData.cert;

            const result = await Container.get(DataSource).manager.save(adfsAd);
            if (result?.id) {
                let adfsResult: any = await dataSource
                    .getRepository(AdfsAd)
                    .findOne({
                        where: {
                            id: result.id,
                        },
                    });
                if (adfsResult) {
                    responseData = adfsResult;
                }
            }

            return responseData;
        } catch (error) {
            ApplicationLogger.error("Error occurred in adfsAd::", error);

            return {
                error: {
                    error_description: (error as Error).message,
                },
            };
        }
    }
}
