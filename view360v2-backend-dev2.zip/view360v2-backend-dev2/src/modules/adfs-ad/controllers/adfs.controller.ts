import {
    CommonHelper,
    ApiErrorResponse,
} from "../../../utils/helpers/common.helper";
import passport from "passport";
import { Strategy } from "passport-saml";
import { Users, MenuModule, MdbClient, AdfsAd } from "../../../entities";
import { JwtEncryptUtil } from "../../../utils/jwt-encrypt.util";
import { CommonUtil } from "../../../utils/common.util";
import { DataSource } from "typeorm";
import Container from "typedi";
import { Controller } from "tsoa";
const zlib = require("zlib");
const Buffer = require("buffer").Buffer;
const xml2js = require("xml2js");
export class AsdfController extends Controller {
    async getAsdfConnect(req: any, res: any, next: any): Promise<any> {
        try {
            const url = await this.getLoginByClientUrl();
            if (url) {
                res.json({ url: url });
            } else {
                res.json({ url: null });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }

    async getLoginByClientUrl() {
        const adfsAdConfig = await Container.get(DataSource)
            .getRepository(AdfsAd)
            .findOne({ where: { id: process.env.ADFS_ID } });
        if (!adfsAdConfig) {
            return null;
        }
        return process.env.BASE_URL + `/adfs/login/${adfsAdConfig.id}`;
    }

    async getAdfsLoginRequestById(req: any, res: any, next: any): Promise<any> {
        try {
            const adfsAdConfig = await Container.get(DataSource)
                .getRepository(AdfsAd)
                .findOne({ where: { id: req.params.id } });
            if (!adfsAdConfig) {
                return CommonHelper.apiSuccessResponse(res, {
                    message: "no certificate found, calling redirect !",
                });
            }

            let origin: any = await CommonUtil.getOriginUrl(req.headers.host);          
            let entryPoint = process.env.ENTRY_POINT_URL;
            let result: any = await Container.get(DataSource)
                .getRepository(MdbClient)
                .findOne({ where: { websiteUrl: origin } });
            if (result) {
                let menuResult: any = await Container.get(DataSource)
                    .getRepository(MenuModule)
                    .findOne({
                        where: {
                            moduleName: "SSO_ADFS_SAML",
                            clientId: result.id,
                        },
                    });
                if (menuResult?.isActive) {
                    let config = JSON.parse(menuResult.config);
                    entryPoint = config.url;
                }
            }

            console.log(adfsAdConfig.cert, "adfsAdConfig.cert");
            const backendurl = process.env.BASE_URL;
            console.log(entryPoint, "entryPoint", backendurl);
            passport.use(
                "saml",
                new Strategy(
                    {
                        callbackUrl: `${backendurl}/adfs/callback`,
                        issuer: `${backendurl}/adfs/callback`,
                        cert: adfsAdConfig.cert,
                        identifierFormat: null,
                        entryPoint: entryPoint,
                    },
                    (profile, done) => {
                        console.log(done, "datatattaatatt");
                        return done;
                    }
                )
            );
            passport.authenticate(
                "saml",
                { failureRedirect: "/adfs/fail", failureFlash: true },
                (req1, res1) => {
                    console.log(
                        "Passport Authenticate Failure, calling redirect !"
                    );
                    res1.redirect("/");
                }
            )(req, res);
        } catch (error) {
            console.log(error, "err+++");
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }
    decodeSAMLResponse(encodedMessage, callback) {
        // Decode the Base64 encoded message
        const decodedMessage = Buffer.from(
            decodeURIComponent(encodedMessage),
            "base64"
        );

        // Decompress the message
        zlib.inflateRaw(decodedMessage, (err, decompressed) => {
            if (err) {
                return callback(err);
            }

            // Convert decompressed message to a string
            const samlMessage = decompressed.toString("utf8");

            // Parse the XML
            xml2js.parseString(
                samlMessage,
                { explicitArray: false },
                (err, result) => {
                    if (err) {
                        return callback(err);
                    }
                    callback(null, result);
                }
            );
        });
    }
    async getAdfsCallback(req: any, res: any, next: any): Promise<any> {
        try {
            let samlResponse = null;
            let encodedSamlResponse = req.query.SAMLResponse; // Assuming it's already URL-decoded
            this.decodeSAMLResponse(encodedSamlResponse, (err, result) => {
                if (err) {
                    console.error("Error decoding SAML message:", err);
                } else {
                    samlResponse = result;
                    // const xmlUserData = result.Response.Assertion[0].AttributeStatement[0].Attribute;
                    // const userData = {
                    //     ssoType: 'adfs'
                    // }
                    // userData[xmlKeyName] = xmlUserData[0].AttributeValue[0]._;
                    // const userBuffer = Buffer.from(JSON.stringify(userData)).toString('base64');
                    // res.redirect(`${process.env.VIEW360v2FE_URL}/saml?data=${userBuffer}`);

                    const xmlUserData =
                        samlResponse["samlp:Response"]["saml:Assertion"][
                            "saml:AttributeStatement"
                        ]["saml:Attribute"];
                    const userData = {
                        ssoType: "adfs",
                    };
                    console.log(xmlUserData, "samlResponsesamlResponse");
                    //const result = {};

                    xmlUserData.forEach((attribute) => {
                        const friendlyName = attribute["$"].FriendlyName;
                        const value = attribute["saml:AttributeValue"]._;

                        if (friendlyName && value) {
                            userData[friendlyName] = value;
                        }
                    });
                    // xmlUserData.map((data) => {
                    //     if (
                    //         data["Name"] ==
                    //         '/UserAttribute[@ldap:targetAttribute="mail"]'
                    //     ) {
                    //         userData["email"] = data["saml:AttributeValue"]["$t"];
                    //     } else {
                    //         // for keycloak
                    //        // console.log(data,'data["FriendlyName"]',data?.FriendlyName);

                    //         userData[data["FriendlyName"]] = data["saml:AttributeValue"]["$t"];
                    //         userData[data["Name"]] = data["saml:AttributeValue"]["$t"];
                    //     }
                    // });
                    console.log(
                        "Check SAML userdata,email should match",
                        userData
                    );
                    const userBuffer = Buffer.from(
                        JSON.stringify(userData)
                    ).toString("base64");
                    res.redirect(
                        `${process.env.VIEW360v2FE_URL}/saml?data=${userBuffer}`
                    );
                }
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }

    async adfsGenerateToken(req: any, res: any, next: any): Promise<any> {
        try {
            let token;
            const userLoginDetails = {};
            const responseData = {
                status: false,
                data: null,
                userData: null,
                email: req.params.email,
                username: null,
                err: null,
            };
            const USER = await Container.get(DataSource)
                .getRepository(Users)
                .findOne({ where: { email: req.params.email, isActive: 1 } });
            if (USER) {
                const jwtDataSet = {
                    id: USER.id,
                    role_id: USER.roleId,
                    username: USER.username,
                    useremail: USER.email,
                    client_id: USER.clientId,
                    is_superadmin: USER.isSuperAdmin,
                    loginDate: new Date(),
                };
                token = JwtEncryptUtil.encryptedCode(jwtDataSet, "1d");
                Object.keys(USER).forEach((u) => {
                    if (["PASSWORD"].indexOf(u) === -1) {
                        userLoginDetails[u.toLowerCase()] = USER[u];
                    }
                });
                res.cookie("auth", token, {
                    httpOnly: true,
                    maxAge: process.env.COOKIE_TIMEOUT_SECONDS || 24 * 60 * 60,
                });
                responseData.data = token;
                responseData.userData = userLoginDetails;
                responseData.status = true;
                return CommonHelper.apiSuccessResponse(res, {
                    data: responseData,
                });
            } else {
                responseData.err =
                    "No user found with email : " + req.params.email;
                responseData.status = false;
                return CommonHelper.apiSuccessResponse(res, {
                    data: responseData,
                });
            }
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }
}
