import {AppRoutes} from "../../app.routes";
import {AsdfController} from "./controllers/adfs.controller";


export class AdfsRoutes extends AppRoutes {
    private asdfController: AsdfController;


    constructor() {
        super();
        this.asdfController = new AsdfController();
        this.initRoutes();
    }

    initRoutes() {
        this.router.get('/adfs/organization', (req: any, res: any, next: any) =>
            this.asdfController.getAsdfConnect(req, res, next).catch(next)
        );

        this.router.get('/adfs/login/:id', (req: any, res: any, next: any) =>
            this.asdfController.getAdfsLoginRequestById(req, res, next).catch(next)
        );
        this.router.get('/adfs/callback', (req: any, res: any, next: any) =>
            this.asdfController.getAdfsCallback(req, res, next).catch(next)
        );
        this.router.get('/adfs/token/:email', (req: any, res: any, next: any) =>
            this.asdfController.adfsGenerateToken(req, res, next).catch(next)
        );
    }
}
