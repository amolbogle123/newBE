import { AppRoutes } from "../../app.routes";
import { UserLogsController } from "./controllers/user-logs.controller";
import { MailTrackController } from "./controllers/mail-track.controller";

export class UserLogsRoutes extends AppRoutes {
    userLogsController: UserLogsController;
    mailTrackController: MailTrackController;
    
    constructor() {
        super();
        this.userLogsController = new UserLogsController();
        this.mailTrackController = new MailTrackController();
        this.initRoutes();
    }

    initRoutes() {
        /**
         * this.router.get("/logs/user-logs", (req, res, next) =>
            this.userLogsService.getAllUserLogs(req, res, next).catch(next)
        );
        this.router.get("/logs/mail-logs", (req, res, next) =>
            this.userLogsService.getAllMailLogs(req, res, next).catch(next)
        );
         */
        this.router.get("/logs/track-mail/:imageName", (req, res, next) =>
            this.mailTrackController.getImage(req, res, next).catch(next)
        );
        this.router.get("/logs/track-btn-click/:btnId", (req, res, next) =>
            this.mailTrackController.getButtonClick(req, res, next).catch(next)
        );
    }
}
