export interface UserLogRequest {
    perPage?: number; 
    current?: number;
    clientId?: number;
}

export interface MailLogRequest {
    customFilters: any;
    draw: number;
    columns: Columns[];
    order: Order[];
    start: number;
    length: number;
    search: Search;
    type: string;
}

export interface UserLogResponse {
    status: string;
    data?: any;
    message?: string;
}

interface Columns {
    data: string;
    name: string;
    searchable: boolean;
    orderable: boolean;
    search: Search;
}
interface Search {
    value: string;
    regex: boolean;
}

interface Order {
    column: number;
    dir: string;
}
