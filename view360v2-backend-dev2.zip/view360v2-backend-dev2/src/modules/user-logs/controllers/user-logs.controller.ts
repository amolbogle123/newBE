import { dataSource } from "../../../core/data-source";
import { MailLog, UserLogs } from "../../../entities";
import Container from 'typedi';
import {DataSource} from 'typeorm';
import {ApiErrorResponse, CommonHelper} from "../../../utils/helpers/common.helper";
import { Body, Controller, Post, Request, Route, Tags } from 'tsoa';
import { UserLogRequest, UserLogResponse } from '../doc/logs.interface';

@Route('logs')
@Tags('User Logs')
export class UserLogsController extends Controller {

    @Post('user-logs')
    async getAllUserLogs(
        @Body() requestBody: UserLogRequest,
        @Request() request: any
    ): Promise<UserLogResponse | unknown> {
        try {
            const { perPage = 10, current = 1, clientId } = requestBody;
            const startPoint =
                (parseInt(current.toString(), 10) - 1) *
                parseInt(perPage.toString(), 10);
            const queryObj = {};
            if (clientId) {
                queryObj["client_id"] = clientId;
            }
            const userLogs = await Container.get(DataSource).getRepository(UserLogs).find({
                where: { ...queryObj },
                take: +perPage,
                skip: startPoint,
            });
            return CommonHelper.apiSwaggerSuccessResponse({data: userLogs});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
    
    @Post('mail-logs')
    async getAllMailLogs(
        @Body() requestBody: any,
        @Request() request: any
    ): Promise<UserLogResponse | unknown> {
        try {
            const { perPage = 10, current = 1, clientId } = requestBody.customFilters;
            const startPoint =
                (parseInt(current.toString(), 10) - 1) *
                parseInt(perPage.toString(), 10);
            const queryObj = {};
            if (clientId) {
                queryObj["client_id"] = clientId;
            }
            const mailLogs = await dataSource
                .getRepository(MailLog)
                .find({
                    where: { ...queryObj },
                    take: +perPage,
                    skip: startPoint,
                });
            return CommonHelper.apiSwaggerSuccessResponse({data: mailLogs});
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
