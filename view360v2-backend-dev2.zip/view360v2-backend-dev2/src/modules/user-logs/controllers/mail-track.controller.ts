import { Request, Response, NextFunction } from "express";
import path from "path";
import { validate as uuidValidate } from "uuid";

import { dataSource } from "../../../core/data-source";
import { MailLog } from "../../../entities";
import Container from 'typedi';
import {DataSource} from 'typeorm';
import {ApiErrorResponse, CommonHelper} from "../../../utils/helpers/common.helper";

export class MailTrackController {

    async getImage(
        req: Request,
        res: Response,
        next: any
    ): Promise<any> {
        try {
            const {imageName} = req.params;

            if (imageName?.includes(".png")) {
                const logId = path.basename(imageName, ".png");
                const validate = uuidValidate(logId);
                if (logId && validate) {
                    const mailLogs = await dataSource
                        .getRepository(MailLog)
                        .find({
                            where: { id: logId },
                        });
                    if (mailLogs?.length) {
                        await this.insertIntoMailLog(mailLogs, logId);
                    }
                }
            }
            const trackImage = `${__dirname}/sample.png`;
            res.status(200).sendFile(trackImage);
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }
    
    async getButtonClick(
        req: Request,
        res: Response,
        next: NextFunction
    ): Promise<any> {
        try {
            const { btnId: logId } = req.params;
            const validate = uuidValidate(logId);
            if (logId && validate) {
                const mailLogs = await dataSource
                    .getRepository(MailLog)
                    .find({
                        where: { id: logId },
                    });
                if (mailLogs && mailLogs.length) {
                    let openLog = [];
                    const [firstMailLogObject] = mailLogs;
                    try {
                        openLog = firstMailLogObject["CLICK_BTN"]
                            ? JSON.parse(firstMailLogObject["CLICK_BTN"])
                            : [];
                    } catch (error) {}
                    openLog.push({
                        timeStramp: new Date(),
                    });
                    await Container.get(DataSource).getRepository(MailLog).save({
                        id: logId,
                        click_btn: JSON.stringify(openLog),
                    });
                }
            }
            res.status(200).send(
                `<script>window.location.href="${req.query.r}";</script>`
            );
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message
                }
            }
            return CommonHelper.apiErrorResponse(res, apiErrorResponse);
        }
    }

    insertIntoMailLog(mailLogs, logId) {
        return new Promise(async(resolve) => {
            let openLog = [];
            const [firstMailLogObject] = mailLogs;
            try {
                openLog = firstMailLogObject["openLog"]
                    ? JSON.parse(
                            firstMailLogObject["openLog"].toString()
                        )
                    : [];
            } catch (error) {}
            openLog.push({
                timeStramp: new Date(),
            });
            await Container.get(DataSource).getRepository(MailLog).insert({
                id: logId.toString(),
                isOpened: firstMailLogObject["isOpened"] + 1,
                openLog: JSON.stringify(openLog),
            });
            resolve(true);
        });
    }
}
