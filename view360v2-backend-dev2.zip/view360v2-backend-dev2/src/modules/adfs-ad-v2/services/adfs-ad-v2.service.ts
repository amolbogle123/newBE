import axios from "axios";
import { AdfsAd } from "entities/adfs-ad";
import Container from "typedi";
import { DataSource } from "typeorm";
import { parseStringPromise } from "xml2js";

export class Adfsv2Service {
    async saveAdfsv2(data) {
        return Container.get(DataSource).getRepository(AdfsAd).save(data);
    }

    async getAdfsv2ByClientId(clientId: number) {
        return Container.get(DataSource)
            .getRepository(AdfsAd)
            .findOne({ where: { clientId: clientId } });
    }

    async getLoginByClientUrl(clientId: number) {
        return Container.get(DataSource)
            .getRepository(AdfsAd)
            .findOne({ where: { clientId: clientId } });
    }

    async updateAdfsv2(data, clientId: number, id: any) {
        return Container.get(DataSource)
            .getRepository(AdfsAd)
            .update({ clientId: clientId, id: id }, data);
    }

    async deleteAdfsv2(id: string) {
        return Container.get(DataSource)
            .getRepository(AdfsAd)
            .delete({ id: id });
    }

    async getMetaDataFromUrl(url: string) {
        return (await axios.get(url)).data;
    }

    async processAdfsAdData(data) {
        let adfsData = await parseStringPromise(data);
        let adfsVersion = 0;

        if (adfsData["md:EntityDescriptor"]) {
            adfsData = adfsData["md:EntityDescriptor"];
            adfsVersion = 1;
        } else {
            adfsVersion = 2;
            adfsData = adfsData["EntityDescriptor"];
        }

        const entityID = adfsData["$"]["entityID"].split("/")[2];
        let cert = null;

        if (adfsVersion == 1) {
            cert =
                adfsData["md:IDPSSODescriptor"][0]["md:KeyDescriptor"][0][
                    "ds:KeyInfo"
                ][0]["ds:X509Data"][0]["ds:X509Certificate"][0];
        } else if (adfsVersion == 2) {
            cert =
                adfsData["IDPSSODescriptor"][0]["KeyDescriptor"][0][
                    "KeyInfo"
                ][0]["X509Data"][0]["X509Certificate"][0];
        }

        return {
            microsoftId: `https://${entityID}/`,
            cert: cert,
        };
    }
}
