import {
    Body,
    Controller,
    Delete,
    Get,
    Patch,
    Path,
    Post,
    Request,
    Route,
    Tags,
} from "tsoa";
import { ApiErrorResponse, CommonHelper } from "utils/helpers/common.helper";
import { Adfsv2Service } from "../services/adfs-ad-v2.service";

@Route("adfs-ad-v2")
@Tags("ADFS-AD-V2")
export class AdfsAdv2Controller extends Controller {
    private adfsAdv2Service: Adfsv2Service;
    constructor() {
        super();
        this.adfsAdv2Service = new Adfsv2Service();
    }

    @Post()
    async create(@Request() req: any, @Body() requestBody: any): Promise<void> {
        try {
            let metaDataString: any;

            if (!requestBody.type) {
                this.setStatus(400);
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description: "Type is required",
                    },
                });
            }

            if (!requestBody.metadata) {
                this.setStatus(400);
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description: "Metadata is required",
                    },
                });
            }

            if (req.body.type === "url") {
                try {
                    const response =
                        await this.adfsAdv2Service.getMetaDataFromUrl(
                            requestBody.metadata
                        );
                    if (!response) {
                        this.setStatus(400);
                        return CommonHelper.apiSwaggerErrorResponse({
                            error: {
                                error_description: "Wrong Url",
                            },
                        });
                    }

                    metaDataString = response;
                } catch (error) {
                    this.setStatus(400);
                    return CommonHelper.apiSwaggerErrorResponse({
                        error: {
                            error_description: "Wrong Url",
                        },
                    });
                }
            } else {
                metaDataString = Buffer.from(
                    requestBody.metadata,
                    "base64"
                ).toString();
            }

            const adfsData = await this.adfsAdv2Service.processAdfsAdData(
                metaDataString
            );
            const response = await this.adfsAdv2Service.saveAdfsv2({
                clientId: req.userDetails.client_id,
                ...adfsData,
            });
            return CommonHelper.apiSwaggerSuccessResponse({ data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get()
    async getByClientId(@Request() req: any): Promise<void> {
        try {
            const response = await this.adfsAdv2Service.getAdfsv2ByClientId(
                req.userDetails.client_id
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Get("get-login-by-client-url")
    async getLoginByClientUrl(@Request() req: any): Promise<void> {
        try {
            const response = await this.adfsAdv2Service.getLoginByClientUrl(
                req.userDetails.client_id
            );

            if (response) {
                return CommonHelper.apiSwaggerSuccessResponse({
                    data: {
                        url:
                            process.env.ADFS_BASE_URL +
                            "/adfs/login/" +
                            response.id,
                    },
                });
            }
            return CommonHelper.apiSwaggerSuccessResponse({
                data: { url: null },
            });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Patch("/:id")
    async update(
        @Path() id: string,
        @Request() req: any,
        @Body() requestBody: any
    ): Promise<void> {
        try {
            let metaDataString: any;
            if (!requestBody.type) {
                this.setStatus(400);
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description: "Type is required",
                    },
                });
            }

            if (!requestBody.metadata) {
                this.setStatus(400);
                return CommonHelper.apiSwaggerErrorResponse({
                    error: {
                        error_description: "Metadata is required",
                    },
                });
            }

            if (requestBody.type === "url") {
                try {
                    const response =
                        await this.adfsAdv2Service.getMetaDataFromUrl(
                            requestBody.metadata
                        );
                    if (!response) {
                        this.setStatus(400);
                        return CommonHelper.apiSwaggerErrorResponse({
                            error: {
                                error_description: "Wrong Url",
                            },
                        });
                    }

                    metaDataString = response;
                } catch (error) {
                    this.setStatus(400);
                    return CommonHelper.apiSwaggerErrorResponse({
                        error: {
                            error_description: "Wrong Url",
                        },
                    });
                }
            } else {
                metaDataString = Buffer.from(
                    requestBody.metadata,
                    "base64"
                ).toString();
            }

            const adfsData = await this.adfsAdv2Service.processAdfsAdData(
                metaDataString
            );
            const response = await this.adfsAdv2Service.updateAdfsv2(
                adfsData,
                req.userDetails.client_id,
                id
            );
            return CommonHelper.apiSwaggerSuccessResponse({ data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };

            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }

    @Delete("/:id")
    async delete(@Path() id: string, @Request() req: any): Promise<void> {
        try {
            const response = await this.adfsAdv2Service.deleteAdfsv2(id);
            return CommonHelper.apiSwaggerSuccessResponse({ data: response });
        } catch (error) {
            const apiErrorResponse: ApiErrorResponse = {
                error: {
                    error_description: (error as Error).message,
                },
            };
            this.setStatus(500);
            return CommonHelper.apiSwaggerErrorResponse(apiErrorResponse);
        }
    }
}
