import dotenv from "dotenv";
dotenv.config({ override: true });
import '../dd-tracer';
/**
 * import { setupTracing } from '../tracer';
 * setupTracing();
 */

import { Bootstrap } from './core/bootstrap';





const bootstrap = new Bootstrap();

bootstrap.bootstrap();