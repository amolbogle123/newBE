import rateLimit from 'express-rate-limit';

export const rateLimiterMiddleware = (maxRequest: number, windowMs: number) => {
    return rateLimit({
        windowMs,
        max: maxRequest,
        keyGenerator: (req) => req.path,
        handler: (req, res) => {
            res.status(429).json({
                status: 'error',
                statusCode: 429,
                message: 'Too many requests. Please try again later.'
            })
        }
    });
};