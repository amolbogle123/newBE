import { NextFunction, Request, Response } from "express";
import { EncryptionSerice } from "services/encryption.service";
import Container from "typedi";
import { DataSource } from "typeorm";

interface CustomRequest extends Request {
    userDetails: any;
}

export const subscriptionMiddleware = async (req: CustomRequest, res: Response, next: NextFunction): Promise<void> => {
    try {
        const subscription = await Container.get(DataSource).getRepository('ModuleSubscription').findOne({
            where: { moduleId: res.locals.moduleId, isActive: 1 }
        });

        if (subscription) {
            const encryptionService = new EncryptionSerice();
            const decryptedKey = JSON.parse(encryptionService.decryptValue(subscription.accessKey));
            if (decryptedKey) {
                if (new Date() > new Date(decryptedKey.validUntil)) {
                    res.status(403).json({ message: 'Your Subscription is Expired! Please contact administrator.' });
                    return;
                }
                return next();
            }
        }
        
        res.status(403).json({ message: 'You are not authorized to access this resource.' });
    } catch (error) {
        console.log('Error in subscription middleware :: ', error)
        res.status(500).send('Internal Server Error from subscription middleware.');
    }
}