import { NextFunction, Request, Response } from "express";
import Container from "typedi";
import { DataSource } from "typeorm";

interface CustomRequest extends Request {
    userDetails: any;
}

export const permissionMiddlewareUtil = async (
    req: CustomRequest,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        let canAccess = false;
        if (req["userDetails"] && req["userDetails"].role_id) {
            if (
                req["userDetails"].is_superadmin &&
                req["userDetails"].is_superadmin === 1
            ) {
                /* SUPER ADMIN USER HAS ALL THE ACCESS */
                console.log(
                    req["userDetails"].is_superadmin,
                    'req["userDetails"].is_superadmin'
                );
                next();
                return;
            }

            const roleResults = await Container.get(DataSource)
                .getRepository("UserRoles")
                .findOne({
                    where: {
                        id: req["userDetails"].role_id,
                        clientId: req["userDetails"].client_id,
                    },
                });
            if (roleResults) {
                const rolePermission = roleResults.permission
                    ? JSON.parse(roleResults.permission)
                    : {};

                const requestedPath = req.path.slice(1).split("/");

                canAccess = checkRole(
                    rolePermission,
                    requestedPath,
                    req.method
                );
                console.log(canAccess, "canAcccc");
                if (canAccess) {
                    return next();
                }
            }
        }
        res.status(403).json({
            message: "You are not authorized to access this resource.",
        });
    } catch (error) {
        console.log("Error in permission middleware :: ", error);
        res.status(500).send(
            "Internal Server Error from permission middleware."
        );
    }
};

function checkRole(roleArray, path, method) {
    path = exactPath(path);
    let canAccess = false;
    switch (method) {
        case "GET":
            canAccess = roleArray[path[0]][path[1]].view;
            break;
        case "DELETE":
            canAccess = roleArray[path[0]][path[1]].delete;
            break;
        case "POST":
            canAccess = roleArray[path[0]][path[1]].add;
            break;
        case "PATCH":
            canAccess = roleArray[path[0]][path[1]].edit;
            break;
        case "PUT":
            canAccess = roleArray[path[0]][path[1]].edit;
            break;
    }
    return canAccess;
}

function exactPath(path) {
    switch (path[0]) {
        case "dashboard":
            if (path[1] && path[1] !== "dashboard") {
                path[1] = "widget";
            } else {
                path[1] = "dashboard";
            }
            break;
        case "form-builder":
            path[0] = "documents";
            if (path[1] && path[1] === "forms") {
                path[1] = "form";
            } else {
                path[1] = "document";
            }
            break;
    }
    return path;
}
