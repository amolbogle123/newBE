import Container from "typedi";
import {DataSource} from "typeorm";

export  const getCountForEntity = async (req, res, next, entityClass: string, verifyCount: any, whereCondition?: object ): Promise<number> => {
    try{
        if (process.env.MASTER_ENTRY_COUNT && process.env.MASTER_ENTRY_COUNT == 'true') {
            let whereConditions = whereCondition;
            if(req && req.body && req.body[res.locals.key]) {
                whereConditions = { dashboard: null, isWidgetVisible: 1};
                whereConditions['dashboard'] = req.body[res.locals.key];
            }

            // Get the repository for the provided entity class
            const repository = Container.get(DataSource).getRepository(entityClass);

            // Count the records in the repository with optional where condition
            if(isNaN(verifyCount)) {
                next();
            } else {
                const _count = Number(verifyCount);
                const count = await repository.count({ where: whereConditions });
                if(count >= _count){
                    res.status(200).json({error: 'maxUserLimit'});
                    return ;
                } else {
                    next();
                }
            }
        }
    } catch (error) {
        console.error('Error in middleware getCountForEntity:', error);
        res.status(500).send('Internal Server Error from middleware getCountForEntity.');
    }
};
