import { Request, Response, NextFunction } from 'express';
import { RedisService } from 'services/redis.service';

export const cacheMiddleware = async (req: Request, res: Response, next: NextFunction) => {
    const redisService = new RedisService();
    
    try {
        // Check if the request do not allow caching for a widget
        let cacheWidget = req.query.cachingStatus == 'true';
        if (req[res.locals.location][res.locals.key] && !req.query?.reloadCache && res.locals.operation === 'cache') {
            const cachedResponse = await redisService.getValue(req[res.locals.location][res.locals.key]);
            if (cachedResponse && cacheWidget) {
                console.log("Sending Cached Response :: Key :: ", req[res.locals.location][res.locals.key]);
                return res.status(200).send(cachedResponse)
            }
        }

        if (res.locals.operation === 'flush') {
            console.log("Going to Flush the Cache :: Key :: ", req[res.locals.location][res.locals.key])
            await redisService.deleteValue(req[res.locals.location][res.locals.key])
        }

        // Store the original send function
        const originalSend = res.send;

        // Create a variable to store the response data
        let responseData;

        // Override the send function to capture response data
        res.send = (data: any): Response => {
            // Log the captured response data
            responseData = JSON.parse(data);
            // Call the original send method to actually send the response to the client
            return originalSend.call(res, data);
        };

        // Create a listener for 'finish' event to log response data after the response has been sent
        res.on('finish', async function () {
            // Store the response data into redis.
            if (cacheWidget && res.locals.operation === 'cache') {
                console.log("Storing Response in Cache :: Key :: ", req[res.locals.location][res.locals.key]);
                if (responseData.data?.length || responseData.data.data?.length) {
                    await redisService.setValue(req[res.locals.location][res.locals.key], JSON.stringify(responseData))                    
                }
            }
        });

        // Continue to the next middleware or route handler
        next();
    } catch (error) {
        console.error('Error in cache middleware:', error);
        res.status(500).send('Internal Server Error from cache middleware.');
    }
};