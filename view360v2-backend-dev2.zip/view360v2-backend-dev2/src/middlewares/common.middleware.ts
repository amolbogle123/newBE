import { NextFunction, Request, Response } from "express";
import { cacheMiddleware } from "./cache.middleware";
import { getCountForEntity } from "./totalCount.middleware";
import { cachedEndpoints } from "../utils/constants/cache-endpoint.constants";
import { entryCount } from "utils/constants/allowed-entry-count.constants";
import { subscriptionMiddleware } from "./subscription.middleware";
import { readFileSync } from "fs";
import { permissionMiddlewareUtil } from "./permissions.middleware";
let axios = require("axios");

interface CustomRequest extends Request {
    userDetails: any;
}

export const commonMiddleware = async (
    req: CustomRequest,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        if (process.env.REDIS_ENABLE && process.env.REDIS_ENABLE == "true") {
            for (const endpoint of cachedEndpoints) {
                if (
                    req.path.includes(endpoint.endpoint) &&
                    req.method === endpoint.method
                ) {
                    res.locals.endpoint = endpoint.endpoint;
                    res.locals.key = endpoint.key;
                    res.locals.location = endpoint.location;
                    res.locals.operation = endpoint.operation;
                    // Use cacheMiddleware
                    await cacheMiddleware(req, res, next);
                    return;
                }
            }
        }

        if (
            process.env.SUBSCRIPTION_VALIDATION &&
            process.env.SUBSCRIPTION_VALIDATION == "true"
        ) {
            // Path to the JSON file
            // const filePath = path.join(__dirname, '../../moduleList.json');
            const filePath = "./public/moduleList.json";
            const subscriptionModulesList = JSON.parse(
                readFileSync(filePath, "utf-8")
            );
            console.log(
                "subscriptionModulesList :: Common Middleware :: ",
                subscriptionModulesList
            );
            const requestedPath = req.path.slice(1).split("/");
            const [mainRoute] = requestedPath;
            if (subscriptionModulesList[mainRoute]) {
                res.locals.moduleId = subscriptionModulesList[mainRoute];
                // Use Subscription Middleware
                await subscriptionMiddleware(req, res, next);
                return;
            }
            // if (subscriptionEndpoints[req.path] && subscriptionEndpoints[req.path].methods[req.method] === 'validate') {
            //     res.locals.moduleId = subscriptionEndpoints[req.path].moduleId;
            //     // Use Subscription Middleware
            //     await subscriptionMiddleware(req, res, next);
            //     return;
            // }
        }

        if (
            process.env.PERMISSION_VALIDATION &&
            process.env.PERMISSION_VALIDATION == "true"
        ) {
            await permissionMiddleware(req, res, next);
            return;
        }

        next();
    } catch (error) {
        console.error("Error in common middleware:", error);
        res.status(500).send("Internal Server Error from common middleware.");
    }
};

export const validateEntryCount = async (
    req: Request,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        if (
            process.env.MASTER_ENTRY_COUNT &&
            process.env.MASTER_ENTRY_COUNT == "true"
        ) {
            for (const endpoint of entryCount) {
                if (
                    req.path.includes(endpoint.endpoint) &&
                    req.method === endpoint.method
                ) {
                    res.locals.endpoint = endpoint.endpoint;
                    res.locals.key = endpoint.key ? endpoint.key : undefined;
                    const result = await axios.get(process.env.MASTER_ENTRY_COUNT_URL + req['userDetails'].client_id);
                    if(result.status === 200 && result.data.data.length > 0) {
                        for(const classCount of result.data.data) {
                            if(classCount.configKey === endpoint.class) {
                                res.locals.count = classCount.configValue;
                                endpoint.count = classCount.configValue;
                            }
                        }
                    }
                    res.locals.count = endpoint.count;
                    res.locals.class = endpoint.class;
                    const clientID = req['userDetails'].client_id;
                    await getCountForEntity(req, res, next, endpoint.class, endpoint.count, { clientId: clientID, isSuperAdmin: 0});
                    return;
                }
            }
        }
        next();
    } catch (error) {
        console.error("Error in common middleware validateEntryCount:", error);
        res.status(500).send(
            "Internal Server Error from common middleware validateEntryCount."
        );
    }
};

export const permissionMiddleware = async (
    req: CustomRequest,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        if (
            process.env.PERMISSION_VALIDATION &&
            process.env.PERMISSION_VALIDATION == "true"
        ) {
            await permissionMiddlewareUtil(req, res, next);
            return;
        }
        next();
    } catch (error) {
        console.error("Error in permission middleware:", error);
        res.status(500).send(
            "Internal Server Error from permission middleware."
        );
    }
};
