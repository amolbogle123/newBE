export interface NavigationMenu {
    name: string;
    order: number;
    roles: string;
    active: number;
    tempId: string;
    iconClass?: string;
    parantTmpId: string | null;
    components: NavigationMenu[];
    routerLink: string | null;
    faClass?: string;
}

export interface NewNavigationMenu {
    name: string;
    type: string;
    sectionTextColor: string
    sectionBgColor: string;
    menuItems: NavigationMenu[];
    sectionActiveBgColor: string;
    sectionActiveTextColor: string;
    sectionHoverBgColor: string;
    sectionHoverTextColor: string;
}