export enum UserType {
    OWNER = 'owner'
}

export enum QueryType {
    INSERT = 'INSERT',
    UPDATE = 'UPDATE',
    SELECT = 'SELECT',
    DELETE = 'DELETE',
}

export enum DatabaseType {
    MYSQL = 'mysql',
    ORACLE = 'oracle',
    POSTGRE_SQL = 'postgresql',
    MSSQL = 'mssql',
    MONGO_DB = 'mongodb',
    MARIA_DB = 'mariadb',
    SQLITE = 'sqlite'
}

export enum Days {
    MONDAY = 'monday',
    TUESDAY = 'tuesday',
    WEDNESDAY = 'wednesday',
    THURSDAY =  'thursday',
    FRIDAY = 'friday',
    SATURDAY = 'saturday',
    SUNDAY = 'sunday'
}

export enum StatusType {
    ERROR = 'error',
    SUCCESS = 'success',
    WARN = 'warning'
}
