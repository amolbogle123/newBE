import {IAccountConfig} from "./account-config";

export class MsSql {

    public host?: string;
    public user?: string;
    public password?: string;
    public server?: string;

    public options: any;
    public arrayRowMode: boolean;

    constructor(accountConfig: IAccountConfig) {

        this.host = accountConfig.dbHost || '';
        this.user = accountConfig.dbUser || '';
        this.password = accountConfig.dbPassword || '';
        this.server = accountConfig.dbName || '';

        this.arrayRowMode = true;
        this.options = {
            arrayRowMode: true,
            encrypt: true, // for azure
            trustServerCertificate: true, // change to true for local dev / self-signed certs
        };

    }
}


export class MySql {

    public multipleStatements: boolean;

    public host?: string;
    public user?: string;
    public password?: string;
    public database?: string;

    constructor(accountConfig: IAccountConfig) {

        this.host = accountConfig.dbHost || '';
        this.user = accountConfig.dbUser || '';
        this.password = accountConfig.dbPassword || '';
        this.database = accountConfig.dbName || '';
        this.multipleStatements = true;
    }
}




