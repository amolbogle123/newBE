import {DatabaseType} from "./enums";


export class AccountConfig {

    public dbType?: DatabaseType | string;
    public dbHost?: string;
    public dbUser?: string;
    public dbPassword?: string;
    public dbName?: string;

    constructor(accountConfig: IAccountConfig) {

        this.dbHost = accountConfig.dbHost || '';
        this.dbType = accountConfig.dbType || '';
        this.dbUser = accountConfig.dbUser || '';
        this.dbPassword = accountConfig.dbPassword || '';
        this.dbName = accountConfig.dbName || '';
    }
}

export interface IAccountConfig extends AccountConfig {
}
