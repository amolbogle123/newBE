import {dbConfiguration} from '../core/config/view360-config';
export = dbConfiguration();
