## Project Setup
This project is a View360 backend application built with Node.js, Express, TypeORM, and MySQL.

### Prerequisites:

Node.js (version 18.12.1 or later) - https://nodejs.org/en \
npm (Node Package Manager) - (usually comes bundled with Node.js) \
MySQL (version 8.0.36 or later) - https://www.mysql.com/ \
MySQL Workbench (optional) - https://dev.mysql.com/downloads/workbench/

### Installation:

1. Clone the repository:
   git clone https://your-repository-url.git
2. Navigate to the project directory:
   cd your-project-name
3. Install dependencies:
   npm install
   This will create a node_modules folder containing all required packages.

### Configuration:

1. #### Environment Variables:

   Create a file named .env in the project root directory.\
   Copy all of the contents from env-sample to.env, replacing the placeholder values with your actual MySQL database connection information:\
      DB_TYPE=mysql\
      DB_HOST=localhost\
      DB_PORT=3306\
      DB_USERNAME=your_username\
      DB_PASSWORD=your_password\
      DB_NAME=your_database_name\
   Important: Never commit your .env file to version control (e.g., Git) to avoid exposing sensitive credentials.

2. #### Database Creation:

   Open MySQL Workbench or your preferred MySQL client.\
   Create a database schema named your_database_name (replace with your desired name).
   
   In MySQL Workbench: Right-click on the "Schemas" panel in the navigator and select "Create Schema...".\
   Using SQL command:
   ```CREATE DATABASE IF NOT EXISTS your_database_name;```

3. #### Intialize Database:

   To create database tables based on your TypeORM entities (models), run:\
   ```npm run typeorm:migrate:run:local```

4. #### Seeding:

   To seed database, run:\
   ```npm run typeorm:seed```\
   This will execute your seed files (located in the src/database/seeds directory).

### Running the Application:

1. Generate routes and api documentation\
   ```npm run tsoa:build```
3. Deletes all JavaScript files (.js extension) within the src directory and its subdirectories \
   ```npm run clean```
2. Start the development server:\
   ```npm run dev```\
   This will typically start the server on port 8080 (as per EXPRESS_PORT in .env file)



### Additional Notes:

   Refer to the package.json file for available scripts and additional configuration options.\
   Consider using a linter and code formatter (like ESLint and Prettier) to maintain consistent code style and quality.\
   Implement unit tests for your backend logic.
