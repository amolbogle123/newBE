import { ThemeBuilderHelper } from '../../../src/modules/theme/utils/helpers/theme-builder.helper';
import { CSS_CONFIG, CSS_FILE_PATH } from "../../../src/modules/theme/utils/constants/theme-builder.constant";
import { ThemeBuilder } from '../../../src/entities/theme-builder';
import { dataSource } from '../../../src/core/data-source';
import fs from 'fs';
// Mock fs module
jest.mock('fs');
const mockFs = fs as jest.Mocked<typeof fs>;
describe('ThemeBuilderHelper', () => {
  let themeBuilderHelper: ThemeBuilderHelper;
  const dataSet = {
    "sidebarLayout": "flat",
    "siteInfo": {
      "logo": "assets/img/logo.png",
      "logoSmall": "assets/img/logo-small.png"
    },
    "fontInfo": {
      "fontFamily": "Poppins",
      "customFont": "",
      "customFontName": "",
      "fontSize": "14px",
      "lineHeight": "default",
      "letterSpacing": "default"
    },
    "siteTheme": {
      "themeName": "default",
      "btnThemeName": "default",
      "colorTheme": "light",
      "header": {
        "backgroundColor": "#fff",
        "color": "#3F4254",
        "hoverBgColor": "#000",
        "hoverColor": "#000",
        "activeBgColor": "#00000000",
        "activeColor": "#1580c2"
      },
      "sidebar": {
        "backgroundColor": "#fff",
        "color": "#3F4254",
        "hoverBgColor": "#000",
        "hoverColor": "#000",
        "activeBgColor": "#00000000",
        "activeColor": "#1580c2"
      },
      "btnThemes": {
        "default": {
          "textColor": "#ffffff",
          "borderColor": "#0b7ac6",
          "backgroundColor": "#0b7ac6"
        },
        "primary": {
          "textColor": "#ffffff",
          "borderColor": "#007bff",
          "backgroundColor": "#007bff"
        },
        "secondary": {
          "textColor": "#ffffff",
          "borderColor": "#6c757d",
          "backgroundColor": "#6c757d"
        },
        "dark": {
          "textColor": "#ffffff",
          "borderColor": "#343a40",
          "backgroundColor": "#343a40"
        },
        "danger": {
          "textColor": "#ffffff",
          "borderColor": "#dc3545",
          "backgroundColor": "#dc3545"
        },
        "light": {
          "textColor": "#212529",
          "borderColor": "#f8f9fa",
          "backgroundColor": "#f8f9fa"
        },
        "warning": {
          "textColor": "#212529",
          "borderColor": "#ffc107",
          "backgroundColor": "#ffc107"
        },
        "success": {
          "textColor": "#ffffff",
          "borderColor": "#28a745",
          "backgroundColor": "#28a745"
        },
        "info": {
          "textColor": "#ffffff",
          "borderColor": "#17a2b8",
          "backgroundColor": "#17a2b8"
        }
      },
      "tableTheme": {
        "textColor": "#212529",
        "backgroundColor": "#ffffff",
        "borderColor": "#dee2e6",
        "headerBgColor": "#eaf1fb",
        "headerTextColor": "#212529",
        "headerTextWeight": "500"
      },
      "editors": {
        "textBox": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#ced4da",
          "placeholderColor": "#a9acaf",
          "borderFocusColor": "#80bdff"
        },
        "selectList": {
          "backgroundColor": "#ffffff"
        },
        "calendar": {
          "textColor": "#212529",
          "backgroundColor": "#ffffff",
          "borderColor": "#ced4da"
        }
      },
      "tabs": {
        "textColor": "#212529",
        "backgroundColor": "#ffffff",
        "borderColor": "#c2cfdd",
        "activeTextColor": "#212529",
        "activeBackgroundColor": "#eaf1fb",
        "activeBorderColor": "#0b7ac6"
      },
      "modal": {
        "headerTextColor": "#212529",
        "headerBackgroundColor": "#ffffff",
        "headerBorderColor": "#dedede",
        "bodyTextColor": "#212529",
        "bodyBackgroundColor": "#ffffff",
        "bodyBorderColor": "#dedede"
      }
    }
  };
  // Mock the functions and objects used by the ThemeBuilderHelper class
  const mockFs = {
    existsSync: jest.fn(),
    mkdirSync: jest.fn(),
    writeFileSync: jest.fn(),
  };

  const mockDataSource = {
    manager: {
      save: jest.fn(),
    },
  };

  beforeEach(() => {
    themeBuilderHelper = new ThemeBuilderHelper();
    (dataSource.manager.save as jest.Mock).mockResolvedValue({ id: 1 }); // Mock the save function
    jest.spyOn(fs, 'existsSync').mockImplementation(mockFs.existsSync);
    jest.spyOn(fs, 'mkdirSync').mockImplementation(mockFs.mkdirSync);
    jest.spyOn(fs, 'writeFileSync').mockImplementation(mockFs.writeFileSync);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  // it('should set up theme settings', async () => {
  //   const clientid = 123;
  //   const result = await themeBuilderHelper.setupThemeSettings(clientid);

  //   expect(result).toEqual(
  //     {
  //       status: true,
  //       data: {
  //         client_id: 123,
  //         config: "{\"id\":\"default\",\"name\":\"default\",\"img\":\"#0b7ac6\",\"data\":{\"sidebarLayout\":\"flat\",\"siteInfo\":{\"logo\":\"assets/img/logo.png\",\"logoSmall\":\"assets/img/logo-small.png\"},\"fontInfo\":{\"fontFamily\":\"Poppins\",\"customFont\":\"\",\"customFontName\":\"\",\"fontSize\":\"14px\",\"lineHeight\":\"default\",\"letterSpacing\":\"default\"},\"siteTheme\":{\"themeName\":\"default\",\"btnThemeName\":\"default\",\"colorTheme\":\"light\",\"header\":{\"backgroundColor\":\"#fff\",\"color\":\"#3F4254\",\"hoverBgColor\":\"#000\",\"hoverColor\":\"#000\",\"activeBgColor\":\"#00000000\",\"activeColor\":\"#1580c2\"},\"sidebar\":{\"backgroundColor\":\"#fff\",\"color\":\"#3F4254\",\"hoverBgColor\":\"#000\",\"hoverColor\":\"#000\",\"activeBgColor\":\"#00000000\",\"activeColor\":\"#1580c2\"},\"btnThemes\":{\"default\":{\"textColor\":\"#ffffff\",\"borderColor\":\"#0b7ac6\",\"backgroundColor\":\"#0b7ac6\"},\"primary\":{\"textColor\":\"#ffffff\",\"borderColor\":\"#007bff\",\"backgroundColor\":\"#007bff\"},\"secondary\":{\"textColor\":\"#ffffff\",\"borderColor\":\"#6c757d\",\"backgroundColor\":\"#6c757d\"},\"dark\":{\"textColor\":\"#ffffff\",\"borderColor\":\"#343a40\",\"backgroundColor\":\"#343a40\"},\"danger\":{\"textColor\":\"#ffffff\",\"borderColor\":\"#dc3545\",\"backgroundColor\":\"#dc3545\"},\"light\":{\"textColor\":\"#212529\",\"borderColor\":\"#f8f9fa\",\"backgroundColor\":\"#f8f9fa\"},\"warning\":{\"textColor\":\"#212529\",\"borderColor\":\"#ffc107\",\"backgroundColor\":\"#ffc107\"},\"success\":{\"textColor\":\"#ffffff\",\"borderColor\":\"#28a745\",\"backgroundColor\":\"#28a745\"},\"info\":{\"textColor\":\"#ffffff\",\"borderColor\":\"#17a2b8\",\"backgroundColor\":\"#17a2b8\"}},\"tableTheme\":{\"textColor\":\"#212529\",\"backgroundColor\":\"#ffffff\",\"borderColor\":\"#dee2e6\",\"headerBgColor\":\"#eaf1fb\",\"headerTextColor\":\"#212529\",\"headerTextWeight\":\"500\"},\"editors\":{\"textBox\":{\"textColor\":\"#212529\",\"backgroundColor\":\"#ffffff\",\"borderColor\":\"#ced4da\",\"placeholderColor\":\"#a9acaf\",\"borderFocusColor\":\"#80bdff\"},\"selectList\":{\"backgroundColor\":\"#ffffff\"},\"calendar\":{\"textColor\":\"#212529\",\"backgroundColor\":\"#ffffff\",\"borderColor\":\"#ced4da\"}},\"tabs\":{\"textColor\":\"#212529\",\"backgroundColor\":\"#ffffff\",\"borderColor\":\"#c2cfdd\",\"activeTextColor\":\"#212529\",\"activeBackgroundColor\":\"#eaf1fb\",\"activeBorderColor\":\"#0b7ac6\"},\"modal\":{\"headerTextColor\":\"#212529\",\"headerBackgroundColor\":\"#ffffff\",\"headerBorderColor\":\"#dedede\",\"bodyTextColor\":\"#212529\",\"bodyBackgroundColor\":\"#ffffff\",\"bodyBorderColor\":\"#dedede\"}}}}",
  //         id: 1,
  //       },
  //     }
  //   );
  //   expect(dataSource.manager.save).toHaveBeenCalledWith(expect.any(ThemeBuilder));
  //   expect(fs.mkdirSync).toHaveBeenCalled();
  //   expect(fs.writeFileSync).toHaveBeenCalled();
  // });


  it('should create CSS file when directory does not exist', async () => {
    const helper = new ThemeBuilderHelper();
    
    const clientid = 'your-client-id';
    
    // Mock fs.existsSync to return false
    mockFs.existsSync.mockReturnValue(false);

    // Mock fs.mkdirSync to do nothing (for directory creation)
    // mockFs.mkdirSync.mockReturnValue();

    // // Mock fs.writeFileSync to do nothing (for file creation)
    // mockFs.writeFileSync.mockReturnValue();

    const result = await helper.createCssFile(dataSet, clientid);

    expect(result.status).toBe(true);
    // Add assertions to check if file was written correctly and directory was created
  });


  it('should create CSS file', async () => {
    const clientid = 123;

    const result = await themeBuilderHelper.createCssFile(dataSet, clientid);

    expect(result).toEqual({
      status: true,
      filePath: "public/theme-builder/123-theme.css",
    });
    expect(fs.mkdirSync).toHaveBeenCalled();
    expect(fs.writeFileSync).toHaveBeenCalled();
  });


  // it('should create a CSS file with other themes', async () => {
  //   // Arrange
  //   const helper = new ThemeBuilderHelper();
  //   const dataSet = {
  //     data:{
  //     siteTheme: {
  //       otherTheme: {
  //         borderRadius: 5,
  //         typography: 'Arial, sans-serif',
  //         fontSize: 16,
  //       },
  //       // Add more themes as needed
  //     }}
  //     // Add other site themes if necessary
  //   };
  //   const clientid = 'your-client-id';

  //   // Mock fs functions
  //   mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
  //   mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
  //   mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

  //   // Act
  //   const result = await helper.createCssFile(dataSet, clientid);

  //   // Assert
  //   expect(result.status).toBe(true);
  //   // You can add more assertions to check the file content, file path, etc.
  // });


  it('should create a CSS file with modal ', async () => {
    // Arrange
    const helper = new ThemeBuilderHelper();
    const clientid = 'your-client-id';

    // Mock fs functions
    mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
    mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
    mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

    // Act
    const result = await helper.createCssFile(dataSet, clientid);

    // Assert
    expect(result.status).toBe(true);
    // You can add more assertions to check the file content, file path, etc.
  });

  it('should create a CSS file with button themes', async () => {
    // Arrange
    const helper = new ThemeBuilderHelper();
    const clientid = 'your-client-id';

    // Mock fs functions
    mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
    mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
    mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

    // Act
    const result = await helper.createCssFile(dataSet, clientid);

    // Assert
    expect(result.status).toBe(true);
    // You can add more assertions to check the file content, file path, etc.
  });


  it('should create a CSS file with component themes', async () => {
    // Arrange
    const helper = new ThemeBuilderHelper();
    const clientid = 'your-client-id';

    // Mock fs functions
    mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
    mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
    mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

    // Act
    const result = await helper.createCssFile(dataSet, clientid);

    // Assert
    expect(result.status).toBe(true);
    // You can add more assertions to check the file content, file path, etc.
  });

  it('should create a CSS file with input  themes', async () => {
    // Arrange
    const helper = new ThemeBuilderHelper();
    const clientid = 'your-client-id';

    // Mock fs functions
    mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
    mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
    mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

    // Act
    const result = await helper.createCssFile(dataSet, clientid);

    // Assert
    expect(result.status).toBe(true);
    // You can add more assertions to check the file content, file path, etc.
  });

  // it('should create a CSS file with sectionTheme  themes', async () => {
  //   // Arrange
  //   const helper = new ThemeBuilderHelper();
  //   const dataSet = {
  //     data:{
  //     siteTheme: {
  //       sectionTheme: {
  //         default: {
  //           backgroundColor: 'red',
  //           textColor: 'white',
  //           borderColor: 'black',
  //         },
  //         header: {
  //           backgroundColor: 'red',
  //           textColor: 'white',
  //           borderColor: 'black',
  //         },
  //         footer: {
  //           backgroundColor: 'red',
  //           textColor: 'white',
  //           borderColor: 'black',
  //         },
  //         sidebar: {
  //           backgroundColor: 'red',
  //           textColor: 'white',
  //           borderColor: 'black',
  //         },
  //         // Add more button themes as needed
  //       },
  //       // Add other site themes if necessary
  //     },}
  //   };
  //   const clientid = 'your-client-id';

  //   // Mock fs functions
  //   mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
  //   mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
  //   mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

  //   // Act
  //   const result = await helper.createCssFile(dataSet, clientid);

  //   // Assert
  //   expect(result.status).toBe(true);
  //   // You can add more assertions to check the file content, file path, etc.
  // });


  // it('should create a CSS file with tableTheme  themes', async () => {
  //   // Arrange
  //   const helper = new ThemeBuilderHelper();
  //   const dataSet = {
  //     data:{
  //     siteTheme: {
  //       sectionTheme: {
  //         default: {
  //           backgroundColor: 'red',
  //           textColor: 'white',
  //           borderColor: 'black',
  //         },
  //         header: {
  //           backgroundColor: 'red',
  //           textColor: 'white',
  //           borderColor: 'black',
  //         },
  //         footer: {
  //           backgroundColor: 'red',
  //           textColor: 'white',
  //           borderColor: 'black',
  //         },
  //         // Add more button themes as needed
  //       },
  //       // Add other site themes if necessary
  //     },
  //   }
  //   };
  //   const clientid = 'your-client-id';

  //   // Mock fs functions
  //   mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
  //   mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
  //   mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

  //   // Act
  //   const result = await helper.createCssFile(dataSet, clientid);

  //   // Assert
  //   expect(result.status).toBe(true);
  //   // You can add more assertions to check the file content, file path, etc.
  // });


  it('should create a CSS file with editors  themes', async () => {
    // Arrange
    const helper = new ThemeBuilderHelper();
    const clientid = 'your-client-id';

    // Mock fs functions
    mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
    mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
    mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

    // Act
    const result = await helper.createCssFile(dataSet, clientid);

    // Assert
    expect(result.status).toBe(true);
    // You can add more assertions to check the file content, file path, etc.
  });


  it('should create a CSS file with tabs  themes', async () => {
    // Arrange
    const helper = new ThemeBuilderHelper();
    const clientid = 'your-client-id';

    // Mock fs functions
    mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
    mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
    mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

    // Act
    const result = await helper.createCssFile(dataSet, clientid);

    // Assert
    expect(result.status).toBe(true);
    // You can add more assertions to check the file content, file path, etc.
  });

  // it('should create a CSS file with button themes', async () => {
  //   // Arrange
  //   const helper = new ThemeBuilderHelper();
  //   const dataSet = {
  //     siteTheme: {
  //       btnThemes: {
  //         default: {
  //           backgroundColor: 'red',
  //           textColor: 'white',
  //           borderColor: 'black',
  //         },
  //         // Add more button themes as needed
  //       },
  //       // Add other site themes if necessary
  //     },
  //   };
  //   const clientid = 'your-client-id';

  //   // Mock fs functions
  //   mockFs.existsSync.mockReturnValueOnce(false); // Directory doesn't exist
  //   mockFs.mkdirSync.mockReturnValueOnce(undefined); // Mock directory creation
  //   mockFs.writeFileSync.mockReturnValueOnce(undefined); // Mock file creation

  //   // Act
  //   const result = await helper.createCssFile(dataSet, clientid);

  //   // Assert
  //   expect(result.status).toBe(true);
  //   // You can add more assertions to check the file content, file path, etc.
  // });
  
  // it('should handle  case  file', async () => {
  //   const dataSet = {}; // Provide the data needed for testing
  //   const clientid = 123;
  //   const expectedFilePath = 'path-to-css-file';

  //   const result = await themeBuilderHelper.createCssFile(dataSet, clientid);

  //   expect(result).toEqual({ status: true, filePath: expectedFilePath });
  //   expect(fs.mkdirSync).toHaveBeenCalled();
  //   expect(fs.writeFileSync).toHaveBeenCalled();
  // });

  // it('should set up theme settings with unsuccessful save', async () => {
  //   const clientid = 123;
  //   const expectedApiResponse = { status: false, data: {} };

  //   (dataSource.manager.save as jest.Mock).mockResolvedValue(null); // Simulate unsuccessful save

  //   const result = await themeBuilderHelper.setupThemeSettings(clientid);

  //   expect(result).toEqual(expectedApiResponse);
  //   expect(dataSource.manager.save).toHaveBeenCalledWith(expect.any(ThemeBuilder));
  //   expect(fs.mkdirSync).not.toHaveBeenCalled(); // Verify that fs functions were not called
  //   expect(fs.writeFileSync).not.toHaveBeenCalled();
  // });
});
