import { ThemeBuilderController } from "../../../src/modules/theme/controllers/theme-builder.controller";
describe('ThemeBuilderController', () => {
    let controller: ThemeBuilderController;
    beforeAll(async () => {
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new ThemeBuilderController();
    });
    it('should be defined', () => {
        expect(controller).toBeDefined();
    });
    it('should get theme', async () => {
        const request = {
            userDetails: {
                client_id: 1,
            }
        }
        const result = await controller.getDetails(request);
        expect(result).toBeDefined();
    });

    it('should update theme', async () => {
        const request = {
            userDetails: {
                client_id: 1,
            }
        }
        const requestBody = {
            "config": {}
        }

        const result = await controller.updateDeatils(requestBody, request);
        expect(result).toBeDefined();
    });

    it('should get all themes', async () => {
        const request = {
            userDetails: {
                client_id: 1,
            }
        }
        const result = await controller.getAllThemes(request);
        expect(result).toBeDefined();
    });

    it('should delete theme', async () => {
        const request = {
            userDetails: {
                client_id: 1,
            }
        }
        const result = await controller.deleteSetting(request,{id:1});
        expect(result).toBeDefined();
    });
});