import { dataSource } from "../../../src/core/data-source";
import { CustomComponentEnhancerController } from "../../../src/modules/theme/controllers/custom-component-enhancer.controller";
import { ThemeBuilderHelper } from "../../../src/modules/theme/utils/helpers/theme-builder.helper";
describe("CustomComponentEnhancerController", () => {
    let controller: CustomComponentEnhancerController;
    beforeAll(() => {
        jest.clearAllMocks();
        controller = new CustomComponentEnhancerController();
    });
    it('should be defined', () => {
        expect(controller).toBeDefined();
    });

    it('should save enhancer', async () => {
        const requestBody = {
            config: {
                data: {
                    name: "test",
                    type: "test",
                    config: {
                        test: "test"
                    }
                }
            }
        }
        const request = {
            userDetails: {
                client_id: "test"
            }
        }
        dataSource.getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockReturnValue({
                where: jest.fn().mockReturnValue({
                    client_id: "test",
                    themes:[{
                        name: "test",
                    }]
                })
            }),
            update: jest.fn().mockReturnValue({
                where: jest.fn().mockReturnValue({
                    client_id: "test"
                })
            })
        });
        ThemeBuilderHelper.prototype.createCssFile = jest.fn().mockReturnValue({
            filePath: "test",
            status: true
        });
        const result = await controller.save(requestBody, request);
        expect(result).toBeDefined();
    });

    it('should get enhancer', async () => {
        const request = {
            userDetails: {
                client_id: "test"
            }
        }
        const result = await controller.get(request);
        expect(result).toBeDefined();
    });

    it('should update enhancer', async () => {
        const requestBody = {
            config: {
                data: {
                    name: "test",
                    type: "test",
                    config: {
                        test: "test"
                    }
                }
            }
        }
        const request = {
            userDetails: {
                client_id: "test"
            }
        }
        const result = await controller.update(requestBody, request);
        expect(result).toBeDefined();
    });

    it('should update enhancer css', async () => {
        const requestBody = {
            config: {
                data: {
                    name: "test",
                    type: "test",
                    config: {
                        test: "test"
                    }
                }
            }
        }
        const request = {
            userDetails: {
                client_id: "test"
            }
        }
        const result = await controller.updateCss(requestBody, request);
        expect(result).toBeDefined();
    });

});