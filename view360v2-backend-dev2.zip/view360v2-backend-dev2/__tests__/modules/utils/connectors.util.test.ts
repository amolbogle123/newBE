import { dataSource } from "../../../src/core/data-source";
import { ConnectorsUtil } from "../../../src/utils/connectors.util";
describe('ConnectorsUtil', () => {
    describe('connect', () => {
        it('should call connect', () => {
            const widgetAccount = {};
            const widgetAccountConfig = { dbType: 'abc' };
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOneBy: jest.fn().mockReturnValue({
                    id: '123',
                    config: {
                        dbType: 'abc',
                        host: 'abc',
                        port: 'abc',
                        username: 'abc',
                        password: 'abc',
                        database: 'abc',
                    }
                }),
            });
            const result = ConnectorsUtil.connect(widgetAccount, 'queryToExecute', widgetAccountConfig);
            expect(result).toBeTruthy();
        });
        it('should call connect', () => {
            const widgetAccount = {};
            const widgetAccountConfig = {};
            const result = ConnectorsUtil.connect(widgetAccount, 'queryToExecute', widgetAccountConfig);
            expect(result).toBeTruthy();
        });
        it('should call connect', () => {
            const widgetAccount = {};
            const widgetAccountConfig = { dbType: 'MSSQL' };
            const result = ConnectorsUtil.connect(widgetAccount, 'queryToExecute', widgetAccountConfig);
            expect(result).toBeTruthy();
        });
        it('should call connect', () => {
            const widgetAccount = {};
            const widgetAccountConfig = { dbType: 'MYSQL' };
            const result = ConnectorsUtil.connect(widgetAccount, 'queryToExecute', widgetAccountConfig);
            expect(result).toBeTruthy();
        });
        it('should call connect', () => {
            const result = ConnectorsUtil.connect('', '', '');
            expect(result).toBeTruthy();
        });
    });

    describe('apiConnector', () => {
        it('should call apiConnector', () => {
            let connectors = { rows: ['aa', 'bb'] };
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOneBy: jest.fn().mockReturnValue(connectors),
                find: jest.fn().mockReturnValue(connectors),
            });
            const result = ConnectorsUtil.apiConnector('connectorId');
            expect(result).toBeTruthy();
        });


        it('should call apiConnector', () => {
            const response: any = { status: false, data: [], message: '' };
            let connectorConfig: any = {}
            let connectors = { rows: ['aa', 'bb'] };
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOneBy: jest.fn().mockReturnValue(connectors),
                find: jest.fn().mockReturnValue(connectors),
            });
            const result = ConnectorsUtil.apiConnector('connectorId');
            expect(result).toBeTruthy();
        });

        // it('should call apiConnector', () => {
        //     const result = ConnectorsUtil.apiConnector('');
        //     expect(result).toBeTruthy();
        // });
    });

    describe('testDBConnection', () => {
        it('should call testDBConnection', async () => {
            const accountConfig = { dbType: null };
            const result = ConnectorsUtil.testDBConnection('queryToExecute', accountConfig);
            await expect(result).resolves.toEqual({ status: false, message: 'Provide Connector.' });
        });

        it('should call testDBConnection MSSQL', async () => {
            const accountConfig = {
                dbType: 'MSSQL',
                user: 'abc',
                password: 'abc',
                server: 'abc',
                database: 'abc',
                port: 'abc',
                options: { encrypt: true, enableArithAbort: true, trustServerCertificate: true }
            };
            const result = ConnectorsUtil.testDBConnection('queryToExecute', accountConfig);
            result.then((res: any) => {
                expect(res.status).toEqual(true);
                expect(res.message).toEqual({});
                expect(res.data).toBeDefined();
            });

        });

        it('should call testDBConnection for MYSQL', async () => {
            const accountConfig = {
                dbType: 'MYSQL',
                user: 'abc',
                password: 'abc',
                server: 'abc',
                database: 'abc',
                port: 'abc',
                options: { encrypt: true, enableArithAbort: true, trustServerCertificate: true }
            };
            const result = ConnectorsUtil.testDBConnection('queryToExecute', accountConfig);
            result.then((res: any) => {
                expect(res.status).toEqual(true);
                expect(res.message).toEqual("Connection successful");
                expect(res.data).toBeDefined();
            });

        });

        // it('should call testDBConnection for MONGODB',async () => {
        //     const accountConfig = {dbType: 'MONGODB' };
        //     const result = ConnectorsUtil.testDBConnection('queryToExecute',accountConfig) ;
        //     expect(result).toBeTruthy();
        // });
    });
});
