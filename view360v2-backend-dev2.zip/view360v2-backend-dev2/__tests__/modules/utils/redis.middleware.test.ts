import { Redis } from "ioredis";
import { cacheMiddleware, cacheResponseData, getAllKeyValues } from "../../../src/utils/redis.middleware";
describe('cacheMiddleware', () => {
    describe('cacheMiddleware', () => {
        beforeAll(() => {
            process.env.REDIS_ENABLE = 'true';
        });
        it('should call cacheMiddleware with req.method as PUT', () => {

            const req: any = { method: 'PUT', originalUrl: '', url: '' }; // You can customize the req object as needed
            const res: any = {
                json: jest.fn(),
            };
            const next = jest.fn();
            Redis.prototype.flushdb = jest.fn().mockImplementationOnce(() => {
                return Promise.resolve();
            });
            const result = cacheMiddleware(req, res, next);
            expect(result).toBeTruthy();
        });
        it('should call cacheMiddleware with req.method as POST', () => {

            const req: any = { method: 'POST', originalUrl: '', url: '/dynamic-dashboard/form-chart' }; // You can customize the req object as needed
            const res: any = {
                json: jest.fn(),
            };
            const next = jest.fn();
            const result = cacheMiddleware(req, res, next);
            expect(result).toBeTruthy();
        });
        it('should call cacheMiddleware with req.method as GET', () => {

            const req: any = { method: 'GET', originalUrl: '', url: '/dynamic-dashboard/form-chart' }; // You can customize the req object as needed
            const res: any = {
                json: jest.fn(),
            };
            const next = jest.fn();
            Redis.prototype.get = jest.fn().mockImplementationOnce((key, callback) => {
                return Promise.resolve({
                    "data": "data"
                });
            });
            const result = cacheMiddleware(req, res, next);
            expect(result).toBeTruthy();
        });

    });
});

describe('cacheResponseData', () => {
    describe('cacheResponseData', () => {
        it('should call cacheResponseData', () => {
            Redis.prototype.set = jest.fn().mockImplementationOnce((key, value) => {
                return Promise.resolve();
            });
            Redis.prototype.quit = jest.fn().mockImplementationOnce(() => {
                return Promise.resolve();
            });
            const responseData = {}; // You can customize the req object as needed
            const result = cacheResponseData('key', responseData);
            expect(result).toBeTruthy();
        });
    });
});

describe('getAllKeyValues', () => {
    describe('getAllKeyValues', () => {
        it('should call getAllKeyValues', () => {
            Redis.prototype.scan = jest.fn().mockImplementationOnce(() => {
                return Promise.resolve(['0', ['key1']]);
            });
            Redis.prototype.get = jest.fn().mockImplementationOnce((key, callback) => {
                return Promise.resolve(JSON.stringify({
                    "data": "data"
                }));
            });

            const result = getAllKeyValues();
            expect(result).toBeTruthy();
        });
    });
});
