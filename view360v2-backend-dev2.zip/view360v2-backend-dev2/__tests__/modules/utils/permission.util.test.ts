import {PermissionUtil} from "../../../src/utils/permission.util";
import Container from "typedi";
import {UserRoles} from "../../../src/entities";
import dbService from "../../../src/services/db.service";
import _ from "lodash";
import {DataSource} from "typeorm";
describe('PermissionUtil', () => {
    it('should check permission with superadmin role', async () => {
        Container.get(DataSource).getRepository(UserRoles).findOne = jest.fn().mockResolvedValueOnce({
            permissions: [
                {
                    name: 'test'
                }
            ]
        });
        dbService._findQueryService = jest.fn().mockResolvedValueOnce({
            data: [
                {
                    name: 'test'
                }
            ]
        });
        const req = {
            userDetails: {
                role_id: 1,
                client_id: 1,
                is_superadmin: 1
            }
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn().mockReturnThis()
        };
        const next = jest.fn();
        await PermissionUtil.checkPermission('test')(req, res, next);
        expect(next).toHaveBeenCalledTimes(1);
    });
    it('should check permission with non superadmin role', async () => {
        Container.get(DataSource).getRepository(UserRoles).findOne = jest.fn().mockResolvedValueOnce({
            permissions: [
                {
                    name: 'test',
                    permission: JSON.stringify({
                        test: true,
                        test1: false
                    })
                }
            ]
        });
        dbService._findQueryService = jest.fn().mockResolvedValueOnce( [
                {
                    name: 'test',
                    permission: JSON.stringify({
                        test: true,
                        test1: false
                    })

                }
            ]
        );
        const req = {
            userDetails: {
                role_id: 1,
                client_id: 1,
                is_superadmin: 0
            }
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn().mockReturnThis()
        };
        const next = jest.fn();
        await PermissionUtil.checkPermission('test')(req, res, next);
    });
});