import {CommonUtil} from "../../../src/utils/common.util";

describe('CommonUtil', () => {
    describe('getOriginUrl', () => {
        it('should call getOriginUrl', () => {
            const result = CommonUtil.getOriginUrl('123');
            expect(result).toBeDefined();
        });
    });

    describe('getTableSubmittedData', () => {
        it('should call getTableSubmittedData', () => {
            const result = CommonUtil.getTableSubmittedData([], '123', '123');
            expect(result).toBeDefined();
        });
    });

    describe('getSubmittedData', () => {
        it('should call getSubmittedData', () => {
            const result = CommonUtil.getSubmittedData([], '123', '123');
            expect(result).toBeDefined();
        });
    });

    describe('getConditionalQuery', () => {
        it('for equals', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'equals','abc' ,'json');
            expect(result).toEqual(result);
        });
        it('for equals', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'equals','abc' ,'operator');
            expect(result).toEqual(result);
        });
        it('for equals', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'equals','abc' ,'');
            expect(result).toEqual(result);
        });

        it('for greater', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'greater','abc' ,'json');
            expect(result).toEqual(result);
        });
        it('for greater', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'greater','abc' ,'operator');
            expect(result).toEqual(result);
        });
        it('for greater', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'greater','abc' ,'');
            expect(result).toEqual(result);
        });

        it('for greater_equals', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'greater_equals','abc' ,'json');
            expect(result).toEqual(result);
        });
        it('for greater_equals', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'greater_equals','abc' ,'operator');
            expect(result).toEqual(result);
        });
        it('for greater_equals', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'greater_equals','abc' ,'');
            expect(result).toEqual(result);
        });

        it('for less', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'less','abc' ,'json');
            expect(result).toEqual(result);
        });
        it('for less', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'less','abc' ,'operator');
            expect(result).toEqual(result);
        });
        it('for less', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'less','abc' ,'');
            expect(result).toEqual(result);
        });

        it('for less_equals', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'less_equals','abc' ,'json');
            expect(result).toEqual(result);
        });
        it('for less_equals', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'less_equals','abc' ,'operator');
            expect(result).toEqual(result);
        });
        it('for less_equals', () => {
            const result = CommonUtil.getConditionalQuery('abc', 'less_equals','abc' ,'');
            expect(result).toEqual(result);
        });

        // it('for default', () => {
        //     const result = CommonUtil.getConditionalQuery('abc', '','abc' ,'');
        //     expect(result).toEqual(result);
        // });
    });

    describe('isNotNull', () => {
        it('should call isNotNull', () => {
            const result = CommonUtil.isNotNull('123');
            expect(result).toBeDefined();
        });
    });

    describe('isNullOrEmpty', () => {
        it('should call isNullOrEmpty', () => {
            const result = CommonUtil.isNullOrEmpty('123');
            expect(result).toBeDefined();
        });
    });

    describe('isTrue', () => {
        it('should call isTrue', () => {
            const result = CommonUtil.isTrue('123');
            expect(result).toBeDefined();
        });
    });
});
