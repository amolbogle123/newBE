import {Crypto} from  "../../../src/utils/crypto";
import {readJWT} from "../../../src/utils/readJWTData.util";
import jwt from 'jsonwebtoken';
jest.mock('crypto', () => ({
    createHash: jest.fn(() => ({
        update: jest.fn().mockReturnThis(),
        digest: jest.fn().mockReturnValue('mockedHash'), // Mocked hash value
    })),
    createDecipheriv: jest.fn(() => ({
        update: jest.fn().mockReturnValue('mockedDecryptedText'), // Mocked decrypted text
        final: jest.fn().mockReturnValue(''), // No more data to decrypt
    })),
    createCipheriv: jest.fn(() => ({
        update: jest.fn().mockReturnValue('mockedEncryptedText'), // Mocked encrypted text
        final: jest.fn().mockReturnValue(''), // No more data to encrypt
    })),
}));
jest.mock('objectPath', () => ({
    get: jest.fn().mockReturnValue({
        data: {
            public: {
                id: '123',
            },
            encData: 'mockedEncryptedData',
        },
    }),
}));
jest.mock('jsonwebtoken', () => ({
    decode: jest.fn().mockReturnValue({
        data: {
            public: {
                id: '123',
            },
            encData: 'mockedEncryptedData',
        },
    }),
}));
describe('readJWT', () => {
    it('should successfully read JWT', () => {
        Crypto.serializeDecr = jest.fn().mockReturnValue({
            id: '123',
        });
        // Mock jwt.decode to return the mocked data
        jwt.decode = jest.fn().mockReturnValue({
            data: {
                public: {
                    id: '123',
                },
                encData: 'mockedEncryptedData',
            },
        });
        // Call the function
        readJWT('mockedToken', JSON.stringify({
            algorithm: 'mockedAlgorithm',
            key: 'mockedKey',
            ivLength: 16,
        }));
        // Assert that the mocked functions were called with the expected parameters
        expect(jwt.decode).toHaveBeenCalledWith('mockedToken');
        expect(Crypto.serializeDecr).toHaveBeenCalledWith("{\"algorithm\":\"mockedAlgorithm\",\"key\":\"mockedKey\",\"ivLength\":16}", "mockedEncryptedData");


    });
});