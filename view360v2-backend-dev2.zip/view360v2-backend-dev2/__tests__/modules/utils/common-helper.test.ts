import { ObjectId } from "mongodb";
import { StatusType } from "../../../src/models/enums";
import { CommonHelper } from "../../../src/utils/helpers/common.helper";

const fs = require('fs');
const os = require('os');

describe('CommonHelper', () => {
    it('should return an object with provided status, message, and data', () => {
        const status = StatusType.SUCCESS;
        const message = 'This is a test message';
        const data = { someKey: 'someValue' };

        const result = CommonHelper.setResponse(status, message, data);

        expect(result).toEqual({ status, message, data });
    });

    it('should set data to null if not provided', () => {
        const status = StatusType.SUCCESS;
        const message = 'This is a test message';

        const result = CommonHelper.setResponse(status, message);

        expect(result).toEqual({ status, message, data: null });
    });

    it('should handle null message and data', () => {
        const status = StatusType.SUCCESS;

        const result = CommonHelper.setResponse(status);

        expect(result).toEqual({ status, message: null, data: null });
    });

    it('should handle empty data', () => {
        const status = StatusType.SUCCESS;
        const message = 'This is a test message';
        const data = {};

        const result = CommonHelper.setResponse(status, message, data);

        expect(result).toEqual({ status, message, data: null });
    });

    it('should return a response with status code 200 and provided response object', () => {
        const responseObject = {
            message: 'Success message',
            data: { someKey: 'someValue' },
        };
        const mockResponse = {
            status: jest.fn(() => mockResponse),
            json: jest.fn(),
        };

        CommonHelper.apiSuccessResponse(mockResponse, responseObject);

        expect(mockResponse.status).toHaveBeenCalledWith(200);
        expect(mockResponse.json).toHaveBeenCalledWith({
            status: true,
            ...responseObject,
        });
    });

    it('should use default success message if message is empty', () => {
        const responseObject = {
            message: '',
            data: { someKey: 'someValue' },
        };
        const mockResponse = {
            status: jest.fn(() => mockResponse),
            json: jest.fn(),
        };

        CommonHelper.apiSuccessResponse(mockResponse, responseObject);

        expect(mockResponse.status).toHaveBeenCalledWith(200);
        expect(mockResponse.json).toHaveBeenCalledWith({
            status: true,
            message: 'Successfully executed.', // Ensure the default message is used
            data: { someKey: 'someValue' },
        });
    });

    it('should allow custom status code', () => {
        const responseObject = {
            message: 'Success message',
            data: { someKey: 'someValue' },
        };
        const mockResponse = {
            status: jest.fn(() => mockResponse),
            json: jest.fn(),
        };

        CommonHelper.apiSuccessResponse(mockResponse, responseObject, 201);

        expect(mockResponse.status).toHaveBeenCalledWith(201);
        expect(mockResponse.json).toHaveBeenCalledWith({
            status: true,
            ...responseObject,
        });
    });

    it('should return a response with status code 400 and provided response object', () => {
        const responseObject = {
            message: 'Error message',
            error: { error_description: 'Error message' },
        };
        const mockResponse = {
            status: jest.fn(() => mockResponse),
            json: jest.fn(),
        };

        CommonHelper.apiErrorResponse(mockResponse, responseObject);

        expect(mockResponse.status).toHaveBeenCalledWith(400);
        expect(mockResponse.json).toHaveBeenCalledWith({
            status: false,
            ...responseObject,
        });
    });

    it('should use default error message if message is empty', () => {
        const responseObject = {
            message: '',
            error: { error_description: 'Error Message' },
        };
        const mockResponse = {
            status: jest.fn(() => mockResponse),
            json: jest.fn(),
        };

        CommonHelper.apiErrorResponse(mockResponse, responseObject);

        expect(mockResponse.status).toHaveBeenCalledWith(400);
        expect(mockResponse.json).toHaveBeenCalledWith({
            status: false,
            message: 'Something went wrong !', // Ensure the default message is used
            error: {
                error_description: 'Error Message'
            }
        });
    });

    it('should allow custom status code', () => {
        const responseObject = {
            message: 'Error message',
            error: { error_description: 'Something went wrong!' },
        };
        const mockResponse = {
            status: jest.fn(() => mockResponse),
            json: jest.fn(),
        };

        CommonHelper.apiErrorResponse(mockResponse, responseObject, 401);

        expect(mockResponse.status).toHaveBeenCalledWith(401);
        expect(mockResponse.json).toHaveBeenCalledWith({
            status: false,
            ...responseObject,
        });
    });

    it('should return an object with status true and provided response object', () => {
        const responseObject = {
            message: 'Success message',
            data: { someKey: 'someValue' },
        };

        const result = CommonHelper.apiSwaggerSuccessResponse(responseObject);

        expect(result).toEqual({
            status: true,
            ...responseObject,
        });
    });

    it('should use default success message if message is empty', () => {
        const responseObject = {
            message: '',
            data: { someKey: 'someValue' },
        };

        const result = CommonHelper.apiSwaggerSuccessResponse(responseObject);

        expect(result).toEqual({
            status: true,
            message: 'Successfully executed.', // Ensure the default message is used
            data: { someKey: 'someValue' },
        });
    });

    it('should allow custom response status', () => {
        const responseObject = {
            message: 'Success message',
            data: { someKey: 'someValue' },
        };

        const result = CommonHelper.apiSwaggerSuccessResponse(responseObject, false);

        expect(result).toEqual({
            status: false,
            ...responseObject,
        });
    });

    it('should return an object with status false and provided response object', () => {
        const responseObject = {
            message: 'Error message',
            error: { error_description: 'Something went wrong!' },
        };

        const result = CommonHelper.apiSwaggerErrorResponse(responseObject);

        expect(result).toEqual({
            status: false,
            ...responseObject,
        });
    });

    it('should use default error message if message is empty', () => {
        const responseObject = {
            message: '',
            error: { error_description: 'Something went wrong!' },
        };

        const result = CommonHelper.apiSwaggerErrorResponse(responseObject);

        expect(result).toEqual({
            status: false,
            message: 'Something went wrong !', // Ensure the default message is used
            error: {
                error_description: "Something went wrong!"
            }
        });
    });

    it('should allow custom response status', () => {
        const responseObject = {
            message: 'Error message',
            error: { error_description: 'Something went wrong!' },
        };

        const result = CommonHelper.apiSwaggerErrorResponse(responseObject, true);

        expect(result).toEqual({
            status: true,
            ...responseObject,
        });
    });

    it('should convert keys to snake_case', () => {
        const input = {
            firstName: 'Test',
            lastName: 'User',
            contactDetails: {
                emailAddress: 'testuser@example.com',
                phoneNumber: '123456789'
            },
            hobbies: ['Reading', 'Swimming']
        };

        const expectedOutput = {
            FIRST_NAME: 'Test',
            LAST_NAME: 'User',
            CONTACT_DETAILS: {
                EMAIL_ADDRESS: 'testuser@example.com',
                PHONE_NUMBER: '123456789'
            },
            HOBBIES: ['Reading', 'Swimming']
        };

        const result = CommonHelper.transformToSnakeCase(input);

        expect(result).toEqual(expectedOutput);
    });

    it('should handle Date objects correctly', () => {
        const input = {
            birthDate: new Date('2000-01-01T00:00:00Z')
        };

        const expectedOutput = {
            BIRTH_DATE: '2000-01-01T00:00:00.000Z'
        };

        const result = CommonHelper.transformToSnakeCase(input);

        expect(result).toEqual(expectedOutput);
    });

    it('should handle ObjectId objects correctly', () => {
        const fakeObjectId = {
            toString: () => 'fake-object-id'
        };

        const input = {
            userId: fakeObjectId
        };

        const expectedOutput = {
            USER_ID: {
                TO_STRING: {}
            }
        };

        const result = CommonHelper.transformToSnakeCase(input);

        expect(result).toEqual(expectedOutput);
    });

    it('should convert keys to camelCase', () => {
        const input = {
            first_name: 'Test',
            last_name: 'User',
            contact_details: {
                email_address: 'testuser@example.com',
                phone_number: '123456789'
            },
            hobbies: ['Reading', 'Swimming']
        };

        const expectedOutput = {
            firstName: 'Test',
            lastName: 'User',
            contactDetails: {
                emailAddress: 'testuser@example.com',
                phoneNumber: '123456789'
            },
            hobbies: ['Reading', 'Swimming']
        };

        const result = CommonHelper.transformToCamelCase(input);

        expect(result).toEqual(expectedOutput);
    });

    it('should handle Date objects correctly', () => {
        const date = new Date('2000-01-01T00:00:00Z');
        const result = CommonHelper.transformToCamelCase(date);

        expect(result).toBe(date.toISOString());
    });

    it('should handle ObjectId objects correctly', () => {
        const objectId = new ObjectId();
        const result = CommonHelper.transformToCamelCase(objectId);

        expect(result).toBe(objectId.toString());
    });

    it('should handle an array of objects', () => {
        const input = [
            {
                first_name: 'Test',
                last_name: 'User 1'
            },
            {
                first_name: 'Test',
                last_name: 'User 2'
            }
        ];

        const expectedOutput = [
            {
                firstName: 'Test',
                lastName: 'User 1'
            },
            {
                firstName: 'Test',
                lastName: 'User 2'
            }
        ];

        const result = CommonHelper.transformToCamelCase(input);

        expect(result).toEqual(expectedOutput);
    });

    it('should handle nested arrays and objects', () => {
        const input = {
            user_info: {
                addresses: [
                    { street_name: 'Main St', zip_code: '12345' },
                    { street_name: 'Oak Ave', zip_code: '67890',
                 }
                ]
            }
        };

        const expectedOutput = {
            userInfo: {
                addresses: [
                    {
                    "streetName": "Main St",
                           "zipCode": "12345" },
                    {
                    "streetName": "Oak Ave",
                            "zipCode": "67890" }
                ]
            }
        };

        const result = CommonHelper.transformToCamelCase(input);

        expect(result).toEqual(expectedOutput);
    });
})