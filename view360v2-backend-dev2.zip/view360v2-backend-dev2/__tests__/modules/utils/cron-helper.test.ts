import { CronHelper } from "../../../src/utils/helpers/cron.helper";

describe('CronHelper', () => {
    it('should return null if data is null', () => {
        const result = CronHelper.generateTime(null);

        expect(result).toBeNull();
    });

    it('should generate cron time for weekly frequency with selected time', () => {
        const data = {
            frequency: 'weekly',
            time: '14:45',
            cronDate: '',
            timezone: '',
            startMinute: '',
            monday: '',
            tuesday: '',
            wednesday: '',
            thursday: '',
            friday: '',
            saturday: '',
            sunday: ''
        };

        const expectedOutput = {
            second: '',
            minute: '45',
            hour: '14',
            monthDay: '*',
            month: '*',
            weekDay: ''
        };

        const result = CronHelper.generateTime(data);

        expect(result).toEqual(expectedOutput);
    });


    it('should generate cron time for daily frequency with selected time', () => {
        const data = {
            frequency: 'daily',
            time: '12:30',
            cronDate: '',
            timezone: '',
            startMinute: '',
            monday: '',
            tuesday: '',
            wednesday: '',
            thursday: '',
            friday: '',
            saturday: '',
            sunday: ''
        };

        const expectedOutput = {
            second: '',
            minute: '30',
            hour: '12',
            monthDay: '*',
            month: '*',
            weekDay: ''
        };

        const result = CronHelper.generateTime(data);

        expect(result).toEqual(expectedOutput);
    });

    it('should generate cron time for 30 minute frequency with start minute 20', () => {
        const data = {
            frequency: '30_minute',
            startMinute: '20',
            time: '14:45',
            cronDate: '',
            timezone: '',
            monday: '',
            tuesday: '',
            wednesday: '',
            thursday: '',
            friday: '',
            saturday: '',
            sunday: ''
        };

        const expectedOutput = {
            second: '0',
            minute: '20,50',
            hour: '*',
            monthDay: '*',
            month: '*',
            weekDay: ''
        };

        const result = CronHelper.generateTime(data);

        expect(result).toEqual(expectedOutput);
    });

    it('should generate cron time for 1 hour frequency', () => {
        const data = {
            frequency: '1_hour',
            time: '12:30',
            cronDate: '',
            timezone: '',
            startMinute: '',
            monday: '',
            tuesday: '',
            wednesday: '',
            thursday: '',
            friday: '',
            saturday: '',
            sunday: ''
        };

        const expectedOutput = {
            second: '0',
            minute: '0',
            hour: '*/1',
            monthDay: '*',
            month: '*',
            weekDay: ''
        };

        const result = CronHelper.generateTime(data);

        expect(result).toEqual(expectedOutput);
    });

    it('should generate cron time for exact date with selected time and timezone', () => {
        const data = {
            frequency: 'exactDate',
            time: '08:15',
            cronDate: '2023-09-20T00:00:00Z',
            timezone: 'America/New_York',
            startMinute: '',
            monday: '',
            tuesday: '',
            wednesday: '',
            thursday: '',
            friday: '',
            saturday: '',
            sunday: ''
        };

        const expectedOutput = {
            second: '0',
            minute: '15',
            hour: '08',
            monthDay: '19',
            month: '9',
            weekDay: 'Tuesday'
        };

        const result = CronHelper.generateTime(data);

        expect(result).toEqual(expectedOutput);
    });

    it('should generate cron time for 3 hour frequency', () => {
        const data = {
            frequency: '3_hour',
            time: '',
            cronDate: '',
            timezone: '',
            startMinute: '',
            monday: '',
            tuesday: '',
            wednesday: '',
            thursday: '',
            friday: '',
            saturday: '',
            sunday: ''
        };

        const expectedOutput = {
            second: '0',
            minute: '0',
            hour: '*/3',
            monthDay: '*',
            month: '*',
            weekDay: ''
        };

        const result = CronHelper.generateTime(data);

        expect(result).toEqual(expectedOutput);
    });

    it('should generate cron time for 6 hour frequency', () => {
        const data = {
            frequency: '6_hour',
            time: '',
            cronDate: '',
            timezone: '',
            startMinute: '',
            monday: '',
            tuesday: '',
            wednesday: '',
            thursday: '',
            friday: '',
            saturday: '',
            sunday: ''
        };

        const expectedOutput = {
            second: '0',
            minute: '0',
            hour: '*/6',
            monthDay: '*',
            month: '*',
            weekDay: ''
        };

        const result = CronHelper.generateTime(data);

        expect(result).toEqual(expectedOutput);
    });

    it('should generate cron time for 12 hour frequency', () => {
        const data = {
            frequency: '12_hour',
            time: '',
            cronDate: '',
            timezone: '',
            startMinute: '',
            monday: '',
            tuesday: '',
            wednesday: '',
            thursday: '',
            friday: '',
            saturday: '',
            sunday: ''
        };

        const expectedOutput = {
            second: '0',
            minute: '0',
            hour: '*/12',
            monthDay: '*',
            month: '*',
            weekDay: ''
        };

        const result = CronHelper.generateTime(data);

        expect(result).toEqual(expectedOutput);
    });

    it('should generate cron time for 1 minute frequency', () => {
        const data = {
            frequency: '1_minute',
            time: '',
            cronDate: '',
            timezone: '',
            startMinute: '',
            monday: '',
            tuesday: '',
            wednesday: '',
            thursday: '',
            friday: '',
            saturday: '',
            sunday: ''
        };

        const expectedOutput = {
            second: '0',
            minute: '*',
            hour: '*',
            monthDay: '*',
            month: '*',
            weekDay: ''
        };

        const result = CronHelper.generateTime(data);

        expect(result).toEqual(expectedOutput);
    });

    it('should handle null data gracefully', () => {
        const data = null;

        const result = CronHelper.generateTime(data);

        expect(result).toBeNull();
    });

    it('should return true for equals condition', () => {
        const result = CronHelper.valueCompare(10, '=', 10);

        expect(result).toBe(true);
    });

    it('should return true for not equals condition', () => {
        const result = CronHelper.valueCompare(10, '!=', 20);

        expect(result).toBe(true);
    });

    it('should return true for greater than condition', () => {
        const result = CronHelper.valueCompare(20, '>', 10);

        expect(result).toBe(true);
    });

    it('should return true for smaller than condition', () => {
        const result = CronHelper.valueCompare(10, '<', 20);

        expect(result).toBe(true);
    });

    it('should return true for greater than or equals condition', () => {
        const result = CronHelper.valueCompare(20, '>=', 20);

        expect(result).toBe(true);
    });

    it('should return true for smaller than or equals condition', () => {
        const result = CronHelper.valueCompare(10, '<=', 20);

        expect(result).toBe(true);
    });

    it('should return true for contains condition', () => {
        const result = CronHelper.valueCompare('hello world', 'contains', 'world');

        expect(result).toBe(true);
    });

    it('should return true for starts with condition', () => {
        const result = CronHelper.valueCompare('hello world', 'startswith', 'hello');

        expect(result).toBe(true);
    });

    it('should return true for ends with condition', () => {
        const result = CronHelper.valueCompare('hello world', 'endswith', 'world');

        expect(result).toBe(true);
    });

    it('should handle string case insensitivity', () => {
        const result = CronHelper.valueCompare('Hello', '=', 'hello');

        expect(result).toBe(true);
    });

    it('should handle numeric case insensitivity', () => {
        const result = CronHelper.valueCompare('10', '=', 10);

        expect(result).toBe(true);
    });

    it('should handle invalid condition gracefully', () => {
        const result = CronHelper.valueCompare(10, 'invalid_condition', 20);

        expect(result).toBe(false);
    });
})