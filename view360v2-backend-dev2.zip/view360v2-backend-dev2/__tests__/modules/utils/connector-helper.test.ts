import { WidgetAccount } from "../../../src/entities";
import { dataSource } from "../../../src/core/data-source";
import { DatabaseType, StatusType } from "../../../src/models/enums";
import { ConnectorHelper } from "../../../src/utils/helpers/connector.helper";

// Add this import for Axios
const axios = require('axios');

// Mock Axios
jest.mock('axios');

describe('ConnectorHelper', () => {
    let connectorHelper: ConnectorHelper;

    beforeAll(async () => {
        jest.clearAllMocks();
    });

    beforeEach(async () => {
        connectorHelper = new ConnectorHelper();
    })

    describe('connect function', () => {
        it('should connect to MSSQL and return data', async () => {
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({
                    id: 1,
                    config: JSON.stringify({
                        dbType: 'MSSQL',
                        host: 'yourHost',
                        port: 1433,
                        user: 'yourUser',
                        password: 'yourPassword',
                        database: 'yourDatabase',
                    })
                })
            });

            const mssql = require('mssql');
            // Mock MS SQL behavior
            const msSqlConnection = {
                query: jest.fn().mockResolvedValue({ recordset: [{ id: 1, name: 'Test' }] }),
                close: jest.fn(),
            };

            mssql.connect = jest.fn(() => msSqlConnection);

            const result = await ConnectorHelper.connect(1, 'SELECT * FROM yourTable');

            expect(result).toEqual({
                status: 'success',
                message: null,
                data: [{ id: 1, name: 'Test' }],
            });
        });

        it('should connect to MYSQL and return data', async () => {
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({
                    id: 1,
                    config: JSON.stringify({
                        dbType: 'MYSQL',
                        host: 'yourHost',
                        user: 'yourUser',
                        password: 'yourPassword',
                        database: 'yourDatabase',
                    }),
                })
            });

            const mysql = require('mysql');

            // Mock MySQL behavior
            const mySqlConnection = {
                query: jest.fn().mockImplementation((query, callback) => callback(null, [{ id: 1, name: 'Test' }])),
                connect: jest.fn(),
                end: jest.fn(),
                destroy: jest.fn(),
            };

            // Mock the behavior of mysql.createConnection
            mysql.createConnection = jest.fn(() => mySqlConnection);

            const result = await ConnectorHelper.connect(1, 'SELECT * FROM yourTable', {});

            expect(result).toEqual({
                status: 'success',
                message: null,
                data: [{ id: 1, name: 'Test' }],
            });
        });

        it('should handle case where no connector is provided', async () => {
            const result = await ConnectorHelper.connect(null, '')

            expect(result.status).toBe(StatusType.ERROR);
            expect(result.message).toBe('Error while fetching records or connecting database. please check configuration.');
        });

        it('should return an error if there is an error executing the database query', async () => {
            const msSql = require('mssql');
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({
                    id: 1,
                    config: JSON.stringify({
                        dbType: 'MSSQL',
                    })
                })
            });

            msSql.connect.mockResolvedValue({
                query: jest.fn().mockRejectedValue(new Error('Database query error')),
                close: jest.fn(),
            });

            const result = await ConnectorHelper.connect(1, 'SELECT * FROM yourTable');

            expect(result).toEqual({
                status: 'error',
                message: 'Error while fetching records or connecting database. please check configuration.',
                data: null,
            });
        });
        
        it('should return an error when blank response from connector', async () => {
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({})
            });

            const result = await ConnectorHelper.connect(1, 'SELECT * FROM yourTable');

            expect(result).toEqual({
                status: 'error',
                message: 'No Connectors found.',
                data: null,
            });
        });
    });

    describe('apiConnector', () => {
        it('should return error response if connector is not found', async () => {
            const connectorId = 1;
            const response = await ConnectorHelper.apiConnector(connectorId);

            expect(response.status).toBe(StatusType.ERROR);
            expect(response.message).toBe('Invalid connector type. please check configuration.');
        });

        it('should return error response if connector type is not API', async () => {
            const connectorId = 1;
            // Mock the database response to simulate finding the connector
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({ id: connectorId, widgetType: 'Database', config: '{}' })
            })

            const response = await ConnectorHelper.apiConnector(connectorId);

            expect(response.status).toBe(StatusType.ERROR);
            expect(response.message).toBe('Invalid connector type. please check configuration.');
        });

        it('should return error response if API configuration is invalid', async () => {
            const connectorId = 1;
            // Mock the database response to simulate finding the connector
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({ id: connectorId, widgetType: 'API', config: '{}' }),
            })

            const response = await ConnectorHelper.apiConnector(connectorId);

            expect(response.status).toBe(StatusType.ERROR);
            expect(response.message).toBe('Error while fetching records or connecting database. please check configuration.');
        });

        it('should make a successful API call and return the response', async () => {
            const connectorId = 1;
            const connectorConfig = {
                method: 'GET',
                apiLink: 'https://example.com/api/data',
                params: [],
                headers: [],
            };

            // Mock the database response to simulate finding the connector
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({ id: connectorId, widgetType: 'API', config: JSON.stringify(connectorConfig) }),
            })

            // Mock the axios function to simulate a successful API call
            axios.mockResolvedValue({ data: 'API Response Data' });

            const response = await ConnectorHelper.apiConnector(connectorId);

            expect(response.status).toBe(StatusType.SUCCESS);
            expect(response.data).toBe('API Response Data');
            expect(axios).toHaveBeenCalledWith({
                method: 'GET',
                url: 'https://example.com/api/data',
            });
        });

        it('should return error response for failed API call', async () => {
            const connectorId = 4; // Assuming this is a valid id
            // Mocking the response from the repository
            jest.spyOn(dataSource.getRepository(WidgetAccount), 'findOne').mockResolvedValue({
                widgetType: 'API',
                config: JSON.stringify({
                    method: 'GET',
                    apiLink: 'https://example.com/api',
                    params: []
                })
            } as WidgetAccount);
            // Mocking the Axios error response
            axios.mockRejectedValue(new Error('Mocked Error'));
            const result = await ConnectorHelper.apiConnector(connectorId);
            expect(result).toEqual({ status: 'error', message: 'Mocked Error', data: null });
        });
    })
});