import { MailLog, MailTemplate, MdbClient, SettingConfig, Users } from "../../../src/entities";
import { DataSource, Repository } from "typeorm";
import { CommunicationHelper, MailerParam } from "../../../src/utils/helpers/communication.helper";
import Container from "typedi";

jest.mock('nodemailer', () => ({
    createTransport: jest.fn().mockReturnValue({
        sendMail: jest.fn().mockImplementation((mailOptions, callback) => {
          callback(null, { messageId: '12345' });
        }),
      }),
}));

describe('CommunicationHelper', () => {
    let communicationHelper: CommunicationHelper;
    let mdbClientRepositoryMock: Partial<Repository<MdbClient>>;
    let userRepositoryMock: Partial<Repository<Users>>;
    let mailTemplateRepositoryMock: Partial<Repository<MailTemplate>>;
    let settingConfigRepositoryMock: Partial<Repository<SettingConfig>>;

    beforeAll(async () => {
        jest.clearAllMocks();
    });

    beforeEach(() => {
        communicationHelper = new CommunicationHelper();
        mdbClientRepositoryMock = {
            find: jest.fn(),
        };
        communicationHelper['mdbClientRepository'] = mdbClientRepositoryMock as Repository<MdbClient>;
        userRepositoryMock = {
            find: jest.fn(),
        };
        communicationHelper['userRepository'] = userRepositoryMock as Repository<Users>;
        mailTemplateRepositoryMock = {
            find: jest.fn(),
        }
        communicationHelper['mailTemplateRepository'] = mailTemplateRepositoryMock as Repository<MailTemplate>;
        settingConfigRepositoryMock = {
            findOne: jest.fn(),
        }
    });

    describe('getMdbClient', () => {
        it('should call find on mdbClientRepository with correct arguments', async () => {
            const condition = { id: 1 }; // Sample condition
            const fields = ['field1', 'field2']; // Sample fields

            const expectedResult = [
                { id: 1, field1: 'value1', field2: 'value2' },
            ];

            // Mock the return value of find method
            mdbClientRepositoryMock.find = jest.fn().mockResolvedValue(expectedResult);

            const result = await communicationHelper['getMdbClient'](condition, fields);

            expect(mdbClientRepositoryMock.find).toHaveBeenCalledWith({ where: condition, select: fields });
            expect(result).toEqual(expectedResult);
        });

        it('should return an empty array if no matching records are found', async () => {
            const expectedResult = []; // No matching records

            // Mock the return value of find method
            mdbClientRepositoryMock.find = jest.fn().mockResolvedValue(expectedResult);

            const result = await communicationHelper['getMdbClient']({}, []);

            expect(mdbClientRepositoryMock.find).toHaveBeenCalledWith({ where: {}, select: [] });
            expect(result).toEqual(expectedResult);
        });
    });

    describe('getUsers', () => {
        it('should call find on userRepository with default arguments', async () => {
            const expectedResult = [
                { id: 1, field1: 'value1', field2: 'value2' },
            ];

            // Mock the return value of find method
            userRepositoryMock.find = jest.fn().mockResolvedValue(expectedResult);

            const result = await communicationHelper['getUsers']({}, []);

            expect(userRepositoryMock.find).toHaveBeenCalledWith({ where: {}, select: [], order: { createdOn: 'DESC' } });
            expect(result).toEqual(expectedResult);
        });

        it('should return an empty array if no matching records are found', async () => {
            const expectedResult = []; // No matching records

            // Mock the return value of find method
            userRepositoryMock.find = jest.fn().mockResolvedValue(expectedResult);

            const result = await communicationHelper['getUsers']({}, []);

            expect(userRepositoryMock.find).toHaveBeenCalledWith({ where: {}, select: [], order: { createdOn: 'DESC' } });
            expect(result).toEqual(expectedResult);
        });
    });

    describe('getMailTemplate', () => {
        it('should call find on mailTemplateRepository with default arguments', async () => {
            const expectedResult = [
                { id: 1, field1: 'value1', field2: 'value2' },
            ];

            // Mock the return value of find method
            mailTemplateRepositoryMock.find = jest.fn().mockResolvedValue(expectedResult);

            const result = await communicationHelper['getMailTemplate']({}, []);

            expect(mailTemplateRepositoryMock.find).toHaveBeenCalledWith({ where: {}, select: [] });
            expect(result).toEqual(expectedResult);
        });

        it('should return an empty array if no matching records are found', async () => {
            const expectedResult = []; // No matching records

            // Mock the return value of find method
            mailTemplateRepositoryMock.find = jest.fn().mockResolvedValue(expectedResult);

            const result = await communicationHelper['getMailTemplate']({}, []);

            expect(mailTemplateRepositoryMock.find).toHaveBeenCalledWith({ where: {}, select: [] });
            expect(result).toEqual(expectedResult);
        });
    });

    describe('htmlReplace', () => {
        it('should replace placeholders in html string with provided values', async () => {
            const key = 'someKey';
            const type = 'html';
            const userDetails = { username: 'test_user' };
            const configData = {
                var1: 'Value1',
                var2: 'Value2',
            };

            const expectedResult = {
                status: true,
                htmlString: key,
                subject: null,
            };

            const result = await communicationHelper.htmlReplace(key, type, userDetails, configData);

            expect(result).toEqual(expectedResult);
        });

        it('should handle case when type is "id"', async () => {
            const key = 'someId';
            const type = 'id';
            const userDetails = { username: 'test_user' };
            const configData = {
                var1: 'Value1',
                var2: 'Value2',
            };

            // Assuming getMailTemplate returns a MailTemplate with body and subject properties
            communicationHelper['getMailTemplate'] = jest.fn().mockResolvedValue([{ body: '<body>@var1 - @var2 - @UserName</body>', subject: 'Sample Subject' }]);

            const expectedResult = {
                status: true,
                htmlString: "<body>@var1 - @var2 - @UserName</body>",
                subject: "Sample Subject",
              };

            const result = await communicationHelper.htmlReplace(key, type, userDetails, configData);

            expect(result).toEqual(expectedResult);
        });

        it('should handle error when parsing formMapKey', async () => {
            const key = 'someId';
            const type = 'id';
            const userDetails = { username: 'test_user' };
            const configData = {
                var1: 'Value1',
                var2: 'Value2',
            };

            // Mocking a scenario where formMapKey is not a valid JSON
            communicationHelper['getMailTemplate'] = jest.fn().mockResolvedValue([{ body: '<body>@var1 - @var2 - @UserName</body>', subject: 'Sample Subject', formMapKey: 'invalidJSON' }]);

            const expectedResult = {
                error: "Required field missing",
                status: true,
              };

            const result = await communicationHelper.htmlReplace(key, type, userDetails, configData);

            expect(result).toEqual(expectedResult);
        });

        it('should return an error when required fields are missing', async () => {
            const key = '';
            const type = '';
            const userDetails = {};
            const configData = {};

            const expectedResult = {
                error: 'Required field missing',
                status: true,
            };

            const result = await communicationHelper.htmlReplace(key, type, userDetails, configData);

            expect(result).toEqual(expectedResult);
        });
    });

    describe('nodeMailerService', () => {
        it('should send an email using SMTP configuration', async () => {
            // Mocking config with SMTP settings
            const config = {
                to: 'test@example.com',
                subject: 'Test Subject',
                html: '<html><body>Test Body</body></html>',
                clientId: 123,
                importantMail: true, // Assuming this indicates SMTP config should be used
                attachments: [
                    { filename: 'Attachment.txt', content: 'Attachment Content' }
                ]
            };

            // Mocking settingConfigRepository result with SMTP configuration
            communicationHelper['getMailTemplate'] = jest.fn();
            communicationHelper.replaceAllHtmlString = jest.fn().mockImplementation((str, replaceWhat, replaceTo) => str); // Assuming this function works as expected

            const settingConfigValue = {
                clientId: config.clientId,
                type: 'smtp',
                config: JSON.stringify({
                    host: 'smtp.example.com',
                    port: 587,
                    secure: false,
                    username: 'smtpuser',
                    password: 'smtppassword',
                    emailId: 'info@example.com'
                })
            };
            Container.get(DataSource).getRepository(SettingConfig).findOne = jest.fn().mockResolvedValue(settingConfigValue);

            // Mocking NodeMailer.createTransport and sendMail
            // const mockTransport = {
            //     sendMail: jest.fn().mockImplementation((mailOptions, callback) => {
            //         callback(null, { messageId: '12345' });
            //     })
            // };
            // jest.mock('nodemailer', () => ({
            //     createTransport: jest.fn().mockReturnValue(mockTransport)
            // }));
            

            await communicationHelper.nodeMailerService(config);
        });
        it('should handle case when config or "to" field is missing', async () => {
            const communicationHelper = new CommunicationHelper();

            // Mocking config with missing "to" field
            const config = {
                subject: 'Test Subject',
                html: '<html><body>Test Body</body></html>',
                clientId: 123,
                importantMail: true,
                attachments: [
                    { filename: 'Attachment.txt', content: 'Attachment Content' }
                ]
            };

            // Mocking settingConfigRepository result with SMTP configuration
            communicationHelper['getMailTemplate'] = jest.fn();
            communicationHelper.replaceAllHtmlString = jest.fn().mockImplementation((str, replaceWhat, replaceTo) => str); // Assuming this function works as expected

            const result = await communicationHelper.nodeMailerService(config as MailerParam);

            // Assertions
            expect(result).toBeUndefined();
        });

        it('should handle error when parsing SMTP config', async () => {
            const communicationHelper = new CommunicationHelper();

            // Mocking config with SMTP settings
            const config = {
                to: 'test@example.com',
                subject: 'Test Subject',
                html: '<html><body>Test Body</body></html>',
                clientId: 123,
                importantMail: true, // Assuming this indicates SMTP config should be used
                attachments: [
                    { filename: 'Attachment.txt', content: 'Attachment Content' }
                ]
            };

            // Mocking settingConfigRepository result with invalid JSON
            communicationHelper['getMailTemplate'] = jest.fn();
            communicationHelper.replaceAllHtmlString = jest.fn().mockImplementation((str, replaceWhat, replaceTo) => str); // Assuming this function works as expected
            Container.get(DataSource).getRepository(SettingConfig).findOne = jest.fn().mockResolvedValue({ confg: 'invalidJSON' })

            const result = await communicationHelper.nodeMailerService(config);

            // Assertions
            expect(result).toBeUndefined();
        });
    });

    describe('sendEmail', () => {
        it('should send an email', async () => {
            const params = {
                clientId: 1,
                tempId: 2,
                insertId: 3,
                task: 'assign',
                to: 'test@example.com',
                subject: 'Test Subject',
                body: 'Test Body',
                entryData: {
                    v_attachFiles: ['file1.txt', 'file2.txt'],
                },
                templateId: 'template123',
            };

            // Mock the responses from getMdbClient and getUsers
            const mdbData = [{ websiteUrl: 'http://example.com' }];
            const userResultArr = [{ firstName: 'Test', lastName: 'User', username: 'testuser' }];
            mdbClientRepositoryMock.find = jest.fn().mockResolvedValue(mdbData);
            userRepositoryMock.find = jest.fn().mockResolvedValue(userResultArr);

            // Mock the responses from htmlReplace
            communicationHelper.htmlReplace = jest.fn().mockResolvedValue({
                status: true,
                htmlString: 'Replaced HTML',
            });

            // Call the sendEmail method
            await communicationHelper.sendEmail(params);

            // Expectations
            expect(mdbClientRepositoryMock.find).toHaveBeenCalledWith({
                select: [
                    "websiteUrl",
                ],
                where: {
                    id: 1
                }
            })
            expect(userRepositoryMock.find).toHaveBeenCalledWith({
                order: {
                    createdOn: "DESC",
                },
                select: [
                    'firstName',
                    'lastName',
                    'username',
                ],
                where: {
                    "email": "test@example.com",
                },
            });
            expect(communicationHelper.htmlReplace).toHaveBeenCalledWith('template123', 'id', null, {
                Email: 'test@example.com',
                FirstName: 'Test',
                LastName: 'User',
                Link: 'https://http://example.com/custom-form-view/2/3/edit',
                Username: 'testuser',
            });
        });
    });

    describe('sendSMS', () => {
        // it('should send an SMS', async () => {
        //     const params = {
        //         message: 'Test message',
        //         from: '+14135917049',
        //         to: '+1234567890',
        //     };

        //     // Call the sendSms method
        //     await communicationHelper.sendSms(params);

        //     // Expectations
        //     expect(require('twilio').messages.create).toHaveBeenCalledWith({
        //         body: 'Test message',
        //         from: '+14135917049',
        //         to: '+1234567890',
        //     });
        // });

        // it('should send an SMS with default "from" number', async () => {
        //     const params = {
        //         message: 'Test message',
        //         from: '+1234567890',
        //         to: '+1234567890',
        //     };

        //     // Call the sendSms method
        //     await communicationHelper.sendSms(params);

        //     // Expectations
        //     expect(require('twilio').messages.create).toHaveBeenCalledWith({
        //         body: 'Test message',
        //         from: '+14135917049',
        //         to: '+1234567890',
        //     });
        // });

        // it('should handle Twilio API error', async () => {
        //     const params = {
        //         message: 'Test message',
        //         from: '+14135917049',
        //         to: '+1234567890',
        //     };

        //     // Mock Twilio API to throw an error
        //     require('twilio').messages.create = jest.fn().mockRejectedValue(new Error('Twilio API Error'));

        //     // Call the sendSms method
        //     try {
        //         await communicationHelper.sendSms(params);
        //     } catch (error) {
        //         // Expect an error to be thrown
        //         expect(error.message).toBe('Twilio API Error');
        //     }
        // });
    })
});