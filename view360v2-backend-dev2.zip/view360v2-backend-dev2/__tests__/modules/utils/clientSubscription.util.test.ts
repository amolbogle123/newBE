import {ClientSubscriptionUtil} from "../../../src/utils/clientSubscription.util";
import { dataSource } from "../../../src/core/data-source";
import bcrypt from "bcryptjs";
describe('ClientSubscriptionUtil', () => {
    describe('checkSubscribeValidUser', () => {
        it('should call checkSubscribeValidUser',async () => {
            dataSource.getRepository = jest.fn().mockReturnValue({
                createQueryBuilder: jest.fn().mockReturnValue({
                    where: jest.fn().mockReturnThis(),
                    orderBy: jest.fn().mockReturnThis(),
                    getMany: jest.fn().mockReturnValue([{
                        id: '123',
                        validUntil: Date.now()+1000000,
                    }]),
                }),
            });
            const result = await ClientSubscriptionUtil.checkSubscribeValidUser('123');
            expect(dataSource.getRepository).toHaveBeenCalled();
            expect(result.data).toBeDefined();
            expect(result.data.isValidUser).toBeTruthy();
            expect(result.data.date).toBeDefined();
            expect(result.errors).toBeNull();
            


        });
    });
    describe('verifyPassword', () => {
        it('should call verifyPassword', async () => {
            bcrypt.compare = jest.fn().mockImplementation((passwordEntered, passwordInDB, callback) => {
                callback(null, true);
              });
            const result = await ClientSubscriptionUtil.verifyPassword('123', '123', {
                id: '123',
                password: '123',
            }, {});
            expect(bcrypt.compare).toHaveBeenCalled();
            expect(result).toEqual(
                {
                    status: true,
                    userLoginDetails: {
                      id: "123",
                    },
                  }
            )
            
        });
    });
});
