import { Crypto } from '../../../src/utils/crypto';
const crypto = require('crypto');
// Mock the 'crypto' module
jest.mock('crypto', () => ({
    createHash: jest.fn(() => ({
        update: jest.fn().mockReturnThis(),
        digest: jest.fn().mockReturnValue('mockedHash'), // Mocked hash value
    })),
    createDecipheriv: jest.fn(() => ({
        update: jest.fn().mockReturnValue('mockedDecryptedText'), // Mocked decrypted text
        final: jest.fn().mockReturnValue(''), // No more data to decrypt
    })),
    createCipheriv: jest.fn(() => ({
        update: jest.fn().mockReturnValue('mockedEncryptedText'), // Mocked encrypted text
        final: jest.fn().mockReturnValue(''), // No more data to encrypt
    })),
}));
describe('Crypto', () => {
    describe('decr', () => {
        it('should successfully decrypt text', () => {
            const encryptionConfig = {}; // Mocked encryption config
            const text = 'mockedEncryptedText';

            const result = Crypto.decr(encryptionConfig, text);

            // Assert that the mocked functions were called with the expected parameters
            expect(crypto.createHash).toHaveBeenCalledWith('sha256');
            expect(crypto.createDecipheriv).toHaveBeenCalledWith('aes-256-cbc', 'mockedHash', 'epiashiksoshkats');
            expect(result).toBe('mockedDecryptedText');
        });

        it('should handle decryption errors', () => {
            // Mock crypto.createDecipheriv to throw an error during decryption
            crypto.createDecipheriv.mockImplementation(() => {
                throw new Error('Decryption error');
            });

            const encryptionConfig = {}; // Mocked encryption config
            const text = 'mockedEncryptedText';

            try {
                Crypto.decr(encryptionConfig, text);
                // If the function does not throw an error, fail the test
                expect(true).toBe(false);
            } catch (error) {
                // Assert that the error message matches the expected error message
                expect(error.message).toBe('Decryption error');
            }
        });
    });
    describe('encr', () => {
        it('should successfully encrypt text', () => {
            const encryptionConfig = {}; // Mocked encryption config
            const text = 'mockedDecryptedText';

            const result = Crypto.encr(encryptionConfig, text);

            // Assert that the mocked functions were called with the expected parameters
            expect(crypto.createHash).toHaveBeenCalledWith('sha256');
            expect(crypto.createCipheriv).toHaveBeenCalledWith('aes-256-cbc', 'mockedHash', 'epiashiksoshkats');
            expect(result).toBe('mockedEncryptedText');
        });
        
        it('should handle encryption errors', () => {
            // Mock crypto.createCipheriv to throw an error during encryption
            crypto.createCipheriv.mockImplementation(() => {
                throw new Error('Encryption error');
            });

            const encryptionConfig = {}; // Mocked encryption config
            const text = 'mockedDecryptedText';

            try {
                Crypto.encr(encryptionConfig, text);
                // If the function does not throw an error, fail the test
                expect(true).toBe(false);
            } catch (error) {
                // Assert that the error message matches the expected error message
                expect(error.message).toBe('Encryption error');
            }
        });

    });
});



