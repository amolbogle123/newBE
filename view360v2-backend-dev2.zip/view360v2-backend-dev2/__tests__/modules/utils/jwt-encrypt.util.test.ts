import {JwtEncryptUtil} from "../../../src/utils/jwt-encrypt.util";

describe('JwtEncryptUtil', () => {
    describe('encryptedCode', () => {
        it('should call encryptedCode', () => {
            const result = JwtEncryptUtil.encryptedCode({data: 'data'}, 200);
            expect(result).toBeTruthy();
        });
    });
});
