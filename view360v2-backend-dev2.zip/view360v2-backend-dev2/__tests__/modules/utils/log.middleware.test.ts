import LogMiddleware from "../../../src/utils/log.middleware";
jest.mock('../../../src/utils/jwt-encrypt.util');
jest.mock('jsonwebtoken', () => ({
    verify: jest.fn().mockImplementation((token, secret, callback) => {
        if (token === 'mockedCookies_') {
            return callback(null);
        } else {
            return callback(new Error('mockedError'));
        }
    }),
    decode: jest.fn().mockImplementation((token) => {
        if (token === 'mockedCookies') {
            return {
                data: {
                   
                },
            };
        } else {
            return {
                data: {},
            };
        }
    })
}));
jest.mock('../../../src/utils/readJWTData.util');
describe('LogMiddleware', () => {
    let logMiddleWare: LogMiddleware;
    let request: any;
    let response: any;
    let next: any;
    let EXCLUDED_API_PATHS = ['/users/login'];
    beforeEach(() => {
        logMiddleWare = new LogMiddleware();
        request = {
            get: jest.fn().mockImplementation((headerName) => {
                if (headerName === 'authorization') {
                    return 'mockedAuthorization';
                }
            })                 
                    ,
            on: jest.fn(),
            off: jest.fn(),
            url: 'mockedUrl',
            rawHeaders: 'mockedRawHeaders',
            method: 'mockedMethod',
            httpVersion: 'mockedHttpVersion',
            headers: {
                authorization: 'mockedAuthorization',
            },
            cookies: 'mockedCookies',
            socket:{
                remoteAddress: 'mockedRemoteAddress',
                remoteFamily: 'mockedRemoteFamily',
            },
            ip: 'mockedIp',
            body: 'mockedBody',
        };
        response = {
            on: jest.fn(),
            off: jest.fn(),
            statusCode: 200,
            statusMessage: 'mockedStatusMessage',
            getHeaders: jest.fn(),

        };
        next = jest.fn();
    });
    describe('log', () => {
        it('should log the request', async () => {
            logMiddleWare.log(request, response, next);
            expect(request.on).toHaveBeenCalledTimes(3);
            expect(response.on).toHaveBeenCalledTimes(3);
            expect(request.on).toHaveBeenCalledWith('data', expect.any(Function));
            expect(request.on).toHaveBeenCalledWith('end', expect.any(Function));
            expect(request.on).toHaveBeenCalledWith('error', expect.any(Function));
            expect(response.on).toHaveBeenCalledWith('close', expect.any(Function));
            expect(response.on).toHaveBeenCalledWith('error', expect.any(Function));
            expect(response.on).toHaveBeenCalledWith('finish', expect.any(Function));
            expect(next).toHaveBeenCalledTimes(1);
        });

    });

    describe('logger', () => {
        it("should log when no authorization header and not on excluded path", async() => {
            // Mock your logger functions
            const mockApplicationLogger = {
              info: jest.fn(),
            };
            const mockAccessLogger = {
              info: jest.fn(),
            };
      
            // Temporarily replace the actual logger functions with mocks
      
            // Call the logger method
            const requestStart = Date.now();
            const body = "request body";
            const errorMessage = "error message";
            LogMiddleware.logger(request, response, errorMessage, requestStart, body);
          });
      
    });

});