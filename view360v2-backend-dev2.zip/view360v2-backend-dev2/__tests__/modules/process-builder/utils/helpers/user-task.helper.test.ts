import {ProcessBuilderService} from "../../../../../src/modules/process-builder/services/process-builder.service";
import {PanelDataTask, ProcessAssignee} from "../../../../../src/modules/process-builder/models";
import { DataSource} from "typeorm";
import {CommunicationHelper} from "../../../../../src/utils/helpers/communication.helper";
import { FormBuilderService } from "../../../../../src/modules/form-builder/services/form-builder.service";
import Container from 'typedi';
import { UserTask } from "../../../../../src/modules/process-builder-v2/tasks/user-task";
import { BpmnEngine } from "bpmn-engine";
  
describe('UserTaskHelper', () => {
    let userTask: UserTask;
    let bpmnEngineMock: Partial<BpmnEngine>;
    beforeEach(() => {
        userTask = new UserTask();
        bpmnEngineMock = {
            stop: jest.fn(),
        };
    });    
    it("should be defined", () => {
        expect(UserTask).toBeDefined();
    });
    it("should call executeTask with task PanelDataTask.ASSIGN", async () => {
        let getBpmnExecuteMockResults = [{
            id: 1,
            name: 'test',
        },{}];
        const getBpmnExecuteMock = jest.fn();
        getBpmnExecuteMockResults.forEach((mockResult) => {
            getBpmnExecuteMock.mockReturnValueOnce(mockResult);
        });
        ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
        ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);
        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
        FormBuilderService.prototype.getFormBuilder = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
        FormBuilderService.prototype.updateFormBuilder = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
        ProcessBuilderService.prototype.getMultipleUser = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1,username:'test',mobile:'1234567890' }]);
        ProcessBuilderService.prototype.runCustomizedQuery= jest.fn().mockResolvedValue([{ id: 1, referenceId: 1,ASSIGN_TO:ProcessAssignee.ASSIGNED_USER }]);   
        CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
        Container.get(DataSource).getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockResolvedValue({}),
            find: jest.fn().mockResolvedValue([{ subject: '', body: 'test' }]),
            save: jest.fn().mockResolvedValue({}),
        });
        const task = {
            // Your task data here
            panelData: {
                process:{
                    name: 'test'
                },
                taskarr: [
                    {
                        id: '1',
                        durationTime: 1,
                        catchDuration: 'minute',
                        params:{
                            assignee: '1',
                            assignto:ProcessAssignee.ASSIGNED_USER,
                            mailtemplate: {
                                subject: 'test',
                                body: 'test',
                            },
                            enablesms : true,
                        },
                        task:PanelDataTask.ASSIGN
                    },
                    {
                        id: '2',
                        durationTime: 1,
                        catchDuration: 'hour'
                    },
                    {
                        id: '3',
                        durationTime: 1,
                        catchDuration: 'day'
                    },
                    {
                        id: '4',
                        durationTime: 1,
                        catchDuration: 'month'
                    }
                ],
                executedActivities: [],
                timerparams: {
                    exactDate: '2020-12-12T12:12:12.000Z',
                    timezone: 'Asia/Kolkata',
                    time: '12:12',
                    frequency: 'exactDate',
                    cronDate: null
                }
                
            },
            api: {
                id: '1',
                signal:jest.fn
            },
            data: {
                id: '1',
                name: 'test',
                createdBy: 'test'
            },
            clientId: '123'
        };
        await userTask.executeTask(task,bpmnEngineMock);
    });

    it("should call executeTask with task PanelDataTask.SEND_FOR_REVIEW", async () => {
        let getBpmnExecuteMockResults = [{
            id: 1,
            name: 'test',
        },{}];
        const getBpmnExecuteMock = jest.fn();
        getBpmnExecuteMockResults.forEach((mockResult) => {
            getBpmnExecuteMock.mockReturnValueOnce(mockResult);
        });
        ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
        ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);
        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
        FormBuilderService.prototype.getFormBuilder = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
        FormBuilderService.prototype.updateFormBuilder = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
        ProcessBuilderService.prototype.getMultipleUser = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1,username:'test',mobile:'1234567890' }]);
        ProcessBuilderService.prototype.runCustomizedQuery= jest.fn().mockResolvedValue([{ id: 1, referenceId: 1,ASSIGN_TO:ProcessAssignee.ASSIGNED_USER }]);   
        CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
        Container.get(DataSource).getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockResolvedValue({}),
            find: jest.fn().mockResolvedValue([{ subject: '', body: 'test' }]),
            save: jest.fn().mockResolvedValue({}),
        });
        const task = {
            // Your task data here
            panelData: {
                process:{
                    name: 'test'
                },
                taskarr: [
                    {
                        id: '1',
                        durationTime: 1,
                        catchDuration: 'minute',
                        params:{
                            assignee: [
                                {
                                    id: '1',
                                }
                            ],
                            assignto:ProcessAssignee.FORM_FIELD,
                            mailtemplate: {
                                subject: 'test',
                                body: 'test',
                            },
                            enablesms : true,
                        },
                        task:PanelDataTask.SEND_FOR_REVIEW
                    },
                    {
                        id: '2',
                        durationTime: 1,
                        catchDuration: 'hour'
                    },
                    {
                        id: '3',
                        durationTime: 1,
                        catchDuration: 'day'
                    },
                    {
                        id: '4',
                        durationTime: 1,
                        catchDuration: 'month'
                    }
                ],
                executedActivities: [],
                timerparams: {
                    exactDate: '2020-12-12T12:12:12.000Z',
                    timezone: 'Asia/Kolkata',
                    time: '12:12',
                    frequency: 'exactDate',
                    cronDate: null
                }
                
            },
            api: {
                id: '1',
                signal:jest.fn
            },
            data: {
                id: '1',
                name: 'test',
                createdBy: 'test',
                submittedData: JSON.stringify({
                    id: '1',
                    name: 'test',
                }),
            },
            clientId: '123'
        };
        await userTask.executeTask(task,bpmnEngineMock);
    });



});
