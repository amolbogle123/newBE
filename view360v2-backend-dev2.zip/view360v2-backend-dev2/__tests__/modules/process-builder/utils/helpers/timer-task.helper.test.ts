import { ProcessCronService } from "../../../../../src/modules/process-builder/services/process-cron.service";
import { TimerTask } from "../../../../../src/modules/process-builder-v2/tasks/timer-task";
import { BpmnEngine } from 'bpmn-engine';
import moment from 'moment-timezone';
import { StatusType } from "../../../../../src/models/enums";
jest.mock('../../../../../src/modules/process-builder/services/process-cron.service');
describe('TimerTaskHelper', () => {
    let timerTask: TimerTask;
    let processCronServiceMock: jest.Mocked<ProcessCronService>;
    let bpmnEngineMock: Partial<BpmnEngine>;
    beforeEach(() => {
        processCronServiceMock = new ProcessCronService() as jest.Mocked<ProcessCronService>;
        timerTask = new TimerTask();
        // timerTask['processCronService'] = processCronServiceMock; // Commented out because the processCronService is private, need to find a way to mock it
        bpmnEngineMock = {
            stop: jest.fn(),
        };
    });

    it('should execute the task and add a cron job', async () => {

        // Create a custom mock for moment-timezone
        jest.mock('moment-timezone', () => {
            // Mock the 'tz' method
            const mockTz = jest.fn(() => moment);

            // Mock the 'add' method to return a modified moment object
            moment.fn.add = jest.fn((durationTime, unit) => {
                return moment();
            });

            // Mock the 'format' method
            const mockFormat = jest.fn((formatString) => {
                if (formatString === 'HH:mm') {
                    return '12:34'; // Mock the format for 'HH:mm' as needed
                }
            });

            return {
                tz: mockTz,
                fn: {
                    format: mockFormat,
                },
            };
        });
        // Mock the inputs for the executeTask method
        const task = {
            // Your task data here
            panelData: {
                taskarr: [
                    {
                        id: '1',
                        durationTime: 1,
                        catchDuration: 'minute'
                    },
                    {
                        id: '2',
                        durationTime: 1,
                        catchDuration: 'hour'
                    },
                    {
                        id: '3',
                        durationTime: 1,
                        catchDuration: 'day'
                    },
                    {
                        id: '4',
                        durationTime: 1,
                        catchDuration: 'month'
                    }
                ],
                executedActivities: [],
                timerparams: {
                    exactDate: '2020-12-12T12:12:12.000Z',
                    timezone: 'Asia/Kolkata',
                    time: '12:12',
                    frequency: 'exactDate',
                    cronDate: null
                }
            },
            api: {
                id: '1'
            },
            data: {
                id: '1',
                name: 'test',
                createdBy: 'test'
            },
            clientId: '123'
        };

        // Mock the processCronService.addCron method
        processCronServiceMock.addCron.mockResolvedValueOnce({
            status: StatusType.SUCCESS,
            message: 'Cron added successfully',
            data: {}
        });

        // Call the executeTask method
        await timerTask.executeTask(task, bpmnEngineMock as BpmnEngine);

        // Assertions
        expect(processCronServiceMock.addCron).toHaveBeenCalled();
        expect(bpmnEngineMock.stop).toHaveBeenCalled();
    });


    afterEach(() => {
        jest.clearAllMocks(); // Clear mock calls after each test
    });
});

