//write down below jest test cases for service-task.helper.ts
import {ProcessBuilderService} from "../../../../../src/modules/process-builder/services/process-builder.service";
import {TaskServiceType} from "../../../../../src/modules/process-builder/models";
import {CommunicationHelper} from "../../../../../src/utils/helpers/communication.helper";
import {In, DataSource} from "typeorm";
import {BpmnNotificationHelper} from "../../../../../src/modules/process-builder/utils/helpers/bpmn-notification.helper";
import { ServiceTask } from "../../../../../src/modules/process-builder-v2/tasks/service-task";
import container from "../../../../../__mocks__/typedi";
import { dataSource } from "../../../../../src/core/data-source";
import { FormBuilderService } from "../../../../../src/modules/form-builder/services/form-builder.service";
describe('ServiceTaskHelper', () => {
    let serviceTask: ServiceTask;
    let processBuilderService: ProcessBuilderService;
    let communicationHelper: CommunicationHelper;
    let bpmnNotificationHelper: BpmnNotificationHelper;
    let panelData:any;
    beforeEach(() => {
        serviceTask = new ServiceTask();
        processBuilderService = new ProcessBuilderService();
        communicationHelper = new CommunicationHelper();
        bpmnNotificationHelper = new BpmnNotificationHelper();
        panelData={
                
            process: { name: 'test' },
            taskarr: [{ id: 1, name: 'test',
                process: { name: 'test' },
                taskarr: [],
                executedActivities:[],
                nextbpmn:"1",
                serviceType:TaskServiceType.ANOTHER_PROCESS,
                params:{
                    mailtemplate:1,
                    recipientMail:"test@test.com",
                    notificationTemplate:1,
                    alertMasterClient:false,
                    assignee:'test'
                },
                api:{id:1, name:'test'},
            }],
            executedActivities:[],
            params:{
                mailtemplate:1,
                recipientMail:"test@test.com",
                notificationTemplate:1,
                alertMasterClient:false,
                assignee:'test'
            },
        
    }
    });
    describe('executeTask', () => {
        it('should execute service task when task service type is ANOTHER_PROCESS', async () => {
            let getBpmnExecuteMockResults = [{
                id: 1,
                name: 'test',
            },{}];
            const getBpmnExecuteMock = jest.fn();
            getBpmnExecuteMockResults.forEach((mockResult) => {
                getBpmnExecuteMock.mockReturnValueOnce(mockResult);
            });
            ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
            ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1,clientId:1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);

            CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
            BpmnNotificationHelper.prototype.execute = jest.fn().mockResolvedValue({});
            container.get(DataSource).getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({}),
                find: jest.fn().mockResolvedValue([{ subject: '', body: 'test' }]),
            });
            const result = await serviceTask.executeTask(panelData, { id: 1, name: 'test' }, { id: 1, name: 'test' },"test","test", {}, '');
            expect(result).toEqual({ status:true });
        });
        it('should execute service task when task service type is CONNECTOR', async () => {
            let getBpmnExecuteMockResults = [{
                id: 1,
                name: 'test',
            },{}];
            const getBpmnExecuteMock = jest.fn();
            getBpmnExecuteMockResults.forEach((mockResult) => {
                getBpmnExecuteMock.mockReturnValueOnce(mockResult);
            });
            ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
            ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1,clientId:1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);

            CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
            BpmnNotificationHelper.prototype.execute = jest.fn().mockResolvedValue({});
            dataSource.getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({}),
                find: jest.fn().mockResolvedValue([{ id: 'test', config: JSON.stringify({id:1,dbType:"mysql"}) }]),
            });
            panelData.taskarr[0].serviceType=TaskServiceType.CONNECTOR;
            panelData.manualSQLConnector={
                connectorParams:{
                    sqlAccount :"test",
                    columnName :"test",
                    sqlTable:"test",
                    manualQuery:"test"

                }
            }
            panelData.connectorParams={
                sqlAccount :"test",
                columnName :"test",
                sqlTable:"test",
                manualQuery:"test"

            }
            panelData.taskarr[0].params = {
                sqlAccount:"test",
                sqlTable :"test",
                dbQuery:"test",


            }
            const result = await serviceTask.executeTask(panelData, { id: 1, type: 'SQL_CONNECTOR',queryData:{"test":""} }, { id: 1, name: 'test' },"test","test", {}, '');
            expect(result).toEqual({ status:true });
        });
        it('should execute service task when task service type is FORM', async () => {
            let getBpmnExecuteMockResults = [{
                id: 1,
                name: 'test',
            },{}];
            const getBpmnExecuteMock = jest.fn();
            getBpmnExecuteMockResults.forEach((mockResult) => {
                getBpmnExecuteMock.mockReturnValueOnce(mockResult);
            });
            ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
            ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1,clientId:1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);

            CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
            BpmnNotificationHelper.prototype.execute = jest.fn().mockResolvedValue({});
            container.get(DataSource).getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({}),
                find: jest.fn().mockResolvedValue([{ subject: '', body: 'test' }]),
            });
            FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ id: 1, name: 'test' }]);
            FormBuilderService.prototype.getFormBuilder = jest.fn().mockResolvedValue({ id: 1, name: 'test',submittedData:JSON.stringify([{"test":"test"}]) });
            panelData.taskarr[0].serviceType=TaskServiceType.FORM;
            panelData.taskarr[0].params = {
                updateFormFields:[{
                    id:1,
                    formField:"test",
                    updateValue:"test"
                }],
            }
            panelData.form={}
            panelData.formId=1;
            const result = await serviceTask.executeTask(panelData, { id: 1, name: 'test' }, { id: 1, name: 'test' },"test","test", {}, '');
            expect(result).toEqual({ status:true });
        });
    });
});

                    

