import {BpmnNotificationHelper} from '../../../../../src/modules/process-builder/utils/helpers/bpmn-notification.helper';
import {NotificationTemplate} from '../../../../../src/entities/notification-template';
import {PanelDataTask, ProcessAssignee} from '../../../../../src/modules/process-builder/models/enums';
import container from '../../../../../__mocks__/typedi';
describe('BpmnNotificationHelper', () => {
    let service: BpmnNotificationHelper;
    beforeEach(() => {
        service = new BpmnNotificationHelper();
    });
    describe('execute', () => {
        // it('should return success response when type is PanelDataTask.ASSIGN and params.assignto is ProcessAssignee.ROLE', async () => {
        //     container.get().getRepository(NotificationTemplate).find= jest.fn().mockResolvedValue([{message: 'test'}]);
        //     container.get().getRepository().save= jest.fn().mockResolvedValue({id: 1});
        //     await service.execute('test', 'test', {notificationTemplate:'',assignto:ProcessAssignee.ROLE,assigneerole:['role']}, PanelDataTask.ASSIGN, 1, 'test');
        // });
        it('should return success response when type is PanelDataTask.SEND_FOR_REVIEW and params.assignto is ProcessAssignee.USER', async () => {
            container.get().getRepository(NotificationTemplate).find= jest.fn().mockResolvedValue([{message: 'test'}]);
            container.get().getRepository().save= jest.fn().mockResolvedValue({id: 1});
            await service.execute('test', 'test', {notificationTemplate:'',assignto:ProcessAssignee.USER,assignee:['role']}, PanelDataTask.SEND_FOR_REVIEW, 1, 'test');
        });
        it('should return success response when type is PanelDataTask.ASSIGN and params.assignto is ProcessAssignee.ASSIGNED_USER', async () => {
            container.get().getRepository(NotificationTemplate).find= jest.fn().mockResolvedValue([{message: 'test'}]);
            container.get().getRepository().save= jest.fn().mockResolvedValue({id: 1});
            await service.execute('test', 'test', {notificationTemplate:'',assignto:ProcessAssignee.ASSIGNED_USER,assignee:['role']}, PanelDataTask.ASSIGN, 1, 'test');
        });
        it('should return success response when type is PanelDataTask.ASSIGN and params.assignto is ProcessAssignee.FORM_FIELD', async () => {
            container.get().getRepository(NotificationTemplate).find= jest.fn().mockResolvedValue([{message: 'test'}]);
            container.get().getRepository().save= jest.fn().mockResolvedValue({id: 1});
            await service.execute('test', 'test', {notificationTemplate:'',assignto:ProcessAssignee.FORM_FIELD,assignee:['role']}, PanelDataTask.ASSIGN, 1, 'test');
        });
        it('should return success response when type is PanelDataTask.APPROVAL and params.assignto is ProcessAssignee.USER', async () => {
            container.get().getRepository(NotificationTemplate).find= jest.fn().mockResolvedValue([{message: 'test'}]);
            container.get().getRepository().save= jest.fn().mockResolvedValue({id: 1});
            await service.execute('test', 'test', {notificationTemplate:'',assignto:ProcessAssignee.USER,assignee:['role']}, PanelDataTask.APPROVAL, 1, 'test');
        });
        // it('should return success response when type is PanelDataTask.APPROVAL and params.assignto is ProcessAssignee.ROLE', async () => {
        //     container.get().getRepository(NotificationTemplate).find= jest.fn().mockResolvedValue([{message: 'test'}]);
        //     container.get().getRepository().save= jest.fn().mockResolvedValue({id: 1});
        //     await service.execute('test', 'test', {notificationTemplate:'',assignto:ProcessAssignee.ROLE,assigneerole:['role']}, PanelDataTask.APPROVAL, 1, 'test');
        // });
        it('should return success response when type is PanelDataTask.DRAFT_INITIATION', async () => {
            container.get().getRepository(NotificationTemplate).find= jest.fn().mockResolvedValue([{message: 'test'}]);
            container.get().getRepository().save= jest.fn().mockResolvedValue({id: 1});
            await service.execute('test', 'test', {notificationTemplate:'',assignto:ProcessAssignee.ROLE,assignee:['role']}, PanelDataTask.DRAFT_INITIATION, 1, 'test');
        });
        it('should return success response when type is PanelDataTask.START_INITIATION', async () => {
            container.get().getRepository(NotificationTemplate).find= jest.fn().mockResolvedValue([{message: 'test'}]);
            container.get().getRepository().save= jest.fn().mockResolvedValue({id: 1});
            await service.execute('test', 'test', {notificationTemplate:'',assignto:ProcessAssignee.ROLE,assignee:['role']}, PanelDataTask.START_INITIATION, 1, 'test');
        });
        it('should return success response when type is PanelDataTask.RECEIVE_TASK_NOTIFY', async () => {
            container.get().getRepository(NotificationTemplate).find= jest.fn().mockResolvedValue([{message: 'test'}]);
            container.get().getRepository().save= jest.fn().mockResolvedValue({id: 1});
            await service.execute('test', 'test', {notificationTemplate:'',assignto:ProcessAssignee.ROLE,assignee:['role'],checkon:''}, PanelDataTask.START_INITIATION, 1, 'test');
        });

    });
});