import {ProcessBuilderService} from "../../../../../src/modules/process-builder/services/process-builder.service";
import lodash from "lodash";
import {PanelData, PanelDataTask, ProcessCheckOn} from "../../../../../src/modules/process-builder/models";
import {CommunicationHelper} from "../../../../../src/utils/helpers/communication.helper";
import {MailTemplate, NotificationTemplate, Users} from "../../../../../src/entities";
import {In, DataSource} from "typeorm";
import {BpmnNotificationHelper} from "../../../../../src/modules/process-builder/utils/helpers/bpmn-notification.helper";
import Container from 'typedi';
import { ReceiveTask } from "../../../../../src/modules/process-builder-v2/tasks/receive-task";
import container from "../../../../../__mocks__/typedi";
//import { Data } from "applicationinsights/out/Declarations/Contracts";

describe('ReceiveTaskHelper', () => {
    let receiveTask: ReceiveTask;
    let processBuilderService: ProcessBuilderService;
    let communicationHelper: CommunicationHelper;
    let bpmnNotificationHelper: BpmnNotificationHelper;
    let task:any;
    beforeEach(() => {
        receiveTask = new ReceiveTask();
        processBuilderService = new ProcessBuilderService();
        communicationHelper = new CommunicationHelper();
        bpmnNotificationHelper = new BpmnNotificationHelper();
        task={
            id: 1,
            name: 'test',
            type: 'receiveTask',
            processId: 1,
            process: { name: 'test' },
            api:{id:1, name:'test'},
            panelData: { 
                process: { name: 'test' },
                taskarr: [{ id: 1, name: 'test',
                    process: { name: 'test' },
                    taskarr: [],
                    executedActivities:[],
                    params:{
                        mailtemplate:1,
                        recipientMail:"asd@test.com",
                        notificationTemplate:1,
                        alertMasterClient:false,
                        assignee:'test',
    
                    },
                    checkon:ProcessCheckOn.FORM_FIELD,
                 } ],
                executedActivities:[],
                params:{
                    mailtemplate:1,
                    recipientMail:{
                        teamIds:[1],
                        RoleType_ID:1,
                    },
                    notificationTemplate:1,
                    alertMasterClient:false,
                    assignee:'test',
    
                },
                checkon:ProcessCheckOn.FORM_FIELD,
             },
             data:{
                submittedData:JSON.stringify([{"asd@test.com":[{to:"asd@test.com",subject:"test",body:"test"}]}]),
                assignUser:"test",
                EMAIL_CONFIG:"test@test.com"
             },
            bpmnData: { id: 1, referenceId: 1 },
            taskType: 'receiveTask',
            taskCategory: 'receiveTask',
            taskName: 'test',
            taskDescription: 'test',
            taskForm: 'test',
            taskFormId: 'test',
            taskFormName: 'test',
            taskFormDescription: 'test',
            taskFormType: 'test',
            taskFormCategory: 'test',
            taskFormReferenceId: 1,
            taskFormReferenceType: 'test',
            taskFormReferenceName: 'test',
        };
    });
    describe('executeTask', () => {
        it('should execute receive task with checkon as formfield', async () => {
            let getBpmnExecuteMockResults = [{
                id: 1,
                name: 'test',
            },{}];
            const getBpmnExecuteMock = jest.fn();
            getBpmnExecuteMockResults.forEach((mockResult) => {
                getBpmnExecuteMock.mockReturnValueOnce(mockResult);
            });
            ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
            ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);

            CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
            BpmnNotificationHelper.prototype.execute = jest.fn().mockResolvedValue({});
            container.get(DataSource).getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({}),
                find: jest.fn().mockResolvedValue([{ subject: '', body: 'test' }]),
            });
            await receiveTask.executeTask(task);
        });
        it('should execute receive task with checkon as textvalue', async () => {
            let getBpmnExecuteMockResults = [{
                id: 1,
                name: 'test',
            },{}];
            const getBpmnExecuteMock = jest.fn();
            getBpmnExecuteMockResults.forEach((mockResult) => {
                getBpmnExecuteMock.mockReturnValueOnce(mockResult);
            });
            ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
            ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);

            CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
            BpmnNotificationHelper.prototype.execute = jest.fn().mockResolvedValue({});
            container.get(DataSource).getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({}),
                find: jest.fn().mockResolvedValue([{ subject: '', body: 'test' }]),
            });
            task.panelData.checkon=ProcessCheckOn.TEXT_VALUE;
            task.panelData.taskarr[0].checkon=ProcessCheckOn.TEXT_VALUE;
            await receiveTask.executeTask(task);
        });
        it('should execute receive task with checkon as customField', async () => {
            let getBpmnExecuteMockResults = [{
                id: 1,
                name: 'test',
            },{}];
            const getBpmnExecuteMock = jest.fn();
            getBpmnExecuteMockResults.forEach((mockResult) => {
                getBpmnExecuteMock.mockReturnValueOnce(mockResult);
            });
            ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
            ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);

            CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
            BpmnNotificationHelper.prototype.execute = jest.fn().mockResolvedValue({});
            container.get(DataSource).getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({}),
                find: jest.fn().mockResolvedValue([{ subject: '', body: 'test' }]),
            });
            task.panelData.checkon=ProcessCheckOn.CUSTOM_FIELD;
            task.panelData.taskarr[0].checkon=ProcessCheckOn.CUSTOM_FIELD;
            await receiveTask.executeTask(task);
        });
        it('should execute receive task with checkon as assignedUser', async () => {
            let getBpmnExecuteMockResults = [{
                id: 1,
                name: 'test',
            },{}];
            const getBpmnExecuteMock = jest.fn();
            getBpmnExecuteMockResults.forEach((mockResult) => {
                getBpmnExecuteMock.mockReturnValueOnce(mockResult);
            });
            ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
            ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);
            ProcessBuilderService.prototype.getMultipleUser = jest.fn().mockResolvedValue([{ id: 1,email:'test@test.com' }]);

            CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
            BpmnNotificationHelper.prototype.execute = jest.fn().mockResolvedValue({});
            container.get(DataSource).getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({}),
                find: jest.fn().mockResolvedValue([{ subject: '', body: 'test' }]),
            });
            task.panelData.checkon=ProcessCheckOn.ASSIGNED_USER;
            task.panelData.taskarr[0].checkon=ProcessCheckOn.ASSIGNED_USER;
            await receiveTask.executeTask(task);
        });
        it('should execute receive task with checkon as campaignUsers', async () => {
            let getBpmnExecuteMockResults = [{
                id: 1,
                name: 'test',
            },{}];
            const getBpmnExecuteMock = jest.fn();
            getBpmnExecuteMockResults.forEach((mockResult) => {
                getBpmnExecuteMock.mockReturnValueOnce(mockResult);
            });
            ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
            ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);
            ProcessBuilderService.prototype.getMultipleUser = jest.fn().mockResolvedValue([{ id: 1,email:'test@test.com' }]);

            CommunicationHelper.prototype.sendEmail = jest.fn().mockResolvedValue({});
            BpmnNotificationHelper.prototype.execute = jest.fn().mockResolvedValue({});
            container.get(DataSource).getRepository = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({}),
                find: jest.fn().mockResolvedValue([{ subject: '', body: 'test' }]),
            });
            task.panelData.checkon=ProcessCheckOn.CAMPAIGN_USERS;
            task.panelData.taskarr[0].checkon=ProcessCheckOn.CAMPAIGN_USERS;
            await receiveTask.executeTask(task);
        });
        });
});
