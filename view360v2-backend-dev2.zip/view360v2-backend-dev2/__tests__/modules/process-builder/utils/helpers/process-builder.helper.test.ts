import EventEmitter from "events";
import {ProcessBuilderService} from "../../../../../src/modules/process-builder/services/process-builder.service";
import {UserTask} from "../../../../../src/modules/process-builder-v2/tasks/user-task";
import {ReceiveTask} from "../../../../../src/modules/process-builder-v2/tasks/receive-task";
import {TimerTask} from "../../../../../src/modules/process-builder-v2/tasks/timer-task";
import {ServiceTask} from "../../../../../src/modules/process-builder-v2/tasks/service-task";
import {FormBuilderHelper} from "../../../../../src/modules/form-builder/utils/helpers/form-builder.helper";
jest.mock('bpmn-engine');
import { ProcessBuilderHelper } from "../../../../../src/modules/process-builder/utils/helpers/process-builder.helper";
import { Engine } from "../../../../../__mocks__/bpmn-engine";

describe('ProcessBuilderHelper', () => {
    let processBuilderHelper: ProcessBuilderHelper;
    let processBuilderService: ProcessBuilderService;
    let userTask: UserTask;
    let receiveTask: ReceiveTask;
    let timerTask: TimerTask;
    let serviceTask: ServiceTask;
    let formBuilderHelper: FormBuilderHelper;
    let mockListener: EventEmitter;
    beforeEach(async() => {
        processBuilderHelper = new ProcessBuilderHelper();
        processBuilderService = new ProcessBuilderService();
        userTask = new UserTask();
        receiveTask = new ReceiveTask();
        timerTask = new TimerTask();
        serviceTask = new ServiceTask();
        formBuilderHelper = new FormBuilderHelper();
        let getBpmnExecuteMockResults = [{
            id: 1,
            name: 'test',
        },{}];
        const getBpmnExecuteMock = jest.fn();
        getBpmnExecuteMockResults.forEach((mockResult) => {
            getBpmnExecuteMock.mockReturnValueOnce(mockResult);
        });
        ProcessBuilderService.prototype.getBpmnExecute = getBpmnExecuteMock;
        ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1, panelData: { process: { name: 'test' } },bpmnData: { id: 1, referenceId: 1 } }]);

        ServiceTask.prototype.executeTask= jest.fn().mockResolvedValue({});
        mockListener = new EventEmitter();
        const activityStartPromise = new Promise((resolve) => {
            mockListener.on('activity.start', (api) => {
              resolve(api);
            });
          });
            // Simulate the 'activity.start' event
    mockListener.emit('activity.start', { type: 'UserTask' });

    // Wait for the promise to resolve
    const api = await activityStartPromise;
        FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
            findOne: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
            save: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
            findBy: jest.fn().mockResolvedValue([])
        });
        
        Engine.prototype.BpmnEngineExecuteOptions = jest.fn().mockReturnValue({
            listener: expect.any(Function), // You can use expect.any(Function) to match any function
            services: {
                getRequest: jest.fn(async (scope,callback)=>{}),
                check: jest.fn().mockResolvedValue({}),
            }
            });
            
        Engine.prototype.execute = jest.fn((options:any) => {});
        Engine.prototype.execute = jest.fn().mockResolvedValue({});
    });    
    describe('execute', () => {
        it('should execute process builder when formid is passed with bpmnid', async () => {
            FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
                findOne: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
                save: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
                findBy: jest.fn().mockResolvedValue([{ bpmnid : 1 }])
            });
            processBuilderHelper.execute(1,'formid','entryid','',{},'formid', { id: 1, referenceId: 1 });
            expect(FormBuilderHelper.formBuilderRepo).toHaveBeenCalled();
        });
        it('should execute process builder when formid is not passed and bpmnid is passed', async () => {
            processBuilderHelper.execute(1,null,'entryid','',{type:"BPMN_CRON",bpmnid:"bpmnid"},'formid', { id: 1, referenceId: 1 });
        });
        it('should execute process builder when formid is passed and bpmnid is not passed', async () => {
            processBuilderHelper.execute(1,'formid','entryid','',{},null, { id: 1, referenceId: 1 });
            expect(FormBuilderHelper.formBuilderRepo).toHaveBeenCalled();

        });
    });
});