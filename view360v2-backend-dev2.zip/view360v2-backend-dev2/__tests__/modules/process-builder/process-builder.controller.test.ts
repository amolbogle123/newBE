import { ProcessBuilderController } from "../../../src/modules/process-builder/controllers/process-builder.controller";
import { ProcessBuilderService } from "../../../src/modules/process-builder/services/process-builder.service";
import { ProcessCronService } from "../../../src/modules/process-builder/services/process-cron.service";
import { FormBuilderService } from "../../../src/modules/form-builder/services/form-builder.service";
import { FormBuilderHelper } from "../../../src/modules/form-builder/utils/helpers/form-builder.helper";

describe('ProcessBuilderController', () => {
  let controller: ProcessBuilderController;
  beforeAll(async () => {
    jest.clearAllMocks();
  });
  beforeEach(() => {
    controller = new ProcessBuilderController();
  });

  it('should return a success response with all process lists when the rbav parameter is passed as all.', async () => {
    const request = { userDetails: { client_id: 'clientId', id: 'userId' } };
    ProcessBuilderService.prototype.getProcessListDetails = jest.fn().mockResolvedValue({
      status: true, data: [{
        CREATED_BY: 'test',
        ID: 1,
        PROCESSDATA: 'test',
        CREATEDON: 'test',
        FORMNAME: 'test',
        STATUS: 1,
        TYPE: 'test',
      }]
    });
    const result = await controller.getProcessList('all', request);
    expect(result).toBeDefined();
    expect(result.status).toEqual(true);
    expect(result.data).toBeDefined();
    expect(result.data.length).toBeGreaterThan(0);
  });

  it('should return a success response with status code 204 and no process list when the rbav parameter is passed as all.', async () => {
    const request = { userDetails: { client_id: 'clientId', id: 'userId' } };
    ProcessBuilderService.prototype.getProcessListDetails = jest.fn().mockResolvedValue({ status: false, data: null });
    controller.setStatus = jest.fn();
    const result = await controller.getProcessList('all', request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(204);
    expect(result.data).toBeNull();
  });

  it('should return a success response with all process lists when the rbav parameter is not passed as all.', async () => {
    const request = { userDetails: { client_id: 'clientId' } };
    ProcessBuilderService.prototype.getAllProcess = jest.fn().mockResolvedValue({
      status: true, data: [
        {
          "id": 1,
          "panelData": {
            "processtype": "test",
            "type": "test",
            "form": "test",
            "formname": "test",
            "formFields": [],
            "processafter": "test",
            "manualSQLConnector": false,
            "connectorParams": {},
            "timerparams": {
              "starton": "test",
              "cron": "test"
            },
            "starton": "test",
            "process": {
              "name": "test",
              "desc": "test",
              "approval": "Yes"
            },
            "campaign": "test",
            "apiInput": "test",
            "task": "test",
            "taskarr": [],
            "usertaskarr": [],
            "conditionsarr": [
              {
                "id": "",
                "checkon": "",
                "value1": "",
                "check": "",
                "value2": "",
                "params": {},
                "conditionon": "",
                "conditionType": ""
              }
            ],
            "items": [
              {
                "id": "test",
                "type": "test"
              }
            ],
            "tasksarr": [],
            "end": "test",
            "executedActivities": "test"
          },
          "status": 1
        }
      ]
    });
    const result = await controller.getProcessList('', request);
    expect(result).toBeDefined();
    expect(result.status).toEqual(true);
    expect(result.data).toBeDefined();
    expect(result.data.length).toBeGreaterThan(0);
  });

  it('should return a success response with status code 204 and no process list when the rbav parameter is not passed as all.', async () => {
    const request = { userDetails: { client_id: 'clientId' } };
    ProcessBuilderService.prototype.getAllProcess = jest.fn().mockResolvedValue({ status: false, data: null });
    controller.setStatus = jest.fn();
    const result = await controller.getProcessList('', request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(204);
    expect(result.data).toBeNull();
  });

  it('should return a error response with status code 500', async () => {
    const request = { userDetails: { client_id: 'clientId' } };
    ProcessBuilderService.prototype.getAllProcess = jest.fn().mockRejectedValue(new Error('Internal Server Error'));
    controller.setStatus = jest.fn();
    const result = await controller.getProcessList('', request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(500);
    expect(result).toEqual(
      {
        status: false,
        error: {
          error_description: "Internal Server Error",
        },
        message: "Something went wrong !",
      }
    )
  });


  it('should return a success response with a single process data when the process id is passed.', async () => {
    const request = { userDetails: { client_id: 'clientId' }, body: { id: 1 } };

    ProcessBuilderService.prototype.getSingleProcessDetail = jest.fn().mockResolvedValue({
      status: true, data: {
        "id": 1,
        "clientId": 1,
        "formId": "test",
        "type": "test",
        "sqlConnector": 1,
        "bpmnData": "test",
        "panelData": {
          "processtype": "test",
          "type": "test",
          "form": "test",
          "formname": "test",
          "formFields": [],
          "processafter": "test",
          "manualSQLConnector": false,
          "connectorParams": {},
          "timerparams": {
            "starton": "test",
            "cron": "test"
          },
          "starton": "test",
          "process": {
            "name": "test",
            "desc": "test",
            "approval": "Yes"
          },
          "campaign": "test",
          "apiInput": "test",
          "task": "test",
          "taskarr": [],
          "usertaskarr": [],
          "conditionsarr": [
            {
              "id": "",
              "checkon": "",
              "value1": "",
              "check": "",
              "value2": "",
              "params": {},
              "conditionon": "",
              "conditionType": ""
            }
          ],
          "items": [
            {
              "id": "test",
              "type": "test"
            }
          ],
          "tasksarr": [],
          "end": "test",
          "executedActivities": "test"
        },
        "followAfter": "test",
        "createdBy": "test",
        "updatedBy": "test",
        "createdOn": "test",
        "appIdd": "test",
        "status": 1
      }
    });
    const result = await controller.getSingleProcess(request);
    expect(result).toBeDefined();
    expect(result.status).toEqual(true);
    expect(result.data).toBeDefined();
  });

  it('should return a error response with status code 500 when getting single process', async () => {
    const request = { userDetails: { client_id: 'clientId' }, body: { id: 1 } };
    ProcessBuilderService.prototype.getSingleProcessDetail = jest.fn().mockRejectedValue(new Error('Internal Server Error'));
    controller.setStatus = jest.fn();
    const result = await controller.getSingleProcess(request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(500);
    expect(result).toEqual(
      {
        status: false,
        error: {
          error_description: "Internal Server Error",
        },
        message: "Something went wrong !",
      }
    )
  });

  it('should return a success response when saving process data with starton as processcomplete', async () => {
    let panelData = {
      "processtype": "test",
      "type": "test",
      "form": "test",
      "formname": "test",
      "formFields": [],
      "processafter": "test",
      "manualSQLConnector": true,
      "manualSQlConnectorOperation": "test",
      "connectorParams": {
        "sqlTable": "test",
        "columnName": "test",
        "sqlAccount": "test",

      },
      "timerparams": {
        "starton": "test",
        "cron": "test"
      },
      "starton": "processcomplete",
      "process": {
        "name": "test",
        "desc": "test",
        "approval": "Yes"
      },
      "campaign": "test",
      "apiInput": "test",
      "task": "test",
      "taskarr": [],
      "usertaskarr": [],
      "conditionsarr": [
        {
          "id": "",
          "checkon": "",
          "value1": "",
          "check": "",
          "value2": "",
          "params": {},
          "conditionon": "",
          "conditionType": ""
        }
      ],
      "items": [
        {
          "id": "test",
          "type": "test"
        }
      ],
      "tasksarr": [],
      "end": "test",
      "executedActivities": "test"
    }
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "clientId": 1,
        "formId": "test",
        "panel": panelData
      }
    };
    let mockResponseSaveOrUpdateBpmn = {
      data: {
        "id": 1,
        "clientId": 1,
        "formId": "test",
        "type": "test",
        "sqlConnector": 1,
        "bpmnData": "test",
        "panelData": panelData,
        "followAfter": "test",
        "createdBy": "test",
        "updatedBy": "test",
        "createdOn": "test",
        "appIdd": "test",
        "status": 1
      },
      "message": "Something went wrong !",
      "status": "success",
    }
    ProcessBuilderService.prototype.getBpmnById = jest.fn().mockResolvedValue({ formId: 1 });
    ProcessBuilderService.prototype.saveOrUpdateBpmn = jest.fn().mockResolvedValue(mockResponseSaveOrUpdateBpmn);
    const result = await controller.saveProcess(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: true,
      data: {
        lastInsertId: 1,
      },
      message: "Successfully executed.",
    });
  });
  it('should return a success response when saving process data with starton as timerbased', async () => {
    let panelData = {
      "processtype": "test",
      "type": "test",
      "form": "test",
      "formname": "test",
      "formFields": [],
      "processafter": "test",
      "manualSQLConnector": true,
      "manualSQlConnectorOperation": "test",
      "connectorParams": {
        "sqlTable": "test",
        "columnName": "test",
        "sqlAccount": "test",

      },
      "timerparams": {
        "starton": "test",
        "cron": "test"
      },
      "starton": "timerbased",
      "process": {
        "name": "test",
        "desc": "test",
        "approval": "Yes"
      },
      "campaign": "test",
      "apiInput": "test",
      "task": "test",
      "taskarr": [],
      "usertaskarr": [],
      "conditionsarr": [
        {
          "id": "",
          "checkon": "",
          "value1": "",
          "check": "",
          "value2": "",
          "params": {},
          "conditionon": "",
          "conditionType": ""
        }
      ],
      "items": [
        {
          "id": "test",
          "type": "test"
        }
      ],
      "tasksarr": [],
      "end": "test",
      "executedActivities": "test"
    }
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "clientId": 1,
        "formId": "test",
        "panel": panelData
      }
    };
    let mockResponseSaveOrUpdateBpmn = {
      data: {
        "id": 1,
        "clientId": 1,
        "formId": "test",
        "type": "test",
        "sqlConnector": 1,
        "bpmnData": "test",
        "panelData": panelData,
        "followAfter": "test",
        "createdBy": "test",
        "updatedBy": "test",
        "createdOn": "test",
        "appIdd": "test",
        "status": 1
      },
      "message": "Something went wrong !",
      "status": "success",
    }
    ProcessBuilderService.prototype.getBpmnById = jest.fn().mockResolvedValue({ formId: 1 });
    ProcessBuilderService.prototype.saveOrUpdateBpmn = jest.fn().mockResolvedValue(mockResponseSaveOrUpdateBpmn);
    const result = await controller.saveProcess(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: true,
      data: {
        lastInsertId: 1,
      },
      message: "Successfully executed.",
    });
  });

  it('should return a error response with status code 500 when saving process data', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "clientId": 1,
        "formId": "test",
        "panel": {}
      }
    };
    ProcessBuilderService.prototype.saveOrUpdateBpmn = jest.fn().mockRejectedValue(new Error('Internal Server Error'));
    controller.setStatus = jest.fn();
    const result = await controller.saveProcess(request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(500);
    expect(result).toEqual(
      {
        status: false,
        error: {
          error_description: "Internal Server Error",
        },
        message: "Something went wrong !",
      }
    )
  });

  it('should return a success response when updating process data', async () => {
    let panelData = {
      "processtype": "test",
      "type": "test",
      "form": "test",
      "formname": "test",
      "formFields": [],
      "processafter": "test",
      "manualSQLConnector": true,
      "connectorParams": {},
      "timerparams": {
        "starton": "test",
        "cron": "test"
      },
      "starton": "processcomplete",
      "process": {
        "name": "test",
        "desc": "test",
        "approval": "Yes"
      },
      "campaign": "test",
      "apiInput": "test",
      "task": "test",
      "taskarr": [],
      "usertaskarr": [],
      "conditionsarr": [
        {
          "id": "",
          "checkon": "",
          "value1": "",
          "check": "",
          "value2": "",
          "params": {},
          "conditionon": "",
          "conditionType": ""
        }
      ],
      "items": [
        {
          "id": "test",
          "type": "test"
        }
      ],
      "tasksarr": [],
      "end": "test",
      "executedActivities": "test"
    }
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": 1,
        "clientId": 1,
        "formId": "test",
        "panel": panelData
      }
    };
    let mockResponseSaveOrUpdateBpmn = {
      data: {
        "id": 1,
        "clientId": 1,
        "formId": "test",
        "type": "test",
        "sqlConnector": 1,
        "bpmnData": "test",
        "panelData": panelData,
        "followAfter": "test",
        "createdBy": "test",
        "updatedBy": "test",
        "createdOn": "test",
        "appIdd": "test",
        "status": 1
      },
      "message": "Something went wrong !",
      "status": "success",
    }
    ProcessBuilderService.prototype.getBpmnById = jest.fn().mockResolvedValue({ formId: 1 });
    ProcessBuilderService.prototype.saveOrUpdateBpmn = jest.fn().mockResolvedValue(mockResponseSaveOrUpdateBpmn);
    const result = await controller.updateProcess(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: true,
      data: {
        updatedRows: 1,
      },
      message: "Successfully executed."
    });
  });

  it('should return a error response with status code 500 when updating process data', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": 1,
        "clientId": 1,
        "formId": "test",
        "panel": {}
      }
    };
    ProcessBuilderService.prototype.saveOrUpdateBpmn = jest.fn().mockRejectedValue(new Error('Internal Server Error'));
    controller.setStatus = jest.fn();
    const result = await controller.updateProcess(request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(500);
    expect(result).toEqual(
      {
        status: false,
        error: {
          error_description: "Internal Server Error",
        },
        message: "Something went wrong !",
      }
    )
  });

  it('should return a success response when deleting process data', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": ["1"],
        "clientId": 1,
      }
    };
    let mockResponseDeleteMultipleProcess = {
      "data": {
        "affected": 1,
      },
      "message": "Process has been deleted successfully.",
      "status": "success",
    }
    ProcessCronService.prototype.deleteCron = jest.fn().mockResolvedValue({ status: 'success', message: null, data: null });
    ProcessBuilderService.prototype.deleteMultipleProcess = jest.fn().mockResolvedValue(mockResponseDeleteMultipleProcess);
    const result = await controller.deleteMultipleProcess(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: true,
      data: 1,
      message: "Successfully executed."
    });
  });
  it('should return a error response with status code 500 when deleting process data', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": ["1"],
        "clientId": 1,
      }
    };
    ProcessBuilderService.prototype.deleteMultipleProcess = jest.fn().mockRejectedValue(new Error('Internal Server Error'));
    controller.setStatus = jest.fn();
    const result = await controller.deleteMultipleProcess(request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(500);
    expect(result).toEqual(
      {
        status: false,
        error: {
          error_description: "Internal Server Error",
        },
        message: "Something went wrong !",
      }
    )
  });

  it('should return a success response when updating process status', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "status": 1,
      }
    };
    let mockResponseUpdateProcessStatus = {
      "data": {
        "updatedRows": 1,
      },
      "message": null,
      "status": "success",
    }
    ProcessBuilderService.prototype.getBpmnById = jest.fn().mockResolvedValue({ formId: 1 });
    ProcessBuilderService.prototype.updateBpmn = jest.fn().mockResolvedValue(mockResponseUpdateProcessStatus);
    const result = await controller.updateStatus(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: true,
      message: "Status has been updated successfully."
    });
  });
  it('should return a error response with status code 500 when updating process status', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "status": 1,
      }
    };
    ProcessBuilderService.prototype.updateBpmn = jest.fn().mockRejectedValue(new Error('Internal Server Error'));
    controller.setStatus = jest.fn();
    const result = await controller.updateStatus(request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(500);
    expect(result).toEqual(
      {
        status: false,
        error: {
          error_description: "Internal Server Error",
        },
        message: "Something went wrong !",
      }
    )
  });
  it('should return a error response when updating process status with empty id', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "",
        "status": 1,
      }
    };
    const result = await controller.updateStatus(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      error: null,
      status: false,
      message: "Couldn\'t process; bpmn id not found !"
    });
  });
  it('should return a error response with status code 404 when updating process status and process not found', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "status": 1,
      }
    };
    ProcessBuilderService.prototype.getBpmnById = jest.fn().mockResolvedValue(null);
    controller.setStatus = jest.fn();
    const result = await controller.updateStatus(request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(404);
    expect(result).toEqual(
      {
        status: false,
        error: null,
        message: "Couldn\'t process; data not found !",
      }
    )
  });
  it('should return a success response with valid message when updating process status and status is already same', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "status": 1,
      }
    };
    ProcessBuilderService.prototype.getBpmnById = jest.fn().mockResolvedValue({ status: 1 });
    const result = await controller.updateStatus(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: true,
      message: "Status update not required."
    });
  });


  it('should return a success response when initiating process', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "tempId": "1",
        "entryId": "1"
      }
    };
    let mockResponseUpdateProcessStatus = {
      "data": {
        "updatedRows": 1,
      },
      "message": null,
      "status": "success",
    }

    FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
      findOne: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
      save: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
      findBy: jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]),
    });
    FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
    ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([{ id: 1, panelData: { process: { name: 'test' } } }]);
    ProcessBuilderService.prototype.getBpmnExecute = jest.fn().mockResolvedValue({});
    ProcessBuilderService.prototype.updateBpmnExecute = jest.fn().mockResolvedValue(mockResponseUpdateProcessStatus);
    const result = await controller.nextProcess(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: true,
      message: "Status has been updated successfully."
    });
  });
  it('should return a error response with status code 500 when initiating process', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "tempId": "1",
        "entryId": "1"
      }
    };
    ProcessBuilderService.prototype.getBpmnExecute = jest.fn().mockRejectedValue(new Error('Internal Server Error'));
    controller.setStatus = jest.fn();
    const result = await controller.nextProcess(request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(500);
    expect(result).toEqual(
      {
        status: false,
        error: {
          error_description: "Internal Server Error",
        },
        message: "Something went wrong !",
      }
    );
  });

  it('should return a success response when marking proceess with status as reject', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "tempId": "1",
        "entryId": "1",
        "bpmnId": "1",
        "status": "reject",
        "params": {
          "saveResultApproval": {
            "id": "1",
            "status": "reject"
          },
          "saveResultOn": {
            "id": "1",
            "status": "reject"
          }
        },
        "reject": {
          "onreject": "sendtoaction"
        }
      }
    };
    FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
      findOne: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
      save: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
      findBy: jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]),
    });
    FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
    FormBuilderService.prototype.getFormBuilder = jest.fn().mockResolvedValue({
      id: 1, submittedData: {
        "saveResultApproval": {
          "id": "1",
          "status": "reject"
        },
        "saveResultOn": {
          "id": "1",
          "status": "reject"
        },
        "saveResult": {
          "id": "1",
          "status": "reject"
        }
      }
    });
    FormBuilderService.prototype.updateFormBuilder = jest.fn().mockResolvedValue({ id: 1, referenceId: 1 });
    ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([]);
    ProcessBuilderService.prototype.getBpmnExecute = jest.fn().mockResolvedValue([{ id: 1, activityId: 1 }]);
    ProcessBuilderService.prototype.saveOrUpdateBpmnExecute = jest.fn().mockResolvedValue({});
    const result = await controller.statusProcess(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: "success",
      message: "Operation has been successfully executed.",
      data: null
    });
  });
  it('should return a error response with status code 500 when marking proceess with status as reject', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "tempId": "1",
        "entryId": "1",
        "bpmnId": "1",
        "status": "reject",
        "params": {
          "saveResultApproval": {
            "id": "1",
            "status": "reject"
          },
          "saveResultOn": {
            "id": "1",
            "status": "reject"
          }
        },
        "reject": {
          "onreject": "sendtoaction"
        }
      }
    };
    ProcessBuilderService.prototype.getBpmnExecute = jest.fn().mockRejectedValue(new Error('Internal Server Error'));
    controller.setStatus = jest.fn();
    const result = await controller.statusProcess(request);
    expect(result).toBeDefined();
    expect(controller.setStatus).toHaveBeenCalledWith(500);
    expect(result).toEqual(
      {
        status: false,
        error: {
          error_description: "Internal Server Error",
        },
        message: "Something went wrong !",
      }
    );
  });
  it('should return a success response when marking process with status as userAssigned or approve', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "tempId": "1",
        "entryId": "1",
        "bpmnId": "1",
        "status": "userAssigned",
        "params": {
          "saveResultApproval": {
            "id": "1",
            "status": "userAssigned"
          },
          "saveResultOn": {
            "id": "1",
            "status": "userAssigned"
          }
        },
        "reject": {
          "onreject": "sendtoaction"
        }
      }
    };

    FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
      findOne: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
      save: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
      findBy: jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]),
    });
    FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
    FormBuilderService.prototype.getFormBuilder = jest.fn().mockResolvedValue({
      id: 1, submittedData: {
        "saveResultApproval": {
          "id": "1",
          "status": "userAssigned"
        },
        "saveResultOn": {
          "id": "1",
          "status": "userAssigned"
        },
        "saveResult": {
          "id": "1",
          "status": "userAssigned"
        }
      }
    });
    FormBuilderService.prototype.updateFormBuilder = jest.fn().mockResolvedValue({ id: 1, referenceId: 1, affected: 1 });
    ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([]);
    ProcessBuilderService.prototype.getBpmnExecute = jest.fn().mockResolvedValue([{ id: 1, activityId: 1 }]);
    ProcessBuilderService.prototype.updateBpmnExecute = jest.fn().mockResolvedValue({ data: { affected: 1 } });
    const result = await controller.statusProcess(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: true,
      message: "Successfully executed.",
      data: {
        data: {
          affected: 1,
        }
      }
    });
  });
  it('should return a success response when marking process with status as markcomplete', async () => {
    const request = {
      userDetails: { client_id: 'clientId', id: "id" }, body: {
        "id": "1",
        "tempId": "1",
        "entryId": "1",
        "bpmnId": "1",
        "status": "markcomplete",
        "params": {
          "saveResultApproval": {
            "id": "1",
            "status": "markcomplete"
          },
          "saveResultOn": {
            "id": "1",
            "status": "markcomplete"
          }
        },
        "reject": {
          "onreject": "sendtoaction"
        }
      }
    };

    FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
      findOne: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
      save: jest.fn().mockResolvedValue({ id: 1, referenceId: 1 }),
      findBy: jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]),
    });
    FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ id: 1, referenceId: 1 }]);
    FormBuilderService.prototype.getFormBuilder = jest.fn().mockResolvedValue({
      id: 1, submittedData: {
        "saveResultApproval": {
          "id": "1",
          "status": "markcomplete"
        },
        "saveResultOn": {
          "id": "1",
          "status": "markcomplete"
        },
        "saveResult": {
          "id": "1",
          "status": "markcomplete"
        }
      }
    });
    FormBuilderService.prototype.updateFormBuilder = jest.fn().mockResolvedValue({ id: 1, referenceId: 1, affected: 1 });
    ProcessBuilderService.prototype.getMultipleBpmn = jest.fn().mockResolvedValue([]);
    ProcessBuilderService.prototype.getBpmnExecute = jest.fn().mockResolvedValue([{ id: 1, activityId: 1 }]);
    ProcessBuilderService.prototype.saveOrUpdateBpmnExecute = jest.fn().mockResolvedValue({});
    const result = await controller.statusProcess(request);
    expect(result).toBeDefined();
    expect(result).toEqual({
      status: true,
      message: "Operation has been successfully executed.",
    });
  });
});