import { ProcessCronService } from "../../../../src/modules/process-builder/services/process-cron.service";
import axios from 'axios';
import { CommonHelper, SetResponse } from "../../../../src/utils/helpers/common.helper";
import { StatusType } from "../../../../src/models/enums";
import * as txt from "../../../../src/modules/process-builder/utils/constants/api.constant";
import { json } from "stream/consumers";

describe('ProcessCronService', () => {
    describe('addCron', () => {
        it('should return success response', async () => {
            const mockResponse = {
                data: {
                    status: StatusType.SUCCESS
                }
            };
            jest.spyOn(axios, 'post').mockResolvedValue(mockResponse);
            const service = new ProcessCronService();
            const response = await service.addCron({
                hitApi: '/test',
                hitMethod: 'POST',
                cronType: 'test',
                refId: 'test'
            });
            expect(response).toEqual(CommonHelper.setResponse(StatusType.SUCCESS));
        });
        it('should return error response', async () => {
            jest.spyOn(axios, 'post').mockRejectedValue({});
            const service = new ProcessCronService();
            const response = await service.addCron({
                hitApi: '/test',
                hitMethod: 'POST',
                cronType: 'test',
                refId: 'test'
            });
            expect(response).toEqual({"status":"error","message":"Couldn't process; data not found !","data":{"data":{}}});
        });
    });
    describe('deleteCron', () => {
        it('should return success response', async () => {
            const mockResponse = {
                data: {
                    status: StatusType.SUCCESS
                }
            };
            jest.spyOn(axios, 'post').mockResolvedValue(mockResponse);
            const service = new ProcessCronService();
            const response = await service.deleteCron('test');
            expect(response).toEqual(CommonHelper.setResponse(StatusType.SUCCESS));
        });
        it('should return error response', async () => {
            jest.spyOn(axios, 'post').mockRejectedValue({});
            const service = new ProcessCronService();
            const response = await service.deleteCron('test');
            expect(response).toEqual({"status":"error","message":"Couldn't process; reference id not found !","data":{"data":{}}});
        });
    });
});