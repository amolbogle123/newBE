import { ProcessBuilderService } from '../../../../src/modules/process-builder/services/process-builder.service';
import container from '../../../../__mocks__/typedi';
describe('ProcessBuilderService', () => {
        let processBuilderService: ProcessBuilderService;
        beforeEach(() => {
            processBuilderService = new ProcessBuilderService();
        });
        describe('isBpmnExist', () => {
            it('should return true', async () => {
                container.get().getRepository().count = jest.fn().mockReturnValue(1);
                const result = await processBuilderService.isBpmnExist({});
                expect(result).toBe(true);
            });
        });
        describe('getBpmnById', () => {
            it('should return null', async () => {
                container.get().getRepository().findOne = jest.fn().mockReturnValue(null);
                const result = await processBuilderService.getBpmnById('id', []);
                expect(result).toBe(null);
            });
            it('should return object', async () => {
                container.get().getRepository().findOne = jest.fn().mockReturnValue({});
                const result = await processBuilderService.getBpmnById('id', []);
                expect(result).toEqual({});
            });
        });
        describe('runCustomizedQuery', () => {
            it('should return null', async () => {
                container.get().manager.query = jest.fn().mockReturnValue(null);
                const result = await processBuilderService.runCustomizedQuery('queryStatement', []);
                expect(result).toBe(null);
            });
            it('should return object', async () => {
                container.get().manager.query = jest.fn().mockReturnValue({});
                const result = await processBuilderService.runCustomizedQuery('queryStatement', []);
                expect(result).toEqual({});
            });
        });
        describe('getProcessListDetails', () => {
            // it('should return null', async () => {
            //     container.get().getRepository().find = jest.fn().mockReturnValue(null);
            //     const result = await processBuilderService.getProcessListDetails({}, 'userType', []);
            //     expect(result).toBe(null);
            // });
            it('should return object', async () => {
                container.get().getRepository().find = jest.fn().mockReturnValue([{
                    createdBy: 'createdBy',
                    id: 'id',
                    panelData: '{"process": "process", "formname": "formname"}',
                    createdOn: 'createdOn',
                    status: 'status',
                    type: 'type',
                }]);
                const result = await processBuilderService.getProcessListDetails({}, 'userType', [],10,10,{});
                expect(result).toEqual({
                    data: [{
                        CREATEDON: 'createdOn',
                        CREATED_BY: 'createdBy',
                        ID: 'id',
                        PROCESSDATA:"\"process\"",
                        FORMNAME: "\"formname\"",
                        STATUS: 'status',
                        TYPE: 'type',
                    }],
                    message:null,
                    status:"success"

                });
            });
        });
        describe('getAllProcess', () => {
            // it('should return null', async () => {
            //     const result = await processBuilderService.getAllProcess(0, []);
            //     expect(result).toBe(null);
            // });
            it('should return object', async () => {
                container.get().getRepository().find = jest.fn().mockReturnValue([{
                    createdBy: 'createdBy',
                    id: 'id',
                    panelData: '{"process": "process", "formname": "formname"}',
                    createdOn: 'createdOn',
                    status: 'status',
                    type: 'type',
                }]);
                const result = await processBuilderService.getAllProcess(0, [],10,10,{});
                expect(result).toEqual({
                    data: [{
                        createdOn: 'createdOn',
                        createdBy: 'createdBy',
                        id: 'id',
                        panelData:"{\"process\": \"process\", \"formname\": \"formname\"}",
                        status: 'status',
                        type: 'type',
                    }],
                    message:null,
                    status:"success"

                });
            });
        });
        describe('getSingleProcessDetail', () => {
            // it('should return null', async () => {
            //     const result = await processBuilderService.getSingleProcessDetail({});
            //     expect(result).toBe(null);
            // });
            it('should return object', async () => {
                container.get().getRepository().findOne = jest.fn().mockReturnValue({
                    createdBy: 'createdBy',
                    id: 'id',
                    panelData: '{"process": "process", "formname": "formname"}',
                    createdOn: 'createdOn',
                    status: 'status',
                    type: 'type',
                });
                const result = await processBuilderService.getSingleProcessDetail({});
                expect(result).toEqual({
                    data: {
                        createdOn: 'createdOn',
                        createdBy: 'createdBy',
                        id: 'id',
                        "panelData": "{\"process\": \"process\", \"formname\": \"formname\"}",
                        status: 'status',
                        type: 'type',
                    },
                    message:null,
                    status:"success"

                });
            });
        });
        describe('getMultipleBpmn', () => {
            // it('should return null', async () => {
            //     const result = await processBuilderService.getMultipleBpmn({}, []);
            //     expect(result).toBe(null);
            // });
            it('should return object', async () => {
                container.get().getRepository().find = jest.fn().mockReturnValue([{
                    createdBy: 'createdBy',
                    id: 'id',
                    panelData: '{"process": "process", "formname": "formname"}',
                    createdOn: 'createdOn',
                    status: 'status',
                    type: 'type',
                }]);
                const result = await processBuilderService.getMultipleBpmn({}, []);
                expect(result).toEqual([{
                    createdOn: 'createdOn',
                    createdBy: 'createdBy',
                    id: 'id',
                    "panelData": "{\"process\": \"process\", \"formname\": \"formname\"}",
                    status: 'status',
                    type: 'type',
                }]);
            });
        });
        describe('deleteProcess', () => {
            // it('should return null', async () => {
            //     const result = await processBuilderService.deleteProcess({});
            //     expect(result).toBe(null);
            // });
            it('should return object with success status when Bpmn exists', async () => {
                container.get().getRepository().delete = jest.fn().mockReturnValue({});
                const result = await processBuilderService.deleteProcess({});
                expect(result).toEqual({
                    data: null,
                    message:"Process has been deleted successfully.",
                    status:"success"

                });
            });
            it('should return object with error status when Bpmn does not exists', async () => {
                container.get().getRepository().delete = jest.fn().mockReturnValue(null);
                processBuilderService.isBpmnExist = jest.fn().mockReturnValue(false);
                const result = await processBuilderService.deleteProcess({});
                expect(result).toEqual({
                    data: null,
                    message:"Couldn\'t process; data not found !",
                    status:"error"

                });
            });

        });
        describe('deleteMultipleProcess', () => {
            it('should return object with success status', async () => {
                container.get().getRepository().delete = jest.fn().mockReturnValue({});
                const result = await processBuilderService.deleteMultipleProcess([]);
                expect(result).toEqual({
                    data: null,
                    message:"Process has been deleted successfully.",
                    status:"success"

                });
            });
        });
        describe('getBpmnExecute', () => {
            it('should return object', async () => {
                container.get().getRepository().find = jest.fn().mockReturnValue([{
                    createdBy: 'createdBy',
                    id: 'id',
                    panelData: '{"process": "process", "formname": "formname"}',
                    createdOn: 'createdOn',
                    status: 'status',
                    type: 'type',
                }]);
                const result = await processBuilderService.getBpmnExecute({}, []);
                expect(result).toEqual([{
                    createdOn: 'createdOn',
                    createdBy: 'createdBy',
                    id: 'id',
                    "panelData": "{\"process\": \"process\", \"formname\": \"formname\"}",
                    status: 'status',
                    type: 'type',
                }]);
            });
        });
        describe('getBpmnSql', () => {
           it('should return object', async () => {
                container.get().getRepository().find = jest.fn().mockReturnValue([{
                     createdBy: 'createdBy',
                     id: 'id',
                     panelData: '{"process": "process", "formname": "formname"}',
                     createdOn: 'createdOn',
                     status: 'status',
                     type: 'type',
                }]);
                const result = await processBuilderService.getBpmnSql({}, []);
                expect(result).toEqual({
                     data: [{
                          createdOn: 'createdOn',
                          createdBy: 'createdBy',
                          id: 'id',
                          "panelData": "{\"process\": \"process\", \"formname\": \"formname\"}",
                          status: 'status',
                          type: 'type',
                     }],
                     message:null,
                     status:"success"
    
                });
              });
        });
        describe('saveOrUpdateBpmn', () => {
            it('should return object with success status', async () => {
                container.get().getRepository().save = jest.fn().mockReturnValue({});
                const result = await processBuilderService.saveOrUpdateBpmn({});
                expect(result).toEqual({
                    data: null,
                    message:null,
                    status:"success"

                });
            });
        });
        describe('updateBpmn', () => {
            it('should return object with success status', async () => {
                container.get().getRepository().update = jest.fn().mockReturnValue({});
                const result = await processBuilderService.updateBpmn({}, {});
                expect(result).toEqual({
                    data: null,
                    message:null,
                    status:"success"

                });
            });
        });
        describe('saveOrUpdateBpmnExecute', () => {
            it('should return object with success status', async () => {
                container.get().getRepository().save = jest.fn().mockReturnValue({});
                const result = await processBuilderService.saveOrUpdateBpmnExecute({});
                expect(result).toEqual({
                    data: null,
                    message:null,
                    status:"success"

                });
            });
        });
        describe('updateBpmnExecute', () => {
            it('should return object with success status', async () => {
                container.get().getRepository().update = jest.fn().mockReturnValue({});
                const result = await processBuilderService.updateBpmnExecute({}, {});
                expect(result).toEqual({
                    data: null,
                    message:null,
                    status:"success"

                });
            });
        });
        describe('getSingleCampaign', () => {
            it('should return object with success status', async () => {
                container.get().getRepository().findOne = jest.fn().mockReturnValue({});
                const result = await processBuilderService.getSingleCampaign({},[]);
                expect(result).toEqual({
                    data: null,
                    message:null,
                    status:"success"

                });
            });
        });
        describe('saveOrUpdateBpmnSql', () => {
            it('should return object with success status', async () => {
                container.get().getRepository().save = jest.fn().mockReturnValue({});
                const result = await processBuilderService.saveOrUpdateBpmnSql({});
                expect(result).toEqual({
                    data: null,
                    message:null,
                    status:"success"

                });
            });
        });
        describe('getMultipleUser', () => {
            it('should return object with success status', async () => {
                container.get().getRepository().find = jest.fn().mockReturnValue([{}]);
                const result = await processBuilderService.getMultipleUser({}, []);
                expect(result).toEqual([{}]);
            });
        });
        describe('getMdbClient', () => {
            it('should return object with success status', async () => {
                container.get().getRepository().find = jest.fn().mockReturnValue([{}]);
                const result = await processBuilderService.getMdbClient({}, []);
                expect(result).toEqual([{}]);
            });
        });
        
});