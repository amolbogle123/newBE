import { CommonHelper } from "../../../src/utils/helpers/common.helper";
import { FormBuilderController } from "../../../src/modules/form-builder/controllers/form-builder.controller";
import { createFormBody, updateFormBody } from "../../asset/form-body";
import { FormBuilderService } from "../../../src/modules/form-builder/services/form-builder.service";
import { FormBuilderHelper } from "../../../src/modules/form-builder/utils/helpers/form-builder.helper";
import { DocumentService } from "../../../src/modules/documents/services/document.service";

describe('FormBuilderController', () => {
    let controller: FormBuilderController;

    CommonHelper.apiSwaggerSuccessResponse = jest.fn((data) => data);
    CommonHelper.apiSwaggerErrorResponse = jest.fn((error) => error);

    beforeAll(async () => {
        jest.clearAllMocks();
    });

    beforeEach(() => {
        controller = new FormBuilderController();
    });

    it('should return API success response when request is valid', async () => {
        const req = {
            userDetails: {
                client_id: 'someClientId',
                id: 'someUserId'
            },
            body: createFormBody
        };

        FormBuilderService.prototype.saveCustomForms = jest.fn().mockResolvedValue({ referenceId: 'refId' });
        FormBuilderHelper.formBuilderRepo = jest.fn();
        FormBuilderHelper.formBuilderHistoryRepo = jest.fn();

        controller.setStatus = jest.fn();

        const result = await controller.createFormBuilder(req.body, req);

        expect(controller.setStatus).toBeCalledWith(201);
        expect(result).toHaveProperty('data');
        expect(result).toHaveProperty('message');
        expect(result).toEqual({
            data: { referenceId: "refId" },
            message: "Form status has been saved successfully",
        });
    });

    it('should return API error response if an error is thrown', async () => {
        const req = {
            userDetails: {
                client_id: 'someClientId',
                id: 'someUserId'
            },
            body: createFormBody,
        };

        FormBuilderService.prototype.saveCustomForms = jest.fn().mockRejectedValue(new Error('Failed to save form'));

        const result = await controller.createFormBuilder(req.body, req);

        expect(result).toHaveProperty('error');
        expect((result as any).error.error_description).toBe('Failed to save form');
    });

    it('should update a custom form and return a success response', async () => {
        // Mock the request object with necessary data
        const req = {
            userDetails: {
                client_id: 'someClientId',
                id: 'someUserId',
            },
            body: updateFormBody,
        };

        FormBuilderService.prototype.updateCustomForms = jest.fn().mockResolvedValue({
            affected: 1
        })

        const result = await controller.updateFormBuilder(req.body, req);

        // Assertions
        expect(result).toHaveProperty('message');
        expect(result).toEqual({
            "data": {
                "affected": 1,
            },
            "message": "Form status has been updated successfully",
        });
    });

    it('should handle an error and return an error response', async () => {
        // Mock the request object with necessary data
        const req = {
            userDetails: {
                client_id: 'someClientId',
                id: 'someUserId',
            },
            body: updateFormBody
        };

        FormBuilderService.prototype.updateCustomForms = jest.fn().mockRejectedValue(new Error('Something went wrong'));

        const result = await controller.updateFormBuilder(req.body, req);

        expect(result).toHaveProperty('error');
        expect((result as any).error.error_description).toBe('Something went wrong');
    });

    it('should update the mapped user and return a success response', async () => {
        // Mock the request object with necessary data
        const req = {
            body: {
                formId: 'someFormId',
                mappedUser: [
                    { userId: 'someUserId' },
                ],
            },
        };

        FormBuilderService.prototype.updateCustomForms = jest.fn().mockResolvedValue({
            affected: 1
        })

        const result = await controller.updateFormMappedUser(req.body)
        // Assertions
        expect(result).toHaveProperty('message');
        expect(result).toEqual({
            message: "Form status has been updated successfully",
        });
    });

    it('should handle an error and return an error response', async () => {
        // Mock the request object with necessary data
        const req = {
            body: {
                formId: 'someFormId',
                mappedUser: [
                    { userId: 'someUserId' },
                ],
            },
        };

        FormBuilderService.prototype.updateCustomForms = jest.fn().mockRejectedValue(new Error('Something went wrong'));

        const result = await controller.updateFormMappedUser(req.body);

        // Assertions
        expect(result).toHaveProperty('error');
        expect((result as any).error.error_description).toBe('Something went wrong');
    });

    it('should delete form builder records and return success response', async () => {
        // Mock the request object with necessary data
        const req = {
            body: {
                formId: ['formId1', 'formId2'],
            },
            userDetails: {
                client_id: 'clientId',
            },
        };

        FormBuilderService.prototype.deleteCustomForms = jest.fn().mockResolvedValue({ affected: 2 });

        controller.getReferenceId = jest.fn().mockResolvedValue('referenceId');

        FormBuilderService.prototype.deleteFormBuilder = jest.fn().mockResolvedValue({});
        FormBuilderService.prototype.deleteFormBuilderHistory = jest.fn().mockResolvedValue({});

        const result = await controller.deleteFormBuilder(req.body, req);

        // Assertions
        expect(controller.getReferenceId).toHaveBeenCalledTimes(2); // Assuming 2 formIds were provided
        expect(FormBuilderService.prototype.deleteFormBuilder).toHaveBeenCalledTimes(2); // Assuming 2 formIds were provided
        expect(FormBuilderService.prototype.deleteFormBuilderHistory).toHaveBeenCalledTimes(2); // Assuming 2 formIds were provided
        expect(result).toHaveProperty('message');
        expect(result).toEqual({
            message: "Form status has been deleted successfully",
        });
    });

    it('should handle an error and return an error response', async () => {
        // Mock the request object with necessary data
        const req = {
            body: {
                formId: ['formId1', 'formId2'],
            },
            userDetails: {
                client_id: 'clientId',
            },
        };

        controller.getReferenceId = jest.fn().mockRejectedValue(new Error('Something went wrong'));

        const result = await controller.deleteFormBuilder(req.body, req);

        // Assertions
        expect(result).toHaveProperty('error');
        expect((result as any).error.error_description).toBe('Something went wrong');
    });

    it('should return the referenceId', async () => {
        // Mock the parameters
        const clientId = 123;
        const formId = 'formId1';

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([
            {
                referenceId: 'mockReferenceId',
            },
        ])

        // Call the function
        const result = await controller.getReferenceId(clientId, formId);

        // Assertions
        expect(result).toBe('mockReferenceId');
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith(
            { clientId: clientId, id: formId },
            ['referenceId']
        );
    });

    it('should return a list of forms', async () => {
        // Mock the userDetails in the request
        const mockUserDetails = {
            client_id: 'mockClientId',
        };
        const mockRequest = {
            userDetails: mockUserDetails,
        };

        // Mock the results from your formBuilderService
        const mockResultData = [
            {
                id: 'form1',
                docId: 'doc1',
                formName: 'Form 1',
                formDescription: 'Description 1',
                formData: '{}',
                formDataConfig: '{}',
            },
            {
                id: 'form2',
                docId: 'doc2',
                formName: 'Form 2',
                formDescription: 'Description 2',
                formData: '{}',
                formDataConfig: '{}',
            },
        ];

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue(mockResultData)

        // Call the function
        const result = await controller.getAllFormList(mockRequest);

        // Assertions
        expect(result).toEqual({
            data: mockResultData,
        });
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith(
            { clientId: mockUserDetails.client_id },
            ['id', 'docId', 'formName', 'formDescription', 'formData', 'formDataConfig']
        );
    });

    it('should return an empty list if no forms are found', async () => {
        // Mock the userDetails in the request
        const mockUserDetails = {
            client_id: 'mockClientId',
        };
        const mockRequest = {
            userDetails: mockUserDetails,
        };

        // Mock an empty result from your formBuilderService
        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([]);

        // Call the function
        const result = await controller.getAllFormList(mockRequest);

        // Assertions
        expect(result).toEqual({
            data: null,
        });
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith(
            { clientId: mockUserDetails.client_id },
            ['id', 'docId', 'formName', 'formDescription', 'formData', 'formDataConfig']
        );
    });

    it('should handle errors', async () => {
        // Mock the userDetails in the request
        const mockUserDetails = {
            client_id: 'mockClientId',
        };
        const mockRequest = {
            userDetails: mockUserDetails,
        };

        // Mock an error from your formBuilderService
        FormBuilderService.prototype.getCustomForms = jest.fn().mockRejectedValue(new Error('Something went wrong'));

        // Call the function
        const result = await controller.getAllFormList(mockRequest);

        // Assertions
        expect(result).toEqual({
            error: {
                error_description: 'Something went wrong',
            },
        });
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith(
            { clientId: mockUserDetails.client_id },
            ['id', 'docId', 'formName', 'formDescription', 'formData', 'formDataConfig']
        );
    });

    it('should return a list of documents with form lists for OWNER RBAC', async () => {
        // Mock the userDetails in the request for OWNER RBAC
        const mockUserDetails = {
            client_id: 'mockClientId',
            id: 'mockUserId',
        };
        const mockRequest = {
            userDetails: mockUserDetails,
            query: {
                rbav: 'OWNER',
            },
            originalUrl: 'mockOriginalUrl',
        };

        // Mock the results from your documentService
        const mockResults = [
            {
                id: 'doc1',
                name: 'Document 1',
                docs: [
                    {
                        id: 'form1',
                        name: 'Form 1',
                    },
                    {
                        id: 'form2',
                        name: 'Form 2',
                    },
                ],
            },
            {
                id: 'doc2',
                name: 'Document 2',
                docs: [
                    {
                        id: 'form3',
                        name: 'Form 3',
                    },
                ],
            },
        ];

        DocumentService.prototype.getFormGroupWithRelations = jest.fn().mockResolvedValue(mockResults)

        // Call the function
        const result = await controller.getDocumentWithFormList(mockRequest);

        // Assertions
        expect(result).toEqual({
            data: [
                {
                    DOC_ID: 'doc1',
                    DOC_NAME: 'Document 1',
                    FORM_LIST: [
                        {
                            FORM_ID: 'form1',
                            NAME: 'Form 1',
                            _id: 'form1'
                        },
                        {
                            FORM_ID: 'form2',
                            NAME: 'Form 2',
                            _id: 'form2'
                        },
                    ],
                },
                {
                    DOC_ID: 'doc2',
                    DOC_NAME: 'Document 2',
                    FORM_LIST: [
                        {
                            FORM_ID: 'form3',
                            NAME: 'Form 3',
                            _id: 'form3'
                        },
                    ],
                },
            ],
        });
        expect(DocumentService.prototype.getFormGroupWithRelations).toHaveBeenCalledWith(
            {
                status: 2,
                clientId: mockUserDetails.client_id
            },
            ['id', 'name', 'mappedUser', 'docs'],
            ['docs']
        );
    });

    it('should return a list of documents with form lists for RBAC other than OWNER', async () => {
        // Mock the userDetails in the request for RBAC other than OWNER
        const mockUserDetails = {
            client_id: 'mockClientId',
            id: 'mockUserId',
        };
        const mockRequest = {
            userDetails: mockUserDetails,
            query: {
                rbav: 'OPERATOR',
            },
            originalUrl: 'mockOriginalUrl',
        };

        // Mock the results from your documentService
        const mockResults = [
            {
                id: 'doc1',
                name: 'Document 1',
                docs: [
                    {
                        id: 'form1',
                        name: 'Form 1',
                    },
                    {
                        id: 'form2',
                        name: 'Form 2',
                    },
                ],
            },
            {
                id: 'doc2',
                name: 'Document 2',
                docs: [
                    {
                        id: 'form3',
                        name: 'Form 3',
                    },
                ],
            },
        ];

        DocumentService.prototype.getFormGroupWithRelations = jest.fn().mockResolvedValue(mockResults);

        // Call the function
        const result = await controller.getDocumentWithFormList(mockRequest);

        // Assertions
        expect(result).toEqual({
            data: [
                {
                    DOC_ID: 'doc1',
                    DOC_NAME: 'Document 1',
                    FORM_LIST: [
                        {
                            FORM_ID: 'form1',
                            NAME: 'Form 1',
                            _id: 'form1'
                        },
                        {
                            FORM_ID: 'form2',
                            NAME: 'Form 2',
                            _id: 'form2'
                        },
                    ],
                },
                {
                    DOC_ID: 'doc2',
                    DOC_NAME: 'Document 2',
                    FORM_LIST: [
                        {
                            FORM_ID: 'form3',
                            NAME: 'Form 3',
                            _id: 'form3'
                        },
                    ],
                },
            ],
        });
        expect(DocumentService.prototype.getFormGroupWithRelations).toHaveBeenCalledWith(
            {
                status: 2,
                clientId: mockUserDetails.client_id,
            },
            ['id', 'name', 'mappedUser', 'docs'],
            ['docs']
        );
    });

    it('should return an empty list if no documents are found', async () => {
        // Mock the userDetails in the request for OWNER RBAC
        const mockUserDetails = {
            client_id: 'mockClientId',
            id: 'mockUserId',
        };
        const mockRequest = {
            userDetails: mockUserDetails,
            query: {
                rbav: 'OWNER',
            },
            originalUrl: 'mockOriginalUrl',
        };

        // Mock an empty result from your documentService
        DocumentService.prototype.getFormGroupWithRelations = jest.fn().mockResolvedValue([]);

        // Call the function
        const result = await controller.getDocumentWithFormList(mockRequest);

        // Assertions
        expect(result).toEqual({
            data: [],
        });
        expect(DocumentService.prototype.getFormGroupWithRelations).toHaveBeenCalledWith(
            {
                status: 2,
                clientId: mockUserDetails.client_id,
            },
            ['id', 'name', 'mappedUser', 'docs'],
            ['docs']
        );
    });

    it('should handle errors', async () => {
        // Mock the userDetails in the request for OWNER RBAC
        const mockUserDetails = {
            client_id: 'mockClientId',
            id: 'mockUserId',
        };
        const mockRequest = {
            userDetails: mockUserDetails,
            query: {
                rbav: 'OWNER',
            },
            originalUrl: 'mockOriginalUrl',
        };

        // Mock an error from your documentService
        DocumentService.prototype.getFormGroupWithRelations = jest.fn().mockRejectedValue(new Error('Something went wrong'));

        // Call the function
        const result = await controller.getDocumentWithFormList(mockRequest);

        // Assertions
        expect(result).toEqual({
            error: {
                error_description: 'Something went wrong',
            },
        });
        expect(DocumentService.prototype.getFormGroupWithRelations).toHaveBeenCalledWith(
            {
                status: 2,
                clientId: mockUserDetails.client_id,
            },
            ['id', 'name', 'mappedUser', 'docs'],
            ['docs']
        );
    });

    it('should return a successful response when data is available', async () => {
        // Mock the necessary dependencies and request object
        const request = {
            userDetails: {
                client_id: 'client-id',
            },
            params: {
                formId: 'form-id'
            }
        };

        // Mock the data you expect to be returned by the formBuilderService
        const mockCustomForms = [
            {
                id: '1',
                docId: 'doc1',
                formName: 'Form 1',
                mappedUser: 'User 1',
                createdOn: '2023-09-08T10:00:00Z',
                formDataConfig: JSON.stringify({ field1: 'config1', field2: 'config2' }),
                createdBy: 'user123',
            },
        ];

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue(mockCustomForms)

        // Mock the expected response
        const expectedApiResponse = {
            data: {
                id: '1',
                docId: 'doc1',
                formName: 'Form 1',
                mappedUser: 'User 1',
                createdOn: '2023-09-08T10:00:00Z',
                formDataConfig: { field1: 'config1', field2: 'config2' },
                createdBy: 'user123',
            },
        };

        // Call the customFormsDashboard function with mocked dependencies
        const result = await controller.customFormsDashboard(request, request.params.formId)

        // Verify the function calls and the expected result
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith(
            { clientId: 'client-id', id: 'form-id' },
            ['id', 'docId', 'formName', 'mappedUser', 'createdOn', 'formDataConfig', 'createdBy']
        );

        expect(result).toEqual(expectedApiResponse);
    });

    it('should return an error response when an error occurs', async () => {
        // Mock the necessary dependencies and request object
        const request = {
            userDetails: {
                client_id: 'client-id',
            },
            params: {
                fomrId: 'form-id'
            }
        };

        // Mock the formBuilderService to throw an error
        FormBuilderService.prototype.getCustomForms = jest.fn().mockRejectedValue(new Error('Something went wrong'))

        // Call the customFormsDashboard function with mocked dependencies
        const result = await controller.customFormsDashboard(request, request.params.fomrId)

        // Verify the function call and the expected result
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith(
            { clientId: 'client-id', id: 'form-id' },
            ['id', 'docId', 'formName', 'mappedUser', 'createdOn', 'formDataConfig', 'createdBy']
        );

        expect(result).toEqual({
            error: {
                error_description: 'Something went wrong',
            },
        });
    });

    it('should return a successful response when data is available', async () => {
        // Mock the necessary dependencies and request object
        const request = {
            userDetails: {
                client_id: 'client-id',
                is_superadmin: 1, // Assuming user is a superadmin
            },
            body: {
                id: 'doc-id',
            },
        };

        // Mock the data you expect to be returned by the formBuilderService
        const mockResults = [
            {
                id: '1',
                docId: 'doc1',
                formName: 'Form 1',
                formDescription: 'Description 1',
                formData: '{"field1":"value1"}',
                mappedUser: '[]',
                createdBy: 'user123',
                referenceId: 'ref1',
            },
        ];

        // Mock the formBuilderService
        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue(mockResults)

        // Mock the expected response
        const expectedApiResponse = {
            data: {
                recordsTotal: 1,
                recordsFiltered: 1,
                records: [
                    {
                        id: '1',
                        docId: 'doc1',
                        formName: 'Form 1',
                        formDescription: 'Description 1',
                        formData: JSON.stringify({ field1: 'value1' }),
                        mappedUser: [],
                        createdBy: 'user123',
                        referenceId: 'ref1',
                        permission: {
                            viewForm: true,
                            editForm: true,
                            manageUserForm: true,
                            deleteForm: true,
                            formShare: true,
                            formEmbed: true,
                            formsEntryCreate: true,
                            formsEntryList: true,
                        },
                    },
                ],
            },
        };

        // Call the getCustomFormList function with mocked dependencies
        const result = await controller.getCustomFormList(request);

        // Verify the function calls and the expected result
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith({
            clientId: 'client-id',
            docId: 'doc-id',
        }, ['id', 'docId', 'formName', 'formDescription', 'formData', 'mappedUser', 'createdBy', 'referenceId']);

        expect(result).toEqual(expectedApiResponse);
    });

    it('should return an error response when an error occurs', async () => {
        // Mock the necessary dependencies and request object
        const request = {
            userDetails: {
                client_id: 'client-id',
                is_superadmin: 1, // Assuming user is a superadmin
            },
            body: {
                id: 'doc-id',
            },
        };

        // Mock the formBuilderService to throw an error
        FormBuilderService.prototype.getCustomForms = jest.fn().mockRejectedValue(new Error('Something went wrong'))

        // Call the getCustomFormList function with mocked dependencies
        const result = await controller.getCustomFormList(request);

        // Verify the function call and the expected result
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith({
            clientId: 'client-id',
            docId: 'doc-id',
        }, ['id', 'docId', 'formName', 'formDescription', 'formData', 'mappedUser', 'createdBy', 'referenceId']);

        expect(result).toEqual({
            error: {
                error_description: 'Something went wrong',
            },
        });
    });

    it('should return the expected response', async () => {
        const mockRequest = {
            params: {
                form_id: 'form_id',
                client_id: 'client_id',
            },
        };

        const mockCustomForm = {
            id: 1,
            docId: 'docId_1',
            formName: 'Form Name'
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([mockCustomForm])

        const expectedResult = {
            data: {
                id: 1,
                docId: 'docId_1',
                formName: 'Form Name',
                approvalData: [],
                formData: [],
                formDataConfig: []
            },
        };

        const result = await controller.getSelfRegistrationCustomForm(mockRequest);

        expect(result).toEqual(expectedResult);
    });

    it('should return an error response when an error occurs', async () => {
        const mockRequest = {
            params: {
                form_id: 'valid_form_id',
                client_id: 'valid_client_id',
            },
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockRejectedValue(new Error('Something went wrong'));

        const result = await controller.getSelfRegistrationCustomForm(mockRequest);

        expect(result).toEqual({
            error: {
                error_description: 'Something went wrong',
            },
        });
    });    
    
    it('should return handle when error is thrown', async () => {
        const mockRequest = {
            params: {
                id: 'valid_id',
            },
            userDetails: {
                client_id: 'valid_client_id', // Assuming valid client_id
            },
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockRejectedValue(new Error('Something went wrong'))

        const result = await controller.getCustomForm(mockRequest.params.id, mockRequest);

        expect(result).toEqual({
            error: {
                error_description: 'Something went wrong'
            }
        });
    });
});