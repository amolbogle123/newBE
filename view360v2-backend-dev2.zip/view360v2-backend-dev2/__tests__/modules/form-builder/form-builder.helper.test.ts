import Container from "typedi";
import { FormBuilderHelper } from "../../../src/modules/form-builder/utils/helpers/form-builder.helper";
import { formBuilderEntity, formBuilderHistoryEntity, formBuilderPdfEntity } from "../../../src/entities/create-form-builder";
import { DataSource } from "typeorm";

describe('Form Builder Helper', () => {
    let helper: FormBuilderHelper;

    beforeAll(async () => {
        jest.clearAllMocks();
    });

    beforeEach(() => {
        helper = new FormBuilderHelper();
    });

    it('should throw an error with the provided error message', () => {
        const errorMessage = 'This is an error message';

        // Wrapping the function call in a try-catch block to capture the thrown error
        try {
            FormBuilderHelper.throwError(errorMessage);
            // If the error is not thrown, the test should fail
            expect(true).toBe(false); // This line should not be reached
        } catch (error) {
            // Asserting that the error message matches the provided message
            expect(error.message).toBe(errorMessage);
        }
    });

    it('should return the provided headerOrigin without modification', async () => {
        const headerOrigin = 'http://example.com';
        const status = true;

        // Calling the function
        const result = await FormBuilderHelper.setOrigin(headerOrigin, status);

        // Asserting that the result is equal to the provided headerOrigin
        expect(result).toEqual(headerOrigin);
    });

    it('should create form builder entities', async () => {
        // Mock the createFormBuilder, createFormBuilderHistory, createFormBuilderPdf functions
        const createFormBuilder = jest.fn();
        const createFormBuilderHistory = jest.fn();
        const createFormBuilderPdf = jest.fn();

        // Mock the DatabaseConnection class
        class MockedDatabaseConnection {
            async setDbOption(entities) {
                // Simulate setting up the database connection
            }
        }

        jest.spyOn(FormBuilderHelper, 'throwError');
        jest.spyOn(FormBuilderHelper, 'setOrigin');

        // Mock entity creation functions to return mock entities
        createFormBuilder.mockReturnValue('MockedFormBuilderEntity');
        createFormBuilderHistory.mockReturnValue('MockedFormBuilderHistoryEntity');
        createFormBuilderPdf.mockReturnValue('MockedFormBuilderPdfEntity');

        // Call the function
        const result = await FormBuilderHelper.generateFormBuilderEntity(123);

        // Expectations
        expect(FormBuilderHelper.throwError).not.toHaveBeenCalled();
        expect(FormBuilderHelper.setOrigin).not.toHaveBeenCalled();
        expect(result).toBeInstanceOf(DataSource);
    });

    it('should handle errors', async () => {
        // Mock the throwError function
        jest.spyOn(FormBuilderHelper, 'throwError').mockImplementation(() => {
            throw new Error('Mocked Error');
        });

        // const result = FormBuilderHelper.throwError('Something went wrong')
        FormBuilderHelper.generateFormBuilderEntity = jest.fn().mockRejectedValue(new Error('Mocked Error'))
        // Call the function and expect it to throw an error
        await expect(FormBuilderHelper.generateFormBuilderEntity(123)).rejects.toThrow('Mocked Error');
        // expect(result).toBe('Mocked Error')
    });
    
    // here now
    it('should return existing entity metadata if available', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(true);
        const getMetadata = jest.fn().mockReturnValue({ name: 'MockedEntity', columns: [{ name: 'id' }] });

        Container.get = jest.fn().mockReturnValue({ hasMetadata, getMetadata })

        const mockClientID = 123;
        const mockEntityName = 'MockedEntity';

        // Calling the function
        const result = await FormBuilderHelper.getEntityMetaData(mockClientID, mockEntityName);

        // Expectations
        expect(result).toEqual({ name: 'MockedEntity', columns: [{ name: 'id' }] });
        expect(hasMetadata).toHaveBeenCalledWith(mockEntityName);
        expect(getMetadata).toHaveBeenCalledWith(mockEntityName);
    });

    it('should generate entity metadata if not available', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(false);
        const generateFormBuilderEntity = jest.fn().mockResolvedValue({
            getMetadata: jest.fn().mockReturnValue({ name: 'GeneratedEntity', columns: [{ name: 'id' }] }),
        });

        Container.get = jest.fn().mockReturnValue({ hasMetadata })

        // Assigning the mock Container to the FormBuilderHelper
        FormBuilderHelper.generateFormBuilderEntity = generateFormBuilderEntity;

        const mockClientID = 123;
        const mockEntityName = 'GeneratedEntity';

        // Calling the function
        const result = await FormBuilderHelper.getEntityMetaData(mockClientID, mockEntityName);

        // Expectations
        expect(result).toEqual({ name: 'GeneratedEntity', columns: [{ name: 'id' }] });
        expect(hasMetadata).toHaveBeenCalledWith(mockEntityName);
        expect(generateFormBuilderEntity).toHaveBeenCalledWith(mockClientID, mockEntityName);
    });

    it('should return the table name of an existing entity', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(true);
        const getRepository = jest.fn().mockReturnValue({ tableName: 'MockedTable' });

        Container.get = jest.fn().mockReturnValue({ hasMetadata, getRepository })

        const mockClientID = 123;
        const mockEntityName = 'MockedEntity';

        // Calling the function
        const result = await FormBuilderHelper.getTableName(mockClientID, mockEntityName);

        // Expectations
        expect(result).toBe('MockedTable');
        expect(hasMetadata).toHaveBeenCalledWith(mockEntityName);
        expect(getRepository).toHaveBeenCalledWith(mockEntityName);
    });

    it('should generate entity metadata and return the table name if entity is not available', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(false);
        const generateFormBuilderEntity = jest.fn().mockResolvedValue({
            getMetadata: jest.fn().mockReturnValue({ tableName: 'GeneratedTable' }),
        });

        Container.get = jest.fn().mockReturnValue({ hasMetadata })

        FormBuilderHelper.generateFormBuilderEntity = generateFormBuilderEntity;

        const mockClientID = 123;
        const mockEntityName = 'GeneratedEntity';

        // Calling the function
        const result = await FormBuilderHelper.getTableName(mockClientID, mockEntityName);

        // Expectations
        expect(result).toBe('GeneratedTable');
        expect(hasMetadata).toHaveBeenCalledWith(mockEntityName);
        expect(generateFormBuilderEntity).toHaveBeenCalledWith(mockClientID, mockEntityName);
    });

    it('should return Repository when entity metadata is available', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(true);
        const getRepository = jest.fn().mockReturnValue('MockedRepository');

        Container.get = jest.fn().mockReturnValue({ hasMetadata, getRepository })

        const mockClientID = 123;
        const mockReferenceId = '123456';

        // Calling the function
        const result = await FormBuilderHelper.formBuilderRepo(mockClientID, mockReferenceId);

        // Expectations
        expect(result).toBe('MockedRepository');
        expect(hasMetadata).toHaveBeenCalledWith(formBuilderEntity);
        expect(getRepository).toHaveBeenCalledWith(formBuilderEntity);
    });

    it('should generate entity metadata and return Repository when entity metadata is not available', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(false);
        const generateFormBuilderEntity = jest.fn().mockResolvedValue({
            getRepository: jest.fn().mockReturnValue('GeneratedRepository'),
        });

        Container.get = jest.fn().mockReturnValue({ hasMetadata });

        FormBuilderHelper.generateFormBuilderEntity = generateFormBuilderEntity;

        const mockClientID = 123;
        const mockReferenceId = '123456';

        // Calling the function
        const result = await FormBuilderHelper.formBuilderRepo(mockClientID, mockReferenceId);

        // Expectations
        expect(result).toBe('GeneratedRepository');
        expect(hasMetadata).toHaveBeenCalledWith(formBuilderEntity);
        expect(generateFormBuilderEntity).toHaveBeenCalledWith(mockClientID, formBuilderEntity);
    });

    it('should return Repository when entity metadata is available', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(true);
        const getRepository = jest.fn().mockReturnValue('MockedRepository');

        Container.get = jest.fn().mockReturnValue({ hasMetadata, getRepository })

        const mockClientID = 123;
        const mockReferenceId = '123456';

        // Calling the function
        const result = await FormBuilderHelper.formBuilderHistoryRepo(mockClientID, mockReferenceId);

        // Expectations
        expect(result).toBe('MockedRepository');
        expect(hasMetadata).toHaveBeenCalledWith(formBuilderHistoryEntity);
        expect(getRepository).toHaveBeenCalledWith(formBuilderHistoryEntity);
    });

    it('should generate entity metadata and return Repository when entity metadata is not available', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(false);
        const generateFormBuilderEntity = jest.fn().mockResolvedValue({
            getRepository: jest.fn().mockReturnValue('GeneratedRepository'),
        });

        Container.get = jest.fn().mockReturnValue({ hasMetadata })

        FormBuilderHelper.generateFormBuilderEntity = generateFormBuilderEntity;

        const mockClientID = 123;
        const mockReferenceId = '123456';

        // Calling the function
        const result = await FormBuilderHelper.formBuilderHistoryRepo(mockClientID, mockReferenceId);

        // Expectations
        expect(result).toBe('GeneratedRepository');
        expect(hasMetadata).toHaveBeenCalledWith(formBuilderHistoryEntity);
        expect(generateFormBuilderEntity).toHaveBeenCalledWith(mockClientID, formBuilderHistoryEntity);
    });

    it('should return Repository when entity metadata is available', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(true);
        const getRepository = jest.fn().mockReturnValue('MockedRepository');

        Container.get = jest.fn().mockReturnValue({ hasMetadata, getRepository });

        const mockClientID = 123;

        // Calling the function
        const result = await FormBuilderHelper.formBuilderPdfRepo(mockClientID);

        // Expectations
        expect(result).toBe('MockedRepository');
        expect(hasMetadata).toHaveBeenCalledWith(formBuilderPdfEntity);
        expect(getRepository).toHaveBeenCalledWith(formBuilderPdfEntity);
    });

    it('should generate entity metadata and return Repository when entity metadata is not available', async () => {
        // Mocking dependencies
        const hasMetadata = jest.fn().mockReturnValue(false);
        const generateFormBuilderEntity = jest.fn().mockResolvedValue({
            getRepository: jest.fn().mockReturnValue('GeneratedRepository'),
        });

        Container.get = jest.fn().mockReturnValue({ hasMetadata })

        FormBuilderHelper.generateFormBuilderEntity = generateFormBuilderEntity;

        const mockClientID = 123;

        // Calling the function
        const result = await FormBuilderHelper.formBuilderPdfRepo(mockClientID);

        // Expectations
        expect(result).toBe('GeneratedRepository');
        expect(hasMetadata).toHaveBeenCalledWith(formBuilderPdfEntity);
        expect(generateFormBuilderEntity).toHaveBeenCalledWith(mockClientID, formBuilderPdfEntity);
    });
});