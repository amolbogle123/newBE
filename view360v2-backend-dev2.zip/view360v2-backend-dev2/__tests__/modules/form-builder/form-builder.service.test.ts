import { FormBuilderHelper } from "../../../src/modules/form-builder/utils/helpers/form-builder.helper";
import { BusinessProcessModelingExecute, CustomForms, CustomFormsGroup, Users } from "../../../src/entities";
import { FormBuilderService } from "../../../src/modules/form-builder/services/form-builder.service";
import Container from "typedi";
import { DataSource } from "typeorm";

describe('FormBuilderService', () => {
    let service: FormBuilderService;

    beforeAll(async () => {
        jest.clearAllMocks();
    });

    beforeEach(() => {
        service = new FormBuilderService();
    });

    it('should return true if custom form group exists', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomFormsGroup).count = jest.fn().mockResolvedValue(1);

        // Defining the condition you want to test
        const condition = {
            id: 1
        };

        // Calling the function
        const result = await service.isCustomFormGroupExist(condition);

        // Asserting the result
        expect(result).toBe(true);
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomFormsGroup);
        expect(Container.get(DataSource).getRepository(CustomFormsGroup).count).toHaveBeenCalledWith(condition);
    });

    it('should return false if custom form group does not exist', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomFormsGroup).count = jest.fn().mockResolvedValue(0);

        // Defining the condition you want to test
        const condition = {
            id: 1
        };

        // Calling the function
        const result = await service.isCustomFormGroupExist(condition);

        // Asserting the result
        expect(result).toBe(false);
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomFormsGroup);
        expect(Container.get(DataSource).getRepository(CustomFormsGroup).count).toHaveBeenCalledWith(condition);
    });

    it('should return an array of form builders', async () => {
        // Mocking the getRepository function of typeorm
        FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
            find: jest.fn().mockResolvedValue([
                { id: 1, name: 'Form A' },
                { id: 2, name: 'Form B' },
            ])
        });

        // Defining the parameters
        const client_id = 123;
        const condition = {
            id: 1
        };
        const fields = ['id', 'name'];
        const order = { name: 'ASC' };
        const referenceId = 'some_reference_id';

        // Calling the function
        const result = await service.getFormBuilderList(client_id,referenceId, condition, fields, order);

        // Asserting the result
        expect(result).toEqual([
            { id: 1, name: 'Form A' },
            { id: 2, name: 'Form B' },
        ]);
        expect(FormBuilderHelper.formBuilderRepo).toHaveBeenCalledWith(client_id, referenceId);
        expect((await FormBuilderHelper.formBuilderRepo(client_id, referenceId)).find).toHaveBeenCalledWith({ where: condition, select: fields, order });
    });

    it('should return a form builder if found', async () => {
        // Mocking the getRepository function of typeorm
        FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
            findOne: jest.fn().mockResolvedValue({ id: 1, name: 'Form A' })
        });

        // Defining the parameters
        const client_id = 123;
        const condition = {
            id: 1
        };
        const fields = ['id', 'name'];
        const referenceId = 'some_reference_id';

        // Calling the function
        const result = await service.getFormBuilder(client_id,referenceId, condition, fields );

        // Asserting the result
        expect(result).toEqual({ id: 1, name: 'Form A' });
        expect(FormBuilderHelper.formBuilderRepo).toHaveBeenCalledWith(client_id, referenceId);
        expect((await FormBuilderHelper.formBuilderRepo(client_id, referenceId)).findOne).toHaveBeenCalledWith({ where: condition, select: fields });
    });

    it('should return null if form builder not found', async () => {
        // Mocking the getRepository function of typeorm
        FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
            findOne: jest.fn().mockResolvedValue(null)
        });

        // Defining the parameters
        const client_id = 123;
        const condition = {
            id: 1
        };
        const fields = ['id', 'name'];
        const referenceId = 'some_reference_id';

        // Calling the function
        const result = await service.getFormBuilder(client_id, referenceId,condition, fields );

        // Asserting the result
        expect(result).toBeNull();
        expect(FormBuilderHelper.formBuilderRepo).toHaveBeenCalledWith(client_id, referenceId);
        expect((await FormBuilderHelper.formBuilderRepo(client_id, referenceId)).findOne).toHaveBeenCalledWith({ where: condition, select: fields });
    });

    it('should insert a form builder entry and return the inserted entity', async () => {
        // Mocking the getRepository function of typeorm
        FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
            save: jest.fn().mockResolvedValue({ id: 1, name: 'Form A' })
        });

        // Defining the parameters
        const client_id = 123;
        const payload = { name: 'Form A' };
        const referenceId = 'some_reference_id';

        // Calling the function
        const result = await service.fbInsertEntry(client_id, payload, referenceId);

        // Asserting the result
        expect(result).toEqual({ id: 1, name: 'Form A' });
        expect(FormBuilderHelper.formBuilderRepo).toHaveBeenCalledWith(client_id, referenceId);
        expect((await FormBuilderHelper.formBuilderRepo(client_id, referenceId)).save).toHaveBeenCalledWith(payload);
    });

    it('should insert a form builder history entry and return the inserted entity', async () => {
        // Mocking the getRepository function of typeorm
        FormBuilderHelper.formBuilderHistoryRepo = jest.fn().mockReturnValue({
            save: jest.fn().mockResolvedValue({ id: 1, name: 'Form A' })
        });
        // Defining the parameters
        const client_id = 123;
        const payload = { name: 'Form A' };
        const referenceId = 'some_reference_id';

        // Calling the function
        const result = await service.fbHistoryInsertEntry(client_id, payload, referenceId);

        // Asserting the result
        expect(result).toEqual({ id: 1, name: 'Form A' });
        expect(FormBuilderHelper.formBuilderHistoryRepo).toHaveBeenCalledWith(client_id, referenceId);
        expect((await FormBuilderHelper.formBuilderHistoryRepo(client_id, referenceId)).save).toHaveBeenCalledWith(payload);
    });

    it('should return an array of form builder history versions', async () => {
        // Mocking the getRepository function of typeorm
        FormBuilderHelper.formBuilderHistoryRepo = jest.fn().mockReturnValue({
            find: jest.fn().mockResolvedValue([
                { id: 1, version: 1, name: 'Form A v1' },
                { id: 2, version: 2, name: 'Form A v2' },
            ])
        });

        // Defining the parameters
        const client_id = 123;
        const condition = {
            id: 1
        };
        const order = { version: 'DESC' };
        const referenceId = 'some_reference_id';

        // Calling the function
        const result = await service.getVersionHistory(client_id, referenceId,condition, order);

        // Asserting the result
        expect(result).toEqual([
            { id: 1, version: 1, name: 'Form A v1' },
            { id: 2, version: 2, name: 'Form A v2' },
        ]);

        // Checking if formBuilderHistoryRepo was called with the correct parameters
        expect(FormBuilderHelper.formBuilderHistoryRepo).toHaveBeenCalledWith(client_id, referenceId);
        expect((await FormBuilderHelper.formBuilderHistoryRepo(client_id, referenceId)).find).toHaveBeenCalledWith({ where: condition, order });
    });

    it('should update form builders and return the update result', async () => {
        // Mocking the getRepository function of typeorm
        FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
            update: jest.fn().mockResolvedValue({ affected: 2, raw: {} })
        });

        // Defining the parameters
        const client_id = 123;
        const condition = {};
        const updateSet = {};
        const referenceId = 'some_reference_id';

        // Calling the function
        const result = await service.updateFormBuilder(client_id,referenceId, condition, updateSet);

        // Asserting the result
        expect(result).toEqual({ affected: 2, raw: {} });
        expect(FormBuilderHelper.formBuilderRepo).toHaveBeenCalledWith(client_id, referenceId);
        expect((await FormBuilderHelper.formBuilderRepo(client_id, referenceId)).update).toHaveBeenCalledWith(condition, updateSet);
    });

    it('should delete form builders and return the delete result', async () => {
        // Mocking the getRepository function of typeorm
        FormBuilderHelper.formBuilderRepo = jest.fn().mockReturnValue({
            delete: jest.fn().mockResolvedValue({ affected: 2 })
        });
        // Defining the parameters
        const client_id = 123;
        const condition = {};
        const referenceId = 'some_reference_id';

        // Calling the function
        const result = await service.deleteFormBuilder(client_id,referenceId, condition);

        // Asserting the result
        expect(result).toEqual({ affected: 2 });
        expect(FormBuilderHelper.formBuilderRepo).toHaveBeenCalledWith(client_id, referenceId);
        expect((await FormBuilderHelper.formBuilderRepo(client_id, referenceId)).delete).toHaveBeenCalledWith(condition);
    });

    it('should delete form builder history entries and return the delete result', async () => {
        // Mocking the getRepository function of typeorm
        FormBuilderHelper.formBuilderHistoryRepo = jest.fn().mockReturnValue({
            delete: jest.fn().mockResolvedValue({ affected: 2 })
        });

        // Defining the parameters
        const client_id = 123;
        const condition = {
            id: 1
        };
        const referenceId = 'some_reference_id';

        // Calling the function
        const result = await service.deleteFormBuilderHistory(client_id,referenceId, condition);

        // Asserting the result
        expect(result).toEqual({ affected: 2 });
        expect(FormBuilderHelper.formBuilderHistoryRepo).toHaveBeenCalledWith(client_id, referenceId);
        expect((await FormBuilderHelper.formBuilderHistoryRepo(client_id, referenceId)).delete).toHaveBeenCalledWith(condition);
    });

    it('should return a custom forms group if found', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomFormsGroup).findOne = jest.fn().mockResolvedValue({ id: 1, name: 'Form A' });

        // Defining the condition and fields
        const condition = {
            id: 1
        };
        const fields = ['id', 'name'];

        // Calling the function
        const result = await service.getFormGroup(condition, fields);

        // Asserting the result
        expect(result).toEqual({ id: 1, name: 'Form A' });
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomFormsGroup);
        expect(Container.get(DataSource).getRepository(CustomFormsGroup).findOne).toHaveBeenCalledWith({ where: condition, select: fields });
    });

    it('should return null if custom forms group is not found', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomFormsGroup).findOne = jest.fn().mockResolvedValue(null);

        // Defining the condition and fields
        const condition = {
            id: 1
        };
        const fields = ['id', 'name'];

        // Calling the function
        const result = await service.getFormGroup(condition, fields);

        // Asserting the result
        expect(result).toBeNull();
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomFormsGroup);
        expect(Container.get(DataSource).getRepository(CustomFormsGroup).findOne).toHaveBeenCalledWith({ where: condition, select: fields });
    });

    it('should return an array of custom forms groups', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomFormsGroup).find = jest.fn().mockResolvedValue([
            { id: 1, name: 'Group A' },
            { id: 2, name: 'Group B' },
        ]);

        // Defining the condition and fields
        const condition = {};
        const fields = ['id', 'name'];

        // Calling the function
        const result = await service.getFormGroups(condition, fields);

        // Asserting the result
        expect(result).toEqual([
            { id: 1, name: 'Group A' },
            { id: 2, name: 'Group B' },
        ]);
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomFormsGroup);
        expect(Container.get(DataSource).getRepository(CustomFormsGroup).find).toHaveBeenCalledWith({ where: condition, select: fields });
    });

    it('should save custom forms and return the saved entity', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomForms).save = jest.fn().mockResolvedValue({ id: 1, name: 'Form A' });

        // Defining the payload
        const payload = { name: 'Form A' };

        // Calling the function
        const result = await service.saveCustomForms(payload);

        // Asserting the result
        expect(result).toEqual({ id: 1, name: 'Form A' });
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomForms);
        expect(Container.get(DataSource).getRepository(CustomForms).save).toHaveBeenCalledWith(payload);
    });

    it('should update custom forms and return the update result', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomForms).update = jest.fn().mockResolvedValue({ affected: 1 });

        // Defining the condition and payload
        const condition = { id: 1 };
        const payload = { name: 'Updated Form A' };

        // Calling the function
        const result = await service.updateCustomForms(condition, payload);

        // Asserting the result
        expect(result).toEqual({ affected: 1 });
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomForms);
        expect(Container.get(DataSource).getRepository(CustomForms).update).toHaveBeenCalledWith(condition, payload);
    });

    it('should delete a custom forms group and return the delete result', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomFormsGroup).delete = jest.fn().mockResolvedValue({ affected: 1 });

        // Defining the condition
        const condition = { id: 1 };

        // Calling the function
        const result = await service.deleteFormGroup(condition);

        // Asserting the result
        expect(result).toEqual({ affected: 1 });
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomFormsGroup);
        expect(Container.get(DataSource).getRepository(CustomForms).delete).toHaveBeenCalledWith(condition);
    });

    it('should return an array of custom forms', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomForms).find = jest.fn().mockResolvedValue([
            { id: 1, name: 'Form A' },
            { id: 2, name: 'Form B' }
        ]);
        // Defining the condition and fields
        const condition = {};
        const fields = ['id', 'name'];

        // Calling the function
        const result = await service.getCustomForms(condition, fields);

        // Asserting the result
        expect(result).toEqual([
            { id: 1, name: 'Form A' },
            { id: 2, name: 'Form B' }
        ]);
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomForms);
        expect(Container.get(DataSource).getRepository(CustomForms).find).toHaveBeenCalledWith({ where: condition, select: fields });
    });

    it('should delete custom forms and return the delete result', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomForms).delete = jest.fn().mockResolvedValue({ affected: 1 });

        // Defining the condition
        const condition = {};

        // Calling the function
        const result = await service.deleteCustomForms(condition);

        // Asserting the result
        expect(result).toEqual({ affected: 1 });
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomForms);
        expect(Container.get(DataSource).getRepository(CustomForms).delete).toHaveBeenCalledWith(condition);
    });

    it('should return an array of users', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(Users).find = jest.fn().mockResolvedValue([
            { id: 1, username: 'user1' },
            { id: 2, username: 'user2' }
        ]);

        // Defining the condition and fields
        const condition = {};
        const fields = ['id', 'username'];

        // Calling the function
        const result = await service.getUsers(condition, fields);

        // Asserting the result
        expect(result).toEqual([
            { id: 1, username: 'user1' },
            { id: 2, username: 'user2' }
        ]);
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(Users);
        expect(Container.get(DataSource).getRepository(Users).find).toHaveBeenCalledWith({ where: condition, select: fields });
    });

    it('should return an array of custom forms groups with specified relations', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomFormsGroup).find = jest.fn().mockResolvedValue([
            { id: 1, name: 'Group A', users: [{ id: 1, username: 'user1' }] },
            { id: 2, name: 'Group B', users: [{ id: 2, username: 'user2' }] }
        ]);

        // Defining the condition, fields, and relations
        const condition = {};
        const fields = ['id', 'name'];
        const relations = ['users'];

        // Calling the function
        const result = await service.getFormGroupWithRelations(condition, fields, relations);

        // Asserting the result
        expect(result).toEqual([
            { id: 1, name: 'Group A', users: [{ id: 1, username: 'user1' }] },
            { id: 2, name: 'Group B', users: [{ id: 2, username: 'user2' }] }
        ]);
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomFormsGroup);
        expect(Container.get(DataSource).getRepository(CustomFormsGroup).find).toHaveBeenCalledWith({ where: condition, select: fields, relations });
    });

    it('should execute a custom query and return the result', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(CustomForms).query = jest.fn().mockResolvedValue([
            { id: 1, name: 'Form A', docId: 'doc_1' },
            { id: 2, name: 'Form B', docId: 'doc_2' },
        ]);

        // Defining the payload
        const payload = { id: 1, formId: 'doc_1' };

        // Calling the function
        const result = await service.customFormDetails(payload);

        // Asserting the result
        expect(result).toEqual([
            { id: 1, name: 'Form A', docId: 'doc_1' },
            { id: 2, name: 'Form B', docId: 'doc_2' },
        ]);
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(CustomForms);
        const expectedQuery = `SELECT * FROM custom_forms  WHERE ID = '1' AND DOC_ID = 'doc_1'`;
        expect(Container.get(DataSource).getRepository(CustomForms).query).toHaveBeenCalledWith(expectedQuery);
    });

    it('should return an array of business process modeling executions', async () => {
        // Mocking the getRepository function of typeorm
        Container.get(DataSource).getRepository(BusinessProcessModelingExecute).find = jest.fn().mockResolvedValue([
            { id: 1, processName: 'Process A', status: 'Completed' },
            { id: 2, processName: 'Process B', status: 'Pending' },
        ]);

        // Defining the condition, fields, order, and relations
        const condition = { };
        const fields = ['id', 'processName', 'status'];
        const order = { processName: 'ASC' };
        const relations = ['participants'];

        // Calling the function
        const result = await service.bpmnExecDetails(condition, fields, order, relations);

        // Asserting the result
        expect(result).toEqual([
            { id: 1, processName: 'Process A', status: 'Completed' },
            { id: 2, processName: 'Process B', status: 'Pending' },
        ]);
        expect(Container.get(DataSource).getRepository).toHaveBeenCalledWith(BusinessProcessModelingExecute);
        expect(Container.get(DataSource).getRepository(BusinessProcessModelingExecute).find).toHaveBeenCalledWith({ where: condition, select: fields, order, relations });
    });
});