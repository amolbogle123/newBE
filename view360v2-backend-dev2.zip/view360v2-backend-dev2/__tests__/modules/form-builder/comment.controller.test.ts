import dbService from "../../../src/services/db.service";
import { CommentController } from "../../../src/modules/form-builder/controllers/comment.controller";
import { CommonHelper } from "../../../src/utils/helpers/common.helper";
const DataSource = require('../../../src/core/data-source');
const UsersRepository = require('../../../src/entities/users');
const CustomFormCommunicationRepository = require('../../../src/entities/custom-form-communication');
 
describe('CommentController', () => {
    // Create mock path parameters
    const mockFormId = 'form_id';
    const mockEntryId = 'entry_id';

    // Create a mock request object
    const mockRequest = {
        userDetails: {
            client_id: 'client_id',
            id: 'user_id',
        },
    };

    // Create a mock requestBody
    const mockRequestBody = {
        formId: 'form_id',
        entryId: 'entry_id',
        comment: 'Test comment',
    };

    // Mock the CommonHelper functions
    CommonHelper.apiSwaggerSuccessResponse = jest.fn((data) => data);
    CommonHelper.apiSwaggerErrorResponse = jest.fn((error) => error);
    let controller: CommentController;

    beforeAll(async () => {
        jest.clearAllMocks();
    });

    beforeEach(() => {
        controller = new CommentController();
    });

    it('should insert a comment', async () => {
        // Mock the DataSource and repository functions
        DataSource.getRepository = jest.fn((repository) => {
            if (repository === UsersRepository) {
                return UsersRepository; // Mock UsersRepository
            } else if (repository === CustomFormCommunicationRepository) {
                return CustomFormCommunicationRepository; // Mock CustomFormCommunicationRepository
            }
        });

        // Mock the database service functions
        dbService._findQueryService = jest.fn(async () => [
            { firstName: 'Test', lastName: 'User' },
        ]);

        dbService._createQueryService = jest.fn(async (repository, data) => ({
            id: 'new_comment_id',
            ...data,
        }));

        // Mock the setStatus method
        controller.setStatus = jest.fn();

        // Call the insertComment method with mockRequest and mockRequestBody
        const result = await controller.insertComment(mockRequest, mockRequestBody);

        // Assertions
        expect(result).toEqual({
            data: {
                clientId: "client_id",
                comments: "Test comment",
                createdBy: "user_id",
                entryId: "entry_id",
                firstName: "Test",
                formId: "form_id",
                id: "new_comment_id",
                lastName: "User"
            },
        });
        expect(controller.setStatus).toHaveBeenCalledWith(201);
    });

    it('should handle error when client id is not provided', async () => {
        // Mock the setStatus method
        controller.setStatus = jest.fn();

        // Modify the mockRequest to simulate missing client_id
        const modifiedMockRequest = { userDetails: { id: 'user_id' } };

        // Call the insertComment method with modifiedMockRequest and mockRequestBody
        const result = await controller.insertComment(modifiedMockRequest, mockRequestBody);

        // Assertions
        expect(result).toEqual({
            error: {
                error_description: 'Client Id Required!',
            },
        });
        expect(controller.setStatus).not.toHaveBeenCalled();
    });

    it('should handle error when an exception is thrown', async () => {
        // Mock the setStatus method
        controller.setStatus = jest.fn();

        // Mock the _findQueryService function to throw an exception
        dbService._findQueryService = jest.fn(() => {
            throw new Error('Database error');
        });

        // Call the insertComment method
        const result = await controller.insertComment(mockRequest, mockRequestBody);

        // Assertions
        expect(result).toEqual({
            error: {
                error_description: 'Database error',
            },
        });
        expect(controller.setStatus).toHaveBeenCalledWith(500);
    });

    it('should retrieve comments list', async () => {
        // Mock the database service functions
        dbService._findQueryService = jest.fn(async () => [
            {
                id: "my_comment_id",
                formId: "form_id",
                entryId: "entry_id",
                clientId: "client_id",
                comments: "<p>My Comment</p>",
                createdBy: "created_by",
                createdOn: "created_on",
                firstName: "Test",
                lastName: "User"
            }
        ]);

        // Mock the DataSource and repository functions
        DataSource.getRepository = jest.fn((repository) => {
            if (repository === CustomFormCommunicationRepository) {
                return CustomFormCommunicationRepository; // Mock CustomFormCommunicationRepository
            }
        });

        // Call the getCommentsList method with mockRequest and mock path parameters
        const result = await controller.getCommentsList(mockRequest, mockFormId, mockEntryId);

        // Assertions
        expect(result).toEqual({
            data: [
                {
                    id: "my_comment_id",
                    formId: "form_id",
                    entryId: "entry_id",
                    clientId: "client_id",
                    comments: "<p>My Comment</p>",
                    createdBy: "created_by",
                    createdOn: "created_on",
                    firstName: "Test",
                    lastName: "User"
                }
            ],
        });
    });

    it('should handle the case when no data is found', async () => {
        // Modify the mock database service function to return an empty array
        dbService._findQueryService = jest.fn(async () => []);

        // Call the getCommentsList method with mockRequest and mock path parameters
        const result = await controller.getCommentsList(mockRequest, mockFormId, mockEntryId);

        // Assertions
        expect(result).toEqual({
            data: null,
            message: 'No Data Found!',
        });
    });

    it('should handle error when client id is not provided', async () => {
        // Modify the mockRequest to simulate missing client_id
        const modifiedMockRequest = { userDetails: {} };

        // Call the getCommentsList method with modifiedMockRequest and mock path parameters
        const result = await controller.getCommentsList(modifiedMockRequest, mockFormId, mockEntryId);

        // Assertions
        expect(result).toEqual({
            error: {
                error_description: 'Client Id Required!',
            },
        });
    });

    it('should handle error when an exception is thrown', async () => {
        // Mock the setStatus method
        controller.setStatus = jest.fn();

        // Mock the _findQueryService function to throw an exception
        dbService._findQueryService = jest.fn(() => {
            throw new Error('Database error');
        });

        // Call the getCommentsList method
        const result = await controller.getCommentsList(mockRequest, mockFormId, mockEntryId);

        // Assertions
        expect(result).toEqual({
            error: {
                error_description: 'Database error',
            },
        });
        expect(controller.setStatus).toHaveBeenCalledWith(500);
    });

    it('should throw an error with the provided message', () => {
        const errorMessage = 'Test error message';

        try {
            CommentController.throwError(errorMessage);
        } catch (error) {
            expect(error.message).toBe(errorMessage);
        }
    });
});