import { SubmitCustomFormRequest, UpdateCustomFormRequest } from "modules/form-builder/doc/formBuilderEntry-interface";
import { FormBuilderEntryController } from "../../../src/modules/form-builder/controllers/form-builder-entry.controller";
import { FormBuilderService } from "../../../src/modules/form-builder/services/form-builder.service";
import { CommonHelper } from "../../../src/utils/helpers/common.helper";
import Container from "typedi";
import { DataSource } from "typeorm";
import { FormBuilderTimeLog } from "../../../src/entities";
import { ProcessBuilderHelper } from "../../../src/modules/process-builder/utils/helpers/process-builder.helper";
import { UserService } from "../../../src/modules/user/services/user.service";

describe('FormBuilderEntryController', () => {
    let controller: FormBuilderEntryController;

    CommonHelper.apiSwaggerSuccessResponse = jest.fn((data) => data);
    CommonHelper.apiSwaggerErrorResponse = jest.fn((error) => error);

    beforeAll(async () => {
        jest.clearAllMocks();
    });

    beforeEach(() => {
        controller = new FormBuilderEntryController();
    });

    it('should throw an error with the provided message', () => {
        const errorMessage = 'Test error message';

        try {
            FormBuilderEntryController.throwError(errorMessage);
        } catch (error) {
            expect(error.message).toBe(errorMessage);
        }
    });

    it('should return API success response with valid data', async () => {
        const id = 'someId';
        const rbav = 'someRbav';
        const request = {
            userDetails: {
                client_id: 'someClientId',
                id: 'someUserId'
            }
        };

        // Mocking formBuilderService methods
        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([
            {
                formName: 'Sample Form',
                formDataConfig: '{"field1": "config1", "field2": "config2"}',
                referenceId: 'ref123'
            }
        ])

        FormBuilderService.prototype.getFormBuilderList = jest.fn().mockResolvedValue([
            {
                id: 'form1',
                submittedData: '{"field1": "value1", "field2": "value2"}',
                createdBy: 'user123',
                createdOn: '2023-09-08T12:34:56Z'
            }
        ])

        const result = await controller.entryList(id, rbav, request);

        // Add assertions to check if result matches expected API success response
        expect(result).toHaveProperty('data')
        expect(result).toEqual({
            data: {
                formData: [
                    {
                        id: 'form1',
                        createdBy: 'user123',
                        submittedData: { field1: 'value1', field2: 'value2' }
                    }
                ],
                formDataConfig: { field1: 'config1', field2: 'config2' },
                name: { formName: 'Sample Form' }
            },
            recordsFiltered: 1,
            recordsTotal: 1
        });
    });

    it('should return API error response when reqData is missing', async () => {
        const id = 'someId';
        const rbav = 'someRbav';
        const request = {}; // Missing userDetails
        const mockResponse = {
            error: {
                error_description: "Bad Request: Client Or Doc is Required!!",
            },
        }

        const result = await controller.entryList(id, rbav, request);

        expect(result).toHaveProperty('error');
        expect(result).toEqual(mockResponse);
    });

    it('should return API success response with empty data when no custom forms are found', async () => {
        const id = 'someId';
        const rbav = 'someRbav';
        const request = {
            userDetails: {
                client_id: 'someClientId',
                id: 'someUserId'
            }
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([]);

        const result = await controller.entryList(id, rbav, request);

        expect(result).toHaveProperty('data');
        expect(result).toEqual({
            data: {
                formData: [],
                formDataConfig: [],
                name: {
                    formName: ''
                }
            },
            recordsFiltered: 0,
            recordsTotal: 0
        });
    });

    it('should handle errors and return an error response', async () => {
        const id = 'someId';
        const rbav = 'someRbav';
        const request = {
            userDetails: {
                client_id: 'testClientId',
            },
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockRejectedValue(new Error('Test error'));

        const result = await controller.entryList(id, rbav, request);

        expect(result).toHaveProperty('error');
        expect((result as any).error.error_description).toBe('Test error');
    });

    it('should return API success response with valid data', async () => {
        const formId = 'someFormId';
        const id = 'someId';
        const request = {
            params: {
                formId: 'someFormId'
            },
            userDetails: {
                client_id: 'someClientId'
            }
        };

        // Mocking formBuilderService methods
        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([
            {
                formName: 'Sample Form',
                formDataConfig: '{"field1": "config1", "field2": "config2"}',
                referenceId: 'ref123'
            }
        ])

        FormBuilderService.prototype.getFormBuilder = jest.fn().mockResolvedValue([
            {
                id: 'form1',
                submittedData: '{"field1": "value1", "field2": "value2"}',
                createdBy: 'user123',
                createdOn: '2023-09-08T12:34:56Z'
            }
        ])

        const mockResponse = {
            data: {
                bpmn: [],
                submittedData: [],
            },
        }

        const result = await controller.entryDetails(formId, id, request);

        // Add assertions to check if result matches expected API success response
        expect(result).toHaveProperty('data');
        expect(result).toEqual(mockResponse)
    });

    it('should handle errors and return an error response', async () => {
        const formId = 'someFormId';
        const id = 'someId';
        const request = {
            params: {
                formId: 'someFormId'
            },
            userDetails: {
                client_id: 'someClientId'
            }
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockRejectedValue(new Error('Test error'));
        FormBuilderService.prototype.getFormBuilder = jest.fn().mockResolvedValue([
            {
                id: 'form1',
                submittedData: '{"field1": "value1", "field2": "value2"}',
                createdBy: 'user123',
                createdOn: '2023-09-08T12:34:56Z'
            }
        ])

        const result = await controller.entryDetails(formId, id, request);

        expect(result).toHaveProperty('error');
        expect((result as any).error.error_description).toBe('Test error');
    });

    it('should return API error response with missing formBuilderRes', async () => {
        const formId = 'someFormId';
        const id = 'someId';
        const request = {
            params: {
                formId: 'someFormId'
            },
            userDetails: {
                client_id: 'someClientId'
            }
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([
            {
                formName: 'Sample Form',
                formDataConfig: '{"field1": "config1", "field2": "config2"}',
                referenceId: 'ref123'
            }
        ])

        FormBuilderService.prototype.getFormBuilder = jest.fn().mockResolvedValue([])

        const mockResponse = {
            data: {
                bpmn: [],
                submittedData: [],
            },
        }

        const result = await controller.entryDetails(formId, id, request);

        // Add assertions to check if result matches expected API error response
        expect(result).toEqual(mockResponse)
    });

    it('should successfully insert entry form', async () => {
        // Set up request body with valid data
        const requestBody: SubmitCustomFormRequest = {
            formId: 'someFormId',
            data: {

            },
            isTimerBased: true,
            time: '2023-09-08T12:34:56Z',
            userid: 'userid',
            referenceId: 'refId'
        };

        const request = {
            userDetails: {
                id: 'someUserId',
                client_id: 'someClientId',
                username: 'someUsername'
            },
            body: requestBody
        };

        FormBuilderService.prototype.fbInsertEntry = jest.fn().mockResolvedValue({
            id: 'fb-insert-id'
        })

        FormBuilderService.prototype.fbHistoryInsertEntry = jest.fn().mockResolvedValue({
            id: 'fb-history-insert-id'
        })

        Container.get(DataSource).getRepository(FormBuilderTimeLog).save = jest.fn();

        ProcessBuilderHelper.prototype.execute = jest.fn();

        controller.setStatus = jest.fn();

        const result = await controller.insertEntryForm(requestBody, request);

        // Add assertions to check if result matches expected API success response
        expect(controller.setStatus).toHaveBeenCalledWith(201);
        expect(result).toEqual({
            data: {
                id: "fb-insert-id",
            },
        })
    });

    it('should return API error response if FormBuilderEntryController throws an error', async () => {
        const requestBody: SubmitCustomFormRequest = {
            formId: 'someFormId',
            data: {

            },
            isTimerBased: true,
            time: '2023-09-08T12:34:56Z',
            userid: 'user-id',
            referenceId: 'ref-id'
        };

        const request = {
            userDetails: {
                id: 'someUserId',
                client_id: 'someClientId',
                username: 'someUsername'
            },
            body: requestBody
        };

        FormBuilderService.prototype.fbInsertEntry = jest.fn().mockResolvedValue(null)

        const result = await controller.insertEntryForm(requestBody, request);

        // Add assertions to check if result matches expected API error response
        expect(result).toHaveProperty('error');
        expect(result).toEqual({
            error: {
                error_description: "Unable to save entry in form",
            }
        })
    })

    it('should return API error response if an error is thrown', async () => {
        const requestBody: SubmitCustomFormRequest = {
            formId: 'someFormId',
            data: {
                // Add your form data here
            },
            isTimerBased: true,
            time: '2023-09-08T12:34:56Z',
            userid: 'user-id',
            referenceId: 'ref-id'
        };
        const request = {
            userDetails: {
                id: 'someUserId',
                client_id: 'someClientId',
                username: 'someUsername'
            },
            body: requestBody
        };

        FormBuilderService.prototype.fbInsertEntry = jest.fn().mockRejectedValue(new Error('Something went wrong'));

        const result = await controller.insertEntryForm(requestBody, request);

        expect(result).toHaveProperty('error');
        expect(result).toEqual({
            error: {
                error_description: "Something went wrong",
            },
        })
    });

    it('should successfully update entry form', async () => {
        // Set up request body with valid data
        const requestBody: UpdateCustomFormRequest = {
            formId: 'someFormId',
            submissionId: 'someSubmissionId',
            data: {
                // Add your form data here
            },
            isTimerBased: true,
            time: '2023-09-08T12:34:56Z'
        };

        const request = {
            userDetails: {
                id: 'someUserId',
                client_id: 'someClientId',
                username: 'someUsername'
            },
            body: requestBody
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([
            {
                formName: 'Sample Form',
                formDataConfig: '{"field1": "config1", "field2": "config2"}',
                referenceId: 'ref123'
            }
        ]);

        FormBuilderService.prototype.updateFormBuilder = jest.fn().mockResolvedValue({
            affected: 1
        })

        FormBuilderService.prototype.fbHistoryInsertEntry = jest.fn().mockResolvedValue({
            id: 'fb-history-insert-id'
        })

        Container.get(DataSource).getRepository(FormBuilderTimeLog).save = jest.fn();

        const result = await controller.updateEntryForm(requestBody, request);

        // Add assertions to check if result matches expected API success response
        expect(result).toHaveProperty('message');
        expect(result).toEqual({
            message: 'Form entry updated successfully'
        })
    });

    it('should return API error response if update fails', async () => {
        const requestBody: UpdateCustomFormRequest = {
            formId: 'someFormId',
            submissionId: 'someSubmissionId',
            data: {

            },
            isTimerBased: true,
            time: '2023-09-08T12:34:56Z'
        };
        const request = {
            userDetails: {
                id: 'someUserId',
                client_id: 'someClientId',
                username: 'someUsername'
            },
            body: requestBody
        };

        FormBuilderService.prototype.updateFormBuilder = jest.fn().mockResolvedValue({
            affected: 0
        })

        const result = await controller.updateEntryForm(requestBody, request);

        // Add assertions to check if result matches expected API error response
        expect(result).toHaveProperty('error');
        expect(result).toEqual({
            error: {
                error_description: "Unable to update form entry, something went wrong!!",
            },
        })
    });

    it('should return API error response if an error is thrown', async () => {
        const requestBody: UpdateCustomFormRequest = {
            formId: 'someFormId',
            submissionId: 'someSubmissionId',
            data: {
                // Add your form data here
            },
            isTimerBased: true,
            time: '2023-09-08T12:34:56Z'
        };
        const request = {
            userDetails: {
                id: 'someUserId',
                client_id: 'someClientId',
                username: 'someUsername'
            },
            body: requestBody
        };

        FormBuilderService.prototype.updateFormBuilder = jest.fn().mockRejectedValue(new Error('Something went wrong'))

        const result = await controller.updateEntryForm(requestBody, request);

        // Add assertions to check if result matches expected API error response
        expect(result).toHaveProperty('error');
        expect(result).toEqual({
            error: {
                error_description: "Something went wrong",
            },
        })
    });

    it('should successfully delete entry form', async () => {
        // Set up request body with valid data
        const requestBody = {
            id: ['someEntryId'],
            formId: 'someFormId'
        };

        const request = {
            userDetails: {
                client_id: 'someClientId'
            },
            body: requestBody
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([
            {
                formName: 'Sample Form',
                formDataConfig: '{"field1": "config1", "field2": "config2"}',
                referenceId: 'ref123'
            }
        ]);

        FormBuilderService.prototype.deleteFormBuilder = jest.fn().mockResolvedValue({
            id: 'deleted-id'
        });

        FormBuilderService.prototype.deleteFormBuilderHistory = jest.fn();

        const result = await controller.deleteEntryForm(requestBody, request);

        // Add assertions to check if result matches expected API success response
        expect(result).toHaveProperty('message');
        expect(result).toEqual({
            message: "Form entry deleted successfully",
        })
    });

    it('should return API error response if delete fails', async () => {
        const requestBody = {
            id: ['someEntryId'],
            formId: 'someFormId'
        };

        const request = {
            userDetails: {
                client_id: 'someClientId'
            },
            body: requestBody
        };

        FormBuilderService.prototype.deleteFormBuilder = jest.fn().mockResolvedValue({
            affected: 0
        })

        const result = await controller.deleteEntryForm(requestBody, request);

        // Add assertions to check if result matches expected API error response
        expect(result).toHaveProperty('error');
        expect(result).toEqual({
            error: {
                error_description: "Unable to delete form entry, something went wrong!!",
            },
        })
    });

    it('should return API error response if an error is thrown', async () => {
        const requestBody = {
            id: ['someEntryId'],
            formId: 'someFormId'
        };
        const request = {
            userDetails: {
                client_id: 'someClientId'
            },
            body: requestBody
        };

        FormBuilderService.prototype.deleteFormBuilder = jest.fn().mockRejectedValue(new Error('Something went wrong'));

        const result = await controller.deleteEntryForm(requestBody, request);

        // Add assertions to check if result matches expected API error response
        expect(result).toHaveProperty('error');
        expect(result).toEqual({
            error: {
                error_description: "Something went wrong"
            }
        })
    });

    // it('should return API success response with valid data and date range', async () => {
    //     const req = {
    //         userDetails: {
    //             client_id: 'someClientId'
    //         },
    //         body: {
    //             formId: 'someFormId',
    //             columns: [{ data: 'field1' }, { data: 'field2' }],
    //             whereCondition: {
    //                 startDate: '2023-09-01',
    //                 endDate: '2023-09-10',
    //                 filter: []
    //             }
    //         }
    //     };

    //     Container.get(DataSource).manager.query = jest.fn().mockResolvedValue([
    //         {
    //             mockedKey: "mockedValue"
    //         }
    //     ])

    //     const result = await controller.formReportEntryDataTableList(req);

    //     // Add assertions to check if result matches expected API success response
    //     expect(result).toHaveProperty('data')
    //     expect(result.data.status).toBe(true)
    //     expect(result).toEqual({
    //         data: {
    //             data: [
    //                 {
    //                     mockedKey: "mockedValue"
    //                 }
    //             ],
    //             recordsFiltered: 1,
    //             recordsTotal: 1,
    //             status: true
    //         }
    //     });
    //     expect(Container.get(DataSource).manager.query).toHaveBeenCalledWith(
    //         `SELECT ID,FORM_ID,SUBMITTED_DATA,CREATED_ON FROM form_builder_someClientId WHERE FORM_ID = 'someFormId' "CREATEDON"::timestamp without time zone >= '09-01-2023 00:00:00'::timestamp without time zone "CREATEDON"::timestamp without time zone <= '09-10-2023 00:00:00'::timestamp without time zone`
    //     )
    // });

    // it('should return API success response with valid data and filter conditions', async () => {
    //     const req = {
    //         userDetails: {
    //             client_id: 'someClientId'
    //         },
    //         body: {
    //             formId: 'someFormId',
    //             columns: [{ data: 'field1' }, { data: 'field2' }],
    //             whereCondition: {
    //                 startDate: null,
    //                 endDate: null,
    //                 filter: [
    //                     {
    //                         field: 'field1',
    //                         type: 'text',
    //                         operator: 'like',
    //                         value: 'someValue'
    //                     }
    //                 ]
    //             }
    //         }
    //     };

    //     Container.get(DataSource).manager.query = jest.fn().mockResolvedValue([
    //         {
    //             mockedKey: "mockedValue"
    //         }
    //     ])

    //     const result = await controller.formReportEntryDataTableList(req);

    //     // Add assertions to check if result matches expected API success response
    //     expect(result).toHaveProperty('data')
    //     expect(result.data.status).toBe(true)
    //     expect(result).toEqual({
    //         data: {
    //             data: [
    //                 {
    //                     mockedKey: "mockedValue"
    //                 }
    //             ],
    //             recordsFiltered: 1,
    //             recordsTotal: 1,
    //             status: true
    //         }
    //     });
    //     expect(Container.get(DataSource).manager.query).toHaveBeenCalledWith(
    //         `SELECT ID,FORM_ID,SUBMITTED_DATA,CREATED_ON FROM form_builder_someClientId WHERE FORM_ID = 'someFormId' AND LOWER(SUBMITTED_DATA -> '$.field1') LIKE LOWER('%someValue%')`
    //     )
    // });

    // it('should return API error response if query fails', async () => {
    //     const req = {
    //         userDetails: {
    //             client_id: 'someClientId'
    //         },
    //         body: {
    //             formId: 'someFormId',
    //             columns: [{ data: 'field1' }, { data: 'field2' }],
    //             whereCondition: {
    //                 startDate: '2023-09-01',
    //                 endDate: '2023-09-10',
    //                 filter: []
    //             }
    //         }
    //     };

    //     Container.get(DataSource).manager.query = jest.fn().mockResolvedValue([])

    //     const result = await controller.formReportEntryDataTableList(req);

    //     // Add assertions to check if result matches expected API error response
    //     expect(result.data.status).toBe(false)
    //     expect(result).toHaveProperty('data');
    //     expect(result).toEqual({
    //         data: {
    //             data: [],
    //             recordsFiltered: 0,
    //             recordsTotal: 0,
    //             status: false
    //         }
    //     })
    // });

    // it('should return API error response if an error is thrown', async () => {
    //     const req = {
    //         userDetails: {
    //             client_id: 'someClientId'
    //         },
    //         body: {
    //             formId: 'someFormId',
    //             columns: [{ data: 'field1' }, { data: 'field2' }],
    //             whereCondition: {
    //                 startDate: '2023-09-01',
    //                 endDate: '2023-09-10',
    //                 filter: []
    //             }
    //         }
    //     };

    //     Container.get(DataSource).manager.query = jest.fn().mockRejectedValue(new Error('Something went wrong'))

    //     const result = await controller.formReportEntryDataTableList(req);

    //     // Add assertions to check if result matches expected API error response
    //     expect(result).toHaveProperty('error')
    //     expect(result).toEqual({
    //         error: {
    //             error_description: "Something went wrong",
    //         },
    //     })
    // });

    it('should return API success response with valid data and columns', async () => {
        const req = {
            userDetails: {
                client_id: 'someClientId'
            },
            body: {
                formId: 'someFormId',
                columns: [{ data: 'field1' }, { data: 'field2' }],
                whereCondition: []
            }
        };

        Container.get(DataSource).manager.query = jest.fn().mockResolvedValue([{
            mockedKey: "Mocked Value"
        }])

        const result = await controller.formEntries(req);

        expect(result).toEqual({
            data: [
                {
                    mockedKey: "Mocked Value",
                },
            ],
            recordsFiltered: 1,
            recordsTotal: 1,
        })
        expect(Container.get(DataSource).manager.query).toHaveBeenCalledWith(
            `SELECT ID,FORM_ID,SUBMITTED_DATA,CREATED_ON FROM form_builder_someclientid WHERE FORM_ID = 'someFormId'`
        )
    });

    it('should return API error response if query fails', async () => {
        const req = {
            userDetails: {
                client_id: 'someClientId'
            },
            body: {
                formId: 'someFormId',
                columns: [],
                whereCondition: []
            }
        };

        Container.get(DataSource).manager.query = jest.fn().mockResolvedValue([])

        const result = await controller.formEntries(req);

        expect(result).toEqual({
            data: [],
            recordsTotal: 0,
            recordsFiltered: 0
        });
    });

    it('should return API error response if an error is thrown', async () => {
        const req = {
            userDetails: {
                client_id: 'someClientId'
            },
            body: {
                formId: 'someFormId',
                columns: [],
                whereCondition: []
            }
        };

        Container.get(DataSource).manager.query = jest.fn().mockRejectedValue(new Error('Something went wrong'))

        const result = await controller.formEntries(req);

        expect(result).toEqual({
            error: {
                error_description: "Something went wrong"
            }
        });
    });

    it('should return API success response when user does not exist', async () => {
        const req = {
            body: {
                client_id: 'someClientId',
                form_Id: 'someFormId',
                formId: 'someFormId',
                role_Id: 'someRoleId',
                data: {
                    firstName: 'Test',
                    lastName: 'User',
                    email: 'test.user@example.com',
                    phoneNumber: '123456789',
                    password: 'somePassword',
                },
            },
        };

        UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(false);

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{
            referenceId: 'ref123'
        }]);

        FormBuilderService.prototype.fbInsertEntry = jest.fn().mockResolvedValue({
            id: 'fb-insert-id'
        })

        FormBuilderService.prototype.fbHistoryInsertEntry = jest.fn();

        UserService.prototype.createUser = jest.fn().mockResolvedValue({
            id: 'insert-id'
        })

        controller.setStatus = jest.fn();

        const result = await controller.insertSelfRegistrationCustomForm(req);

        expect(controller.setStatus).toHaveBeenCalledWith(201)
        expect(result).toHaveProperty('data');
        expect(result).toEqual({
            data: {
                id: 'fb-insert-id'
            }
        });
    });

    it('should return API error response when user already exists', async () => {
        const req = {
            body: {
                client_id: 'someClientId',
                form_Id: 'someFormId',
                formId: 'someFormId',
                role_Id: 'someRoleId',
                data: {
                    firstName: 'Test',
                    lastName: 'User',
                    email: 'existing.email@example.com',
                    phoneNumber: '123456789',
                    password: 'somePassword',
                },
            },
        };

        UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(true);

        const result = await controller.insertSelfRegistrationCustomForm(req);

        expect(result).toEqual({
            error: {
                error_description: "User email already exists"
            }
        });
    });

    // it('should return API error response if an error is thrown in fbInsertEntry', async () => {
    //     const req = {
    //         body: {
    //             client_id: 'someClientId',
    //             form_Id: 'someFormId',
    //             formId: 'someFormId',
    //             role_Id: 'someRoleId',
    //             data: {
    //                 firstName: 'Test',
    //                 lastName: 'User',
    //                 email: 'test.user@example.com',
    //                 phoneNumber: '123456789',
    //                 password: 'somePassword',
    //             },
    //         },
    //     };

    //     UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(false);

    //     FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{
    //         referenceId: 'ref123'
    //     }]);

    //     FormBuilderService.prototype.fbInsertEntry = jest.fn().mockResolvedValue([])

    //     const result = await controller.insertSelfRegistrationCustomForm(req);

    //     expect(result).toEqual({
    //         error: {
    //             error_description: "Unable to save entry in form"
    //         }
    //     });
    // });

    // it('should return API error response if an error is thrown in create user', async () => {
    //     const req = {
    //         body: {
    //             client_id: 'someClientId',
    //             form_Id: 'someFormId',
    //             formId: 'someFormId',
    //             role_Id: 'someRoleId',
    //             data: {
    //                 firstName: 'Test',
    //                 lastName: 'User',
    //                 email: 'test.user@example.com',
    //                 phoneNumber: '123456789',
    //                 password: 'somePassword',
    //             },
    //         },
    //     };

    //     UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(false);

    //     FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{
    //         referenceId: 'ref123'
    //     }]);

    //     FormBuilderService.prototype.fbInsertEntry = jest.fn().mockResolvedValue([{
    //         id: 'insert-id'
    //     }])

    //     UserService.prototype.createUser = jest.fn().mockResolvedValue([])

    //     const result = await controller.insertSelfRegistrationCustomForm(req);

    //     expect(result).toEqual({
    //         error: {
    //             error_description: "Unable to save user in Users"
    //         }
    //     });
    // });

    it('should create a new user and custom form entry', async () => {
        // Mock request body
        const request = {
            body: {
                client_id: 1,
                data: {
                    email: 'test@example.com',
                    password: 'password123',
                    // Other data...
                },
                form_Id: 2,
                role_Id: 3,
                // Other properties...
            },
        };

        // Mock user service behavior
        UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(false);
        UserService.prototype.createUser = jest.fn().mockResolvedValue({ /* Mocked user data */ });

        // Mock formBuilderService behavior
        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ referenceId: 'mockedReferenceId' }]);
        FormBuilderService.prototype.fbInsertEntry = jest.fn().mockResolvedValue({ id: 123 });

        // Call the function
        const result = await controller.insertSelfRegistrationCustomForm(request);

        // Expectations
        expect(UserService.prototype.checkUserExist).toHaveBeenCalledWith('test@example.com', 1);
        expect(UserService.prototype.createUser).toHaveBeenCalled();
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith(
            { clientId: 1, id: 2 },
            ['referenceId']
        );
        expect(FormBuilderService.prototype.fbInsertEntry).toHaveBeenCalledWith(
            1,
            {"beingFilledBy": "self-registration",
          "createdBy": "self-registration", formId: 2, submittedData: JSON.stringify(request.body.data) },
            'mockedReferenceId'
        );

        // Add more expectations based on your specific logic

        // Check the response
        expect(result).toEqual({ data: { id: 123 } });
    });

    it('should return error if user already exists', async () => {
        const request = {
            body: {
                client_id: 1,
                data: {
                    email: 'existing@example.com', // Assuming this email already exists
                    password: 'password123',
                },
                form_Id: 2,
                role_Id: 3,
            },
        };

        UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(true);

        const result = await controller.insertSelfRegistrationCustomForm(request);

        expect(UserService.prototype.checkUserExist).toHaveBeenCalledWith('existing@example.com', 1);
        expect(result).toEqual({
            error: {
                error_description: 'User email already exists'
            }
        });
    });

    it('should handle errors during user creation', async () => {
        const request = {
            body: {
                client_id: 1,
                data: {
                    email: 'newuser@example.com',
                    password: 'password123',
                },
                form_Id: 2,
                role_Id: 3,
            },
        };

        UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(false);
        UserService.prototype.createUser = jest.fn().mockRejectedValue(new Error('User creation failed'));

        const result = await controller.insertSelfRegistrationCustomForm(request);

        expect(UserService.prototype.checkUserExist).toHaveBeenCalledWith('newuser@example.com', 1);
        expect(UserService.prototype.createUser).toHaveBeenCalled();
        expect(result).toEqual({
            error: {
                error_description: 'User creation failed'
            }
        });
    });

    it('should handle errors during form entry creation', async () => {
        const request = {
            body: {
                client_id: 1,
                data: {
                    email: 'newuser@example.com',
                    password: 'password123',
                },
                form_Id: 2,
                role_Id: 3,
            },
        };

        UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(false);
        UserService.prototype.createUser = jest.fn().mockResolvedValue({ /* Mocked user data */ });

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ referenceId: 'mockedReferenceId' }]);
        FormBuilderService.prototype.fbInsertEntry = jest.fn().mockRejectedValue(new Error('Form entry creation failed'));

        const result = await controller.insertSelfRegistrationCustomForm(request);

        // Expectations similar to previous tests

        expect(result).toEqual({
            error: {
                error_description: "Form entry creation failed"
            }
        });
    });

    it('should handle error if no fb entry response', async () => {
        const request = {
            body: {
                client_id: 1,
                data: {
                    email: 'newuser@example.com',
                    password: 'password123',
                },
                form_Id: 2,
                role_Id: 3,
            },
        };

        UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(false);
        UserService.prototype.createUser = jest.fn().mockResolvedValue({ /* Mocked user data */ });

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ referenceId: 'mockedReferenceId' }]);
        FormBuilderService.prototype.fbInsertEntry = jest.fn().mockResolvedValue(undefined);

        const result = await controller.insertSelfRegistrationCustomForm(request);

        // Expectations similar to previous tests

        expect(result).toEqual({
            error: {
                error_description: "Unable to save entry in form"
            }
        });
    });

    it('should handle error if no fb entry response', async () => {
        const request = {
            body: {
                client_id: 1,
                data: {
                    email: 'newuser@example.com',
                    password: 'password123',
                },
                form_Id: 2,
                role_Id: 3,
            },
        };

        UserService.prototype.checkUserExist = jest.fn().mockResolvedValue(false);
        UserService.prototype.createUser = jest.fn().mockResolvedValue(undefined);

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ referenceId: 'mockedReferenceId' }]);
        FormBuilderService.prototype.fbInsertEntry = jest.fn().mockResolvedValue({});

        const result = await controller.insertSelfRegistrationCustomForm(request);

        // Expectations similar to previous tests
        expect(result).toEqual({
            error: {
                error_description: "Unable to save user in Users"
            }
        });
    });
});