import dbService from "../../../src/services/db.service";
import { FormBuilderHistoryController } from "../../../src/modules/form-builder/controllers/form-builder-history.controller"
import { CommonHelper } from "../../../src/utils/helpers/common.helper";
import { FormBuilderService } from "../../../src/modules/form-builder/services/form-builder.service";

describe('FormBuilderHistoryController', () => {
    let controller: FormBuilderHistoryController;

    CommonHelper.apiSwaggerSuccessResponse = jest.fn((data) => data);
    CommonHelper.apiSwaggerErrorResponse = jest.fn((error) => error);

    beforeAll(async () => {
        jest.clearAllMocks();
    });

    beforeEach(() => {
        controller = new FormBuilderHistoryController();
    });

    it('should return version history with valid formId and entryId', async () => {
        const request = {
            userDetails: {
                client_id: 'testClientId',
            },
        };

        const mockCustomForms = [
            {
                referenceId: 'testReferenceId',
            },
        ];

        const mockFbHistoryResponse =
            [
                {
                    submittedData: '{"key": "value"}',
                    createdBy: 'userId123',
                },
            ]
            ;

        const mockUserInfo = [
            {
                firstName: 'Test',
                lastName: 'User',
                username: 'testuser',
            }
        ]

        dbService._findQueryService = jest.fn().mockResolvedValue(mockUserInfo);
        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue(mockCustomForms);
        FormBuilderService.prototype.getVersionHistory = jest.fn().mockResolvedValue(mockFbHistoryResponse);

        const result = await controller.getVersionHistory('testFormId', 'testEntryId', request);

        expect(result).toHaveProperty('data');
        expect((result as any).data).toEqual(mockFbHistoryResponse);
    });

    it('should handle case where no version history is found', async () => {
        const request = {
            userDetails: {
                client_id: 'testClientId',
            },
        };

        const mockCustomForms = [
            {
                referenceId: 'testReferenceId',
            },
        ];

        const mockFbHistoryResponse = [];

        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue(mockCustomForms);
        FormBuilderService.prototype.getVersionHistory = jest.fn().mockResolvedValue(mockFbHistoryResponse);

        const result = await controller.getVersionHistory('testFormId', 'testEntryId', request);

        expect(result).toHaveProperty('error');
        expect((result as any).error.error_description).toBe('Unable to save entry in form');
    });

    it('should handle errors and return an error response', async () => {
        const request = {
            userDetails: {
                client_id: 'testClientId',
            },
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockRejectedValue(new Error('Test error'));

        const result = await controller.getVersionHistory('testFormId', 'testEntryId', request);

        expect(result).toHaveProperty('error');
        expect((result as any).error.error_description).toBe('Test error');
    });

    it('should return user info with valid userId', async () => {
        const mockUserResult = [
            {
                firstName: 'Test',
                lastName: 'User',
                username: 'testuser',
            },
        ];

        dbService._findQueryService = jest.fn().mockResolvedValue(mockUserResult);

        const result = await controller.resolveUserId('userId123');

        expect(result).toEqual({
            firstName: 'Test',
            lastName: 'User',
            username: 'testuser',
        });
    });

    it('should handle case where no user is found', async () => {
        const mockUserResult = [];

        dbService._findQueryService = jest.fn().mockResolvedValue(mockUserResult);

        const result = await controller.resolveUserId('userId123');

        expect(result).toEqual({
            firstName: '',
            lastName: '',
            username: '',
        });
    });
});