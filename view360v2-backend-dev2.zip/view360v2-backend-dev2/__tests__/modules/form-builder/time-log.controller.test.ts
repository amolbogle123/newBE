import { FormBuilderService } from "../../../src/modules/form-builder/services/form-builder.service";
import { FormBuilderTimeLog } from "../../../src/entities";
import { TimeLogController } from "../../../src/modules/form-builder/controllers/time-log.controller";
import { CommonHelper } from "../../../src/utils/helpers/common.helper";
import Container from "typedi";
import { DataSource } from "typeorm";

describe('TimeLogController', () => {
    let controller: TimeLogController;

    CommonHelper.apiSwaggerSuccessResponse = jest.fn((data) => data);
    CommonHelper.apiSwaggerErrorResponse = jest.fn((error) => error);

    beforeAll(async () => {
        jest.clearAllMocks();
    });

    beforeEach(() => {
        controller = new TimeLogController();
    });

    it('should throw an error with the provided message', () => {
        const errorMessage = 'Test error message';

        try {
            TimeLogController.throwError(errorMessage);
        } catch (error) {
            expect(error.message).toBe(errorMessage);
        }
    });

    it('should return time logs when formId and entryId are provided', async () => {
        // Mock the database query result
        const mockTimeLogs = [
            {
                FORM_ID: 1,
                ENTRY_ID: 123,
                CREATEDON: new Date(),
                CREATED_BY: 1,
                DESSC: 'Some description',
            },
        ];

        Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder = jest.fn().mockReturnValue({
            leftJoinAndSelect: jest.fn().mockReturnThis(),
            select: jest.fn().mockReturnThis(),
            where: jest.fn().mockReturnThis(),
            andWhere: jest.fn().mockReturnThis(),
            orderBy: jest.fn().mockReturnThis(),
            execute: jest.fn().mockResolvedValue(mockTimeLogs)
        });

        // Call your function
        const result = await controller.getTimeLogs('1', '123');

        // Assertions
        expect(result).toEqual({
            data: mockTimeLogs,
            message: 'TimeLog Fetched Successfully!!!',
        });

        // Verify that the expected database query was called
        expect(Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder().select).toHaveBeenCalledWith(
            'FORM_ID,ENTRY_ID,FBT.CREATEDON,CREATED_BY,DESSC'
        );
        expect(Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder().where).toHaveBeenCalledWith("ENTRY_ID=:entryId", { "entryId": 123 });
        expect(Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder().orderBy).toHaveBeenCalledWith(
            'FBT.CREATEDON',
            'DESC'
        );

        // Verify that CommonHelper functions were called
        expect(CommonHelper.apiSwaggerSuccessResponse).toHaveBeenCalledWith({
            data: mockTimeLogs,
            message: 'TimeLog Fetched Successfully!!!',
        });

        // Ensure that CommonHelper.apiSwaggerErrorResponse was not called
        expect(CommonHelper.apiSwaggerErrorResponse).not.toHaveBeenCalled();
    });

    it('should handle API response if user not exists', async () => {
        Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder = jest.fn().mockReturnValue({
            leftJoinAndSelect: jest.fn().mockReturnThis(),
            select: jest.fn().mockReturnThis(),
            where: jest.fn().mockReturnThis(),
            andWhere: jest.fn().mockReturnThis(),
            orderBy: jest.fn().mockReturnThis(),
            execute: jest.fn().mockResolvedValue([])
        });

        // Call your function
        const result = await controller.getTimeLogs('1', '123');

        // Assertions
        expect(result).toEqual({
            error: {
                error_description: "User Doesn't Exist!!!",
            }
        })
    });

    it('should return an error response when formId or entryId is not provided', async () => {
        // Call your function without providing formId and entryId
        const result = await controller.getTimeLogs('', '');

        // Assertions
        expect(result).toEqual({
            error: {
                error_description: "Entry and Form ID is Required!",
            },
        });

        // Ensure that CommonHelper.apiSwaggerErrorResponse was called
        expect(CommonHelper.apiSwaggerErrorResponse).toHaveBeenCalledWith({
            error: {
                error_description: "Entry and Form ID is Required!",
            },
        });
    });

    it('should handle API response it thrown an error', async () => {
        Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder = jest.fn().mockReturnValue({
            leftJoinAndSelect: jest.fn().mockReturnThis(),
            select: jest.fn().mockReturnThis(),
            where: jest.fn().mockReturnThis(),
            andWhere: jest.fn().mockReturnThis(),
            orderBy: jest.fn().mockReturnThis(),
            execute: jest.fn().mockRejectedValue(new Error('Something went wrong'))
        });

        // Call your function
        const result = await controller.getTimeLogs('1', '123');

        // Assertions
        expect(result).toEqual({
            error: {
                error_description: "Something went wrong",
            }
        })
    });

    it('should update filling availability', async () => {
        const request = {
            userDetails: {
                client_id: 'client123',
                id: 'user789'
            },
            body: {
                type: 'set',
                formId: 'form123',
                entryId: 'entry456'
            }
        };

        // Mocking the formBuilderService
        FormBuilderService.prototype.getCustomForms = jest.fn().mockResolvedValue([{ referenceId: 'refId' }]);
        FormBuilderService.prototype.updateFormBuilder = jest.fn().mockResolvedValue({ affected: 1 });

        const result = await controller.updateFillingAvailability(request.body, request)

        expect(FormBuilderService.prototype.updateFormBuilder).toHaveBeenCalledWith('client123', 'refId', { formId: 'form123', id: 'entry456' }, { beingFilledBy: 'user789' });
        expect(result).toEqual({
            data: { affected: 1 },
            message: 'Successfully Updated !!!'
        });
    });

    it('should handle client not existing', async () => {
        const request = {
            userDetails: {
                client_id: ''
            },
            body: {
                type: 'set',
                formId: 'form123',
                entryId: 'entry456'
            }
        };

        const result = await controller.updateFillingAvailability(request.body, request);

        expect(result).toEqual({
            error: { error_description: "Client Doesn\'t Exist !!!" }
        });
    });

    it('should handle API response if error is thrown', async () => {
        const request = {
            userDetails: {
                client_id: 'client-id'
            },
            body: {
                type: 'set',
                formId: 'form123',
                entryId: 'entry456'
            }
        };

        FormBuilderService.prototype.getCustomForms = jest.fn().mockRejectedValue(new Error('Something went wrong'));

        const result = await controller.updateFillingAvailability(request.body, request);

        expect(result).toEqual({
            error: { error_description: "Something went wrong" }
        });
    });

    it('should return data if formId and entryId are provided', async () => {
        // Mocking the request object
        const req = {
            userDetails: {
                clientId: 'yourClientId'
            }
        };
        const formId = 'yourFormId';
        const entryId = 'yourEntryId';

        Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder = jest.fn().mockReturnValue({
            leftJoinAndSelect: jest.fn().mockReturnThis(),
            select: jest.fn().mockReturnThis(),
            where: jest.fn().mockReturnThis(),
            andWhere: jest.fn().mockReturnThis(),
            execute: jest.fn().mockResolvedValue([{ ID: 'userId123', USERNAME: 'testuser' }]),
            Not: jest.fn().mockReturnValue({ type: 'not' })
        });

        const result = await controller.checkFillingAvailability(req, formId, entryId);

        expect(result).toEqual({
            data: [{ ID: 'userId123', USERNAME: 'testuser' }],
            message: 'Data Fetched Successfully !!!'
        });
    });

    it('should return error response if formId or entryId is not provided', async () => {
        // Mocking the request object
        const req = {
            userDetails: {
                clientId: 'yourClientId'
            }
        };
        const formId = '';
        const entryId = '';

        const result = await controller.checkFillingAvailability(req, formId, entryId);

        expect(result).toEqual({
            error: { error_description: 'Form And Entry Id Required!' }
        });
    });

    it('should return error response if no results are found', async () => {
        // Mocking the request object
        const req = {
            userDetails: {
                clientId: 'yourClientId'
            }
        };
        const formId = 'yourFormId';
        const entryId = 'yourEntryId';

        Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder = jest.fn().mockReturnValue({
            leftJoinAndSelect: jest.fn().mockReturnThis(),
            select: jest.fn().mockReturnThis(),
            where: jest.fn().mockReturnThis(),
            andWhere: jest.fn().mockReturnThis(),
            execute: jest.fn().mockResolvedValue([]),
            Not: jest.fn().mockReturnValue({ type: 'not' })
        });

        const result = await controller.checkFillingAvailability(req, formId, entryId);

        expect(result).toEqual({
            error: { error_description: 'Form Doesn\'t Exist !!!' }
        });
    });

    it('should handle if error is thrown', async () => {
        // Mocking the request object
        const req = {
            userDetails: {
                clientId: 'yourClientId'
            }
        };
        const formId = 'yourFormId';
        const entryId = 'yourEntryId';

        Container.get(DataSource).getRepository(FormBuilderTimeLog).createQueryBuilder = jest.fn().mockReturnValue({
            leftJoinAndSelect: jest.fn().mockReturnThis(),
            select: jest.fn().mockReturnThis(),
            where: jest.fn().mockReturnThis(),
            andWhere: jest.fn().mockReturnThis(),
            execute: jest.fn().mockRejectedValue(new Error('Something went wrong')),
            Not: jest.fn().mockRejectedValue(new Error('Something went wrong'))
        });

        const result = await controller.checkFillingAvailability(req, formId, entryId);

        expect(result).toEqual({
            error: { error_description: 'Something went wrong' }
        });
    });
})