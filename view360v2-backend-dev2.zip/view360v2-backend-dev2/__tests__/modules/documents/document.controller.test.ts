import {DocumentController} from "../../../src/modules/documents/controllers/document.controller";
import {
    DeleteDocument,
    UpdateDocumentRequest
} from "../../../src/modules/documents/doc/document-interface";
import {DocumentService} from "../../../src/modules/documents/services/document.service";
import { FormBuilderService } from "../../../src/modules/form-builder/services/form-builder.service";
describe('DocumentController', () => {
    let controller: DocumentController;
    
    beforeAll(async ()=>{
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new DocumentController();
    });

    it('should insert a document', async () => {
        // Mock request and response objects
        const request = {
          userDetails: {
            client_id: 'client_id',
            id: 'user_id',
            username: 'user_username',
            is_superadmin: 0,
          },
        };
  
        const requestBody = {
          projectName: 'Test Project',
          projectshortName: 'TestShort',
          projectDiscription: 'TestDiscription',
          // Provide other necessary request body data
        };
  
       
        DocumentService.prototype.getFormGroups=jest.fn().mockResolvedValue(Promise.resolve([]));
        DocumentService.prototype.saveFormGroup=jest.fn().mockResolvedValue({
          id: 'new_document_id',
          name: requestBody.projectName,
          shortName: requestBody.projectshortName,
        });
  
        const response = await controller.insertDocument(requestBody, request);
  
        expect(response).toEqual({
          data: {
            id: 'new_document_id',
            name: requestBody.projectName,
            shortName: requestBody.projectshortName,
          },
          message: 'Document has been saved successfully',
          status:true
        });
      });
  
      it('should handle duplicate project names', async () => {
        const request = {
          userDetails: {
            client_id: 'client_id',
            id: 'user_id',
            username: 'user_username',
            is_superadmin: 0,
          },
        };
  
        const requestBody = {
          projectName: 'Existing Project', // Assume this name already exists
          projectshortName: 'TestShort',
          projectDiscription: 'TestDiscription',
        };
  
        DocumentService.prototype.getFormGroups=jest.fn().mockResolvedValue([
          {
            id: 'existing_document_id',
            name: 'Existing Project',
            shortName: 'ExistingShort',
          },
        ]);
  
        const response = await controller.insertDocument(requestBody, request);
  
        expect(response).toEqual({
          error: {
            projectName:"Folder name already exists",
          },
          message:"Folder name already exists",
          status:false,
        });
      });
  
      it('should handle errors during document insertion', async () => {
        const request = {
          userDetails: {
            client_id: 'client_id',
            id: 'user_id',
            username: 'user_username',
            is_superadmin: 0,
          },
        };
  
        const requestBody = {
          projectName: 'Test Project',
          projectshortName: 'TestShort',
          projectDiscription: 'TestDiscription',
        };
  
        DocumentService.prototype.getFormGroups=jest.fn().mockRejectedValue(new Error('Internal server error'));
        const response = await controller.insertDocument(requestBody, request);
        expect(response).toEqual({
          error: {
            error_description: 'Internal server error',
          },
          message:"Something went wrong !",
          status:false
        });
      });
    it('should update a Document', async () => {
        const requestBody: UpdateDocumentRequest = {
            projectName: 'testProjectName',
            projectDiscription: 'testProjectDiscription',
            projectManager: 'testProjectManager',
            projectshortName: 'testProjectshortName',
            mapped_user: [],
            status: 1
        };
        const request = {userDetails: {client_id: '1', id: '1', username: 'testUsername'}};
        const result = await controller.updateDocument('1',requestBody,request);
        expect(result).toBeTruthy();
    });

    it('should delete documents and associated forms', async () => {
        const request = {
          userDetails: {
            client_id: 'client_id',
          },
        };
    
        const requestBody = {
          id: ['document_id_1', 'document_id_2'],
        };
    
        FormBuilderService.prototype.getCustomForms=jest.fn().mockResolvedValue([
            {
              id: 'form_id_1',
              referenceId: 'reference_id_1',
              // Provide other data for the form
            },
            {
              id: 'form_id_2',
              referenceId: 'reference_id_2',
              // Provide other data for the form
            },
          ]);
    
          DocumentService.prototype.deleteFormGroup=jest.fn().mockResolvedValue({ affected: 2 });
          DocumentService.prototype.deleteCustomForms=jest.fn().mockResolvedValue(undefined);
        // Call the deleteDocument method
        await controller.deleteDocument(requestBody, request);
    
        // Write assertions to check if the response is as expected
        expect(await controller.deleteDocument(requestBody, request)).toEqual({ 
            message:"Successfully executed.",
            status:true }); // Assuming this is the success response
    
        // Verify that the necessary methods were called with the correct parameters
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith(
          {
            clientId: 'client_id',
            docId: undefined,
          },
          ['id', 'referenceId']
        );
    
        expect(DocumentService.prototype.deleteFormGroup).toHaveBeenCalledWith({ id: undefined });
        expect(DocumentService.prototype.deleteCustomForms).toHaveBeenCalledWith({
          docId: undefined,
          clientId: 'client_id',
        });
      });
    
      it('should handle errors during document deletion', async () => {
        // Mock request and response objects
        const request = {
          userDetails: {
            client_id: 'client_id',
          },
        };
    
        const requestBody = {
          id: ['document_id_1', 'document_id_2'],
          // Provide other necessary request body data
        };
    
        FormBuilderService.prototype.getCustomForms=jest.fn().mockRejectedValue(new Error('Form error'));
    
        DocumentService.prototype.deleteFormGroup= jest.fn().mockRejectedValue(new Error('Delete error'));
    
        // Call the deleteDocument method
        await controller.deleteDocument(requestBody, request);
    
        // Write assertions to check if the response is as expected
        expect(await controller.deleteDocument(requestBody, request)).toEqual({
          error: {
            error_description: 'Form error', // Assuming this is the error message
          },
          message:"Something went wrong !",
          status:false
        });
    
        // Verify that the necessary methods were called with the correct parameters
        expect(FormBuilderService.prototype.getCustomForms).toHaveBeenCalledWith(
          {
            clientId: 'client_id',
            docId: undefined,
          },
          ['id', 'referenceId']
        );
    
        expect(DocumentService.prototype.deleteCustomForms).toHaveBeenCalledWith({
          docId: undefined,
          clientId: 'client_id',
        });
      });

    it('should List a Document', async () => {
        const requestBody: DeleteDocument = {
            id: []
        };
        const request = {userDetails: {client_id: '1', id: '1', username: 'testUsername'}};
        const status = 1;
        const rbav = 'all';
        const searchKey = 'test';
        const result = await controller.documentList(request,status,rbav,searchKey);
        expect(result).toBeTruthy();
    });

    it('should show  Document details', async () => {
        const request = {userDetails: {client_id: '1', id: '1', username: 'testUsername'}};
        const result = await controller.documentDetails('1',request);
        expect(result).toBeTruthy();
    });

});
