import { CustomFooterController } from "../../../src/modules/custom-footer/controllers/custom-footer.controller";
import { AddUpdateCustomFooterRequestBody,DeleteCustomFooterRequestBody } from "../../../src/modules/custom-footer/doc/custom-footer.interface";
describe('CustomFooterController', () => {
    let controller: CustomFooterController;
    beforeAll(async ()=>{
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new CustomFooterController();
    });

    it('should add a custom footer', async () => {
        
        const requestBody: AddUpdateCustomFooterRequestBody = {
            clientId:  1,
            createdBy:'3989373b-e435-4a27-b4e3-9b70b60c9f9b',
            data:'<p>Hello Asd Asdaksdjkas alkdmaksdm</p>\n',
            active:1,
            stickyFooter: 0,
            themeSetting: '{\"backgroundColor\":\"#ffffff\",\"textColor\":\"#ff0505\"}'
        };
        const request = { userDetails: { client_id: '1' } };
        const result = await controller.add(request,requestBody);
        expect(result).toBeDefined();
        expect(result.status).toEqual(true);
        //expect(controller.getStatus()).toBe(201);
    });

    it('should update a custom footer', async () => {
        const requestBody: AddUpdateCustomFooterRequestBody = {
            clientId:  1,
            createdBy:'test',
            data:'test',
            active:1,
            stickyFooter: 0,
            themeSetting: 'test'
        };
        const result = await controller.update(requestBody);
        expect(result).toBeDefined();
        //expect(result.message).toEqual("Custom Footer updated successfully");
    });

    it('should get a custom footer', async () => {
        const request = { userDetails: { client_id: '1' } };
        const result = await controller.get(request);
        expect(result).toBeTruthy();
        expect(result.status).toEqual(true);
    });

    it('should delete a custom footer', async () => {
        const requestBody: DeleteCustomFooterRequestBody = {
            id: "1"
        };
        const request = { userDetails: { client_id: '1' } };
        const result = await controller.delete(request,requestBody);
        expect(result).toBeDefined();
        //expect(result.message).toEqual("Record deleted successfully");
    });
});