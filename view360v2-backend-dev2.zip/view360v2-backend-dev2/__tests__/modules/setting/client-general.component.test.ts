import { UpdateClientGeneral } from "modules/settings/doc/clientGeneral-interface";
import {ClientGeneralController} from "../../../src/modules/settings/controllers/client-general.controller";

describe('Client General', () => {
  let clientGeneralController = new ClientGeneralController();
  beforeAll(async ()=>{
      jest.clearAllMocks();
  });
  beforeEach(() => {
    clientGeneralController = new ClientGeneralController();
  });
  it('Should update client general ', async () => {
    const req:UpdateClientGeneral = {
        company_name:"Test"
    };

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }
    const res = await clientGeneralController.updateClientGeneral(req, request);
    expect(res.status).toBe(false);
  });

  it('should get all client general information', async () => {
    // Mock the necessary dependencies and user details
    const userDetails = { client_id: 'mockClientId' };
    const mockClientGenerals = [{}];

    const request = {
        userDetails: {
          client_id: 'mockClientId'
        }
      }
    const response = await clientGeneralController.getAllClientGenerals(request);

    // Make a request to the endpoint
    

    // Assertions
    expect(response.status).toBe(true);
   
    expect(response.body).toEqual(undefined);
  });
});
