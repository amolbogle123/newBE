import { UpdateClientGeneral } from "modules/settings/doc/clientGeneral-interface";
import {ClientSystemController} from "../../../src/modules/settings/controllers/client-system.controller";

describe('Client Navigation', () => {
  let clientSystemController = new ClientSystemController();
  beforeAll(async ()=>{
      jest.clearAllMocks();
  });
  beforeEach(() => {
    clientSystemController = new ClientSystemController();
  });


  it('Fetch Client Systems ', async () => {
  
    const res = await clientSystemController.getAllClientSystems();
    expect(res.status).toBe(false);
  });


  it('update  Client Systems ', async () => {

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }  
    const res = await clientSystemController.updateClientSystem(request,'test');
    expect(res.status).toBe(false);
  });


});
