import {ModuleController} from "../../../src/modules/settings/controllers/module.controller";

describe('Module', () => {
  let controller = new ModuleController();
  beforeAll(async ()=>{
      jest.clearAllMocks();
  });
  beforeEach(() => {
    controller = new ModuleController();
  });


  it('add module', async () => {
    const request = {
        userDetails: {
          client_id: 'mockClientId'
        }
      }  
      const body = {
        isActive:1,
        clientId:"mockClientId"
      }
    const res = await controller.addModule(body,request);
    expect(res.status).toBe(true);
  });


  it('update  Module ', async () => {

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }  
    const res = await controller.updateModule('test',request,'test');
    expect(res.status).toBe(true);
  });


  it('Delete Multiple  Module ', async () => {

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }  

    const deleteIds = {
        id:["Test","TestOne"]
    }
    const res = await controller.deleteMultipleModules(deleteIds);
    expect(res.status).toBe(true);
  });


  it('get   Module By Id ', async () => {

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }  

    const getIds = "test"
    const res = await controller.getModuleById(getIds);
    expect(res.status).toBe(true);
  });


  it('get Module By name ', async () => {

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }  

    const getIds = "test"
    const res = await controller.getModuleByName(getIds);
    // expect(res.status).toBe(true);
  });


  it('get  All Module ', async () => {

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }  

    const getIds = "test"
    const res = await controller.getAllModules(getIds);
    expect(res.status).toBe(true);
  });

});



