import { UpdateClientGeneral } from "modules/settings/doc/clientGeneral-interface";
import { SettingConfigController } from "../../../src/modules/settings/controllers/setting-config.controller";
import { AddUpdateSettingConfigRequest } from "modules/settings/settings.interface";

describe('Setting Config Controller', () => {
    let controller = new SettingConfigController();
    beforeAll(async () => {
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new SettingConfigController();
    });


    it('Test Setting config', async () => {
        const request = {
            userDetails: {
                client_id: 'mockClientId'
            }
        }
        const res = await controller.testSettingConfig(request);
        expect(res.status).toBe(false);
    });


    it('add setting config', async () => {

        const request = {
            userDetails: {
                client_id: 'mockClientId'
            }
        }

        const reqbody: AddUpdateSettingConfigRequest = {
            type: "test",
            config: {

            }
        }
        const res = await controller.addSettingConfig(reqbody, request);
        // expect(res.status).toBe(false);
    });


    it('update setting config', async () => {

        const request = {
            userDetails: {
                client_id: 'mockClientId'
            }
        }

        const reqbody: AddUpdateSettingConfigRequest = {
            type: "test",
            config: {

            }
        }
        const res = await controller.updateSettingConfig(reqbody, "test");
        // expect(res.status).toBe(false);
    });

});
