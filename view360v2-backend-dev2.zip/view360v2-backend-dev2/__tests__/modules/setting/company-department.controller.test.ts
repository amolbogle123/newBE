import { CompanyDepartmentController } from "../../../src/modules/settings/controllers/company-department.controller";

describe('Company Department ', () => {
    let companyDepartmentController = new CompanyDepartmentController();
    beforeAll(async () => {
        jest.clearAllMocks();
    });
    beforeEach(() => {
        companyDepartmentController = new CompanyDepartmentController();
    });


    it('Add Company Department ', async () => {
        const request = {
            userDetails: {
                client_id: 'mockClientId'
            }
        }

        const reqBody = {
            name: "company",
            child_companies: ["Test"]
        }

        const res = await companyDepartmentController.addCompanyDepartment(reqBody, request);
        // expect(res.status).toBe(false);
    });


    it('deleteMultipleCompanyDepartments', async () => {


        const deleteId = {
            id: ["Test", "Test2"]
        };
        const res = await companyDepartmentController.deleteMultipleCompanyDepartments(deleteId);
        // expect(res.status).toBe(false);
    });


});
