import { UpdateClientGeneral } from "modules/settings/doc/clientGeneral-interface";
import {TimezoneController} from "../../../src/modules/settings/controllers/timezone.controller";
import { Request, Response, NextFunction } from "express";
import momentTz from "moment-timezone";

// Import the TimezoneController class and any necessary dependencies


// Create a mock request and response objects
const mockRequest = {} as Request;
const mockResponse = {
  status: jest.fn(() => mockResponse),
  json: jest.fn(),
} as unknown as Response;

describe('TimezoneController', () => {
  it('should return a list of timezones and the server timezone', async () => {
    // Create an instance of the TimezoneController
    const controller = new TimezoneController();

    // Mock the moment-timezone methods
    const mockTimezones = ['Timezone1', 'Timezone2'];
    const mockServerTimezone = 'ServerTimezone';
    jest.spyOn(momentTz.tz, 'names').mockReturnValue(mockTimezones);
    jest.spyOn(momentTz.tz, 'guess').mockReturnValue(mockServerTimezone);

    // Call the list method with the mock request and response
    await controller.list(mockRequest, mockResponse, jest.fn());

    // Verify that the response status and json methods were called with the expected values
    expect(mockResponse.status).toHaveBeenCalledWith(200);
    expect(mockResponse.json).toHaveBeenCalledWith({
      status: 'success',
      data: {
        timezones: mockTimezones,
        serverTimezone: mockServerTimezone,
      },
    });
  });

  it('should handle errors and return them in the response', async () => {
    // Create an instance of the TimezoneController
    const controller = new TimezoneController();

    // Mock an error
    const mockError = new Error('Test error');
    jest.spyOn(momentTz.tz, 'names').mockImplementation(() => {
      throw mockError;
    });

    // Call the list method with the mock request and response
    await controller.list(mockRequest, mockResponse, jest.fn());

    // Verify that the response status and json methods were called with the error
    expect(mockResponse.status).toHaveBeenCalledWith(200);
    expect(mockResponse.json).toHaveBeenCalledWith(mockError);
  });
});

