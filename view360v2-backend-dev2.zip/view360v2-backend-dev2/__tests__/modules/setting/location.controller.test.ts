import { AddLocationResponse } from "modules/settings/settings.interface";
import { LocationController } from "../../../src/modules/settings/controllers/location.controller";

describe('Location ', () => {
    let controller = new LocationController();
    beforeAll(async () => {
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new LocationController();
    });


    it('add Location ', async () => {
        const reqBody = { name: "Test", clientid: 1 }
        const request = {
            userDetails: {
                client_id: 'mockClientId'
            }
        }



        let res = await controller.addLocation(reqBody, request);
        // expect(res.status).toBe(false);
    });


    it('Delete Multiple Locations', async () => {

        const request = {
            userDetails: {
                client_id: 'mockClientId'
            }
        }
        const deleteIds = { id: [1, 2] };
        const res = await controller.deleteMultipleLocations(deleteIds);
        // expect(res.status).toBe(true);
    });

    it('get all Locations', async () => {

        const request = {
            userDetails: {
                client_id: 'mockClientId'
            }
        }
        const res = await controller.getAllLocations(request);
        // expect(res.status).toBe(true);
    });


});
