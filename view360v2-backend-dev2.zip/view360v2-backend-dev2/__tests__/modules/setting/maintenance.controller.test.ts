import { UpdateClientGeneral } from "modules/settings/doc/clientGeneral-interface";
import {MaintenanceController} from "../../../src/modules/settings/controllers/maintenance.controller";

describe('Maintenance', () => {
  let controller = new MaintenanceController();
  beforeAll(async ()=>{
      jest.clearAllMocks();
  });
  beforeEach(() => {
    controller = new MaintenanceController();
  });


  it('Get Data ', async () => {
    const request = {
        userDetails: {
          client_id: 'mockClientId'
        }
      }  
    const res = await controller.getData(request);
    expect(res.status).toBe(false);
  });


  // it('Details  ', async () => {

  //   const request = {
  //     userDetails: {
  //       client_id: 'mockClientId'
  //     }
  //   }  
  //   const id = "Test"
  //   const res = await controller.details(id , request);
  //   expect(res.status).toBe(true);
  // });


});
