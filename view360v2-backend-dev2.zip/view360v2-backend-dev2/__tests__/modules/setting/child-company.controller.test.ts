import { ChildCompanyController } from "../../../src/modules/settings/controllers/child-company.controller";

describe('childCompanyController', () => {
  let childCompanyController = new ChildCompanyController();
  beforeAll(async () => {
    jest.clearAllMocks();
  });
  beforeEach(() => {
    childCompanyController = new ChildCompanyController();
  });
  it('Should add child company ', async () => {
    const req = {
      locations: [],
      name: "TEst"
    };

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }
    const res = await childCompanyController.addChildCompany(req, request);
    expect(res.status).toBe(true);
  });

  it('Delete Multiple Child Company', async () => {
    const req = {
      locations: [],
      name: "TEst"
    };

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }

    const deleteIds = {
      id: ["Test"]
    }
    const res = await childCompanyController.deleteMultipleChildCompanies(deleteIds);
    expect(res.status).toBe(true);
  });
});
