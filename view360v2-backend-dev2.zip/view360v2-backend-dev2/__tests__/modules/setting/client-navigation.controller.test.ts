import { UpdateClientGeneral } from "modules/settings/doc/clientGeneral-interface";
import {ClientNavigationController} from "../../../src/modules/settings/controllers/client-navigation.controller";

describe('Client Navigation', () => {
  let clientNavigationController = new ClientNavigationController();
  beforeAll(async ()=>{
      jest.clearAllMocks();
  });
  beforeEach(() => {
    clientNavigationController = new ClientNavigationController();
  });
  it('should get all client Navigation ', async () => {
    const req:UpdateClientGeneral = {
        company_name:"Test"
    };

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }
    const res = await clientNavigationController.getAllClientNavigations(request)
    expect(res.status).toBe(true);
  });


  it('should get Update client Navigation ', async () => {


    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }

    let body = {
     menu:"Test"
    }
    const res = await clientNavigationController.updateClientNavigation(body,request)
    expect(res.status).toBe(true);
  });


  it('should set default menu', async () => {

    const request = {
      userDetails: {
        client_id: 'mockClientId'
      }
    }

    let body = {
     menu:"Test"
    }
    const res = await clientNavigationController.setMenuSettingsToDefault(request)
    expect(res.status).toBe(true);
  });

});
