import { CustomHeaderController } from "../../../src/modules/custom-header/controllers/custom-header.controller";
import { AddUpdateCustomHeaderRequestBody,DeleteCustomHeaderRequestBody } from "../../../src/modules/custom-header/doc/custom-header.interface";
describe('CustomHeaderController', () => {
    let controller: CustomHeaderController;
    beforeAll(async ()=>{
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new CustomHeaderController();
    }
    );
    it('should add a custom header', async () => {
        const requestBody: AddUpdateCustomHeaderRequestBody = {
        active: 1,
        config: '{"test":"test"}',
        };
        const request = { userDetails: { client_id: '1' } };
        const result = await controller.add(request,requestBody);
        expect(result).toBeDefined();
        //expect(result.data).toBeDefined();
        //expect(controller.getStatus()).toBe(201);
    });

    it('should update a custom header', async () => {
        const requestBody: AddUpdateCustomHeaderRequestBody = {
        active: 1,
        config: '{"test":"test"}',
        };
        const request = { userDetails: { client_id: '1' } };
        const result = await controller.update(request,requestBody);
        expect(result).toBeDefined();
        //expect(result.data).toBeDefined();
    });

    it('should get a custom header', async () => {
        const request = { userDetails: { client_id: '1' } };
        const result = await controller.get(request);
        expect(result).toBeDefined();
    });

    it('should delete a custom header', async () => {
        const requestBody: DeleteCustomHeaderRequestBody = {
            id: "1"
        };
        const request = { userDetails: { client_id: '1' } };
        const result = await controller.delete(request,requestBody);
        expect(result).toBeDefined();
        expect(result.message).toBeDefined();
    });

});
