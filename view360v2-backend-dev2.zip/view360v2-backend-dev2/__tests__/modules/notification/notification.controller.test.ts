import { dataSource } from "../../../src/core/data-source";
import { NotificationController } from "../../../src/modules/notification/controllers/notification.controller";

describe('NotificationController', () => {
    let controller: NotificationController; 
    beforeEach(() => {
        controller = new NotificationController();
    });

    it('should get notification list', async () => { 
        const request = {
            userDetails: { id: '1', client_id: "1", role_id: "1" },
            query:{length : 6 },
        };
        dataSource.getRepository = jest.fn().mockReturnValue({
            find: jest.fn().mockReturnValue({
                where: jest.fn().mockReturnValue({
                    take: jest.fn().mockReturnValue({
                        order: jest.fn().mockReturnValue([{
                            clientId: request.userDetails.client_id,
                            viewMessage: 0,
                        }])
                    })
                })
            })
        });


        const result = await controller.list(request);
        expect(result.status).toEqual(true);
    });

    it('should get notification count', async () => {
        const request = { userDetails: { id: '1', client_id: "1", role_id: "1" } };
        dataSource.getRepository = jest.fn().mockReturnValue({
            find: jest.fn().mockReturnValue({
                where: jest.fn().mockReturnValue([{
                    clientId: request.userDetails.client_id,
                    viewMessage: 0,
                }])
            })
        });
        const result = await controller.totalCount(request);
        expect(result.status).toEqual(true);

    });
   
    it("should add a User", async () => {
        const requestBody = {
            clientId: 1,
            type: "form",
            senderId: "121",
            receiverId: "123",
            roleType: "xyz",
            message: "lorem ipsum",
            extraMessage: "dummy text",
            viewMessage: 0,
            redirectUrl: "string",
            createdBy: "string",
            createdOn: "string",
            zip: "string",
        };
        const result = await controller.notificationlist(requestBody);
        expect(result).toBeTruthy();
        expect(result.status).toBe(false);
    });

});
