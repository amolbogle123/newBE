import { MapperController } from "../../../src/modules/mapper/controllers/mapper.controller";
import {
    GetMapperListRequest,
    InsertMapperRequest,
    UpdateMapperRequest,
    DeleteMapper,
} from "../../../src/modules/mapper/doc/mapper-interface";

import dbService from "../../../src/services/db.service";
const DataSource = require('../../../src/core/data-source');
const UsersRepository = require('../../../src/entities/users');

DataSource.getRepository = jest.fn((repository) => {
    if (repository === UsersRepository) {
        return UsersRepository;
    }
});


describe("MapperController", () => {
    let controller: MapperController;
    beforeAll(async () => {
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new MapperController();
    });

    it("should get a mapper", async () => {
        dbService._findQueryService = jest.fn(async () => [
            {
                "id": "id",
                "clientId": "clientId",
                "formId": "formId",
                "config": "config",
                "createdOn": "createdOn",
            },
        ]);
        const requestBody: GetMapperListRequest = {
            draw: 1,
            columns: [
                {
                    data: "formName",
                    name: "",
                    searchable: true,
                    orderable: true,
                    search: { value: "", regex: false },
                },
                {
                    data: "createdOn",
                    name: "",
                    searchable: true,
                    orderable: true,
                    search: { value: "", regex: false },
                },
                {
                    data: "id",
                    name: "",
                    searchable: true,
                    orderable: false,
                    search: { value: "", regex: false },
                },
            ],
            order: [{ column: 1, dir: "desc" }],
            start: 0,
            length: 10,
            search: { value: "", regex: false },
            type: "excel",
        };
        const request = { userDetails: { client_id: "1" } };
        const result: any = await controller.mapperList(requestBody, request);
        expect(result).toBeTruthy();
        expect(result).toEqual({
            data: [
                {
                    "id": "id",
                    "clientId": "clientId",
                    "formId": "formId",
                    "config": "config",
                    "createdOn": "createdOn",
                },
            ],
            recordsFiltered: 1,
            recordsTotal: 1,
            message: "Successfully executed.",
            status: true
        });

    });

    it("should get all mapper as per type", async () => {
        const request = { userDetails: { client_id: "1" } };
        dbService._findQueryService = jest.fn(async () => [
            {
                "id":"id", 
                "columnHeader":"columnHeader",
                "formId":"formId"
            },
        ]);
        const result: any = await controller.getAllMapper("excel", request);

        expect(result).toBeTruthy();
        expect(result.status).toEqual(true);
        expect(result).toEqual({data:[
            {
                "id":"id",
                "columnHeader":"columnHeader",
                "formId":"formId"
            }],
            message: "Successfully executed.",
            status: true
        });
    });

    it("should add a mapper", async () => {
        const requestBody: InsertMapperRequest = {
            columnHeader: "4",
            config: [
                {
                    fieldObj: {
                        label: "Received Date",
                        tableView: true,
                        showongrid: true,
                        key: "textfield0",
                        type: "textfield",
                    },
                    isUse: true,
                    label: "Received Date",
                },
            ],
            fileConfig: {
                filePath: "public/xlsx-mapper/1694013205381.xls",
                name: "Disapproved Intake Worksheet_wData-updated (1).xls",
            },
            formDetails: {},
            type: "excel",
        };
        const request = { userDetails: { client_id: "1" } };
        const result: any = await controller.saveMapper(requestBody, request);
        expect(result).toBeDefined();
        expect(result.status).toEqual(true);
    });

    it("should get a mapper by id", async () => {
        const id = "34e52f07-9376-41f1-8114-166054cd81d9";
        const request = { userDetails: { client_id: "1" } };
        const result: any = await controller.getMapper(id, request);
        expect(result).toBeTruthy();
    });

    it("should update a mapper", async () => {
        const requestBody: UpdateMapperRequest = {
            formId: "9d23d27c-c4b8-403d-8948-3677f424c4fd",
            columnHeader: 4,
            config: [
                {
                    fieldObj: {
                        label: "Received Date",
                        tableView: true,
                        showongrid: true,
                        key: "textfield0",
                        type: "textfield",
                    },
                    isUse: true,
                    label: "Received Date",
                },
            ],
            type: "excel",
        };
        const id = "34e52f07-9376-41f1-8114-166054cd81d9";
        const request = { userDetails: { client_id: "1" } };
        const result: any = await controller.updateMapper(
            id,
            requestBody,
            request
        );
        expect(result).toBeDefined();
    });

    it("should delete a mapper", async () => {
        const requestBody: DeleteMapper = {
            id: ["1"],
        };
        const request = { userDetails: { client_id: "1" } };
        const result: any = await controller.deleteMapper(requestBody, request);
        expect(result).toBeDefined();
    });
});
