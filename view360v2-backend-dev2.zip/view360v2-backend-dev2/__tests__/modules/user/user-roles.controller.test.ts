import { UserRolesController } from "../../../src/modules/user/controllers/user-roles.controller";
import { DeleteRoles } from "../../../src/modules/user/doc/user-roles.interface";
import { CommonHelper } from "../../../src/utils/helpers/common.helper";
import dbService from "../../../src/services/db.service";

describe("UserRolesController", () => {
    // Create mock request body parameters
    const requestBody = {
        name: "Super Admin",
        description: "All Access",
        permission: "100101",
    };

    const request = { userDetails: { client_id: "1" },query:{} };
    // Mock the CommonHelper functions
    CommonHelper.apiSwaggerSuccessResponse = jest.fn((data) => data);
    CommonHelper.apiSwaggerErrorResponse = jest.fn((error) => error);

    let controller: UserRolesController;

    beforeEach(() => {
        controller = new UserRolesController();
    });
    it("should add a Role", async () => {
        dbService._createQueryService = jest.fn(async (repository, data) => ({
            id: "id",
            ...data,
        }));
        // Mock the setStatus method
        controller.setStatus = jest.fn();
        const result = await controller.addRole(requestBody, request);
        expect(result).toBeDefined();
        expect(controller.setStatus).toHaveBeenCalledWith(201);
        expect(result.data).toEqual(
            {
                id: "id",
                name: "Super Admin",
                description: "All Access",
                permission: "\"100101\"",
                isDefaultRole: 0,
                clientId: "1",
                createdBy: undefined,
              }
        );

    });

    it("should update a Role", async () => {
        dbService._updateQueryService = jest.fn(async () => ({
            id: "id",
            ...requestBody,
        }));
        const pathId = "xyz";
        const result = await controller.editRole(pathId, requestBody, request);
        expect(result).toBeDefined();
        expect(result).toEqual(
            {
                data: {
                  id: "id",
                  name: "Super Admin",
                  description: "All Access",
                  permission: "100101",
                },
              }
        );

    });

    it("should get roles details", async () => {
        dbService._findQueryService = jest.fn(async () => [
            {
                id: "id",
                ...requestBody,
            },
        ]);
        const pathId = "xyz";
        request.query = { current: 1, perPage: 10,clientId:1 };
        const result = await controller.getRoleDetails(pathId, request);
        expect(result).toBeDefined();
        expect(result).toEqual({
            data: {
              id: "id",
              name: "Super Admin",
              description: "All Access",
              permission: 100101,
            },
            status: true,
          });

    });


    //  it("should get all Roles details", async () => {
    //     dbService._findQueryService = jest.fn(async () => [
    //         {
    //             id: "id",
    //             ...requestBody,
    //         },
    //     ]);
    //     const result = await controller.getAllRoles(request);
    //     expect(result).toBeDefined();

    // });

    it("should delete role details", async () => {
        const request: DeleteRoles = {
            id: "0f7fbd56-2fd6-40c6-a771-0a3659f9f179",
        };
        dbService._deleteQueryService = jest.fn(async () => ({
            id: "id",
            ...requestBody,
        }));
        const result = await controller.deleteRoles(request);
        expect(result).toBeDefined();
        expect(result).toEqual(
            {
                data: {
                  id: "id",
                  name: "Super Admin",
                  description: "All Access",
                  permission: "100101",
                },
              });

    });
});
