import { RoleInvitesController } from "../../../src/modules/user/controllers/role-invites.controller";
import { InviteRequestBody, InviteRegisterRequestBody} from "../../../src/modules/user/doc/invites.interface";
import container from "../../../__mocks__/typedi";
const DataSource = require('../../../src/core/data-source');
import {CommonHelper} from "../../../src/utils/helpers/common.helper";
import dbService from "../../../src/services/db.service";
import { CommunicationHelper } from "../../../src/utils/helpers/communication.helper";
import * as MailTemplateRepository from "../../../src/entities/mail-template";
import * as UsersRepository from "../../../src/entities/users";
describe('RoleInvitesController', () => {
    let controller: RoleInvitesController;
    let communicationHelperService: CommunicationHelper=new CommunicationHelper();
    CommonHelper.apiSwaggerSuccessResponse = jest.fn((data) => data);
    CommonHelper.apiSwaggerErrorResponse = jest.fn((error) => error);
    communicationHelperService.htmlReplace = jest.fn((key: string, type: string, userDetails: any, configData: any)  => {
        return Promise.resolve();
    });
    communicationHelperService.nodeMailerService = jest.fn((mailParams: any) => {
        return Promise.resolve();
    });

    beforeAll(async ()=>{
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new RoleInvitesController();
        
    });

    it('should add a user invite and get error as User already exist', async () => {
        const requestBody: InviteRequestBody = {
        role: 'Test',
        email: 'test@test.com',
        emailTemplate: 'test',
        newEmail: ''
        };
        const request = { userDetails: { client_id: '1' } };
        dbService._findQueryService = jest.fn(async () => [
            {
                id: '1',
                email: '',
                firstname: '',
                lastname: '',
                phoneNumber: '',
                password: '',
                clientId: 1,
                roleId: '1',
                emailVerificationCode: '',
                emailVerified: false,
                status: true,
                createdAt: new Date(),
                updatedAt: new Date(),
            }]);
        const result = await controller.createRoleInvite(request,requestBody);
        expect(result).toBeDefined();
        expect(result.error).toBeDefined();
        expect(result.error.error_description).toEqual('User already exist');
    });

    it('should add a user invite and send email successfully', async () => {
       

            DataSource.dataSource.getRepository = jest.fn((repository) => {
                if (repository === UsersRepository) {
                    return UsersRepository; // Mock UsersRepository
                } else if (repository === MailTemplateRepository) {
                    return MailTemplateRepository; // Mock MailTemplateRepository
                }
            });
            DataSource.dataSource.getRepository.find = jest.fn(async () => [
                {
                    id: '1',
                    subject: '',
                    body: '',
                    type: '',
                    clientId: 1,
                    status: true,
                    createdAt: new Date(),
                    updatedAt: new Date(),
                }]);

        controller.setStatus = jest.fn();
        dbService._findQueryService = jest.fn(async () => [
            ]);
        dbService._createQueryService = jest.fn(async () => ({
            id: '1',
            email: '',
            firstname: '',
            lastname: '',
            phoneNumber: '',
            password: '',
            clientId: 1,
            roleId: '1',
            emailVerificationCode: '',
            emailVerified: false,
            status: true,
            createdAt: new Date(),
            updatedAt: new Date(),
        }));
        dbService._updateQueryService = jest.fn(async () => ({
            id: '1',
            email: '',
            firstname: '',
            lastname: '',
            phoneNumber: '',
            password: '',
            clientId: 1,
            roleId: '1',
            emailVerificationCode: '',
            emailVerified: false,
            status: true,
            createdAt: new Date(),
            updatedAt: new Date(),
        }));

        const requestBody: InviteRequestBody = {
        role: 'Test',
        email: 'test@test.com',
        emailTemplate: 'test',
        newEmail: ''
        };
        const request = { userDetails: { client_id: '1' } };

        const result = await controller.createRoleInvite(request,requestBody);
        expect(result).toBeDefined();
        expect(controller.setStatus).toHaveBeenCalledWith(201);
    });

    it('should get all user invites',async()=>{
        const request = { userDetails: { client_id: '1' }, query: { first: 1, rows: 10,sortField:'role',sortOrder:1,
        filters:"{%22email%22:[{%22value%22:%22test2%22,%22matchMode%22:%22startsWith%22,%22operator%22:%22and%22}],%22role%22:[{%22value%22:%22User%22,%22matchMode%22:%22contains%22,%22operator%22:%22and%22}],%22status%22:[{%22value%22:null,%22matchMode%22:%22startsWith%22,%22operator%22:%22and%22}],%22date%22:[{%22value%22:null,%22matchMode%22:%22startsWith%22,%22operator%22:%22and%22}]}" } };
        const result = await controller.getRoleInvites(request);
        expect(result).toBeDefined();
    });

    it('should verify a user invite',async()=>{
        const request = { userDetails: { client_id: '1' }, params: { code: '123' }};
        const result = await controller.verifyEmail(request.params.code);
        expect(result).toBeDefined();
    });

    it('should register a user invite',async()=>{
        const requestBody: InviteRegisterRequestBody = {
            email: "test@test.com",
            firstName: "test",
            lastName: "test",
            phoneNumber: "1234567890",
            password: "1234567890",
            clientId: 1,
            roleId: "1",
            emailVerificationCode: "1234567890"
        };
        const result = await controller.register(requestBody);
        expect(result).toBeDefined();
    });
});
