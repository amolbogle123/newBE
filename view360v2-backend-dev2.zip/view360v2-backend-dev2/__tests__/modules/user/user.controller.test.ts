import { UserController } from "../../../src/modules/user/controllers/user.controller";
import { UserRequest } from "../../../src/modules/user/doc/user.interface";
import dbServiceMock from "../../../__mocks__/dbService.mock";

describe("UserController", () => {
    let controller: UserController;

    beforeEach(() => {
        controller = new UserController();
    });

    it("should get user details", async () => {
        const pathId = "xyz";
        const request = { userDetails: { client_id: "1" } };
        const result = await controller.getUserDetail(pathId, request);
        expect(result).toBeDefined();
    });

    it("should add a User", async () => {
        const requestBody: UserRequest = {
            first_name: "test",
            last_name: "test_l",
            username: "test_test_l",
            email: "test@mailinator.com",
            mobile: "0000000000",
            password: "Epik@123",
            address: "NY",
            role_id: "zyx",
            state: "string",
            country: "string",
            city: "string",
            zip: "string",
        };
        const request = { userDetails: { client_id: "1" } };

        const result = await controller.createUser(requestBody, request);
        expect.anything()
        expect(result).toBeDefined();
    });

    it("should update a User", async () => {
        const requestBody: UserRequest = {
            first_name: "test",
            last_name: "test_l",
            username: "test_test_l",
            email: "test@mailinator.com",
            mobile: "0000000000",
            password: "Epik@123",
            address: "NY",
            role_id: "zyx",
            state: "string",
            country: "string",
            city: "string",
            zip: "string",
        };
        const request = { userDetails: { client_id: "1" } };
        const pathId = "xyz";
        const result = await controller.editUser(pathId, requestBody, request); 
        expect.anything()

        expect(result).toBeDefined();
    });

    it("should delete user details", async () => {
        const requestBody = { id: ["xyz"] };
        const request = { userDetails: { client_id: "1" } };
        const result = await controller.deleteUser(requestBody, request);
        expect(result).toBeDefined();
    });

    it("should get all user details", async () => {
        const roleId = "xyz";
        const request = { userDetails: { client_id: "1" } };
        const result = await controller.allUser(request, roleId);
        expect(result).toBeDefined();
    });

    it("should update a User  profile image", async () => {
        const requestBody = { url: "xzy.com" };
        const request = { userDetails: { client_id: "1" } };
        const pathId = "xyz";
        const result = await controller.updateUserImage(
            pathId,
            requestBody,
            request
        );
        expect(result).toBeDefined();
    });

    it("should get user role details", async () => {
        const pathId = "xyz";
        const request = { userDetails: { client_id: "1" } };
        const result = await controller.getUserByRole(pathId, request);
        expect(result).toBeDefined();
    });

     it("should get user getAllUserList", async () => {
        const pathId = "xyz";
        const request = { userDetails: { client_id: "1" },body:{start:5,limit:5} };
        const result = await controller.getAllUserList(request);
        expect(result).toBeDefined();
    });

});
