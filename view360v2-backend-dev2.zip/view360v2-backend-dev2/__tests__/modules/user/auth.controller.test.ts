import { AuthController } from "../../../src/modules/user/controllers/auth.controller";
import { LoginRequest } from "../../../src/modules/user/doc/auth.interface";
import dbServiceMock from "../../../__mocks__/dbService.mock";

describe("AuthController", () => {
    let controller: AuthController;
    beforeEach(() => {
        controller = new AuthController();
    });

    it("should login an User", async () => {
        const requestBody: LoginRequest = {
            email: "test@mailinator.com",
            password: "epik123",
            token: "string",
            Skip2FA: false,
            appType: "string",
        };
        const request = { userDetails: { client_id: "1" } };
        const result = await controller.login(requestBody, request);
        expect(result).toBeDefined();
    });

    it("should logout user", async () => {
        const request = { userDetails: { client_id: "1" } };
        const result = await controller.logout(request);
        expect(result).toBeDefined();
    });

    it("should check SSO status ", async () => {
        const request = { headers: { origin: "localhost" } };
        const result = await controller.ssoStatus(request);
        expect(result).toBeDefined();
    });
});
