import { UploadFileController } from "../../../src/modules/upload-files/controllers/upload-file.controller";
import Container  from "typedi";
import fs from "fs";
import { Response } from 'express';
describe("UploadFileController", () => {    
    let controller: UploadFileController;
    type MockedResponse = Response<any, Record<string, any>> & {
        status: jest.Mock<any, any>;
        json: jest.Mock<any, any>;
      };
    const mockRequest = (overrides = {}) => ({
        body: {},
        file: null,
        ...overrides,
      });
      
      const mockResponse = () => {
        const res: any = {
          status: jest.fn().mockReturnThis(),
          json: jest.fn(),
        };
        res.status = jest.fn().mockReturnValue(res);
        return res;
      };
    beforeAll(async () => {
      jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new UploadFileController();
    });

    describe('base64Img', () => {
        it('should return an error response if base64Data is missing', async () => {
          const req = { body: { base64Data: null } };
          const res = mockResponse();
          const nextt = jest.fn();
          await controller.base64Img(req, res,nextt);
    
          expect(res.json).toHaveBeenCalledWith({ 
            data:null,
            error: 'Required field is missing',
            message:"Successfully executed.",
            status:true
         });
        });
    
        it('should save a base64 image and return a success response', async () => {
          const base64Data = 'data:image/png;base64,iVBORw...'; // Replace with a valid base64 string
          const req = mockRequest({ body: { base64Data } });
          const res = mockResponse();
          let nextt= jest.fn();
    
          await controller.base64Img(req, res,nextt);
    
          expect(res.status).toHaveBeenCalledWith(200);
          expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ data: { filePath: expect.any(String) } }));
        });
      });

      describe('mediaAssets', () => {
        it('should return an error response if request.file is missing', async () => {
          const req = { file: null };
          const res = mockResponse();
          const nextt = jest.fn();
          await controller.mediaAssets(req, res,nextt);
    
          expect(res.json).toHaveBeenCalledWith({ 
            data:null,
            error: 'Required field is missing',
            message:"Successfully executed.",
            status:true
         });
        });
    
        it('should save a media asset and return a success response', async () => {
          const fakeFile = {
            destination: './public/upload64-files/',
            filename: 'testfile.png',
            path: '/path/to/testfile.png',
            originalname: 'testfile.png',
          };
          const req = mockRequest({ file: fakeFile });
          const res = mockResponse();
          let nextt= jest.fn();
    
          // Mock the necessary dependencies (fs and Container)
          jest.spyOn(fs, 'existsSync').mockReturnValue(true);
          jest.spyOn(fs, 'writeFileSync').mockImplementation(() => {});
          jest.spyOn(Container, 'get').mockReturnValue({ manager: { save: jest.fn() } });
    
          await controller.mediaAssets(req, res,nextt);
    
          expect(res.status).toHaveBeenCalledWith(200);
          expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ data: expect.any(Object) }));
        });
    
        it('should handle a failed file save and return an error response', async () => {
          const fakeFile = {
            destination: './public/upload64-files/',
            filename: 'testfile.png',
          };
          const req = mockRequest({ file: fakeFile });
          const res = mockResponse();
          let nextt= jest.fn();
    
          // Mock the necessary dependencies (fs)
          jest.spyOn(fs, 'existsSync').mockReturnValue(false);
    
          await controller.mediaAssets(req, res,nextt);
    
          expect(res.json).toHaveBeenCalledWith({ 
            data:null,
            error: 'Please try again',
            message:"Successfully executed.",
            status:true 
        });
        });
      });
});
    