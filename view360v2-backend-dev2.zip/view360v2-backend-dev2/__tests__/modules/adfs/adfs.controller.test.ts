import Container from "typedi";
import { AsdfController } from "../../../src/modules/adfs-ad/controllers/adfs.controller";
import { DataSource } from "typeorm";
import { CommonUtil } from "../../../src/utils/common.util";
import passport from "passport";
import { Strategy } from "passport-saml";

jest.mock('passport-saml', () => {
    return {
        Strategy: jest.fn((options, callback) => ({
            authenticate: jest.fn((req, res) => {
                const mockProfile = {
                };
                callback(mockProfile, () => {
                    console.log('Passport Authenticate Success');
                });
            }),
        })),
    };
});
describe('AsdfController', () => {
    let controller: AsdfController;
    beforeAll(async () => {
        jest.clearAllMocks();
        process.env.BASE_URL = 'http://localhost:3000';
    });
    beforeEach(() => {
        controller = new AsdfController();
    });

    it('should call getLoginByClientUrl and get client URL', async () => {
        Container.get(DataSource).getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockReturnValue({
                id: 1
            })
        });
        const result: any = await controller.getLoginByClientUrl();
        expect(result).toEqual(process.env.BASE_URL + `/adfs/login/1`);
    });
    it('should call getLoginByClientUrl and get client URL as null', async () => {
        Container.get(DataSource).getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockReturnValue(null)
        });
        const result: any = await controller.getLoginByClientUrl();
        expect(result).toEqual(null);
    });

    it('should call getAsdfConnect and get valid url', async () => {
        Container.get(DataSource).getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockReturnValue({
                id: 1
            })
        });
        const req = {}; // You can customize the req object as needed
        const res = {
            json: jest.fn().mockImplementation((data) => {
                return data;
            }),
        };
        const next = jest.fn();
        controller.getLoginByClientUrl = jest.fn().mockReturnValue(process.env.BASE_URL + `/adfs/login/1`);
        await controller.getAsdfConnect(req, res, next);
        expect(res.json.mock.results.length).toEqual(1);
        expect(res.json.mock.results[0].value).toEqual({ url: process.env.BASE_URL + `/adfs/login/1` });
    });
    it('should call getAsdfConnect and get url as null', async () => {
        Container.get(DataSource).getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockReturnValue(null)
        });
        const req = {}; // You can customize the req object as needed
        const res = {
            json: jest.fn().mockImplementation((data) => {
                return data;
            }),
        };
        const next = jest.fn();
        controller.getLoginByClientUrl = jest.fn().mockReturnValue(null);
        await controller.getAsdfConnect(req, res, next);
        expect(res.json.mock.results.length).toEqual(1);
        expect(res.json.mock.results[0].value).toEqual({ url: null });
    });

    it('should call getAdfsLoginRequestById and get valid url', async () => {
        let backendurl = "test";
        passport.use('saml', new Strategy(
            {
                callbackUrl: `${backendurl}/adfs/callback`,
                issuer: `${backendurl}/adfs/callback`,
                cert: null,
                identifierFormat: null,
                entryPoint: "",
            }, (profile, done) => {
                //return done();
            }
        ));
        const request = {
            params: {
                id: 1
            },
            headers: {
                host: 'localhost'
            }
        }
        const response = {
            status: jest.fn().mockImplementation((statusCode) => ({
                json: jest.fn().mockImplementation((data) => {
                    return data;
                }),
            })),
        };
        const next = jest.fn();
        let mockGetRepositoryResults = [{
            findOne: jest.fn().mockReturnValue({
                id: 1
            })
        }, {
            findOne: jest.fn().mockReturnValue({
                id: 1
            })
        },
        {
            findOne: jest.fn().mockReturnValue({
                id: 1,
                name: 'test',
                isActive: true,
                config: {
                    url: 'test'
                }
            })
        }];
        const getRepositoryMock = jest.fn();
        mockGetRepositoryResults.forEach(mockResult => {
            getRepositoryMock.mockReturnValueOnce(mockResult);
        });
        Container.get(DataSource).getRepository = getRepositoryMock;
        CommonUtil.getOriginUrl = jest.fn().mockReturnValue('http://localhost');

        await controller.getAdfsLoginRequestById(request, response, next);
    });
    it('should call getAdfsLoginRequestById and no certificate found', async () => {
        const request = {
            params: {
                id: 1
            },
            headers: {
                host: 'localhost'
            }
        }
        const response = {
            status: jest.fn().mockImplementation((statusCode) => ({
                json: jest.fn().mockImplementation((data) => {
                    return data;
                }),
            })),
        };
        const next = jest.fn();
        Container.get(DataSource).getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockReturnValue(null)
        });
        await controller.getAdfsLoginRequestById(request, response, next);
        expect(response.status.mock.results.length).toEqual(1);
        expect(response.status.mock.results[0].value.json.mock.results[0].value).toEqual({ status: true, message: 'no certificate found, calling redirect !' });
    });

    it('should call getAdfsCallback & handle SAMLResponse then redirect', async () => {
        jest.mock('saml-encoder-decoder-js', () => {
            return {
                decodeSamlPost: jest.fn((xmlData, callback) => {
                    // Your mock implementation here
                }),
            };
        });
        jest.mock('xml2js');
        const req = {
            body: {
                SAMLResponse: 'mocked-saml-response',
            },
        };
        const res = {
            redirect: jest.fn(),
        };

        const mockParseString = jest.fn((xmlResponse, options, callback) => {
            // Simulate successful parsing
            const result = {
                Response: {
                    Assertion: [
                        {
                            AttributeStatement: [
                                {
                                    Attribute: [
                                        {
                                            AttributeValue: [
                                                {
                                                    _: 'mocked-user-data',
                                                },
                                            ],
                                        },
                                    ],
                                },
                            ],
                        },
                    ],
                },
            };
            callback(null, result);
        });
        // Execute the method
        await controller.getAdfsCallback(req, res, null);
        expect(res.redirect).toHaveBeenCalledWith(
            expect.stringMatching(new RegExp(`${process.env.VIEW360v2FE_URL}/saml\\?data=`))
        );


    });

    it('should call adfsGenerateToken and generate Token', async () => {
        const req = { params: { email: 'admin@epikso.com' } }; // You can customize the req object as needed
        const res = {
            status: jest.fn().mockImplementation((statusCode) => ({
                json: jest.fn().mockImplementation((data) => {
                    return data;
                }),
            })),
        };
        const next = jest.fn();
        Container.get(DataSource).getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockReturnValue({
                id: 1,
                roleId: 1,
                name: 'test',
                username: 'test',
                email: 'test@test.com',
                clientid: 1,
                isSuperAdmin: true,
                isActive: true,
                config: {
                    url: 'test'
                }
            })
        });
        await controller.adfsGenerateToken(req, res, next);
        expect(res.status.mock.results.length).toEqual(1);
        expect(res.status.mock.results[0].value.json.mock.results[0].value).toEqual(
            {
                status: true,
                data: {
                    status: true,
                    data: expect.stringMatching(new RegExp(`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9`)),
                    userData: {
                        id: 1,
                        roleid: 1,
                        name: "test",
                        username: "test",
                        email: "test@test.com",
                        clientid: 1,
                        issuperadmin: true,
                        isactive: true,
                        config: {
                            url: "test",
                        },
                    },
                    email: "admin@epikso.com",
                    username: null,
                    err: null,
                },
                message: "Successfully executed.",
            }
        );

    });

    it('should call adfsGenerateToken and No user found with email', async () => {
        const req = { params: { email: 'admin@epikso.com' } }; // You can customize the req object as needed
        const res = {
            status: jest.fn().mockImplementation((statusCode) => ({
                json: jest.fn().mockImplementation((data) => {
                    return data;
                }),
            })),
        };
        const next = jest.fn();
        Container.get(DataSource).getRepository = jest.fn().mockReturnValue({
            findOne: jest.fn().mockReturnValue(null)
        });
        await controller.adfsGenerateToken(req, res, next);
        expect(res.status.mock.results.length).toEqual(1);
        expect(res.status.mock.results[0].value.json.mock.results[0].value).toEqual(
            {
                status: true,
                data: {
                    status: false,
                    data: null,
                    userData: null,
                    email: "admin@epikso.com",
                    username: null,
                    err: "No user found with email : admin@epikso.com",
                },
                message: "Successfully executed.",
            }
        );
    });
});






