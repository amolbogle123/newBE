import {
    NotificationTemplateController
} from "../../../src/modules/template-builder/controllers/notification-template.controller";
import {DeleteTemplateRequest} from "../../../src/modules/template-builder/doc/notificationTemplate-interface";



describe('NotificationTemplateController', () => {
    let controller: NotificationTemplateController;
    beforeAll(async ()=>{
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new NotificationTemplateController();
    });

    it('should add a Notification Template', async () => {
        const requestBody = {
            clientId: '1',
            createdBy: '1',
            updatedBy: '1',
            formMapKey: null
        };
        const request = { userDetails: { client_id: '1' } };
        const result = await controller.createTemplate(requestBody,request);
        expect(result).toBeTruthy();
        expect(result.status).toEqual(true);
    });

    it('should get all Notification Template',async()=>{
        const request = { userDetails: { client_id: '1' } };
        const result = await controller.listTemplate(request);
        expect(result).toBeTruthy();
        expect(result.status).toEqual(true);
    });

    it('should edit a Notification Template',async()=>{
        let payload: any = {};
        const request = { userDetails: { client_id: '1', id: '1' } };
        const requestBody = {
            name: 'abc',
            message: 'Success',
            formMapKey: null
        };
        payload.clientId = request.userDetails.client_id;
        payload.createdBy = request.userDetails.id;
        payload.name = requestBody.name;
        payload.message = requestBody.message;
        const result = await controller.updateTemplate(requestBody,request,'1');
        expect(result).toBeTruthy();
    });

    it('should get Notification Template according to Id',async()=>{
        const result = await controller.getTemplate('1');
        expect(result).toBeTruthy();
        expect(result.status).toEqual(true);
    });

    it('should delete a Notification Template',async()=>{
        const requestBody: DeleteTemplateRequest = {
            id: "1",
        };
        const result = await controller.deleteTemplate(requestBody);
        expect(result).toBeTruthy();
    });
});
