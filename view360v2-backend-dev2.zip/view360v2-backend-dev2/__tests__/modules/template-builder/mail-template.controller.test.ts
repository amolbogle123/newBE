import {MailTemplateController} from "../../../src/modules/template-builder/controllers/mail-template.controller";
import {SetResponse} from "utils/helpers/common.helper";
describe('MailTemplateController', () => {
    let controller: MailTemplateController;
    beforeAll(async ()=>{
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new MailTemplateController();
    });
    it('should add a Mail Template', async () => {
        const requestBody = {
            clientId: '39906290-4ea4-4f68-bb6f-8be4ff69f15f',
            createdBy: '1',
            updatedBy: '1',
            formMapKey: null
        };
        const request = { userDetails: { client_id: '39906290-4ea4-4f68-bb6f-8be4ff69f15f' } };
        const result = await controller.createTemplate(requestBody,request);
        expect(result).toBeTruthy();
        expect(result.status).toEqual(true);
    });

    it('should get all Mail Template',async()=>{
        const request = { userDetails: { client_id: '39906290-4ea4-4f68-bb6f-8be4ff69f15f' } };
        const result = await controller.listTemplate(request);
        expect(result).toBeTruthy();
        expect(result.status).toEqual(true);
    });

    it('should edit a Mail Template',async()=>{
        const requestBody = {
            clientId: '39906290-4ea4-4f68-bb6f-8be4ff69f15f',
            createdBy: '1',
            formMapKey: null
        };
        const request = { userDetails: { client_id: '39906290-4ea4-4f68-bb6f-8be4ff69f15f' } };
        const result = await controller.updateTemplate(request,requestBody,'1');
        expect(result).toBeTruthy();
    });

    it('should get Mail Template according to Id',async()=>{
        const request = { params: { id: '0956695b-4704-4f0e-aaef-3873cc97d964' } };
        const result = await controller.getTemplate(request,'0956695b-4704-4f0e-aaef-3873cc97d964');
        expect(result).toBeTruthy();
        expect(result.status).toEqual('error');
    });

    it('should delete a Mail Template',async()=>{
        const requestBody = {
            id: '0956695b-4704-4f0e-aaef-3873cc97d964',
        };
        const result: SetResponse = await controller.deleteTemplate(requestBody);
        expect(result).toBeTruthy();
    });
});
