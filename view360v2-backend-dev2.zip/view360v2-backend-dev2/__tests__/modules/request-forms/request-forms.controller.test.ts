import { RequestFormsController } from "../../../src/modules/request-forms/controllers/request-forms.controller";

const DataSource = require('../../../src/core/data-source');
const UsersRepository = require('../../../src/entities/users');

DataSource.getRepository = jest.fn((repository) => {
    if (repository === UsersRepository) {
        return UsersRepository;
    }
});

describe("RequestFormsController", () => {
    let controller: RequestFormsController;
    beforeAll(async () => {
        jest.clearAllMocks();
    });
    beforeEach(() => {
        controller = new RequestFormsController();
    });

    it("should get a request form", async () => {
        const urlPath = "34e52f07-9376-41f1-8114-166054cd81d9";
        const result: any = await controller.details(urlPath);
        expect(result).toBeTruthy();
    });

    it("should get a request form", async () => {
        const id = "34e52f07-9376-41f1-8114-166054cd81d9";
        const result: any = await controller.getCustomForm(id);
        expect(result).toBeTruthy();
    });

    it("should add a request form", async () => {
        const request = {
            body: {
                formId: "34e52f07-9376-41f1-8114-166054cd81d9",
                data: {},
                client_id: "1",
                urlPath: "34e52f07-41f1-9376-8114-166054cd81d9",
                userid: "34e52f07-8114-41f1-9376-166054cd81d9",
            },
        };
        const result: any = await controller.submitCustomForm(request);
        expect(result).toBeDefined();
    });
});
