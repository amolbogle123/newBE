import type {NextFunction, Request, Response} from "express";

export const getMocks = () => ({
    next: jest.fn() as jest.Mock<NextFunction>,
    request: {
        userDetails: {
            id: "myId",
            client_id: "clientId",
        },
        body: {},
        url: "",
        query: '',
        params: { },
    } as unknown as Request,
    response: {
        on: jest.fn(),
        json: jest.fn().mockReturnThis(),
        status: jest.fn().mockReturnThis(),
    } as unknown as Response,
});
